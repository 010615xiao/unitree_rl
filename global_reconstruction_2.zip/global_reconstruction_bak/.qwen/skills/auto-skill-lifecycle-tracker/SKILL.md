---
name: lifecycle-tracker
description: Object lifecycle tracking with depth-ray state detection (persisting/occluded/disappeared), miss-count death threshold, merged-state propagation to constituents, and irreversible object death
source: auto-skill
extracted_at: '2026-07-02T12:31:33.958Z'
---

# Object Lifecycle Tracker

## Problem

During incremental reconstruction, objects are detected frame-by-frame. Need to track:
- Birth frame, observed frames, centroid trajectory per object instance
- Object state each frame: persisting, occluded, or disappeared (via depth ray comparison)
- Miss count with death threshold — only mark permanently dead after consecutive misses
- State propagation from merged objects back to all constituent originals via `_merged_from`
- Irreversible death — once dead, future detections at same location create new instances

## Architecture

### State Detection (`object_state_detector.py`)

Depth ray comparison determines object state per frame:

1. **Project** each merged object's 3D points to image plane → get pixel coords + expected depth
2. **Sample** actual depth from depth map at those pixels (mask-based, not bbox, with edge erosion)
3. **Classify** per pixel: `|actual_depth - expected_depth| < depth_tolerance` → match
4. **Decide state** by match ratio:
   - `match_ratio >= persist_ratio_threshold` → **PERSISTING**
   - `match_ratio < threshold` but many pixels show closer depth → **OCCLUDED**
   - Otherwise → **DISAPPEARED**

Key: occlusion detection is depth-primary — if something closer blocks the ray, it's occluded regardless of what name the closer surface has.

### Lifecycle Tracker (`lifecycle_tracker.py`)

```python
@dataclass
class ObjectInstance:
    obj_id: int
    category: str
    birth_frame: str
    observed_frames: list[str]
    centroid_trajectory: list[tuple]  # (frame_id, cx, cy, cz, point_count)
    is_alive: bool = True
    miss_count: int = 0
    current_state: str = "unknown"
```

Key API methods:
- `register_object()` — new instance at birth frame
- `update_observation(state="persisting")` — records observation, resets miss_count when persisting
- `increment_miss_count(death_threshold=5)` — increments miss; marks `is_alive=False` when threshold exceeded
- `get_alive_instances()` — returns only alive instances
- `record_merge_groups()` — per-frame lightweight merge groups

### Config (`config.yaml`)

```yaml
visibility_viz:
  state_detection_enabled: true
  depth_tolerance: 0.15          # meters, sensor noise + surface thickness
  min_valid_samples: 20          # minimum pixels for reliable classification
  persist_ratio_threshold: 0.5   # fraction of matching pixels
  miss_death_threshold: 5        # consecutive misses before permanent death
```

## Integration in Main Loop

After `visualize_visibility()` returns `_vis_records`:

```python
if state_detection_enabled:
    state_results = detect_object_states(
        merged_objects=_merged_objects, K=K, T_w2c=T_w2c,
        depth_map=depth, max_distance=..., depth_tolerance=...,
        min_valid_samples=..., persist_ratio=...,
    )
    for mi, mobj in enumerate(_merged_objects):
        constituents = mobj.get('_merged_from', [mi])
        state = state_by_idx[mi].state
        if state == PERSISTING:
            for orig_idx in constituents:
                tracker.update_observation(orig_idx, frame_id, ..., state='persisting')
        else:  # OCCLUDED or DISAPPEARED
            for orig_idx in constituents:
                tracker.increment_miss_count(orig_idx, frame_id, state=..., death_threshold=...)
```

## Key Design Decisions

1. **Depth-primary, name-secondary** — Occlusion is detected by depth mismatch regardless of object name. A wall in front of a chair correctly causes occlusion.
2. **Mask-based sampling** — Uses projected pixel region (with edge erosion), not bbox, to avoid noise/outlier interference from bbox boundaries.
3. **Merged state propagation** — State detected on a merged object propagates to ALL constituent original objects via `_merged_from`.
4. **Miss count threshold** — Prevents premature death from transient occlusions. Only consecutive misses exceeding threshold cause permanent death.
5. **Irreversible death** — Dead objects cannot be resurrected. Future detections at same location create new instances.
6. **Fallback mode** — When `state_detection_enabled=false`, reverts to simple observation updates for all visible objects.
