#!/usr/bin/env python3
"""
3D 场景重建 + 物体分割 + 拓扑图生成

服务依赖:
- VLM (RoboBrain2.5-8B): http://localhost:8008/v1/chat/completions
- SAM 3.1: http://localhost:20023/predict
"""

import numpy as np
import open3d as o3d
import cv2
import yaml
import time
import json
from pathlib import Path
from datetime import datetime
from tqdm import tqdm
import requests
import base64
import re
from collections import Counter, defaultdict
import matplotlib.pyplot as plt

from global_reconstruction.segmentation.segment_rooms import segment_rooms, save_rooms

from global_reconstruction.visualization.visualize_room_segmentation import generate_top_view_visualization

from global_reconstruction.core.data_adapter import DatasetAdapter

from global_reconstruction.incremental.object_memory import annotate_scene_graph_with_object_updates
from global_reconstruction.incremental.visibility_visualizer import (
    visualize_visibility,
    load_visibility_viz_config,
)
from global_reconstruction.incremental.object_merger import merge_similar_objects
from global_reconstruction.incremental.lifecycle_tracker import LifecycleTracker
from global_reconstruction.incremental.object_state_detector import detect_object_states
from global_reconstruction.reconstruction.voxel_fusion import SparseVoxelFusion
from global_reconstruction.reconstruction.build_pointcloud import load_poses_from_odom_camera

# ================= 配置 =================
import os
from global_reconstruction.core.config_loader import (
    find_images_dir,
    find_poses_file,
    get_config,
    model_path,
    project_root,
    service_url,
)

BASE_DIR = project_root()

cfg = get_config()

_TRAJECTORY_ALIGNMENT_CFG = cfg.get('trajectory_alignment', {}) or {}
TRAJECTORY_ALIGNMENT_ENABLED = bool(_TRAJECTORY_ALIGNMENT_CFG.get('enabled', True))

if TRAJECTORY_ALIGNMENT_ENABLED:
    VERTICAL_AXIS = 1    # Y-up (trajectory-aligned frame)
    HORIZONTAL_AXES = [0, 2]  # X, Z
else:
    VERTICAL_AXIS = 2    # Z-up (original odom frame)
    HORIZONTAL_AXES = [0, 1]  # X, Y

DATA_DIR = Path(os.environ.get("GLOBAL_RECON_DATA_DIR", cfg.data.default_dir))

# 初始化数据适配器
adapter = DatasetAdapter(DATA_DIR)

IMAGES_DIR = adapter.images_dir
DEPTH_DIR = adapter.depth_dir
POSES_FILE = adapter.poses_file

# 服务地址
VLM_API_URL = service_url('vlm_api_url')
SAM3_URL = service_url('sam3_url')
SAM3_BATCH_URL = SAM3_URL.rsplit('/', 1)[0] + '/predict_batch'
VLM_MODEL_NAME = model_path('vlm_model_name')
VLM_MODEL_PATH = model_path('vlm_model_path')

# 输出目录
OUTPUT_DIR = BASE_DIR / cfg.output.base_dir
SCENE_GRAPH_FILE = OUTPUT_DIR / cfg.output.scene_graph_file
CLEANING_INSPECTION_FILE = OUTPUT_DIR / "cleaning_inspection.json"
BEHAVIORAL_ANALYSIS_FILE = OUTPUT_DIR / "behavioral_analysis.json"


def _resolve_runtime_path(value, default_path, base_dir=BASE_DIR):
    if value is None or str(value).strip() == "":
        return Path(default_path)
    path = Path(str(value))
    if path.is_absolute():
        return path
    return Path(base_dir) / path

# 点云重建参数
VOXEL_SIZE = cfg.reconstruction.voxel_size
SKIP_FRAMES = cfg.reconstruction.skip_frames
DEPTH_MIN = cfg.reconstruction.depth_min
DEPTH_MAX = cfg.reconstruction.depth_max
DEPTH_SCALE = cfg.reconstruction.depth_scale
MAX_FRAMES = cfg.reconstruction.max_frames
CONFIDENCE_THRESHOLD = getattr(cfg.reconstruction, 'confidence_threshold', 0.0)
FUSION_CONFIG = cfg.reconstruction.get('fusion', {}) or {}
FUSION_ENABLED = bool(FUSION_CONFIG.get('enabled', True))

# 物体分割参数
OBJECT_CATEGORIES = cfg.object_segmentation.categories
OBJECT_MIN_POINTS = cfg.object_segmentation.min_points
OBJECT_MERGE_DISTANCE_THRESHOLD = cfg.object_segmentation.merge_distance
OBJECT_MERGE_SIMILARITY_THRESHOLD = cfg.object_segmentation.merge_similarity_threshold
OBJECT_MERGE_CONTAINMENT_THRESHOLD = cfg.object_segmentation.get('merge_containment_threshold', 0.50)
OBJECT_DETECTION_INTERVAL = cfg.object_segmentation.detection_interval
MERGE_CATEGORIES = cfg.object_segmentation.merge_categories
SAM3_MAX_DETECTIONS = cfg.object_segmentation.get('sam3_max_detections_per_category', 3)
SAM3_MIN_CONFIDENCE = cfg.object_segmentation.get('sam3_min_confidence', 0.35)

# 类别同义词映射
CATEGORY_SYNONYMS = dict(cfg.object_segmentation.category_synonyms) if hasattr(cfg.object_segmentation, 'category_synonyms') else {}

# 楼层分割参数
FLOOR_HEIGHT_THRESHOLD = cfg.floor_segmentation.height_threshold
FLOOR_HIST_BIN_SIZE = cfg.floor_segmentation.hist_bin_size
FLOOR_GAUSSIAN_SIGMA = cfg.floor_segmentation.gaussian_sigma
FLOOR_PEAK_DISTANCE = cfg.floor_segmentation.peak_distance
FLOOR_PEAK_HEIGHT_PERCENTILE = cfg.floor_segmentation.peak_height_percentile
FLOOR_DBSCAN_EPS = cfg.floor_segmentation.dbscan_eps

# 房间分割参数
GRID_RESOLUTION = cfg.room_segmentation.grid_resolution
ROOM_HEIGHT_MIN_OFFSET = 1.0
ROOM_HEIGHT_MAX_OFFSET = cfg.room_segmentation.height_max_offset
HIST_THRESHOLD_RATIO = 0.20
GAUSSIAN_BLUR_KERNEL = 7
GAUSSIAN_BLUR_SIGMA = 1

# 去噪参数
DBSCAN_EPS = cfg.reconstruction.dbscan_eps
DBSCAN_MIN_POINTS = cfg.reconstruction.dbscan_min_points

# 坐标轴变换矩阵
USE_AXIS_TRANSFORM = cfg.coordinate.use_axis_transform and adapter.dataset_type != "da3_ezviz"
T_SWITCH_AXIS = np.array(cfg.coordinate.switch_axis, dtype=np.float64)
if cfg.coordinate.use_axis_transform and adapter.dataset_type == "da3_ezviz":
    print(f"  ℹ️  da3_ezviz 格式：跳过坐标轴变换 (由轨迹平面旋转对齐)")
if not TRAJECTORY_ALIGNMENT_ENABLED:
    print(f"  ℹ️  轨迹平面对齐：已禁用 (保持原始里程计坐标系, VERTICAL_AXIS={VERTICAL_AXIS})")

# Object environment
OBJECT_ENVIRONMENT_DESCRIPTION_ENABLED = cfg.object_segmentation.environment_description_enabled
OBJECT_ENVIRONMENT_MAX_IMAGES = cfg.object_segmentation.environment_description_max_images
OBJECT_ENVIRONMENT_CACHE_FILE = OUTPUT_DIR / "object_environment_descriptions.json"
OBJECT_VIEW_OUTPUT_DIR = OUTPUT_DIR / cfg.output.object_views_dir
OBJECT_SOURCE_VIEW_LIMIT = cfg.object_segmentation.source_view_limit
OBJECT_ENVIRONMENT_CONTEXT_SCALE = cfg.object_segmentation.environment_context_scale
OBJECT_REPROJECTION_MAX_FRAMES = cfg.object_segmentation.reprojection_max_frames
OBJECT_REPROJECTION_MAX_POINTS = cfg.object_segmentation.reprojection_max_points
OBJECT_REPROJECTION_MIN_VISIBLE_POINTS = cfg.object_segmentation.reprojection_min_visible_points

# Visibility visualization (config loaded from incremental module)
_VIS_VIZ_CFG = load_visibility_viz_config(cfg)
VIS_VIZ_ENABLED = _VIS_VIZ_CFG['enabled']

# Object lifecycle updates
OBJECT_LIFECYCLE_CONFIG = dict(cfg.get('object_lifecycle', {}))
OBJECT_LIFECYCLE_ENABLED = bool(OBJECT_LIFECYCLE_CONFIG.get('enabled', True))
OBJECT_LIFECYCLE_PREVIOUS_SCENE_GRAPH = _resolve_runtime_path(
    OBJECT_LIFECYCLE_CONFIG.get('previous_scene_graph', ''),
    SCENE_GRAPH_FILE,
)
OBJECT_UPDATE_REPORT_FILE = _resolve_runtime_path(
    OBJECT_LIFECYCLE_CONFIG.get('report_file', 'object_update_report.json'),
    OUTPUT_DIR / 'object_update_report.json',
    base_dir=OUTPUT_DIR,
)

NAVIGATION_ENABLED = bool(cfg.get('navigation', {}).get('enabled', False))
# ===========================================

# 预加载 SentenceTransformer 语义嵌入模型 (用于类别相似度计算)
_SEMANTIC_EMBEDDING_MODEL = None

def _get_embedding_model():
    """Lazy load 语义嵌入模型"""
    global _SEMANTIC_EMBEDDING_MODEL
    if _SEMANTIC_EMBEDDING_MODEL is None:
        try:
            from sentence_transformers import SentenceTransformer
            _SEMANTIC_EMBEDDING_MODEL = SentenceTransformer('all-MiniLM-L6-v2', device='cpu')
        except Exception as e:
            print(f"  ⚠ 语义嵌入模型加载失败: {e}，将仅使用同义词映射")
            return None
    return _SEMANTIC_EMBEDDING_MODEL


def _categories_semantically_similar(cat_a, cat_b):
    """判断两个类别名是否语义相似 — 同义词映射 + SentenceTransformer 余弦相似度"""
    if cat_a == cat_b:
        return True

    # 优先检查同义词映射
    for canonical, synonyms in CATEGORY_SYNONYMS.items():
        all_names = [canonical] + synonyms
        if cat_a in all_names and cat_b in all_names:
            return True

    # SentenceTransformer 语义嵌入
    model = _get_embedding_model()
    if model is not None:
        import numpy as np
        emb_a = model.encode([cat_a], show_progress_bar=False)[0]
        emb_b = model.encode([cat_b], show_progress_bar=False)[0]
        cosine_sim = float(np.dot(emb_a, emb_b) / (np.linalg.norm(emb_a) * np.linalg.norm(emb_b)))
        return cosine_sim >= OBJECT_MERGE_SIMILARITY_THRESHOLD

    return False


def load_intrinsics(yaml_file):
    return adapter.K


def load_poses(pose_file):
    """
    加载位姿,支持两种格式:
    - TUM 格式 (8 values): timestamp tx ty tz qx qy qz qw
    - 4x4 矩阵格式 (16 values): row-major camera-to-world 矩阵
    """
    poses = {}
    seq_idx = 0
    with open(pose_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()

            if len(parts) == 16:
                # 4x4 矩阵格式 (camera_poses.txt)
                T_c2w = np.array([float(x) for x in parts], dtype=np.float64).reshape(4, 4)

                timestamp = f"{seq_idx:05d}"
                seq_idx += 1

                if USE_AXIS_TRANSFORM:
                    T_c2w = T_SWITCH_AXIS @ T_c2w

                poses[timestamp] = T_c2w

            elif len(parts) >= 8:
                # TUM 格式
                timestamp = parts[0]
                tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
                qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

                q = np.array([qx, qy, qz, qw])
                q = q / np.linalg.norm(q)
                x, y, z, w = q

                R = np.array([
                    [1 - 2*y*y - 2*z*z, 2*x*y - 2*z*w, 2*x*z + 2*y*w],
                    [2*x*y + 2*z*w, 1 - 2*x*x - 2*z*z, 2*y*z - 2*x*w],
                    [2*x*z - 2*y*w, 2*y*z + 2*x*w, 1 - 2*x*x - 2*y*y]
                ])

                T_w2c = np.eye(4)
                T_w2c[:3, :3] = R
                T_w2c[:3, 3] = [tx, ty, tz]

                T_c2w = np.linalg.inv(T_w2c)

                # 坐标轴变换
                if USE_AXIS_TRANSFORM:
                    T_c2w = T_SWITCH_AXIS @ T_c2w

                poses[timestamp] = T_c2w

    return poses


def fit_trajectory_plane_from_poses(poses):
    """
    从相机位姿拟合机器人行走轨迹平面
    
    使用 RANSAC 鲁棒拟合，得到行走平面方程。
    用于：
    1. 导航路径点的 Y 高度计算
    2. 轨迹点云的 3D→2D 投影
    
    参数:
        poses: dict of {timestamp: T_c2w (4x4)} 相机位姿
    
    返回:
        result: dict 包含以下字段:
            - normal: 平面法向量 (3,)
            - d: 平面方程常数项 (ax + by + cz + d = 0)
            - centroid: 轨迹质心 (3,)
            - inlier_ratio: 内点比例
            - mean_distance: 平均距离偏差 (m)
    """
    # 提取所有相机位置
    positions = np.array([T[:3, 3] for T in poses.values()])
    n = len(positions)
    
    if n < 3:
        print("  警告: 位姿数量不足，使用默认水平面")
        return {
            'normal': np.array([0.0, 1.0, 0.0]),
            'd': 0.0,
            'centroid': positions.mean(axis=0) if n > 0 else np.zeros(3),
            'inlier_ratio': 0.0,
            'mean_distance': 0.0,
        }
    
    # RANSAC 平面拟合
    np.random.seed(42)
    threshold = 0.05  # 5cm 内点阈值
    max_iterations = 1000
    
    best_normal = None
    best_d = None
    best_count = 0
    best_inliers = []
    
    for _ in range(max_iterations):
        # 随机选择3个点
        idx = np.random.choice(n, 3, replace=False)
        p1, p2, p3 = positions[idx]
        
        # 计算法向量
        v1 = p2 - p1
        v2 = p3 - p1
        normal = np.cross(v1, v2)
        norm = np.linalg.norm(normal)
        
        if norm < 1e-6:
            continue
        
        normal = normal / norm
        d = -np.dot(normal, p1)
        
        # 统计内点
        distances = np.abs(np.dot(positions, normal) + d)
        inliers = np.where(distances < threshold)[0]
        
        if len(inliers) > best_count:
            best_count = len(inliers)
            best_normal = normal
            best_d = d
            best_inliers = inliers
        
        # 提前终止
        if best_count > n * 0.95:
            break
    
    if len(best_inliers) > 2:
        inlier_points = positions[best_inliers]
        centroid = inlier_points.mean(axis=0)
        centered = inlier_points - centroid
        _, _, vh = np.linalg.svd(centered)
        best_normal = vh[-1]
        
        # 确保法向量朝上 (Y 轴正方向)
        if best_normal[1] < 0:
            best_normal = -best_normal
        
        best_d = -np.dot(best_normal, centroid)
    
    centroid = positions.mean(axis=0)
    distances = np.abs(np.dot(positions, best_normal) + best_d)
    inlier_ratio = best_count / n * 100
    mean_dist = distances.mean()
    
    print(f"  轨迹点云: {n} 帧")
    print(f"  法向量: [{best_normal[0]:.6f}, {best_normal[1]:.6f}, {best_normal[2]:.6f}]")
    print(f"  平面方程: {best_normal[0]:.4f}x + {best_normal[1]:.4f}y + {best_normal[2]:.4f}z + {best_d:.4f} = 0")
    print(f"  内点: {best_count}/{n} ({inlier_ratio:.1f}%)")
    print(f"  平均偏差: {mean_dist*1000:.1f} mm")
    
    plane_info_file = OUTPUT_DIR / "trajectory_plane.json"
    plane_info = {
        'normal': best_normal.tolist(),
        'd': float(best_d),
        'centroid': centroid.tolist(),
        'inlier_count': int(best_count),
        'total_points': int(n),
        'inlier_ratio': float(inlier_ratio),
        'mean_distance': float(mean_dist),
    }
    with open(plane_info_file, 'w') as f:
        json.dump(plane_info, f, indent=2)
    print(f"  ✓ 已保存: {plane_info_file}")
    
    return {
        'normal': best_normal,
        'd': best_d,
        'centroid': centroid,
        'inlier_ratio': inlier_ratio,
        'mean_distance': mean_dist,
    }


def build_trajectory_rotation_matrix(normal):
    """
    构建旋转矩阵，将轨迹平面法向量对齐到 Y 轴正方向 [0, 1, 0]

        相机轨迹平行于地面，拟合出的平面法向量即为真实"上"方向。
        旋转后 Y 轴 = 真实高度方向，XZ 平面 = 地面平面。

    参数:
        normal: 轨迹平面法向量 (3,)

    返回:
        R: 3x3 旋转矩阵 (将原始坐标变换到对齐坐标系)
        R_inv: 3x3 逆旋转矩阵 (将对齐坐标变换回原始坐标系)
    """
    normal = np.asarray(normal, dtype=np.float64)
    normal = normal / np.linalg.norm(normal)
    target = np.array([0.0, 1.0, 0.0])

    cos_angle = np.clip(np.dot(normal, target), -1.0, 1.0)
    if abs(cos_angle - 1.0) < 1e-6:
        return np.eye(3), np.eye(3)

    if abs(cos_angle + 1.0) < 1e-6:
        R = np.diag([1.0, -1.0, -1.0])
        return R, R.T

    # Rodrigues 旋转公式: 将 normal 旋转到 target
    v = np.cross(normal, target)
    s = np.linalg.norm(v)
    c = cos_angle

    vx = np.array([
        [0, -v[2], v[1]],
        [v[2], 0, -v[0]],
        [-v[1], v[0], 0]
    ])

    R = np.eye(3) + vx + vx @ vx * ((1 - c) / (s * s))

    # 验证: R @ normal 应该接近 [0, 1, 0]
    rotated = R @ normal
    if abs(rotated[1] - 1.0) > 0.01:
        R = R.T

    R_inv = R.T
    return R, R_inv


def depth_to_pointcloud(depth, color, K, T_c2w, confidence=None, conf_threshold=0.0):
    """深度图 + 彩色图 → 3D 点云"""
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    valid_mask = (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
    if confidence is not None and conf_threshold > 0:
        valid_mask &= (confidence >= conf_threshold)
    v, u = np.where(valid_mask)
    
    if len(u) == 0:
        return np.empty((0, 3)), np.empty((0, 3))
    
    depths = depth[v, u].flatten()
    
    X_cam = (u - cx) * depths / fx
    Y_cam = (v - cy) * depths / fy
    Z_cam = depths
    
    points_cam = np.stack([X_cam, Y_cam, Z_cam, np.ones_like(X_cam)], axis=1)
    points_world = (T_c2w @ points_cam.T).T[:, :3]
    
    colors = color[v, u]
    return points_world, colors


def voxel_downsample(points, colors, voxel_size):
    """体素下采样"""
    if len(points) == 0:
        return points, colors
    
    indices = np.floor(points / voxel_size).astype(np.int64)
    _, unique_idx = np.unique(indices, axis=0, return_index=True)
    
    return points[unique_idx], colors[unique_idx]


# ================= VLM 物体检测 =================

def vlm_detect_objects(image_path, discovered_categories=None, history_images=None):
    """
    使用 VLM 检测图像中的物体类别

    返回:
    [
        {"category": "chair"},
        {"category": "desk", "sam3_prompt": "office desk"},
        ...
    ]

    discovered_categories: 已发现的类别集合（跨帧上下文），
                          让 VLM 优先使用一致的类别名
    history_images: 历史检测帧的缩略图列表 [(file_path, base64), ...]
                   VLM 同时看到历史帧和当前帧，提高检测可靠性
    """
    # 跨帧上下文：告诉 VLM 场景中已知有哪些物体
    context_line = ""
    if discovered_categories:
        cat_list = ", ".join(sorted(discovered_categories.keys()))
        context_line = (
            f"\nPreviously detected objects in this scene: {cat_list}.\n"
            f"Use these exact category names if those objects are still visible.\n"
        )

    # 历史帧上下文
    history_line = ""
    if history_images:
        n = len(history_images)
        history_line = (
            f"\nThe following {n} earlier frame(s) are provided for context. "
            f"The LAST image is the current frame you should detect objects in.\n"
        )

    prompt = f"""You are an indoor object detection assistant. Detect indoor objects and output STRICT JSON.

## Output Format (MANDATORY)
{{"objects":[{{"category":"name"}},...]}}
You MUST wrap the result in an object with an "objects" key. Each item has ONLY a "category" field.

### Correct examples:
{{"objects":[{{"category":"chair"}},{{"category":"desk"}},{{"category":"wall"}}]}}
{{"objects":[{{"category":"sofa"}},{{"category":"tv"}},{{"category":"floor"}},{{"category":"window"}}]}}
{{"objects":[]}}

### WRONG (never do this):
[{{"category":"chair"}},{{"category":"desk"}}]          ← bare array, missing "objects" key
{{"objects":[{{"category":"chair","confidence":0.9}}]}}   ← no "confidence" field
{{"objects":[{{"category":"Office Chair"}}]}}             ← not lowercase, not short name

## Detection Rules
1. Categories: lowercase, short common names (e.g., "chair" NOT "office_chair").
2. Visibility: ONLY include objects ≥50% visible in the **current frame** (the last image).
3. Limit: Max 12 objects. Prioritize larger/prominent ones.
4. Skip: ceiling, sky, outdoor objects, pets.
5. DO NOT detect parts or components of an object as separate items (e.g., wheels, casters, handles, legs, armrests, drawer fronts, shelves, screens, buttons). Only detect the whole object they belong to (e.g., "chair" includes its wheels and armrests; "cart" includes its wheels and handle).
6. If it has product display and payment interface (coin slot, card reader, QR code), call it "vending_machine" NOT "refrigerator".{context_line}{history_line}
Analyze the **current frame** (the last image) and use earlier frames for context if helpful.
Output ONLY the JSON object NOW:"""

    try:
        # 构建 content 数组：历史帧 + 当前帧 + prompt
        image_base64 = image_to_base64(image_path)
        content_items = []

        # 添加历史帧
        if history_images:
            for _, hist_b64 in history_images:
                content_items.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{hist_b64}"},
                })

        # 添加当前帧
        content_items.append({
            "type": "image_url",
            "image_url": {"url": f"data:image/png;base64,{image_base64}"},
        })

        # 添加文本 prompt
        content_items.append({"type": "text", "text": prompt})

        payload = {
            "model": VLM_MODEL_NAME,
            "messages": [{
                "role": "user",
                "content": content_items,
            }],
            "max_tokens": 1500,
            "temperature": 0.01,
            "stream": False,
            "reasoning": False,
        }

        response = requests.post(VLM_API_URL, json=payload, timeout=60)
        response.raise_for_status()

        result = response.json()
        msg = result['choices'][0]['message']
        content = msg.get('content', '').strip()
        if not content:
            content = msg.get('reasoning_content', '').strip()

        content = clean_json_output(content)

        try:
            detection_result = json.loads(content)
        except json.JSONDecodeError:
            # 包裹成数组: {"category":"a"}, {"category":"b"} → [{...}, {...}]
            fixed = content.strip().strip(',').strip()
            if not fixed.startswith('['):
                fixed = f'[{fixed}]'
            if not fixed.endswith(']'):
                fixed = fixed + ']'
            detection_result = json.loads(fixed)

        # 提取 objects 列表
        if isinstance(detection_result, dict):
            objects = detection_result.get('objects', [])
            if not isinstance(objects, list):
                objects = [detection_result]
        elif isinstance(detection_result, list):
            objects = detection_result
        else:
            print(f"  VLM 返回格式错误：无法解析为列表")
            return []

        # 规范类别名称
        seen = set()
        valid_objects = []
        for obj in objects:
            if isinstance(obj, dict) and 'category' in obj:
                category = _canonicalize_category(obj['category'])
                if category in seen or category == 'ceiling':
                    continue
                seen.add(category)
                obj_info = {'category': category}
                if category == 'water_dispenser':
                    obj_info['sam3_prompt'] = 'a water cooler'
                valid_objects.append(obj_info)

        if valid_objects:
            print(f"    VLM 检测到 {len(valid_objects)} 个物体：{', '.join([o['category'] for o in valid_objects[:5]])}{'...' if len(valid_objects) > 5 else ''}")

        return valid_objects

    except json.JSONDecodeError as e:
        print(f"  VLM JSON 解析失败：{e}")
        print(f"  原始输出：{content[:200] if 'content' in dir() else 'N/A'}...")
        return []
    except Exception as e:
        print(f"  VLM 物体检测失败：{e}")
        return []


def _canonicalize_category(cat):
    """将同义词/变体映射到标准类别名"""
    cat = cat.lower().strip().replace(' ', '_').replace('-', '_')
    for canonical, synonyms in CATEGORY_SYNONYMS.items():
        if cat == canonical or cat in synonyms:
            return canonical
    return cat


def clean_json_output(content):
    """清理 VLM 输出，提取有效 JSON"""
    if content.startswith('```json'):
        content = content[7:]
    if content.startswith('```'):
        content = content[3:]
    if content.endswith('```'):
        content = content[:-3]
    
    content = content.strip()
    
    start = content.find('{')
    end = content.rfind('}') + 1
    
    if start >= 0 and end > start:
        return content[start:end]
    
    return content


def image_to_base64(image_path):
    with open(image_path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')


def _restart_vllm_if_needed(wait_seconds=30):
    import subprocess

    # Quick health check
    try:
        r = requests.get("http://localhost:8008/v1/models", timeout=5)
        if r.status_code == 200:
            return True
    except Exception:
        pass

    print("  ⚠ vLLM 无响应，正在检查进程...")
    result = subprocess.run(["pgrep", "-f", "vllm.entrypoints"], capture_output=True, text=True)
    if result.stdout.strip():
        print("  vLLM 进程仍存在但无响应，正在终止...")
        subprocess.run(["pkill", "-f", "vllm.entrypoints"], timeout=5)
        time.sleep(2)

    print("  正在重启 vLLM...")
    cmd = [
        "python", "-m", "vllm.entrypoints.openai.api_server",
        "--model", VLM_MODEL_PATH,
        "--served-model-name", VLM_MODEL_NAME,
        "--host", "0.0.0.0", "--port", "8008",
        "--max_model_len", "32768",
        "--tensor-parallel-size", "2",
    ]
    subprocess.Popen(
        cmd,
        stdout=open("/tmp/vllm_restart.log", "w"),
        stderr=subprocess.STDOUT,
    )

    print(f"  等待 vLLM 启动 ({wait_seconds}s)...")
    for i in range(wait_seconds):
        time.sleep(1)
        try:
            r = requests.get("http://localhost:8008/v1/models", timeout=3)
            if r.status_code == 200:
                print("  ✓ vLLM 已恢复")
                return True
        except Exception:
            pass
    print("  ✗ vLLM 重启超时")
    return False


def vlm_generate_json_from_images(image_paths, prompt, max_tokens=1500, temperature=0.05, timeout=180):
    valid_image_paths = []
    seen = set()
    for image_path in image_paths or []:
        if not image_path:
            continue
        normalized_path = str(Path(image_path))
        if normalized_path in seen or not Path(normalized_path).exists():
            continue
        seen.add(normalized_path)
        valid_image_paths.append(normalized_path)

    if not valid_image_paths:
        return None

    max_retries = 2
    for attempt in range(max_retries + 1):
        try:
            content = []
            for image_path in valid_image_paths:
                image_base64 = image_to_base64(image_path)
                image_suffix = Path(image_path).suffix.lower()
                image_mime = "jpeg" if image_suffix in {".jpg", ".jpeg"} else "png"
                content.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:image/{image_mime};base64,{image_base64}"},
                })
            content.append({"type": "text", "text": prompt})

            payload = {
                "model": VLM_MODEL_NAME,
                "messages": [{
                    "role": "user",
                    "content": content,
                }],
                "max_tokens": max_tokens,
                "temperature": temperature,
                "stream": False,
                "reasoning": False,
            }

            response = requests.post(VLM_API_URL, json=payload, timeout=timeout)
            response.raise_for_status()

            result = response.json()

            # Handle vLLM/llama-server error responses
            if "error" in result:
                raise RuntimeError(f"VLM error: {result['error']}")
            if "choices" not in result or not result["choices"]:
                raise RuntimeError(f"Unexpected VLM response format: {json.dumps(result)[:300]}")

            msg = result['choices'][0]['message']
            response_text = msg.get('content', '').strip()
            if not response_text:
                response_text = msg.get('reasoning_content', '').strip()
            response_text = clean_json_output(response_text)
            return json.loads(response_text)
        except Exception as e:
            if attempt < max_retries:
                delay = 2 ** attempt

                if "Connection refused" in str(e) or "Max retries exceeded" in str(e):
                    if attempt == 0:
                        _restart_vllm_if_needed(wait_seconds=30)
                        delay = 5  # Extra wait after restart
                    else:
                        delay = max(delay, 5)

                print(f"  VLM 调用失败 ({attempt + 1}/{max_retries + 1})：{e}，{delay}s 后重试...")
                time.sleep(delay)
            else:
                print(f"  VLM 多图 JSON 调用失败（已重试 {max_retries} 次）：{e}")
                return None


def _slugify_token(value):
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "")).strip("._")
    return text or "object"


def _dedupe_ordered_strings(values, limit=None):
    ordered = []
    seen = set()
    for value in values or []:
        normalized = str(value or "").strip()
        if not normalized or normalized in seen:
            continue
        ordered.append(normalized)
        seen.add(normalized)
        if limit is not None and len(ordered) >= limit:
            break
    return ordered


def _normalize_bbox_xyxy(box, width, height):
    if box is None or len(box) != 4 or width <= 0 or height <= 0:
        return None

    try:
        x1, y1, x2, y2 = [float(v) for v in box]
    except (TypeError, ValueError):
        return None

    if x2 < x1:
        x1, x2 = x2, x1
    if y2 < y1:
        y1, y2 = y2, y1

    x1 = max(0, min(width - 1, int(np.floor(x1))))
    y1 = max(0, min(height - 1, int(np.floor(y1))))
    x2 = max(x1 + 1, min(width, int(np.ceil(x2))))
    y2 = max(y1 + 1, min(height, int(np.ceil(y2))))
    return [x1, y1, x2, y2]


def _mask_to_bbox_xyxy(mask_2d):
    if mask_2d is None:
        return None

    ys, xs = np.where(mask_2d > 0)
    if len(xs) == 0 or len(ys) == 0:
        return None

    return [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]


def _expand_bbox_xyxy(box, width, height, scale=1.8):
    normalized = _normalize_bbox_xyxy(box, width, height)
    if normalized is None:
        return None

    x1, y1, x2, y2 = normalized
    box_w = max(1, x2 - x1)
    box_h = max(1, y2 - y1)
    center_x = (x1 + x2) / 2.0
    center_y = (y1 + y2) / 2.0
    expanded_w = max(box_w, int(np.ceil(box_w * scale)))
    expanded_h = max(box_h, int(np.ceil(box_h * scale)))

    new_x1 = max(0, int(np.floor(center_x - expanded_w / 2.0)))
    new_y1 = max(0, int(np.floor(center_y - expanded_h / 2.0)))
    new_x2 = min(width, max(new_x1 + 1, int(np.ceil(center_x + expanded_w / 2.0))))
    new_y2 = min(height, max(new_y1 + 1, int(np.ceil(center_y + expanded_h / 2.0))))
    return [new_x1, new_y1, new_x2, new_y2]


def _save_rgb_image(path, image_rgb):
    path.parent.mkdir(parents=True, exist_ok=True)
    image_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    cv2.imwrite(str(path), image_bgr)


def _normalize_source_view_record(source_view):
    if not isinstance(source_view, dict):
        return None

    normalized = {}
    for key in (
        'frame',
        'image_path',
        'annotated_image',
        'context_crop',
        'object_crop',
        'mask_crop',
        'projection_method',
    ):
        value = source_view.get(key)
        if value:
            normalized[key] = str(value)

    for key in ('bbox_xyxy', 'context_bbox_xyxy', 'image_size'):
        value = source_view.get(key)
        if isinstance(value, (list, tuple)) and len(value) in {2, 4}:
            try:
                normalized[key] = [int(round(float(v))) for v in value]
            except (TypeError, ValueError):
                pass

    for key in ('score', 'mask_area_pixels', 'projection_visible_points', 'projection_ratio'):
        value = source_view.get(key)
        if value is None:
            continue
        try:
            normalized[key] = float(value)
        except (TypeError, ValueError):
            continue

    return normalized if normalized else None


def _categories_semantically_similar(cat_a, cat_b):
    """判断两个类别名是否语义相似"""
    if cat_a == cat_b:
        return True
    for canonical, synonyms in CATEGORY_SYNONYMS.items():
        all_names = [canonical] + synonyms
        if cat_a in all_names and cat_b in all_names:
            return True
    return False


def _unified_category_name(cat_a, cat_b):
    """两个相似类别合并时，选择统一的名称 — 优先用同义词映射的 canonical 名"""
    if cat_a == cat_b:
        return cat_a
    for canonical, synonyms in CATEGORY_SYNONYMS.items():
        all_names = [canonical] + synonyms
        if cat_a in all_names and cat_b in all_names:
            return canonical
    # SentenceTransformer 匹配时，取较短的名称
    return cat_a if len(cat_a) <= len(cat_b) else cat_b


def _source_view_area(source_view):
    bbox = (source_view or {}).get('bbox_xyxy') or []
    if len(bbox) != 4:
        return 0.0
    return float(max(0, bbox[2] - bbox[0]) * max(0, bbox[3] - bbox[1]))


def merge_source_views(items, limit=OBJECT_SOURCE_VIEW_LIMIT):
    merged = []
    seen = set()
    for item in items or []:
        for source_view in item.get('source_views', []):
            normalized = _normalize_source_view_record(source_view)
            if not normalized:
                continue
            key = (
                normalized.get('frame'),
                tuple(normalized.get('bbox_xyxy', [])),
                normalized.get('annotated_image'),
                normalized.get('object_crop'),
            )
            if key in seen:
                continue
            merged.append(normalized)
            seen.add(key)

    merged.sort(
        key=lambda view: (
            float(view.get('score', 0.0)),
            float(view.get('mask_area_pixels', 0.0)),
            _source_view_area(view),
        ),
        reverse=True,
    )
    return merged[:limit]


def create_object_grounded_views(
    image_path,
    image_rgb,
    frame,
    category,
    object_index,
    box,
    mask,
    score=None,
):
    """Save grounded view artifacts so later VLM calls know which instance is the target."""
    if image_rgb is None or len(image_rgb.shape) != 3:
        return None

    height, width = image_rgb.shape[:2]
    mask_bbox = _mask_to_bbox_xyxy(mask)
    bbox_xyxy = _normalize_bbox_xyxy(mask_bbox or box, width, height)
    if bbox_xyxy is None:
        return None

    context_bbox_xyxy = _expand_bbox_xyxy(
        bbox_xyxy,
        width,
        height,
        scale=OBJECT_ENVIRONMENT_CONTEXT_SCALE,
    )
    if context_bbox_xyxy is None:
        return None

    x1, y1, x2, y2 = bbox_xyxy
    cx1, cy1, cx2, cy2 = context_bbox_xyxy

    annotated = image_rgb.copy()
    mask_binary = None
    if mask is not None and mask.shape[:2] == (height, width):
        mask_binary = mask > 128
        if mask_binary.any():
            highlighted = annotated[mask_binary].astype(np.float32)
            target_tint = np.array([255.0, 48.0, 48.0], dtype=np.float32)
            annotated[mask_binary] = np.clip(0.45 * highlighted + 0.55 * target_tint, 0, 255).astype(np.uint8)

    cv2.rectangle(annotated, (x1, y1), (x2 - 1, y2 - 1), (255, 0, 0), 2)
    label = f"{category} {score:.2f}" if score is not None else str(category)
    cv2.putText(
        annotated,
        label,
        (x1, max(18, y1 - 8)),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 255),
        2,
        cv2.LINE_AA,
    )

    context_crop = image_rgb[cy1:cy2, cx1:cx2].copy()
    object_crop = image_rgb[y1:y2, x1:x2].copy()
    mask_crop = None
    mask_area_pixels = float(_source_view_area({'bbox_xyxy': bbox_xyxy}))
    if mask_binary is not None:
        crop_mask = mask_binary[y1:y2, x1:x2]
        if crop_mask.size > 0:
            mask_area_pixels = float(crop_mask.sum())
            mask_crop = (crop_mask.astype(np.uint8) * 255)
            dimmed_background = (object_crop.astype(np.float32) * 0.2).astype(np.uint8)
            object_crop = np.where(crop_mask[..., None], object_crop, dimmed_background)

    object_dir = OBJECT_VIEW_OUTPUT_DIR / f"{_slugify_token(frame)}_{_slugify_token(category)}_{int(object_index):05d}"
    annotated_path = object_dir / "annotated.png"

    _save_rgb_image(annotated_path, annotated)

    return {
        'frame': str(frame),
        'image_path': str(image_path),
        'bbox_xyxy': bbox_xyxy,
        'context_bbox_xyxy': context_bbox_xyxy,
        'image_size': [int(width), int(height)],
        'score': float(score) if score is not None else 0.0,
        'mask_area_pixels': mask_area_pixels,
        'annotated_image': str(annotated_path),
    }


def _resolve_frame_image_path(frame, fallback_paths=None):
    candidates = []
    frame_token = str(frame) if frame else None
    if frame:
        for ext in (".png", ".jpg", ".jpeg"):
            candidates.append(IMAGES_DIR / f"{frame_token}{ext}")
    for fallback_path in fallback_paths or []:
        if fallback_path:
            fallback_candidate = Path(str(fallback_path))
            if frame_token and fallback_candidate.stem != frame_token:
                continue
            candidates.append(fallback_candidate)

    seen = set()
    for candidate in candidates:
        normalized = str(candidate)
        if normalized in seen:
            continue
        seen.add(normalized)
        if candidate.exists():
            return candidate
    return None


def _project_world_points_to_image(points_world, K, T_c2w, width, height, max_points=OBJECT_REPROJECTION_MAX_POINTS):
    if points_world is None or len(points_world) == 0 or width <= 0 or height <= 0:
        return None

    if len(points_world) > max_points:
        sample_indices = np.linspace(0, len(points_world) - 1, max_points, dtype=np.int32)
        sampled_points = points_world[sample_indices]
    else:
        sampled_points = points_world

    points_h = np.concatenate(
        [sampled_points.astype(np.float64), np.ones((len(sampled_points), 1), dtype=np.float64)],
        axis=1,
    )
    T_w2c = np.linalg.inv(T_c2w)
    points_cam = (T_w2c @ points_h.T).T[:, :3]
    positive_depth_mask = points_cam[:, 2] > 1e-3
    if not np.any(positive_depth_mask):
        return None

    points_cam = points_cam[positive_depth_mask]
    uv = (K @ points_cam.T).T
    u = uv[:, 0] / points_cam[:, 2]
    v = uv[:, 1] / points_cam[:, 2]

    in_bounds_mask = (u >= 0) & (u < width) & (v >= 0) & (v < height)
    if not np.any(in_bounds_mask):
        return None

    projected_uv = np.stack([u[in_bounds_mask], v[in_bounds_mask]], axis=1)
    visible_depths = points_cam[in_bounds_mask, 2]
    return {
        'uv': projected_uv,
        'depths': visible_depths,
        'visible_points': int(len(projected_uv)),
        'sampled_points': int(len(sampled_points)),
    }


def _mask_from_projected_points(projected_uv, width, height):
    if projected_uv is None or len(projected_uv) < OBJECT_REPROJECTION_MIN_VISIBLE_POINTS:
        return None

    pixel_coords = np.round(projected_uv).astype(np.int32)
    pixel_coords[:, 0] = np.clip(pixel_coords[:, 0], 0, width - 1)
    pixel_coords[:, 1] = np.clip(pixel_coords[:, 1], 0, height - 1)

    mask = np.zeros((height, width), dtype=np.uint8)
    mask[pixel_coords[:, 1], pixel_coords[:, 0]] = 255

    raw_bbox = _mask_to_bbox_xyxy(mask)
    if raw_bbox is None:
        return None

    bbox_area = max(1, (raw_bbox[2] - raw_bbox[0]) * (raw_bbox[3] - raw_bbox[1]))
    kernel_size = int(np.clip(np.sqrt(bbox_area) / 18.0, 2, 8))
    kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
    mask = cv2.dilate(mask, kernel, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return mask


def create_reprojected_object_grounded_view(
    obj,
    object_index,
    frame,
    image_path,
    image_rgb,
    K,
    T_c2w,
):
    projection = _project_world_points_to_image(
        points_world=obj.get('points'),
        K=K,
        T_c2w=T_c2w,
        width=image_rgb.shape[1],
        height=image_rgb.shape[0],
    )
    if not projection:
        return None

    projected_mask = _mask_from_projected_points(
        projected_uv=projection['uv'],
        width=image_rgb.shape[1],
        height=image_rgb.shape[0],
    )
    if projected_mask is None:
        return None

    bbox_xyxy = _mask_to_bbox_xyxy(projected_mask)
    if bbox_xyxy is None:
        return None

    grounded_view = create_object_grounded_views(
        image_path=image_path,
        image_rgb=image_rgb,
        frame=frame,
        category=obj.get('category'),
        object_index=100000 + int(object_index),
        box=bbox_xyxy,
        mask=projected_mask,
        score=10.0 + projection['visible_points'] / max(1, projection['sampled_points']),
    )
    if not grounded_view:
        return None

    grounded_view['projection_method'] = 'final_object_reprojection'
    grounded_view['projection_visible_points'] = int(projection['visible_points'])
    grounded_view['projection_ratio'] = round(
        float(projection['visible_points']) / max(1, projection['sampled_points']),
        4,
    )
    grounded_view['mask_area_pixels'] = float(np.count_nonzero(projected_mask))
    return grounded_view


def rebuild_final_object_grounded_views(objects, poses, K, max_frames=OBJECT_REPROJECTION_MAX_FRAMES):
    for object_index, obj in enumerate(objects):
        candidate_frames = _dedupe_ordered_strings(
            [obj.get('representative_frame')] + list(obj.get('source_frames', [])),
            limit=OBJECT_SOURCE_VIEW_LIMIT,
        )
        if not candidate_frames:
            continue

        fallback_paths = [obj.get('representative_image')] + list(obj.get('source_images', []))
        projected_views = []
        for frame in candidate_frames:
            T_c2w = poses.get(str(frame))
            if T_c2w is None:
                continue

            image_path = _resolve_frame_image_path(frame, fallback_paths=fallback_paths)
            if image_path is None:
                continue

            image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
            if image_bgr is None:
                continue
            image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

            grounded_view = create_reprojected_object_grounded_view(
                obj=obj,
                object_index=object_index,
                frame=str(frame),
                image_path=str(image_path),
                image_rgb=image_rgb,
                K=K,
                T_c2w=T_c2w,
            )
            if grounded_view:
                projected_views.append(grounded_view)

        if not projected_views:
            continue

        projected_views = merge_source_views([{'source_views': projected_views}], limit=max_frames)

        merged_views = merge_source_views(
            [{'source_views': projected_views}, {'source_views': obj.get('source_views', [])}],
            limit=OBJECT_SOURCE_VIEW_LIMIT,
        )
        obj['source_views'] = merged_views
        obj['representative_source_view'] = merged_views[0] if merged_views else obj.get('representative_source_view')
        obj['source_frames'] = _dedupe_ordered_strings(
            [view.get('frame') for view in projected_views] + list(obj.get('source_frames', [])),
            limit=OBJECT_SOURCE_VIEW_LIMIT,
        )
        obj['source_images'] = _dedupe_ordered_strings(
            [view.get('image_path') for view in projected_views] + list(obj.get('source_images', [])),
            limit=OBJECT_SOURCE_VIEW_LIMIT,
        )
        if obj.get('representative_source_view'):
            obj['representative_frame'] = obj['representative_source_view'].get('frame') or obj.get('representative_frame')
            obj['representative_image'] = obj['representative_source_view'].get('image_path') or obj.get('representative_image')
        obj['reprojected_view_count'] = len(projected_views)

    return objects


def select_object_context_images(obj, max_images=1):
    """选取 annotated 标注图"""
    ordered_paths = []
    seen = set()

    source_views = obj.get('source_views', []) or []
    representative_view = obj.get('representative_source_view')
    if isinstance(representative_view, dict):
        source_views = [representative_view] + source_views

    for source_view in source_views:
        if not isinstance(source_view, dict):
            continue
        image_path = source_view.get('annotated_image')
        normalized_path = str(image_path) if image_path else ''
        if not normalized_path or normalized_path in seen or not Path(normalized_path).exists():
            continue
        ordered_paths.append(normalized_path)
        seen.add(normalized_path)
        if len(ordered_paths) >= max_images:
            return ordered_paths[:max_images]

    representative_image = obj.get('representative_image')
    if representative_image:
        normalized_path = str(representative_image)
        if normalized_path not in seen and Path(normalized_path).exists():
            ordered_paths.append(normalized_path)
            seen.add(normalized_path)
            if len(ordered_paths) >= max_images:
                return ordered_paths[:max_images]

    for image_path in obj.get('source_images', []):
        normalized_path = str(image_path)
        if normalized_path in seen or not Path(normalized_path).exists():
            continue
        ordered_paths.append(normalized_path)
        seen.add(normalized_path)
        if len(ordered_paths) >= max_images:
            break

    return ordered_paths[:max_images]


def build_object_environment_cache_key(obj):
    representative_frame = str(obj.get('representative_frame') or '')
    representative_image = Path(str(obj.get('representative_image') or '')).name
    representative_view = obj.get('representative_source_view') or {}
    bbox = representative_view.get('bbox_xyxy') or []
    annotated_image = Path(str(representative_view.get('annotated_image') or '')).name
    return (
        f"v2|{obj.get('name', '')}|{obj.get('category', '')}|"
        f"{representative_frame}|{representative_image}|{bbox}|{annotated_image}"
    )


def describe_floor_condition(obj, max_images=1):
    """Use the VLM to assess floor cleanliness and trash for one floor object instance."""
    context_images = select_object_context_images(obj, max_images=max_images)
    if not context_images:
        return None

    object_payload = {
        "name": obj.get('name'),
        "category": obj.get('category'),
        "representative_frame": obj.get('representative_frame'),
        "source_frames": obj.get('source_frames', [])[:max_images],
    }

    prompt = f"""You are an expert in indoor floor condition assessment and scene understanding.

Target floor patch:
{json.dumps(object_payload, ensure_ascii=False, indent=2)}

Task:
1. Assess the floor surface cleanliness and any trash/debris visible in the images.
2. Identify the floor material and condition.
3. Describe what you see in natural English.

Return JSON only with this exact schema:
{{
  "floor_type": "carpet/tile/wood/concrete/marble/other",
  "cleanliness": "clean/slightly_dirty/moderately_dirty/heavily_dirty",
  "has_trash": true or false,
  "description": "One sentence natural language description of the floor condition in English. Example: The carpeted floor is slightly dirty with scattered yellow and white paper fragments, no stains or puddles.",
  "detected_objects": ["List of specific trash/items visible on the floor in English, e.g., paper fragments, crumpled paper ball, plastic bottle"],
  "has_stains": true or false,
  "has_puddles": true or false,
  "scene_tag": "Short tag in English, e.g., floor_trash/floor_clean/slightly_dirty_floor/floor_with_puddles"
}}

Rules:
1. Be specific about trash items — do not just say "debris", say what it looks like
2. If no trash or stains, say so explicitly (e.g., "The floor is clean with no visible trash or stains")
3. description must be a natural English sentence
4. Output ONLY the JSON object, no markdown, no extra text

Analyze the floor condition in the provided images NOW:"""

    return vlm_generate_json_from_images(context_images, prompt, max_tokens=1000, temperature=0.3, timeout=120)


def describe_person_behavior(obj, max_images=1):
    """Use the VLM to analyze person behavior and activity for one person object instance."""
    context_images = select_object_context_images(obj, max_images=max_images)
    if not context_images:
        return None

    object_payload = {
        "name": obj.get('name'),
        "category": obj.get('category'),
        "representative_frame": obj.get('representative_frame'),
        "source_frames": obj.get('source_frames', [])[:max_images],
    }

    prompt = f"""You are an expert in human behavior understanding and activity recognition in indoor scenes.

Target person:
{json.dumps(object_payload, ensure_ascii=False, indent=2)}

Task:
1. Analyze what the person is doing based on the provided images.
2. Describe their behavior, posture, and interaction with the environment.
3. Identify the key activity or action they are performing.

Return JSON only with this exact schema:
{{
  "posture": "sitting/standing/walking/bending/kneeling/lying/other",
  "activity": "short phrase describing the main activity, e.g., dumping garbage, filling water dispenser, cleaning the floor",
  "description": "One sentence natural language description of what the person is doing. Example: A person is dumping garbage into a trash can. A person is cleaning up the trash on the ground. A person is filling a water dispenser.",
  "interacting_with": ["List of objects or items the person is interacting with, e.g., trash can, garbage bag, water dispenser"],
  "environment_context": "Brief description of the surrounding environment, e.g., standing near a desk in an office, in a hallway next to a water cooler",
  "active_tag": "Short tag summarizing what the person is doing, e.g., dumping garbage, cleaning the floor, filling water dispenser, walking through hallway, resting on sofa"
}}

Rules:
1. If the person's behavior is unclear, say so briefly (e.g., "Person is standing but activity is unclear")
2. description must be a complete English sentence starting with "A person is ..."
3. active_tag should be a concise action phrase
4. Output ONLY the JSON object, no markdown, no extra text

Analyze the person's behavior in the provided images NOW:"""

    return vlm_generate_json_from_images(context_images, prompt, max_tokens=1000, temperature=0.3, timeout=120)


def describe_object_environment(obj, max_images=1):
    """Use the VLM to describe the local environment of one object instance."""
    context_images = select_object_context_images(obj, max_images=max_images)
    if not context_images:
        return None

    representative_view = obj.get('representative_source_view') or {}
    grounded_views = []
    for source_view in (obj.get('source_views', []) or [])[:2]:
        if not isinstance(source_view, dict):
            continue
        grounded_views.append(
            {
                "frame": source_view.get('frame'),
                "bbox_xyxy": source_view.get('bbox_xyxy'),
                "context_bbox_xyxy": source_view.get('context_bbox_xyxy'),
            }
        )

    object_payload = {
        "name": obj.get('name'),
        "category": obj.get('category'),
        "representative_frame": obj.get('representative_frame'),
        "source_frames": obj.get('source_frames', [])[:max_images],
        "representative_bbox_xyxy": representative_view.get('bbox_xyxy'),
        "grounded_views": grounded_views,
    }

    category = str(obj.get('category', '')).lower()

    if category in ('person', 'people', 'human'):
        prompt = f"""You are analyzing a person's behavior and posture in an indoor scene from multiple camera views.

Target person:
{json.dumps(object_payload, ensure_ascii=False, indent=2)}

Task:
- Analyze the person's current behavior, posture, and activity based on the images.
- Describe what the person appears to be doing (e.g., sitting, standing, walking, working, resting, interacting with objects).
- Mention their position relative to nearby furniture or objects (e.g., sitting at a desk, standing near the door).
- If multiple images show the same person from different angles, combine the views to infer their action.
- If the person's behavior is unclear or ambiguous, say so briefly.

Return JSON only with this exact schema:
{{
  "behavior_description": "1-3 concise sentences about what the person is doing",
  "posture": "sitting/standing/walking/lying/other",
  "activity": "short phrase like 'working at desk' or 'resting on sofa'",
  "nearby_context": ["nearby object or area 1", "nearby object or area 2"],
  "confidence": 0.0
}}"""
    else:
        prompt = f"""You are describing the surrounding environment of one specific indoor object instance from a few robot-camera views.

Target object:
{json.dumps(object_payload, ensure_ascii=False, indent=2)}

Grounding rules:
- The target object is explicitly indicated in the provided images.
- Full-frame images contain a highlighted or boxed target instance.
- Context crops are centered on the same target instance.
- Tight crops show the target object itself.
- If multiple objects of the same category appear, only describe the surroundings of the grounded target instance.

Task:
- Focus on the environment around this object instance, not on repeating the object category itself.
- Mention nearby furniture or fixtures, whether it is near a wall, corner, doorway, window, open area, or support surface.
- Use the multiple images to resolve the local context when possible.
- If the target is only partially visible or ambiguous, say so briefly.

Return JSON only with this exact schema:
{{
  "environment_description": "1-3 concise sentences about the surroundings",
  "landmarks": ["nearby landmark 1", "nearby landmark 2"],
  "spatial_context": "short phrase like 'against a wall beside a table'",
  "confidence": 0.0
}}"""

    return vlm_generate_json_from_images(
        image_paths=context_images,
        prompt=prompt,
        max_tokens=1000,
        temperature=0.05,
        timeout=90,
    )


def annotate_scene_graph_with_environment_descriptions(scene_graph, cache_file=None, max_images=3):
    """Generate and attach VLM environment descriptions for each final object.

    Returns:
        (scene_graph, floor_results, person_results)
        - scene_graph: updated with regular objects' environment descriptions
        - floor_results: list of floor cleaning inspection records
        - person_results: list of person behavior analysis records
    """
    objects = scene_graph.get('objects', [])
    if not objects:
        return scene_graph, [], []

    cache_path = Path(cache_file) if cache_file else None
    if cache_path is not None:
        cache_path.parent.mkdir(parents=True, exist_ok=True)

    cache = {}
    if cache_path is not None and cache_path.exists():
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                cache = json.load(f)
        except Exception:
            cache = {}

    refreshed_count = 0
    floor_results = []
    person_results = []
    for obj in tqdm(objects, desc="生成物体环境描述"):
        obj_category = str(obj.get('category', '')).lower()

        # Floor：使用清洁/垃圾检测函数
        if obj_category == 'floor':
            floor_cache_key = "floor_" + build_object_environment_cache_key(obj)
            cached_result = cache.get(floor_cache_key)

            if not isinstance(cached_result, dict):
                cached_result = describe_floor_condition(obj, max_images=max_images)
                if isinstance(cached_result, dict):
                    cache[floor_cache_key] = cached_result
                    refreshed_count += 1

            if isinstance(cached_result, dict):
                floor_type = str(cached_result.get('floor_type') or '').strip()
                cleanliness = str(cached_result.get('cleanliness') or '').strip()
                has_trash = bool(cached_result.get('has_trash', False))
                description = str(cached_result.get('description') or '').strip()
                detected_objects = [
                    str(item).strip()
                    for item in cached_result.get('detected_objects', [])
                    if str(item).strip()
                ]
                has_stains = bool(cached_result.get('has_stains', False))
                has_puddles = bool(cached_result.get('has_puddles', False))
                scene_tag = str(cached_result.get('scene_tag') or '').strip()

                rep_view = obj.get('representative_source_view') or {}
                floor_record = {
                    'id': obj.get('id'),
                    'name': obj.get('name'),
                    'category': obj.get('category'),
                    'center': obj.get('center'),
                    'room_id': obj.get('room_id'),
                    'floor_id': obj.get('floor_id'),
                    'representative_frame': obj.get('representative_frame'),
                    'annotated_image': str(rep_view.get('annotated_image') or '') if rep_view else None,
                    'nearby_objects': obj.get('nearby_objects', []),
                    'environment_description': '',
                    'timestamp': '',
                    'description': description,
                    'scene_tag': scene_tag,
                    'floor_analysis': {
                        'floor_type': floor_type,
                        'cleanliness': cleanliness,
                        'has_trash': has_trash,
                        'has_stains': has_stains,
                        'has_puddles': has_puddles,
                        'detected_objects': detected_objects,
                    },
                }
                floor_results.append(floor_record)
            continue

        # ================= person：行为分析 =================
        if obj_category in ('person', 'people', 'human'):
            person_cache_key = "person_" + build_object_environment_cache_key(obj)
            cached_result = cache.get(person_cache_key)

            if not isinstance(cached_result, dict):
                cached_result = describe_person_behavior(obj, max_images=max_images)
                if isinstance(cached_result, dict):
                    cache[person_cache_key] = cached_result
                    refreshed_count += 1

            if isinstance(cached_result, dict):
                posture = str(cached_result.get('posture') or '').strip()
                activity = str(cached_result.get('activity') or '').strip()
                description = str(cached_result.get('description') or '').strip()
                interacting_with = [
                    str(item).strip()
                    for item in cached_result.get('interacting_with', [])
                    if str(item).strip()
                ]
                env_context_str = str(cached_result.get('environment_context') or '').strip()
                active_tag = str(cached_result.get('active_tag') or '').strip()

                rep_view = obj.get('representative_source_view') or {}
                person_record = {
                    'id': obj.get('id'),
                    'name': obj.get('name'),
                    'category': obj.get('category'),
                    'center': obj.get('center'),
                    'room_id': obj.get('room_id'),
                    'floor_id': obj.get('floor_id'),
                    'representative_frame': obj.get('representative_frame'),
                    'annotated_image': str(rep_view.get('annotated_image') or '') if rep_view else None,
                    'nearby_objects': obj.get('nearby_objects', []),
                    'environment_description': env_context_str,
                    'timestamp': '',
                    'description': description,
                    'active_tag': active_tag,
                    'person_analysis': {
                        'posture': posture,
                        'activity': activity,
                        'interacting_with': interacting_with,
                    },
                }
                person_results.append(person_record)
            continue

        # ================= 常规物体：环境描述 =================
        cache_key = build_object_environment_cache_key(obj)
        cached_result = cache.get(cache_key)

        if not isinstance(cached_result, dict):
            cached_result = describe_object_environment(obj, max_images=max_images)
            if isinstance(cached_result, dict):
                cache[cache_key] = cached_result
                refreshed_count += 1

        if not isinstance(cached_result, dict):
            continue

        environment_description = str(cached_result.get('environment_description') or '').strip()
        landmarks = [
            str(item).strip()
            for item in cached_result.get('landmarks', [])
            if str(item).strip()
        ]
        spatial_context = str(cached_result.get('spatial_context') or '').strip()
        try:
            confidence = float(cached_result.get('confidence', 0.0))
        except (TypeError, ValueError):
            confidence = 0.0

        obj['environment_description'] = environment_description
        obj['environment_landmarks'] = landmarks[:8]
        obj['environment_spatial_context'] = spatial_context
        obj['environment_confidence'] = round(confidence, 3)

        environment_context = obj.get('environment_context')
        if not isinstance(environment_context, dict):
            environment_context = {}
        environment_context['vlm_description'] = environment_description
        environment_context['vlm_landmarks'] = landmarks[:8]
        environment_context['vlm_spatial_context'] = spatial_context
        environment_context['vlm_confidence'] = round(confidence, 3)
        obj['environment_context'] = environment_context

        if cache_path is not None and refreshed_count > 0 and refreshed_count % 5 == 0:
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(cache, f, indent=2, ensure_ascii=False)

    if cache_path is not None:
        with open(cache_path, 'w', encoding='utf-8') as f:
            json.dump(cache, f, indent=2, ensure_ascii=False)

    scene_graph['objects'] = objects
    scene_graph['has_environment_descriptions'] = any(
        obj.get('environment_description')
        for obj in objects
    )
    return scene_graph, floor_results, person_results


# ================= SAM 3.1 分割 =================

def sam3_segment(image_path, category):
    """SAM 3.1 文本分割 — text prompt → masks + boxes"""
    try:
        payload = {
            "image_path": str(Path(image_path).resolve()),
            "text": category,
        }

        response = requests.post(SAM3_URL, json=payload, timeout=30)
        response.raise_for_status()

        result = response.json()
        if not result.get('success', False):
            return []

        masks_data = result.get('masks', [])
        scores = result.get('scores', [])
        boxes = result.get('boxes', [])

        if not masks_data or len(masks_data) == 0:
            return []

        detections = []
        for i in range(len(masks_data)):
            mask = np.array(masks_data[i], dtype=np.float32)
            # convert to uint8 0/255
            mask = (mask > 0.5).astype(np.uint8) * 255
            score = scores[i] if i < len(scores) else 0.5

            if i < len(boxes):
                box_px = [int(boxes[i][0]), int(boxes[i][1]), int(boxes[i][2]), int(boxes[i][3])]
            else:
                # 从 mask 计算 bbox
                ys, xs = np.where(mask > 0)
                if len(xs) == 0:
                    continue
                box_px = [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]

            detections.append({
                'mask': mask,
                'box': box_px,
                'score': score,
            })

        # 过滤低置信度检测
        max_score_before_filter = max((d['score'] for d in detections), default=0.0)
        detections = [d for d in detections if d['score'] >= SAM3_MIN_CONFIDENCE]

        # 按分数降序
        detections.sort(key=lambda d: d['score'], reverse=True)

        if len(detections) > 0:
            print(f"      SAM3: {category} → {len(detections)} 个掩码 (阈值≥{SAM3_MIN_CONFIDENCE})")
        else:
            print(f"      SAM3: {category} → 0 个掩码 (最高分={max_score_before_filter:.2f} < {SAM3_MIN_CONFIDENCE})")

        return detections

    except Exception as e:
        print(f"      SAM3 失败 ({category}): {e}")
        return []


def sam3_segment_batch(image_path, category_prompts):
    """SAM 3.1 批量文本分割 — 图像编码一次，多个 text prompt 复用。

    Args:
        image_path: 图片路径
        category_prompts: [(category, sam3_text), ...] 列表

    Returns:
        {sam3_text: [detection, ...], ...} 字典，每个 detection 含 mask/box/score
    """
    empty = {text: [] for _, text in category_prompts}
    if not category_prompts:
        return empty

    texts = list(dict.fromkeys(text for _, text in category_prompts))  # 去重保序
    try:
        payload = {
            "image_path": str(Path(image_path).resolve()),
            "texts": texts,
        }
        response = requests.post(SAM3_BATCH_URL, json=payload, timeout=60)
        response.raise_for_status()
        result = response.json()

        if not result.get('success', False):
            print(f"      SAM3 batch: 服务端返回失败")
            return empty

        results_map = result.get('results', {})
    except Exception as e:
        print(f"      SAM3 batch 失败: {e}")
        return empty

    output = {}
    for text in texts:
        data = results_map.get(text, {})
        masks_data = data.get('masks', [])
        scores = data.get('scores', [])
        boxes = data.get('boxes', [])

        detections = []
        for i in range(len(masks_data)):
            mask = np.array(masks_data[i], dtype=np.float32)
            mask = (mask > 0.5).astype(np.uint8) * 255
            score = scores[i] if i < len(scores) else 0.5

            if i < len(boxes) and boxes[i]:
                box_px = [int(boxes[i][0]), int(boxes[i][1]), int(boxes[i][2]), int(boxes[i][3])]
            else:
                ys, xs = np.where(mask > 0)
                if len(xs) == 0:
                    continue
                box_px = [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]

            detections.append({
                'mask': mask,
                'box': box_px,
                'score': score,
            })

        detections = [d for d in detections if d['score'] >= SAM3_MIN_CONFIDENCE]
        detections.sort(key=lambda d: d['score'], reverse=True)
        output[text] = detections

    for category, text in category_prompts:
        n = len(output.get(text, []))
        if n > 0:
            print(f"      SAM3 batch: {category} → {n} 个掩码 (阈值≥{SAM3_MIN_CONFIDENCE})")

    return output


def mask_to_3d_points(mask_2d, depth_img, K, T_c2w, confidence=None, conf_threshold=0.0):
    """2D 掩码 → 3D 点云"""
    depth = depth_img.astype(np.float32)

    # 缩放掩码到深度尺寸
    if mask_2d.shape[:2] != depth.shape[:2]:
        mask_2d = cv2.resize(mask_2d.astype(np.float32), (depth.shape[1], depth.shape[0]),
                             interpolation=cv2.INTER_NEAREST).astype(np.uint8)

    mask_binary = (mask_2d > 128).astype(np.uint8)

    valid_mask = (mask_binary > 0) & (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
    if confidence is not None and conf_threshold > 0:
        valid_mask &= (confidence >= conf_threshold)
    
    if valid_mask.sum() == 0:
        return np.empty((0, 3))
    
    v, u = np.where(valid_mask)
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]
    
    z_cam = depth[v, u]
    x_cam = (u - cx) * z_cam / fx
    y_cam = (v - cy) * z_cam / fy
    
    points_cam = np.stack([x_cam, y_cam, z_cam], axis=-1)
    points_hom = np.hstack([points_cam, np.ones((len(points_cam), 1))])
    points_world = (T_c2w @ points_hom.T).T[:, :3]
    
    return points_world


# ================= 楼层分割 =================

def segment_floors(global_points, global_colors):
    """
    基于高度直方图 + 峰值检测的楼层分割

    流程:
    1. 体素下采样 (0.05m)
    2. 创建 Y 轴 (高度) 直方图 (bin=0.01m)
    3. 高斯平滑 + 峰值检测
    4. DBSCAN 聚类峰值
    5. 每两个峰值之间定义一个楼层
    """
    from sklearn.cluster import DBSCAN
    from scipy.signal import find_peaks
    from scipy.ndimage import gaussian_filter1d
    
    print("  体素下采样 (0.05m)...")
    down_points, down_colors = voxel_downsample(global_points, global_colors, 0.05)
    
    # 创建高度 (垂直轴) 直方图
    y_coords = down_points[:, VERTICAL_AXIS]
    y_min, y_max = y_coords.min(), y_coords.max()
    
    # 计算 bin 数量 (bin 大小=0.01m)
    num_bins = int((y_max - y_min) / FLOOR_HIST_BIN_SIZE)
    print(f"  高度范围：{y_min:.2f}m ~ {y_max:.2f}m, {num_bins} 个 bin")
    
    # 创建直方图
    hist, bin_edges = np.histogram(y_coords, bins=num_bins)
    
    # 高斯平滑
    hist_smooth = gaussian_filter1d(hist.astype(float), sigma=FLOOR_GAUSSIAN_SIGMA)
    
    # 峰值检测
    distance = int(FLOOR_PEAK_DISTANCE / FLOOR_HIST_BIN_SIZE)  # 转换为 bin 数量
    min_peak_height = np.percentile(hist_smooth, FLOOR_PEAK_HEIGHT_PERCENTILE)
    print(f"  峰值检测：distance={distance} bins, min_height={min_peak_height:.1f}")
    
    peaks, _ = find_peaks(hist_smooth, distance=distance, height=min_peak_height)
    print(f"  检测到 {len(peaks)} 个峰值")
    
    if len(peaks) == 0:
        print("  未检测到峰值，使用单楼层")
        floors = [{'id': 0, 'y_min': y_min, 'y_max': y_max, 'points': global_points, 'colors': global_colors}]
        return floors
    
    # 峰值位置 (实际高度值)
    peak_heights = bin_edges[peaks]
    print(f"  峰值高度：{peak_heights.round(2)}")
    
    # DBSCAN 聚类峰值
    clustering = DBSCAN(eps=FLOOR_DBSCAN_EPS, min_samples=1).fit(peak_heights.reshape(-1, 1))
    labels = clustering.labels_
    
    # 对每个聚类，取顶部和底部峰值作为楼层边界
    clustered_peaks = []
    for label in np.unique(labels):
        cluster_peaks = peak_heights[labels == label]
        if len(cluster_peaks) >= 2:
            # 取最高和最低的峰值
            clustered_peaks.extend([cluster_peaks.min(), cluster_peaks.max()])
        else:
            clustered_peaks.append(cluster_peaks[0])
    
    clustered_peaks = np.sort(clustered_peaks)
    print(f"  聚类后峰值：{clustered_peaks.round(2)}")
    
    # 生成楼层边界
    floors = []
    for i in range(0, len(clustered_peaks) - 1, 2):
        floor_y_min = clustered_peaks[i]
        floor_y_max = clustered_peaks[i + 1] if i + 1 < len(clustered_peaks) else y_max
        floors.append({'y_min': floor_y_min, 'y_max': floor_y_max})
    
    if len(floors) == 0:
        floors.append({'y_min': y_min, 'y_max': y_max})
    
    if len(floors) > 0:
        floors[0]['y_min'] = (floors[0]['y_min'] + y_min) / 2
        floors[-1]['y_max'] = y_max
    
    print(f"  检测到 {len(floors)} 个楼层")
    
    # 为每个楼层分配点云
    for i, floor in enumerate(floors):
        floor_mask = (global_points[:, VERTICAL_AXIS] >= floor['y_min']) & (global_points[:, VERTICAL_AXIS] <= floor['y_max'])
        floor['points'] = global_points[floor_mask]
        floor['colors'] = global_colors[floor_mask] if len(global_colors) == len(global_points) else global_colors[floor_mask]
        floor['id'] = i
        floor['floor_zero_level'] = floor['points'][:, VERTICAL_AXIS].min() if len(floor['points']) > 0 else floor['y_min']
        floor['room_height'] = floor['y_max'] - floor['floor_zero_level']
        print(f"    Floor {i}: {len(floor['points']):,} 点，zero_level={floor['floor_zero_level']:.2f}m, room_height={floor['room_height']:.2f}m")
    
    return floors


# ================= 房间分割 =================

def segment_rooms_by_floor(global_points, global_colors, objects):
    """
    基于 2D 直方图 + 形态学 + 距离变换

    流程:
    1. 提取 floor 点云 (基于高度过滤)
    2. 投影到 2D (XZ 平面)
    3. 创建 2D 直方图/栅格地图
    4. 形态学操作提取墙体骨架 (GaussianBlur + threshold)
    5. 距离变换 + 分水岭算法分割房间
    6. 映射回 3D 点云
    """
    import cv2
    from scipy import ndimage
    from sklearn.neighbors import NearestNeighbors

    # Step 1: 提取 floor 点云 (使用最低楼层地面点)
    floor_points_list = []
    for obj in objects:
        if obj['category'] == 'floor':
            floor_points_list.append(obj['points'])

    if len(floor_points_list) == 0:
        print("  未检测到 floor 点云，使用全局点云分割")
        return segment_rooms_geometric(global_points, global_colors)

    all_floor_points = np.vstack(floor_points_list)
    print(f"  Floor 点云：{len(all_floor_points):,} 点")

    # 计算楼层零平面和房间净高
    floor_zero_level = all_floor_points[:, VERTICAL_AXIS].min()
    room_height = all_floor_points[:, VERTICAL_AXIS].max() - floor_zero_level
    print(f"  Floor zero level: {floor_zero_level:.2f}m, room_height: {room_height:.2f}m")

    # Step 2: 高度过滤 (floor_zero_level+0.3 ~ room_height-0.3)
    height_min = floor_zero_level + ROOM_HEIGHT_MIN_OFFSET
    height_max = floor_zero_level + room_height - ROOM_HEIGHT_MAX_OFFSET
    floor_filtered = all_floor_points[(all_floor_points[:, VERTICAL_AXIS] >= height_min) &
                                       (all_floor_points[:, VERTICAL_AXIS] <= height_max)]
    print(f"  高度过滤后：{len(floor_filtered):,} 点")

    if len(floor_filtered) < 100:
        print("  floor 点云太少，使用 fallback 方法")
        return segment_rooms_geometric(global_points, global_colors)

    # Step 3: 投影到 2D (水平面)
    floor_2d = floor_filtered[:, HORIZONTAL_AXES]
    
    # 计算 2D 边界和栅格尺寸
    x_min, z_min = floor_2d.min(axis=0)
    x_max, z_max = floor_2d.max(axis=0)
    
    grid_size_x = int(np.ceil((x_max - x_min) / GRID_RESOLUTION)) + 1
    grid_size_z = int(np.ceil((z_max - z_min) / GRID_RESOLUTION)) + 1
    
    print(f"  2D 边界：X[{x_min:.2f}, {x_max:.2f}], Z[{z_min:.2f}, {z_max:.2f}]")
    print(f"  栅格尺寸：{grid_size_x} x {grid_size_z}")

    # Step 4: 创建 2D 直方图
    num_bins = (grid_size_z, grid_size_x)
    hist, _, _ = np.histogram2d(floor_2d[:, 1], floor_2d[:, 0], bins=num_bins,
                                 range=[[z_min, z_max], [x_min, x_max]])

    # 归一化并应用高斯模糊
    hist_norm = cv2.normalize(hist, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_blur = cv2.GaussianBlur(hist_norm, (GAUSSIAN_BLUR_KERNEL, GAUSSIAN_BLUR_KERNEL), GAUSSIAN_BLUR_SIGMA)

    # 阈值处理提取墙体骨架
    threshold = int(HIST_THRESHOLD_RATIO * 255)
    _, walls_skeleton = cv2.threshold(hist_blur, threshold, 255, cv2.THRESH_BINARY)

    # 添加 border 避免丢失墙体
    walls_skeleton = cv2.copyMakeBorder(
        walls_skeleton, 10, 10, 10, 10, cv2.BORDER_CONSTANT, value=0
    )
    
    # 墙体骨架形态学闭运算
    kernel_cross = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    walls_skeleton = cv2.morphologyEx(
        walls_skeleton, cv2.MORPH_CLOSE, kernel_cross, iterations=1
    )

    # Step 5: 提取外部边界
    hist_full, _, _ = np.histogram2d(
        floor_2d[:, 1], floor_2d[:, 0], bins=num_bins,
        range=[[z_min, z_max], [x_min, x_max]])
    hist_full = cv2.normalize(
        hist_full, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_full = cv2.GaussianBlur(hist_full, (21, 21), 2)
    _, outside_boundary = cv2.threshold(
        hist_full, 0, 255, cv2.THRESH_BINARY)
    
    outside_boundary = cv2.copyMakeBorder(
        outside_boundary, 10, 10, 10, 10, cv2.BORDER_CONSTANT, value=0
    )
    
    # 外部边界形态学闭运算
    kernel_rect_5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    outside_boundary = cv2.morphologyEx(
        outside_boundary, cv2.MORPH_CLOSE, kernel_rect_5, iterations=3
    )
    
    # 提取外部轮廓并填充
    contours, _ = cv2.findContours(
        outside_boundary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    outside_boundary_filled = np.zeros_like(outside_boundary)
    cv2.drawContours(outside_boundary_filled, contours, -1, 255, -1)
    outside_boundary = outside_boundary_filled.astype(np.uint8)

    # 合并墙体骨架和外部边界
    full_map = cv2.bitwise_or(
        walls_skeleton,
        cv2.bitwise_not(outside_boundary))

    # full_map 形态学闭运算
    kernel_rect_3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    full_map = cv2.morphologyEx(
        full_map, cv2.MORPH_CLOSE, kernel_rect_3, iterations=2
    )

    # Step 6: 距离变换 + 分水岭算法
    bw = cv2.bitwise_not(full_map)
    dist_transform = cv2.distanceTransform(bw, cv2.DIST_L2, cv2.DIST_MASK_3)

    # 归一化
    cv2.normalize(dist_transform, dist_transform, 0, 1.0, cv2.NORM_MINMAX)
    
    # 高斯模糊 + Otsu 阈值
    dist_transform_uint8 = (dist_transform * 255).astype(np.uint8)
    dist_blur = cv2.GaussianBlur(dist_transform_uint8, (11, 1), 10)
    _, dist_thresh = cv2.threshold(dist_blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    dist_8u = dist_thresh.astype(np.uint8)
    contours, _ = cv2.findContours(dist_8u, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    print(f"  距离变换种子数：{len(contours)}")
    
    # 移除小面积种子 (min_area = 0.5m²)
    min_area_m = 0.5
    min_area = (min_area_m / GRID_RESOLUTION) ** 2
    contours = [c for c in contours if cv2.contourArea(c) > min_area]
    print(f"  过滤后种子数：{len(contours)}")

    markers = np.zeros(dist_8u.shape, dtype=np.int32)
    for i, contour in enumerate(contours):
        cv2.drawContours(markers, [contour], -1, i + 1, -1)
    
    cv2.circle(markers, (3, 3), 1, len(contours) + 1, -1)
    
    # 分水岭算法
    if len(contours) > 0:
        full_map_3ch = cv2.cvtColor(full_map, cv2.COLOR_GRAY2BGR)
        markers = cv2.watershed(full_map_3ch, markers)
    else:
        print("  没有种子区域，跳过分水岭")
        markers = np.zeros_like(full_map, dtype=np.int32)

    # Step 6.5: 连通性后处理 — 拆分不连通的区域
    # 用 connectedComponentsWithStats 检测并拆分
    unique_markers = np.unique(markers[markers > 1])  # 跳过背景 (0) 和未知 (-1)
    print(f"  分水岭分割得到 {len(unique_markers)} 个区域")

    split_rooms = []  # (marker_id, mask_2d)
    for marker_id in unique_markers:
        room_mask = (markers == marker_id).astype(np.uint8)
        components = cv2.connectedComponentsWithStats(room_mask, connectivity=4)
        n_labels, labels, stats = components[0], components[1], components[2]

        # 跳过背景 (label=0)，检查每个连通分量
        for label in range(1, n_labels):
            area = stats[label, cv2.CC_STAT_AREA]
            if area < 25:  # 最小 25 个栅格单元，太小的碎片丢弃
                continue
            component_mask = (labels == label).astype(np.uint8)
            split_rooms.append((marker_id, component_mask))

    print(f"  连通性检查后：{len(split_rooms)} 个房间区域（含拆分）")

    # Step 7: 为每个连通区域创建房间
    rooms = []

    # 2D 房间映射回 3D 点云
    floor_tree = NearestNeighbors(n_neighbors=1).fit(floor_2d)
    
    for room_idx, (marker_id, room_mask) in enumerate(split_rooms):
        # 获取房间 2D 点 (栅格坐标)
        room_2d_indices = np.where(room_mask)
        if len(room_2d_indices[0]) < 10:
            continue

        # 计算房间 2D 边界 (世界坐标)
        z_indices = room_2d_indices[0] * GRID_RESOLUTION + z_min
        x_indices = room_2d_indices[1] * GRID_RESOLUTION + x_min

        room_x_min, room_x_max = x_indices.min(), x_indices.max()
        room_z_min, room_z_max = z_indices.min(), z_indices.max()

        # 2D 房间栅格映射回点云
        room_2d_cells = np.column_stack([x_indices, z_indices])
        _, indices = floor_tree.kneighbors(room_2d_cells, n_neighbors=1)
        room_floor_points = floor_filtered[indices.flatten()]

        if len(room_floor_points) < 50:
            continue

        # 房间中心
        room_center = room_floor_points.mean(axis=0)

        # 分配全局点云到房间
        global_tree = NearestNeighbors(n_neighbors=1).fit(global_points[:, HORIZONTAL_AXES])

        # 为房间生成 3D 边界框
        room_bbox_min = np.array([room_x_min, floor_zero_level, room_z_min])
        room_bbox_max = np.array([room_x_max, floor_zero_level + room_height, room_z_max])

        # 分配点云：水平距离 < 0.5m 且高度在房间范围内
        room_center_2d = room_center[HORIZONTAL_AXES]
        dists, indices = global_tree.kneighbors(room_center_2d.reshape(1, 2), n_neighbors=100)

        room_points = []
        room_colors = []
        for i, pt in enumerate(global_points):
            pt_2d = pt[HORIZONTAL_AXES]
            dist_2d = np.linalg.norm(pt_2d - room_center_2d)
            height_ok = (pt[VERTICAL_AXIS] >= floor_zero_level - 0.5 and
                        pt[VERTICAL_AXIS] <= floor_zero_level + room_height + 0.5)

            # 检查点是否在房间 2D 边界内
            in_bbox = (room_x_min - 0.5 <= pt_2d[0] <= room_x_max + 0.5 and
                      room_z_min - 0.5 <= pt_2d[1] <= room_z_max + 0.5)

            if in_bbox and height_ok:
                room_points.append(pt)
                room_colors.append(global_colors[i] if len(global_colors) == len(global_points) else [128, 128, 128])

        if len(room_points) < 100:
            continue

        room_points = np.array(room_points)
        room_colors = np.array(room_colors)

        rooms.append({
            'id': len(rooms),
            'points': room_points,
            'colors': room_colors,
            'center': room_points.mean(axis=0),
            'area': np.prod(room_points[:, HORIZONTAL_AXES].max(axis=0) - room_points[:, HORIZONTAL_AXES].min(axis=0)),
            'bbox': {
                'min': room_points.min(axis=0).tolist(),
                'max': room_points.max(axis=0).tolist()
            },
            'floor_zero_level': floor_zero_level,
            'room_height': room_height
        })

    print(f"  最终房间数：{len(rooms)}")
    return rooms


def segment_rooms_geometric(points, colors):
    """基于几何的房间分割"""
    if len(points) < 1000:
        return []

    # 1. 提取 floor/ceiling (基于垂直轴坐标)
    y_coords = points[:, VERTICAL_AXIS]
    y_min, y_max = y_coords.min(), y_coords.max()

    floor_mask = y_coords < (y_min + 0.3)
    ceiling_mask = y_coords > (y_max - 0.3)

    # 2. 在水平面上聚类房间
    floor_points = points[floor_mask]
    if len(floor_points) < 100:
        return []

    from sklearn.cluster import DBSCAN

    # 地面点投影到水平面
    floor_2d = floor_points[:, HORIZONTAL_AXES]

    # DBSCAN 聚类房间
    db = DBSCAN(eps=0.5, min_samples=50).fit(floor_2d)
    labels = db.labels_

    rooms = []
    for label in np.unique(labels[labels >= 0]):
        room_mask = np.zeros(len(points), dtype=bool)
        room_floor_indices = np.where(labels == label)[0]

        # 找到对应的 3D 点索引
        floor_indices = np.where(floor_mask)[0]
        room_3d_indices = floor_indices[room_floor_indices]
        room_mask[room_3d_indices] = True

        room_points = points[room_mask]
        room_colors = colors[room_mask]

        if len(room_points) > 100:
            rooms.append({
                'points': room_points,
                'colors': room_colors,
                'center': room_points.mean(axis=0),
                'area': np.prod(room_points[:, HORIZONTAL_AXES].max(axis=0) - room_points[:, HORIZONTAL_AXES].min(axis=0))
            })

    return rooms


# ================= 物体合并 (点云 IoU + 多轮迭代) =================

def _can_merge_objects(obj_a, obj_b, overlap_threshold=0.30, voxel_size=0.02,
                       containment_threshold=None):
    """
    判断两个物体是否应合并，使用两种互补的判定策略：

    策略1 - 双向体素占用：
        AABB 交集区域内的体素占用比例，双向都超过阈值才合并。
        适用于大小相近的物体。

    策略2 - 包含率：
        小物体的体素有多少比例落在大物体的 AABB 内。
        当小物体几乎完全被大物体包含时触发合并，解决大小悬殊时
        AABB IoU 失效的问题（如 chair_20 100% 在 chair_19 bbox 内，
        但 IoU 仅 0.018）。

    支持预计算的体素数据（通过 _precomputed 字段），避免重复体素化。
    """
    if containment_threshold is None:
        containment_threshold = OBJECT_MERGE_CONTAINMENT_THRESHOLD

    if len(obj_a['points']) == 0 or len(obj_b['points']) == 0:
        return False

    # 使用预计算数据或按需计算
    pre_a = obj_a.get('_precomputed')
    pre_b = obj_b.get('_precomputed')

    if pre_a is not None:
        unique_voxels_a = pre_a['unique_voxels']
        bbox_a_min, bbox_a_max = pre_a['bbox_min'], pre_a['bbox_max']
    else:
        pts_a = obj_a['points']
        bbox_a_min, bbox_a_max = pts_a.min(axis=0), pts_a.max(axis=0)
        unique_voxels_a = np.unique(np.floor(pts_a / voxel_size).astype(np.int64), axis=0)

    if pre_b is not None:
        unique_voxels_b = pre_b['unique_voxels']
        bbox_b_min, bbox_b_max = pre_b['bbox_min'], pre_b['bbox_max']
    else:
        pts_b = obj_b['points']
        bbox_b_min, bbox_b_max = pts_b.min(axis=0), pts_b.max(axis=0)
        unique_voxels_b = np.unique(np.floor(pts_b / voxel_size).astype(np.int64), axis=0)

    total_voxels_a = len(unique_voxels_a)
    total_voxels_b = len(unique_voxels_b)

    # AABB 预过滤：不相交则直接跳过
    inter_min = np.maximum(bbox_a_min, bbox_b_min)
    inter_max = np.minimum(bbox_a_max, bbox_b_max)
    if np.any(inter_min >= inter_max):
        return False

    def count_voxels_in_bbox(unique_voxels, region_min, region_max, voxel_size):
        rmin = np.floor(region_min / voxel_size).astype(np.int64)
        rmax = np.floor(region_max / voxel_size).astype(np.int64)
        in_region = np.all((unique_voxels >= rmin) & (unique_voxels <= rmax), axis=1)
        return int(np.sum(in_region))

    # ---- 策略2: 包含率 ----
    if total_voxels_a >= total_voxels_b:
        small_voxels, large_bbox_min, large_bbox_max = unique_voxels_b, bbox_a_min, bbox_a_max
        small_total = total_voxels_b
    else:
        small_voxels, large_bbox_min, large_bbox_max = unique_voxels_a, bbox_b_min, bbox_b_max
        small_total = total_voxels_a

    small_in_large = count_voxels_in_bbox(small_voxels, large_bbox_min, large_bbox_max, voxel_size)
    containment_ratio = small_in_large / small_total if small_total > 0 else 0.0

    if containment_ratio >= containment_threshold:
        return True

    # ---- 策略1: 双向体素占用 ----
    voxels_a_in_inter = count_voxels_in_bbox(unique_voxels_a, inter_min, inter_max, voxel_size)
    voxels_b_in_inter = count_voxels_in_bbox(unique_voxels_b, inter_min, inter_max, voxel_size)

    ratio_a = voxels_a_in_inter / total_voxels_a if total_voxels_a > 0 else 0.0
    ratio_b = voxels_b_in_inter / total_voxels_b if total_voxels_b > 0 else 0.0

    return ratio_a >= overlap_threshold and ratio_b >= overlap_threshold


def _merge_cluster(cluster):
    """合并一个簇中的所有物体实例，返回合并后的单个物体字典。"""
    all_pts = np.vstack([c['points'] for c in cluster])
    source_views = merge_source_views(cluster)
    source_frames = _dedupe_ordered_strings(
        [c.get('frame') for c in cluster] + [view.get('frame') for view in source_views],
        limit=OBJECT_SOURCE_VIEW_LIMIT,
    )
    source_images = _dedupe_ordered_strings(
        [c.get('image_path') for c in cluster] + [view.get('image_path') for view in source_views],
        limit=OBJECT_SOURCE_VIEW_LIMIT,
    )
    representative_source_view = source_views[0] if source_views else None

    # 统一类别名
    unified = cluster[0]['category']
    for c in cluster[1:]:
        unified = _unified_category_name(unified, c['category'])

    return {
        'category': unified,
        'points': all_pts,
        'num_frames': len(cluster),
        'source_frames': source_frames,
        'source_images': source_images,
        'source_views': source_views,
        'representative_source_view': representative_source_view,
        'representative_frame': (
            representative_source_view.get('frame')
            if representative_source_view
            else next((str(c.get('frame')) for c in cluster if c.get('frame')), None)
        ),
        'representative_image': (
            representative_source_view.get('image_path')
            if representative_source_view
            else next((str(c.get('image_path')) for c in cluster if c.get('image_path')), None)
        ),
    }


def _precompute_voxel_data(obj, voxel_size):
    """为物体预计算体素化数据和 AABB，供合并比较时复用。"""
    pts = obj['points']
    if len(pts) == 0:
        return {'unique_voxels': np.empty((0, 3), dtype=np.int64),
                'bbox_min': np.zeros(3), 'bbox_max': np.zeros(3)}
    return {
        'unique_voxels': np.unique(np.floor(pts / voxel_size).astype(np.int64), axis=0),
        'bbox_min': pts.min(axis=0),
        'bbox_max': pts.max(axis=0),
    }


def iterative_merge_objects(all_objects, max_rounds=4):
    """
    使用并查集合并：处理所有重叠关系，确保传递性 (A-B, B-C → A-B-C)。

    优化：预计算体素数据 + 同类别分组比较，避免 O(n²) 全对全 + 重复体素化。
    """
    objects = list(all_objects)

    # 预计算每个物体的体素数据和 AABB
    for obj in objects:
        obj['_precomputed'] = _precompute_voxel_data(obj, VOXEL_SIZE)

    rounds = [
        {'overlap': 0.30, 'semantic': True, 'dist': None, 'label': '体素占用≥30% (含同义词)'},
    ]

    for round_idx, params in enumerate(rounds[:max_rounds]):
        prev_count = len(objects)
        n = len(objects)

        parent = list(range(n))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py

        # 按类别分组，只在同类别（或语义相似类别）内做两两比较
        from collections import defaultdict
        cat_groups = defaultdict(list)
        for i in range(n):
            cat_groups[objects[i]['category']].append(i)

        cat_list = list(cat_groups.keys())

        for ci_idx in range(len(cat_list)):
            cat_a = cat_list[ci_idx]
            indices_a = cat_groups[cat_a]

            # 同类别内两两比较
            for ii in range(len(indices_a)):
                for jj in range(ii + 1, len(indices_a)):
                    i, j = indices_a[ii], indices_a[jj]
                    if find(i) == find(j):
                        continue

                    if params['dist'] is not None:
                        ci = objects[i]['points'].mean(axis=0)
                        cj = objects[j]['points'].mean(axis=0)
                        if np.linalg.norm(ci - cj) > params['dist']:
                            continue

                    should_merge = False
                    if params['overlap'] > 0:
                        should_merge = _can_merge_objects(
                            objects[i], objects[j],
                            overlap_threshold=params['overlap'],
                        )
                    else:
                        should_merge = True

                    if should_merge:
                        union(i, j)

            # 语义相似类别间的比较
            if params['semantic']:
                for cj_idx in range(ci_idx + 1, len(cat_list)):
                    cat_b = cat_list[cj_idx]
                    if not _categories_semantically_similar(cat_a, cat_b):
                        continue
                    indices_b = cat_groups[cat_b]
                    for i in indices_a:
                        for j in indices_b:
                            if find(i) == find(j):
                                continue
                            if params['overlap'] > 0:
                                if _can_merge_objects(objects[i], objects[j],
                                                      overlap_threshold=params['overlap']):
                                    union(i, j)
                            else:
                                union(i, j)

        clusters = defaultdict(list)
        for i in range(n):
            clusters[find(i)].append(objects[i])

        new_objects = [_merge_cluster(cluster) for cluster in clusters.values()]

        # 合并后重新预计算体素数据（合并后点云变了）
        for obj in new_objects:
            obj['_precomputed'] = _precompute_voxel_data(obj, VOXEL_SIZE)

        print(f"  Round {round_idx+1} ({params['label']}): {prev_count} → {len(new_objects)} 个物体")
        objects = new_objects

        if len(new_objects) >= prev_count:
            break

    # 清理临时字段
    for obj in objects:
        obj.pop('_precomputed', None)

    return objects


# ================= 场景拓扑图 =================

def _is_point_in_bbox(point, bbox):
    lower = bbox.get('min') or []
    upper = bbox.get('max') or []
    if len(point) != 3 or len(lower) != 3 or len(upper) != 3:
        return False
    return all(lower[idx] <= point[idx] <= upper[idx] for idx in range(3))


def _infer_room_id_for_center(center, room_records):
    if len(center) != 3:
        return None

    for room in room_records:
        if _is_point_in_bbox(center, room.get('bbox', {})):
            return room.get('id')

    best_room_id = None
    best_distance = float('inf')
    center_xz = np.array([center[HORIZONTAL_AXES[0]], center[HORIZONTAL_AXES[1]]], dtype=float)
    for room in room_records:
        room_center = room.get('center') or []
        if len(room_center) != 3:
            continue
        room_xz = np.array([room_center[HORIZONTAL_AXES[0]], room_center[HORIZONTAL_AXES[1]]], dtype=float)
        distance = float(np.linalg.norm(center_xz - room_xz))
        if distance < best_distance:
            best_distance = distance
            best_room_id = room.get('id')
    return best_room_id


def _infer_floor_id_for_room(room_record, floors):
    room_id = room_record.get('id')
    for floor in floors or []:
        if room_id in (floor.get('room_ids') or []):
            return floor.get('id')

    center = room_record.get('center') or []
    if len(center) != 3:
        return None

    for floor in floors or []:
        if _is_point_in_bbox(center, floor.get('bbox', {})):
            return floor.get('id')

    return None


def _infer_floor_id_for_center(center, floors):
    if len(center) != 3:
        return None
    for floor in floors or []:
        if _is_point_in_bbox(center, floor.get('bbox', {})):
            return floor.get('id')
    return None


def _summarize_nearby_objects(objects, center, exclude_id=None, radius=2.5, limit=5):
    if len(center) != 3:
        return []

    center_xz = np.array([center[HORIZONTAL_AXES[0]], center[HORIZONTAL_AXES[1]]], dtype=float)
    counts = Counter()
    for obj in objects:
        if exclude_id is not None and obj.get('id') == exclude_id:
            continue
        other_center = obj.get('center') or []
        if len(other_center) != 3:
            continue
        other_xz = np.array([other_center[HORIZONTAL_AXES[0]], other_center[HORIZONTAL_AXES[1]]], dtype=float)
        if float(np.linalg.norm(center_xz - other_xz)) <= radius:
            category = str(obj.get('category') or '').strip()
            if category:
                counts[category] += 1

    return [
        {'category': category, 'count': int(count)}
        for category, count in counts.most_common(limit)
    ]


def export_hierarchical_graph(output_dir, floor_levels, rooms, objects, scene_graph):
    """
    目录结构:
        <output_dir>/hierarchical_graph/
            floors/<floor_id>.ply + .json
            rooms/<floor_id>_<room_local_id>.ply + .json
            objects/<floor_id>_<room_local_id>_<obj_local_id>.ply + .json

    ID 命名规范:
        Floor:  "0", "1", ...
        Room:   "0_0", "0_1", ... (floor_room_local)
        Object: "0_0_0", "0_1_2", ... (floor_room_local_obj_local)

    参数:
        output_dir: 输出根目录 (如 unified_output/)
        floor_levels: 楼层列表
        rooms: 房间列表
        objects: 物体列表 (final_objects)
        scene_graph: 已构建的场景图 JSON (用于物体 room_id 映射)
    """
    import shutil

    graph_dir = output_dir / "hierarchical_graph"
    floors_dir = graph_dir / "floors"
    rooms_dir = graph_dir / "rooms"
    objects_dir = graph_dir / "objects"

    for d in [floors_dir, rooms_dir, objects_dir]:
        d.mkdir(parents=True, exist_ok=True)

    # 清空旧文件
    for d in [floors_dir, rooms_dir, objects_dir]:
        for f in d.glob("*"):
            f.unlink()

    print(f"  导出分层场景图到: {graph_dir}")

    # ============ 1. 导出 Floors ============
    room_id_map = {}  # global_room_id -> (floor_id_str, room_local_id, room_id_str)
    obj_id_map = {}   # global_obj_id -> object_id_str

    for floor_idx, floor_data in enumerate(floor_levels):
        floor_id_str = str(floor_idx)
        floor_points = floor_data.get('points', np.empty((0, 3)))
        floor_colors = floor_data.get('colors', np.empty((0, 3)))

        # 保存 Floor PLY
        floor_ply_path = floors_dir / f"{floor_id_str}.ply"
        floor_pcd = o3d.geometry.PointCloud()
        if len(floor_points) > 0:
            floor_pcd.points = o3d.utility.Vector3dVector(floor_points.astype(np.float64))
        if len(floor_colors) > 0 and len(floor_colors) == len(floor_points):
            if floor_colors.max() > 1.0:
                floor_pcd.colors = o3d.utility.Vector3dVector(floor_colors / 255.0)
            else:
                floor_pcd.colors = o3d.utility.Vector3dVector(floor_colors)
        o3d.io.write_point_cloud(str(floor_ply_path), floor_pcd)

        # 计算 8 顶点 bbox
        if len(floor_points) > 0:
            pmin = floor_points.min(axis=0)
            pmax = floor_points.max(axis=0)
            vertices = [
                [pmin[0], pmin[1], pmin[2]], [pmax[0], pmin[1], pmin[2]],
                [pmax[0], pmax[1], pmin[2]], [pmin[0], pmax[1], pmin[2]],
                [pmin[0], pmin[1], pmax[2]], [pmax[0], pmin[1], pmax[2]],
                [pmax[0], pmax[1], pmax[2]], [pmin[0], pmax[1], pmax[2]],
            ]
        else:
            vertices = []

        # 收集该楼层的房间 ID
        floor_rooms = [r for r in rooms if r.get('floor_id', 0) == floor_idx]
        floor_room_id_strs = []

        for room_local_id, room in enumerate(floor_rooms):
            room_id_str = f"{floor_id_str}_{room_local_id}"
            floor_room_id_strs.append(room_id_str)
            room_id_map[room['id']] = (floor_id_str, room_local_id, room_id_str)

        # 保存 Floor JSON
        floor_json = {
            'floor_id': floor_id_str,
            'name': f'Floor {floor_idx}',
            'rooms': floor_room_id_strs,
            'vertices': vertices,
            'room_height': float(floor_data.get('room_height') or 0),
            'floor_zero_level': float(floor_data.get('floor_zero_level') or 0),
        }
        with open(floors_dir / f"{floor_id_str}.json", 'w') as f:
            json.dump(floor_json, f, indent=2, default=str)

        print(f"    Floor {floor_id_str}: {len(floor_points):,} 点, {len(floor_rooms)} 个房间")

    # ============ 2. 导出 Rooms ============
    # 预计算 object ID 映射（供 Room JSON 使用）
    _room_obj_counter = defaultdict(int)
    for sg_obj in scene_graph.get('objects', []):
        _sg_room_id = sg_obj.get('room_id')
        if _sg_room_id is not None and _sg_room_id in room_id_map:
            _f_id, _, _r_id = room_id_map[_sg_room_id]
        else:
            _f_id = str(sg_obj.get('floor_id', 0))
            _r_id = f"{_f_id}_0"
        _local = _room_obj_counter[(_f_id, _r_id)]
        _room_obj_counter[(_f_id, _r_id)] += 1
        obj_id_map[sg_obj['id']] = f"{_f_id}_{_r_id.split('_', 1)[1]}_{_local}"

    for floor_idx, floor_data in enumerate(floor_levels):
        floor_id_str = str(floor_idx)
        floor_rooms = [r for r in rooms if r.get('floor_id', 0) == floor_idx]

        for room_local_id, room in enumerate(floor_rooms):
            room_id_str = f"{floor_id_str}_{room_local_id}"
            room_points = room.get('points', np.empty((0, 3)))
            room_colors = room.get('colors', np.empty((0, 3)))

            # 保存 Room PLY
            room_ply_path = rooms_dir / f"{room_id_str}.ply"
            room_pcd = o3d.geometry.PointCloud()
            if len(room_points) > 0:
                room_pcd.points = o3d.utility.Vector3dVector(room_points.astype(np.float64))
            if len(room_colors) > 0 and len(room_colors) == len(room_points):
                if room_colors.max() > 1.0:
                    room_pcd.colors = o3d.utility.Vector3dVector(room_colors / 255.0)
                else:
                    room_pcd.colors = o3d.utility.Vector3dVector(room_colors)
            o3d.io.write_point_cloud(str(room_ply_path), room_pcd)

            # 计算 room 高度参数
            if len(room_points) > 0:
                r_y = room_points[:, VERTICAL_AXIS]
                room_zero_level = float(r_y.min())
                room_height = float(r_y.max() - r_y.min())
                # 2D vertices (XZ 平面投影)
                r_xz = room_points[:, HORIZONTAL_AXES]
                v_min = r_xz.min(axis=0)
                v_max = r_xz.max(axis=0)
                vertices = [
                    [float(v_min[0]), float(v_min[1])],
                    [float(v_max[0]), float(v_min[1])],
                    [float(v_max[0]), float(v_max[1])],
                    [float(v_min[0]), float(v_max[1])],
                ]
            else:
                room_zero_level = 0.0
                room_height = 0.0
                vertices = []

            # 收集该房间内的物体 ID
            room_object_id_strs = []
            sg_room_id = room['id']
            for sg_obj in scene_graph.get('objects', []):
                if sg_obj.get('room_id') == sg_room_id:
                    obj_id = sg_obj['id']
                    if obj_id in obj_id_map:
                        room_object_id_strs.append(obj_id_map[obj_id])

            # 保存 Room JSON
            room_json = {
                'room_id': room_id_str,
                'name': f'Room {room_id_str}',
                'floor_id': floor_id_str,
                'objects': room_object_id_strs,
                'vertices': vertices,
                'room_height': room_height,
                'room_zero_level': room_zero_level,
            }
            with open(rooms_dir / f"{room_id_str}.json", 'w') as f:
                json.dump(room_json, f, indent=2, default=str)

    # ============ 3. 导出 Objects ============
    for sg_obj in scene_graph.get('objects', []):
        obj_global_id = sg_obj['id']
        category = sg_obj.get('category', 'object')
        name = sg_obj.get('name', category)
        sg_room_id = sg_obj.get('room_id')

        # 查找对应的 room_id_str
        if sg_room_id is not None and sg_room_id in room_id_map:
            _, _, room_id_str = room_id_map[sg_room_id]
        else:
            room_id_str = f"{sg_obj.get('floor_id', 0)}_0"

        object_id_str = obj_id_map.get(obj_global_id, f"0_0_{obj_global_id}")

        # 从 final_objects 中获取点云
        obj_points = None
        obj_colors = None
        if obj_global_id < len(objects):
            raw_obj = objects[obj_global_id]
            obj_points = raw_obj.get('points', np.empty((0, 3)))
            obj_colors = raw_obj.get('colors', np.empty((0, 3)))

        # 保存 Object PLY
        obj_ply_path = objects_dir / f"{object_id_str}.ply"
        obj_pcd = o3d.geometry.PointCloud()
        if obj_points is not None and len(obj_points) > 0:
            obj_pcd.points = o3d.utility.Vector3dVector(obj_points.astype(np.float64))
        if obj_colors is not None and len(obj_colors) > 0 and len(obj_colors) == len(obj_points):
            if obj_colors.max() > 1.0:
                obj_pcd.colors = o3d.utility.Vector3dVector(obj_colors / 255.0)
            else:
                obj_pcd.colors = o3d.utility.Vector3dVector(obj_colors)
        o3d.io.write_point_cloud(str(obj_ply_path), obj_pcd)

        # 计算物体高度
        if obj_points is not None and len(obj_points) > 0:
            o_y = obj_points[:, VERTICAL_AXIS]
            object_zero_level = float(o_y.min())
            object_height = float(o_y.max() - o_y.min())
        else:
            object_zero_level = 0.0
            object_height = 0.0

        # 保存 Object JSON
        obj_json = {
            'object_id': object_id_str,
            'persistent_id': sg_obj.get('persistent_id'),
            'name': name,
            'room_id': room_id_str,
            'object_height': object_height,
            'object_zero_level': object_zero_level,
            'lifecycle': sg_obj.get('lifecycle', {}),
            'embedding': [],
            'view_ids': [],
            'best_view_id': '',
        }
        with open(objects_dir / f"{object_id_str}.json", 'w') as f:
            json.dump(obj_json, f, indent=2, default=str)

    # 统计
    n_floors = len(list(floors_dir.glob("*.json")))
    n_rooms = len(list(rooms_dir.glob("*.json")))
    n_objects = len(list(objects_dir.glob("*.json")))
    print(f"  ✓ 已导出: {n_floors} 楼层, {n_rooms} 房间, {n_objects} 物体")
    print(f"  目录: {graph_dir}")

    return graph_dir


def build_scene_graph(global_pcd, rooms, objects, merged_objects, floors=None):
    """构建分层场景拓扑图"""

    scene_graph = {
        'timestamp': datetime.now().isoformat(),
        'global_bbox': {
            'min': global_pcd['points'].min(axis=0).tolist(),
            'max': global_pcd['points'].max(axis=0).tolist(),
            'num_points': len(global_pcd['points'])
        },
        'floors': [],
        'rooms': [],
        'connections': [],
        'objects_summary': {},
        'processing_config': {
            'max_frames': MAX_FRAMES,
            'skip_frames': SKIP_FRAMES,
            'object_detection_interval': OBJECT_DETECTION_INTERVAL,
            'actual_frames_processed': merged_objects.get('num_frames', 0),
            'detection_frames': merged_objects.get('detection_frames', 0),
            'merge_categories': MERGE_CATEGORIES,
            'detect_categories': OBJECT_CATEGORIES
        }
    }

    # 使用传入的 floors 参数
    if floors is not None and len(floors) > 0:
        for floor_idx, floor in enumerate(floors):
            floor_rooms = [i for i, r in enumerate(rooms) if r.get('floor_id') == floor_idx]
            floor_pts = floor.get('points')
            has_points = floor_pts is not None and len(floor_pts) > 0
            scene_graph['floors'].append({
                'id': floor_idx,
                'y_level': floor.get('zero_level', floor.get('floor_zero_level', 0)),
                'room_height': floor.get('height', floor.get('room_height', 0) or 0),
                'num_rooms': len(floor_rooms),
                'room_ids': floor_rooms,
                'bbox': {
                    'min': [float(floor_pts[:, 0].min()),
                            float(floor_pts[:, 1].min()),
                            float(floor_pts[:, 2].min())] if has_points else [0,0,0],
                    'max': [float(floor_pts[:, 0].max()),
                            float(floor_pts[:, 1].max()),
                            float(floor_pts[:, 2].max())] if has_points else [0,0,0]
                }
            })
    else:
        # Fallback: 按 Y 坐标分层
        if len(rooms) > 0:
            y_sorted = sorted(rooms, key=lambda r: r['center'][VERTICAL_AXIS])

            current_floor = {'rooms': [], 'y_level': y_sorted[0]['center'][VERTICAL_AXIS]}
            floor_id = 0

            for room in y_sorted:
                if abs(room['center'][VERTICAL_AXIS] - current_floor['y_level']) > FLOOR_HEIGHT_THRESHOLD:
                    scene_graph['floors'].append({
                        'id': floor_id,
                        'y_level': current_floor['y_level'],
                        'num_rooms': len(current_floor['rooms']),
                        'room_ids': list(range(len(current_floor['rooms'])))
                    })
                    floor_id += 1
                    current_floor = {'rooms': [], 'y_level': room['center'][1]}
                current_floor['rooms'].append(room)

            if current_floor['rooms']:
                scene_graph['floors'].append({
                    'id': floor_id,
                    'y_level': current_floor['y_level'],
                    'num_rooms': len(current_floor['rooms']),
                    'room_ids': list(range(len(current_floor['rooms'])))
                })

    # 房间信息 (几何属性)
    scene_graph['rooms'] = [
        {
            'id': i,
            'center': r['center'].tolist(),
            'area': float(r.get('area', 0)),
            'num_points': r.get('num_points', len(r.get('points', []))),
            'floor_id': r.get('floor_id'),
            'bbox': r.get('bbox', {
                'min': r['points'].min(axis=0).tolist() if len(r.get('points', [])) > 0 else [0,0,0],
                'max': r['points'].max(axis=0).tolist() if len(r.get('points', [])) > 0 else [0,0,0]
            })
        }
        for i, r in enumerate(rooms)
    ]
    
    # 房间连接关系 (基于空间邻接)
    connections = []
    if len(rooms) > 1:
        for i, room in enumerate(rooms):
            for j, other_room in enumerate(rooms):
                if i >= j:
                    continue
                # 检查房间是否相邻 (中心距离 < 阈值)
                dist = np.linalg.norm(room['center'][[0, 2]] - other_room['center'][[0, 2]])
                if dist < 3.0:  # 3 米内认为相邻
                    connections.append({
                        'from': i,
                        'to': j,
                        'distance': float(dist)
                    })
    
    scene_graph['connections'] = connections
    
    # 物体统计
    object_counts = defaultdict(int)
    for obj in objects:
        object_counts[obj['category']] += 1

    scene_graph['objects_summary'] = dict(object_counts)
    scene_graph['num_objects'] = len(objects)

    room_records = scene_graph['rooms']
    floor_records = scene_graph['floors']
    room_floor_lookup = {
        room['id']: room.get('floor_id', _infer_floor_id_for_room(room, floor_records))
        for room in room_records
    }

    object_records = []
    for i, obj in enumerate(objects):
        center = obj['points'].mean(axis=0).tolist()
        room_id = obj.get('room_id')
        if room_id is None:
            room_id = _infer_room_id_for_center(center, room_records)

        floor_id = obj.get('floor_id')
        if floor_id is None and room_id is not None:
            floor_id = room_floor_lookup.get(room_id)
        if floor_id is None:
            floor_id = _infer_floor_id_for_center(center, floor_records)

        source_frames = [str(frame) for frame in obj.get('source_frames', []) if frame]
        source_images = [str(path) for path in obj.get('source_images', []) if path]
        source_views = merge_source_views([obj], limit=OBJECT_SOURCE_VIEW_LIMIT)
        representative_source_view = source_views[0] if source_views else None

        object_records.append(
            {
                'id': i,
                'name': obj.get('name', f"{obj['category']}_{obj.get('id', 0)}"),
                'category': obj['category'],
                'instance_id': obj.get('id', 0),
                'center': center,
                'num_points': len(obj['points']),
                'num_frames': obj.get('num_frames', 1),
                'room_id': room_id,
                'floor_id': floor_id,
                'representative_frame': obj.get('representative_frame'),
                'representative_image': obj.get('representative_image'),
                'reprojected_view_count': int(obj.get('reprojected_view_count', 0)),
                'representative_source_view': representative_source_view,
                'source_frames': source_frames[:OBJECT_SOURCE_VIEW_LIMIT],
                'source_images': source_images[:OBJECT_SOURCE_VIEW_LIMIT],
                'source_views': source_views,
                'bbox': {
                    'min': obj['points'].min(axis=0).tolist(),
                    'max': obj['points'].max(axis=0).tolist()
                }
            }
        )

    for obj in object_records:
        nearby_objects = _summarize_nearby_objects(object_records, obj['center'], exclude_id=obj['id'])
        obj['nearby_objects'] = nearby_objects
        obj['environment_context'] = {
            'region_id': obj.get('room_id'),
            'floor_id': obj.get('floor_id'),
            'nearby_objects': nearby_objects,
            'grounded_view_count': len(obj.get('source_views', []) or []),
            'reprojected_view_count': int(obj.get('reprojected_view_count', 0)),
        }

    region_summaries = []
    for room in room_records:
        room_id = room['id']
        room_objects = [obj for obj in object_records if obj.get('room_id') == room_id]
        category_counts = Counter(obj['category'] for obj in room_objects if obj.get('category'))
        region_summaries.append(
            {
                'region_id': room_id,
                'floor_id': room.get('floor_id', room_floor_lookup.get(room_id)),
                'num_objects': len(room_objects),
                'object_counts': dict(category_counts),
                'top_categories': [
                    {'category': category, 'count': int(count)}
                    for category, count in category_counts.most_common(5)
                ],
            }
        )

    scene_graph['region_summaries'] = region_summaries
    scene_graph['objects'] = object_records

    return scene_graph


def save_point_cloud(filename, points, colors):
    """保存点云为 PLY"""
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points.astype(np.float64))
    pcd.colors = o3d.utility.Vector3dVector(colors.astype(np.float64) / 255.0)
    o3d.io.write_point_cloud(str(filename), pcd, write_ascii=False, compressed=True)


def dbscan_filter_point_cloud(points, colors, eps=DBSCAN_EPS, min_points=DBSCAN_MIN_POINTS, label="pointcloud"):
    """Run DBSCAN and keep the largest non-noise cluster."""
    stats = {
        "label": label,
        "before": int(len(points)),
        "after": int(len(points)),
        "removed": 0,
        "kept_cluster_label": None,
    }
    if len(points) == 0:
        return points, colors, stats

    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    pcd.colors = o3d.utility.Vector3dVector(colors) if len(colors) == len(points) else None

    labels = np.array(pcd.cluster_dbscan(eps=eps, min_points=min_points, print_progress=False))
    valid_labels = labels[labels >= 0]
    if len(valid_labels) == 0:
        return points, colors, stats

    cluster_sizes = np.bincount(valid_labels)
    max_cluster = int(np.argmax(cluster_sizes))
    inlier_mask = labels == max_cluster
    filtered_points = points[inlier_mask]
    filtered_colors = colors[inlier_mask]

    stats.update({
        "after": int(len(filtered_points)),
        "removed": int(len(points) - len(filtered_points)),
        "kept_cluster_label": max_cluster,
    })
    return filtered_points, filtered_colors, stats


def main():
    print("=" * 70)
    print("统一 3D 场景重建 + 物体分割 + 拓扑图生成")
    print("(单趟遍历同时完成全局点云和物体分割)")
    print("=" * 70)

    # 输出目录
    OUTPUT_DIR.mkdir(exist_ok=True, parents=True)
    (OUTPUT_DIR / 'global').mkdir(exist_ok=True)
    (OUTPUT_DIR / 'objects').mkdir(exist_ok=True)

    # 检查服务
    print("\n[0] 检查服务连接...")
    services_ok = True
    vlm_ok = False

    try:
        test_payload = {
            "model": cfg.models.vlm_model_legacy,
            "messages": [{"role": "user", "content": [{"type": "text", "text": "test"}]}],
            "max_tokens": 10
        }
        response = requests.post(VLM_API_URL, json=test_payload, timeout=5)
        if response.status_code == 200:
            print("  ✓ VLM API (物体检测)")
            vlm_ok = True
        else:
            print(f"  ✗ VLM API (状态码：{response.status_code})")
    except Exception as e:
        print(f"  ✗ VLM API ({str(e)[:50]})")

    try:
        r = requests.get("http://localhost:20023/health", timeout=5)
        if r.status_code == 200:
            print("  ✓ SAM 3.1")
        else:
            print("  ✗ SAM 3.1")
            services_ok = False
    except:
        print("  ✗ SAM 3.1")
        services_ok = False

    if not services_ok:
        print("\n警告：部分服务不可用，将跳过对应功能")
    
    adapter.print_info()

    # 加载数据
    print("\n[1] 加载数据...")
    K = adapter.K

    odom_cam_file = adapter.data_dir / "odom_matched_camera.txt"
    if odom_cam_file.exists():
        poses = load_poses_from_odom_camera(str(adapter.data_dir))
        if poses is None:
            poses = load_poses(POSES_FILE)
    else:
        poses = load_poses(POSES_FILE)

    depth_files = adapter.get_depth_file_list(max_frames=MAX_FRAMES * SKIP_FRAMES)

    # 建立深度图文件名到pose时间戳的映射 (处理文件名不匹配的情况)
    file_to_pose = adapter.build_pose_timestamp_map(poses)

    print(f"  内参：fx={K[0,0]:.1f}, fy={K[1,1]:.1f}, cx={K[0,2]:.1f}, cy={K[1,2]:.1f}")
    print(f"  位姿：{len(poses)} 个")
    print(f"  深度图：{len(depth_files)} 个")
    
    # 打印配置信息
    print(f"\n[配置]")
    print(f"  最大帧数：{MAX_FRAMES}")
    print(f"  跳帧：每 {SKIP_FRAMES} 帧处理 1 帧")
    print(f"  物体检测间隔：每 {OBJECT_DETECTION_INTERVAL} 帧检测一次")
    print(f"  检测类别：{OBJECT_CATEGORIES}")
    print(f"  合并类别：{MERGE_CATEGORIES}")
    if CONFIDENCE_THRESHOLD > 0:
        print(f"  置信度过滤：≥ {CONFIDENCE_THRESHOLD}")
    else:
        print(f"  置信度过滤：关闭")
    if FUSION_ENABLED:
        print(
            "  点云融合：稀疏体素融合 "
            f"(min_hits={FUSION_CONFIG.get('min_hits', 2)}, "
            f"min_span={FUSION_CONFIG.get('min_observation_span', 0)}, "
            f"min_baseline={FUSION_CONFIG.get('min_view_baseline_m', 0.0)}, "
            f"free_space={FUSION_CONFIG.get('free_space_carving', True)}, "
            f"ray_stride={FUSION_CONFIG.get('ray_stride', 8)})"
        )
    else:
        print("  点云融合：旧版追加 + 体素下采样")
    
    # ================= 全局点云 + 物体分割 =================
    print("\n" + "=" * 70)
    print("[2] 一趟遍历：同时完成全局点云累积 + 物体语义分割")
    print("=" * 70)
    
    fusion_map = None
    if FUSION_ENABLED:
        fusion_map = SparseVoxelFusion.from_config(
            FUSION_CONFIG,
            voxel_size=VOXEL_SIZE,
            depth_min=DEPTH_MIN,
            depth_max=DEPTH_MAX,
            confidence_threshold=CONFIDENCE_THRESHOLD,
        )

    all_global_points = []
    all_global_colors = []
    # 已下采样的累积点云
    merged_global_points = np.empty((0, 3), dtype=np.float32)
    merged_global_colors = np.empty((0, 3), dtype=np.uint8)
    INCREMENTAL_DS_EVERY = 50  # 每 50 帧增量式下采样

    # 物体点云容器 (按帧存储，后续合并)
    all_objects = []

    # 物体生命周期追踪器
    lifecycle_tracker = LifecycleTracker()

    # 处理计数器
    num_frames_processed = 0
    num_objects_detected = 0
    num_detection_frames = 0
    num_vlm_detections = 0

    # 跨帧类别上下文：记录已发现的类别，用于 VLM prompt 注入
    # 预置常见类别，让 VLM 在早期帧就能检测到这些物体
    discovered_categories = {
        'plant': 1, 'chair': 1, 'desk': 1, 'table': 1,
        'wall': 1, 'floor': 1, 'door': 1, 'window': 1,
        'cabinet': 1, 'sofa': 1, 'bed': 1, 'tv': 1,
    }  # canonical_name → count (初始权重 1)

    # 历史检测帧缩略图缓冲：供 VLM 参考 (file_path, base64)
    detection_history_images = []  # [(file_path, base64), ...]
    VLM_MAX_HISTORY = 3  # VLM 最多参考的历史帧数
    VLM_HISTORY_THUMB_SIZE = (512, 384)  # 历史帧缩略图尺寸

    for i, depth_file in enumerate(tqdm(depth_files, desc="处理帧")):
        # 两种任务独立调度：点云每 SKIP_FRAMES 帧，VLM 每 OBJECT_DETECTION_INTERVAL 帧
        process_pointcloud = (i % SKIP_FRAMES == 0)
        detect_objects = (i % OBJECT_DETECTION_INTERVAL == 0)

        if not process_pointcloud and not detect_objects:
            continue

        # 使用映射获取对应的时间戳
        timestamp_str = depth_file.stem
        if timestamp_str not in file_to_pose:
            continue
        pose_timestamp = file_to_pose[timestamp_str]

        if pose_timestamp not in poses:
            continue

        # 读取深度图 (da3_ezviz: 原生分辨率; standard: 上采样到 RGB)
        depth = adapter.load_depth(depth_file, target_resolution=adapter.rgb_resolution)
        if depth is None:
            continue

        # 深度图单位转换 (毫米 -> 米)
        if depth.dtype == np.uint16:
            depth = depth.astype(np.float32) / DEPTH_SCALE
        elif depth.dtype == np.uint8:
            depth = depth.astype(np.float32)

        # 无效值 (inf/NaN) 统一置 0, 避免下游算术触发 RuntimeWarning
        depth = np.where(np.isfinite(depth), depth, 0.0).astype(np.float32)

        # 读取彩色图 (适配器自动缩放到工作分辨率)
        color_file = adapter.match_color_file(timestamp_str)
        if color_file is None:
            continue

        color = adapter.load_color(color_file)
        if color is None:
            continue

        # 确保尺寸一致 (安全校验)
        if color.shape[:2] != depth.shape:
            color = cv2.resize(color, (depth.shape[1], depth.shape[0]))

        # 加载置信度图 (da3_ezviz: 已在深度分辨率, 无需缩放)
        confidence = None
        if CONFIDENCE_THRESHOLD > 0:
            confidence = adapter.load_confidence(i)

        T_c2w = poses[pose_timestamp]

        # 使用逐帧内参 (如果有), 否则使用全局 K
        K_frame = adapter.get_K_for_frame(i)

        # ========== 任务 1: 生成全局点云 ==========
        if process_pointcloud:
            if FUSION_ENABLED:
                fusion_map.integrate(
                    depth,
                    color,
                    K_frame,
                    T_c2w,
                    confidence=confidence,
                    frame_id=timestamp_str,
                )
            else:
                points_global, colors_global = depth_to_pointcloud(
                    depth, color, K_frame, T_c2w, confidence, CONFIDENCE_THRESHOLD
                )

                if len(points_global) > 0:
                    all_global_points.append(points_global)
                    all_global_colors.append(colors_global)

                # 增量式下采样: 每 N 帧合并+体素下采样, 控制内存
                if len(all_global_points) >= INCREMENTAL_DS_EVERY:
                    batch_pts = np.vstack(all_global_points)
                    batch_cols = np.vstack(all_global_colors)
                    if len(merged_global_points) > 0:
                        batch_pts = np.vstack([merged_global_points, batch_pts])
                        batch_cols = np.vstack([merged_global_colors, batch_cols])
                    merged_global_points, merged_global_colors = voxel_downsample(batch_pts, batch_cols, VOXEL_SIZE)
                    all_global_points = []
                    all_global_colors = []

        # ========== 任务 2: VLM 物体检测 + GroundingDINO + SAM2 分割 ==========
        if detect_objects and services_ok:
            num_detection_frames += 1

            # Step 1: VLM 检测物体类别（传入历史帧 + 已发现类别）
            if vlm_ok:
                # 将当前帧缩略图加入历史缓冲
                _thumb = cv2.resize(color, VLM_HISTORY_THUMB_SIZE, interpolation=cv2.INTER_AREA)
                _, _thumb_buf = cv2.imencode('.jpg', _thumb, [cv2.IMWRITE_JPEG_QUALITY, 80])
                _thumb_b64 = base64.b64encode(_thumb_buf.tobytes()).decode('utf-8')
                detection_history_images.append((str(color_file), _thumb_b64))
                # 限制历史帧数量（保留最近的 N 帧）
                if len(detection_history_images) > VLM_MAX_HISTORY:
                    detection_history_images = detection_history_images[-VLM_MAX_HISTORY:]

                # 历史帧不包含当前帧本身，所以传入 history[:-1]
                history_for_vlm = detection_history_images[:-1] if len(detection_history_images) > 1 else None

                detected_objects = vlm_detect_objects(
                    color_file, discovered_categories, history_images=history_for_vlm,
                )
                num_vlm_detections += 1
                # 更新已发现类别统计
                for obj in detected_objects:
                    cat = obj['category']
                    discovered_categories[cat] = discovered_categories.get(cat, 0) + 1
                # 提取类别列表 (去重)
                categories_to_detect = list(set([obj['category'] for obj in detected_objects]))

                # 强制加入 floor（VLM 通常不把地板当"物体"，但房间分割需要）
                if 'floor' not in categories_to_detect:
                    categories_to_detect.append('floor')
                    detected_objects.append({'category': 'floor'})
            else:
                # VLM 不可用，使用固定类别
                categories_to_detect = OBJECT_CATEGORIES
                detected_objects = [{'category': cat} for cat in categories_to_detect]

            # Step 2: 收集当前帧应可见的历史物体类别（补充 VLM 可能漏检的物体）
            expected_categories = set()
            if len(all_objects) > 0:
                T_w2c = np.linalg.inv(T_c2w)
                fx, fy = K_frame[0, 0], K_frame[1, 1]
                cx, cy = K_frame[0, 2], K_frame[1, 2]
                h, w = depth.shape[:2]

                for hist_obj in all_objects:
                    pts = hist_obj['points']
                    if len(pts) == 0:
                        continue
                    cat = hist_obj.get('category', '')
                    if cat in {'floor', 'wall', 'ceiling'}:
                        continue

                    # 快速反投影判断是否在当前帧可见
                    pts_hom = np.hstack([pts, np.ones((len(pts), 1))])
                    pts_cam = (T_w2c @ pts_hom.T).T[:, :3]
                    in_front = pts_cam[:, 2] > 0.1
                    pts_in_front = pts_cam[in_front]
                    if len(pts_in_front) == 0:
                        continue
                    z = pts_in_front[:, 2]
                    u = (pts_in_front[:, 0] * fx / z + cx).astype(np.int32)
                    v = (pts_in_front[:, 1] * fy / z + cy).astype(np.int32)
                    in_image = (u >= 0) & (u < w) & (v >= 0) & (v < h)
                    visible_ratio = float(np.sum(in_image)) / len(pts)

                    if visible_ratio >= 0.20:  # 至少 20% 点云可见
                        expected_categories.add(cat)

            # Step 3: 批量 SAM 3.1 分割 (图像编码一次，多个 prompt 复用)
            batch_prompts = []
            vlm_categories = set()
            for obj_info in detected_objects:
                category = obj_info['category']
                sam3_text = obj_info.get('sam3_prompt', category)
                batch_prompts.append((category, sam3_text))
                vlm_categories.add(category)

            # 添加 VLM 未检测但预期可见的历史物体类别
            for cat in expected_categories:
                if cat not in vlm_categories:
                    batch_prompts.append((cat, cat))
                    print(f"          + 补充历史物体类别：{cat}")

            batch_results = sam3_segment_batch(color_file, batch_prompts)

            # 预计算图片尺寸比例 (所有类别共用)
            orig_h, orig_w = color.shape[:2]
            _orig_sample = cv2.imread(str(color_file))
            _sam3_orig_h, _sam3_orig_w = (_orig_sample.shape[:2]) if _orig_sample is not None else (orig_h, orig_w)
            _need_resize = (_sam3_orig_h != orig_h or _sam3_orig_w != orig_w)
            _sx, _sy = (orig_w / _sam3_orig_w, orig_h / _sam3_orig_h) if _need_resize else (1.0, 1.0)

            # 收集当前帧检测信息（用于可视化）
            current_frame_detections = []
            for (category, sam3_text), detections in zip(batch_prompts, [batch_results.get(t, []) for _, t in batch_prompts]):
                if not detections:
                    continue
                for _det in detections:
                    current_frame_detections.append({
                        'mask': _det.get('mask'),
                        'category': category,
                        'score': _det.get('score', 0),
                    })

            # ========== 可见性对照可视化（此时 all_objects 只含历史物体）==========
            if VIS_VIZ_ENABLED and detect_objects:
                _viz_dir = OUTPUT_DIR / "visibility_viz"
                _color_bgr = cv2.cvtColor(color, cv2.COLOR_RGB2BGR)
                # 轻量合并：同类物体重心距离 < 阈值视为同一物体，减少冗余重投影
                _merged_objects = merge_similar_objects(
                    all_objects,
                    centroid_distance=_VIS_VIZ_CFG['merge_centroid_distance'],
                )
                # 记录轻量合并组（用于生命周期追踪）
                _merge_groups = [obj.get('_merged_from', [i]) for i, obj in enumerate(_merged_objects)]
                lifecycle_tracker.record_merge_groups(timestamp_str, _merge_groups)
                _viz_path, _num_visible, _vis_records = visualize_visibility(
                    color_bgr=_color_bgr,
                    K=K_frame,
                    T_c2w=T_c2w,
                    depth=depth,
                    all_objects=_merged_objects,
                    current_detections=current_frame_detections,
                    frame_id=timestamp_str,
                    output_dir=_viz_dir,
                    point_size=_VIS_VIZ_CFG['point_size'],
                    mask_alpha=_VIS_VIZ_CFG['mask_alpha'],
                    max_points_per_obj=_VIS_VIZ_CFG['max_points_per_obj'],
                    max_distance=_VIS_VIZ_CFG['max_distance'],
                )
                print(f"      📊 可见性可视化：{_viz_path.name} "
                      f"(可见={_num_visible}/{len(_merged_objects)}"
                      f"{'，合并前=' + str(len(all_objects)) if len(_merged_objects) < len(all_objects) else ''}"
                      f", 检测={len(current_frame_detections)})")

                # ---- 物体状态检测与生命周期更新 ----
                _visible_merged_indices = set()
                for _vr in _vis_records:
                    _visible_merged_indices.add(_vr['obj_idx'])

                # 过滤结构性类别（floor/wall/ceiling），不参与状态检测和生命周期维护
                _STRUCTURAL_CATS = frozenset({'floor', 'wall', 'ceiling'})
                _non_structural_objects = [
                    obj for obj in _merged_objects
                    if obj.get('category', '') not in _STRUCTURAL_CATS
                ]
                # 建立原索引 → 新索引的映射（仅非结构性物体）
                _orig_to_ns = {}
                for _ns_idx, _obj in enumerate(_non_structural_objects):
                    _orig_idx = _obj.get('_merged_from', [_ns_idx])[0]
                    _orig_to_ns[_orig_idx] = _ns_idx

                if _VIS_VIZ_CFG.get('state_detection_enabled', False):
                    _T_w2c = np.linalg.inv(T_c2w)
                    _state_results = detect_object_states(
                        merged_objects=_non_structural_objects,
                        K=K_frame,
                        T_w2c=_T_w2c,
                        depth_map=depth,
                        max_distance=_VIS_VIZ_CFG['max_distance'],
                        depth_tolerance=_VIS_VIZ_CFG['depth_tolerance'],
                        min_valid_samples=_VIS_VIZ_CFG['min_valid_samples'],
                        persist_ratio=_VIS_VIZ_CFG['persist_ratio_threshold'],
                    )
                    _death_threshold = _VIS_VIZ_CFG['miss_death_threshold']
                    _state_by_idx = {sf['obj_idx']: sf for sf in _state_results}

                    # 只对通过可见性过滤的非结构性物体更新生命周期
                    for _mi in _visible_merged_indices:
                        if _mi >= len(_merged_objects):
                            continue
                        _mobj = _merged_objects[_mi]
                        if _mobj.get('category', '') in _STRUCTURAL_CATS:
                            continue
                        _ns_idx = _orig_to_ns.get(_mi)
                        if _ns_idx is None:
                            continue
                        _constituents = _mobj.get('_merged_from', [_mi])
                        _sf = _state_by_idx.get(_ns_idx)
                        _state_val = _sf['state'].value if _sf else 'disappeared'

                        if _state_val == 'persisting':
                            # 持续存在：更新观测，重置 miss_count
                            _centroid = _mobj['points'].mean(axis=0).tolist()
                            for _orig_idx in _constituents:
                                lifecycle_tracker.update_observation(
                                    obj_id=_orig_idx,
                                    frame_id=timestamp_str,
                                    centroid=_centroid,
                                    point_count=len(_mobj['points']),
                                    state='persisting',
                                )
                        else:
                            # 遮挡或消失：累加 miss count
                            for _orig_idx in _constituents:
                                lifecycle_tracker.increment_miss_count(
                                    obj_id=_orig_idx,
                                    frame_id=timestamp_str,
                                    state=_state_val,
                                    death_threshold=_death_threshold,
                                )

                    # 统计打印（仅非结构性物体）
                    _n_persist = sum(1 for sf in _state_results if sf['state'].value == 'persisting')
                    _n_occl = sum(1 for sf in _state_results if sf['state'].value == 'occluded')
                    _n_disp = sum(1 for sf in _state_results if sf['state'].value == 'disappeared')
                    print(f"       状态检测（非结构物体）：持续={_n_persist} 遮挡={_n_occl} 消失={_n_disp} / 总={len(_state_results)}")
                else:
                    # 状态检测未启用，回退到简单观测更新
                    for _vr in _vis_records:
                        _merged_src = _vr.get('merged_from', [_vr['obj_idx']])
                        for _orig_idx in _merged_src:
                            lifecycle_tracker.update_observation(
                                obj_id=_orig_idx,
                                frame_id=timestamp_str,
                                centroid=_vr.get('centroid_3d'),
                                point_count=_vr.get('point_count', 0),
                            )

            # 可视化完成后再将当前帧物体添加到历史集合
            for (category, sam3_text), detections in zip(batch_prompts, [batch_results.get(t, []) for _, t in batch_prompts]):
                if not detections:
                    continue

                for mask_data in detections:
                    points_3d = mask_to_3d_points(mask_data['mask'], depth, K_frame, T_c2w, confidence, CONFIDENCE_THRESHOLD)

                    if len(points_3d) > OBJECT_MIN_POINTS:
                        object_center = points_3d.mean(axis=0)

                        grounded_box = mask_data.get('box')
                        grounded_mask = mask_data.get('mask')
                        if _need_resize:
                            if grounded_box is not None:
                                grounded_box = [
                                    int(grounded_box[0] * _sx),
                                    int(grounded_box[1] * _sy),
                                    int(grounded_box[2] * _sx),
                                    int(grounded_box[3] * _sy),
                                ]
                            if grounded_mask is not None:
                                grounded_mask = cv2.resize(
                                    grounded_mask.astype(np.float32),
                                    (orig_w, orig_h),
                                    interpolation=cv2.INTER_NEAREST,
                                ).astype(np.uint8)

                        grounded_view = create_object_grounded_views(
                            image_path=color_file,
                            image_rgb=color,
                            frame=timestamp_str,
                            category=category,
                            object_index=len(all_objects),
                            box=grounded_box,
                            mask=grounded_mask,
                            score=mask_data.get('score'),
                        )

                        all_objects.append({
                            'category': category,
                            'points': points_3d,
                            'frame': timestamp_str,
                            'image_path': str(color_file),
                            'center': object_center,
                            'T_c2w': T_c2w.copy(),
                            'source_views': [grounded_view] if grounded_view else [],
                            '_centroid': object_center.copy(),
                            '_point_count': len(points_3d),
                        })
                        # 注册新物体到生命周期追踪器
                        _new_obj_idx = len(all_objects) - 1
                        lifecycle_tracker.register_object(
                            obj_id=_new_obj_idx,
                            category=category,
                            frame_id=timestamp_str,
                            centroid=object_center.tolist(),
                            point_count=len(points_3d),
                        )
                        num_objects_detected += 1
                        if num_objects_detected <= 5:
                            print(f"          ✓ 3D 物体：{category}, {len(points_3d)} 点，中心={object_center.round(2)}")

        num_frames_processed += 1

    print(f"\n  处理帧数：{num_frames_processed}")
    print(f"  检测帧数：{num_detection_frames} (每 {OBJECT_DETECTION_INTERVAL} 帧检测一次)")
    if vlm_ok:
        print(f"  VLM 检测次数：{num_vlm_detections}")
        if detection_history_images:
            print(f"  VLM 历史帧缓冲：{len(detection_history_images)} 帧（最多参考 {VLM_MAX_HISTORY} 帧）")
        if discovered_categories:
            sorted_cats = sorted(discovered_categories.items(), key=lambda x: -x[1])
            cat_summary = ", ".join(f"{k}({v})" for k, v in sorted_cats[:10])
            if len(sorted_cats) > 10:
                cat_summary += f"... +{len(sorted_cats)-10} more"
            print(f"  发现类别：{cat_summary}")
    print(f"  检测到物体实例：{num_objects_detected}")

    # ================= 保存物体生命周期数据 =================
    _lifecycle_dir = OUTPUT_DIR / "lifecycle"
    lifecycle_tracker.save(_lifecycle_dir)
    print(f"  生命周期数据已保存：{_lifecycle_dir}")

    # ================= 合并全局点云 =================
    stable_raw_points = None
    stable_raw_colors = None
    complete_raw_points = None
    complete_raw_colors = None
    complete_global_points = None
    complete_global_colors = None
    complete_denoised_points = None
    complete_denoised_colors = None
    fusion_stats = None
    fusion_stats_file = None
    if FUSION_ENABLED:
        assert fusion_map is not None
        global_points, global_colors = fusion_map.to_point_cloud(mode="stable")
        if FUSION_CONFIG.get("export_complete_map", True):
            complete_global_points, complete_global_colors = fusion_map.to_point_cloud(mode="complete")
        else:
            complete_global_points = np.empty((0, 3), dtype=np.float32)
            complete_global_colors = np.empty((0, 3), dtype=np.uint8)

        stable_raw_points = global_points.copy()
        stable_raw_colors = global_colors.copy()
        complete_raw_points = complete_global_points.copy()
        complete_raw_colors = complete_global_colors.copy()
        fusion_stats = fusion_map.stats()
        fusion_stats["stable_before_denoise_points"] = int(len(stable_raw_points))
        fusion_stats["complete_before_denoise_points"] = int(len(complete_raw_points))
        fusion_stats["main_output_mode"] = "stable"

        if len(global_points) == 0 and len(complete_global_points) > 0:
            print("  警告：稳定层为空，使用 complete 点云作为主输出兜底")
            global_points = complete_global_points.copy()
            global_colors = complete_global_colors.copy()
            fusion_stats["main_output_mode"] = "complete_fallback"

        fusion_stats_file = OUTPUT_DIR / "global" / "voxel_fusion_stats.json"
        fusion_stats_file.parent.mkdir(parents=True, exist_ok=True)

        if len(global_points) == 0:
            print("  错误：融合地图没有导出任何可用点云")
            with open(fusion_stats_file, "w", encoding="utf-8") as f:
                json.dump(fusion_stats, f, indent=2, ensure_ascii=False)
            print(f"  融合统计已保存：{fusion_stats_file}")
            return

        print(
            f"\n  全局点云 raw (stable): {fusion_stats['stable_before_denoise_points']:,} 点, "
            f"complete: {fusion_stats['complete_before_denoise_points']:,} 点, "
            f"main: {len(global_points):,} 点 "
            f"/ {fusion_stats['total_voxels']:,} voxels"
        )
    else:
        # 合并已增量下采样的点云 + 最后一批未下采样的点
        if all_global_points:
            batch_pts = np.vstack(all_global_points)
            batch_cols = np.vstack(all_global_colors)
            if len(merged_global_points) > 0:
                batch_pts = np.vstack([merged_global_points, batch_pts])
                batch_cols = np.vstack([merged_global_colors, batch_cols])
            merged_global_points, merged_global_colors = voxel_downsample(batch_pts, batch_cols, VOXEL_SIZE)
            all_global_points = []
            all_global_colors = []

        if len(merged_global_points) == 0:
            print("  错误：没有生成任何点云!")
            return

        global_points = merged_global_points
        global_colors = merged_global_colors
        print(f"\n  全局点云 (增量下采样后): {len(global_points):,} 点")

    print("\n  DBSCAN 去噪...")
    global_points, global_colors, stable_denoise_stats = dbscan_filter_point_cloud(
        global_points,
        global_colors,
        DBSCAN_EPS,
        DBSCAN_MIN_POINTS,
        label="main_stable",
    )
    print(
        f"  stable/main: {stable_denoise_stats['before']:,} -> "
        f"{stable_denoise_stats['after']:,} 点 "
        f"(移除 {stable_denoise_stats['removed']:,})"
    )

    if FUSION_ENABLED and complete_raw_points is not None and len(complete_raw_points) > 0:
        complete_denoised_points, complete_denoised_colors, complete_denoise_stats = dbscan_filter_point_cloud(
            complete_raw_points,
            complete_raw_colors,
            DBSCAN_EPS,
            DBSCAN_MIN_POINTS,
            label="complete",
        )
        print(
            f"  complete: {complete_denoise_stats['before']:,} -> "
            f"{complete_denoise_stats['after']:,} 点 "
            f"(移除 {complete_denoise_stats['removed']:,})"
        )
    else:
        complete_denoise_stats = None

    if FUSION_ENABLED and fusion_stats is not None:
        fusion_stats["stable_after_denoise_points"] = int(len(global_points))
        fusion_stats["stable_denoise"] = stable_denoise_stats
        if complete_denoise_stats is not None:
            fusion_stats["complete_after_denoise_points"] = int(len(complete_denoised_points))
            fusion_stats["complete_denoise"] = complete_denoise_stats
        else:
            fusion_stats["complete_after_denoise_points"] = 0
        with open(fusion_stats_file, "w", encoding="utf-8") as f:
            json.dump(fusion_stats, f, indent=2, ensure_ascii=False)
        print(f"  融合统计已保存：{fusion_stats_file}")
    
    # 全局点云将在步骤 [3] 轨迹旋转后保存 (对齐坐标系)
    global_pcd_file = OUTPUT_DIR / "global" / "global_pointcloud.ply"
    
    # ================= 合并跨帧物体 =================
    # ================= 机器人轨迹平面拟合 =================
    print("\n" + "=" * 70)
    print("[3] 机器人轨迹平面拟合 (RANSAC)")
    print("=" * 70)

    trajectory_plane_result = fit_trajectory_plane_from_poses(poses)

    if TRAJECTORY_ALIGNMENT_ENABLED:
        # 计算旋转矩阵：将轨迹平面法向量对齐到 Y 轴 [0, 1, 0]
        # 相机轨迹平行于地面 → 拟合平面法向量 = 真实"上"方向
        R_align, R_align_inv = build_trajectory_rotation_matrix(trajectory_plane_result['normal'])

        # 旋转 global_points 到对齐坐标系
        print("\n  旋转点云到轨迹对齐坐标系...")
        _normal = trajectory_plane_result['normal']
        _cos = abs(np.dot(_normal / np.linalg.norm(_normal), [0, 1, 0]))
        print(f"  法向量与 Y 轴夹角: {np.degrees(np.arccos(_cos)):.1f}°")
        global_points = (R_align @ global_points.T).T.astype(np.float32)
        if stable_raw_points is not None and len(stable_raw_points) > 0:
            stable_raw_points = (R_align @ stable_raw_points.T).T.astype(np.float32)
        if complete_raw_points is not None and len(complete_raw_points) > 0:
            complete_raw_points = (R_align @ complete_raw_points.T).T.astype(np.float32)
        if complete_denoised_points is not None and len(complete_denoised_points) > 0:
            complete_denoised_points = (R_align @ complete_denoised_points.T).T.astype(np.float32)

        # 检查 Y 轴方向：如果大部分点在负 Y，说明 Y 轴指向下方，需要翻转
        y_median = np.median(global_points[:, VERTICAL_AXIS])
        if y_median < 0:
            print(f"  Y 中位数：{y_median:.2f} m < 0，翻转 Y 轴")
            global_points[:, VERTICAL_AXIS] = -global_points[:, VERTICAL_AXIS]
            if stable_raw_points is not None and len(stable_raw_points) > 0:
                stable_raw_points[:, VERTICAL_AXIS] = -stable_raw_points[:, VERTICAL_AXIS]
            if complete_raw_points is not None and len(complete_raw_points) > 0:
                complete_raw_points[:, VERTICAL_AXIS] = -complete_raw_points[:, VERTICAL_AXIS]
            if complete_denoised_points is not None and len(complete_denoised_points) > 0:
                complete_denoised_points[:, VERTICAL_AXIS] = -complete_denoised_points[:, VERTICAL_AXIS]
            # 更新 R_align_inv 以包含翻转
            R_align_inv = np.diag([1.0, -1.0, 1.0]) @ R_align_inv

        # 旋转 poses 到对齐坐标系
        R_align_4x4 = np.eye(4)
        R_align_4x4[:3, :3] = R_align
        for ts in poses:
            poses[ts] = R_align_4x4 @ poses[ts]

        # 旋转物体点云到对齐坐标系
        for obj in all_objects:
            obj['points'] = (R_align @ obj['points'].T).T
            obj['center'] = (R_align @ obj['center'])
        print(f"  ✓ 已旋转 {len(global_points):,} 个点 + {len(poses)} 个位姿 + {len(all_objects)} 个物体实例")
    else:
        # 轨迹对齐禁用：保持原始里程计坐标系
        R_align = np.eye(3)
        R_align_inv = np.eye(3)
        print("\n  轨迹平面对齐已禁用，保持原始里程计坐标系")
        print(f"  VERTICAL_AXIS={VERTICAL_AXIS} (Z-up), HORIZONTAL_AXES={HORIZONTAL_AXES}")

    # 保存全局点云
    save_point_cloud(global_pcd_file, global_points, global_colors)
    print(f"  ✓ 已保存全局点云: {global_pcd_file}")
    if FUSION_ENABLED and stable_raw_points is not None and len(stable_raw_points) > 0:
        stable_raw_file = OUTPUT_DIR / "global" / "global_pointcloud_stable_raw.ply"
        save_point_cloud(stable_raw_file, stable_raw_points, stable_raw_colors)
        print(f"  ✓ 已保存 stable raw 点云: {stable_raw_file}")
    if FUSION_ENABLED and complete_raw_points is not None and len(complete_raw_points) > 0:
        complete_raw_file = OUTPUT_DIR / "global" / "global_pointcloud_complete_raw.ply"
        complete_pcd_file = OUTPUT_DIR / "global" / "global_pointcloud_complete.ply"
        save_point_cloud(complete_raw_file, complete_raw_points, complete_raw_colors)
        if complete_denoised_points is not None and len(complete_denoised_points) > 0:
            save_point_cloud(complete_pcd_file, complete_denoised_points, complete_denoised_colors)
        else:
            save_point_cloud(complete_pcd_file, complete_raw_points, complete_raw_colors)
        print(f"  ✓ 已保存 complete raw/denoised 点云: {complete_raw_file}, {complete_pcd_file}")

    # ================= 体素稳定性过滤 =================

    def filter_objects_by_voxel_stability(fusion_map, objects, min_stable_ratio=None, R_inv=None):
        """用体素融合状态过滤物体：物体点云中有多少比例落在稳定体素上。"""
        if min_stable_ratio is None:
            min_stable_ratio = OBJECT_LIFECYCLE_CONFIG.get('min_stable_ratio', 0.25)

        soa = fusion_map._soa
        n_voxels = soa.n
        vs = fusion_map.voxel_size

        all_keys = soa.keys[:n_voxels]
        stable_mask = soa.is_stable[:n_voxels]

        # 用 np.unique 去重后转 tuple（去重后数量大幅减少，速度可接受）
        def _keys_to_set(keys):
            if len(keys) == 0:
                return set()
            unique = np.unique(keys, axis=0)
            return {tuple(k) for k in unique}

        stable_keys_set = _keys_to_set(all_keys[stable_mask])
        all_keys_set = _keys_to_set(all_keys)

        filtered = []
        filtered_out = []
        for obj in objects:
            pts = obj['points']
            if len(pts) == 0:
                filtered_out.append((obj, "空点云"))
                continue

            if R_inv is not None:
                pts_for_lookup = (R_inv @ pts.T).T
            else:
                pts_for_lookup = pts

            keys = np.floor(pts_for_lookup / vs).astype(np.int64)
            unique_keys = np.unique(keys, axis=0)
            unique_set = _keys_to_set(unique_keys)

            stable_count = len(unique_set & stable_keys_set)
            observed_count = len(unique_set & all_keys_set)

            stable_ratio = stable_count / len(unique_keys)
            observed_ratio = observed_count / len(unique_keys)

            if stable_ratio >= min_stable_ratio:
                obj['voxel_stable_ratio'] = round(stable_ratio, 3)
                obj['voxel_observed_ratio'] = round(observed_ratio, 3)
                filtered.append(obj)
            else:
                filtered_out.append((obj, f"stable_ratio={stable_ratio:.1%}, observed_ratio={observed_ratio:.1%}"))

        return filtered, filtered_out

    # ================= 跨帧物体合并 + 同类物体编号 =================
    print("\n" + "=" * 70)
    print("[4] 跨帧物体合并 + 同类物体编号 (点云 IoU + 多轮迭代)")
    print("=" * 70)

    # ================= 分离背景与前景物体 =================
    bg_objects = [obj for obj in all_objects if obj['category'] in MERGE_CATEGORIES]
    fg_objects = [obj for obj in all_objects if obj['category'] not in MERGE_CATEGORIES]

    # 仅对前景物体执行迭代合并（去重/防过合并）
    merged_fg_objects = iterative_merge_objects(fg_objects, max_rounds=4)
    print(f"  前景物体迭代合并：{len(fg_objects)} → {len(merged_fg_objects)} 个")

    final_objects = []

    # 处理背景类别 (wall/floor) -> 每类强制合并为 1 个实例
    for category in MERGE_CATEGORIES:
        category_bg = [obj for obj in bg_objects if obj['category'] == category]
        if category_bg:
            all_pts = np.vstack([obj['points'] for obj in category_bg])
            source_views = merge_source_views(category_bg)
            representative_source_view = source_views[0] if source_views else None
            final_objects.append({
                'category': category,
                'points': all_pts,
                'num_frames': len(category_bg),
                'source_frames': _dedupe_ordered_strings(
                    [obj.get('frame', '') for obj in category_bg] + [view.get('frame') for view in source_views],
                    limit=OBJECT_SOURCE_VIEW_LIMIT,
                ),
                'source_images': _dedupe_ordered_strings(
                    [obj.get('image_path', '') for obj in category_bg] + [view.get('image_path') for view in source_views],
                    limit=OBJECT_SOURCE_VIEW_LIMIT,
                ),
                'source_views': source_views,
                'representative_source_view': representative_source_view,
                'representative_frame': (
                    representative_source_view.get('frame')
                    if representative_source_view
                    else next((str(obj.get('frame', '')) for obj in category_bg if obj.get('frame')), None)
                ),
                'representative_image': (
                    representative_source_view.get('image_path')
                    if representative_source_view
                    else next((str(obj.get('image_path', '')) for obj in category_bg if obj.get('image_path')), None)
                ),
                'id': 0
            })
            print(f"  合并 {category}: {len(category_bg)} → 1 (总点数：{len(all_pts):,})")

    # 处理前景物体 (非 wall/floor) -> 迭代合并结果进行编号
    category_counters = defaultdict(int)
    for obj in merged_fg_objects:
        category = obj['category']
        obj_with_id = {
            **obj,
            'id': category_counters[category],
            'name': f"{category}_{category_counters[category]}"
        }
        final_objects.append(obj_with_id)
        category_counters[category] += 1

    for obj in final_objects:
        if 'name' not in obj:
            obj['name'] = f"{obj['category']}_{obj['id']}"

    # ================= 过滤 floor 以下的噪声点云 =================
    # 删除floor下方噪声点云
    print("\n" + "=" * 70)
    print("[4.5] 过滤 floor 以下的噪声点云")
    print("=" * 70)

    floor_zero_level = None

    floor_objects = [obj for obj in final_objects if obj.get('category') == 'floor']

    if floor_objects:
        # 合并所有 floor 物体点云，确定地板位置
        all_floor_pts = np.vstack([obj['points'] for obj in floor_objects])

        # 地板位置 = floor 点云的最低垂直轴值
        floor_zero_level = float(all_floor_pts[:, VERTICAL_AXIS].min())
        print(f"  Floor 物体：{len(floor_objects)} 个, {len(all_floor_pts):,} 点")
        print(f"  地板位置：{floor_zero_level:.2f} m")

        # 过滤全局点云：删除 floor 以下的点
        above_floor_mask = global_points[:, VERTICAL_AXIS] >= floor_zero_level
        removed_points = (~above_floor_mask).sum()
        global_points = global_points[above_floor_mask]
        global_colors = global_colors[above_floor_mask] if len(global_colors) == len(global_points) + removed_points else global_colors[above_floor_mask]

        print(f"  删除 floor 以下点云：{removed_points:,} 点 ({removed_points/(removed_points+len(global_points))*100:.1f}%)")
        print(f"  剩余点云：{len(global_points):,} 点")

        # 过滤物体：删除中心在 floor 以下的物体
        objects_above_floor = []
        removed_objects_count = 0
        for obj in final_objects:
            obj_center_y = obj['center'][VERTICAL_AXIS] if 'center' in obj else obj['points'][:, VERTICAL_AXIS].mean()
            if obj_center_y >= floor_zero_level - 0.1:  # 留 10cm 余量
                objects_above_floor.append(obj)
            else:
                removed_objects_count += 1

        if removed_objects_count > 0:
            print(f"  删除 floor 以下物体：{removed_objects_count} 个")
            final_objects = objects_above_floor

    if floor_zero_level is None:
        print("  未找到 floor 物体，跳过过滤")

    # ================= 体素稳定性验证 =================
    if FUSION_ENABLED and fusion_map is not None:
        print("\n" + "=" * 70)
        print("[5] 体素稳定性验证：用融合状态过滤瞬态伪影物体")
        print("=" * 70)
        print(f"  融合体素记录数：{len(fusion_map.records):,}")
        print(f"  体素大小：{fusion_map.voxel_size:.3f}m")
        print(f"  过滤阈值：stable_ratio >= {OBJECT_LIFECYCLE_CONFIG.get('min_stable_ratio', 0.25)}")

        stable_objects, removed_objects = filter_objects_by_voxel_stability(
            fusion_map, final_objects, R_inv=R_align_inv
        )

        for obj, reason in removed_objects:
            print(f"  ✗ 过滤 {obj.get('name', 'unknown')} ({obj['category']}): {reason}")

        if removed_objects:
            print(f"\n  过滤结果：{len(final_objects)} → {len(stable_objects)} 个物体（移除 {len(removed_objects)} 个瞬态伪影）")
            final_objects = stable_objects
        else:
            print(f"\n  全部物体通过稳定性验证：{len(final_objects)} 个")

    print(f"  最终物体数：{len(final_objects)}")

    print("\n  物体列表:")
    for i, obj in enumerate(final_objects):
        print(f"    [{i:03d}] {obj['name']}: {len(obj['points']):,} 点 (帧数：{obj.get('num_frames', 1)})")

    for i, obj in enumerate(final_objects):
        colors = np.tile([128, 128, 128], (len(obj['points']), 1))
        obj_file = OUTPUT_DIR / "objects" / f"object_{i:04d}_{obj['name']}.ply"
        save_point_cloud(obj_file, obj['points'], colors)

        # 保存物体多帧视图
        obj_view_dir = OBJECT_VIEW_OUTPUT_DIR / obj['name']
        obj_view_dir.mkdir(parents=True, exist_ok=True)

        saved_view_indices = set()
        for view_idx, source_view in enumerate(obj.get('source_views', [])):
            if not isinstance(source_view, dict):
                continue
            annotated_path = source_view.get('annotated_image')
            if not annotated_path or not Path(annotated_path).exists():
                continue

            # 避免重复保存同一帧
            frame_key = source_view.get('frame', f'view_{view_idx}')
            if frame_key in saved_view_indices:
                continue
            saved_view_indices.add(frame_key)

            src = Path(annotated_path)
            # 命名：annotated_{frame_stem}.png
            frame_stem = src.stem  # 通常是 annotated 或原始帧名
            dest_name = f"annotated_{frame_stem}_{view_idx:03d}.png"
            dst = obj_view_dir / dest_name
            import shutil
            shutil.copy2(src, dst)

    obj_counts = defaultdict(int)
    for obj in final_objects:
        obj_counts[obj['category']] += 1

    print("\n  物体统计:")
    for cat, count in sorted(obj_counts.items()):
        print(f"    {cat}: {count} 个")

    # ================= 楼层分割 =================
    print("\n" + "=" * 70)
    print("[5] 楼层分割 (使用 floor 物体点云)")
    print("=" * 70)

    # 尝试从物体点云中加载 floor
    floor_object_files = list(OUTPUT_DIR.glob("objects/object_*_floor_*.ply"))

    if floor_object_files:
        print(f"  找到 {len(floor_object_files)} 个 floor 物体点云")

        # 合并所有 floor 物体点云
        floor_pcds = []
        for f in floor_object_files:
            pcd = o3d.io.read_point_cloud(str(f))
            if len(pcd.points) > 0:
                floor_pcds.append(pcd)

        if floor_pcds:
            # 合并 + 体素下采样 0.02m
            combined_floor = floor_pcds[0]
            for pcd in floor_pcds[1:]:
                combined_floor += pcd
            floor_downsampled = combined_floor.voxel_down_sample(0.02)
            floor_points = np.asarray(floor_downsampled.points)
            floor_colors = np.asarray(floor_downsampled.colors) if len(floor_downsampled.colors) == len(floor_downsampled.points) else None

            # 计算楼层参数（使用 floor 物体确定地板位置）
            floor_zero_level = float(floor_points[:, VERTICAL_AXIS].min())

            print(f"  Floor 物体：{len(floor_points):,} 点 (0.02m 体素下采样后)")
            print(f"  地板 Y 位置：{floor_zero_level:.2f} m")
            print(f"  房间分割：使用 floor 物体 + 墙面点云")

            # 房间分割使用 floor 物体 + 全局点云墙面
            scene_height = float(global_points[:, VERTICAL_AXIS].max() - floor_zero_level)
            floor_levels = [{
                'floor_zero_level': floor_zero_level,
                'room_height': scene_height,
                'points': floor_points,  # floor 物体点云
                'colors': floor_colors,
                'id': 0
            }]
        else:
            floor_levels = []
    else:
        print("  未找到 floor 物体点云，回退到高度直方图检测")
        floor_levels = segment_floors(global_points, global_colors)

    if len(floor_levels) == 0:
        print("  未检测到楼层，使用全局高度范围")
        floor_zero = global_points[:, VERTICAL_AXIS].min()
        floor_h = global_points[:, VERTICAL_AXIS].max() - floor_zero
        floor_levels = [{
            'y_min': floor_zero, 'y_max': global_points[:, VERTICAL_AXIS].max(),
            'floor_zero_level': floor_zero, 'room_height': floor_h,
            'points': global_points, 'colors': global_colors, 'id': 0
        }]

    # ================= 房间分割 =================
    print("\n" + "=" * 70)
    print("[6] 房间分割 (2D 直方图 + 形态学 + 距离变换/分水岭)")
    print("=" * 70)

    all_rooms = []
    for floor_idx, floor_data in enumerate(floor_levels):
        print(f"\n  处理 Floor {floor_idx}...")

        floor_zero_level = floor_data['floor_zero_level']
        room_height = floor_data.get('room_height')

        # 直接从全局点云按高度选取房间分割用点云（floor_zero_level 由 VLM floor 物体确定）
        height_min = floor_zero_level + 0.3
        height_max = floor_zero_level + 2.5
        sel_mask = (global_points[:, VERTICAL_AXIS] >= height_min) & \
                   (global_points[:, VERTICAL_AXIS] < height_max)
        floor_points = global_points[sel_mask]
        floor_colors = global_colors[sel_mask] if len(global_colors) == len(global_points) else None

        print(f"  房间分割点云：{len(floor_points):,} 点 (全局点云, 高度 {height_min:.1f}~{height_max:.1f}m)")

        # 加载 VLM floor 和 wall 物体（与单独运行 segment_rooms.py 保持一致）
        import glob as glob_mod
        objects_dir = OUTPUT_DIR / "objects"
        
        # 加载 VLM floor
        floor_ply = objects_dir / "object_0001_floor_0.ply"
        if floor_ply.exists():
            floor_pcd = o3d.io.read_point_cloud(str(floor_ply))
            floor_pcd_ds = floor_pcd.voxel_down_sample(0.02)
            floor_points = np.asarray(floor_pcd_ds.points)
            floor_colors = np.asarray(floor_pcd_ds.colors) if len(floor_pcd_ds.colors) == len(floor_points) else None
            print(f"  加载 VLM Floor: {len(floor_points):,} 点")
        else:
            print(f"  警告：未找到 VLM floor，使用全局点云高度过滤")
        
        # 加载 VLM wall
        wall_ply = objects_dir / "object_0000_wall_0.ply"
        if wall_ply.exists():
            wall_pcd = o3d.io.read_point_cloud(str(wall_ply))
            wall_pcd_ds = wall_pcd.voxel_down_sample(0.02)
            wall_points = np.asarray(wall_pcd_ds.points)
            wall_colors = np.asarray(wall_pcd_ds.colors) if len(wall_pcd_ds.colors) == len(wall_points) else None
            print(f"  加载 VLM Wall: {len(wall_points):,} 点")
        else:
            wall_points = None
            wall_colors = None
            print(f"  警告：未找到 VLM wall")
        
        # 合并 floor + wall
        if wall_points is not None:
            combined_points = np.vstack([floor_points, wall_points])
            if floor_colors is not None and wall_colors is not None:
                combined_colors = np.vstack([floor_colors, wall_colors])
            else:
                combined_colors = floor_colors
        else:
            combined_points = floor_points
            combined_colors = floor_colors
        print(f"  合并后：{len(combined_points):,} 点 (floor {len(floor_points):,} + wall {len(wall_points) if wall_points is not None else 0:,})")

        # 房间分割
        scene_height = float(global_points[:, VERTICAL_AXIS].max() - floor_zero_level)
        room_save_path = OUTPUT_DIR / "rooms" / f"floor_{floor_idx}"
        rooms = segment_rooms(combined_points, floor_zero_level, room_height=scene_height, save_path=str(room_save_path),
                             floor_colors=combined_colors,
                             vertical_axis=VERTICAL_AXIS, horizontal_axes=HORIZONTAL_AXES,
                             global_points=combined_points, global_colors=combined_colors)

        # 保存房间
        rooms_output_dir = OUTPUT_DIR / "rooms" / f"floor_{floor_idx}_rooms"
        save_rooms(rooms, str(rooms_output_dir))

        # 添加到总房间列表
        for room in rooms:
            room['floor_id'] = floor_idx
            all_rooms.append(room)

    rooms = all_rooms
    print(f"\n  总房间数：{len(rooms)}")

    for i, room in enumerate(rooms):
        print(f"    Room {i} (Floor {room.get('floor_id', 0)}): {len(room['points']):,} 点，面积 {room.get('area', 0):.1f}m², 中心={room['center'].round(2)}")

    print("\n  保持轨迹对齐坐标系 (Y=上)，后续步骤均在此坐标系下运行")

    # ================= 拟合轨迹平面 =================
    print("\n" + "=" * 70)
    print("[7] 拟合机器人行走轨迹平面")
    print("=" * 70)

    trajectory_plane = fit_trajectory_plane_from_poses(poses)

    # 从位姿生成重采样轨迹
    positions = np.array([T[:3, 3] for T in poses.values()])
    n_poses = len(positions)

    # 计算累计距离
    distances = np.zeros(n_poses)
    for i in range(1, n_poses):
        distances[i] = distances[i - 1] + np.linalg.norm(positions[i] - positions[i - 1])

    total_length = distances[-1]
    step_size = 0.01  # 1cm
    num_samples = int(np.floor(total_length / step_size)) + 1
    sample_distances = np.linspace(0, total_length, num_samples)

    # 线性插值重采样
    resampled_traj = np.zeros((num_samples, 3))
    for i, sd in enumerate(sample_distances):
        idx = np.searchsorted(distances, sd, side='right') - 1
        idx = min(max(idx, 0), n_poses - 2)
        seg_len = distances[idx + 1] - distances[idx]
        t = (sd - distances[idx]) / seg_len if seg_len > 1e-8 else 0.0
        resampled_traj[i] = positions[idx] + t * (positions[idx + 1] - positions[idx])

    traj_pcd = o3d.geometry.PointCloud()
    traj_pcd.points = o3d.utility.Vector3dVector(resampled_traj)
    traj_path = OUTPUT_DIR / "trajectory_resampled.ply"
    o3d.io.write_point_cloud(str(traj_path), traj_pcd)
    print(f"  ✓ 已保存重采样轨迹: {traj_path} ({num_samples} 点, {total_length:.2f}m)")

    # ================= 基于轨迹的 Gateway 检测 =================
    print("\n" + "=" * 70)
    print("[8] Gateway 检测 (基于实际行走轨迹)")
    print("=" * 70)

    # 加载重采样轨迹
    if not NAVIGATION_ENABLED:
        print("  已按配置跳过 Gateway/Navigation 检测")
    elif traj_path.exists():
        traj_pcd_loaded = o3d.io.read_point_cloud(str(traj_path))
        trajectory = np.asarray(traj_pcd_loaded.points)
        print(f"  轨迹点数: {len(trajectory)}")

        # 导入 gateway detector
        from navigation.gateway_detector import GatewayDetector

        # 提取 floor 点云 (用于 detector)
        floor_zero_level = floor_levels[0]['floor_zero_level'] if floor_levels else global_points[:, VERTICAL_AXIS].min()
        room_height = floor_levels[0].get('room_height') or (global_points[:, VERTICAL_AXIS].max() - floor_zero_level)
        floor_mask = (global_points[:, VERTICAL_AXIS] >= floor_zero_level) & \
                     (global_points[:, VERTICAL_AXIS] < floor_zero_level + room_height)
        floor_points = global_points[floor_mask]

        # 创建 detector
        detector = GatewayDetector(floor_points, resolution=0.05)

        # 加载房间点云
        rooms_dir = OUTPUT_DIR / "rooms" / "floor_0_rooms"
        room_pointclouds = {}
        if rooms_dir.exists():
            for room_file in rooms_dir.glob("room_*.ply"):
                room_id = int(room_file.stem.replace("room_", ""))
                room_pcd = o3d.io.read_point_cloud(str(room_file))
                room_pts = np.asarray(room_pcd.points)
                room_pointclouds[room_id] = room_pts
            print(f"  ✓ 加载了 {len(room_pointclouds)} 个房间的点云")
        
        # 为每个房间创建 room dict (带 points)
        enriched_rooms = []
        for room in rooms:
            room_data = dict(room)
            if room['id'] in room_pointclouds:
                room_data['points'] = room_pointclouds[room['id']]
            enriched_rooms.append(room_data)

        # 生成房间栅格
        room_raster = detector.compute_room_raster(enriched_rooms)
        floor_grid = detector._compute_floor_grid()

        # 检测 gateway
        gateways = detector.detect_gateways_from_trajectory(
            trajectory=trajectory,
            rooms=enriched_rooms,
            room_raster=room_raster,
            floor_grid=floor_grid,
            merge_distance=1.0
        )

        # 将 gateway 投影到拟合的轨迹平面
        plane_normal = trajectory_plane['normal']
        plane_d = trajectory_plane['d']

        def project_to_plane(point):
            """将点投影到平面上 (沿法向量方向)"""
            dist = np.dot(plane_normal, point) + plane_d
            return point - dist * plane_normal

        for gw in gateways:
            gw.position_3d = project_to_plane(gw.position_3d)

        print(f"\n  已将 {len(gateways)} 个 gateway 投影到轨迹平面")

        # 保存 gateway 点云
        gateway_output_dir = OUTPUT_DIR / "navigation" / "gateways"
        gateway_output_dir.mkdir(parents=True, exist_ok=True)

        if gateways:
            # 保存 gateway 点云 (黄色)
            gw_cloud = []
            gw_colors = []
            for gw in gateways:
                pos = gw.position_3d
                # 每个 gateway 生成 100 个点用于可视化
                for _ in range(100):
                    pt = pos + np.random.normal(0, 0.08, 3)
                    gw_cloud.append(pt)
                    gw_colors.append([1.0, 1.0, 0.0])  # 黄色

            gw_pcd = o3d.geometry.PointCloud()
            gw_pcd.points = o3d.utility.Vector3dVector(np.array(gw_cloud))
            gw_pcd.colors = o3d.utility.Vector3dVector(np.array(gw_colors))

            gw_ply_path = gateway_output_dir / "gateways.ply"
            o3d.io.write_point_cloud(str(gw_ply_path), gw_pcd)
            print(f"  ✓ 已保存 gateway 点云: {gw_ply_path} ({len(gw_cloud)} 点)")

            # 保存 gateway JSON
            gw_data = {
                'gateways': [{
                    'id': gw.id,
                    'room_a': gw.room_a,
                    'room_b': gw.room_b,
                    'position': gw.position.tolist(),
                    'position_3d': gw.position_3d.tolist(),
                    'width': gw.width,
                    'confidence': gw.confidence
                } for gw in gateways],
                'total': len(gateways)
            }

            gw_json_path = gateway_output_dir / "gateways.json"
            with open(gw_json_path, 'w') as f:
                json.dump(gw_data, f, indent=2)
            print(f"  ✓ 已保存 gateway 数据: {gw_json_path}")

            print(f"\n  Gateway 列表 ({len(gateways)} 个):")
            for gw in gateways:
                print(f"    GW{gw.id}: Room {gw.room_a} ↔ Room {gw.room_b} "
                      f"@ ({gw.position_3d[0]:.2f}, {gw.position_3d[1]:.2f}, {gw.position_3d[2]:.2f}) "
                      f"穿越={int(gw.confidence * 10)}, 宽≈{gw.width:.2f}m")
        else:
            print("  未检测到 gateway")
    else:
        print(f"  警告: 轨迹文件不存在 {traj_path}，跳过 gateway 检测")

    # ================= 构建场景拓扑图 =================
    print("\n" + "=" * 70)
    print("[9] 构建场景拓扑图")
    print("=" * 70)

    global_pcd = {'points': global_points, 'colors': global_colors}
    merged_info = {
        'num_frames': num_frames_processed,
        'detection_frames': num_detection_frames
    }
    scene_graph = build_scene_graph(global_pcd, rooms, final_objects, merged_info, floor_levels)

    object_update_report = None
    if OBJECT_LIFECYCLE_ENABLED:
        previous_scene_graph = None
        if OBJECT_LIFECYCLE_PREVIOUS_SCENE_GRAPH.exists():
            try:
                with open(OBJECT_LIFECYCLE_PREVIOUS_SCENE_GRAPH, 'r', encoding='utf-8') as f:
                    previous_scene_graph = json.load(f)
                print(f"  已加载上一版场景图用于对象级更新: {OBJECT_LIFECYCLE_PREVIOUS_SCENE_GRAPH}")
            except Exception as e:
                print(f"  警告：上一版场景图读取失败，按首次构建处理: {e}")

        scene_graph, object_update_report = annotate_scene_graph_with_object_updates(
            scene_graph,
            previous_scene_graph=previous_scene_graph,
            config=OBJECT_LIFECYCLE_CONFIG,
        )
        OBJECT_UPDATE_REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(OBJECT_UPDATE_REPORT_FILE, 'w', encoding='utf-8') as f:
            json.dump(object_update_report, f, indent=2, default=str, ensure_ascii=False)

        summary = object_update_report.get('summary', {})
        print(
            "  对象级更新: "
            f"active={summary.get('active', 0)}, "
            f"new={summary.get('new', 0)}, "
            f"merged={summary.get('merged', 0)}, "
            f"moved={summary.get('moved', 0)}, "
            f"missing={summary.get('missing', 0)}, "
            f"disappeared={summary.get('disappeared', 0)}"
        )
        print(f"  ✓ 已保存对象更新报告: {OBJECT_UPDATE_REPORT_FILE}")

    if vlm_ok and OBJECT_ENVIRONMENT_DESCRIPTION_ENABLED:
        print("\n" + "=" * 70)
        print("[9.5] 生成每个物体的环境描述")
        print("=" * 70)
        scene_graph, floor_results, person_results = annotate_scene_graph_with_environment_descriptions(
            scene_graph,
            cache_file=OBJECT_ENVIRONMENT_CACHE_FILE,
            max_images=OBJECT_ENVIRONMENT_MAX_IMAGES,
        )

        with open(CLEANING_INSPECTION_FILE, 'w') as f:
            json.dump(floor_results, f, indent=2, default=str, ensure_ascii=False)
        print(f"  ✓ 已保存地板清洁检测：{CLEANING_INSPECTION_FILE} ({len(floor_results)} 个 floor)")

        with open(BEHAVIORAL_ANALYSIS_FILE, 'w') as f:
            json.dump(person_results, f, indent=2, default=str, ensure_ascii=False)
        print(f"  ✓ 已保存行为分析：{BEHAVIORAL_ANALYSIS_FILE} ({len(person_results)} 个 person)")
    elif OBJECT_ENVIRONMENT_DESCRIPTION_ENABLED:
        print("\n  警告：VLM 服务不可用，跳过每个物体的环境描述生成。")
        scene_graph, floor_results, person_results = scene_graph, [], []

    with open(SCENE_GRAPH_FILE, 'w') as f:
        json.dump(scene_graph, f, indent=2, default=str)

    print(f"  ✓ 已保存：{SCENE_GRAPH_FILE}")
    print(f"  楼层数：{len(scene_graph['floors'])}")
    print(f"  房间数：{len(scene_graph.get('rooms', []))}")
    print(f"  房间连接数：{len(scene_graph.get('connections', []))}")
    print(f"  物体数：{scene_graph['num_objects']}")

    print("\n" + "=" * 70)
    print("[9.6] 导出分层场景图 (visualize_graph.py 兼容格式)")
    print("=" * 70)
    export_hierarchical_graph(OUTPUT_DIR, floor_levels, rooms, final_objects, scene_graph)

    print("\n" + "=" * 70)
    print("[10] 生成俯视图可视化")
    print("=" * 70)

    top_view_output_dir = OUTPUT_DIR / "top_view"
    # 获取 floor_zero_level 用于正确的高度过滤
    floor_zero = floor_levels[0]['floor_zero_level'] if floor_levels else None
    generate_top_view_visualization(global_points, global_colors, rooms, top_view_output_dir,
                                   floor_zero_level=floor_zero,
                                   vertical_axis=VERTICAL_AXIS,
                                   horizontal_axes=HORIZONTAL_AXES)

    # 释放点云
    num_global_points = len(global_points)
    num_rooms = len(rooms)
    num_final_objects = len(final_objects)
    del global_points, global_colors, global_pcd
    del floor_levels
    for room in rooms:
        for key in ('points', 'colors'):
            if key in room:
                del room[key]
    import gc
    gc.collect()

    print("\n" + "=" * 70)
    print("完成!")
    print("=" * 70)
    print(f"\n输出目录：{OUTPUT_DIR}")
    print(f"  - 全局点云：{OUTPUT_DIR / 'global' / 'global_pointcloud.ply'} ({num_global_points:,} 点)")
    if FUSION_ENABLED and FUSION_CONFIG.get("export_complete_map", True):
        print(f"  - Stable raw 点云：{OUTPUT_DIR / 'global' / 'global_pointcloud_stable_raw.ply'}")
        print(f"  - Complete raw 点云：{OUTPUT_DIR / 'global' / 'global_pointcloud_complete_raw.ply'}")
        print(f"  - 完整性点云：{OUTPUT_DIR / 'global' / 'global_pointcloud_complete.ply'}")
    print(f"  - 房间点云：{OUTPUT_DIR / 'rooms' / 'floor_*_rooms' / 'room_*.ply'} ({num_rooms} 个)")
    print(f"  - 物体点云：{OUTPUT_DIR / 'objects' / 'object_*.ply'} ({num_final_objects} 个)")
    if NAVIGATION_ENABLED:
        print(f"  - Gateway 点云：{OUTPUT_DIR / 'navigation' / 'gateways' / 'gateways.ply'} (黄色)")
    else:
        print("  - Gateway 检测：已跳过")
    print(f"  - 场景拓扑图：{SCENE_GRAPH_FILE}")
    if OBJECT_LIFECYCLE_ENABLED:
        print(f"  - 对象更新报告：{OBJECT_UPDATE_REPORT_FILE}")
    print(f"  - 俯视图可视化：{OUTPUT_DIR / 'top_view' / '*.png'}")

    print("\n场景拓扑图摘要:")
    print(json.dumps(scene_graph, indent=2, default=str)[:1500])


if __name__ == "__main__":
    main()
