"""Object lifecycle tracking for incremental reconstruction.

Tracks:
- Object instances: birth frame, observed frames, centroid trajectory
- Per-frame lightweight merge groups (for visualization deduplication)
- Structured JSON output for downstream analysis
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ObjectInstance:
    """Single object instance with lifecycle information."""
    obj_id: int
    category: str
    birth_frame: str
    # Ordered list of frames where this object was observed (visible or created)
    observed_frames: list[str] = field(default_factory=list)
    # Centroid trajectory: [(frame_id, cx, cy, cz, point_count), ...]
    centroid_trajectory: list[tuple] = field(default_factory=list)
    # State tracking
    is_alive: bool = True
    miss_count: int = 0
    current_state: str = "unknown"

    def to_dict(self) -> dict[str, Any]:
        return {
            'obj_id': self.obj_id,
            'category': self.category,
            'birth_frame': self.birth_frame,
            'observed_frames': self.observed_frames,
            'centroid_trajectory': [
                {
                    'frame_id': t[0],
                    'centroid_3d': [t[1], t[2], t[3]],
                    'point_count': t[4],
                }
                for t in self.centroid_trajectory
            ],
            'is_alive': self.is_alive,
            'miss_count': self.miss_count,
            'current_state': self.current_state,
        }


class LifecycleTracker:
    """Manages object lifecycle tracking across all frames.

    Usage:
        tracker = LifecycleTracker()
        # When a new object is created:
        tracker.register_object(obj_id, category, frame_id, centroid, point_count)
        # When an object is observed (visible) in a frame:
        tracker.update_observation(obj_id, frame_id, centroid, point_count)
        # After lightweight merge for a frame:
        tracker.record_merge_groups(frame_id, merge_groups)
        # At end of sequence:
        tracker.save(output_dir)
    """

    def __init__(self) -> None:
        self._instances: dict[int, ObjectInstance] = {}
        # Per-frame merge groups: {frame_id: [group1, group2, ...]}
        # Each group is a list of obj_ids that were merged together
        self._frame_merge_groups: dict[str, list[list[int]]] = {}

    def register_object(
        self,
        obj_id: int,
        category: str,
        frame_id: str,
        centroid: list[float] | None = None,
        point_count: int = 0,
    ) -> None:
        """Register a new object instance at its birth frame."""
        inst = ObjectInstance(
            obj_id=obj_id,
            category=category,
            birth_frame=frame_id,
        )
        if centroid is not None:
            inst.observed_frames.append(frame_id)
            inst.centroid_trajectory.append(
                (frame_id, centroid[0], centroid[1], centroid[2], point_count)
            )
        self._instances[obj_id] = inst

    def update_observation(
        self,
        obj_id: int,
        frame_id: str,
        centroid: list[float] | None = None,
        point_count: int = 0,
        state: str = "persisting",
    ) -> None:
        """Record that an existing object was observed in a frame.

        Resets miss_count when state is 'persisting'.
        """
        inst = self._instances.get(obj_id)
        if inst is None or not inst.is_alive:
            return
        inst.current_state = state
        if state == "persisting":
            inst.miss_count = 0
        # Avoid duplicate frame entries
        if len(inst.observed_frames) == 0 or inst.observed_frames[-1] != frame_id:
            inst.observed_frames.append(frame_id)
        if centroid is not None:
            inst.centroid_trajectory.append(
                (frame_id, centroid[0], centroid[1], centroid[2], point_count)
            )

    def increment_miss_count(
        self,
        obj_id: int,
        frame_id: str,
        state: str = "disappeared",
        death_threshold: int = 5,
    ) -> None:
        """Increment consecutive miss count; mark dead when threshold exceeded."""
        inst = self._instances.get(obj_id)
        if inst is None or not inst.is_alive:
            return
        inst.miss_count += 1
        inst.current_state = state
        if inst.miss_count >= death_threshold:
            inst.is_alive = False

    def get_alive_instances(self) -> dict[int, ObjectInstance]:
        """Return all alive object instances."""
        return {oid: inst for oid, inst in self._instances.items() if inst.is_alive}

    def record_merge_groups(
        self,
        frame_id: str,
        merge_groups: list[list[int]],
    ) -> None:
        """Record lightweight merge groups for a frame.

        Args:
            frame_id: The frame identifier
            merge_groups: List of groups, each group is a list of obj_ids
                         that were merged together for visualization.
                         Single-element groups (no merge) are also included.
        """
        self._frame_merge_groups[frame_id] = merge_groups

    def get_instance(self, obj_id: int) -> ObjectInstance | None:
        return self._instances.get(obj_id)

    def save(self, output_dir: Path) -> Path:
        """Save all lifecycle data to JSON.

        Creates two files:
        - object_instances.json: per-object lifecycle data
        - frame_merge_groups.json: per-frame lightweight merge groups

        Returns:
            Path to the output directory
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        # Save object instances
        instances_data = {
            'total_objects': len(self._instances),
            'objects': [
                self._instances[oid].to_dict()
                for oid in sorted(self._instances.keys())
            ],
        }
        inst_path = output_dir / 'object_instances.json'
        with open(inst_path, 'w', encoding='utf-8') as f:
            json.dump(instances_data, f, ensure_ascii=False, indent=2)

        # Save per-frame merge groups
        merge_data = {
            'total_frames': len(self._frame_merge_groups),
            'frames': {
                fid: groups
                for fid, groups in sorted(self._frame_merge_groups.items())
            },
        }
        merge_path = output_dir / 'frame_merge_groups.json'
        with open(merge_path, 'w', encoding='utf-8') as f:
            json.dump(merge_data, f, ensure_ascii=False, indent=2)

        return output_dir
