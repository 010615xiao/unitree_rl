"""Object state detection via depth ray comparison.

Projects each merged object's 3D points onto the current frame's depth map,
samples actual depth at projected pixel locations, and classifies each object
as PERSISTING / OCCLUDED / DISAPPEARED based on depth consistency.

Depth ray comparison is the primary signal; name matching is auxiliary.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

import numpy as np


class ObjectState(str, Enum):
    """Object lifecycle state based on depth ray comparison."""
    PERSISTING = "persisting"      # depth matches expected range
    OCCLUDED = "occluded"          # something closer blocks the view
    DISAPPEARED = "disappeared"    # not enough evidence to determine


# ---------------------------------------------------------------------------
# Projection & sampling
# ---------------------------------------------------------------------------

def project_and_sample(
    points_world: np.ndarray,
    K: np.ndarray,
    T_w2c: np.ndarray,
    depth_map: np.ndarray,
    max_samples: int = 50,
) -> dict[str, Any]:
    """Project 3D points to image plane and sample depth at projected pixels.

    Returns dict with:
        valid_pixels: (N, 2) int pixel coords
        expected_depths: (N,) float expected depth from point projection
        actual_depths: (N,) float sampled from depth_map
        min_expected: float min of expected_depths
        max_expected: float max of expected_depths
    """
    h, w = depth_map.shape[:2]
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    # World → camera
    n = len(points_world)
    if n == 0:
        return _empty_sample()

    pts_hom = np.hstack([points_world, np.ones((n, 1))])
    pts_cam = (T_w2c @ pts_hom.T).T[:, :3]

    # Keep points in front of camera
    in_front = pts_cam[:, 2] > 0.1
    pts_cam = pts_cam[in_front]
    if len(pts_cam) == 0:
        return _empty_sample()

    # Project to pixel coordinates
    z = pts_cam[:, 2]
    u = (pts_cam[:, 0] * fx / z + cx).astype(np.int32)
    v = (pts_cam[:, 1] * fy / z + cy).astype(np.int32)

    # Keep pixels inside image
    valid = (u >= 0) & (u < w) & (v >= 0) & (v < h)
    u, v, z_valid = u[valid], v[valid], z[valid]
    if len(u) == 0:
        return _empty_sample()

    # Deduplicate pixels — build per-pixel depth range
    pixel_key = v.astype(np.int64) * w + u.astype(np.int64)
    order = np.argsort(pixel_key)
    pixel_key = pixel_key[order]
    u, v, z_valid = u[order], v[order], z_valid[order]

    # Find unique pixel boundaries
    change = np.concatenate([[True], pixel_key[1:] != pixel_key[:-1]])
    unique_keys = pixel_key[change]
    indices = np.where(change)[0]

    n_unique = len(unique_keys)
    px_u = (unique_keys % w).astype(np.int32)
    px_v = (unique_keys // w).astype(np.int32)
    min_z = np.minimum.reduceat(z_valid, indices)
    max_z = np.maximum.reduceat(z_valid, indices)

    # Sample up to max_samples pixels
    if n_unique > max_samples:
        sel = np.random.choice(n_unique, max_samples, replace=False)
        sel.sort()
        px_u = px_u[sel]
        px_v = px_v[sel]
        min_z = min_z[sel]
        max_z = max_z[sel]

    actual = depth_map[px_v, px_u]

    # 物体级全局深度区间（所有投影点，不做像素去重）
    global_min_z = float(z_valid.min())
    global_max_z = float(z_valid.max())

    return {
        'valid_pixels': np.stack([px_u, px_v], axis=1),
        'expected_min': min_z,
        'expected_max': max_z,
        'actual_depths': actual,
        'n_pixels': n_unique,
        'global_min_z': global_min_z,
        'global_max_z': global_max_z,
    }


def _empty_sample() -> dict[str, Any]:
    return {
        'valid_pixels': np.zeros((0, 2), dtype=np.int32),
        'expected_min': np.array([], dtype=np.float32),
        'expected_max': np.array([], dtype=np.float32),
        'actual_depths': np.array([], dtype=np.float32),
        'n_pixels': 0,
        'global_min_z': 0.0,
        'global_max_z': 0.0,
    }


# ---------------------------------------------------------------------------
# State classification
# ---------------------------------------------------------------------------

def classify_state(
    sample: dict[str, Any],
    depth_tolerance: float = 0.15,
    min_valid_samples: int = 20,
    persist_ratio: float = 0.5,
) -> ObjectState:
    """Classify object state from depth comparison results.

    For each sampled pixel:
      - "match"   if actual_depth ∈ [expected_min - tol, expected_max + tol]
      - "occluded" if actual_depth < expected_min - tol  (something closer)
      - "mismatch" otherwise (depth beyond expected range)

    Returns:
      PERSISTING  if match_ratio >= persist_ratio
      OCCLUDED    if enough samples but low match ratio
      DISAPPEARED if fewer than min_valid_samples
    """
    n = sample['n_pixels']
    if n < min_valid_samples:
        return ObjectState.DISAPPEARED

    actual = sample['actual_depths']
    exp_min = sample['expected_min']
    exp_max = sample['expected_max']

    # Per-pixel classification
    lo = exp_min - depth_tolerance
    hi = exp_max + depth_tolerance

    match = (actual >= lo) & (actual <= hi)
    occluded = actual < lo
    # mismatch = actual > hi  (not used separately)

    n_match = int(np.sum(match))
    n_occluded = int(np.sum(occluded))

    match_ratio = n_match / n

    if match_ratio >= persist_ratio:
        return ObjectState.PERSISTING
    else:
        return ObjectState.OCCLUDED


def classify_state_object_level(
    sample: dict[str, Any],
    depth_tolerance: float = 0.30,
    min_valid_samples: int = 10,
) -> tuple[ObjectState, dict[str, Any]]:
    """Object-level state classification using global depth range.

    Uses the object's full projected depth span [global_min_z, global_max_z]
    as the expected range, and compares against the median actual depth
    sampled from the current frame's depth map at projected pixel locations.

    This is more robust than per-pixel comparison because:
      - Tolerates per-pixel depth noise from monocular depth estimation
      - Avoids false occlusion from slight projection misalignment
      - Uses median to resist outlier pixels (background leakage)

    Returns:
        (state, details_dict) where details has:
          obj_depth_range, median_actual, mean_actual, n_valid,
          n_occluded_pixels, n_match_pixels
    """
    n = sample['n_pixels']
    if n < min_valid_samples:
        return ObjectState.DISAPPEARED, {
            'obj_depth_range': (sample['global_min_z'], sample['global_max_z']),
            'median_actual': 0.0, 'mean_actual': 0.0,
            'n_valid': n, 'n_occluded_pixels': 0, 'n_match_pixels': 0,
        }

    actual = sample['actual_depths']
    obj_min = sample['global_min_z']
    obj_max = sample['global_max_z']

    # Object-level expected range with tolerance
    lo = obj_min - depth_tolerance
    hi = obj_max + depth_tolerance

    median_actual = float(np.median(actual))
    mean_actual = float(np.mean(actual))

    # Per-pixel stats for reference
    exp_min = sample['expected_min']
    exp_max = sample['expected_max']
    px_lo = exp_min - depth_tolerance
    px_hi = exp_max + depth_tolerance
    n_match_pixels = int(np.sum((actual >= px_lo) & (actual <= px_hi)))
    n_occluded_pixels = int(np.sum(actual < px_lo))

    details = {
        'obj_depth_range': (obj_min, obj_max),
        'median_actual': median_actual,
        'mean_actual': mean_actual,
        'n_valid': n,
        'n_occluded_pixels': n_occluded_pixels,
        'n_match_pixels': n_match_pixels,
    }

    # Object-level decision: median actual depth vs object range
    if median_actual < lo:
        # The bulk of the region is closer than the object → occluded
        return ObjectState.OCCLUDED, details
    elif median_actual > hi:
        # The bulk of the region is farther → likely disappeared or moved
        return ObjectState.DISAPPEARED, details
    else:
        return ObjectState.PERSISTING, details


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def detect_object_states(
    merged_objects: list[dict],
    K: np.ndarray,
    T_w2c: np.ndarray,
    depth_map: np.ndarray,
    max_distance: float = 6.0,
    depth_tolerance: float = 0.15,
    min_valid_samples: int = 20,
    persist_ratio: float = 0.5,
    max_samples_per_obj: int = 50,
    structural_cats: frozenset | None = None,
) -> list[dict[str, Any]]:
    """Detect state for each merged object via depth ray comparison.

    Args:
        merged_objects: List of merged object dicts (must have 'points', 'category').
        K: 3×3 camera intrinsic matrix.
        T_w2c: 4×4 world-to-camera transform.
        depth_map: Current frame depth map (H, W) float32, meters.
        max_distance: Max camera-to-object-centre distance (m).
        depth_tolerance: Depth comparison tolerance (m).
        min_valid_samples: Min projected pixels required for classification.
        persist_ratio: Min fraction of matching pixels for PERSISTING.
        max_samples_per_obj: Max pixels to sample per object.
        structural_cats: Categories to skip (floor/wall/ceiling).

    Returns:
        List of dicts, one per merged object:
          obj_idx, state, merged_from, n_pixels, n_match, n_occluded, distance
    """
    if structural_cats is None:
        structural_cats = frozenset({'floor', 'wall', 'ceiling'})

    results: list[dict[str, Any]] = []

    for obj_idx, obj in enumerate(merged_objects):
        cat = obj.get('category', '')
        if cat in structural_cats:
            results.append(_result(obj_idx, obj, ObjectState.DISAPPEARED, 0, 0, 0))
            continue

        pts = obj['points']
        if len(pts) == 0:
            results.append(_result(obj_idx, obj, ObjectState.DISAPPEARED, 0, 0, 0))
            continue

        # Quick distance check
        centroid = pts.mean(axis=0)
        cam_pos = centroid - T_w2c[:3, 3]  # approximate: world - camera_origin
        # More accurate: transform centroid to camera frame
        cent_hom = np.append(centroid, 1.0)
        cent_cam = (T_w2c @ cent_hom)[:3]
        distance = float(np.linalg.norm(cent_cam))
        if distance > max_distance:
            results.append(_result(obj_idx, obj, ObjectState.DISAPPEARED, 0, 0, 0,
                                   distance=distance))
            continue

        # Project & sample
        sample = project_and_sample(pts, K, T_w2c, depth_map,
                                    max_samples=max_samples_per_obj)

        if sample['n_pixels'] < min_valid_samples:
            results.append(_result(obj_idx, obj, ObjectState.DISAPPEARED,
                                   sample['n_pixels'], 0, 0, distance=distance))
            continue

        # Classify using object-level approach (more robust to noise)
        state, details = classify_state_object_level(
            sample, depth_tolerance, min_valid_samples)

        results.append(_result(obj_idx, obj, state, sample['n_pixels'],
                               details['n_match_pixels'],
                               details['n_occluded_pixels'],
                               distance=distance))

    return results


def _result(
    obj_idx: int,
    obj: dict,
    state: ObjectState,
    n_pixels: int,
    n_match: int,
    n_occluded: int,
    distance: float = 0.0,
) -> dict[str, Any]:
    return {
        'obj_idx': obj_idx,
        'state': state,
        'merged_from': obj.get('_merged_from', [obj_idx]),
        'category': obj.get('category', ''),
        'n_pixels': n_pixels,
        'n_match': n_match,
        'n_occluded': n_occluded,
        'distance': round(distance, 3),
    }
