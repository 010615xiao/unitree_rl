# Global Reconstruction

全局场景重建项目现在按功能组织为一个 Python 包。根目录只保留全局配置和说明，源码、测试、第三方依赖、日志与文档分别归档。

## 目录结构

```text
global_reconstruction/
  core/                 # 配置读取、数据集适配、路径工具
  reconstruction/       # 离线重建主流程、轨迹导出/拟合、独立点云构建工具
  segmentation/         # 房间分割与参数调试
  incremental/          # 对象级增量更新：可见性、生命周期、单帧更新入口
  analysis/             # VLM 行为/地面/人员/环境描述分析
  visualization/        # 场景图与房间分割可视化
  services/             # 本地服务封装，例如 SAM3 server
tests/                  # 无外部服务依赖的回归测试
external/sam3-main/     # 第三方 SAM3 代码
docs/                   # 设计文档
logs/                   # 历史运行日志
config.yaml             # 全局配置
```

## 主流程

安装依赖：

```powershell
pip install -r requirements.txt
```

离线全量重建：

```powershell
python -m global_reconstruction.reconstruction.reconstruct_and_segment
```

核心链路是数据适配、点云构建、对象分割、房间分割、scene graph 导出。`navigation.enabled: false` 时会跳过 gateway/navigation 检测。

对象级增量更新：

```powershell
python -m global_reconstruction.incremental.incremental_update `
  --scene-graph unified_output/scene_graph.json `
  --config config.yaml `
  --image current.jpg `
  --depth current_depth.npy `
  --pose current_pose.txt `
  --intrinsics intrinsic.txt `
  --auto-detect
```

也可以用已有检测结果替代 VLM/SAM3：

```powershell
python -m global_reconstruction.incremental.incremental_update `
  --scene-graph unified_output/scene_graph.json `
  --config config.yaml `
  --depth current_depth.npy `
  --pose current_pose.txt `
  --intrinsics intrinsic.txt `
  --detections current_detections.json
```

## 后续优化：基于点云重投影的可见性判断

当前 `incremental/object_visibility.py` 使用 AABB 边界框 + 射线相交做深度证据推理，存在缺陷：
- 不规则物体的边界框包含大量空洞，射线穿过空洞会误判为 cleared
- 采样密度不足时更容易漏检

**改进方案**：用物体实际点云重投影代替边界框
1. 对历史物体点云采样（如最多 500 点）
2. 投影到当前帧，得到 N 个 (u, v, expected_depth) 三元组
3. 采样当前深度图在这些 (u, v) 位置的真实深度值
4. 统计比例：
   - 深度匹配（|real - expected| < margin）→ 存在
   - 深度更近（real < expected - margin）→ 遮挡
   - 深度更远（real > expected + margin）→ 消失
5. 根据比例判断物体状态

优势：精确匹配物体形状，无空洞问题，计算更简单可靠。

**适用场景**：物体生命周期管理中的可见性验证（当前版本仅做几何投影可视化，未启用深度推理）

## 文件职责

- `core/config_loader.py`：读取 `config.yaml`，并提供项目根目录解析。
- `core/data_adapter.py`：统一不同 RGB-D 数据集目录结构。
- `reconstruction/reconstruct_and_segment.py`：当前主离线 pipeline。
- `reconstruction/build_pointcloud.py`：独立点云构建工具，和主 pipeline 有重叠，主要用于调试/最小重建。
- `reconstruction/export_camera_trajectory.py`、`fit_trajectory_plane.py`：轨迹导出、轨迹平面拟合工具。
- `segmentation/segment_rooms.py`：房间分割核心逻辑。
- `segmentation/tune_room_segmentation.py`：房间分割参数调试工具。
- `incremental/object_visibility.py`：把历史对象投影到当前帧，生成可见/遮挡/清空证据。
- `incremental/incremental_update.py`：根据当前 RGB-D 观测更新对象生命周期。
- `incremental/object_memory.py`：全量重建结果之间的对象级 diff，作为离线辅助，不替代单帧增量更新。
- `analysis/`：VLM 相关分析和人员检测，属于可选后处理。
- `visualization/`：离线结果可视化。
- `services/sam3_server.py`：SAM3 HTTP 服务入口。

