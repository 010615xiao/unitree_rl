#!/usr/bin/env python3
"""Generate a trajectory point cloud from odom_matched_camera.txt.

Reads camera center (x, y) from each pose line and writes a PLY point cloud.
"""

import argparse
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Trajectory point cloud from odom_matched_camera.txt")
    p.add_argument("--input", type=Path, required=True, help="odom_matched_camera.txt path")
    p.add_argument("--output", type=Path, default=None, help="Output PLY path (default: <input>_trajectory.ply)")
    p.add_argument("--camera_height", type=float, default=0.0575, help="Z height in meters")
    p.add_argument("--step", type=int, default=1, help="Subsample step (1 = all frames)")
    return p.parse_args()


def read_poses(path: Path, camera_height: float, step: int):
    points = []
    with path.open() as f:
        for line in f:
            parts = line.strip().split("\t")
            if len(parts) < 6:
                continue
            x = float(parts[1]) / 1000.0  # mm -> m
            y = float(parts[2]) / 1000.0
            points.append((x, y, camera_height))
    pts = np.array(points, dtype=np.float64)
    if step > 1:
        pts = pts[::step]
    return pts


def write_ply(path: Path, pts: np.ndarray):
    n = len(pts)
    header = (
        "ply\n"
        "format ascii 1.0\n"
        f"element vertex {n}\n"
        "property float x\n"
        "property float y\n"
        "property float z\n"
        "end_header\n"
    )
    with path.open("w") as f:
        f.write(header)
        for x, y, z in pts:
            f.write(f"{x:.6f} {y:.6f} {z:.6f}\n")


def main():
    args = parse_args()
    output = args.output or args.input.with_name(args.input.stem + "_trajectory.ply")
    pts = read_poses(args.input, args.camera_height, args.step)
    write_ply(output, pts)
    print(f"Wrote {len(pts)} points -> {output}")


if __name__ == "__main__":
    main()
