"""
读取 config.yaml 并提供所有配置项的访问接口

用法:
    from global_reconstruction.core.config_loader import get_config, find_poses_file, find_images_dir

    cfg = get_config()
    cfg.data.default_dir          # -> "/workspace/wxd/VLN/datasets/icra_ic7f"
    cfg.services.vlm_api_url      # -> "http://localhost:8008/v1/chat/completions"

    # 通过 CLI 参数覆盖 (argparse.Namespace)
    cfg = get_config(cli_args=args)
"""

import os
from pathlib import Path
from typing import Optional, List


def project_root() -> Path:
    """Return the repository root that contains config.yaml."""
    current = Path(__file__).resolve()
    for parent in [current.parent, *current.parents]:
        if (parent / "config.yaml").exists():
            return parent
    return current.parents[2]


# ---------------------------------------------------------------------------
# 配置文件查找
# ---------------------------------------------------------------------------

def _find_config_file() -> Path:
    """从当前模块所在目录开始查找 config.yaml。"""
    candidate = project_root() / "config.yaml"
    if candidate.exists():
        return candidate
    raise FileNotFoundError(
        f"未找到 config.yaml: {candidate}。"
        "可通过设置环境变量 GLOBAL_RECON_CONFIG_PATH 指定路径。"
    )


_env_cfg = os.environ.get("GLOBAL_RECON_CONFIG_PATH", "").strip()
if _env_cfg and Path(_env_cfg).is_file():
    _CONFIG_PATH = Path(_env_cfg)
else:
    _CONFIG_PATH = _find_config_file()


# ---------------------------------------------------------------------------
# 原始配置字典
# ---------------------------------------------------------------------------

_raw_config: dict = {}


def _load_raw() -> dict:
    global _raw_config
    if not _raw_config:
        try:
            import yaml
        except ImportError as exc:
            raise ImportError("PyYAML is required to read config.yaml. Install with: pip install pyyaml") from exc
        with open(_CONFIG_PATH, "r") as f:
            _raw_config = yaml.safe_load(f)
    return _raw_config


class _DotDict(dict):
    """通过点号 (.) 访问嵌套字典键。"""

    def __getattr__(self, key: str):
        if key in self:
            v = self[key]
            return _DotDict(v) if isinstance(v, dict) else v
        raise AttributeError(f"配置中不存在键 '{key}'")

    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


def get_config(cli_args=None) -> _DotDict:
    """
    返回完整配置 (_DotDict 对象)。

    参数:
        cli_args: 可选的 argparse.Namespace。以下参数会覆盖配置:
            --data-dir, --output, --poses-file 等。

    返回:
        _DotDict 对象，所有配置项可通过点号访问。
    """
    raw = _load_raw()
    cfg = _DotDict(raw)

    # CLI 覆盖
    if cli_args is not None:
        if hasattr(cli_args, "data_dir") and cli_args.data_dir:
            cfg["data"]["default_dir"] = cli_args.data_dir
        if hasattr(cli_args, "output") and cli_args.output:
            cfg["output"]["base_dir"] = cli_args.output
        if hasattr(cli_args, "poses_file") and cli_args.poses_file:
            cfg["data"]["poses_file"] = cli_args.poses_file

    return cfg


# ---------------------------------------------------------------------------
# 候选路径
# ---------------------------------------------------------------------------

def _resolve_candidate(template: str, base_dir: Path) -> Path:
    """替换路径模板中 {base_dir} 和 {base_dir_parent} """
    result = template
    result = result.replace("{base_dir}", str(base_dir))
    result = result.replace("{base_dir_parent}", str(base_dir.parent))
    return Path(result)


def find_poses_file(base_dir: Optional[Path] = None,
                    extra_candidates: Optional[List[Path]] = None) -> Optional[Path]:
    """
    按配置中定义的候选路径查找 poses.txt。

    参数:
        base_dir: 脚本的基准目录 (默认为本模块的父目录)。
        extra_candidates: 额外追加的候选路径。

    返回:
        第一个存在的 poses.txt 路径，未找到则返回 None。
    """
    cfg = _load_raw()
    base_dir = base_dir or project_root()

    candidates = []
    if extra_candidates:
        candidates.extend(extra_candidates)

    for template in cfg.get("data", {}).get("poses_file_candidates", []):
        candidates.append(_resolve_candidate(template, base_dir))

    for p in candidates:
        if p.exists():
            return p
    return None


def find_images_dir(base_dir: Optional[Path] = None,
                    data_dir: Optional[Path] = None,
                    extra_candidates: Optional[List[Path]] = None) -> Optional[Path]:
    """
    查找图片目录。

    参数:
        base_dir: 脚本的基准目录 (默认为本模块的父目录)。
        data_dir: 数据集根目录 (如果已知，优先使用其下的图片子目录)。
        extra_candidates: 额外追加的候选路径。

    返回:
        第一个存在的图片目录路径，未找到则返回 None。
    """
    cfg = _load_raw()
    base_dir = base_dir or project_root()

    candidates = []
    if extra_candidates:
        candidates.extend(extra_candidates)

    if data_dir:
        subdir = cfg.get("data", {}).get("images_subdir", "images")
        candidates.append(data_dir / subdir)
        subdir_alt = cfg.get("data", {}).get("images_subdir_alt", "rgb")
        if subdir_alt != subdir:
            candidates.append(data_dir / subdir_alt)

    for template in cfg.get("data", {}).get("images_dir_candidates", []):
        candidates.append(_resolve_candidate(template, base_dir))

    for p in candidates:
        if p.exists() and p.is_dir():
            return p
    return None


def find_intrinsic_file(data_dir: Path) -> Optional[Path]:
    """查找相机内参文件。"""
    cfg = _load_raw()
    for name in cfg.get("data", {}).get("intrinsic_file_candidates", ["camera.yaml", "d435i.yaml"]):
        p = data_dir / name
        if p.exists():
            return p
    return None


def service_url(name: str) -> str:
    cfg = _load_raw()
    return cfg.get("services", {}).get(name, "")


def model_path(name: str) -> str:
    cfg = _load_raw()
    return cfg.get("models", {}).get(name, "")


def output_dir(base_dir: Path, subdir: Optional[str] = None) -> Path:
    cfg = _load_raw()
    base = base_dir / cfg.get("output", {}).get("base_dir", "unified_output")
    if subdir:
        base = base / subdir
    base.mkdir(parents=True, exist_ok=True)
    return base


def output_file(base_dir: Path, filename: str) -> Path:
    return output_dir(base_dir) / filename


if __name__ == "__main__":
    cfg = get_config()
    print(f"配置文件: {_CONFIG_PATH}")
    print(f"数据目录: {cfg.data.default_dir}")
    print(f"VLM 地址: {cfg.services.vlm_api_url}")
    print(f"模型名称: {cfg.models.vlm_model_name}")
    print(f"输出目录: {cfg.output.base_dir}")

    poses = find_poses_file()
    print(f"位姿文件: {poses}")

    imgs = find_images_dir(data_dir=Path(cfg.data.default_dir))
    print(f"图片目录: {imgs}")
