"""
支持的数据集格式:
  - standard: images/ + depth/*.png(16bit mm) + poses.txt(TUM) + camera.yaml
  - da3_ezviz: rgb/ + depth/*.npy(float32 m) + camera_poses.txt(4x4) + intrinsic.txt(逐帧)

分辨率对齐:
  - da3_ezviz: 以深度图分辨率为工作分辨率, RGB 下采样到深度尺寸, 内参不变
  - standard:  以 RGB 分辨率为工作分辨率, 深度图上采样到 RGB 尺寸, 内参同步缩放
"""

import numpy as np
import cv2
from pathlib import Path


class DatasetAdapter:
    """数据集适配器,处理格式差异"""

    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)

        # 检测数据集类型
        self.dataset_type = self._detect_dataset_type()

        # 根据类型设置目录和文件
        if self.dataset_type == "da3_ezviz":
            self.images_dir = self.data_dir / "rgb"
            self.depth_dir = self.data_dir / "depth"
            self.poses_file = self.data_dir / "camera_poses.txt"
            self._depth_ext = ".npy"
        else:
            self.images_dir = self.data_dir / "images"
            self.depth_dir = self.data_dir / "depth"
            self.poses_file = self.data_dir / "poses.txt"
            self._depth_ext = ".png"

        # 检测内参文件
        self.intrinsic_file = self._find_intrinsic_file()

        # 获取原始分辨率
        self.depth_resolution = self._get_depth_resolution()
        self.rgb_resolution_original = self._get_rgb_resolution()

        # 加载内参
        self.K_original = self._load_intrinsics()

        # 加载逐帧内参
        self._per_frame_intrinsics = {}
        if self.dataset_type == "da3_ezviz":
            self._load_per_frame_intrinsics()

        # 工作分辨率策略:
        #   da3_ezviz: 以深度图分辨率为工作分辨率, RGB 下采样到深度尺寸, 内参不变
        #   standard:  以 RGB 分辨率为工作分辨率, 深度图上采样到 RGB 尺寸
        if self.dataset_type == "da3_ezviz":
            self.process_resolution = self.depth_resolution
            self.rgb_resolution = self.depth_resolution
            self.needs_depth_upsample = False
            if self.rgb_resolution_original != self.depth_resolution:
                print(f"  ⚙️  工作分辨率: {self.process_resolution} (深度原生分辨率)")
                print(f"     RGB 原始: {self.rgb_resolution_original} -> 将下采样到 {self.process_resolution}")
        else:
            self.process_resolution = self.rgb_resolution_original
            self.rgb_resolution = self.rgb_resolution_original
            self.needs_depth_upsample = self.depth_resolution != self.rgb_resolution

        # 适配后的内参
        self.K = self._compute_adapted_intrinsics()

    def _detect_dataset_type(self):
        """检测数据集类型"""
        has_rgb = (self.data_dir / "rgb").is_dir()
        has_poses = (self.data_dir / "camera_poses.txt").exists() or \
                    (self.data_dir / "odom_matched_camera.txt").exists()
        if has_rgb and has_poses:
            print(f"  📷 检测到 da3_ezviz 格式 (Depth Anything V3 + EZVIZ)")
            return "da3_ezviz"
        return "standard"

    def _find_intrinsic_file(self):
        """查找内参文件"""
        if self.dataset_type == "da3_ezviz":
            candidates = ["intrinsic.txt", "intrinsics.csv", "camera.yaml", "d435i.yaml"]
        else:
            candidates = ["camera.yaml", "d435i.yaml"]
        for name in candidates:
            path = self.data_dir / name
            if path.exists():
                return path
        raise FileNotFoundError(f"未找到相机内参文件,支持的文件名: {candidates}")

    def _load_intrinsics(self):
        """加载原始内参"""
        if self.dataset_type == "da3_ezviz":
            return self._load_intrinsics_da3()
        return self._load_intrinsics_yaml()

    def _load_intrinsics_da3(self):
        """加载 da3_ezviz 逐帧内参,返回平均值作为默认 K (已在深度分辨率下)"""
        intrinsics = []
        with open(self.intrinsic_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split()
                if len(parts) >= 4:
                    fx, fy, cx, cy = float(parts[0]), float(parts[1]), \
                                     float(parts[2]), float(parts[3])
                    intrinsics.append([fx, fy, cx, cy])

        if not intrinsics:
            raise ValueError(f"内参文件为空: {self.intrinsic_file}")

        mean = np.mean(intrinsics, axis=0)
        print(f"  📷 逐帧内参: {len(intrinsics)} 帧, "
              f"均值 fx={mean[0]:.1f} fy={mean[1]:.1f} cx={mean[2]:.1f} cy={mean[3]:.1f}")
        return np.array([[mean[0], 0, mean[2]], [0, mean[1], mean[3]], [0, 0, 1]])

    def _load_intrinsics_yaml(self):
        """加载 YAML 格式内参"""
        import yaml
        with open(self.intrinsic_file, 'r') as f:
            params = yaml.safe_load(f)

        fx = params.get('Camera1.fx', params.get('fx', 385.38))
        fy = params.get('Camera1.fy', params.get('fy', 384.85))
        cx = params.get('Camera1.cx', params.get('cx', 320.58))
        cy = params.get('Camera1.cy', params.get('cy', 240.08))

        return np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])

    def _load_per_frame_intrinsics(self):
        """加载逐帧内参 ( fx fy cx cy, 已在深度分辨率下)"""
        if not self.intrinsic_file or self.intrinsic_file.suffix != '.txt':
            return

        with open(self.intrinsic_file, 'r') as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split()
                if len(parts) >= 4:
                    fx, fy = float(parts[0]), float(parts[1])
                    cx, cy = float(parts[2]), float(parts[3])
                    self._per_frame_intrinsics[i] = (fx, fy, cx, cy)

        print(f"  📷 已加载 {len(self._per_frame_intrinsics)} 帧逐帧内参")

    def _get_depth_resolution(self):
        """获取深度图分辨率"""
        if self.dataset_type == "da3_ezviz":
            npy_files = sorted(self.depth_dir.glob("*.npy"))
            if npy_files:
                d = np.load(str(npy_files[0]))
                return (d.shape[0], d.shape[1])

        png_files = sorted(self.depth_dir.glob("*.png"))
        if png_files:
            sample = cv2.imread(str(png_files[0]), cv2.IMREAD_UNCHANGED)
            if sample is not None:
                return (sample.shape[0], sample.shape[1])

        raise FileNotFoundError(f"深度图目录为空: {self.depth_dir}")

    def _get_rgb_resolution(self):
        """获取RGB图像原始分辨率"""
        rgb_files = list(self.images_dir.glob("*.png"))
        if not rgb_files:
            rgb_files = list(self.images_dir.glob("*.jpg"))
        if not rgb_files:
            raise FileNotFoundError(f"RGB图像目录为空: {self.images_dir}")

        sample = cv2.imread(str(rgb_files[0]))
        return (sample.shape[0], sample.shape[1])  # (H, W)

    def _compute_adapted_intrinsics(self):
        """计算适配后的内参"""
        if not self.needs_depth_upsample:
            return self.K_original.copy()

        # standard 格式: 深度图上采样到 RGB 尺寸, 内参同步缩放
        scale_h = self.rgb_resolution[0] / self.depth_resolution[0]
        scale_w = self.rgb_resolution[1] / self.depth_resolution[1]

        K_adapted = self.K_original.copy()
        K_adapted[0, 0] *= scale_w  # fx
        K_adapted[1, 1] *= scale_h  # fy
        K_adapted[0, 2] *= scale_w  # cx
        K_adapted[1, 2] *= scale_h  # cy

        return K_adapted

    def load_depth(self, depth_file, target_resolution=None):
        """
        加载深度图

        参数:
            depth_file: 深度图路径
            target_resolution: 目标分辨率 (H, W), 仅 standard 格式用于上采样

        返回:
            depth: 深度图 (da3_ezviz: 原生分辨率; standard: 上采样到 RGB 分辨率)
        """
        depth_file = Path(depth_file)

        if self.dataset_type == "da3_ezviz":
            npy_path = self._resolve_depth_npy(depth_file)
            if npy_path is None:
                return None
            return np.load(str(npy_path)).astype(np.float32)

        # standard format: PNG uint16
        depth = cv2.imread(str(depth_file), cv2.IMREAD_UNCHANGED)
        if depth is None:
            return None

        if self.needs_depth_upsample and target_resolution is not None:
            depth = cv2.resize(
                depth,
                (target_resolution[1], target_resolution[0]),
                interpolation=cv2.INTER_NEAREST
            )

        return depth

    def load_depth_raw_mm(self, depth_file, target_resolution=None):
        """
        加载深度图(返回毫米单位,未缩放)

        参数:
            depth_file: 深度图路径
            target_resolution: 目标分辨率 (H, W)

        返回:
            depth_mm: 深度图 (单位:毫米)
        """
        depth_file = Path(depth_file)

        if self.dataset_type == "da3_ezviz":
            depth_m = self.load_depth(depth_file, target_resolution)
            if depth_m is None:
                return None
            return (depth_m * 1000).astype(np.uint16)

        depth = cv2.imread(str(depth_file), cv2.IMREAD_UNCHANGED)
        if depth is None:
            return None

        if self.needs_depth_upsample and target_resolution is not None:
            depth = cv2.resize(
                depth,
                (target_resolution[1], target_resolution[0]),
                interpolation=cv2.INTER_NEAREST
            )

        return depth

    def load_color(self, color_file):
        """
        加载彩色图并缩放到工作分辨率

        da3_ezviz: RGB 下采样到深度图分辨率
        standard: 返回原始 RGB

        参数:
            color_file: RGB图像路径

        返回:
            color: RGB 数组 (H, W, 3), uint8, 与工作分辨率一致
        """
        color = cv2.imread(str(color_file), cv2.IMREAD_COLOR)
        if color is None:
            return None
        color = cv2.cvtColor(color, cv2.COLOR_BGR2RGB)

        if self.dataset_type == "da3_ezviz":
            # 下采样到深度图分辨率
            th, tw = self.process_resolution
            if color.shape[0] != th or color.shape[1] != tw:
                color = cv2.resize(color, (tw, th), interpolation=cv2.INTER_LINEAR)

        return color

    def _resolve_depth_npy(self, depth_file):
        """将深度文件路径解析为 .npy 路径"""
        depth_file = Path(depth_file)
        if depth_file.suffix == '.npy':
            return depth_file if depth_file.exists() else None
        npy_path = depth_file.with_suffix('.npy')
        return npy_path if npy_path.exists() else None

    def get_depth_file_list(self, max_frames=None):
        """获取深度图文件列表"""
        depth_files = sorted(self.depth_dir.glob(f"*{self._depth_ext}"))
        if max_frames is not None:
            depth_files = depth_files[:max_frames]
        return depth_files

    def build_pose_timestamp_map(self, poses):
        """
        构建深度图文件到pose的映射

        处理两种情况:
        1. 深度图文件名 = 时间戳 (如 icra_ic7f): 直接匹配
        2. 深度图文件名 = 序号 (如 00000.png/npy): 按列表顺序一一对应

        参数:
            poses: dict of {timestamp: T_c2w}

        返回:
            file_to_pose: dict of {filename_stem: timestamp}
        """
        depth_files = self.get_depth_file_list()
        pose_timestamps = sorted(poses.keys())

        first_name = depth_files[0].stem
        is_timestamp = '.' in first_name and len(first_name) > 10

        file_to_pose = {}

        if is_timestamp:
            for depth_file in depth_files:
                if depth_file.stem in poses:
                    file_to_pose[depth_file.stem] = depth_file.stem
        else:
            for i, depth_file in enumerate(depth_files):
                if i < len(pose_timestamps):
                    file_to_pose[depth_file.stem] = pose_timestamps[i]

        matched = len(file_to_pose)
        print(f"  📌 建立文件名-时间戳映射: {matched}/{len(depth_files)} 个深度图匹配到 poses")
        return file_to_pose

    def match_color_file(self, timestamp_str):
        """
        根据时间戳/文件名匹配对应的RGB图像

        返回:
            color_file: RGB图像路径,如果不存在则返回None
        """
        if self.dataset_type == "da3_ezviz":
            for ext in [".jpg", ".png"]:
                candidate = self.images_dir / f"{timestamp_str}{ext}"
                if candidate.exists():
                    return candidate
            return None

        if timestamp_str.startswith('depth_'):
            idx_str = timestamp_str.split('_')[1]
        elif timestamp_str.isdigit():
            idx_str = timestamp_str
        else:
            candidates = [
                self.images_dir / f"{timestamp_str}.png",
                self.images_dir / f"{timestamp_str}.jpg",
            ]
            for candidate in candidates:
                if candidate.exists():
                    return candidate
            return None

        idx = int(idx_str)
        candidates = [
            self.images_dir / f"frame_{idx:05d}.jpg",
            self.images_dir / f"frame_{idx:05d}.png",
            self.images_dir / f"{idx_str}.png",
            self.images_dir / f"{idx_str}.jpg",
        ]

        for candidate in candidates:
            if candidate.exists():
                return candidate

        return None

    def get_K_for_frame(self, frame_idx):
        """
        获取指定帧的内参矩阵 (已在工作分辨率下)

        参数:
            frame_idx: 帧序号 (int)

        返回:
            K: 3x3 内参矩阵
        """
        if not self._per_frame_intrinsics:
            return self.K

        if frame_idx not in self._per_frame_intrinsics:
            return self.K

        fx, fy, cx, cy = self._per_frame_intrinsics[frame_idx]
        K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])

        # standard 格式需要缩放到 RGB 分辨率
        if self.needs_depth_upsample:
            scale_h = self.rgb_resolution[0] / self.depth_resolution[0]
            scale_w = self.rgb_resolution[1] / self.depth_resolution[1]
            K[0, 0] *= scale_w
            K[1, 1] *= scale_h
            K[0, 2] *= scale_w
            K[1, 2] *= scale_h

        return K

    def load_confidence(self, frame_idx):
        """
        加载指定帧的置信度图 (仅 da3_ezviz)

        返回:
            confidence: float32 数组, 与工作分辨率 (深度原生分辨率) 一致
        """
        if self.dataset_type != "da3_ezviz":
            return None

        conf_dir = self.data_dir / "conf"
        if not conf_dir.exists():
            return None

        conf_path = conf_dir / f"{frame_idx:05d}_conf.npy"
        if conf_path.exists():
            return np.load(str(conf_path))
        return None

    def print_info(self):
        """打印数据集信息"""
        print(f"\n{'='*60}")
        print(f"数据集适配器信息")
        print(f"{'='*60}")
        print(f"  数据集类型: {self.dataset_type}")
        print(f"  数据目录: {self.data_dir}")
        print(f"  内参文件: {self.intrinsic_file}")
        print(f"  RGB目录: {self.images_dir.name}/")
        print(f"  深度格式: {self._depth_ext}")
        print(f"  RGB原始分辨率: {self.rgb_resolution_original}")
        print(f"  深度图分辨率: {self.depth_resolution}")
        print(f"  工作分辨率: {self.process_resolution}")
        if self._per_frame_intrinsics:
            print(f"  逐帧内参: {len(self._per_frame_intrinsics)} 帧")
        if self.dataset_type == "da3_ezviz":
            conf_dir = self.data_dir / "conf"
            if conf_dir.exists():
                print(f"  置信度目录: conf/ ({len(list(conf_dir.glob('*.npy')))} 帧)")
        print(f"\n  原始内参:")
        print(f"    fx={self.K_original[0,0]:.2f}, fy={self.K_original[1,1]:.2f}")
        print(f"    cx={self.K_original[0,2]:.2f}, cy={self.K_original[1,2]:.2f}")
        if self.needs_depth_upsample:
            print(f"\n  适配后内参 (缩放到RGB分辨率):")
            print(f"    fx={self.K[0,0]:.2f}, fy={self.K[1,1]:.2f}")
            print(f"    cx={self.K[0,2]:.2f}, cy={self.K[1,2]:.2f}")
        print(f"{'='*60}\n")


if __name__ == "__main__":
    import sys
    from global_reconstruction.core.config_loader import get_config, project_root
    cfg = get_config()

    datasets = [
        cfg.data.default_dir,
    ]

    da3_dir = project_root() / "da3_ezviz"
    if da3_dir.exists():
        datasets.append(str(da3_dir))

    for dataset_path in datasets:
        print(f"\n测试数据集: {dataset_path}")
        try:
            adapter = DatasetAdapter(dataset_path)
            adapter.print_info()

            depth_files = adapter.get_depth_file_list(max_frames=3)
            for i, df in enumerate(depth_files):
                depth_m = adapter.load_depth(df)
                print(f"  深度图 {i}: {df.name}")
                print(f"    形状: {depth_m.shape}, dtype: {depth_m.dtype}")
                print(f"    范围: [{depth_m.min():.4f}, {depth_m.max():.4f}] 米")

                K_frame = adapter.get_K_for_frame(i)
                print(f"    K[{i}]: fx={K_frame[0,0]:.2f}, fy={K_frame[1,1]:.2f}")

                color_file = adapter.match_color_file(df.stem)
                if color_file:
                    color = adapter.load_color(color_file)
                    print(f"    彩色图: {color.shape} (已缩放到工作分辨率)")

        except Exception as e:
            print(f"  ❌ 错误: {e}")
            import traceback
            traceback.print_exc()
