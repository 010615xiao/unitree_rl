"""Shared configuration and dataset adapters."""

