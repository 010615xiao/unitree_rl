"""Room and object segmentation helpers."""

