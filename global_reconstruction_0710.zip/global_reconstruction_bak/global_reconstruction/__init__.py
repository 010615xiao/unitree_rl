"""Global scene reconstruction package."""

