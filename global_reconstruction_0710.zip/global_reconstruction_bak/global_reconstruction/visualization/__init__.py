"""Scene graph and room segmentation visualization tools."""

