"""VLM-based scene, floor, behavior, and person analysis tools."""

