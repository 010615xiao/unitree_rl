#!/usr/bin/env python3
"""
地面情况分析 - 从视频中提取帧并用 VLM 分析地面状态（垃圾、污渍、积水等）

用法:
  python analyze_floor_condition.py --video 检测垃圾.mp4
  python analyze_floor_condition.py --video 检测垃圾.mp4 --interval 30
  python analyze_floor_condition.py --video 检测垃圾.mp4 --max-frames 20
"""

import argparse
import base64
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import requests

from global_reconstruction.core.config_loader import get_config, model_path, project_root, service_url

# ================= 配置 =================
cfg = get_config()

VLM_API_URL = service_url('vlm_api_url')
VLM_MODEL_NAME = model_path('vlm_model_legacy')

# 默认采样间隔（帧数）
DEFAULT_INTERVAL = cfg.floor_condition_analysis.sample_interval

# VLM 请求参数
VLM_TIMEOUT = cfg.floor_condition_analysis.timeout
MAX_TOKENS = cfg.floor_condition_analysis.max_tokens
TEMPERATURE = cfg.floor_condition_analysis.temperature

# 输出
OUTPUT_DIR = project_root() / cfg.output.base_dir / cfg.output.floor_analysis_dir
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
# ===========================================


def extract_frames_from_video(video_path, output_dir, interval=30, max_frames=None):
    """从视频中提取帧图像"""
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f"✗ 无法打开视频: {video_path}")
        return []

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    print(f"  视频总帧数: {total_frames}, FPS: {fps:.1f}")

    frame_paths = []
    frame_idx = 0
    saved_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_idx % interval == 0:
            out_path = output_dir / f"frame_{frame_idx:06d}.jpg"
            cv2.imwrite(str(out_path), frame)
            frame_paths.append(out_path)
            saved_count += 1

            if max_frames and saved_count >= max_frames:
                break

        frame_idx += 1

    cap.release()
    print(f"  ✓ 提取了 {saved_count} 帧 (间隔: {interval})")
    return frame_paths


def image_to_base64(image_path):
    """将图片转换为 base64"""
    with open(image_path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')


def build_floor_analysis_prompt():
    prompt = """You are an expert in indoor floor condition assessment.

## Task
Analyze the floor/ground visible in the provided image. Focus ONLY on the floor surface and any objects or conditions on it.

## What to assess
1. **Cleanliness**: Is the floor clean, slightly dirty, or heavily littered?
2. **Debris/Trash**: Are there any pieces of trash, litter, or scattered objects on the floor? Describe them specifically.
3. **Stains/Spills**: Any visible stains, water puddles, oil spots, or other marks?
4. **Floor material**: What is the floor made of? (tile, wood, carpet, concrete, etc.)
5. **Overall condition**: Summarize the floor state.

## Output Format (MANDATORY)
Output ONLY this JSON, no markdown, no explanation:
{
  "floor_visible": true or false,
  "floor_material": "tile/wood/carpet/concrete/unknown",
  "cleanliness": "clean/slightly_dirty/moderately_dirty/heavily_dirty",
  "has_trash": true or false,
  "trash_items": ["List specific trash visible, e.g., paper scraps, plastic bottle, food wrapper, dust"],
  "has_stains": true or false,
  "stains_description": "Describe any stains if present, or empty string",
  "has_puddles": true or false,
  "overall_description": "One sentence summary of floor condition",
  "confidence": "high/medium/low"
}

## Rules
1. If the floor is NOT visible (blocked by furniture, too dark, etc.), set floor_visible=false and give a short reason
2. Be specific about trash items — do not just say "debris", say what it looks like
3. If no trash or stains, say so explicitly (e.g., "No visible trash", "Floor is clean")
4. Output ONLY the JSON object, no markdown, no extra text

Analyze the floor in this image NOW:"""

    return prompt


def clean_json_output(content):
    """清理 VLM 输出，提取有效 JSON"""
    if content.startswith('```json'):
        content = content[7:]
    if content.startswith('```'):
        content = content[3:]
    if content.endswith('```'):
        content = content[:-3]

    content = content.strip()

    start = content.find('{')
    end = content.rfind('}') + 1

    if start >= 0 and end > start:
        return content[start:end]

    return content


def call_vlm_single_image(image_path, prompt, max_tokens=MAX_TOKENS, temperature=TEMPERATURE, timeout=VLM_TIMEOUT):
    """调用 VLM 分析单张图像"""
    if not Path(image_path).exists():
        print(f"  错误: 图像不存在: {image_path}")
        return None

    image_base64 = image_to_base64(image_path)

    content = [
        {
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"},
        },
        {"type": "text", "text": prompt}
    ]

    payload = {
        "model": VLM_MODEL_NAME,
        "messages": [{
            "role": "user",
            "content": content,
        }],
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stream": False,
    }

    try:
        response = requests.post(VLM_API_URL, json=payload, timeout=timeout)
        response.raise_for_status()

        result = response.json()
        response_text = result['choices'][0]['message']['content'].strip()

        response_text = clean_json_output(response_text)
        return json.loads(response_text)

    except requests.exceptions.ConnectionError:
        print(f"  错误: 无法连接到 VLM 服务 ({VLM_API_URL})")
        return None
    except requests.exceptions.Timeout:
        print(f"  错误: VLM 请求超时 ({timeout}秒)")
        return None
    except json.JSONDecodeError as e:
        print(f"  错误: VLM 返回 JSON 解析失败: {e}")
        print(f"  原始输出: {response_text[:300]}")
        return None
    except Exception as e:
        print(f"  错误: VLM 调用失败: {e}")
        return None


def check_vlm_service():
    """检查 VLM 服务是否可用"""
    try:
        payload = {
            "model": VLM_MODEL_NAME,
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 10,
            "stream": False,
        }
        response = requests.post(VLM_API_URL, json=payload, timeout=5)
        if response.status_code == 200:
            print(f"✓ VLM 服务可用 ({VLM_API_URL})")
            return True
        else:
            print(f"✗ VLM 服务返回状态码: {response.status_code}")
            return False
    except Exception as e:
        print(f"✗ 无法连接 VLM 服务: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="地面情况分析 - 从视频中提取帧并用 VLM 分析")
    parser.add_argument("--video", type=str, required=True, help="视频文件路径")
    parser.add_argument("--interval", type=int, default=DEFAULT_INTERVAL, help=f"采样间隔帧数 (默认: {DEFAULT_INTERVAL})")
    parser.add_argument("--max-frames", type=int, default=None, help="最大处理帧数 (默认: 全部)")
    parser.add_argument("--output", type=str, default=None, help="输出 JSON 文件路径")
    parser.add_argument("--keep-frames", action="store_true", help="保留提取的帧图像 (默认: 分析后删除)")
    args = parser.parse_args()

    video_path = Path(args.video)
    if not video_path.exists():
        print(f"✗ 视频文件不存在: {video_path}")
        return

    print("\n" + "=" * 70)
    print("地面情况分析 - VLM 视频帧分析")
    print("=" * 70)

    # 检查 VLM 服务
    if not check_vlm_service():
        print("\n请先启动 VLM 服务:")
        print('  ./llama-server -m /path/RoboBrain2.5-8B_q8_0.gguf \\')
        print('    --mmproj /path/mmproj-RoboBrain2.5-8b-F16.gguf \\')
        print('    --port 8008 --host 0.0.0.0 --media-path /path/images --ctx-size 12000')
        return

    # 提取帧
    print(f"\n提取视频帧: {video_path.name}")
    frames_dir = OUTPUT_DIR / "extracted_frames"
    frames_dir.mkdir(parents=True, exist_ok=True)

    frame_paths = extract_frames_from_video(video_path, frames_dir, args.interval, args.max_frames)
    if not frame_paths:
        print("✗ 未提取到任何帧")
        return

    # 构建提示词
    prompt = build_floor_analysis_prompt()

    # 逐帧分析
    all_results = []
    success_count = 0
    fail_count = 0

    print(f"\n开始分析地面情况...")
    start_time = time.time()

    for i, frame_path in enumerate(frame_paths):
        frame_idx = int(frame_path.stem.split('_')[1])
        print(f"\n[{i+1}/{len(frame_paths)}] 帧 {frame_idx}")

        result = call_vlm_single_image(frame_path, prompt)

        if result:
            result["frame_index"] = frame_idx
            result["image_file"] = frame_path.name

            # 简短摘要
            if not result.get("floor_visible", True):
                print(f"  ⊘ 地面不可见")
            else:
                has_trash = result.get("has_trash", False)
                trash_str = ", ".join(result.get("trash_items", []))[:40]
                cleanliness = result.get("cleanliness", "?")
                overall = result.get("overall_description", "")[:60]
                print(f"  ✓ [{cleanliness}] 垃圾: {has_trash} ({trash_str}) | {overall}")

            all_results.append(result)
            success_count += 1
        else:
            print(f"  ✗ 分析失败")
            fail_count += 1

        if i < len(frame_paths) - 1:
            time.sleep(0.5)

    elapsed = time.time() - start_time

    # 清理提取的帧
    if not args.keep_frames:
        for fp in frame_paths:
            fp.unlink(missing_ok=True)
        print(f"\n  已清理提取的帧图像")

    print(f"\n{'=' * 70}")
    print(f"分析完成:")
    print(f"  总采样帧: {len(frame_paths)}")
    print(f"  成功: {success_count}")
    print(f"  失败: {fail_count}")
    print(f"  耗时: {elapsed:.1f} 秒")

    if not all_results:
        print("\n无有效结果,退出")
        return

    # 统计垃圾出现频率
    trash_frames = [r for r in all_results if r.get("has_trash", False)]
    clean_frames = [r for r in all_results if r.get("floor_visible", True) and not r.get("has_trash", False)]
    floor_invisible = [r for r in all_results if not r.get("floor_visible", True)]

    print(f"\n统计摘要:")
    print(f"  地面可见: {len(all_results) - len(floor_invisible)} 帧")
    print(f"  有垃圾: {len(trash_frames)} 帧")
    print(f"  无垃圾: {len(clean_frames)} 帧")
    print(f"  地面不可见: {len(floor_invisible)} 帧")

    # 汇总所有检测到的垃圾类型
    all_trash_items = {}
    for r in trash_frames:
        for item in r.get("trash_items", []):
            all_trash_items[item] = all_trash_items.get(item, 0) + 1

    if all_trash_items:
        print(f"\n检测到的垃圾汇总:")
        for item, count in sorted(all_trash_items.items(), key=lambda x: -x[1]):
            print(f"  {item}: {count} 帧")

    # 构建输出 JSON
    output_data = {
        "metadata": {
            "video_file": str(video_path),
            "total_frames_extracted": len(frame_paths),
            "sampling_interval": args.interval,
            "successful_analyses": success_count,
            "failed_analyses": fail_count,
            "frames_with_trash": len(trash_frames),
            "frames_without_trash": len(clean_frames),
            "processing_time_seconds": round(elapsed, 1),
            "generated_at": datetime.now().isoformat(),
        },
        "trash_summary": {
            "total_trash_items_detected": {k: v for k, v in sorted(all_trash_items.items(), key=lambda x: -x[1])},
            "trash_frequency": f"{len(trash_frames)}/{len(all_results)} frames contain trash" if all_trash_items else "No trash detected",
        },
        "frame_results": all_results,
    }

    # 保存结果
    if args.output:
        output_file = Path(args.output)
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = OUTPUT_DIR / f"floor_analysis_{timestamp}.json"

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)

    print(f"\n✓ 结果已保存: {output_file}")


if __name__ == "__main__":
    main()
