"""Lightweight object merging for visualization deduplication.

Provides two approaches:
1. ``merge_similar_objects`` — full recluster from scratch (original, kept for
   backward compatibility and one-shot use cases).
2. ``IncrementalMergeTracker`` — persistent merge groups that are updated
   incrementally as new detections arrive.  Groups keep stable IDs and only
   new objects trigger matching; existing groups are never reclustered.

Both produce the same output shape: a list of dicts with ``points``,
``category``, ``_merged_from``, ``_merge_id``, ``_centroid``, ``_point_count``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

import numpy as np


# ================= Centroid Helpers =================

def _compute_centroid(obj: dict[str, Any]) -> tuple[np.ndarray, int]:
    """Return (centroid, point_count) for an object.

    Uses cached values if present and consistent, otherwise computes from
    the full point array and caches the result on the object dict.
    """
    cached = obj.get('_centroid')
    cached_n = obj.get('_point_count')
    pts = obj['points']
    n = len(pts)

    if cached is not None and cached_n == n:
        return cached, cached_n

    centroid = pts.mean(axis=0) if n > 0 else np.zeros(3)
    obj['_centroid'] = centroid
    obj['_point_count'] = n
    return centroid, n


def update_centroid_incremental(
    obj: dict[str, Any],
    new_points: np.ndarray,
) -> None:
    """Update an object's cached centroid after appending new points.

    Uses the incremental formula:
        new_centroid = (old_centroid * N_old + new_centroid * N_new) / (N_old + N_new)

    Call this right after ``obj['points'] = np.vstack([obj['points'], new_points])``.

    Args:
        obj: Object dict (must already contain updated 'points')
        new_points: The newly appended points (M, 3)
    """
    n_new = len(new_points)
    if n_new == 0:
        return

    old_centroid = obj.get('_centroid')
    old_n = obj.get('_point_count', 0)

    if old_centroid is None or old_n == 0:
        obj['_centroid'] = obj['points'].mean(axis=0)
        obj['_point_count'] = len(obj['points'])
        return

    new_centroid = new_points.mean(axis=0)
    total_n = old_n + n_new
    obj['_centroid'] = (old_centroid * old_n + new_centroid * n_new) / total_n
    obj['_point_count'] = total_n


# ================= Merge Result Cache =================

_merge_cache: dict[int, tuple[list[dict[str, Any]], int]] = {}


def _fingerprint(objects: list[dict[str, Any]]) -> int:
    """Cheap hash identifying the current object list state.

    Uses ``id()`` of each dict + its point count so that appending new
    points to an existing object invalidates the cache.
    """
    return hash((len(objects), tuple(
        (id(obj), len(obj.get('points', ()))) for obj in objects
    )))


def invalidate_merge_cache() -> None:
    """Clear the module-level merge result cache."""
    _merge_cache.clear()


# ================= Merge Logic =================

_STRUCTURAL_CATS = {'floor', 'wall', 'ceiling'}


def merge_similar_objects(
    objects: list[dict[str, Any]],
    centroid_distance: float = 0.5,
) -> list[dict[str, Any]]:
    """Greedy merge of objects with same category and close 3D centroids.

    Two-pass algorithm:
      1. **Assign** — for each category, greedily assign objects to
         clusters using vectorised centroid distance checks (no copies).
      2. **Build** — for each cluster, batch ``np.vstack`` all member
         point arrays in one shot and compute the merged centroid.

    Structural categories (floor/wall/ceiling) pass through unchanged.

    Results are cached by a lightweight fingerprint of the input list;
    if the list hasn't changed since the last call the cached result is
    returned immediately.

    Args:
        objects: List of object dicts (each has 'points', 'category')
        centroid_distance: Max Euclidean distance (metres) between 3D
            centroids for two objects to be considered the same

    Returns:
        New list with duplicates merged.  Original list is not modified.
    """
    if len(objects) <= 1:
        for idx, obj in enumerate(objects):
            obj['_merged_from'] = [obj.get('_det_id', f'D{idx}')]
        return list(objects)

    # ---- Cache check ----
    fp = _fingerprint(objects)
    cached = _merge_cache.get(fp)
    if cached is not None:
        return cached[0]

    # ---- Group indices by category ----
    by_cat: dict[str, list[int]] = {}
    for idx, obj in enumerate(objects):
        cat = obj.get('category', '')
        by_cat.setdefault(cat, []).append(idx)

    merged: list[dict[str, Any]] = []

    for cat, indices in by_cat.items():
        # Structural cats pass through untouched
        if cat in _STRUCTURAL_CATS:
            for idx in indices:
                objects[idx]['_merged_from'] = [objects[idx].get('_det_id', f'D{idx}')]
                merged.append(objects[idx])
            continue

        # --- Pass 1: assign objects to clusters (no data copies) ---
        # cluster_members[i] = list of object indices in cluster i
        # cluster_centroids[i] = centroid of cluster i (updated lazily)
        cluster_members: list[list[int]] = []
        cluster_centroids: list[np.ndarray] = []
        dist_sq_thr = centroid_distance * centroid_distance

        for idx in indices:
            obj = objects[idx]
            centroid, _ = _compute_centroid(obj)

            best_ci = -1
            best_dist_sq = float('inf')

            if cluster_centroids:
                # Vectorised distance to all existing cluster centroids
                centroids_arr = np.array(cluster_centroids)  # (C, 3)
                diffs = centroids_arr - centroid             # (C, 3)
                dists_sq = np.einsum('ij,ij->i', diffs, diffs)  # (C,)
                best_ci = int(np.argmin(dists_sq))
                best_dist_sq = float(dists_sq[best_ci])

            if best_dist_sq < dist_sq_thr and best_ci >= 0:
                cluster_members[best_ci].append(idx)
                # Update cluster centroid incrementally (weighted avg)
                old_n = sum(len(objects[mi]['points'])
                            for mi in cluster_members[best_ci][:-1])
                new_n = len(obj['points'])
                total_n = old_n + new_n
                cluster_centroids[best_ci] = (
                    cluster_centroids[best_ci] * old_n
                    + centroid * new_n
                ) / total_n
            else:
                cluster_members.append([idx])
                cluster_centroids.append(centroid.copy())

        # --- Pass 2: build merged objects (single batched vstack each) ---
        for members in cluster_members:
            if len(members) == 1:
                obj = objects[members[0]]
                obj['_merged_from'] = [obj.get('_det_id', f'D{members[0]}')]
                merged.append(obj)
                continue

            # Batch vstack all member points
            all_pts = np.vstack([objects[mi]['points'] for mi in members])
            # Shallow-copy the first member as the cluster representative
            cl = dict(objects[members[0]])
            cl['points'] = all_pts
            cl['_centroid'] = all_pts.mean(axis=0)
            cl['_point_count'] = len(all_pts)
            cl['_merged_from'] = [objects[mi].get('_det_id', f'D{mi}') for mi in members]
            # Merge source_views if present
            for mi in members[1:]:
                sv = objects[mi].get('source_views')
                if sv:
                    cl.setdefault('source_views', []).extend(sv)
            merged.append(cl)

    # ---- Store in cache ----
    _merge_cache[fp] = (merged, fp)

    return merged


# ================= Incremental Merge Tracker =================

@dataclass
class MergeGroup:
    """A persistent merge group representing one physical object."""
    merge_id: int
    category: str
    # Member D-index list (int, extracted from _det_id)
    member_ids: List[int] = field(default_factory=list)
    # Merged points (vstack of all member points)
    points: np.ndarray = field(default_factory=lambda: np.empty((0, 3), dtype=np.float64))
    # Cached centroid
    centroid: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    # Cached point count
    point_count: int = 0
    # Source views aggregated from all members
    source_views: List[dict] = field(default_factory=list)

    def rebuild(self, all_objects: List[dict[str, Any]]) -> None:
        """Rebuild points, centroid, and source_views from current members."""
        pts_list = []
        sv_list = []
        for mid in self.member_ids:
            obj = all_objects[mid]
            if len(obj['points']) > 0:
                pts_list.append(obj['points'])
            sv = obj.get('source_views')
            if sv:
                sv_list.extend(sv)
        if pts_list:
            self.points = np.vstack(pts_list)
            self.centroid = self.points.mean(axis=0)
            self.point_count = len(self.points)
        else:
            self.points = np.empty((0, 3), dtype=np.float64)
            self.centroid = np.zeros(3, dtype=np.float64)
            self.point_count = 0
        self.source_views = sv_list

    def to_dict(self) -> dict[str, Any]:
        """Convert to the dict shape expected by downstream consumers."""
        merged_from = [f'D{mid}' for mid in self.member_ids]
        d: dict[str, Any] = {
            'category': self.category,
            'points': self.points,
            '_centroid': self.centroid,
            '_point_count': self.point_count,
            '_merged_from': merged_from,
            '_merge_id': f'M{self.merge_id}',
            'source_views': self.source_views,
        }
        return d


class IncrementalMergeTracker:
    """Persistent lightweight merge groups updated incrementally.

    Usage::

        tracker = IncrementalMergeTracker(centroid_distance=0.5)

        # After new objects are appended to all_objects:
        tracker.update(new_object_indices, all_objects)

        # After lifecycle updates, prune dead members:
        tracker.prune(set(alive_obj_ids), all_objects)

        # Get the current merged object list (for filter_visible_objects etc.):
        merged = tracker.to_merged_objects()
    """

    def __init__(self, centroid_distance: float = 0.5) -> None:
        self.centroid_distance = centroid_distance
        self._groups: List[MergeGroup] = []
        # D-index → group index in self._groups (for fast lookup)
        self._member_to_group: Dict[int, int] = {}
        self._next_id: int = 0

    def update(
        self,
        new_object_indices: List[int],
        all_objects: List[dict[str, Any]],
    ) -> None:
        """Add newly detected objects to existing groups or create new ones.

        Only processes the given indices; existing groups are not reclustered.

        Structural categories (floor/wall/ceiling) always create their own
        singleton groups (no cross-object merging).

        Args:
            new_object_indices: List of indices into ``all_objects`` that are
                newly added since the last ``update`` call.
            all_objects: The full object list (read-only reference).
        """
        dist_sq_thr = self.centroid_distance * self.centroid_distance

        for obj_idx in new_object_indices:
            obj = all_objects[obj_idx]
            category = obj.get('category', '')
            centroid, _ = _compute_centroid(obj)

            # Structural categories never merge
            if category in _STRUCTURAL_CATS:
                self._create_group(category, [obj_idx], all_objects)
                continue

            # Find best matching existing group (same category, min distance)
            best_gi = -1
            best_dist_sq = float('inf')
            for gi, group in enumerate(self._groups):
                if group.category != category:
                    continue
                if group.point_count == 0:
                    continue
                dist_sq = float(np.sum((centroid - group.centroid) ** 2))
                if dist_sq < dist_sq_thr and dist_sq < best_dist_sq:
                    best_gi = gi
                    best_dist_sq = dist_sq

            if best_gi >= 0:
                # Join existing group
                group = self._groups[best_gi]
                group.member_ids.append(obj_idx)
                group.rebuild(all_objects)
                self._member_to_group[obj_idx] = best_gi
            else:
                # Create new group
                self._create_group(category, [obj_idx], all_objects)

    def _create_group(
        self,
        category: str,
        member_ids: List[int],
        all_objects: List[dict[str, Any]],
    ) -> int:
        """Create a new merge group and return its index."""
        gi = len(self._groups)
        group = MergeGroup(
            merge_id=self._next_id,
            category=category,
            member_ids=list(member_ids),
        )
        group.rebuild(all_objects)
        self._groups.append(group)
        for mid in member_ids:
            self._member_to_group[mid] = gi
        self._next_id += 1
        return gi

    def prune(
        self,
        alive_ids: Set[int],
        all_objects: List[dict[str, Any]],
    ) -> None:
        """Remove dead members from groups and discard empty groups.

        After pruning, group ``merge_id`` values are unchanged. Groups with
        no remaining alive members are marked inactive (removed from the
        active list).

        Args:
            alive_ids: Set of D-indices that are still alive.
            all_objects: The full object list (for rebuilding points).
        """
        new_groups: List[MergeGroup] = []
        new_member_to_group: Dict[int, int] = {}

        for group in self._groups:
            surviving = [mid for mid in group.member_ids if mid in alive_ids]
            if not surviving:
                continue
            group.member_ids = surviving
            group.rebuild(all_objects)
            new_gi = len(new_groups)
            new_groups.append(group)
            for mid in surviving:
                new_member_to_group[mid] = new_gi

        self._groups = new_groups
        self._member_to_group = new_member_to_group

    def to_merged_objects(self) -> List[dict[str, Any]]:
        """Return current merge groups as a list of dicts.

        Output shape matches what ``merge_similar_objects`` returns,
        so downstream code (``filter_visible_objects``,
        ``detect_object_states``, ``visualize_visibility``) can use it
        directly.
        """
        return [group.to_dict() for group in self._groups]

    def get_group_for_member(self, obj_id: int) -> Optional[MergeGroup]:
        """Look up the merge group containing a given D-index."""
        gi = self._member_to_group.get(obj_id)
        if gi is None:
            return None
        return self._groups[gi]

    @property
    def group_count(self) -> int:
        return len(self._groups)

    def summary(self) -> Dict[str, int]:
        """Return a summary of group sizes for logging."""
        sizes = [len(g.member_ids) for g in self._groups]
        if not sizes:
            return {'groups': 0, 'singletons': 0, 'merged': 0, 'total_members': 0}
        return {
            'groups': len(sizes),
            'singletons': sum(1 for s in sizes if s == 1),
            'merged': sum(1 for s in sizes if s > 1),
            'total_members': sum(sizes),
        }
