"""Object-level incremental scene graph updates."""

from global_reconstruction.incremental.visibility_visualizer import (
    visualize_visibility,
    load_visibility_viz_config,
)
from global_reconstruction.incremental.object_merger import (
    merge_similar_objects,
    update_centroid_incremental,
    invalidate_merge_cache,
)

