"""Utility functions for the incremental reconstruction pipeline.

Retained helpers: intrinsics/pose/depth loading, quaternion conversion,
and 2D bbox IoU.  The former ray-AABB visibility prediction has been
removed; visibility filtering for visualisation now lives in
``reconstruct_and_segment.visualize_visibility``.
"""

from __future__ import annotations

from pathlib import Path
import json
import re
from typing import Any, Iterable, List, Optional, Tuple

import numpy as np

try:
    import cv2
except ImportError:  # pragma: no cover - depends on runtime environment
    cv2 = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _as_float_array(value: Any, shape: Optional[Tuple[int, ...]] = None) -> Optional[np.ndarray]:
    try:
        arr = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError):
        return None
    if shape is not None and arr.shape != shape:
        return None
    return arr


def _parse_numbers(text: str) -> List[float]:
    return [float(x) for x in re.findall(r"[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?", text)]


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def load_intrinsics(path_or_values: Any) -> np.ndarray:
    """Load intrinsics from fx fy cx cy values, a JSON file, or a plain text file."""
    if isinstance(path_or_values, (list, tuple)) and len(path_or_values) >= 4:
        fx, fy, cx, cy = [float(v) for v in path_or_values[:4]]
        return np.array([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64)

    path = Path(str(path_or_values))
    text = path.read_text(encoding="utf-8") if path.exists() else str(path_or_values)
    if path.exists() and path.suffix.lower() == ".json":
        data = json.loads(text)
        fx, fy, cx, cy = data["fx"], data["fy"], data["cx"], data["cy"]
    else:
        numbers = _parse_numbers(text)
        if len(numbers) < 4:
            raise ValueError(f"Cannot read fx fy cx cy from {path}")
        fx, fy, cx, cy = numbers[:4]
    return np.array([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64)


def quaternion_to_rotation_matrix(qx: float, qy: float, qz: float, qw: float) -> np.ndarray:
    q = np.array([qx, qy, qz, qw], dtype=np.float64)
    norm = np.linalg.norm(q)
    if norm <= 1e-12:
        return np.eye(3, dtype=np.float64)
    x, y, z, w = q / norm
    return np.array(
        [
            [1 - 2 * y * y - 2 * z * z, 2 * x * y - 2 * z * w, 2 * x * z + 2 * y * w],
            [2 * x * y + 2 * z * w, 1 - 2 * x * x - 2 * z * z, 2 * y * z - 2 * x * w],
            [2 * x * z - 2 * y * w, 2 * y * z + 2 * x * w, 1 - 2 * x * x - 2 * y * y],
        ],
        dtype=np.float64,
    )


def load_pose_matrix(path_or_values: Any) -> np.ndarray:
    """Load a camera-to-world pose.

    Supported:
    - 16 numbers: row-major 4x4 camera-to-world matrix
    - 8 numbers: timestamp tx ty tz qx qy qz qw, matching the original pipeline
      convention where the line is interpreted as world-to-camera and inverted.
    """
    if isinstance(path_or_values, np.ndarray):
        arr = _as_float_array(path_or_values, (4, 4))
        if arr is None:
            raise ValueError("Pose array must be 4x4")
        return arr
    if isinstance(path_or_values, (list, tuple)):
        numbers = [float(v) for v in path_or_values]
    else:
        path = Path(str(path_or_values))
        text = path.read_text(encoding="utf-8") if path.exists() else str(path_or_values)
        numbers = _parse_numbers(text)

    if len(numbers) == 16:
        return np.array(numbers, dtype=np.float64).reshape(4, 4)
    if len(numbers) >= 8:
        tx, ty, tz = numbers[1], numbers[2], numbers[3]
        qx, qy, qz, qw = numbers[4], numbers[5], numbers[6], numbers[7]
        T_w2c = np.eye(4, dtype=np.float64)
        T_w2c[:3, :3] = quaternion_to_rotation_matrix(qx, qy, qz, qw)
        T_w2c[:3, 3] = [tx, ty, tz]
        return np.linalg.inv(T_w2c)
    raise ValueError("Pose must contain either 16 matrix values or 8 TUM values")


def load_depth_meters(path: Any, depth_scale: float = 1000.0) -> np.ndarray:
    path = Path(str(path))
    if path.suffix.lower() == ".npy":
        depth = np.load(str(path)).astype(np.float32)
    else:
        if cv2 is None:
            raise ImportError("OpenCV is required to read non-.npy depth images")
        depth = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
        if depth is None:
            raise FileNotFoundError(f"Cannot read depth image: {path}")
        depth = depth.astype(np.float32)
    if np.issubdtype(depth.dtype, np.integer) or float(np.nanmax(depth)) > 100.0:
        depth = depth / float(depth_scale)
    return depth.astype(np.float32)


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def bbox_iou_2d(a: Optional[Iterable[float]], b: Optional[Iterable[float]]) -> float:
    if a is None or b is None:
        return 0.0
    a = list(a)
    b = list(b)
    if len(a) != 4 or len(b) != 4:
        return 0.0
    ax1, ay1, ax2, ay2 = [float(v) for v in a]
    bx1, by1, bx2, by2 = [float(v) for v in b]
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0
