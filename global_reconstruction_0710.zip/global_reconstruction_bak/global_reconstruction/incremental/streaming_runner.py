#!/usr/bin/env python3
"""Replay or watch RGB-D frames and incrementally update a scene graph.

This is the online runner around the one-frame update core in
``incremental_update.py``. It carries the updated scene graph forward after each
new frame instead of rerunning historical reconstruction.

Typical replay usage:

    python -m global_reconstruction.incremental.streaming_runner \
        --scene-graph unified_output/scene_graph.json \
        --data-dir /path/to/rgbd_dataset \
        --output unified_output/scene_graph_streaming.json

With precomputed per-frame detections:

    python -m global_reconstruction.incremental.streaming_runner \
        --scene-graph unified_output/scene_graph.json \
        --data-dir /path/to/rgbd_dataset \
        --detections-dir unified_output/incremental_detections

For live folders, add ``--watch``. The runner will poll for new depth files and
update the scene graph as they arrive.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime
import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from global_reconstruction.core.config_loader import get_config, project_root
from global_reconstruction.incremental.incremental_update import (
    DEFAULT_SAM3_URL,
    DEFAULT_SAM3_BATCH_URL,
    DEFAULT_UPDATE_CONFIG,
    DEFAULT_VLM_MODEL,
    DEFAULT_VLM_URL,
    auto_detect_current_frame,
    load_detections,
    update_scene_graph_with_observation,
)
from global_reconstruction.incremental.object_visibility import (
    quaternion_to_rotation_matrix,
)
from global_reconstruction.reconstruction.voxel_fusion import SparseVoxelFusion


def _to_plain_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    return {}


def _parse_key_values(values: Optional[Sequence[str]]) -> Dict[str, float]:
    result: Dict[str, float] = {}
    for item in values or []:
        if "=" not in str(item):
            continue
        key, value = str(item).split("=", 1)
        try:
            result[key.strip()] = float(value)
        except ValueError:
            continue
    return result


def _parse_categories(value: Optional[str]) -> Optional[List[str]]:
    if not value:
        return None
    categories = []
    for item in str(value).split(","):
        name = item.strip().lower().replace(" ", "_")
        if name:
            categories.append(name)
    return categories or None


def _atomic_write_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    tmp_path.replace(path)


def _resize_array_to_shape(array: np.ndarray, target_shape: Tuple[int, int], linear: bool = False) -> np.ndarray:
    if array.shape[:2] == target_shape:
        return array
    target_h, target_w = target_shape
    try:
        import cv2

        interpolation = cv2.INTER_LINEAR if linear else cv2.INTER_NEAREST
        return cv2.resize(array, (target_w, target_h), interpolation=interpolation)
    except Exception:
        src_h, src_w = array.shape[:2]
        y = np.clip(np.rint(np.linspace(0, src_h - 1, target_h)).astype(np.int64), 0, src_h - 1)
        x = np.clip(np.rint(np.linspace(0, src_w - 1, target_w)).astype(np.int64), 0, src_w - 1)
        if array.ndim == 2:
            return array[y[:, None], x[None, :]]
        return array[y[:, None], x[None, :], :]


def _load_color_for_fusion(
    adapter: DatasetAdapter,
    color_file: Optional[Path],
    depth_shape: Tuple[int, int],
) -> Tuple[np.ndarray, bool]:
    missing = color_file is None
    color = None if color_file is None else adapter.load_color(color_file)
    if color is None:
        color = np.zeros((*depth_shape, 3), dtype=np.uint8)
        missing = True
    else:
        color = _resize_array_to_shape(np.asarray(color), depth_shape, linear=True)
        if color.ndim == 2:
            color = np.repeat(color[:, :, None], 3, axis=2)
        color = np.asarray(color[:, :, :3], dtype=np.uint8)
    return color, missing


def _load_confidence_for_fusion(
    adapter: DatasetAdapter,
    frame_idx: int,
    depth_shape: Tuple[int, int],
) -> Optional[np.ndarray]:
    confidence = adapter.load_confidence(frame_idx)
    if confidence is None:
        return None
    confidence = _resize_array_to_shape(np.asarray(confidence), depth_shape, linear=False)
    return confidence.astype(np.float32)


def _write_basic_ply(path: Path, points: np.ndarray, colors: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    points = np.asarray(points, dtype=np.float32).reshape(-1, 3)
    colors = np.asarray(colors, dtype=np.uint8).reshape(-1, 3)
    n_points = int(len(points))
    vertex_data = np.zeros(
        n_points,
        dtype=[
            ("x", "<f4"),
            ("y", "<f4"),
            ("z", "<f4"),
            ("red", "u1"),
            ("green", "u1"),
            ("blue", "u1"),
        ],
    )
    if n_points:
        vertex_data["x"] = points[:, 0]
        vertex_data["y"] = points[:, 1]
        vertex_data["z"] = points[:, 2]
        vertex_data["red"] = colors[:, 0]
        vertex_data["green"] = colors[:, 1]
        vertex_data["blue"] = colors[:, 2]

    header = f"""ply
format binary_little_endian 1.0
element vertex {n_points}
property float x
property float y
property float z
property uchar red
property uchar green
property uchar blue
end_header
"""
    with path.open("wb") as f:
        f.write(header.encode("ascii"))
        f.write(vertex_data.tobytes())


def _save_point_cloud(path: Path, points: np.ndarray, colors: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    points = np.asarray(points, dtype=np.float32).reshape(-1, 3)
    colors = np.asarray(colors, dtype=np.uint8).reshape(-1, 3)
    try:
        import open3d as o3d

        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points.astype(np.float64))
        pcd.colors = o3d.utility.Vector3dVector(colors.astype(np.float64) / 255.0)
        o3d.io.write_point_cloud(str(path), pcd, write_ascii=False, compressed=True)
    except Exception:
        _write_basic_ply(path, points, colors)


def _output_base_dir(config: Dict[str, Any]) -> Path:
    output_cfg = _to_plain_dict(config.get("output"))
    base = Path(str(output_cfg.get("base_dir", "unified_output")))
    return base if base.is_absolute() else project_root() / base


def _streaming_pointcloud_paths(
    config: Dict[str, Any],
    pointcloud_output_dir: Optional[Path] = None,
    fusion_state_path: Optional[Path] = None,
) -> Dict[str, Path]:
    runner_cfg = _to_plain_dict(config.get("incremental_runner"))
    output_cfg = _to_plain_dict(config.get("output"))
    if pointcloud_output_dir is None:
        subdir = runner_cfg.get("pointcloud_output_dir") or output_cfg.get("global_pointcloud_subdir", "global")
        output_dir = Path(str(subdir))
        if not output_dir.is_absolute():
            output_dir = _output_base_dir(config) / output_dir
    else:
        output_dir = Path(pointcloud_output_dir)

    state_path = Path(fusion_state_path) if fusion_state_path is not None else (
        output_dir / str(runner_cfg.get("fusion_state_file", "voxel_fusion_streaming_state.npz"))
    )
    return {
        "output_dir": output_dir,
        "stable": output_dir / str(runner_cfg.get("pointcloud_file", "global_pointcloud_streaming.ply")),
        "complete": output_dir / str(
            runner_cfg.get("complete_pointcloud_file", "global_pointcloud_streaming_complete.ply")
        ),
        "state": state_path,
        "stats": output_dir / str(runner_cfg.get("fusion_stats_file", "voxel_fusion_streaming_stats.json")),
    }


def _export_fusion_outputs(fusion_map: SparseVoxelFusion, paths: Dict[str, Path]) -> Dict[str, Any]:
    stable_points, stable_colors = fusion_map.to_point_cloud(mode="stable")
    complete_points, complete_colors = fusion_map.to_point_cloud(mode="complete")
    _save_point_cloud(paths["stable"], stable_points, stable_colors)
    _save_point_cloud(paths["complete"], complete_points, complete_colors)
    fusion_map.save_state(paths["state"])

    stats = fusion_map.stats()
    payload = {
        "schema_version": 1,
        "generated_at": datetime.now().isoformat(),
        "stable_pointcloud": str(paths["stable"]),
        "complete_pointcloud": str(paths["complete"]),
        "fusion_state": str(paths["state"]),
        "stats_file": str(paths["stats"]),
        "stable_points": int(len(stable_points)),
        "complete_points": int(len(complete_points)),
        "fusion_stats": stats,
    }
    _atomic_write_json(paths["stats"], payload)
    return payload


def _load_scene_graph(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Scene graph does not exist: {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Scene graph must be a JSON object: {path}")
    return data


def _load_poses(
    pose_file: Path,
    use_axis_transform: bool = False,
    switch_axis: Optional[np.ndarray] = None,
) -> Dict[str, np.ndarray]:
    """Load camera-to-world poses from TUM or row-major 4x4 matrix files."""
    if not pose_file.exists():
        raise FileNotFoundError(f"Pose file does not exist: {pose_file}")

    poses: Dict[str, np.ndarray] = {}
    seq_idx = 0
    switch = np.asarray(switch_axis, dtype=np.float64) if switch_axis is not None else np.eye(4)

    with open(pose_file, "r", encoding="utf-8") as f:
        for line in f:
            raw = line.strip()
            if not raw or raw.startswith("#"):
                continue
            parts = raw.split()
            try:
                numbers = [float(x) for x in parts]
            except ValueError:
                continue

            if len(numbers) == 16:
                T_c2w = np.asarray(numbers, dtype=np.float64).reshape(4, 4)
                timestamp = f"{seq_idx:05d}"
                seq_idx += 1
            elif len(numbers) >= 8:
                timestamp = parts[0]
                tx, ty, tz = numbers[1], numbers[2], numbers[3]
                qx, qy, qz, qw = numbers[4], numbers[5], numbers[6], numbers[7]
                T_w2c = np.eye(4, dtype=np.float64)
                T_w2c[:3, :3] = quaternion_to_rotation_matrix(qx, qy, qz, qw)
                T_w2c[:3, 3] = [tx, ty, tz]
                T_c2w = np.linalg.inv(T_w2c)
            else:
                continue

            if use_axis_transform:
                T_c2w = switch @ T_c2w
            poses[timestamp] = T_c2w

    if not poses:
        raise ValueError(f"No valid poses loaded from: {pose_file}")
    return poses


def _depth_to_meters(depth: np.ndarray, depth_scale: float) -> np.ndarray:
    if depth.dtype == np.uint16:
        return depth.astype(np.float32) / float(depth_scale)
    if depth.dtype == np.uint8:
        return depth.astype(np.float32)
    return depth.astype(np.float32)


def _frame_detection_path(detections_dir: Optional[Path], frame_id: str) -> Optional[Path]:
    if detections_dir is None:
        return None
    candidates = [
        detections_dir / f"{frame_id}.json",
        detections_dir / f"{frame_id}_detections.json",
        detections_dir / f"detections_{frame_id}.json",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _load_frame_detections(detections_dir: Optional[Path], frame_id: str) -> Tuple[List[Dict[str, Any]], Optional[Path]]:
    path = _frame_detection_path(detections_dir, frame_id)
    if path is None:
        return [], None
    return load_detections(str(path)), path


def _save_frame_detections(
    detections_dir: Optional[Path],
    frame_id: str,
    detections: List[Dict[str, Any]],
    auto_detection_info: Optional[Dict[str, Any]],
) -> Optional[Path]:
    if detections_dir is None:
        return None
    path = detections_dir / f"{frame_id}.json"
    _atomic_write_json(path, {"objects": detections, "auto_detection": auto_detection_info})
    return path


def update_scene_graph_for_frame(
    scene_graph: Dict[str, Any],
    depth: np.ndarray,
    K: np.ndarray,
    T_c2w: np.ndarray,
    image_shape: Tuple[int, int],
    detections: Optional[List[Dict[str, Any]]] = None,
    update_config: Optional[Dict[str, Any]] = None,
    frame_id: Optional[str] = None,
    frame_metadata: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Run the one-frame object lifecycle update."""
    updated, report = update_scene_graph_with_observation(
        scene_graph=scene_graph,
        detections=detections or [],
        update_config=update_config,
        frame_id=frame_id,
    )
    report["frame_metadata"] = frame_metadata or {}
    updated["last_incremental_update"] = report
    updated.setdefault("incremental_history", [])
    updated["incremental_history"].append({
        "frame_id": frame_id,
        "updated_at": report.get("generated_at"),
        "summary": report.get("summary", {}),
    })
    max_history = int((update_config or {}).get("history_limit", 200))
    if max_history > 0:
        updated["incremental_history"] = updated["incremental_history"][-max_history:]
    return updated, report


def _selected_depth_files(
    depth_files: Sequence[Path],
    start_index: int = 0,
    end_index: Optional[int] = None,
    max_frames: Optional[int] = None,
    frame_stride: int = 1,
) -> List[Tuple[int, Path]]:
    frame_stride = max(1, int(frame_stride))
    start_index = max(0, int(start_index))
    selected = []
    for idx, depth_file in enumerate(depth_files):
        if idx < start_index:
            continue
        if end_index is not None and idx > end_index:
            continue
        if (idx - start_index) % frame_stride != 0:
            continue
        selected.append((idx, depth_file))
        if max_frames is not None and len(selected) >= max_frames:
            break
    return selected


def process_frame_from_dataset(
    scene_graph: Dict[str, Any],
    adapter: DatasetAdapter,
    poses: Dict[str, np.ndarray],
    file_to_pose: Dict[str, str],
    frame_idx: int,
    depth_file: Path,
    update_config: Dict[str, Any],
    depth_scale: float,
    depth_min: float,
    depth_max: float,
    detections_dir: Optional[Path] = None,
    generated_detections_dir: Optional[Path] = None,
    auto_detect: bool = False,
    categories: Optional[List[str]] = None,
    vlm_url: str = DEFAULT_VLM_URL,
    vlm_model: str = DEFAULT_VLM_MODEL,
    sam3_url: str = DEFAULT_SAM3_URL,
    sam3_batch_url: str = DEFAULT_SAM3_BATCH_URL,
    sam3_max_detections: int = 5,
    min_detection_points: int = 30,
    fusion_map: Optional[SparseVoxelFusion] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    frame_id = depth_file.stem
    if frame_id not in file_to_pose:
        raise KeyError(f"No pose timestamp mapped for depth frame: {depth_file.name}")
    pose_timestamp = file_to_pose[frame_id]
    if pose_timestamp not in poses:
        raise KeyError(f"Pose timestamp not found: {pose_timestamp}")

    depth = adapter.load_depth(depth_file, target_resolution=adapter.rgb_resolution)
    if depth is None:
        raise FileNotFoundError(f"Cannot load depth: {depth_file}")
    depth = _depth_to_meters(depth, depth_scale)

    K = adapter.get_K_for_frame(frame_idx)
    T_c2w = poses[pose_timestamp]
    color_file = adapter.match_color_file(frame_id)
    pointcloud_fusion_info = None

    if fusion_map is not None:
        color, color_missing = _load_color_for_fusion(
            adapter=adapter,
            color_file=color_file,
            depth_shape=(int(depth.shape[0]), int(depth.shape[1])),
        )
        confidence = _load_confidence_for_fusion(
            adapter=adapter,
            frame_idx=frame_idx,
            depth_shape=(int(depth.shape[0]), int(depth.shape[1])),
        )
        integration_stats = fusion_map.integrate(
            depth=depth,
            color=color,
            K=K,
            T_c2w=T_c2w,
            confidence=confidence,
            frame_id=frame_id,
        )
        pointcloud_fusion_info = {
            **integration_stats,
            "enabled": True,
            "color_missing": color_missing,
            "confidence_used": confidence is not None,
            "frames_integrated": fusion_map.stats().get("frames_integrated", 0),
        }

    detections, detection_path = _load_frame_detections(detections_dir, frame_id)
    auto_detection_info = None
    auto_detection_error = None

    if auto_detect and not detections:
        if color_file is None:
            auto_detection_error = "missing_color_file"
        else:
            try:
                detections, auto_detection_info = auto_detect_current_frame(
                    image_path=color_file,
                    scene_graph=scene_graph,
                    depth=depth,
                    K=K,
                    T_c2w=T_c2w,
                    categories=categories,
                    vlm_url=vlm_url,
                    vlm_model=vlm_model,
                    sam3_url=sam3_url,
                    sam3_batch_url=sam3_batch_url,
                    sam3_max_detections=sam3_max_detections,
                    min_points=min_detection_points,
                    depth_min=depth_min,
                    depth_max=depth_max,
                )
                detection_path = _save_frame_detections(
                    generated_detections_dir,
                    frame_id,
                    detections,
                    auto_detection_info,
                )
            except Exception as exc:  # pragma: no cover - service/runtime dependent
                auto_detection_error = f"{type(exc).__name__}: {exc}"

    frame_metadata = {
        "frame_index": frame_idx,
        "frame_id": frame_id,
        "depth_file": str(depth_file),
        "color_file": str(color_file) if color_file else None,
        "pose_timestamp": pose_timestamp,
        "detections_file": str(detection_path) if detection_path else None,
        "auto_detection": auto_detection_info,
        "auto_detection_error": auto_detection_error,
        "image_shape": [int(depth.shape[0]), int(depth.shape[1])],
        "num_detections": len(detections),
        "pointcloud_fusion": pointcloud_fusion_info,
    }
    updated, report = update_scene_graph_for_frame(
        scene_graph=scene_graph,
        depth=depth,
        K=K,
        T_c2w=T_c2w,
        image_shape=(int(depth.shape[0]), int(depth.shape[1])),
        detections=detections,
        update_config=update_config,
        frame_id=frame_id,
        frame_metadata=frame_metadata,
    )
    return updated, report


def run_stream(
    scene_graph_path: Path,
    data_dir: Path,
    output_path: Path,
    report_dir: Path,
    config: Dict[str, Any],
    detections_dir: Optional[Path] = None,
    generated_detections_dir: Optional[Path] = None,
    start_index: int = 0,
    end_index: Optional[int] = None,
    max_frames: Optional[int] = None,
    frame_stride: int = 1,
    auto_detect: bool = False,
    categories: Optional[List[str]] = None,
    watch: bool = False,
    poll_seconds: float = 1.0,
    idle_timeout_seconds: float = 0.0,
    in_place: bool = False,
    update_pointcloud: bool = False,
    pointcloud_output_dir: Optional[Path] = None,
    fusion_state_path: Optional[Path] = None,
    pointcloud_save_every_frames: int = 1,
) -> Dict[str, Any]:
    from global_reconstruction.core.data_adapter import DatasetAdapter

    adapter = DatasetAdapter(data_dir)
    cfg_coordinate = _to_plain_dict(config.get("coordinate"))
    use_axis_transform = bool(cfg_coordinate.get("use_axis_transform", False)) and adapter.dataset_type != "da3_ezviz"
    switch_axis = np.asarray(cfg_coordinate.get("switch_axis", np.eye(4)), dtype=np.float64)
    poses = _load_poses(adapter.poses_file, use_axis_transform=use_axis_transform, switch_axis=switch_axis)
    file_to_pose = adapter.build_pose_timestamp_map(poses)

    scene_graph = _load_scene_graph(scene_graph_path)
    if in_place:
        output_path = scene_graph_path

    reconstruction_cfg = _to_plain_dict(config.get("reconstruction"))
    runner_cfg = _to_plain_dict(config.get("incremental_runner"))
    update_config = dict(DEFAULT_UPDATE_CONFIG)
    update_config.update(_to_plain_dict(config.get("object_lifecycle")))
    services = _to_plain_dict(config.get("services"))
    models = _to_plain_dict(config.get("models"))

    depth_scale = float(reconstruction_cfg.get("depth_scale", 1000.0))
    depth_min = float(reconstruction_cfg.get("depth_min", 0.0))
    depth_max = float(reconstruction_cfg.get("depth_max", 15.0))
    vlm_url = str(services.get("vlm_api_url") or DEFAULT_VLM_URL)
    vlm_model = str(models.get("vlm_model_name") or DEFAULT_VLM_MODEL)
    sam3_url = str(services.get("sam3_url") or DEFAULT_SAM3_URL)
    sam3_batch_url = sam3_url.rsplit("/", 1)[0] + "/predict_batch"
    sam3_max_detections = int(_to_plain_dict(config.get("object_segmentation")).get("sam3_max_detections_per_category", 5))
    min_detection_points = int(runner_cfg.get("min_detection_points", 30))
    pointcloud_save_every_frames = max(1, int(pointcloud_save_every_frames))

    fusion_map: Optional[SparseVoxelFusion] = None
    fusion_paths: Optional[Dict[str, Path]] = None
    latest_pointcloud_export: Optional[Dict[str, Any]] = None
    if update_pointcloud:
        fusion_cfg = _to_plain_dict(reconstruction_cfg.get("fusion"))
        if not bool(fusion_cfg.get("enabled", True)):
            print("Point cloud update requested, but reconstruction.fusion.enabled is false; skipping fusion.")
        else:
            fusion_paths = _streaming_pointcloud_paths(
                config=config,
                pointcloud_output_dir=pointcloud_output_dir,
                fusion_state_path=fusion_state_path,
            )
            if fusion_paths["state"].exists():
                fusion_map = SparseVoxelFusion.load_state(fusion_paths["state"])
                print(f"Loaded streaming point cloud state: {fusion_paths['state']}")
            else:
                fusion_map = SparseVoxelFusion.from_config(
                    fusion_cfg,
                    voxel_size=float(reconstruction_cfg.get("voxel_size", 0.02)),
                    depth_min=depth_min,
                    depth_max=depth_max,
                    confidence_threshold=float(reconstruction_cfg.get("confidence_threshold", 0.0)),
                )
                print(f"Initialized streaming point cloud state: {fusion_paths['state']}")

    processed: List[Dict[str, Any]] = []
    failed: List[Dict[str, Any]] = []
    processed_frame_ids = set()
    idle_start: Optional[float] = None

    while True:
        depth_files = adapter.get_depth_file_list()
        selected = _selected_depth_files(
            depth_files,
            start_index=start_index,
            end_index=end_index,
            max_frames=max_frames,
            frame_stride=frame_stride,
        )
        pending = [(idx, path) for idx, path in selected if path.stem not in processed_frame_ids]

        if not pending:
            if not watch:
                break
            if idle_start is None:
                idle_start = time.time()
            if idle_timeout_seconds > 0 and time.time() - idle_start >= idle_timeout_seconds:
                break
            time.sleep(max(0.1, float(poll_seconds)))
            continue

        idle_start = None
        for frame_idx, depth_file in pending:
            frame_id = depth_file.stem
            try:
                scene_graph, report = process_frame_from_dataset(
                    scene_graph=scene_graph,
                    adapter=adapter,
                    poses=poses,
                    file_to_pose=file_to_pose,
                    frame_idx=frame_idx,
                    depth_file=depth_file,
                    update_config=update_config,
                    depth_scale=depth_scale,
                    depth_min=depth_min,
                    depth_max=depth_max,
                    detections_dir=detections_dir,
                    generated_detections_dir=generated_detections_dir,
                    auto_detect=auto_detect,
                    categories=categories,
                    vlm_url=vlm_url,
                    vlm_model=vlm_model,
                    sam3_url=sam3_url,
                    sam3_batch_url=sam3_batch_url,
                    sam3_max_detections=sam3_max_detections,
                    min_detection_points=min_detection_points,
                    fusion_map=fusion_map,
                )
                report_path = report_dir / f"{frame_id}_object_update_report.json"
                _atomic_write_json(report_path, report)
                _atomic_write_json(output_path, scene_graph)
                if fusion_map is not None and fusion_paths is not None:
                    next_count = len(processed) + 1
                    if next_count % pointcloud_save_every_frames == 0:
                        latest_pointcloud_export = _export_fusion_outputs(fusion_map, fusion_paths)
                processed.append({
                    "frame_id": frame_id,
                    "frame_index": frame_idx,
                    "report": str(report_path),
                    "summary": report.get("summary", {}),
                    "pointcloud_fusion": report.get("frame_metadata", {}).get("pointcloud_fusion"),
                })
                processed_frame_ids.add(frame_id)
                summary = report.get("summary", {})
                fusion_stats = fusion_map.stats() if fusion_map is not None else None
                pc_msg = ""
                if fusion_stats:
                    pc_msg = (
                        f" stable_voxels={fusion_stats.get('stable_exported_voxels', 0)} "
                        f"complete_voxels={fusion_stats.get('complete_exported_voxels', 0)}"
                    )
                print(
                    f"[{frame_id}] objects={summary.get('objects_total', 0)} "
                    f"new={summary.get('new_detection', 0)} "
                    f"merged={summary.get('merged', 0)} "
                    f"moved={summary.get('moved', 0)} "
                    f"missing={summary.get('missing_evidence', 0)} "
                    f"disappeared={summary.get('disappeared', 0)}"
                    f"{pc_msg}"
                )
            except Exception as exc:
                failure = {
                    "frame_id": frame_id,
                    "frame_index": frame_idx,
                    "error": f"{type(exc).__name__}: {exc}",
                }
                failed.append(failure)
                processed_frame_ids.add(frame_id)
                print(f"[{frame_id}] failed: {failure['error']}")

            if max_frames is not None and len(processed) >= max_frames:
                watch = False
                break

    if fusion_map is not None and fusion_paths is not None:
        latest_pointcloud_export = _export_fusion_outputs(fusion_map, fusion_paths)

    stream_report = {
        "schema_version": 1,
        "generated_at": datetime.now().isoformat(),
        "scene_graph_input": str(scene_graph_path),
        "scene_graph_output": str(output_path),
        "data_dir": str(data_dir),
        "frames_processed": len(processed),
        "frames_failed": len(failed),
        "processed": processed,
        "failed": failed,
        "pointcloud_update": {
            "enabled": fusion_map is not None,
            "output_dir": str(fusion_paths["output_dir"]) if fusion_paths else None,
            "stable_pointcloud": str(fusion_paths["stable"]) if fusion_paths else None,
            "complete_pointcloud": str(fusion_paths["complete"]) if fusion_paths else None,
            "fusion_state": str(fusion_paths["state"]) if fusion_paths else None,
            "stats_file": str(fusion_paths["stats"]) if fusion_paths else None,
            "latest_export": latest_pointcloud_export,
        },
    }
    _atomic_write_json(report_dir / "stream_update_report.json", stream_report)
    _atomic_write_json(output_path, scene_graph)
    return stream_report


def _default_output_paths(config: Dict[str, Any]) -> Tuple[Path, Path, Path]:
    root = project_root()
    output_cfg = _to_plain_dict(config.get("output"))
    base = root / str(output_cfg.get("base_dir", "unified_output"))
    scene_graph = base / str(output_cfg.get("scene_graph_file", "scene_graph.json"))
    runner_cfg = _to_plain_dict(config.get("incremental_runner"))
    output = base / str(runner_cfg.get("output_scene_graph", "scene_graph_streaming.json"))
    report_dir = base / str(runner_cfg.get("report_dir", "incremental_reports"))
    return scene_graph, output, report_dir


def _load_config_for_cli() -> Dict[str, Any]:
    try:
        return dict(get_config())
    except ImportError:
        if any(arg in {"-h", "--help"} for arg in sys.argv[1:]):
            return {}
        raise


def main() -> None:
    config = _load_config_for_cli()
    default_scene_graph, default_output, default_report_dir = _default_output_paths(config)
    runner_cfg = _to_plain_dict(config.get("incremental_runner"))

    parser = argparse.ArgumentParser(description="Streaming/replay object-level scene graph updater")
    parser.add_argument("--scene-graph", default=str(default_scene_graph), help="Initial scene_graph.json")
    parser.add_argument("--data-dir", default=str(config.get("data", {}).get("default_dir", "")), help="RGB-D dataset directory")
    parser.add_argument("--output", default=str(default_output), help="Updated rolling scene graph output")
    parser.add_argument("--report-dir", default=str(default_report_dir), help="Per-frame and stream report directory")
    parser.add_argument("--detections-dir", default=None, help="Optional directory with per-frame detection JSON files")
    parser.add_argument("--generated-detections-dir", default=None, help="Directory to save auto-detected per-frame detections")
    parser.add_argument(
        "--update-pointcloud",
        dest="update_pointcloud",
        action="store_true",
        default=bool(runner_cfg.get("update_pointcloud", False)),
        help="Incrementally update the streaming scene point cloud",
    )
    parser.add_argument(
        "--no-update-pointcloud",
        dest="update_pointcloud",
        action="store_false",
        help="Disable streaming scene point cloud updates",
    )
    parser.add_argument("--pointcloud-output-dir", default=None, help="Directory for streaming point cloud outputs")
    parser.add_argument("--fusion-state", default=None, help="Path to voxel fusion state NPZ")
    parser.add_argument(
        "--pointcloud-save-every-frames",
        type=int,
        default=int(runner_cfg.get("pointcloud_save_every_frames", 1)),
    )
    parser.add_argument("--start-index", type=int, default=int(runner_cfg.get("start_index", 0)))
    parser.add_argument("--end-index", type=int, default=None)
    parser.add_argument("--max-frames", type=int, default=runner_cfg.get("max_frames"))
    parser.add_argument("--frame-stride", type=int, default=int(runner_cfg.get("frame_stride", 1)))
    parser.add_argument("--auto-detect", action="store_true", default=bool(runner_cfg.get("auto_detect", False)))
    parser.add_argument("--categories", default=None, help="Comma-separated categories for SAM3; skips VLM category discovery")
    parser.add_argument("--watch", action="store_true", help="Poll data directory for new frames")
    parser.add_argument("--poll-seconds", type=float, default=float(runner_cfg.get("watch_poll_seconds", 1.0)))
    parser.add_argument("--idle-timeout-seconds", type=float, default=float(runner_cfg.get("watch_idle_timeout_seconds", 0.0)))
    parser.add_argument("--in-place", action="store_true", help="Overwrite --scene-graph after every processed frame")
    parser.add_argument("--update-param", action="append", default=[], help="Override update threshold, key=value")
    args = parser.parse_args()

    config.setdefault("object_lifecycle", {})
    config["object_lifecycle"].update(_parse_key_values(args.update_param))

    report = run_stream(
        scene_graph_path=Path(args.scene_graph),
        data_dir=Path(args.data_dir),
        output_path=Path(args.output),
        report_dir=Path(args.report_dir),
        config=config,
        detections_dir=Path(args.detections_dir) if args.detections_dir else None,
        generated_detections_dir=Path(args.generated_detections_dir) if args.generated_detections_dir else (
            Path(args.report_dir) / "detections" if args.auto_detect else None
        ),
        start_index=args.start_index,
        end_index=args.end_index,
        max_frames=args.max_frames,
        frame_stride=args.frame_stride,
        auto_detect=args.auto_detect,
        categories=_parse_categories(args.categories),
        watch=args.watch,
        poll_seconds=args.poll_seconds,
        idle_timeout_seconds=args.idle_timeout_seconds,
        in_place=args.in_place,
        update_pointcloud=args.update_pointcloud,
        pointcloud_output_dir=Path(args.pointcloud_output_dir) if args.pointcloud_output_dir else None,
        fusion_state_path=Path(args.fusion_state) if args.fusion_state else None,
        pointcloud_save_every_frames=args.pointcloud_save_every_frames,
    )
    print(f"Streaming update complete: {report['frames_processed']} frames, {report['frames_failed']} failed")
    print(f"Updated scene graph: {args.scene_graph if args.in_place else args.output}")
    print(f"Stream report: {Path(args.report_dir) / 'stream_update_report.json'}")
    if report.get("pointcloud_update", {}).get("enabled"):
        pointcloud_info = report["pointcloud_update"]
        print(f"Streaming stable point cloud: {pointcloud_info.get('stable_pointcloud')}")
        print(f"Streaming fusion state: {pointcloud_info.get('fusion_state')}")


if __name__ == "__main__":
    main()
