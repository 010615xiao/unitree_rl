import json
import numpy as np
from collections import defaultdict
from typing import Dict, List, Tuple, Set

class FinalObjectLifecycleTracker:
    """追踪最终稳定物体的生命周期"""
    
    def __init__(self):
        self.final_objects = []  # 最终稳定物体列表
        self.final_to_instances = {}  # final_object_id -> List[instance_id]
        self.instance_to_final = {}  # instance_id -> final_object_id
        
    def register_final_object(
        self,
        final_object_id: int,
        category: str,
        points: np.ndarray,
        instance_ids: List[int],
        merge_source: str,  # "iterative_merge" or "background_merge"
        metadata: Dict = None
    ):
        """注册一个最终稳定物体"""
        obj = {
            'final_object_id': final_object_id,
            'category': category,
            'num_points': len(points),
            'center': points.mean(axis=0).tolist(),
            'bbox': {
                'min': points.min(axis=0).tolist(),
                'max': points.max(axis=0).tolist()
            },
            'source_instance_ids': instance_ids,
            'merge_source': merge_source,
            'metadata': metadata or {}
        }
        
        self.final_objects.append(obj)
        self.final_to_instances[final_object_id] = instance_ids
        
        # 建立反向映射
        for inst_id in instance_ids:
            self.instance_to_final[inst_id] = final_object_id
    
    def get_final_object_for_instance(self, instance_id: int) -> int:
        """获取某个原始实例所属的最终物体ID"""
        return self.instance_to_final.get(instance_id)
    
    def get_instances_for_final_object(self, final_object_id: int) -> List[int]:
        """获取某个最终物体包含的所有原始实例ID"""
        return self.final_to_instances.get(final_object_id, [])
    
    def generate_lifecycle_report(self, original_instances: List[Dict]) -> Dict:
        """生成最终物体的生命周期报告"""
        report = {
            'total_final_objects': len(self.final_objects),
            'total_original_instances': len(original_instances),
            'final_objects': []
        }
        
        for final_obj in self.final_objects:
            final_id = final_obj['final_object_id']
            instance_ids = final_obj['source_instance_ids']
            
            # 统计该最终物体包含的所有实例的状态
            instance_states = defaultdict(int)
            birth_frames = []
            last_seen_frames = []
            
            for inst_id in instance_ids:
                if inst_id < len(original_instances):
                    inst = original_instances[inst_id]
                    state = inst.get('current_state', 'unknown')
                    instance_states[state] += 1
                    if 'birth_frame' in inst:
                        birth_frames.append(inst['birth_frame'])
                    if 'last_seen_frame' in inst:
                        last_seen_frames.append(inst['last_seen_frame'])
            
            # 确定最终物体的生命周期信息
            birth_frame = min(birth_frames) if birth_frames else None
            last_seen_frame = max(last_seen_frames) if last_seen_frames else None
            
            # 确定最终状态（基于实例状态的多数投票）
            dominant_state = max(instance_states.items(), key=lambda x: x[1])[0] if instance_states else 'unknown'
            
            final_report = {
                **final_obj,
                'lifecycle': {
                    'birth_frame': birth_frame,
                    'last_seen_frame': last_seen_frame,
                    'num_source_instances': len(instance_ids),
                    'instance_state_distribution': dict(instance_states),
                    'dominant_state': dominant_state,
                    'merge_source': final_obj['merge_source']
                }
            }
            
            report['final_objects'].append(final_report)
        
        return report
    
    def save(self, output_path: str):
        """保存最终物体的生命周期信息"""
        output = {
            'final_objects': self.final_objects,
            'final_to_instances': {str(k): v for k, v in self.final_to_instances.items()},
            'instance_to_final': {str(k): v for k, v in self.instance_to_final.items()}
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2, ensure_ascii=False)
        
        print(f"✓ 最终物体生命周期信息已保存到: {output_path}")
    
    @staticmethod
    def load(loaded_path: str) -> 'FinalObjectLifecycleTracker':
        """加载最终物体的生命周期信息"""
        tracker = FinalObjectLifecycleTracker()
        
        with open(loaded_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        tracker.final_objects = data['final_objects']
        tracker.final_to_instances = {int(k): v for k, v in data['final_to_instances'].items()}
        tracker.instance_to_final = {int(k): v for k, v in data['instance_to_final'].items()}
        
        return tracker
