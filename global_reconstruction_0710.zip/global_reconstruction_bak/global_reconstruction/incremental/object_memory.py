"""Object-level scene graph update utilities.

This module compares a freshly reconstructed object list with the previous
scene graph and annotates object lifecycle events:

- new: object was not present before
- merged: current observation matches an existing persistent object
- moved: current observation matches an existing object but center shifted
- reappeared: object was missing before and is now observed again
- missing/disappeared: previous object was not observed in the current run

The update is intentionally object-level. It does not edit the global point
cloud or navigation graph; those can be layered on top later.
"""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime
import math
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple


Vec3 = Tuple[float, float, float]
BBox = Tuple[Vec3, Vec3]


DEFAULT_LIFECYCLE_CONFIG: Dict[str, float] = {
    "bbox_iou_threshold": 0.08,
    "bbox_overlap_threshold": 0.25,
    "same_object_center_distance": 0.8,
    "move_distance_threshold": 0.6,
    "max_move_distance": 3.0,
    "disappear_after_misses": 2,
}


def _slug(value: Any) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "_", str(value or "object").lower()).strip("_")
    return text or "object"


def _to_vec3(value: Any) -> Optional[Vec3]:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return None
    try:
        return (float(value[0]), float(value[1]), float(value[2]))
    except (TypeError, ValueError):
        return None


def _bbox_from_record(record: Dict[str, Any]) -> Optional[BBox]:
    bbox = record.get("bbox")
    if isinstance(bbox, dict):
        lower = _to_vec3(bbox.get("min"))
        upper = _to_vec3(bbox.get("max"))
        if lower is not None and upper is not None:
            return lower, upper
    return None


def _center_from_record(record: Dict[str, Any]) -> Optional[Vec3]:
    center = _to_vec3(record.get("center"))
    if center is not None:
        return center
    bbox = _bbox_from_record(record)
    if bbox is None:
        return None
    lower, upper = bbox
    return tuple((lower[i] + upper[i]) * 0.5 for i in range(3))  # type: ignore[return-value]


def _category(record: Dict[str, Any]) -> str:
    return _slug(record.get("category"))


def _volume(bbox: BBox) -> float:
    lower, upper = bbox
    size = [max(0.0, upper[i] - lower[i]) for i in range(3)]
    return size[0] * size[1] * size[2]


def _distance(a: Vec3, b: Vec3) -> float:
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(3)))


def _bbox_metrics(a: Optional[BBox], b: Optional[BBox]) -> Dict[str, float]:
    if a is None or b is None:
        return {"iou": 0.0, "overlap_a": 0.0, "overlap_b": 0.0, "overlap": 0.0}

    a_min, a_max = a
    b_min, b_max = b
    inter_min = tuple(max(a_min[i], b_min[i]) for i in range(3))
    inter_max = tuple(min(a_max[i], b_max[i]) for i in range(3))
    inter_size = [max(0.0, inter_max[i] - inter_min[i]) for i in range(3)]
    inter_vol = inter_size[0] * inter_size[1] * inter_size[2]
    vol_a = _volume(a)
    vol_b = _volume(b)
    union = vol_a + vol_b - inter_vol

    overlap_a = inter_vol / vol_a if vol_a > 0 else 0.0
    overlap_b = inter_vol / vol_b if vol_b > 0 else 0.0
    return {
        "iou": inter_vol / union if union > 0 else 0.0,
        "overlap_a": overlap_a,
        "overlap_b": overlap_b,
        "overlap": max(overlap_a, overlap_b),
    }


def _persistent_id(record: Dict[str, Any]) -> Optional[str]:
    lifecycle = record.get("lifecycle") if isinstance(record.get("lifecycle"), dict) else {}
    object_update = record.get("object_update") if isinstance(record.get("object_update"), dict) else {}
    value = (
        record.get("persistent_id")
        or lifecycle.get("persistent_id")
        or object_update.get("persistent_id")
        or record.get("name")
    )
    return str(value) if value else None


def _previous_candidates(previous_scene_graph: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not isinstance(previous_scene_graph, dict):
        return []

    candidates: List[Dict[str, Any]] = []
    for obj in previous_scene_graph.get("objects", []) or []:
        if isinstance(obj, dict):
            candidates.append(deepcopy(obj))

    update = previous_scene_graph.get("object_update")
    if isinstance(update, dict):
        for obj in update.get("missing_objects", []) or []:
            if isinstance(obj, dict):
                status = (obj.get("lifecycle") or {}).get("status")
                if status != "disappeared":
                    candidates.append(deepcopy(obj))

    seen = set()
    deduped = []
    for obj in candidates:
        pid = _persistent_id(obj) or f"legacy_{obj.get('id', len(deduped))}"
        if pid in seen:
            continue
        seen.add(pid)
        obj["persistent_id"] = pid
        deduped.append(obj)
    return deduped


def _next_persistent_id(category: str, used_ids: set) -> str:
    base = _slug(category)
    index = 0
    while True:
        candidate = f"{base}_{index}"
        if candidate not in used_ids:
            used_ids.add(candidate)
            return candidate
        index += 1


def _match_candidate(
    prev: Dict[str, Any],
    current: Dict[str, Any],
    cfg: Dict[str, float],
) -> Optional[Dict[str, Any]]:
    if _category(prev) != _category(current):
        return None

    prev_center = _center_from_record(prev)
    current_center = _center_from_record(current)
    if prev_center is None or current_center is None:
        return None

    distance = _distance(prev_center, current_center)
    metrics = _bbox_metrics(_bbox_from_record(prev), _bbox_from_record(current))
    same_room = prev.get("room_id") is not None and prev.get("room_id") == current.get("room_id")
    same_floor = prev.get("floor_id") is not None and prev.get("floor_id") == current.get("floor_id")

    qualifies = (
        metrics["iou"] >= cfg["bbox_iou_threshold"]
        or metrics["overlap"] >= cfg["bbox_overlap_threshold"]
        or distance <= cfg["same_object_center_distance"]
        or (distance <= cfg["max_move_distance"] and (same_room or same_floor))
    )
    if not qualifies:
        return None

    proximity = max(0.0, 1.0 - distance / max(cfg["max_move_distance"], 1e-6))
    score = 2.0 * metrics["iou"] + metrics["overlap"] + proximity
    if same_room:
        score += 0.25
    if same_floor:
        score += 0.10

    return {
        "score": round(float(score), 6),
        "center_distance": round(float(distance), 6),
        "bbox_iou": round(float(metrics["iou"]), 6),
        "bbox_overlap": round(float(metrics["overlap"]), 6),
        "same_room": bool(same_room),
        "same_floor": bool(same_floor),
    }


def _previous_missed_count(record: Dict[str, Any]) -> int:
    lifecycle = record.get("lifecycle")
    if isinstance(lifecycle, dict):
        try:
            return int(lifecycle.get("missed_observations", 0))
        except (TypeError, ValueError):
            return 0
    return 0


def annotate_scene_graph_with_object_updates(
    scene_graph: Dict[str, Any],
    previous_scene_graph: Optional[Dict[str, Any]] = None,
    config: Optional[Dict[str, Any]] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Annotate current objects with persistent IDs and lifecycle events."""

    cfg = dict(DEFAULT_LIFECYCLE_CONFIG)
    for key, value in (config or {}).items():
        if key in cfg and value is not None:
            try:
                cfg[key] = float(value)
            except (TypeError, ValueError):
                pass
    cfg["disappear_after_misses"] = max(1, int(cfg["disappear_after_misses"]))

    current_objects = scene_graph.get("objects", []) or []
    previous_objects = _previous_candidates(previous_scene_graph)

    used_ids = {
        pid
        for pid in (_persistent_id(obj) for obj in previous_objects)
        if pid
    }
    matched_previous = set()
    events: List[Dict[str, Any]] = []

    for current in current_objects:
        best_prev_idx = None
        best_match = None
        for idx, prev in enumerate(previous_objects):
            if idx in matched_previous:
                continue
            candidate = _match_candidate(prev, current, cfg)
            if candidate is None:
                continue
            if best_match is None or candidate["score"] > best_match["score"]:
                best_prev_idx = idx
                best_match = candidate

        if best_prev_idx is None or best_match is None:
            pid = _next_persistent_id(_category(current), used_ids)
            lifecycle = {
                "persistent_id": pid,
                "status": "active",
                "event": "new",
                "missed_observations": 0,
                "first_observed_in_current_run": True,
            }
            current["persistent_id"] = pid
            current["lifecycle"] = lifecycle
            events.append({
                "type": "new",
                "persistent_id": pid,
                "current_id": current.get("id"),
                "category": current.get("category"),
                "center": current.get("center"),
            })
            continue

        prev = previous_objects[best_prev_idx]
        matched_previous.add(best_prev_idx)
        pid = _persistent_id(prev) or _next_persistent_id(_category(current), used_ids)
        used_ids.add(pid)

        prev_status = (prev.get("lifecycle") or {}).get("status") if isinstance(prev.get("lifecycle"), dict) else None
        moved = (
            best_match["center_distance"] >= cfg["move_distance_threshold"]
            and best_match["bbox_iou"] < cfg["bbox_iou_threshold"]
        )
        if prev_status == "missing":
            event_type = "reappeared"
        elif moved:
            event_type = "moved"
        else:
            event_type = "merged"

        lifecycle = {
            "persistent_id": pid,
            "status": "active",
            "event": event_type,
            "missed_observations": 0,
            "previous_object_id": prev.get("id"),
            "previous_name": prev.get("name"),
            "previous_center": prev.get("center"),
            **best_match,
        }
        current["persistent_id"] = pid
        current["lifecycle"] = lifecycle
        events.append({
            "type": event_type,
            "persistent_id": pid,
            "previous_id": prev.get("id"),
            "current_id": current.get("id"),
            "category": current.get("category"),
            "center_distance": best_match["center_distance"],
            "bbox_iou": best_match["bbox_iou"],
            "bbox_overlap": best_match["bbox_overlap"],
        })

    missing_objects = []
    for idx, prev in enumerate(previous_objects):
        if idx in matched_previous:
            continue
        missed = _previous_missed_count(prev) + 1
        status = "disappeared" if missed >= cfg["disappear_after_misses"] else "missing"
        pid = _persistent_id(prev) or _next_persistent_id(_category(prev), used_ids)
        missing_record = deepcopy(prev)
        missing_record["persistent_id"] = pid
        missing_record["lifecycle"] = {
            "persistent_id": pid,
            "status": status,
            "event": status,
            "missed_observations": missed,
            "last_observed_center": prev.get("center"),
            "last_observed_name": prev.get("name"),
        }
        missing_objects.append(missing_record)
        events.append({
            "type": status,
            "persistent_id": pid,
            "previous_id": prev.get("id"),
            "category": prev.get("category"),
            "missed_observations": missed,
            "last_observed_center": prev.get("center"),
        })

    summary = {
        "active": len(current_objects),
        "new": sum(1 for event in events if event["type"] == "new"),
        "merged": sum(1 for event in events if event["type"] == "merged"),
        "moved": sum(1 for event in events if event["type"] == "moved"),
        "reappeared": sum(1 for event in events if event["type"] == "reappeared"),
        "missing": sum(1 for event in events if event["type"] == "missing"),
        "disappeared": sum(1 for event in events if event["type"] == "disappeared"),
    }

    report = {
        "schema_version": 1,
        "generated_at": datetime.now().isoformat(),
        "previous_object_count": len(previous_objects),
        "current_object_count": len(current_objects),
        "summary": summary,
        "thresholds": cfg,
        "events": events,
        "missing_objects": missing_objects,
    }

    scene_graph["objects"] = current_objects
    scene_graph["object_update"] = report
    return scene_graph, report
