"""Struct-of-Arrays storage for sparse voxel fusion.

Replaces dict[VoxelKey, VoxelRecord] with parallel NumPy arrays for
Numba-compatible access. A numba.typed.Dict provides O(1) key→index lookup.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from numba import typed as numba_typed
from numba.core import types as numba_types

VoxelKey = Tuple[int, int, int]

INITIAL_CAPACITY = 65536
_SENTINEL = -1  # sentinel for "no value" in optional int fields
_NAN = np.nan


@dataclass
class VoxelRecord:
    """Backward-compatible voxel record (used only for .records materialization)."""
    point_sum: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    color_sum: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    weight: float = 0.0
    hit_count: int = 0
    pixel_count: int = 0
    free_count: int = 0
    log_odds: float = 0.0
    first_seen_frame: Optional[Any] = None
    last_seen_frame: Optional[Any] = None
    first_seen_index: int = -1
    last_seen_index: int = -1
    is_stable: bool = False
    promoted_frame_index: Optional[int] = None
    inactive_candidate: bool = False
    inactive_frame_index: Optional[int] = None
    first_camera_center: Optional[np.ndarray] = None
    last_camera_center: Optional[np.ndarray] = None
    first_view_dir: Optional[np.ndarray] = None
    last_view_dir: Optional[np.ndarray] = None
    max_observation_baseline: float = 0.0
    max_view_angle_degrees: float = 0.0
    consecutive_free_streak: int = 0


def _make_key_to_idx() -> numba_typed.Dict:
    """Create an empty numba typed dict for voxel key → index mapping."""
    d = numba_typed.Dict.empty(
        key_type=numba_types.UniTuple(numba_types.int64, 3),
        value_type=numba_types.int64,
    )
    return d


class VoxelSoA:
    """Structure-of-Arrays storage for sparse voxel map.

    All voxel data is stored in parallel NumPy arrays indexed by integer row.
    A numba.typed.Dict maps (x,y,z) voxel keys to row indices.

    Deletion uses swap-with-last: the last active row is moved into the
    deleted slot, keeping arrays compact. The key_to_idx mapping is updated
    for the moved row.
    """

    def __init__(self, capacity: int = INITIAL_CAPACITY) -> None:
        self._cap = capacity
        self._n = 0  # number of active voxels
        self._n_arr = np.zeros(1, dtype=np.int64)  # mutable pointer for Numba

        # Key array (voxel coordinates)
        self.keys = np.zeros((capacity, 3), dtype=np.int64)

        # Scalar fields (1D)
        self.point_sum = np.zeros((capacity, 3), dtype=np.float64)
        self.color_sum = np.zeros((capacity, 3), dtype=np.float64)
        self.weight = np.zeros(capacity, dtype=np.float64)
        self.hit_count = np.zeros(capacity, dtype=np.int64)
        self.pixel_count = np.zeros(capacity, dtype=np.int64)
        self.free_count = np.zeros(capacity, dtype=np.int64)
        self.log_odds = np.zeros(capacity, dtype=np.float64)
        self.first_seen_index = np.full(capacity, _SENTINEL, dtype=np.int64)
        self.last_seen_index = np.full(capacity, _SENTINEL, dtype=np.int64)
        self.is_stable = np.zeros(capacity, dtype=np.bool_)
        self.promoted_frame_index = np.full(capacity, _SENTINEL, dtype=np.int64)
        self.inactive_candidate = np.zeros(capacity, dtype=np.bool_)
        self.inactive_frame_index = np.full(capacity, _SENTINEL, dtype=np.int64)
        self.max_observation_baseline = np.zeros(capacity, dtype=np.float64)
        self.max_view_angle_degrees = np.zeros(capacity, dtype=np.float64)
        self.consecutive_free_streak = np.zeros(capacity, dtype=np.int64)

        # Vector fields (2D, NaN = None)
        self.first_camera_center = np.full((capacity, 3), _NAN, dtype=np.float64)
        self.last_camera_center = np.full((capacity, 3), _NAN, dtype=np.float64)
        self.first_view_dir = np.full((capacity, 3), _NAN, dtype=np.float64)
        self.last_view_dir = np.full((capacity, 3), _NAN, dtype=np.float64)

        # Non-numeric fields (Python lists, serialization only)
        self.first_seen_frame: List[Optional[Any]] = [None] * capacity
        self.last_seen_frame: List[Optional[Any]] = [None] * capacity

        # Hash map: voxel key → array index
        self.key_to_idx = _make_key_to_idx()

        # Cache for .records materialization (unused — Numba bypasses dirty flag)
        self._records_cache: Optional[Dict[VoxelKey, VoxelRecord]] = None
        self._records_dirty = True

    @property
    def n(self) -> int:
        """Number of active voxels."""
        # Always read from the mutable array (Numba kernels modify it directly)
        return int(self._n_arr[0])

    @n.setter
    def n(self, value: int) -> None:
        self._n = value
        self._n_arr[0] = value
        self._records_dirty = True

    @property
    def n_arr(self) -> np.ndarray:
        """Mutable length-1 array for passing _n to Numba functions."""
        return self._n_arr

    def _mark_dirty(self) -> None:
        self._records_dirty = True

    def ensure_capacity(self, needed: int) -> None:
        """Grow arrays if needed. Doubles capacity until sufficient."""
        if needed <= self._cap:
            return
        new_cap = self._cap
        while new_cap < needed:
            new_cap *= 2
        self._resize(new_cap)

    def _resize(self, new_cap: int) -> None:
        """Resize all arrays to new capacity."""
        old_cap = self._cap

        # Scalar and vector arrays
        self.keys = np.resize(self.keys, (new_cap, 3))
        self.point_sum = np.resize(self.point_sum, (new_cap, 3))
        self.color_sum = np.resize(self.color_sum, (new_cap, 3))
        self.weight = np.resize(self.weight, new_cap)
        self.hit_count = np.resize(self.hit_count, new_cap)
        self.pixel_count = np.resize(self.pixel_count, new_cap)
        self.free_count = np.resize(self.free_count, new_cap)
        self.log_odds = np.resize(self.log_odds, new_cap)
        self.first_seen_index = np.resize(self.first_seen_index, new_cap)
        self.last_seen_index = np.resize(self.last_seen_index, new_cap)
        self.is_stable = np.resize(self.is_stable, new_cap)
        self.promoted_frame_index = np.resize(self.promoted_frame_index, new_cap)
        self.inactive_candidate = np.resize(self.inactive_candidate, new_cap)
        self.inactive_frame_index = np.resize(self.inactive_frame_index, new_cap)
        self.max_observation_baseline = np.resize(self.max_observation_baseline, new_cap)
        self.max_view_angle_degrees = np.resize(self.max_view_angle_degrees, new_cap)
        self.consecutive_free_streak = np.resize(self.consecutive_free_streak, new_cap)
        self.first_camera_center = np.resize(self.first_camera_center, (new_cap, 3))
        self.last_camera_center = np.resize(self.last_camera_center, (new_cap, 3))
        self.first_view_dir = np.resize(self.first_view_dir, (new_cap, 3))
        self.last_view_dir = np.resize(self.last_view_dir, (new_cap, 3))

        # Initialize new slots
        if new_cap > old_cap:
            self.first_seen_index[old_cap:new_cap] = _SENTINEL
            self.last_seen_index[old_cap:new_cap] = _SENTINEL
            self.promoted_frame_index[old_cap:new_cap] = _SENTINEL
            self.inactive_frame_index[old_cap:new_cap] = _SENTINEL
            self.first_camera_center[old_cap:new_cap] = _NAN
            self.last_camera_center[old_cap:new_cap] = _NAN
            self.first_view_dir[old_cap:new_cap] = _NAN
            self.last_view_dir[old_cap:new_cap] = _NAN
            self.first_seen_frame.extend([None] * (new_cap - old_cap))
            self.last_seen_frame.extend([None] * (new_cap - old_cap))

        self._cap = new_cap

    def get_or_create(self, key: VoxelKey, frame_index: int) -> int:
        """Get existing voxel index or create a new one. Returns the index."""
        idx = self.key_to_idx.get(key, _SENTINEL)
        if idx >= 0:
            return int(idx)

        # Create new voxel
        idx = self._n
        self.ensure_capacity(idx + 1)

        self.keys[idx] = key
        self.point_sum[idx] = 0.0
        self.color_sum[idx] = 0.0
        self.weight[idx] = 0.0
        self.hit_count[idx] = 0
        self.pixel_count[idx] = 0
        self.free_count[idx] = 0
        self.log_odds[idx] = 0.0
        self.first_seen_index[idx] = frame_index
        self.last_seen_index[idx] = frame_index
        self.is_stable[idx] = False
        self.promoted_frame_index[idx] = _SENTINEL
        self.inactive_candidate[idx] = False
        self.inactive_frame_index[idx] = _SENTINEL
        self.max_observation_baseline[idx] = 0.0
        self.max_view_angle_degrees[idx] = 0.0
        self.consecutive_free_streak[idx] = 0
        self.first_camera_center[idx] = _NAN
        self.last_camera_center[idx] = _NAN
        self.first_view_dir[idx] = _NAN
        self.last_view_dir[idx] = _NAN
        self.first_seen_frame[idx] = None
        self.last_seen_frame[idx] = None

        self.key_to_idx[key] = idx
        self.n = idx + 1
        self._mark_dirty()
        return idx

    def swap_delete(self, idx: int) -> None:
        """Delete voxel at idx by swapping with last active voxel."""
        last = self._n - 1
        if idx < 0 or idx >= self._n:
            return

        # Compute removed key BEFORE any mutation
        removed_key = (int(self.keys[idx, 0]), int(self.keys[idx, 1]), int(self.keys[idx, 2]))

        if idx != last:
            # Copy last row to idx
            self._copy_row(last, idx)
            # Update key_to_idx for the moved row
            moved_key = (int(self.keys[idx, 0]), int(self.keys[idx, 1]), int(self.keys[idx, 2]))
            self.key_to_idx[moved_key] = idx

        # Remove the deleted key from key_to_idx
        if removed_key in self.key_to_idx:
            del self.key_to_idx[removed_key]

        self.n = last
        self._mark_dirty()

    def _copy_row(self, src: int, dst: int) -> None:
        """Copy all data from src row to dst row."""
        self.keys[dst] = self.keys[src]
        self.point_sum[dst] = self.point_sum[src]
        self.color_sum[dst] = self.color_sum[src]
        self.weight[dst] = self.weight[src]
        self.hit_count[dst] = self.hit_count[src]
        self.pixel_count[dst] = self.pixel_count[src]
        self.free_count[dst] = self.free_count[src]
        self.log_odds[dst] = self.log_odds[src]
        self.first_seen_index[dst] = self.first_seen_index[src]
        self.last_seen_index[dst] = self.last_seen_index[src]
        self.is_stable[dst] = self.is_stable[src]
        self.promoted_frame_index[dst] = self.promoted_frame_index[src]
        self.inactive_candidate[dst] = self.inactive_candidate[src]
        self.inactive_frame_index[dst] = self.inactive_frame_index[src]
        self.max_observation_baseline[dst] = self.max_observation_baseline[src]
        self.max_view_angle_degrees[dst] = self.max_view_angle_degrees[src]
        self.consecutive_free_streak[dst] = self.consecutive_free_streak[src]
        self.first_camera_center[dst] = self.first_camera_center[src]
        self.last_camera_center[dst] = self.last_camera_center[src]
        self.first_view_dir[dst] = self.first_view_dir[src]
        self.last_view_dir[dst] = self.last_view_dir[src]
        self.first_seen_frame[dst] = self.first_seen_frame[src]
        self.last_seen_frame[dst] = self.last_seen_frame[src]

    def materialize_records(self) -> Dict[VoxelKey, VoxelRecord]:
        """Construct dict[VoxelKey, VoxelRecord] from SoA arrays.

        Used for backward compatibility with code that accesses .records.
        Always materializes fresh data (Numba kernels bypass the dirty flag).
        """
        records: Dict[VoxelKey, VoxelRecord] = {}
        for i in range(self.n):  # use self.n (reads from n_arr[0])
            key = (int(self.keys[i, 0]), int(self.keys[i, 1]), int(self.keys[i, 2]))

            def _opt_vec(arr: np.ndarray) -> Optional[np.ndarray]:
                v = arr.copy()
                if np.all(np.isfinite(v)):
                    return v
                return None

            rec = VoxelRecord(
                point_sum=self.point_sum[i].copy(),
                color_sum=self.color_sum[i].copy(),
                weight=float(self.weight[i]),
                hit_count=int(self.hit_count[i]),
                pixel_count=int(self.pixel_count[i]),
                free_count=int(self.free_count[i]),
                log_odds=float(self.log_odds[i]),
                first_seen_frame=self.first_seen_frame[i],
                last_seen_frame=self.last_seen_frame[i],
                first_seen_index=int(self.first_seen_index[i]),
                last_seen_index=int(self.last_seen_index[i]),
                is_stable=bool(self.is_stable[i]),
                promoted_frame_index=(
                    int(self.promoted_frame_index[i])
                    if self.promoted_frame_index[i] >= 0 else None
                ),
                inactive_candidate=bool(self.inactive_candidate[i]),
                inactive_frame_index=(
                    int(self.inactive_frame_index[i])
                    if self.inactive_frame_index[i] >= 0 else None
                ),
                first_camera_center=_opt_vec(self.first_camera_center[i]),
                last_camera_center=_opt_vec(self.last_camera_center[i]),
                first_view_dir=_opt_vec(self.first_view_dir[i]),
                last_view_dir=_opt_vec(self.last_view_dir[i]),
                max_observation_baseline=float(self.max_observation_baseline[i]),
                max_view_angle_degrees=float(self.max_view_angle_degrees[i]),
                consecutive_free_streak=int(self.consecutive_free_streak[i]),
            )
            records[key] = rec

        return records

    def set_first_seen_frame(self, idx: int, frame_id: Any) -> None:
        """Set first_seen_frame (non-numeric, Python-side only)."""
        self.first_seen_frame[idx] = frame_id
        self._mark_dirty()

    def set_last_seen_frame(self, idx: int, frame_id: Any) -> None:
        """Set last_seen_frame (non-numeric, Python-side only)."""
        self.last_seen_frame[idx] = frame_id
        self._mark_dirty()
