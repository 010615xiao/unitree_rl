#!/usr/bin/env python3
"""
从 RGB-D 序列构建全局 3D 点云

数据格式:
  - color/*.png: 彩色图像
  - depth/*.png: 深度图像 (单位：毫米)
  - poses.txt: 相机位姿 (格式：timestamp tx ty tz qx qy qz qw)
  - d435i.yaml: 相机内参
"""

import os
import json
import time
import numpy as np
import cv2
import yaml
import open3d as o3d
from pathlib import Path
from global_reconstruction.core.data_adapter import DatasetAdapter
from global_reconstruction.core.config_loader import get_config
from global_reconstruction.reconstruction.voxel_fusion import SparseVoxelFusion

# ================= 配置参数 =================
cfg = get_config()

DATA_FMT = os.environ.get("GLOBAL_RECON_DATA_FORMAT", "auto")
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent  # global_reconstruction_timing/

# 输出文件
OUTPUT_DIR = PROJECT_ROOT / "output" / "reconstruction"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_PLY = OUTPUT_DIR / "global_pointcloud.ply"
OUTPUT_COMPLETE_PLY = OUTPUT_DIR / "global_pointcloud_complete.ply"
OUTPUT_STABLE_RAW_PLY = OUTPUT_DIR / "global_pointcloud_stable_raw.ply"
OUTPUT_COMPLETE_RAW_PLY = OUTPUT_DIR / "global_pointcloud_complete_raw.ply"
OUTPUT_TSDF_PLY = OUTPUT_DIR / "global_pointcloud_tsdf.ply"

# 点云处理参数
VOXEL_SIZE = cfg.reconstruction.voxel_size
SKIP_FRAMES = cfg.reconstruction.skip_frames

# 坐标轴变换矩阵
# da3_ezviz (DA3-Streaming) 输出的世界坐标系 Y 轴近似高度方向，不需要 Z→Y 变换
USE_AXIS_TRANSFORM = cfg.coordinate.use_axis_transform
T_SWITCH_AXIS = np.array(cfg.coordinate.switch_axis, dtype=np.float64)

# 深度过滤
DEPTH_MIN = cfg.reconstruction.depth_min
DEPTH_MAX = cfg.reconstruction.depth_max

# DBSCAN 去噪参数
USE_DBSCAN = False
DBSCAN_EPS = cfg.reconstruction.dbscan_eps
DBSCAN_MIN_POINTS = cfg.reconstruction.dbscan_min_points

# 半径离群点移除
USE_RADIUS_OUTLIER = False
RADIUS_OUTLIER_NB = cfg.reconstruction.radius_outlier_nb_points
RADIUS_OUTLIER_RADIUS = cfg.reconstruction.radius_outlier_radius

# 深度图缩放比例 (深度图单位：毫米 -> 米)
DEPTH_SCALE = cfg.reconstruction.depth_scale

# 置信度过滤
CONFIDENCE_THRESHOLD = getattr(cfg.reconstruction, 'confidence_threshold', 0.0)
FUSION_CONFIG = cfg.reconstruction.get('fusion', {}) or {}
FUSION_ENABLED = bool(FUSION_CONFIG.get('enabled', True))

# TSDF 旁路融合参数 (验证用: 仅导出 global_pointcloud_tsdf.ply，不影响主点云)
_TSDF_CFG = cfg.reconstruction.get('tsdf', {}) or {}
TSDF_ENABLED = bool(_TSDF_CFG.get('enabled', False))
TSDF_VOXEL_LENGTH = float(_TSDF_CFG.get('voxel_length', VOXEL_SIZE))
TSDF_SDF_TRUNC = float(_TSDF_CFG.get('sdf_trunc', 0.08))
TSDF_DEPTH_SAMPLING_STRIDE = int(_TSDF_CFG.get('depth_sampling_stride', 4))
TSDF_EXPORT_MESH = bool(_TSDF_CFG.get('export_mesh', False))
# ===========================================
def load_poses(pose_file):
    """
    加载相机位姿,支持两种格式:
    - TUM 格式 (8 values): timestamp tx ty tz qx qy qz qw
    - 4x4 矩阵格式 (16 values): row-major camera-to-world 矩阵

    返回：{timestamp: 4x4 变换矩阵 (相机到世界)}
    """
    from global_reconstruction.core.data_adapter import DatasetAdapter
    data_dir = Path(pose_file).parent
    dataset_type = DatasetAdapter(data_dir).dataset_type
    apply_axis_transform = USE_AXIS_TRANSFORM and dataset_type != "da3_ezviz"

    poses = {}
    seq_idx = 0
    with open(pose_file, 'r') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue

            parts = line.strip().split()

            if len(parts) == 16:
                # 4x4 矩阵格式 (da3_ezviz: camera_poses.txt)
                T_c2w = np.array([float(x) for x in parts], dtype=np.float64).reshape(4, 4)
                timestamp = f"{seq_idx:05d}"
                seq_idx += 1

                if apply_axis_transform:
                    T_c2w = T_SWITCH_AXIS @ T_c2w

                poses[timestamp] = T_c2w

            elif len(parts) >= 8:
                # TUM 格式
                timestamp = parts[0]
                tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
                qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

                # 四元数转旋转矩阵
                R = quaternion_to_rotation_matrix(qx, qy, qz, qw)

                # 构建 4x4 变换矩阵 (世界到相机)
                T_w2c = np.eye(4)
                T_w2c[:3, :3] = R
                T_w2c[0, 3] = tx
                T_w2c[1, 3] = ty
                T_w2c[2, 3] = tz

                # 取逆得到相机到世界的变换
                T_c2w = np.linalg.inv(T_w2c)

                # 应用坐标轴变换
                if apply_axis_transform:
                    T_c2w = T_SWITCH_AXIS @ T_c2w

                poses[timestamp] = T_c2w

    return poses


def quaternion_to_rotation_matrix(qx, qy, qz, qw):
    """四元数转旋转矩阵"""
    # 归一化四元数
    norm = np.sqrt(qx*qx + qy*qy + qz*qz + qw*qw)
    qx, qy, qz, qw = qx/norm, qy/norm, qz/norm, qw/norm

    R = np.eye(3)
    R[0, 0] = 1 - 2*qy*qy - 2*qz*qz
    R[0, 1] = 2*qx*qy - 2*qz*qw
    R[0, 2] = 2*qx*qz + 2*qy*qw
    R[1, 0] = 2*qx*qy + 2*qz*qw
    R[1, 1] = 1 - 2*qx*qx - 2*qz*qz
    R[1, 2] = 2*qy*qz - 2*qx*qw
    R[2, 0] = 2*qx*qz - 2*qy*qw
    R[2, 1] = 2*qy*qz + 2*qx*qw
    R[2, 2] = 1 - 2*qx*qx - 2*qy*qy

    return R


# ============================================================
# 相机位姿计算 (odom_matched_camera.txt 格式)
# ============================================================
# 相机到机器人的固定旋转:
#   相机 Z(前) -> 机器人 X(前)
#   相机 X(右) -> 机器人 -Y(左)
#   相机 Y(下) -> 机器人 -Z(下)
R_CAM2ROBOT = np.array([[0, 0, 1],
                        [-1, 0, 0],
                        [0, -1, 0]])


def _euler_to_rotmat(yaw, pitch, roll):
    """R_robot (yaw from Y-axis: yaw=0 -> +Y, yaw=-pi/2 -> +X)"""
    cy, sy = np.cos(yaw), np.sin(yaw)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cr, sr = np.cos(roll), np.sin(roll)
    return np.array([
        [-sy*cp,  -sy*sp*sr - cy*cr,  -sy*sp*cr + cy*sr],
        [ cy*cp,   cy*sp*sr - sy*cr,   cy*sp*cr + sy*sr],
        [    sp,              cp*sr,               cp*cr],
    ])


def load_odom_camera(path, fmt="0622"):
    """加载 odom_matched_camera.txt 格式的里程计.

    两种格式:
    - 0622: tab-sep, cols 1/2/3/4/5 = x(mm)/y(mm)/yaw/pitch/roll
    - 0707: space-sep, cols 6/7/8 = x(mm)/y(mm)/yaw, 无 pitch/roll
    - auto: 自动检测 (含 tab → 0622, 否则 → 0707)
    """
    if fmt == "auto":
        with open(path) as f:
            first_line = f.readline()
        fmt = "0622" if '\t' in first_line else "0707"

    records = []
    sep = '\t' if fmt == '0622' else ' '
    min_parts = 6 if fmt == '0622' else 9
    with open(path) as f:
        for line in f:
            parts = line.strip().split(sep)
            if len(parts) < min_parts:
                continue
            if fmt == '0622':
                records.append({
                    'x': float(parts[1]) / 1000.0,
                    'y': float(parts[2]) / 1000.0,
                    'yaw': float(parts[3]),
                    'roll': float(parts[4]),
                    'pitch': float(parts[5]),
                })
            else:
                records.append({
                    'x': float(parts[6]) / 1000.0,
                    'y': float(parts[7]) / 1000.0,
                    'yaw': float(parts[8]),
                    'roll': 0.0,
                    'pitch': 0.0,
                })
    return records


def compute_poses_camera(odom, camera_height):
    """从 odom_matched_camera.txt 构建相机位姿 (4x4 T_cam2world).

    x, y 是相机中心位置, yaw 是相机光轴朝向 (+X 约定: yaw=0 -> +X).
    euler_to_rotmat 使用 +Y 约定 (yaw=0 -> +Y),
    传入 yaw - pi/2 将 +X 约定转为 +Y 约定.
    """
    raw_yaws = np.array([o['yaw'] for o in odom])
    unwrapped_yaws = np.unwrap(raw_yaws)

    poses = []
    for i, o in enumerate(odom):
        yaw_plus_y = unwrapped_yaws[i] - np.pi / 2.0
        R_robot = _euler_to_rotmat(yaw_plus_y, o['pitch'], o['roll'])
        R_cam = R_robot @ R_CAM2ROBOT

        T = np.eye(4)
        T[:3, :3] = R_cam
        T[0, 3] = o['x']
        T[1, 3] = o['y']
        T[2, 3] = camera_height
        poses.append(T)
    return poses


def load_camera_height(data_dir):
    """加载相机高度 (从 camera_height.txt)."""
    height_file = Path(data_dir) / "camera_height.txt"
    if height_file.exists():
        return float(height_file.read_text().strip())
    return None


def load_poses_from_odom_camera(data_dir):
    """从 odom_matched_camera.txt + camera_height.txt 计算位姿.

    返回 {timestamp: 4x4 T_c2w} 或 None (文件不存在时).
    """
    odom_file = Path(data_dir) / "odom_matched_camera.txt"
    if not odom_file.exists():
        return None

    camera_height = load_camera_height(data_dir)
    if camera_height is None:
        print(f"  ⚠️  找到 odom_matched_camera.txt 但缺少 camera_height.txt")
        return None

    odom = load_odom_camera(odom_file, fmt=DATA_FMT)
    if not odom:
        print(f"  ⚠️  odom_matched_camera.txt 解析结果为空 (格式: {DATA_FMT})")
        return None

    poses_list = compute_poses_camera(odom, camera_height)

    poses = {}
    for i, T in enumerate(poses_list):
        poses[f"{i:05d}"] = T

    print(f"  📍 使用 odom_matched_camera.txt + camera_height={camera_height:.4f}m 计算位姿")
    print(f"     {len(poses)} 帧, 首帧位置: [{poses_list[0][0,3]:.3f}, {poses_list[0][1,3]:.3f}, {poses_list[0][2,3]:.3f}]")
    return poses


def depth_to_pointcloud(depth, color, K, T_cam2world, confidence=None, conf_threshold=0.0):
    """
    RGB-D转点云

    参数:
        depth: 深度图 (单位：米)
        color: 彩色图 (RGB)
        K: 相机内参矩阵 (3x3)
        T_cam2world: 相机到世界的变换矩阵 (4x4)
        confidence: 置信度图 (可选)
        conf_threshold: 置信度阈值 (0 = 不过滤)

    返回:
        points: 3D 点坐标 (N x 3)
        colors: 颜色 (N x 3)
    """
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    # 获取有效深度像素
    valid_mask = depth > 0
    if confidence is not None and conf_threshold > 0:
        valid_mask &= (confidence >= conf_threshold)
    v, u = np.where(valid_mask)

    if len(u) == 0:
        return np.empty((0, 3)), np.empty((0, 3))

    # 获取深度值
    depths = depth[v, u].flatten()

    # 反投影到相机坐标系
    # 相机坐标系：X 向右，Y 向下，Z 向前
    X_cam = (u - cx) * depths / fx
    Y_cam = (v - cy) * depths / fy
    Z_cam = depths

    # 齐次坐标
    points_cam = np.stack([X_cam, Y_cam, Z_cam, np.ones_like(X_cam)], axis=1)

    # 变换到世界坐标系
    points_world = (T_cam2world @ points_cam.T).T
    points_world = points_world[:, :3] / points_world[:, 3:4]

    # 获取颜色
    colors = color[v, u]

    return points_world, colors


def voxel_downsample(points, colors, voxel_size):
    """
    体素下采样
    """
    if len(points) == 0:
        return points, colors

    # 计算体素索引
    indices = np.floor(points / voxel_size).astype(np.int64)

    # 使用结构化数组进行快速去重
    idx_min = indices.min(axis=0)
    indices_norm = indices - idx_min
    range_max = indices_norm.max(axis=0) + 1

    # 计算线性索引
    linear_idx = (indices_norm[:, 0] * range_max[1] * range_max[2] +
                  indices_norm[:, 1] * range_max[2] +
                  indices_norm[:, 2])

    # 去重，保留每个体素的第一个点
    _, unique_idx = np.unique(linear_idx, return_index=True)

    # 取每个体素的第一个点
    downsampled_points = points[unique_idx]
    downsampled_colors = colors[unique_idx]

    return downsampled_points, downsampled_colors


def dbscan_denoise(points, colors, eps=DBSCAN_EPS, min_points=DBSCAN_MIN_POINTS):
    """
    DBSCAN 去噪 (保留最大连通簇)
    """
    try:
        import open3d as o3d
        
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
        
        # DBSCAN 聚类
        labels = np.array(pcd.cluster_dbscan(eps=eps, min_points=min_points, print_progress=False))
        
        # 统计每个簇的点数
        unique_labels, counts = np.unique(labels[labels >= 0], return_counts=True)
        
        if len(unique_labels) == 0:
            print(f"  DBSCAN 警告：未找到有效簇，保留所有点")
            return points, colors
        
        # 找到最大簇的标签
        largest_cluster_label = unique_labels[np.argmax(counts)]
        
        # 保留最大簇的点
        mask = labels == largest_cluster_label
        filtered_points = points[mask]
        filtered_colors = colors[mask]
        
        print(f"  DBSCAN 去噪：{len(points):,} → {len(filtered_points):,} 点 (保留最大簇)")
        
        return filtered_points, filtered_colors
    
    except ImportError:
        print("  Open3D 不可用，跳过 DBSCAN 去噪")
        return points, colors


def radius_outlier_removal(points, colors, nb_points=RADIUS_OUTLIER_NB, radius=RADIUS_OUTLIER_RADIUS):
    """
    半径离群点移除
    """
    try:
        import open3d as o3d
        
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
        
        # 半径离群点移除
        _, ind = pcd.remove_radius_outlier(nb_points=nb_points, radius=radius)
        
        filtered_points = points[ind]
        filtered_colors = colors[ind]
        
        print(f"  半径离群点移除：{len(points):,} → {len(filtered_points):,} 点")
        
        return filtered_points, filtered_colors
    
    except ImportError:
        print("  Open3D 不可用，跳过半径离群点移除")
        return points, colors


def denoise_pipeline(points, colors, label="pointcloud"):
    stats = {
        "label": label,
        "before": int(len(points)),
        "after_dbscan": int(len(points)),
        "after_radius": int(len(points)),
        "after": int(len(points)),
    }
    filtered_points, filtered_colors = points, colors

    if USE_DBSCAN:
        before = len(filtered_points)
        filtered_points, filtered_colors = dbscan_denoise(filtered_points, filtered_colors)
        stats["after_dbscan"] = int(len(filtered_points))
        stats["dbscan_removed"] = int(before - len(filtered_points))

    if USE_RADIUS_OUTLIER:
        before = len(filtered_points)
        filtered_points, filtered_colors = radius_outlier_removal(filtered_points, filtered_colors)
        stats["after_radius"] = int(len(filtered_points))
        stats["radius_removed"] = int(before - len(filtered_points))

    stats["after"] = int(len(filtered_points))
    return filtered_points, filtered_colors, stats


def save_ply_with_color(filename, points, colors):
    """保存带颜色的 PLY 文件 (使用 Open3D)"""
    try:
        import open3d as o3d

        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points.astype(np.float64))
        pcd.colors = o3d.utility.Vector3dVector(colors.astype(np.float64) / 255.0)

        o3d.io.write_point_cloud(str(filename), pcd, write_ascii=False, compressed=True)
        print(f"  使用 Open3D 保存 PLY：{filename}")
    except ImportError:
        print("  Open3D 不可用，使用备用保存方法")
        _save_ply_basic(filename, points, colors)


def _save_ply_basic(filename, points, colors):
    n_points = len(points)

    # 创建结构化数组
    vertex_data = np.zeros(n_points, dtype=[
        ('x', '<f4'), ('y', '<f4'), ('z', '<f4'),
        ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')
    ])

    vertex_data['x'] = points[:, 0].astype(np.float32)
    vertex_data['y'] = points[:, 1].astype(np.float32)
    vertex_data['z'] = points[:, 2].astype(np.float32)
    vertex_data['red'] = colors[:, 0].astype(np.uint8)
    vertex_data['green'] = colors[:, 1].astype(np.uint8)
    vertex_data['blue'] = colors[:, 2].astype(np.uint8)

    with open(filename, 'wb') as f:
        header = f"""ply
format binary_little_endian 1.0
element vertex {n_points}
property float x
property float y
property float z
property uchar red
property uchar green
property uchar blue
end_header
"""
        f.write(header.encode('ascii'))
        f.write(vertex_data.tobytes())


def main():
    data_dir = Path(os.environ.get("GLOBAL_RECON_DATA_DIR", cfg.data.default_dir))
    adapter = DatasetAdapter(data_dir)
    color_dir = adapter.images_dir
    depth_dir = adapter.depth_dir
    poses_file = adapter.poses_file

    print("=" * 60)
    print("RGB-D 全局 3D 点云重建工具")
    print("=" * 60)

    # 打印数据集信息
    adapter.print_info()

    # 检查数据目录
    print(f"\n数据目录：{data_dir}")
    assert data_dir.exists(), f"数据目录不存在：{data_dir}"
    assert color_dir.exists(), f"彩色图目录不存在：{color_dir}"
    assert depth_dir.exists(), f"深度图目录不存在：{depth_dir}"
    # 位姿文件: 优先 odom_matched_camera.txt (iTOF), 回退 camera_poses.txt
    odom_cam_file = data_dir / "odom_matched_camera.txt"
    has_poses = poses_file.exists() or odom_cam_file.exists()
    assert has_poses, f"位姿文件不存在：需要 {poses_file} 或 {odom_cam_file}"

    # 加载相机参数
    print("\n[1] 加载相机内参...")
    K = adapter.K
    print(f"  相机内参矩阵:\n{K}")
    print(f"  工作分辨率：{adapter.process_resolution} (H, W)")
    if CONFIDENCE_THRESHOLD > 0:
        print(f"  置信度过滤：≥ {CONFIDENCE_THRESHOLD}")
    else:
        print(f"  置信度过滤：关闭")
    if FUSION_ENABLED:
        print(
            "  点云融合：稀疏体素融合 "
            f"(min_hits={FUSION_CONFIG.get('min_hits', 2)}, "
            f"min_span={FUSION_CONFIG.get('min_observation_span', 0)}, "
            f"min_baseline={FUSION_CONFIG.get('min_view_baseline_m', 0.0)}, "
            f"free_space={FUSION_CONFIG.get('free_space_carving', True)}, "
            f"ray_stride={FUSION_CONFIG.get('ray_stride', 8)})"
        )
    else:
        print("  点云融合：旧版追加 + 体素下采样")

    # 加载位姿
    print("\n[2] 加载相机位姿...")
    # 优先使用 odom_matched_camera.txt + camera_height.txt (iTOF 管线格式)
    poses = load_poses_from_odom_camera(data_dir)
    if poses is None:
        assert poses_file.exists(), f"位姿文件不存在：{poses_file}"
        poses = load_poses(poses_file)
    print(f"  加载了 {len(poses)} 个位姿")

    # 获取深度图列表
    depth_files = adapter.get_depth_file_list()
    print(f"  找到 {len(depth_files)} 个深度图")

    # 建立深度图文件名到pose时间戳的映射
    file_to_pose = adapter.build_pose_timestamp_map(poses)

    # 增量式体素下采样: 每 INCREMENTAL_DOWNSAMPLE_EVERY 帧合并+下采样,控制内存
    INCREMENTAL_DOWNSAMPLE_EVERY = 50
    total_frames = len([i for i in range(len(depth_files)) if i % SKIP_FRAMES == 0])

    fusion_map = None
    if FUSION_ENABLED:
        fusion_map = SparseVoxelFusion.from_config(
            FUSION_CONFIG,
            voxel_size=VOXEL_SIZE,
            depth_min=DEPTH_MIN,
            depth_max=DEPTH_MAX,
            confidence_threshold=CONFIDENCE_THRESHOLD,
        )

    # TSDF 旁路融合 (Open3D ScalableTSDFVolume)，与 fusion 独立，仅用于导出对比点云
    tsdf_volume = None
    if TSDF_ENABLED:
        tsdf_volume = o3d.pipelines.integration.ScalableTSDFVolume(
            voxel_length=TSDF_VOXEL_LENGTH,
            sdf_trunc=TSDF_SDF_TRUNC,
            color_type=o3d.pipelines.integration.TSDFVolumeColorType.RGB8,
            depth_sampling_stride=TSDF_DEPTH_SAMPLING_STRIDE,
        )
        print(f"  TSDF 旁路融合：已启用 (voxel={TSDF_VOXEL_LENGTH}, sdf_trunc={TSDF_SDF_TRUNC}, stride={TSDF_DEPTH_SAMPLING_STRIDE})")

    # 旧版累积点云，仅在 fusion.enabled=false 时使用
    merged_points = np.empty((0, 3), dtype=np.float32)
    merged_colors = np.empty((0, 3), dtype=np.uint8)

    # 当前批次的原始点云
    batch_points = []
    batch_colors = []

    print("\n[3] 逐帧重建点云 (增量下采样)...")
    processed = 0
    _t_fusion_int = _t_tsdf_int = _t_stack_int = 0.0
    for i, depth_file in enumerate(depth_files):
        # 跳帧采样
        if i % SKIP_FRAMES != 0:
            continue

        frame_id = depth_file.stem

        # 使用映射获取对应的时间戳
        if frame_id not in file_to_pose:
            continue
        pose_timestamp = file_to_pose[frame_id]

        if pose_timestamp not in poses:
            continue

        # 读取深度图 (da3_ezviz: 原生分辨率; standard: 上采样到 RGB)
        depth = adapter.load_depth(depth_file, target_resolution=adapter.rgb_resolution)
        if depth is None:
            continue

        # 深度图单位转换 (毫米 -> 米)
        if depth.dtype == np.uint16:
            depth = depth.astype(np.float32) / DEPTH_SCALE
        elif depth.dtype == np.uint8:
            depth = depth.astype(np.float32)
            print(f"  警告：深度图为 uint8 格式，可能已归一化")

        # 无效值 (inf/NaN) 统一置 0, 避免下游算术触发 RuntimeWarning
        depth = np.where(np.isfinite(depth), depth, 0.0).astype(np.float32)

        # 深度过滤
        depth_mask = (depth >= DEPTH_MIN) & (depth <= DEPTH_MAX)
        depth_filtered = depth * depth_mask

        # 读取彩色图 (适配器自动缩放到工作分辨率)
        color_file = adapter.match_color_file(frame_id)
        if color_file is None:
            continue

        color = adapter.load_color(color_file)
        if color is None:
            continue

        # 确保彩色图和深度图尺寸一致 (安全校验)
        if color.shape[:2] != depth_filtered.shape:
            color = cv2.resize(color, (depth_filtered.shape[1], depth_filtered.shape[0]))

        # 应用深度掩码到彩色图
        color_masked = color * depth_mask[:, :, np.newaxis]

        # 加载置信度图 (da3_ezviz: 已在深度分辨率, 无需缩放)
        confidence = None
        if CONFIDENCE_THRESHOLD > 0:
            confidence = adapter.load_confidence(i)

        # 转换为点云
        K_frame = adapter.get_K_for_frame(i)
        if FUSION_ENABLED:
            _t0 = time.perf_counter()
            fusion_map.integrate(
                depth,
                color,
                K_frame,
                poses[pose_timestamp],
                confidence=confidence,
                frame_id=frame_id,
            )
            _t_fusion_int += time.perf_counter() - _t0
        elif TSDF_ENABLED:
            # TSDF 为主重建：integrate 在下方 TSDF 块执行，此处跳过点云叠加
            pass
        else:
            # 两者均关闭：点云叠加兜底
            _t0 = time.perf_counter()
            points, colors = depth_to_pointcloud(
                depth_filtered,
                color_masked,
                K_frame,
                poses[pose_timestamp],
                confidence,
                CONFIDENCE_THRESHOLD,
            )
            if len(points) > 0:
                batch_points.append(points)
                batch_colors.append(colors)
            _t_stack_int += time.perf_counter() - _t0

        # TSDF 融合: extrinsic 传 w->c；depth_filtered 已含距离过滤，再叠加置信度过滤 (与 fusion/叠加一致)
        if TSDF_ENABLED:
            _t0 = time.perf_counter()
            if confidence is not None and CONFIDENCE_THRESHOLD > 0:
                _tsdf_depth = np.where(confidence >= CONFIDENCE_THRESHOLD, depth_filtered, 0.0).astype(np.float32)
            else:
                _tsdf_depth = depth_filtered
            _rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
                o3d.geometry.Image(color_masked.astype(np.uint8)),
                o3d.geometry.Image(_tsdf_depth),
                depth_scale=1.0,
                depth_trunc=DEPTH_MAX,
                convert_rgb_to_intensity=False,
            )
            _h_ds, _w_ds = depth_filtered.shape[:2]
            _K_tsdf = o3d.camera.PinholeCameraIntrinsic(
                _w_ds, _h_ds,
                float(K_frame[0, 0]), float(K_frame[1, 1]),
                float(K_frame[0, 2]), float(K_frame[1, 2]),
            )
            tsdf_volume.integrate(_rgbd, _K_tsdf, np.linalg.inv(poses[pose_timestamp]))
            _t_tsdf_int += time.perf_counter() - _t0

        processed += 1

        # 增量下采样: 每 N 帧合并当前批次并体素下采样
        if FUSION_ENABLED:
            if processed % INCREMENTAL_DOWNSAMPLE_EVERY == 0 or processed == total_frames:
                stats = fusion_map.stats()
                print(
                    f"  进度：{processed}/{total_frames} 帧，"
                    f"融合体素：{stats['exported_voxels']:,}/{stats['total_voxels']:,}"
                )
        elif TSDF_ENABLED:
            if processed % INCREMENTAL_DOWNSAMPLE_EVERY == 0 or processed == total_frames:
                print(f"  进度：{processed}/{total_frames} 帧 (TSDF 融合中)")
        elif processed % INCREMENTAL_DOWNSAMPLE_EVERY == 0 or processed == total_frames:
            if batch_points:
                batch_pts = np.vstack(batch_points)
                batch_cols = np.vstack(batch_colors)

                # 与已累积的点云合并
                if len(merged_points) > 0:
                    batch_pts = np.vstack([merged_points, batch_pts])
                    batch_cols = np.vstack([merged_colors, batch_cols])

                # 体素下采样
                merged_points, merged_colors = voxel_downsample(batch_pts, batch_cols, VOXEL_SIZE)

                batch_points = []
                batch_colors = []

            print(f"  进度：{processed}/{total_frames} 帧，"
                  f"累积点数：{merged_points.shape[0]:,}")

    # 最终合并
    print("\n[4] 合并全局点云...")
    stable_raw_points = None
    stable_raw_colors = None
    complete_raw_points = None
    complete_raw_colors = None
    complete_points = None
    complete_colors = None
    fusion_stats = None
    _t_fusion_export = 0.0
    _t_tsdf_extract = 0.0
    if FUSION_ENABLED:
        _t0 = time.perf_counter()
        assert fusion_map is not None
        all_points, all_colors = fusion_map.to_point_cloud(mode="stable")
        if FUSION_CONFIG.get("export_complete_map", True):
            complete_points, complete_colors = fusion_map.to_point_cloud(mode="complete")
        else:
            complete_points = np.empty((0, 3), dtype=np.float32)
            complete_colors = np.empty((0, 3), dtype=np.uint8)

        stable_raw_points = all_points.copy()
        stable_raw_colors = all_colors.copy()
        complete_raw_points = complete_points.copy()
        complete_raw_colors = complete_colors.copy()
        fusion_stats = fusion_map.stats()
        fusion_stats["stable_before_denoise_points"] = int(len(stable_raw_points))
        fusion_stats["complete_before_denoise_points"] = int(len(complete_raw_points))
        fusion_stats["main_output_mode"] = "stable"
        if len(all_points) == 0 and len(complete_points) > 0:
            print("  警告：稳定层为空，使用 complete 点云作为主输出兜底")
            all_points = complete_points.copy()
            all_colors = complete_colors.copy()
            fusion_stats["main_output_mode"] = "complete_fallback"
        _t_fusion_export = time.perf_counter() - _t0
    elif TSDF_ENABLED:
        # TSDF 为主重建：导出 TSDF 点云作为主点云
        _t0 = time.perf_counter()
        assert tsdf_volume is not None
        _tsdf_pcd = tsdf_volume.extract_point_cloud()
        all_points = np.asarray(_tsdf_pcd.points, dtype=np.float32)
        if len(_tsdf_pcd.colors) == len(all_points):
            all_colors = (np.clip(np.asarray(_tsdf_pcd.colors), 0.0, 1.0) * 255.0).astype(np.uint8)
        else:
            all_colors = np.tile(np.array([128, 128, 128], dtype=np.uint8), (len(all_points), 1))
        _t_tsdf_extract = time.perf_counter() - _t0
        print(f"  TSDF 主点云：{len(all_points):,} 点")
    else:
        # 两者均关闭：点云叠加最终合并
        if batch_points:
            batch_pts = np.vstack(batch_points)
            batch_cols = np.vstack(batch_colors)
            if len(merged_points) > 0:
                batch_pts = np.vstack([merged_points, batch_pts])
                batch_cols = np.vstack([merged_colors, batch_cols])
            merged_points, merged_colors = voxel_downsample(batch_pts, batch_cols, VOXEL_SIZE)
            batch_points = []
            batch_colors = []

        all_points = merged_points
        all_colors = merged_colors

    if len(all_points) == 0:
        print("  错误：没有生成任何稳定点云!")
        return

    print(f"  最终点数：{all_points.shape[0]:,}")

    print(f"\n[5] 点云去噪...")
    all_points, all_colors, stable_denoise_stats = denoise_pipeline(all_points, all_colors, label="main_stable")

    complete_denoised_points = None
    complete_denoised_colors = None
    complete_denoise_stats = None
    if FUSION_ENABLED and complete_raw_points is not None and len(complete_raw_points) > 0:
        complete_denoised_points, complete_denoised_colors, complete_denoise_stats = denoise_pipeline(
            complete_raw_points,
            complete_raw_colors,
            label="complete",
        )

    if FUSION_ENABLED and fusion_stats is not None:
        fusion_stats["stable_after_denoise_points"] = int(len(all_points))
        fusion_stats["stable_denoise"] = stable_denoise_stats
        if complete_denoise_stats is not None:
            fusion_stats["complete_after_denoise_points"] = int(len(complete_denoised_points))
            fusion_stats["complete_denoise"] = complete_denoise_stats
        else:
            fusion_stats["complete_after_denoise_points"] = 0
        fusion_stats_file = OUTPUT_DIR / "voxel_fusion_stats.json"
        with open(fusion_stats_file, "w", encoding="utf-8") as f:
            json.dump(fusion_stats, f, indent=2, ensure_ascii=False)
        print(f"  融合统计：{fusion_stats_file}")

    # 保存最终点云
    print(f"\n[7] 保存点云到 {OUTPUT_PLY}...")
    save_ply_with_color(OUTPUT_PLY, all_points, all_colors)
    if FUSION_ENABLED and stable_raw_points is not None and len(stable_raw_points) > 0:
        print(f"  保存 stable raw 点云到 {OUTPUT_STABLE_RAW_PLY}...")
        save_ply_with_color(OUTPUT_STABLE_RAW_PLY, stable_raw_points, stable_raw_colors)
    if FUSION_ENABLED and complete_raw_points is not None and len(complete_raw_points) > 0:
        print(f"  保存 complete raw 点云到 {OUTPUT_COMPLETE_RAW_PLY}...")
        save_ply_with_color(OUTPUT_COMPLETE_RAW_PLY, complete_raw_points, complete_raw_colors)
        print(f"  保存 complete denoised 点云到 {OUTPUT_COMPLETE_PLY}...")
        if complete_denoised_points is not None and len(complete_denoised_points) > 0:
            save_ply_with_color(OUTPUT_COMPLETE_PLY, complete_denoised_points, complete_denoised_colors)
        else:
            save_ply_with_color(OUTPUT_COMPLETE_PLY, complete_raw_points, complete_raw_colors)
    print(f"  点云已保存!")

    # ================= TSDF 旁路对比点云 (仅 fusion+tsdf 都开启时导出) =================
    # 当 fusion 关闭、TSDF 开启时，TSDF 已作为主点云保存到 OUTPUT_PLY，此处不重复导出。
    # 本工具无轨迹对齐旋转，TSDF 导出点云与 all_points 同坐标系 (axis-switched odom frame)，直接可比。
    if TSDF_ENABLED and FUSION_ENABLED and tsdf_volume is not None:
        _t0 = time.perf_counter()
        _tsdf_pcd = tsdf_volume.extract_point_cloud()
        _t_tsdf_extract = time.perf_counter() - _t0
        _tsdf_pts = np.asarray(_tsdf_pcd.points, dtype=np.float32)
        if len(_tsdf_pcd.colors) == len(_tsdf_pts):
            _tsdf_cols = (np.clip(np.asarray(_tsdf_pcd.colors), 0.0, 1.0) * 255.0).astype(np.uint8)
        else:
            _tsdf_cols = np.tile(np.array([128, 128, 128], dtype=np.uint8), (len(_tsdf_pts), 1))
        save_ply_with_color(OUTPUT_TSDF_PLY, _tsdf_pts, _tsdf_cols)
        print(f"  ✓ 已保存 TSDF 旁路点云: {OUTPUT_TSDF_PLY} ({len(_tsdf_pts):,} 点)")
        if TSDF_EXPORT_MESH:
            _tsdf_mesh = tsdf_volume.extract_triangle_mesh()
            _tsdf_mesh_file = OUTPUT_DIR / "tsdf_mesh.ply"
            o3d.io.write_triangle_mesh(str(_tsdf_mesh_file), _tsdf_mesh)
            print(f"  ✓ 已保存 TSDF mesh: {_tsdf_mesh_file}")

    # 统计信息
    print("\n" + "=" * 60)
    print("重建完成!")
    print("=" * 60)

    # ================= 重建耗时对比 =================
    if processed > 0:
        print("\n" + "=" * 60)
        print("重建耗时对比 (integrate = 逐帧融合；导出 = 一次性导出)")
        print("=" * 60)
        print(f"  处理帧数：{processed}")
        if FUSION_ENABLED:
            print(f"  稀疏体素融合  integrate: {_t_fusion_int:7.2f}s 总  ({_t_fusion_int/processed*1000:6.2f} ms/帧)")
            print(f"              导出(to_point_cloud+stats): {_t_fusion_export:7.2f}s")
        if TSDF_ENABLED:
            print(f"  TSDF          integrate: {_t_tsdf_int:7.2f}s 总  ({_t_tsdf_int/processed*1000:6.2f} ms/帧)")
            print(f"              导出(extract_point_cloud): {_t_tsdf_extract:7.2f}s")
        if not FUSION_ENABLED and not TSDF_ENABLED:
            print(f"  点云叠加      integrate: {_t_stack_int:7.2f}s 总  ({_t_stack_int/processed*1000:6.2f} ms/帧)")
        if FUSION_ENABLED and TSDF_ENABLED and _t_fusion_int > 0:
            print(f"  TSDF / 融合 integrate 比值: {_t_tsdf_int/_t_fusion_int:.2f}x")
    print(f"\n输出文件:")
    print(f"  - 点云：{OUTPUT_PLY}")
    if FUSION_ENABLED and stable_raw_points is not None and len(stable_raw_points) > 0:
        print(f"  - Stable raw 点云：{OUTPUT_STABLE_RAW_PLY}")
    if FUSION_ENABLED and complete_raw_points is not None and len(complete_raw_points) > 0:
        print(f"  - Complete raw 点云：{OUTPUT_COMPLETE_RAW_PLY}")
        print(f"  - 完整性点云：{OUTPUT_COMPLETE_PLY}")
    if TSDF_ENABLED and FUSION_ENABLED:
        print(f"  - TSDF 对比点云：{OUTPUT_TSDF_PLY}")
    print(f"\n点云统计:")
    print(f"  - 边界框 X: [{all_points[:, 0].min():.2f}, {all_points[:, 0].max():.2f}] 米")
    print(f"  - 边界框 Y: [{all_points[:, 1].min():.2f}, {all_points[:, 1].max():.2f}] 米")
    print(f"  - 边界框 Z: [{all_points[:, 2].min():.2f}, {all_points[:, 2].max():.2f}] 米")
    print(f"  - 最终点数：{all_points.shape[0]:,}")

    print("\n可视化建议:")
    print("  - 使用 CloudCompare / MeshLab / Open3D 查看 PLY 文件")
    print("  - Python: open3d.visualization.read_point_cloud('global_pointcloud.ply')")


if __name__ == "__main__":
    main()
