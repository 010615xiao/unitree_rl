#!/usr/bin/env python3
"""
2D 栅格地图生成
1. Floor: Y 阈值提取 (最低点 + threshold)
2. 填充 floor 空洞: 基于 floor 点云的 convex hull + 插值
3. 障碍物: 高度阈值 + scene graph 中的 wall/pillar 对象
4. Gateway: scene graph 中的 door 对象
5. 房间: scene graph 中的 rooms
"""

import numpy as np
import open3d as o3d
from scipy.ndimage import binary_dilation, binary_erosion, label, distance_transform_edt
from scipy.spatial import ConvexHull, Delaunay
from pathlib import Path
import json
import pickle

from .config_loader import load_config, get_section


class GridMap:
    """2D 栅格地图
    
    支持两种坐标系:
      - up_axis='y' (默认): Y-up, 投影到 X-Z 平面 (Y 是高度)
      - up_axis='z': Z-up, 投影到 X-Y 平面 (Z 是高度)
    """

    def __init__(self, floor_points_2d, obstacle_points_2d=None, resolution=0.05, padding=10, up_axis='y',
                 config=None):
        self.resolution = resolution
        self.padding = padding
        self.up_axis = up_axis  # 'y' 或 'z'
        self._config = config or load_config()
        self._gm_cfg = self._config.get('grid_map', {})

        if up_axis == 'z':
            h_idx = 1
            self._h_label = 'y'
        else:
            h_idx = 1
            self._h_label = 'z'

        # 边界计算
        if obstacle_points_2d is not None and len(obstacle_points_2d) > 0:
            all_pts = np.vstack([floor_points_2d, obstacle_points_2d])
        else:
            all_pts = floor_points_2d

        self.x_min, self.h_min = all_pts.min(axis=0)
        self.x_max, self.h_max = all_pts.max(axis=0)

        self.width = int(np.ceil((self.x_max - self.x_min) / resolution)) + 2 * padding
        self.height = int(np.ceil((self.h_max - self.h_min) / resolution)) + 2 * padding

        # 初始化: 0 = 未知/不可行走
        self.grid = np.zeros((self.height, self.width), dtype=np.uint8)

        # 标记可行走 (floor 点)
        self._mark_floor(floor_points_2d)

        if obstacle_points_2d is not None and len(obstacle_points_2d) > 0:
            self._mark_obstacles(obstacle_points_2d)
            # 孤立障碍物移除已禁用
            # obs_cfg = self._gm_cfg.get('obstacle', {})
            # isolation_radius = obs_cfg.get('isolation_radius', 1.0)
            # self._remove_isolated_obstacles(isolation_radius_m=isolation_radius)

        self._fill_floor_gaps()

        # 连通组件
        self.connected_components = None
        self.component_labels = None
        self.component_gateways = []

        # Door 信息
        self.doors = []

    def _world_to_grid(self, x, h):
        grid_x = int((x - self.x_min) / self.resolution) + self.padding
        grid_h = int((h - self.h_min) / self.resolution) + self.padding
        return grid_x, grid_h

    def world_to_grid(self, x, h):
        """世界坐标 → 栅格坐标 (public)"""
        return self._world_to_grid(x, h)

    def _grid_to_world(self, grid_x, grid_h):
        x = (grid_x - self.padding) * self.resolution + self.x_min + self.resolution / 2
        h = (grid_h - self.padding) * self.resolution + self.h_min + self.resolution / 2
        return x, h
    
    def _mark_floor(self, floor_points_2d):
        """标记 floor 点"""
        for pt in floor_points_2d:
            gx, gz = self._world_to_grid(pt[0], pt[1])
            if 0 <= gx < self.width and 0 <= gz < self.height:
                self.grid[gz, gx] = 1
    
    def _fill_floor_gaps(self):
        """填充 floor 空洞 (基于形态学操作, 障碍物作为屏障)"""
        floor_mask = (self.grid == 1).astype(np.uint8)
        obstacle_mask = (self.grid == 100).astype(np.uint8)

        # 闭运算: 先膨胀后腐蚀，填充小空洞 (但不越过障碍物)
        kernel_size = self._gm_cfg.get('morph_kernel_size', 5)
        morph_iters = self._gm_cfg.get('morph_iterations', 2)
        gap_dist = self._gm_cfg.get('gap_filling_distance_threshold', 20)
        kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
        # 膨胀时排除障碍物区域, 防止 floor 膨胀穿过障碍物
        dilated = binary_dilation(floor_mask, structure=kernel, iterations=morph_iters)
        dilated = dilated & ~obstacle_mask.astype(bool)
        closed = binary_erosion(dilated, structure=kernel, iterations=morph_iters)

        # 距离变换: 障碍物标记为 True 作为屏障, 距离不会跨越障碍物
        # EDT 对 False 像素计算到最近 True 像素的距离
        # floor=True, obstacle=True → 未知区域的距离 = min(到floor, 到obstacle)
        edt_input = floor_mask.astype(bool) | obstacle_mask.astype(bool)
        dist = distance_transform_edt(~edt_input)

        fill_mask = closed & (dist < gap_dist)  # gap_dist 像素内填充

        # 更新 grid (只填充未知区域, 不覆盖障碍物)
        self.grid[fill_mask & (self.grid == 0)] = 1
    
    def _mark_obstacles(self, obstacle_points_2d):
        """标记障碍物 (每个 footprint cell 栅格化为 NxN 的 resolution cells)"""
        # 统计 obstacle
        floor_mask = (self.grid == 1).astype(np.uint8)

        # 每个 footprint 对应 NxN cells (footprint_resolution / grid_resolution)
        obs_cfg = self._gm_cfg.get('obstacle', {})
        footprint_res = obs_cfg.get('footprint_resolution', 0.2)
        cells_per_footprint = int(round(footprint_res / self.resolution))
        half = cells_per_footprint // 2

        for pt in obstacle_points_2d:
            # 计算 footprint 中心对应的 grid 坐标
            cx, cz = self._world_to_grid(pt[0], pt[1])
            # 栅格化为 4x4 区域
            for dx in range(-half, half):
                for dz in range(-half, half):
                    gx, gz = cx + dx, cz + dz
                    if 0 <= gx < self.width and 0 <= gz < self.height:
                        self.grid[gz, gx] = 100

        obstacle_count = np.sum(self.grid == 100)
        floor_protected = np.sum(floor_mask & (self.grid == 1))
        print(f"  Obstacle cells: {obstacle_count:,}, Floor protected: {floor_protected:,}")

    def _remove_isolated_obstacles(self, isolation_radius_m=1.0):
        """
        移除孤立障碍物：使用形态学开运算移除小的障碍物块。
        开运算 = 先腐蚀后膨胀，可以移除小于结构元素的物体。
        """
        obstacle_mask = (self.grid == 100).astype(np.uint8)
        if np.sum(obstacle_mask) == 0:
            return

        from scipy.ndimage import binary_opening, binary_erosion

        # 使用十字形结构元素进行开运算（只检查上下左右 4 个邻居）
        # 这比 3×3 方形更严格，只移除真正孤立的点
        structure = np.array([[0, 1, 0],
                              [1, 1, 1],
                              [0, 1, 0]], dtype=np.uint8)
        opened = binary_opening(obstacle_mask, structure=structure)

        # 被移除的障碍物 = 原始障碍物 - 开运算后的障碍物
        removed = obstacle_mask & ~opened

        # 将被移除的障碍物标记为 floor
        self.grid[removed == 1] = 1

        removed_count = np.sum(removed)
        remaining_count = np.sum(self.grid == 100)
        print(f"  孤立障碍物移除：{removed_count:,} cells → floor, 剩余障碍物：{remaining_count:,}")

    def set_doors(self, doors):
        """
        门的位置
        doors: list of dict with 'center', 'bbox', 'name'
        """
        self.doors = doors

        # 门的位置作为连接点
        gateways = []
        for door in doors:
            center = door['center']
            # 根据 up_axis 选择水平面坐标
            if self.up_axis == 'z':
                gx, gh = self._world_to_grid(center[0], center[1])  # X-Y
            else:
                gx, gh = self._world_to_grid(center[0], center[2])  # X-Z

            # 在 grid 中标记门的位置 (可行走)
            if 0 <= gx < self.width and 0 <= gh < self.height:
                self.grid[gh, gx] = 1

            # 膨胀门周围区域为可行走
            for dx in range(-2, 3):
                for dh in range(-2, 3):
                    nx, nh = gx + dx, gh + dh
                    if 0 <= nx < self.width and 0 <= nh < self.height:
                        if self.grid[nh, nx] == 0:  # 只影响未知区域
                            self.grid[nh, nx] = 1

            gateways.append({
                'door_name': door.get('name', 'unknown'),
                'center_2d': [center[0], center[1] if self.up_axis == 'z' else center[2]],
                'center_grid': [gx, gh],
            })

        self.component_gateways = gateways
        return gateways
    
    def find_connected_components(self, min_points=100):
        """查找连通组件"""
        walkable = (self.grid == 1).astype(np.uint8)
        labeled, num_features = label(walkable)
        self.component_labels = labeled

        components = {}
        for comp_id in range(1, num_features + 1):
            mask = labeled == comp_id
            pts_2d = []
            for gh in range(self.height):
                for gx in range(self.width):
                    if mask[gh, gx]:
                        x, h = self._grid_to_world(gx, gh)
                        pts_2d.append((x, h))

            if len(pts_2d) >= min_points:
                pts_arr = np.array(pts_2d)
                centroid = pts_arr.mean(axis=0)
                components[comp_id] = {
                    'points': pts_2d,
                    'centroid': centroid,
                    'num_points': len(pts_2d),
                    'bbox_min': pts_arr.min(axis=0),
                    'bbox_max': pts_arr.max(axis=0),
                }

        self.connected_components = components
        return components
    
    def get_grid(self):
        return self.grid.copy()
    
    def is_walkable(self, grid_x, grid_z):
        if not (0 <= grid_x < self.width and 0 <= grid_z < self.height):
            return False
        return self.grid[grid_z, grid_x] == 1
    
    def save_visualization(self, output_path):
        import cv2
        vis = np.zeros((self.height, self.width, 3), dtype=np.uint8)

        # 可行走
        walkable_mask = self.grid == 1
        vis[walkable_mask] = [0, 255, 0]

        # 障碍
        obstacle_mask = self.grid == 100
        vis[obstacle_mask] = [0, 0, 255]

        # 未知
        unknown_mask = self.grid == 0
        vis[unknown_mask] = [50, 50, 50]

        # 门位置
        for gw in self.component_gateways:
            gx, gh = gw['center_grid']
            if 0 <= gx < self.width and 0 <= gh < self.height:
                vis[gh, gx] = [255, 255, 0]
                for d in range(-3, 4):
                    if 0 <= gx + d < self.width:
                        vis[gh, gx + d] = [255, 255, 0]
                    if 0 <= gh + d < self.height:
                        vis[gh + d, gx] = [255, 255, 0]

        if self.connected_components:
            colors = [
                [0, 180, 180], [180, 0, 180], [180, 180, 0],
                [0, 90, 180], [180, 90, 0], [90, 0, 180],
                [0, 180, 90], [180, 0, 90],
            ]
            for idx, comp_id in enumerate(sorted(self.connected_components.keys())):
                color = colors[idx % len(colors)]
                mask = self.component_labels == comp_id
                vis[mask & walkable_mask] = color

        cv2.imwrite(str(output_path), vis)
        print(f"  栅格地图可视化已保存: {output_path}")


def extract_floor_and_obstacles(points, floor_y_threshold=0.6, up_axis='y', config=None):
    """
    提取 floor 和 obstacle

    参数:
        points: 全局点云 (N, 3)
        floor_y_threshold: floor 高度阈值 (米)
            - 推荐值: 0.2-0.5m
            - 过大 (如 1.0m) 会导致矮家具被误判为 floor
        up_axis: 'y' (Y-up) 或 'z' (Z-up)
        config: 配置字典 (可选)

    返回:
        floor_2d: floor 点 2D 坐标
        obstacle_2d: obstacle 点 2D 坐标
        floor_y_global: 全局 floor 高度
    """
    cfg = config or load_config()
    gm_cfg = cfg.get('grid_map', {})
    obs_cfg = gm_cfg.get('obstacle', {})
    band_size = gm_cfg.get('band_size', 0.3)
    footprint_res = obs_cfg.get('footprint_resolution', 0.2)
    subsample_zup = obs_cfg.get('subsample_zup', 50)
    subsample_yup = obs_cfg.get('subsample_yup', 100)
    z_span_zup = obs_cfg.get('z_span_threshold_zup', 0.05)
    z_span_yup = obs_cfg.get('z_span_threshold_yup', 0.5)
    if up_axis == 'z':
        # Z-up: Z 是高度, 投影到 X-Y 平面
        # 按 Y 分带, 用 Z 做高度阈值
        h_min_all = points[:, 1].min()
        h_max_all = points[:, 1].max()
        height_idx = 2  # Z
        h_idx = 1       # Y

        floor_2d_list = []
        floor_y_map = {}

        h_bands = np.arange(h_min_all - band_size, h_max_all + band_size, band_size)

        for i in range(len(h_bands) - 1):
            h_low = h_bands[i]
            h_high = h_bands[i + 1]

            band_mask = (points[:, h_idx] >= h_low) & (points[:, h_idx] < h_high)
            band_pts = points[band_mask]

            if len(band_pts) < 100:
                continue

            # 局部 Z 10th percentile + threshold = floor threshold
            z_10 = np.percentile(band_pts[:, height_idx], 10)
            floor_z = z_10 + floor_y_threshold

            h_mid = (h_low + h_high) / 2
            floor_y_map[h_mid] = floor_z

            floor_mask = band_pts[:, height_idx] < floor_z
            floor_pts = band_pts[floor_mask]
            if len(floor_pts) > 0:
                floor_2d_list.append(floor_pts[:, [0, h_idx]])  # [x, y]

        floor_2d = np.vstack(floor_2d_list) if floor_2d_list else np.array([]).reshape(0, 2)
        floor_y_global = min(floor_y_map.values()) if floor_y_map else 0

        # 提取 obstacle：单元内点云的 Z 跨度 > threshold → obstacle
        print(f"  提取障碍物 (基于垂直 Z 跨度, Z-up)...")

        x_min, x_max = points[:, 0].min(), points[:, 0].max()
        y_min, y_max = points[:, 1].min(), points[:, 1].max()

        grid_x = int(np.ceil((x_max - x_min) / footprint_res)) + 2
        grid_y = int(np.ceil((y_max - y_min) / footprint_res)) + 2

        from collections import defaultdict
        cell_zs = defaultdict(list)
        for pt in points[::subsample_zup]:
            gx = int((pt[0] - x_min) / footprint_res)
            gy = int((pt[1] - y_min) / footprint_res)
            cell_zs[(gx, gy)].append(pt[2])

        obstacle_2d_list = []
        for (gx, gy), zs in cell_zs.items():
            z_span = max(zs) - min(zs)
            if z_span > z_span_zup:
                x = (gx - 1) * footprint_res + x_min
                y = (gy - 1) * footprint_res + y_min
                obstacle_2d_list.append([x, y])

        obstacle_2d = np.array(obstacle_2d_list) if obstacle_2d_list else np.array([]).reshape(0, 2)

        print(f"  Floor 提取 (自适应 Y 分带, band={band_size}m, Z-up):")
        print(f"  总 band 数: {len(floor_y_map)}")
        for h_mid in sorted(floor_y_map.keys()):
            fz = floor_y_map[h_mid]
            print(f"    Y≈{h_mid:.1f}: floor_z={fz:.2f}")

        print(f"  总 Floor 点数: {len(floor_2d):,}")
        print(f"  总 Obstacle 点数 (footprint): {len(obstacle_2d):,}")
        print(f"  全局 floor_z (最小值): {floor_y_global:.3f}")

    else:
        # Y-up: Y 是高度, 投影到 X-Z 平面 (原始逻辑)
        z_min_all = points[:, 2].min()
        z_max_all = points[:, 2].max()

        floor_2d_list = []
        floor_y_map = {}
        floor_y_by_z = {}

        z_bands = np.arange(z_min_all - band_size, z_max_all + band_size, band_size)

        for i in range(len(z_bands) - 1):
            z_low = z_bands[i]
            z_high = z_bands[i + 1]

            band_mask = (points[:, 2] >= z_low) & (points[:, 2] < z_high)
            band_pts = points[band_mask]

            if len(band_pts) < 100:
                continue

            y_10 = np.percentile(band_pts[:, 1], 10)
            floor_y = y_10 + floor_y_threshold

            z_mid = (z_low + z_high) / 2
            floor_y_map[z_mid] = floor_y

            floor_mask = band_pts[:, 1] < floor_y
            floor_pts = band_pts[floor_mask]
            if len(floor_pts) > 0:
                floor_2d_list.append(floor_pts[:, [0, 2]])

        floor_2d = np.vstack(floor_2d_list) if floor_2d_list else np.array([]).reshape(0, 2)
        floor_y_global = min(floor_y_map.values()) if floor_y_map else 0

        print(f"  提取障碍物 (基于垂直 Y 跨度)...")

        x_min, x_max = points[:, 0].min(), points[:, 0].max()
        z_min, z_max = points[:, 2].min(), points[:, 2].max()

        grid_x = int(np.ceil((x_max - x_min) / footprint_res)) + 2
        grid_z = int(np.ceil((z_max - z_min) / footprint_res)) + 2

        obstacle_cells = set()
        for idx in range(0, len(points), subsample_yup):
            batch = points[idx:idx+subsample_yup]
            for pt in batch:
                gx = int((pt[0] - x_min) / footprint_res)
                gz = int((pt[2] - z_min) / footprint_res)
                if 0 <= gx < grid_x and 0 <= gz < grid_z:
                    obstacle_cells.add((gx, gz))

        from collections import defaultdict
        cell_ys = defaultdict(list)
        for pt in points[::subsample_yup]:
            gx = int((pt[0] - x_min) / footprint_res)
            gz = int((pt[2] - z_min) / footprint_res)
            cell_ys[(gx, gz)].append(pt[1])

        obstacle_2d_list = []
        for (gx, gz), ys in cell_ys.items():
            y_span = max(ys) - min(ys)
            if y_span > z_span_yup:
                x = (gx - 1) * footprint_res + x_min
                z = (gz - 1) * footprint_res + z_min
                obstacle_2d_list.append([x, z])

        obstacle_2d = np.array(obstacle_2d_list) if obstacle_2d_list else np.array([]).reshape(0, 2)

        print(f"  Floor 提取 (自适应 Z 分带, band={band_size}m):")
        print(f"  总 band 数: {len(floor_y_map)}")
        for z_mid in sorted(floor_y_map.keys()):
            fy = floor_y_map[z_mid]
            print(f"    Z≈{z_mid:.1f}: floor_y={fy:.2f}")

        print(f"  总 Floor 点数: {len(floor_2d):,}")
        print(f"  总 Obstacle 点数 (footprint): {len(obstacle_2d):,}")
        print(f"  全局 floor_y (最小值): {floor_y_global:.3f}")

    return floor_2d, obstacle_2d, floor_y_global


def create_grid_map_from_pointcloud(global_pcd_path, scene_graph_path=None,
                                    resolution=0.05, floor_y_threshold=0.6,
                                    points=None, up_axis='y', config=None):
    """
    全局点云 + scene graph 创建栅格地图

    参数:
        global_pcd_path: 全局点云路径
        scene_graph_path: scene graph JSON 路径
        resolution: 栅格分辨率
        floor_y_threshold: floor 高度阈值 (米)
        points: 预加载的点云数组 (N,3)。
        up_axis: 'y' (Y-up) 或 'z' (Z-up)
        config: 配置字典 (可选)

    返回:
        grid_map: GridMap 对象
        floor_y: 地面高度
    """
    cfg = config or load_config()
    gm_cfg = cfg.get('grid_map', {})
    if points is None:
        print(f"加载点云: {global_pcd_path}")
        pcd = o3d.io.read_point_cloud(str(global_pcd_path))
        points = np.asarray(pcd.points)
        print(f"  总点数: {len(points):,}")
    else:
        print(f"使用预加载点云: {len(points):,} 个点 (up_axis={up_axis})")

    # 提取 floor 和 obstacle
    print("提取 floor 和 obstacle...")
    floor_2d, obstacle_2d, floor_y = extract_floor_and_obstacles(
        points, floor_y_threshold, up_axis=up_axis, config=cfg
    )

    # 创建栅格地图
    print(f"创建栅格地图 (分辨率: {resolution}m, up_axis={up_axis})...")
    grid_map = GridMap(floor_2d, obstacle_2d, resolution=resolution, up_axis=up_axis, config=cfg)
    
    # 加载 scene graph 中的 doors
    if scene_graph_path and Path(scene_graph_path).exists():
        print("加载 scene graph doors...")
        with open(scene_graph_path, 'r') as f:
            scene_graph = json.load(f)
        
        doors = []
        for obj in scene_graph.get('objects', []):
            if obj.get('category') == 'door':
                doors.append(obj)
        
        print(f"  找到 {len(doors)} 个门")
        grid_map.set_doors(doors)
    
    print("膨胀障碍物...")
    obstacle_mask = (grid_map.grid == 100).astype(np.uint8)
    dil_kernel = gm_cfg.get('floor_dilation_kernel', 3)
    dil_iters = gm_cfg.get('floor_dilation_iterations', 3)
    kernel = np.ones((dil_kernel, dil_kernel), dtype=np.uint8)
    from scipy.ndimage import binary_dilation
    dilated = binary_dilation(obstacle_mask, structure=kernel, iterations=dil_iters)
    # Floor 保护：膨胀后的障碍物不覆盖已有的 floor
    floor_mask = (grid_map.grid == 1).astype(bool)
    grid_map.grid[dilated & ~floor_mask] = 100

    print("查找连通组件...")
    components = grid_map.find_connected_components(min_points=100)
    print(f"  找到 {len(components)} 个连通组件")
    
    return grid_map, floor_y


def main():
    import argparse
    parser = argparse.ArgumentParser(description='2D 栅格地图生成器')
    parser.add_argument('--pcd', type=str, default='unified_output/global/global_pointcloud.ply')
    parser.add_argument('--scene-graph', type=str, default='unified_output/scene_graph.json')
    parser.add_argument('--resolution', type=float, default=0.05)
    parser.add_argument('--output', type=str, default='navigation/grid_map_floor.png')
    args = parser.parse_args()
    
    from pathlib import Path
    base_dir = Path(__file__).resolve().parent.parent
    pcd_path = base_dir / args.pcd
    sg_path = base_dir / args.scene_graph
    output_path = base_dir / args.output
    
    print("=" * 60)
    print("2D 栅格地图生成器")
    print("=" * 60)
    
    grid_map, floor_y = create_grid_map_from_pointcloud(
        str(pcd_path), str(sg_path), args.resolution
    )
    
    output_path.parent.mkdir(parents=True, exist_ok=True)
    grid_map.save_visualization(output_path)
    
    print(f"\n栅格尺寸: {grid_map.width} x {grid_map.height}")
    h_label = grid_map._h_label.upper()
    print(f"世界范围: X[{grid_map.x_min:.2f}, {grid_map.x_max:.2f}], "
          f"{h_label}[{grid_map.h_min:.2f}, {grid_map.h_max:.2f}]")
    print(f"可行走: {np.sum(grid_map.grid == 1):,}, 障碍: {np.sum(grid_map.grid == 100):,}")

    if grid_map.connected_components:
        for comp_id, comp in sorted(grid_map.connected_components.items()):
            c = comp['centroid']
            print(f"  组件 {comp_id}: 中心=({c[0]:.2f}, {c[1]:.2f}), 点数={comp['num_points']:,}")

    if grid_map.component_gateways:
        print(f"\n门 ({len(grid_map.component_gateways)} 个):")
        for gw in grid_map.component_gateways:
            print(f"  {gw['door_name']}: ({gw['center_2d'][0]:.2f}, {gw['center_2d'][1]:.2f})")

    import pickle
    data_path = output_path.with_suffix('.pkl')
    with open(data_path, 'wb') as f:
        pickle.dump({
            'grid': grid_map.get_grid(),
            'x_min': grid_map.x_min,
            'h_min': grid_map.h_min,
            'resolution': grid_map.resolution,
            'padding': grid_map.padding,
            'floor_y': floor_y,
            'width': grid_map.width,
            'height': grid_map.height,
            'connected_components': grid_map.connected_components,
            'component_gateways': grid_map.component_gateways,
            'doors': grid_map.doors,
            'up_axis': grid_map.up_axis,
        }, f)
    print(f"\n栅格数据已保存: {data_path}")
    print("=" * 60)


if __name__ == '__main__':
    main()
