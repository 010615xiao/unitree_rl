"""
导航轨迹重投影

  1. 将轨迹点沿 Y 轴投影到地板平面 (地板法向量方向)
  2. 调用 GroundingDINO + SAM2 获取 floor 分割掩码
  3. 对每张图片，将地板投影点重投影到图像平面
  4. 筛选: 只保留落在 floor mask 内的轨迹点
  5. 输出: 原图 + floor mask (半透明) + 筛选后的轨迹点
  6. 导出地板投影后的轨迹为点云 (.ply)

用法:
  python project_trajectory_to_images.py --path paths/path_我想打印资料.json \
    --images paths/我想打印资料_images

  # 不使用 floor mask 筛选
  python project_trajectory_to_images.py --path ... --images ... --no-floor-mask

  # 手动指定 SAM2/DINO 服务地址
  python project_trajectory_to_images.py --path ... --images ... \
    --sam2-url http://localhost:20020 --dino-url http://localhost:20021

  # 手动指定地板 Y 坐标
  python project_trajectory_to_images.py --path ... --images ... --floor-y 0.1

  # 使用原始未重采样轨迹
  python project_trajectory_to_images.py --path ... --images ... --use-raw
"""

import argparse
import json
import struct
import base64
import io
import sys
import requests
import cv2
import numpy as np
from pathlib import Path
from scipy.spatial.transform import Rotation as R

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent.parent / 'global_reconstruction' / 'core'))
from config_loader import find_poses_file, get_config, service_url, model_path

_cfg = get_config()

T_SWITCH_AXIS = np.array([
    [1, 0, 0, 0],
    [0, 0, 1, 0],
    [0, -1, 0, 0],
    [0, 0, 0, 1]
], dtype=np.float64)

# 内参
K = np.array([
    [_cfg.camera.fx, 0,           _cfg.camera.cx],
    [0,              _cfg.camera.fy, _cfg.camera.cy],
    [0,              0,           1.0]
], dtype=np.float64)

IMG_W, IMG_H = 640, 480


def load_poses(poses_file):
    """加载 poses.txt → {timestamp: T_c2w} (世界坐标系)"""
    result = {}
    with open(poses_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) < 8:
                continue

            timestamp = parts[0]
            tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
            qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

            quat = [qx, qy, qz, qw]
            rot_matrix = R.from_quat(quat).as_matrix()

            T_w2c = np.eye(4)
            T_w2c[:3, :3] = rot_matrix
            T_w2c[:3, 3] = [tx, ty, tz]

            T_c2w = np.linalg.inv(T_w2c)
            T_c2w = T_SWITCH_AXIS @ T_c2w

            result[timestamp] = T_c2w
    return result


def project_points_to_image(traj_points, T_c2w, K_mat, img_w=IMG_W, img_h=IMG_H,
                             max_distance=10.0, min_depth=0.05):
    """
    将 3D 轨迹点投影到当前相机图像

    Args:
        traj_points: (N, 3) 世界坐标系轨迹点
        T_c2w: (4, 4) 相机到世界的变换矩阵
        K_mat: (3, 3) 相机内参

    Returns:
        valid_uv: (M, 2) 有效投影点的像素坐标
        valid_depths: (M,) 对应深度
    """
    T_w2c = np.linalg.inv(T_c2w)

    # 世界坐标 → 相机坐标
    pts_world = np.hstack([np.array(traj_points), np.ones((len(traj_points), 1))]).T  # (4, N)
    pts_cam = T_w2c @ pts_world  # (4, N)
    pts_cam = pts_cam[:3]  # (3, N)

    # 深度过滤: 只保留相机前方的点
    depth = pts_cam[2]  # (N,)
    valid = depth > min_depth

    # 距离过滤
    valid = valid & (depth < max_distance)

    if not np.any(valid):
        return np.empty((0, 2)), np.empty(0)

    pts_cam_valid = pts_cam[:, valid]
    depth_valid = pts_cam_valid[2]

    # 投影到像素坐标
    uv_homogeneous = K_mat @ pts_cam_valid  # (3, M)
    uv = uv_homogeneous[:2] / uv_homogeneous[2]  # (2, M)

    # 图像边界过滤
    u, v = uv[0], uv[1]
    in_bounds = (u >= 0) & (u < img_w) & (v >= 0) & (v < img_h)

    uv_final = np.stack([u[in_bounds], v[in_bounds]], axis=-1)
    depth_final = depth_valid[in_bounds]

    return uv_final, depth_final


def draw_projection(image, uv_points, depths, max_distance=10.0, point_radius=20):
    """
    在图像上绘制投影的轨迹点
    """
    result = image.copy()

    if len(uv_points) == 0:
        return result

    for i in range(len(uv_points)):
        u, v = int(uv_points[i, 0]), int(uv_points[i, 1])
        cv2.circle(result, (u, v), point_radius, (0, 0, 255), -1)

    return result


def call_trajectory_pixel_api(image_path, pixel_x, pixel_y, trajectory_api_url):
    """
    调用 /api/trajectory_pixel 生成从起点到目标点的轨迹

    Returns:
        dict with keys: success, message, trajectory, num_points, start_point, error
    """
    try:
        resp = requests.post(
            f"{trajectory_api_url}/api/trajectory_pixel",
            files={"image": open(image_path, "rb")},
            data={
                "pixel_x": str(int(pixel_x)),
                "pixel_y": str(int(pixel_y)),
                "render_all_views": "false",
                "return_rendered_views": "false",
                "save_zip": "false",
                "save_trajectory_3d": "false",
            },
            timeout=120,
        )
        result = resp.json()

        if resp.status_code != 200:
            return {
                "success": False,
                "message": result.get("detail", f"HTTP {resp.status_code}"),
                "error": result.get("detail", ""),
            }

        return result
    except requests.exceptions.Timeout:
        return {"success": False, "message": "API 超时 (120s)", "error": "timeout"}
    except Exception as e:
        return {"success": False, "message": str(e), "error": str(e)}


def draw_trajectory_on_image(image, api_result, traj_point_uv):
    """
    绘制 API 返回的轨迹 + 当前帧的投影点
    """
    result = image.copy()

    if not api_result.get("success"):
        cv2.putText(result, f"Trajectory FAIL: {api_result.get('message', 'unknown')[:50]}",
                   (10, result.shape[0] - 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
        return result

    trajectory = api_result.get("trajectory", [])
    if len(trajectory) < 2:
        cv2.putText(result, f"No trajectory ({len(trajectory)} pts)",
                   (10, result.shape[0] - 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        return result

    # 轨迹线
    pts = np.array([(int(p["x"]), int(p["y"])) for p in trajectory], dtype=np.int32)
    cv2.polylines(result, [pts], False, (0, 255, 255), 2)

    # 轨迹点
    for i, p in enumerate(trajectory):
        px, py = int(p["x"]), int(p["y"])
        cv2.circle(result, (px, py), 3, (0, 255, 255), -1)
        if i == 0:
            cv2.circle(result, (px, py), 8, (0, 255, 0), 2)
        elif i == len(trajectory) - 1:
            cv2.circle(result, (px, py), 8, (255, 0, 0), 2)

    return result


def get_floor_mask(image_path, sam2_url, dino_url):
    """
    GroundingDINO + SAM2 获取 floor 分割掩码

    1. GroundingDINO 检测 floor 检测框
    2. SAM2 根据检测框分割 floor

    Returns:
        mask: (H, W) bool 数组, True 表示 floor 区域
        box: floor 检测框 [x1, y1, x2, y2] 或 None
    """
    # Step 1: GroundingDINO 检测 floor
    try:
        resp = requests.post(f"{dino_url}/detect", json={
            "image_path": str(Path(image_path).resolve()),
            "text_prompt": "floor",
            "box_threshold": 0.3,
            "text_threshold": 0.2,
        }, timeout=30)
        dino_result = resp.json()
    except Exception as e:
        print(f"  GroundingDINO 调用失败: {e}")
        return None, None

    if not dino_result.get('success') or dino_result.get('num_detections', 0) == 0:
        return None, None

    # 选最高分的 box
    best_idx = np.argmax(dino_result['scores'])
    box = dino_result['boxes'][best_idx]
    label = dino_result['labels'][best_idx]
    score = dino_result['scores'][best_idx]

    # Step 2: SAM2 分割
    try:
        resp = requests.post(f"{sam2_url}/segment", json={
            "image_path": str(Path(image_path).resolve()),
            "box": box,
        }, timeout=30)
        sam2_result = resp.json()
    except Exception as e:
        print(f"  SAM2 调用失败: {e}")
        return None, None

    if not sam2_result.get('success') or sam2_result.get('mask') is None:
        return None, None

    mask_bytes = base64.b64decode(sam2_result['mask'])
    mask_arr = np.frombuffer(mask_bytes, dtype=np.uint8)
    mask_img = cv2.imdecode(mask_arr, cv2.IMREAD_GRAYSCALE)

    if mask_img is None:
        return None, None

    # 转为二值 mask (255 → True)
    floor_mask = mask_img > 127
    return floor_mask, box


def filter_points_by_mask(uv_points, floor_mask):
    """
    筛选落在 floor mask 内的投影点

    Args:
        uv_points: (N, 2) 像素坐标
        floor_mask: (H, W) bool 数组

    Returns:
        keep_mask: (N,) bool 数组, True 表示在 floor mask 内
    """
    if floor_mask is None:
        return np.ones(len(uv_points), dtype=bool)

    h, w = floor_mask.shape
    u = np.clip(uv_points[:, 0].astype(int), 0, w - 1)
    v = np.clip(uv_points[:, 1].astype(int), 0, h - 1)

    return floor_mask[v, u]


def draw_floor_mask(image, floor_mask, alpha=0.25):
    if floor_mask is None:
        return image.copy()

    result = image.copy()
    overlay = image.copy()
    overlay[floor_mask] = (255, 0, 0)  # 蓝色
    cv2.addWeighted(overlay, alpha, result, 1.0 - alpha, 0, result)
    return result


def write_ply(filename, points, colors=None):
    """
    写入 PLY 点云文件

    Args:
        points: (N, 3) 顶点坐标
        colors: (N, 3) RGB 颜色
    """
    n = len(points)
    has_color = colors is not None and len(colors) == n

    header = (
        "ply\n"
        "format ascii 1.0\n"
        f"element vertex {n}\n"
        "property float x\n"
        "property float y\n"
        "property float z\n"
    )
    if has_color:
        header += (
            "property uchar red\n"
            "property uchar green\n"
            "property uchar blue\n"
        )
    header += "end_header\n"

    with open(filename, 'w') as f:
        f.write(header)
        for i in range(n):
            line = f"{points[i,0]:.4f} {points[i,1]:.4f} {points[i,2]:.4f}"
            if has_color:
                c = colors[i]
                line += f" {int(c[0])} {int(c[1])} {int(c[2])}"
            f.write(line + "\n")


def main():
    parser = argparse.ArgumentParser(description='将导航轨迹重投影到对应图片 (地板投影)')
    parser.add_argument('--path', type=str, required=True,
                       help='导航路径 JSON 文件')
    parser.add_argument('--images', type=str, required=True,
                       help='提取出的图片目录')
    parser.add_argument('--poses', type=str, default=None,
                       help='poses.txt 路径')
    parser.add_argument('--output', type=str, default=None,
                       help='输出目录 (默认: <images>_projected/)')
    parser.add_argument('--use-raw', action='store_true',
                       help='使用原始未重采样的路径 (默认使用 low_level_path_resampled)')
    parser.add_argument('--max-distance', type=float, default=20.0,
                       help='最大投影距离 (米), 默认 20.0')
    parser.add_argument('--draw-all', action='store_true',
                       help='投影所有轨迹点 (默认只投影该帧之后的轨迹点)')
    parser.add_argument('--floor-y', type=float, default=None,
                       help='地板 Y 坐标 (默认自动从轨迹最小值估算)')
    parser.add_argument('--point-radius', type=int, default=3,
                       help='投影点半径, 默认 3')
    parser.add_argument('--shift-height', type=float, default=None,
                       help='相机到地板的高度 (米), 沿法向量下移. 默认自动: 轨迹Y范围')
    parser.add_argument('--no-floor-mask', action='store_true',
                       help='不使用 floor mask 筛选轨迹点')
    parser.add_argument('--sam2-url', type=str, default='http://localhost:20020',
                       help='SAM2 服务地址 (默认: http://localhost:20020)')
    parser.add_argument('--dino-url', type=str, default='http://localhost:20021',
                       help='GroundingDINO 服务地址 (默认: http://localhost:20021)')
    parser.add_argument('--trajectory-api-url', type=str, default='http://localhost:9000',
                       help='Trajectory 2D API 地址 (默认: http://localhost:9000)')
    parser.add_argument('--draw-trajectory', action='store_true',
                       help='调用 Trajectory 2D API 在图上绘制导航轨迹 (黄色线+点)')
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent

    path_file = Path(args.path)
    if not path_file.exists():
        alt = base_dir / 'paths' / path_file.name
        if alt.exists():
            path_file = alt
        else:
            print(f"错误: 路径文件不存在: {args.path}")
            return

    with open(path_file, 'r') as f:
        path_data = json.load(f)

    if not path_data.get('success'):
        print("错误: 该路径规划失败")
        return

    path_key = 'low_level_path' if args.use_raw else 'low_level_path_resampled'
    trajectory = np.array(path_data[path_key])
    print(f"加载路径: {path_file.name}")
    print(f"  使用: {path_key}")
    print(f"  轨迹点数: {len(trajectory)}")
    print(f"  Y 范围: {trajectory[:,1].min():.3f} ~ {trajectory[:,1].max():.3f}")
    print(f"  总距离: {path_data['total_distance']:.2f}m")

    # ===== poses =====
    if args.poses:
        poses_file = Path(args.poses)
    else:
        poses_file = find_poses_file(base_dir=base_dir)
        if poses_file is None:
            print("错误: 未找到 poses.txt")
            return

    # ===== 图片 =====
    images_dir = Path(args.images)
    if not images_dir.exists():
        print(f"错误: 图片目录不存在: {images_dir}")
        return

    # 加载 manifest.json
    manifest_file = images_dir / 'manifest.json'
    manifest = None
    if manifest_file.exists():
        with open(manifest_file, 'r') as f:
            manifest = json.load(f)
        print(f"\n加载 manifest: {manifest_file}")
        print(f"  提取帧数: {manifest['extracted_frames']}")
        print(f"  路径文件: {manifest['path_file']}")

    # 按顺序加载图片
    img_files = sorted(images_dir.glob('*.png'))
    if not img_files:
        img_files = sorted(images_dir.glob('*.jpg'))
    if not img_files:
        print(f"错误: 图片目录为空: {images_dir}")
        return

    # 如果存在 manifest，过滤掉 manifest.json 本身并建立索引映射
    frame_index_map = {}  # filename → manifest entry
    if manifest is not None:
        for frame_entry in manifest['frames']:
            frame_index_map[frame_entry['filename']] = frame_entry
        print(f"  manifest 映射: {len(frame_index_map)} 条")

    # ===== 加载地板平面 + 投影 =====
    plane_file = base_dir.parent / 'unified_output' / 'trajectory_plane.json'

    if plane_file.exists():
        with open(plane_file, 'r') as f:
            plane_data = json.load(f)
        plane_normal = np.array(plane_data['normal'])
        plane_d = plane_data['d']
        inlier_ratio = plane_data.get('inlier_ratio', 0)
        print(f"\n加载相机轨迹平面: {plane_file}")
        print(f"  法向量: {plane_normal}")
        print(f"  d={plane_d:.4f}, 内点={inlier_ratio:.1f}%")

        # 1) 沿法向量投影到轨迹平面 (P → 相机平面)
        dists = np.sum(trajectory * plane_normal, axis=1) + plane_d
        trajectory_proj = trajectory - dists[:, np.newaxis] * plane_normal

        # 2) 沿法向量下移到地板
        if args.shift_height is not None:
            height_shift = args.shift_height
        else:
            # 自动估算: 轨迹Y范围作为相机高度估计
            height_shift = float(trajectory[:, 1].max() - trajectory[:, 1].min())
            if height_shift < 0.3:
                height_shift = 0.9  # 兜底默认

        # 沿法向量反向 (向下) 平移
        trajectory_on_floor = trajectory_proj - height_shift * plane_normal
        floor_y = trajectory_on_floor[:, 1].mean()
        print(f"  投影到轨迹平面: 最大偏差 {np.max(np.abs(dists)):.3f}m")
        print(f"  下移 {height_shift:.2f}m → 地板 (地板Y≈{floor_y:.3f})")
    elif args.floor_y is not None:
        # 无平面文件, 简单Y轴投影
        floor_y = args.floor_y
        trajectory_on_floor = trajectory.copy()
        trajectory_on_floor[:, 1] = floor_y
        plane_normal = None
        print(f"\n未找到轨迹平面, 使用简单Y轴投影: {floor_y:.3f}")
    else:
        # Y最小值
        floor_y = float(trajectory[:, 1].min())
        trajectory_on_floor = trajectory.copy()
        trajectory_on_floor[:, 1] = floor_y
        plane_normal = None
        print(f"\n未找到轨迹平面, 使用Y最小值: {floor_y:.3f}")

    # 地板投影示例和点云导出
    print(f"\n地板投影结果:")
    print(f"  示例: {trajectory[0]} → {trajectory_on_floor[0]}")
    max_dev = np.max(np.abs(trajectory - trajectory_on_floor))
    print(f"  最大偏移: {max_dev:.4f}m")

    # ===== 导出地板投影轨迹为点云 =====
    ply_file = Path(str(images_dir) + '_trajectory_floor.ply')
    colors = np.tile([0, 255, 0], (len(trajectory_on_floor), 1))
    write_ply(ply_file, trajectory_on_floor, colors)
    print(f"\n导出地板投影轨迹点云: {ply_file}")
    print(f"  点数: {len(trajectory_on_floor)}")

    # ===== 位姿 =====
    all_poses = load_poses(poses_file)
    print(f"加载 {len(all_poses)} 帧位姿")

    # ===== 输出 =====
    output_dir = args.output
    if output_dir is None:
        output_dir = Path(str(images_dir) + '_projected')
    else:
        output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    use_floor_mask = not args.no_floor_mask
    print(f"\n开始重投影...")
    print(f"  最大距离: {args.max_distance}m")
    print(f"  模式: {'所有轨迹点' if args.draw_all else '仅该帧之后的轨迹点'}")
    print(f"  点半径: {args.point_radius}")
    print(f"  Floor Mask: {'启用' if use_floor_mask else '禁用'}")
    print(f"  Trajectory API: {'启用' if args.draw_trajectory else '禁用'}")

    if args.draw_trajectory:
        try:
            health = requests.get(f"{args.trajectory_api_url}/health", timeout=5).json()
            print(f"  API 状态: {health.get('status', 'unknown')}")
        except Exception as e:
            print(f"  ⚠ API 健康检查失败: {e}, 将跳过轨迹绘制")
            args.draw_trajectory = False

    processed = 0
    skipped = 0
    mask_fail_count = 0
    total_pts_before = 0
    total_pts_after = 0
    traj_success = 0
    traj_failed = 0

    for img_file in img_files:
        filename = img_file.name
        timestamp = img_file.stem

        # 优先使用 manifest 中的信息
        manifest_entry = frame_index_map.get(filename)

        if manifest_entry is not None:
            # 有 manifest: 直接用映射的位姿和轨迹索引
            traj_idx = manifest_entry['traj_index']
            orig_timestamp = manifest_entry['original_timestamp']
            if orig_timestamp not in all_poses:
                print(f"  跳过: {filename} (原始时间戳 {orig_timestamp} 无对应位姿)")
                skipped += 1
                continue
            T_c2w = all_poses[orig_timestamp]
        else:
            # 无 manifest: 回退到旧逻辑
            if timestamp not in all_poses:
                print(f"  跳过: {filename} (无对应位姿)")
                skipped += 1
                continue
            T_c2w = all_poses[timestamp]

            traj_idx = None
            min_dist_overall = float('inf')
            for i, pt in enumerate(trajectory):
                dist = np.linalg.norm(T_c2w[:3, 3] - pt)
                if dist < min_dist_overall:
                    min_dist_overall = dist
                    traj_idx = i

        if args.draw_all:
            pts_to_project = trajectory_on_floor
        else:
            if traj_idx is not None:
                pts_to_project = trajectory_on_floor[traj_idx:]
            else:
                pts_to_project = trajectory_on_floor

        image = cv2.imread(str(img_file))
        if image is None:
            print(f"  跳过: {img_file.name} (读取失败)")
            skipped += 1
            continue

        # 投影
        uv, depths = project_points_to_image(
            pts_to_project, T_c2w, K,
            max_distance=args.max_distance
        )

        # Floor mask 筛选 + 只保留最后一个点
        floor_mask = None
        floor_box = None
        if use_floor_mask and len(uv) > 0:
            floor_mask, floor_box = get_floor_mask(img_file, args.sam2_url, args.dino_url)
            if floor_mask is not None:
                keep = filter_points_by_mask(uv, floor_mask)
                num_before = len(uv)
                total_pts_before += num_before

                if np.any(keep):
                    last_keep_idx = np.where(keep)[0][-1]
                    uv = uv[last_keep_idx:last_keep_idx+1]
                    depths = depths[last_keep_idx:last_keep_idx+1]
                    total_pts_after += 1
                else:
                    uv = uv[0:1]
                    depths = depths[0:1]
            else:
                mask_fail_count += 1

        result = draw_floor_mask(image, floor_mask, alpha=0.25)

        # 生成轨迹
        api_result = None
        if args.draw_trajectory and len(uv) > 0:
            target_x, target_y = int(uv[0, 0]), int(uv[0, 1])
            api_result = call_trajectory_pixel_api(str(img_file), target_x, target_y, args.trajectory_api_url)
            if api_result.get("success"):
                traj_success += 1
                print(f"  [{processed+1}/{len(img_files)}] {filename}: 轨迹 {api_result.get('num_points', 0)} 点")
            else:
                traj_failed += 1

        result = draw_projection(result, uv, depths,
                                 max_distance=args.max_distance,
                                 point_radius=args.point_radius)

        if api_result is not None:
            result = draw_trajectory_on_image(result, api_result, uv[0] if len(uv) > 0 else None)

        info_lines = [
            f'Frame: {filename}',
            f'Projected: {len(uv)}/{len(pts_to_project)} points',
            f'Distance: {args.max_distance}m',
            f'Floor-Y: {floor_y:.2f}',
        ]
        if manifest_entry is not None:
            info_lines.append(f'Seq: {manifest_entry["sequence_index"]}, Traj idx: {traj_idx}/{len(trajectory)}')
        elif traj_idx is not None:
            info_lines.append(f'Traj idx: {traj_idx}/{len(trajectory)}')
        if floor_box is not None:
            x1, y1, x2, y2 = [int(v) for v in floor_box]
            info_lines.append(f'Floor box: [{x1},{y1},{x2},{y2}]')
        if api_result is not None:
            if api_result.get("success"):
                info_lines.append(f'Trajectory: {api_result.get("num_points", 0)} pts, {api_result.get("processing_time_seconds", 0):.1f}s')
            else:
                info_lines.append(f'Trajectory FAIL: {api_result.get("message", "unknown")[:40]}')

        y_offset = 25
        for line in info_lines:
            cv2.putText(result, line, (10, y_offset),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
            y_offset += 20

        output_file = output_dir / img_file.name
        cv2.imwrite(str(output_file), result)
        processed += 1

        if processed <= 3 or processed == len(img_files):
            print(f"  [{processed}/{len(img_files)}] {img_file.name} → {len(uv)} 点投影")

    print(f"\n完成!")
    print(f"  处理: {processed} 张")
    if skipped > 0:
        print(f"  跳过: {skipped} 张")
    if use_floor_mask:
        if total_pts_before > 0:
            ratio = (total_pts_after / total_pts_before) * 100
            print(f"  Floor mask 筛选: {total_pts_before} → {total_pts_after} 点 ({ratio:.1f}%)")
        if mask_fail_count > 0:
            print(f"  Mask 获取失败: {mask_fail_count} 张")
    if args.draw_trajectory:
        print(f"  Trajectory API: 成功 {traj_success} 张, 失败 {traj_failed} 张")
    print(f"  输出: {output_dir}")
    print(f"  点云: {ply_file}")


if __name__ == '__main__':
    main()
