#!/usr/bin/env python3

import numpy as np
import json
import pickle
import heapq
from pathlib import Path
from typing import List, Dict, Tuple, Optional

from .grid_map import GridMap, create_grid_map_from_pointcloud
from .path_planner import AStarPlanner, rdp_simplify
from .cost_map import CostMap
from .gateway_detector import GatewayDetector, Gateway
from .config_loader import load_config


def _detect_vertical_axis(global_pcd_path):
    """
    检测点云的垂直轴。
    优先从 trajectory_plane.json 法向量判断，
    回退到 config.yaml 的 trajectory_alignment.enabled。
    返回 'y' 或 'z'。
    """
    base_dir = Path(global_pcd_path).parent.parent
    plane_path = base_dir / 'trajectory_plane.json'
    if plane_path.exists():
        with open(plane_path, 'r') as f:
            plane = json.load(f)
        normal = np.array(plane['normal'])
        if abs(normal[2]) > abs(normal[1]):
            print(f"  检测到 Z-up 坐标系 (轨迹平面法向量: {normal})")
            return 'z'
        else:
            print(f"  检测到 Y-up 坐标系 (轨迹平面法向量: {normal})")
            return 'y'

    config_path = base_dir / 'config.yaml'
    if config_path.exists():
        import yaml
        with open(config_path, 'r') as f:
            cfg = yaml.safe_load(f)
        ta = cfg.get('trajectory_alignment', {})
        if ta.get('enabled', False):
            print("  从 config.yaml: trajectory_alignment.enabled=true → Z-up")
            return 'z'

    print("  默认 Y-up 坐标系")
    return 'y'


def resample_path(path_3d, step_size=0.01):
    """
    重采样 (真实 3D 欧氏距离)

    参数:
        path_3d: (N, 3) 原始路径点
        step_size: 采样步长 (米), 默认 0.01m (1cm)

    返回:
        resampled: (M, 3) 重采样后的路径点
    """
    if len(path_3d) < 2:
        return path_3d

    path_3d = np.array(path_3d)

    # 累计距离
    distances = np.zeros(len(path_3d))
    for i in range(1, len(path_3d)):
        distances[i] = distances[i - 1] + np.linalg.norm(path_3d[i] - path_3d[i - 1])

    total_length = distances[-1]

    if total_length < 1e-8:
        return path_3d

    # 等距采样距离
    num_samples = int(np.ceil(total_length / step_size)) + 1
    sample_distances = np.linspace(0, total_length, num_samples)

    # 插值采样
    resampled = np.zeros((num_samples, 3))
    for i, sd in enumerate(sample_distances):
        idx = np.searchsorted(distances, sd, side='right') - 1
        idx = min(max(idx, 0), len(path_3d) - 2)

        seg_start_dist = distances[idx]
        seg_end_dist = distances[idx + 1]
        seg_length = seg_end_dist - seg_start_dist

        if seg_length > 1e-8:
            t = (sd - seg_start_dist) / seg_length
        else:
            t = 0.0

        resampled[i] = path_3d[idx] + t * (path_3d[idx + 1] - path_3d[idx])

    return resampled.tolist()


class FloorNavigator:
    def __init__(self, global_pcd_path, resolution=0.05, grid_map_path=None,
                 scene_graph_path=None, floor_y_threshold=None,
                 use_cost_map=True, cost_sigma=None, cost_weight=None,
                 complete_boundary_wall=None, config=None):
        self.global_pcd_path = Path(global_pcd_path)
        self.resolution = resolution
        self.use_cost_map = use_cost_map
        self._config = config or load_config()
        self._nav_cfg = self._config.get('navigator', {})
        self._pp_cfg = self._config.get('path_planner', {})
        self._gm_cfg = self._config.get('grid_map', {})

        if floor_y_threshold is None:
            floor_y_threshold = self._nav_cfg.get('floor_y_threshold', 0.6)
        self.floor_y_threshold = floor_y_threshold

        if cost_sigma is None:
            # 优先从 cost_map 部分读取，其次从 navigator 部分读取
            cost_sigma = self._config.get('cost_map', {}).get('sigma',
                       self._nav_cfg.get('cost_sigma', 0.5))
        if cost_weight is None:
            # 优先从 cost_map 部分读取，其次从 navigator 部分读取
            cost_weight = self._config.get('cost_map', {}).get('distance_weight',
                        self._nav_cfg.get('cost_weight', 5.0))
        if complete_boundary_wall is None:
            complete_boundary_wall = self._nav_cfg.get('complete_boundary_wall', True)

        print("\n检测坐标系...")
        # 优先从 config.yaml 读取 up_axis
        config_up_axis = self._config.get('up_axis', None)
        if config_up_axis:
            self.up_axis = config_up_axis
            print(f"  从 config.yaml: up_axis={self.up_axis}")
        else:
            self.up_axis = _detect_vertical_axis(str(self.global_pcd_path))

        plane_info_path = self.global_pcd_path.parent.parent / 'trajectory_plane.json'
        self.trajectory_plane = None
        if Path(plane_info_path).exists():
            with open(plane_info_path, 'r') as f:
                plane_data = json.load(f)
            self.trajectory_plane = {
                'normal': np.array(plane_data['normal']),
                'd': plane_data['d'],
                'centroid': np.array(plane_data['centroid']),
                'inlier_ratio': plane_data.get('inlier_ratio', 0),
                'mean_distance': plane_data.get('mean_distance', 0),
            }
            print(f"  轨迹平面: {plane_info_path}")
            print(f"  法向量: {self.trajectory_plane['normal']}")
            print(f"  内点比例: {self.trajectory_plane['inlier_ratio']:.1f}%")

        import open3d as o3d
        pcd = o3d.io.read_point_cloud(str(self.global_pcd_path))
        self._points = np.asarray(pcd.points)
        print(f"  点云: {len(self._points):,} 个点 (up_axis={self.up_axis})")

        # 栅格地图
        if grid_map_path and Path(grid_map_path).exists():
            print(f"\n加载栅格地图: {grid_map_path}")
            with open(grid_map_path, 'rb') as f:
                grid_data = pickle.load(f)
            self.grid_map = self._reconstruct_gridmap(grid_data)
            self.floor_y = grid_data['floor_y']
        else:
            print("\n从点云生成栅格地图...")
            sg_path = scene_graph_path or str(self.global_pcd_path.parent.parent / 'scene_graph.json')
            self.grid_map, self.floor_y = create_grid_map_from_pointcloud(
                str(self.global_pcd_path), sg_path,
                resolution, self.floor_y_threshold,
                points=self._points, up_axis=self.up_axis
            )

            if grid_map_path:
                save_path = Path(grid_map_path)
            else:
                save_path = self.global_pcd_path.parent.parent / 'navigation' / 'grid_map_floor.pkl'
            save_path.parent.mkdir(parents=True, exist_ok=True)
            with open(save_path, 'wb') as f:
                pickle.dump({
                    'grid': self.grid_map.get_grid(),
                    'x_min': self.grid_map.x_min,
                    'h_min': self.grid_map.h_min,
                    'resolution': self.grid_map.resolution,
                    'padding': self.grid_map.padding,
                    'floor_y': self.floor_y,
                    'width': self.grid_map.width,
                    'height': self.grid_map.height,
                    'connected_components': self.grid_map.connected_components,
                    'component_gateways': self.grid_map.component_gateways,
                    'doors': self.grid_map.doors,
                    'up_axis': self.up_axis,
                }, f)
            print(f"  栅格数据已保存: {save_path}")

        # Cost Map
        self.cost_map = None
        if self.use_cost_map:
            nav_dir = self.global_pcd_path.parent.parent / 'navigation'
            cost_map_cache = nav_dir / f'cost_map_s{cost_sigma:.1f}_w{cost_weight:.1f}.pkl'

            if Path(cost_map_cache).exists():
                print(f"\n加载 Cost Map 缓存: {cost_map_cache}")
                import time as _time
                _t0 = _time.time()
                with open(cost_map_cache, 'rb') as f:
                    cm_data = pickle.load(f)
                self.cost_map = CostMap.__new__(CostMap)
                self.cost_map.grid = cm_data['grid']
                self.cost_map.resolution = cm_data['resolution']
                self.cost_map.x_min = cm_data['x_min']
                self.cost_map.h_min = cm_data.get('h_min', cm_data.get('z_min', 0))
                self.cost_map.sigma = cm_data['sigma']
                self.cost_map.distance_weight = cm_data['distance_weight']
                self.cost_map.base_cost = cm_data['base_cost']
                self.cost_map.height = cm_data['height']
                self.cost_map.width = cm_data['width']
                self.cost_map.cost_map = cm_data['cost_map']
                self.cost_map.distance_map = cm_data['distance_map']
                _elapsed = _time.time() - _t0
                print(f"  Cost Map 缓存加载: {_elapsed:.3f}s (σ={cost_sigma}m, w={cost_weight})")
            else:
                print(f"\n创建 Cost Map...")
                import time as _time
                _t0 = _time.time()
                # 从 config.yaml 读取 base_cost
                base_cost = self._config.get('cost_map', {}).get('base_cost', 1.0)
                print(f"  Navigator: base_cost={base_cost} (from config)")
                self.cost_map = CostMap(
                    grid=self.grid_map.get_grid(),
                    resolution=self.grid_map.resolution,
                    x_min=self.grid_map.x_min,
                    h_min=self.grid_map.h_min,
                    sigma=cost_sigma,
                    distance_weight=cost_weight,
                    base_cost=base_cost,
                    complete_boundary_wall=complete_boundary_wall
                )
                _elapsed = _time.time() - _t0
                # 保存到缓存
                nav_dir.mkdir(parents=True, exist_ok=True)
                with open(cost_map_cache, 'wb') as f:
                    pickle.dump({
                        'grid': self.cost_map.grid,
                        'resolution': self.cost_map.resolution,
                        'x_min': self.cost_map.x_min,
                        'h_min': self.cost_map.h_min,
                        'sigma': self.cost_map.sigma,
                        'distance_weight': self.cost_map.distance_weight,
                        'base_cost': self.cost_map.base_cost,
                        'height': self.cost_map.height,
                        'width': self.cost_map.width,
                        'cost_map': self.cost_map.cost_map,
                        'distance_map': self.cost_map.distance_map,
                    }, f)
                print(f"  Cost Map 已缓存: {cost_map_cache} ({_elapsed:.3f}s)")

        # A* 规划
        self.planner = AStarPlanner(self.grid_map, cost_map=self.cost_map)

        # scene graph
        sg_path = scene_graph_path or str(self.global_pcd_path.parent.parent / 'scene_graph.json')
        if Path(sg_path).exists():
            with open(sg_path, 'r') as f:
                self.scene_graph = json.load(f)
            self.objects = self.scene_graph.get('objects', [])
            self.rooms_data = self.scene_graph.get('rooms', [])
        else:
            self.scene_graph = None
            self.objects = []
            self.rooms_data = []

        # Gateway
        self.gateways: List[Gateway] = []
        self.room_adjacency: Dict[Tuple[int, int], List] = {}

        gateway_json_path = self.global_pcd_path.parent.parent / 'navigation' / 'gateways' / 'gateways.json'
        if not Path(gateway_json_path).exists():
            gateway_json_path = self.global_pcd_path.parent.parent / 'navigation' / 'trajectory_gateways' / 'gateways.json'
        if Path(gateway_json_path).exists():
            self.load_gateways_from_json(str(gateway_json_path))

    def _reconstruct_gridmap(self, grid_data):
        up_axis = grid_data.get('up_axis', 'y')
        h_min = grid_data.get('h_min', grid_data.get('z_min', 0))
        resolution = grid_data['resolution']
        width = grid_data['width']
        height = grid_data['height']
        x_min = grid_data['x_min']
        x_max = x_min + width * resolution
        h_max = h_min + height * resolution
        dummy_pts = np.array([[x_min, h_min],
                              [x_max, h_max]])
        grid_map = GridMap(dummy_pts, np.array([]), resolution=resolution, up_axis=up_axis)
        grid_map.grid = grid_data['grid']
        grid_map.x_min = x_min
        grid_map.x_max = x_max
        grid_map.h_min = h_min
        grid_map.h_max = h_max
        grid_map.width = width
        grid_map.height = height
        grid_map.padding = grid_data['padding']
        grid_map.connected_components = grid_data.get('connected_components', {})
        grid_map.component_gateways = grid_data.get('component_gateways', [])
        grid_map.doors = grid_data.get('doors', [])
        grid_map.component_labels = None
        return grid_map

    def load_gateways_from_json(self, gateway_json_path: str):
        """
        gateway 加载

        Args:
            gateway_json_path: gateway JSON 文件路径
        """
        import json
        from pathlib import Path

        json_path = Path(gateway_json_path)
        if not json_path.exists():
            print(f"  Gateway 文件不存在: {gateway_json_path}")
            return

        with open(json_path, 'r') as f:
            gw_data = json.load(f)

        gateways_list = gw_data.get('gateways', [])
        self.gateways = []
        self.room_adjacency = {}

        for gw_dict in gateways_list:
            gw = Gateway(
                id=gw_dict['id'],
                room_a=gw_dict['room_a'],
                room_b=gw_dict['room_b'],
                position=np.array(gw_dict['position']),
                position_3d=np.array(gw_dict['position_3d']),
                grid_cell=(0, 0),  # 从 JSON 加载时不需要栅格位置
                width=gw_dict.get('width', 1.0),
                confidence=gw_dict.get('confidence', 0.5)
            )
            self.gateways.append(gw)
            self.room_adjacency[(gw.room_a, gw.room_b)] = gw

        print(f"\n加载 Gateway: {len(self.gateways)} 个 (来自 {gateway_json_path})")

    def detect_gateways(self, rooms: List[Dict]):
        """
        gateway 检测

        Args:
            rooms: 房间列表,每个 room 包含 'id', 'points', 'center'
        """
        print("\n" + "=" * 60)
        print("Gateway 检测 (基于房间相邻性)")
        print("=" * 60)

        # floor 点云提取
        floor_points = self._extract_floor_points()

        detector = GatewayDetector(floor_points, resolution=self.resolution)
        self.gateways = detector.detect_gateways(rooms, floor_grid=self.grid_map.get_grid())

        # 房间邻接图
        for gw in self.gateways:
            self.room_adjacency[(gw.room_a, gw.room_b)] = gw

        print(f"\nGateway 检测完成: {len(self.gateways)} 个 gateway")
        return self.gateways

    def detect_gateways_from_trajectory(self, trajectory: np.ndarray,
                                         rooms: List[Dict],
                                         merge_distance: float = 1.0):
        """
        从机器人实际行走轨迹提取 gateway

        Args:
            trajectory: (N, 3) 轨迹点云 (x, y, z)
            rooms: 房间列表 (含 'id', 'center')
            merge_distance: 同一房间对 gateway 合并距离阈值 (m)
        """
        print("\n" + "=" * 60)
        print("Gateway 检测 (基于实际行走轨迹)")
        print("=" * 60)

        floor_points = self._extract_floor_points()

        detector = GatewayDetector(floor_points, resolution=self.resolution)
        self.gateways = detector.detect_gateways_from_trajectory(
            trajectory, rooms,
            floor_grid=self.grid_map.get_grid(),
            merge_distance=merge_distance
        )

        # 构建房间邻接图
        for gw in self.gateways:
            self.room_adjacency[(gw.room_a, gw.room_b)] = gw

        print(f"\nGateway 检测完成: {len(self.gateways)} 个 gateway")
        return self.gateways

    def _extract_floor_points(self) -> np.ndarray:
        """从全局点云提取 floor (保持原始坐标系)"""
        points = self._points

        if self.up_axis == 'z':
            # Z-up: Z 是高度, 按 Y 分带
            h_min_all = points[:, 1].min()
            h_max_all = points[:, 1].max()
            height_idx = 2  # Z
            h_idx = 1       # Y
        else:
            # Y-up: Y 是高度, 按 Z 分带
            h_min_all = points[:, 2].min()
            h_max_all = points[:, 2].max()
            height_idx = 1  # Y
            h_idx = 2       # Z

        floor_3d_list = []
        band_size = self._gm_cfg.get('band_size', 0.3)
        h_bands = np.arange(h_min_all - band_size, h_max_all + band_size, band_size)

        for i in range(len(h_bands) - 1):
            h_low = h_bands[i]
            h_high = h_bands[i + 1]

            band_mask = (points[:, h_idx] >= h_low) & (points[:, h_idx] < h_high)
            band_pts = points[band_mask]

            if len(band_pts) < 100:
                continue

            height_10 = np.percentile(band_pts[:, height_idx], 10)
            floor_offset = self._nav_cfg.get('floor_percentile_offset', 1.0)
            floor_threshold = height_10 + floor_offset

            floor_mask = band_pts[:, height_idx] < floor_threshold
            floor_pts = band_pts[floor_mask]
            if len(floor_pts) > 0:
                floor_3d_list.append(floor_pts)

        if not floor_3d_list:
            return points

        return np.vstack(floor_3d_list)

    def find_object_location(self, target_query):
        """查找目标物体位置"""
        try:
            coords = [float(x) for x in target_query.split(',')]
            if len(coords) == 3:
                return coords
        except:
            pass

        for obj in self.objects:
            if obj.get('name', '').lower() == target_query.lower() or \
               obj.get('category', '').lower() == target_query.lower():
                center = obj['center']
                return [center[0], center[1], center[2]]

        for obj in self.objects:
            if target_query.lower() in obj.get('name', '').lower() or \
               target_query.lower() in obj.get('category', '').lower():
                center = obj['center']
                print(f"  模糊匹配: {obj['name']} ({obj['category']})")
                return [center[0], center[1], center[2]]

        print(f"  错误: 找不到 '{target_query}'")
        return None

    def find_room_for_position(self, position, rooms: List[Dict]) -> Optional[int]:
        """房间匹配"""
        from scipy.spatial import cKDTree

        # 根据 up_axis 选择水平面坐标
        if self.up_axis == 'z':
            pos_2d = [position[0], position[1]]  # X-Y
            room_centers = np.array([[r['center'][0], r['center'][1]] for r in rooms])
        else:
            pos_2d = [position[0], position[2]]  # X-Z
            room_centers = np.array([[r['center'][0], r['center'][2]] for r in rooms])

        tree = cKDTree(room_centers)
        _, idx = tree.query(pos_2d)

        return rooms[idx]['id']

    def plan_high_level_path(self, start_position, goal_position, rooms: List[Dict]):
        """
        高层路径: 基于房间邻接图的 BFS/Dijkstra
        
        1. 确定起点和终点所在的房间
        2. 在房间邻接图上找最短房间序列
        3. 提取房间序列之间的 gateway 作为路径点
        """
        if not self.gateways:
            print("  警告: 没有 gateway,使用直接路径")
            return [start_position, goal_position], []

        # 找房间
        start_room = self.find_room_for_position(start_position, rooms)
        goal_room = self.find_room_for_position(goal_position, rooms)

        if start_room is None or goal_room is None:
            print("  警告: 无法确定房间,使用直接路径")
            return [start_position, goal_position], []

        print(f"  起点房间: {start_room}, 目标房间: {goal_room}")

        if start_room == goal_room:
            # 同一房间,直接走
            return [start_position, goal_position], []

        # 房间邻接图
        room_graph = {}
        for gw in self.gateways:
            if gw.room_a not in room_graph:
                room_graph[gw.room_a] = []
            if gw.room_b not in room_graph:
                room_graph[gw.room_b] = []
            
            room_graph[gw.room_a].append((gw.room_b, gw))
            room_graph[gw.room_b].append((gw.room_a, gw))

        # BFS/Dijkstra 找最短房间序列
        dist = {start_room: 0}
        prev = {start_room: None}
        prev_gw = {start_room: None}
        pq = [(0, start_room)]
        visited = set()

        while pq:
            d, current = heapq.heappop(pq)

            if current == goal_room:
                # 重建房间路径
                room_path = []
                gw_path = []
                node = goal_room
                while node is not None:
                    room_path.append(node)
                    if prev_gw[node] is not None:
                        gw_path.append(prev_gw[node])
                    node = prev[node]
                room_path.reverse()
                gw_path.reverse()

                # 转为 3D 路径
                path_3d = [start_position]
                for gw in gw_path:
                    path_3d.append([gw.position_3d[0], gw.position_3d[1], gw.position_3d[2]])
                path_3d.append(goal_position)

                gw_names = [f"GW{gw.id}(R{gw.room_a}↔R{gw.room_b})" for gw in gw_path]
                return path_3d, gw_names

            if current in visited:
                continue
            visited.add(current)

            for neighbor, gw in room_graph.get(current, []):
                if neighbor in visited:
                    continue
                new_dist = d + 1  # 每跳权重为 1
                if new_dist < dist.get(neighbor, float('inf')):
                    dist[neighbor] = new_dist
                    prev[neighbor] = current
                    prev_gw[neighbor] = gw
                    heapq.heappush(pq, (new_dist, neighbor))

        print(f"  错误: 无法找到从房间 {start_room} 到 {goal_room} 的路径")
        return None, None

    def plan_low_level_path(self, start_world, goal_world):
        """微观路径: A* 在 floor grid 上,使用 cost map"""
        if self.up_axis == 'z':
            # Z-up: 水平面是 X-Y
            start_2d = [start_world[0], start_world[1]]
            goal_2d = [goal_world[0], goal_world[1]]
        else:
            # Y-up: 水平面是 X-Z
            start_2d = [start_world[0], start_world[2]]
            goal_2d = [goal_world[0], goal_world[2]]
        path_2d = self.planner.plan(start_2d, goal_2d)
        if path_2d is None:
            return None

        # 平滑
        path_2d = self.planner.smooth_path(path_2d)

        if len(path_2d) > 10:
            rdp_epsilon = self._pp_cfg.get('rdp_epsilon', 0.1)
            path_2d = rdp_simplify(np.array(path_2d), epsilon=rdp_epsilon)

        # 转 3D
        path_3d = []
        for pt_2d in path_2d:
            x = pt_2d[0]
            h = pt_2d[1]
            # 高度轴计算
            if self.trajectory_plane is not None:
                if self.up_axis == 'z':
                    pt = np.array([x, h, self.floor_y])  # [x, y, z]
                    height_idx = 2  # Z
                else:
                    pt = np.array([x, self.floor_y, h])  # [x, y, z]
                    height_idx = 1  # Y

                # 沿法向量投影到平面
                normal = self.trajectory_plane['normal']
                d = self.trajectory_plane['d']

                dist_to_plane = np.dot(normal, pt) + d
                pt_proj = pt - dist_to_plane * normal

                height = pt_proj[height_idx]

                # 根据离障碍物距离微调
                if self.cost_map:
                    row, col = self.grid_map._world_to_grid(x, h)
                    dist_to_obs = self.cost_map.get_distance(row, col)
                    height_factor = self._nav_cfg.get('height_adjust_factor', 0.1)
                    height_max = self._nav_cfg.get('height_adjust_max', 0.3)
                    height += min(dist_to_obs * height_factor, height_max)
            else:
                # 无平面信息，使用固定 floor_y
                if self.cost_map:
                    row, col = self.grid_map._world_to_grid(x, h)
                    dist_to_obs = self.cost_map.get_distance(row, col)
                    height_factor = self._nav_cfg.get('height_adjust_factor', 0.1)
                    height_max = self._nav_cfg.get('height_adjust_max', 0.3)
                    height = self.floor_y + min(dist_to_obs * height_factor, height_max)
                else:
                    height = self.floor_y

            if self.up_axis == 'z':
                path_3d.append([x, h, height])
            else:
                path_3d.append([x, height, h])

        return path_3d

    def plan(self, start_position, target_query, rooms: List[Dict] = None):
        """
        两层路径规划
        
        Args:
            start_position: 起点 [x, y, z]
            target_query: 目标物体名称或坐标
            rooms: 房间列表 (用于 gateway 检测)
        """
        print("\n" + "=" * 60)
        print("基于房间分割和 Cost Map 的路径规划")
        print("=" * 60)

        # Step 0: gateway 检测
        use_gateway = self._nav_cfg.get('use_gateway', True)
        if use_gateway:
            if not self.gateways and rooms:
                self.detect_gateways(rooms)
            elif not self.gateways:
                print("  警告：没有房间数据，使用直接路径")
        else:
            print("  配置：use_gateway=false，跳过 gateway 规划")

        # Step 1: 查找目标
        print(f"\n[1] 查找目标: {target_query}")
        goal_position = self.find_object_location(target_query)
        if goal_position is None:
            return {'success': False, 'error': '找不到目标物体'}
        print(f"  目标位置: {goal_position}")

        # Step 2: 高层路径
        if use_gateway and self.gateways and rooms:
            print(f"\n[2] 高层路径规划 (通过 gateway)...")
            high_level_path, gw_sequence = self.plan_high_level_path(
                start_position, goal_position, rooms
            )
        else:
            print(f"\n[2] 直接路径规划 (起点 → 终点)...")
            high_level_path = [start_position, goal_position]
            gw_sequence = []

        if high_level_path is None:
            print("  尝试直接规划...")
            high_level_path = [start_position, goal_position]
            gw_sequence = []

        waypoints_3d = high_level_path
        print(f"  路径点数: {len(waypoints_3d)}")
        if gw_sequence:
            print(f"  通过 gateway: {', '.join(gw_sequence)}")

        # Step 3: 微观路径 (逐段 A*)
        print(f"\n[3] 微观路径规划...")
        full_path_3d = []

        for i in range(len(waypoints_3d) - 1):
            seg_start = waypoints_3d[i]
            seg_goal = waypoints_3d[i + 1]
            if self.up_axis == 'z':
                s2 = (seg_start[0], seg_start[1])
                g2 = (seg_goal[0], seg_goal[1])
            else:
                s2 = (seg_start[0], seg_start[2])
                g2 = (seg_goal[0], seg_goal[2])
            print(f"  段 {i+1}/{len(waypoints_3d)-1}: "
                  f"({s2[0]:.2f}, {s2[1]:.2f}) → "
                  f"({g2[0]:.2f}, {g2[1]:.2f})")

            seg_path = self.plan_low_level_path(seg_start, seg_goal)
            if seg_path is None:
                print(f"    警告: 段 {i+1} 无路径，使用直线")
                full_path_3d.append(seg_start)
                full_path_3d.append(seg_goal)
            else:
                if i > 0 and len(full_path_3d) > 0:
                    seg_path = seg_path[1:]  # 避免重复
                full_path_3d.extend(seg_path)

        total_distance = 0
        for i in range(len(full_path_3d) - 1):
            total_distance += np.linalg.norm(
                np.array(full_path_3d[i]) - np.array(full_path_3d[i+1])
            )

        print(f"\n[4] 路径统计:")
        print(f"  原始路径点数: {len(full_path_3d)}")
        print(f"  总距离: {total_distance:.2f}m")

        # 路径重采样
        print(f"\n[5] 路径重采样...")
        resample_step = self._nav_cfg.get('resample_step_size', 0.01)
        full_path_3d_resampled = resample_path(full_path_3d, step_size=resample_step)
        print(f"  重采样后点数: {len(full_path_3d_resampled)}")

        total_distance_resampled = 0
        for i in range(len(full_path_3d_resampled) - 1):
            total_distance_resampled += np.linalg.norm(
                np.array(full_path_3d_resampled[i]) - np.array(full_path_3d_resampled[i+1])
            )

        return {
            'success': True,
            'start_position': start_position,
            'goal_position': goal_position,
            'high_level_path': waypoints_3d,
            'gateway_sequence': gw_sequence,
            'low_level_path': full_path_3d,
            'low_level_path_resampled': full_path_3d_resampled,
            'waypoints': waypoints_3d,
            'total_distance': total_distance_resampled,
            'num_path_points': len(full_path_3d),
            'num_path_points_resampled': len(full_path_3d_resampled),
        }
