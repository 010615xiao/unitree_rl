#!/usr/bin/env python3
"""
Navigation config loader.

Loads parameters from navigation/config.yaml and provides
section-based access with fallback defaults.
"""

from pathlib import Path
from typing import Any, Dict, Optional

import yaml

_CONFIG_CACHE: Optional[Dict[str, Any]] = None
_CONFIG_PATH: Optional[Path] = None


def _default_config() -> Dict[str, Any]:
    """Return the default config (mirrors config.yaml)."""
    return {
        "grid_map": {
            "resolution": 0.05,
            "padding": 10,
            "morph_kernel_size": 5,
            "morph_iterations": 2,
            "gap_filling_distance_threshold": 20,
            "band_size": 5.0,
            "floor_dilation_kernel": 3,
            "floor_dilation_iterations": 3,
            "obstacle": {
                "footprint_resolution": 0.2,
                "subsample_zup": 50,
                "subsample_yup": 100,
                "z_span_threshold_zup": 0.05,
                "z_span_threshold_yup": 0.5,
                "isolation_radius": 1.0,
            },
        },
        "cost_map": {
            "sigma": 0.5,
            "distance_weight": 5.0,
            "base_cost": 1.0,
            "complete_boundary_wall": True,
            "boundary_wall_margin": 2,
            "boundary_dilation_iterations": 2,
            "boundary_fallback_dilation_iterations": 5,
            "unknown_cost_threshold": 50.0,
            "obstacle_cost": 1000.0,
        },
        "gateway_detector": {
            "resolution": 0.05,
            "boundary_expansion": 0.5,
            "min_boundary_cells": 3,
            "floor_y_threshold": 1.0,
            "band_size": 5.0,
            "floor_percentile_offset": 1.0,
            "merge_distance": 1.0,
            "confidence_denominator": 10.0,
        },
        "path_planner": {
            "max_dist_nearest_walkable": 100,
            "smoothing_alpha": 0.3,
            "smoothing_beta": 0.3,
            "smoothing_max_iterations": 100,
            "smoothing_safety_margin": 2.0,
            "rdp_epsilon": 0.1,
        },
        "navigator": {
            "resample_step_size": 0.01,
            "floor_y_threshold": 0.6,
            "cost_sigma": 0.5,
            "cost_weight": 5.0,
            "complete_boundary_wall": True,
            "band_size": 5.0,
            "floor_percentile_offset": 1.0,
            "height_adjust_factor": 0.1,
            "height_adjust_max": 0.3,
        },
        "visualize": {
            "scale_bar": 5.0,
            "floor_y_threshold": 0.6,
            "band_size": 5.0,
            "obstacle_resolution": 0.2,
            "obstacle_subsample": 50,
            "obstacle_z_span_threshold_zup": 0.05,
            "obstacle_z_span_threshold_yup": 0.05,
            "component_min_cells": 100,
            "component_dilation_iterations": 2,
        },
    }


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Load navigation config from YAML file.

    Falls back to built-in defaults if the file is missing.
    Results are cached so repeated calls are cheap.

    Args:
        config_path: Explicit path to config.yaml. If None, auto-detects
                     relative to this file's location.

    Returns:
        Nested dict with all config sections.
    """
    global _CONFIG_CACHE, _CONFIG_PATH

    if config_path is not None:
        path = Path(config_path)
    else:
        path = Path(__file__).parent / "config.yaml"

    # Return cached config if the same path was already loaded
    if _CONFIG_CACHE is not None and _CONFIG_PATH == path:
        return _CONFIG_CACHE

    defaults = _default_config()

    if path.exists():
        with open(path, "r") as f:
            loaded = yaml.safe_load(f) or {}
        # Merge loaded values over defaults (shallow per top-level section)
        for section, values in loaded.items():
            if section in defaults and isinstance(values, dict):
                defaults[section].update(values)
            else:
                defaults[section] = values
    else:
        print(f"  [config] Config file not found: {path}, using defaults")

    _CONFIG_CACHE = defaults
    _CONFIG_PATH = path
    return defaults


def get_section(section: str, config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Get a config section by name.

    Args:
        section: Section name (e.g. 'grid_map', 'cost_map').
        config: Pre-loaded config dict. If None, loads automatically.

    Returns:
        Dict of parameters for the requested section.
    """
    if config is None:
        config = load_config()
    return config.get(section, {})


def get_value(section: str, key: str, default: Any = None,
              config: Optional[Dict[str, Any]] = None) -> Any:
    """
    Get a single config value.

    Args:
        section: Section name.
        key: Parameter key within the section.
        default: Fallback value if not found.
        config: Pre-loaded config dict.

    Returns:
        The config value, or default if not found.
    """
    if config is None:
        config = load_config()
    sec = config.get(section, {})
    return sec.get(key, default)
