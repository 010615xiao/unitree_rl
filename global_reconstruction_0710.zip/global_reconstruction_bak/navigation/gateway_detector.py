#!/usr/bin/env python3
"""
Gateway Detector: 基于房间分水岭分割结果提取相邻房间边界和 gateway

1. 运行 watershed 房间分割得到 2D 栅格标签
2. 查找相邻房间共享边界 (两个房间标签在 8-邻域内相邻)
3. 在共享边界区域,检测 floor 通道 (该区域在 floor grid 上必须是可行走的)
4. 提取 gateway 点 (通道的中心/最窄处)
"""

import numpy as np
import cv2
from collections import defaultdict
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
import pickle
from pathlib import Path

from .config_loader import load_config


@dataclass
class Gateway:
    """房间之间的 gateway"""
    id: int
    room_a: int
    room_b: int
    position: np.ndarray  # 2D (x, z) 位置
    position_3d: np.ndarray  # 3D (x, y, z) 位置 (Y 取 floor 高度)
    grid_cell: Tuple[int, int]  # 栅格坐标 (行, 列)
    width: float  # 通道宽度 (像素)
    boundary_cells: List[Tuple[int, int]] = field(default_factory=list)
    floor_cells: List[Tuple[int, int]] = field(default_factory=list)
    confidence: float = 1.0  # 0-1, 基于通道宽度和 floor 连续性


class GatewayDetector:
    """检测 gateway"""
    
    def __init__(self, points: np.ndarray, resolution: float = 0.05, config=None):
        """
        Args:
            points: 全局 floor 点云 (N, 3)
            resolution: 栅格分辨率 (m)
            config: 配置字典 (可选)
        """
        self.points = points
        self.resolution = resolution
        self._config = config or load_config()
        self._gw_cfg = self._config.get('gateway_detector', {})

        # 计算边界
        boundary_expansion = self._gw_cfg.get('boundary_expansion', 0.5)
        self.x_min = points[:, 0].min() - boundary_expansion
        self.x_max = points[:, 0].max() + boundary_expansion
        self.z_min = points[:, 2].min() - boundary_expansion
        self.z_max = points[:, 2].max() + boundary_expansion
        
        self.grid_width = int((self.x_max - self.x_min) / resolution) + 1
        self.grid_height = int((self.z_max - self.z_min) / resolution) + 1
        
        print(f"  栅格尺寸: {self.grid_width}x{self.grid_height} "
              f"(分辨率={resolution*100:.0f}cm)")
    
    def grid_to_world(self, row: int, col: int) -> Tuple[float, float]:
        """栅格坐标 → 世界坐标 (x, z)"""
        x = self.x_min + (col + 0.5) * self.resolution
        z = self.z_min + (row + 0.5) * self.resolution
        return x, z
    
    def world_to_grid(self, x: float, z: float) -> Tuple[int, int]:
        """世界坐标 → 栅格坐标 (row, col)"""
        col = int((x - self.x_min) / self.resolution)
        row = int((z - self.z_min) / self.resolution)
        return row, col
    
    def compute_room_raster(self, rooms: List[Dict]) -> np.ndarray:
        """
        房间分割结果栅格化

        Args:
            rooms: 房间列表,每个 room 包含 'id', 'center'
                   (可选) 包含 'points' 用于精确的房间分割

        Returns:
            2D 数组,每个单元格值为房间 ID,0 表示不属于任何房间
        """
        print("  栅格化房间分割结果...")

        has_points = all('points' in room for room in rooms)

        room_ids = [room['id'] for room in rooms]

        if has_points:
            # 房间点云栅格分配
            from scipy.spatial import cKDTree
            
            all_pts_xz = []
            all_room_idx = []
            for idx, room in enumerate(rooms):
                pts = room['points']
                pts_xz = pts[:, [0, 2]] if pts.shape[1] == 3 else pts
                all_pts_xz.append(pts_xz)
                all_room_idx.append(np.full(len(pts_xz), idx, dtype=np.int32))
            
            all_pts_xz = np.vstack(all_pts_xz)
            all_room_idx = np.concatenate(all_room_idx)
            
            # 构建 KD 树
            tree = cKDTree(all_pts_xz)
            
            raster = np.full((self.grid_height, self.grid_width), -1, dtype=np.int32)
            rows, cols = np.where(np.ones((self.grid_height, self.grid_width), dtype=bool))
            xs = self.x_min + (cols + 0.5) * self.resolution
            zs = self.z_min + (rows + 0.5) * self.resolution
            grid_points = np.column_stack([xs, zs])
            
            dists, idxs = tree.query(grid_points, k=1, distance_upper_bound=1.0)
            
            valid = idxs < len(all_room_idx)
            raster[rows[valid], cols[valid]] = np.array([room_ids[i] for i in all_room_idx[idxs[valid]]])
            
            valid_cells = np.sum(raster >= 0)
            print(f"  有效房间单元格: {valid_cells:,} (基于 {len(all_pts_xz):,} 房间点)")
        else:
            # Fallback: 只用房间中心 (Voronoi)
            room_centers_xz = []
            for room in rooms:
                center = room['center']
                if len(center) == 3:
                    room_centers_xz.append([center[0], center[2]])
                else:
                    room_centers_xz.append(center)

            room_centers_xz = np.array(room_centers_xz)

            raster = np.full((self.grid_height, self.grid_width), -1, dtype=np.int32)  # -1 表示无房间

            from scipy.spatial import cKDTree
            tree = cKDTree(room_centers_xz)

            rows, cols = np.where(np.ones((self.grid_height, self.grid_width), dtype=bool))
            xs = self.x_min + (cols + 0.5) * self.resolution
            zs = self.z_min + (rows + 0.5) * self.resolution
            grid_points = np.column_stack([xs, zs])

            _, room_indices = tree.query(grid_points, k=1)

            raster[rows, cols] = np.array([room_ids[idx] for idx in room_indices])

            valid_cells = np.sum(raster >= 0)
            print(f"  有效房间单元格: {valid_cells:,} (基于房间中心 Voronoi)")

        return raster
    
    def find_adjacent_rooms(self, room_raster: np.ndarray) -> Dict[Tuple[int, int], List[Tuple[int, int]]]:
        """
        找相邻房间对
        
        两个房间如果在 8-邻域内共享边界,则认为是相邻的
        
        Returns:
            {(room_a, room_b): [(row, col), ...]} 共享边界单元格列表
        """
        print("  查找相邻房间...")
        
        room_pairs = defaultdict(list)
        height, width = room_raster.shape
        
        # 对于每个非零单元格,检查 8-邻域
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]:
            # 偏移后的栅格
            shifted = np.roll(room_raster, shift=(dr, dc), axis=(0, 1))
            
            # 边界: 当前单元格 ≠ 偏移单元格,且都不为-1
            boundary_mask = (room_raster != shifted) & (room_raster >= 0) & (shifted >= 0)
            
            # 房间对
            r_a = room_raster[boundary_mask]
            r_b = shifted[boundary_mask]
            
            # 统一顺序
            pair_a = np.minimum(r_a, r_b)
            pair_b = np.maximum(r_a, r_b)
            
            for pa, pb, row, col in zip(pair_a, pair_b, *np.where(boundary_mask)):
                pair = (int(pa), int(pb))
                room_pairs[pair].append((int(row), int(col)))
        
        # 去重
        unique_pairs = {}
        min_boundary_cells = self._gw_cfg.get('min_boundary_cells', 3)
        for pair, cells in room_pairs.items():
            unique_cells = list(set(cells))
            if len(unique_cells) >= min_boundary_cells:  # 至少 N 个单元格才算有效边界
                unique_pairs[pair] = unique_cells
        
        print(f"  找到 {len(unique_pairs)} 对相邻房间")
        for pair, cells in sorted(unique_pairs.items()):
            print(f"    Room {pair[0]} ↔ Room {pair[1]}: {len(cells)} 边界单元格")
        
        return unique_pairs
    
    def find_gateway_on_boundary(self, room_raster: np.ndarray, 
                                  floor_grid: np.ndarray,
                                  boundary_cells: List[Tuple[int, int]],
                                  room_a: int, room_b: int) -> Optional[Gateway]:
        """
        在房间边界上找 gateway (floor 通道)
        
        Args:
            room_raster: 房间栅格
            floor_grid: floor 栅格 (1=可行走, 0=未知/障碍)
            boundary_cells: 房间共享边界单元格
            room_a, room_b: 房间 ID
        """
        if not boundary_cells:
            return None
        
        rows = np.array([c[0] for c in boundary_cells])
        cols = np.array([c[1] for c in boundary_cells])
        
        height, width = floor_grid.shape
        valid_mask = (rows >= 0) & (rows < height) & (cols >= 0) & (cols < width)
        rows, cols = rows[valid_mask], cols[valid_mask]
        
        floor_cells = []
        for r, c in zip(rows, cols):
            if floor_grid[r, c] == 1:  # 可行走
                floor_cells.append((int(r), int(c)))
        
        if len(floor_cells) < 2:
            return None
        
        # 找连通组件 (4-邻域)
        from scipy.ndimage import label
        
        floor_mask = np.zeros_like(floor_grid, dtype=np.uint8)
        for r, c in floor_cells:
            floor_mask[r, c] = 1
        
        labeled, num_components = label(floor_mask, structure=np.ones((3, 3)))
        
        # 选最大的组件
        best_comp_id = 0
        best_comp_size = 0
        for comp_id in range(1, num_components + 1):
            comp_size = np.sum(labeled == comp_id)
            if comp_size > best_comp_size:
                best_comp_size = comp_size
                best_comp_id = comp_id
        
        if best_comp_size < 2:
            return None
        
        # 提取 gateway 单元格
        gateway_cells = list(zip(*np.where(labeled == best_comp_id)))
        
        # 计算中心
        center_row = int(np.mean([r for r, c in gateway_cells]))
        center_col = int(np.mean([c for r, c in gateway_cells]))
        
        # 世界坐标
        x, z = self.grid_to_world(center_row, center_col)
        
        # Y 高度: 原始 floor 点云在该区域的平均 Y
        x_min_region = self.x_min + center_col * self.resolution - 1.0
        x_max_region = x_min_region + 2.0
        z_min_region = self.z_min + center_row * self.resolution - 1.0
        z_max_region = z_min_region + 2.0
        
        region_mask = ((self.points[:, 0] >= x_min_region) & 
                       (self.points[:, 0] < x_max_region) &
                       (self.points[:, 2] >= z_min_region) & 
                       (self.points[:, 2] < z_max_region))
        
        if np.sum(region_mask) > 0:
            y_height = np.mean(self.points[region_mask, 1])
        else:
            y_height = 0.0  # fallback
        
        # 通道宽度
        gateway_rows = np.array([r for r, c in gateway_cells])
        gateway_cols = np.array([c for r, c in gateway_cells])
        
        # 方向
        row_span = gateway_rows.max() - gateway_rows.min() + 1
        col_span = gateway_cols.max() - gateway_cols.min() + 1
        
        if row_span > col_span:
            width_pixels = col_span  # 垂直于主要方向
        else:
            width_pixels = row_span
        
        width_meters = width_pixels * self.resolution
        
        # 置信度: 基于宽度和 floor 连续性
        confidence_denominator = self._gw_cfg.get('confidence_denominator', 10.0)
        confidence = min(1.0, width_meters / 2.0) * min(1.0, best_comp_size / confidence_denominator)
        
        gateway = Gateway(
            id=-1,  # 稍后分配
            room_a=room_a,
            room_b=room_b,
            position=np.array([x, z]),
            position_3d=np.array([x, y_height, z]),
            grid_cell=(center_row, center_col),
            width=width_meters,
            boundary_cells=boundary_cells,
            floor_cells=gateway_cells,
            confidence=confidence
        )
        
        return gateway
    
    def detect_gateways(self, rooms: List[Dict], 
                        floor_grid: Optional[np.ndarray] = None) -> List[Gateway]:
        """
        完整 gateway 检测流程
        
        Args:
            rooms: 房间列表 (来自 watershed 分割)
            floor_grid: floor 栅格 (可选,如果不提供则从 points 生成)
            
        Returns:
            检测到的 gateway 列表
        """
        print("\n" + "=" * 60)
        print("Gateway 检测 (基于房间分割)")
        print("=" * 60)
        
        # Step 1: 栅格化房间
        room_raster = self.compute_room_raster(rooms)
        
        # Step 2: 生成/使用 floor grid
        if floor_grid is None:
            floor_grid = self._compute_floor_grid()
        
        # Step 3: 找相邻房间
        adjacent_pairs = self.find_adjacent_rooms(room_raster)
        
        # Step 4: 对每对相邻房间,在边界上找 gateway
        gateways = []
        gateway_id = 0
        
        for (room_a, room_b), boundary_cells in adjacent_pairs.items():
            gateway = self.find_gateway_on_boundary(
                room_raster, floor_grid, boundary_cells, room_a, room_b
            )
            if gateway is not None:
                gateway.id = gateway_id
                gateways.append(gateway)
                gateway_id += 1
                print(f"  Gateway {gateway.id}: Room {room_a} ↔ Room {room_b} "
                      f"@ ({gateway.position[0]:.1f}, {gateway.position[1]:.1f}), "
                      f"宽度={gateway.width:.2f}m, 置信度={gateway.confidence:.2f}")
        
        print(f"\n  总计检测到 {len(gateways)} 个 gateway")
        return gateways
    
    def _compute_floor_grid(self) -> np.ndarray:
        """从 floor 点云生成 floor 栅格"""
        print("  生成 floor 栅格...")

        grid = np.zeros((self.grid_height, self.grid_width), dtype=np.uint8)

        # floor 提取 (Z-band)
        z_min_all = self.points[:, 2].min()
        z_max_all = self.points[:, 2].max()

        floor_2d_list = []
        band_size = self._gw_cfg.get('band_size', 0.3)
        floor_y_threshold = self._gw_cfg.get('floor_y_threshold', 1.0)
        z_bands = np.arange(z_min_all - band_size, z_max_all + band_size, band_size)

        for i in range(len(z_bands) - 1):
            z_low = z_bands[i]
            z_high = z_bands[i + 1]

            band_mask = (self.points[:, 2] >= z_low) & (self.points[:, 2] < z_high)
            band_pts = self.points[band_mask]

            if len(band_pts) < 100:
                continue

            y_10 = np.percentile(band_pts[:, 1], 10)
            floor_y = y_10 + floor_y_threshold

            floor_mask = band_pts[:, 1] < floor_y
            floor_pts = band_pts[floor_mask]
            if len(floor_pts) > 0:
                floor_2d_list.append(floor_pts[:, [0, 2]])

        if not floor_2d_list:
            print("  警告: 未提取到 floor 点")
            return grid

        floor_2d = np.vstack(floor_2d_list)

        # 栅格化
        for pt in floor_2d:
            row, col = self.world_to_grid(pt[0], pt[1])
            if 0 <= row < self.grid_height and 0 <= col < self.grid_width:
                grid[row, col] = 1

        # 形态学闭运算填充空洞
        from scipy.ndimage import binary_dilation, binary_erosion
        gm_cfg = self._config.get('grid_map', {})
        morph_kernel = gm_cfg.get('morph_kernel_size', 5)
        morph_iters = gm_cfg.get('morph_iterations', 2)
        kernel = np.ones((morph_kernel, morph_kernel), dtype=np.uint8)
        grid = binary_dilation(grid.astype(np.uint8), iterations=morph_iters).astype(np.uint8)
        grid = binary_erosion(grid, iterations=morph_iters).astype(np.uint8)
        
        floor_cells = np.sum(grid == 1)
        print(f"  Floor 单元格: {floor_cells:,}")
        
        return grid
    
    def visualize_gateways(self, gateways: List[Gateway], 
                           rooms: List[Dict],
                           floor_grid: np.ndarray,
                           output_path: str = "gateway_detection.png"):
        """可视化 gateway 检测结果"""
        import matplotlib.pyplot as plt
        from matplotlib.patches import Circle
        import matplotlib.patches as mpatches
        
        fig, axes = plt.subplots(2, 2, figsize=(24, 20))
        
        # 计算房间栅格
        room_raster = self.compute_room_raster(rooms)
        
        # 房间分割 + Gateway
        ax1 = axes[0, 0]
        
        # 房间着色
        cmap = plt.cm.get_cmap('tab10', 10)
        room_vis = np.zeros((room_raster.shape[0], room_raster.shape[1], 3))
        unique_rooms = np.unique(room_raster[room_raster >= 0])
        for i, room_id in enumerate(unique_rooms):
            mask = room_raster == room_id
            color = cmap(i % 10)[:3]
            room_vis[mask] = color
        
        ax1.imshow(room_vis, origin='lower',
                  extent=[self.x_min, self.x_min + self.grid_width * self.resolution,
                         self.z_min, self.z_min + self.grid_height * self.resolution],
                  aspect='equal')
        
        for gw in gateways:
            ax1.scatter(gw.position[0], gw.position[1], c='white', s=200, 
                       edgecolors='red', linewidth=3, zorder=5)
            ax1.annotate(f'GW{gw.id}', (gw.position[0], gw.position[1]),
                        fontsize=8, ha='center', va='center', fontweight='bold',
                        color='red', zorder=6)
        
        ax1.set_title(f'Room Segmentation + Gateway Detection\n{len(gateways)} gateways found', fontsize=14)
        ax1.set_xlabel('X (m)')
        ax1.set_ylabel('Z (m)')
        ax1.legend(handles=[mpatches.Patch(color='white', label='Gateway')], 
                  loc='upper right')
        ax1.grid(True, alpha=0.3)
        
        # Floor Grid + Gateway
        ax2 = axes[0, 1]
        floor_vis = np.zeros((floor_grid.shape[0], floor_grid.shape[1], 3))
        floor_vis[floor_grid == 1] = [0, 1, 0]
        
        ax2.imshow(floor_vis, origin='lower',
                  extent=[self.x_min, self.x_min + self.grid_width * self.resolution,
                         self.z_min, self.z_min + self.grid_height * self.resolution],
                  aspect='equal')
        
        for gw in gateways:
            ax2.scatter(gw.position[0], gw.position[1], c='yellow', s=150,
                       edgecolors='orange', linewidth=2, zorder=5)
        
        ax2.set_title(f'Floor Grid + Gateway Positions\n{len(gateways)} gateways', fontsize=14)
        ax2.set_xlabel('X (m)')
        ax2.set_ylabel('Z (m)')
        ax2.grid(True, alpha=0.3)
        
        # Gateway 置信度分布
        ax3 = axes[1, 0]
        if gateways:
            gw_ids = [gw.id for gw in gateways]
            confidences = [gw.confidence for gw in gateways]
            widths = [gw.width for gw in gateways]
            
            x_pos = np.arange(len(gateways))
            bars1 = ax3.bar(x_pos - 0.2, confidences, 0.4, label='Confidence', color='skyblue')
            bars2 = ax3.bar(x_pos + 0.2, widths, 0.4, label='Width (m)', color='lightcoral')
            
            ax3.set_xticks(x_pos)
            ax3.set_xticklabels([f'GW{i}' for i in gw_ids])
            ax3.set_ylabel('Value')
            ax3.set_title('Gateway Properties', fontsize=14)
            ax3.legend()
            ax3.grid(True, alpha=0.3)
        else:
            ax3.text(0.5, 0.5, 'No gateways detected', ha='center', va='center',
                    fontsize=16, transform=ax3.transAxes)
        
        # Gateway 连通图
        ax4 = axes[1, 1]
        room_positions = {}
        for room in rooms:
            room_id = room['id']
            center = room['center']
            room_positions[room_id] = (center[0], center[2])
            ax4.scatter(center[0], center[2], c='blue', s=100, zorder=3)
            ax4.annotate(f'R{room_id}', (center[0], center[2]),
                        fontsize=8, ha='center', va='center', color='white',
                        fontweight='bold', zorder=4)
        
        # Gateway
        for gw in gateways:
            if gw.room_a in room_positions and gw.room_b in room_positions:
                pos_a = room_positions[gw.room_a]
                pos_b = room_positions[gw.room_b]
                
                ax4.plot([pos_a[0], gw.position[0], pos_b[0]], 
                        [pos_a[1], gw.position[1], pos_b[1]],
                        'g-', linewidth=2, alpha=0.7, zorder=2)
                ax4.scatter(gw.position[0], gw.position[1], c='yellow', s=100,
                           edgecolors='orange', linewidth=2, zorder=5)
        
        ax4.set_title('Room-Gateway Connectivity Graph', fontsize=14)
        ax4.set_xlabel('X (m)')
        ax4.set_ylabel('Z (m)')
        ax4.set_aspect('equal')
        ax4.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  已保存: {output_path}")

    def detect_gateways_from_trajectory(self, trajectory: np.ndarray,
                                         rooms: List[Dict],
                                         room_raster: Optional[np.ndarray] = None,
                                         floor_grid: Optional[np.ndarray] = None,
                                         merge_distance: float = None) -> List[Gateway]:
        """
        基于机器人实际行走轨迹提取 gateway

        Args:
            trajectory: (N, 3) 轨迹点云 (x, y, z)
            rooms: 房间列表 (含 'id', 'center')
            room_raster: 房间栅格
            floor_grid: floor 栅格
            merge_distance: 同一房间对 gateway 合并距离阈值 (m), 默认从 config 读取

        Returns:
            检测到的 gateway 列表
        """
        print("\n" + "=" * 60)
        print("Gateway 检测 (基于实际行走轨迹)")
        print("=" * 60)

        if merge_distance is None:
            merge_distance = self._gw_cfg.get('merge_distance', 1.0)

        if room_raster is None:
            print("  生成房间栅格...")
            room_raster = self.compute_room_raster(rooms)

        if floor_grid is None:
            print("  生成 floor 栅格...")
            floor_grid = self._compute_floor_grid()

        print(f"  轨迹点数: {len(trajectory)}")
        print("  判断每个点所属房间...")

        room_ids = []
        for pt in trajectory:
            rid = self._get_room_id_at_point(pt, room_raster, rooms)
            room_ids.append(rid)

        # 有效房间分配
        valid_assignments = sum(1 for rid in room_ids if rid is not None)
        print(f"  成功分配房间: {valid_assignments}/{len(trajectory)}")

        print("  检测房间变化...")
        candidate_gateways = []  # [(room_a, room_b, position_3d)]

        for i in range(len(trajectory) - 1):
            r_curr = room_ids[i]
            r_next = room_ids[i + 1]

            if r_curr is None or r_next is None:
                continue

            if r_curr != r_next:
                # 候选 gateway
                gw_pos = (trajectory[i] + trajectory[i + 1]) / 2.0

                # 统一房间对顺序
                room_a, room_b = min(r_curr, r_next), max(r_curr, r_next)
                candidate_gateways.append((room_a, room_b, gw_pos))

        print(f"  候选 gateway 数: {len(candidate_gateways)}")

        if not candidate_gateways:
            print("  未检测到房间变化,返回空列表")
            return []

        print("  融合相同房间对的 gateway...")
        room_pair_positions = defaultdict(list)

        for room_a, room_b, pos in candidate_gateways:
            room_pair_positions[(room_a, room_b)].append(pos)

        gateways = []
        gateway_id = 0

        for (room_a, room_b), positions in sorted(room_pair_positions.items()):
            positions = np.array(positions)

            # 距离近的合并
            merged_positions = self._cluster_positions(positions, merge_distance)

            for merged_pos in merged_positions:
                # Y 高度: 用 floor 栅格区域的平均 Y
                row, col = self.world_to_grid(merged_pos[0], merged_pos[1])

                # 在局部区域找 floor 点云的平均 Y
                x_min_r = self.x_min + col * self.resolution - 0.5
                x_max_r = x_min_r + 1.0
                z_min_r = self.z_min + row * self.resolution - 0.5
                z_max_r = z_min_r + 1.0

                region_mask = ((self.points[:, 0] >= x_min_r) &
                               (self.points[:, 0] < x_max_r) &
                               (self.points[:, 2] >= z_min_r) &
                               (self.points[:, 2] < z_max_r))

                if np.sum(region_mask) > 10:
                    y_height = np.percentile(self.points[region_mask, 1], 10) + 0.6
                else:
                    y_height = merged_pos[1]  # fallback 用轨迹 Y

                final_pos_3d = np.array([merged_pos[0], y_height, merged_pos[2]])

                # 通道宽度
                pair_positions = np.array([p for r_a, r_b, p in candidate_gateways
                                           if r_a == room_a and r_b == room_b])
                if len(pair_positions) > 1:
                    width = max(np.max(pair_positions[:, 0]) - np.min(pair_positions[:, 0]),
                                np.max(pair_positions[:, 2]) - np.min(pair_positions[:, 2]))
                else:
                    width = 1.0  # 默认

                confidence_denominator = self._gw_cfg.get('confidence_denominator', 10.0)
                confidence = min(1.0, len(positions) / confidence_denominator)

                gateway = Gateway(
                    id=gateway_id,
                    room_a=room_a,
                    room_b=room_b,
                    position=np.array([merged_pos[0], merged_pos[1]]),
                    position_3d=final_pos_3d,
                    grid_cell=(row, col),
                    width=width,
                    confidence=confidence
                )
                gateways.append(gateway)

                print(f"  Gateway {gateway_id}: Room {room_a} ↔ Room {room_b} "
                      f"@ ({merged_pos[0]:.2f}, {y_height:.2f}, {merged_pos[1]:.2f}), "
                      f"穿越次数={len(positions)}, 宽度≈{width:.2f}m")

                gateway_id += 1

        print(f"\n  总计检测到 {len(gateways)} 个 gateway")
        return gateways

    def _get_room_id_at_point(self, point: np.ndarray,
                               room_raster: np.ndarray,
                               rooms: List[Dict]) -> Optional[int]:
        """
        判断轨迹点属于哪个房间

        Args:
            point: (x, y, z) 轨迹点
            room_raster: 房间栅格
            rooms: 房间列表

        Returns:
            房间 ID, 或 None
        """
        row, col = self.world_to_grid(point[0], point[2])

        if 0 <= row < room_raster.shape[0] and 0 <= col < room_raster.shape[1]:
            room_id = room_raster[row, col]
            if room_id > 0:
                return int(room_id)

        # 距离 fallback: 找最近的房间中心
        min_dist = float('inf')
        best_room = None

        for room in rooms:
            center = room['center']
            if len(center) == 3:
                dist = np.linalg.norm(point - center)
            else:
                dist = np.linalg.norm(point[:3] - np.array([center[0], 0, center[1]]))

            if dist < min_dist:
                min_dist = dist
                best_room = room['id']

        return best_room

    def _cluster_positions(self, positions: np.ndarray,
                            threshold: float) -> List[np.ndarray]:
        """
        位置聚类: 距离近的点合并为一个

        Args:
            positions: (N, 3) 位置数组
            threshold: 合并距离阈值 (m)

        Returns:
            聚类后的位置列表 (每个聚类的中心)
        """
        if len(positions) == 0:
            return []

        clusters = []
        used = np.zeros(len(positions), dtype=bool)

        for i in range(len(positions)):
            if used[i]:
                continue

            cluster = [positions[i]]
            used[i] = True

            for j in range(i + 1, len(positions)):
                if used[j]:
                    continue
                if np.linalg.norm(positions[j] - positions[i]) < threshold:
                    cluster.append(positions[j])
                    used[j] = True

            # 聚类中心
            center = np.mean(cluster, axis=0)
            clusters.append(center)

        return clusters


def run_gateway_detection(points: np.ndarray, rooms: List[Dict],
                          output_dir: str = "navigation/gateway_viz",
                          trajectory: Optional[np.ndarray] = None,
                          merge_distance: float = 1.0) -> List[Gateway]:
    """
    gateway 检测

    Args:
        points: floor 点云
        rooms: 房间列表
        output_dir: 输出目录
        trajectory: (N, 3) 机器人行走轨迹
        merge_distance: 轨迹方法中 gateway 合并距离阈值 (m)

    Returns:
        检测到的 gateway 列表
    """
    from pathlib import Path

    detector = GatewayDetector(points, resolution=0.05)

    if trajectory is not None:
        # 轨迹
        gateways = detector.detect_gateways_from_trajectory(
            trajectory, rooms, merge_distance=merge_distance
        )
    else:
        # 原始房间相邻性
        gateways = detector.detect_gateways(rooms)

    if gateways:
        # floor grid
        floor_grid = detector._compute_floor_grid()

        output_path = Path(output_dir) / "gateway_detection.png"
        output_path.parent.mkdir(parents=True, exist_ok=True)

        detector.visualize_gateways(gateways, rooms, floor_grid, str(output_path))

        # gateway
        gateway_data = {
            'gateways': [{
                'id': gw.id,
                'room_a': gw.room_a,
                'room_b': gw.room_b,
                'position': gw.position.tolist(),
                'position_3d': gw.position_3d.tolist(),
                'grid_cell': gw.grid_cell,
                'width': gw.width,
                'confidence': gw.confidence
            } for gw in gateways],
            'resolution': detector.resolution,
            'x_min': detector.x_min,
            'z_min': detector.z_min,
        }

        with open(Path(output_dir) / "gateways.pkl", 'wb') as f:
            pickle.dump(gateway_data, f)

        print(f"\nGateway 数据已保存至: {output_dir}/gateways.pkl")

    return gateways


if __name__ == '__main__':
    import argparse
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
    
    parser = argparse.ArgumentParser(description='Gateway 检测')
    parser.add_argument('--pcd', type=str, 
                       default='../unified_output/global/global_pointcloud.ply')
    parser.add_argument('--rooms', type=str,
                       default='unified_output/rooms/floor_0_rooms.pkl')
    parser.add_argument('--output', type=str, default='gateway_viz')
    args = parser.parse_args()
    
    import open3d as o3d
    
    print("加载点云...")
    pcd = o3d.io.read_point_cloud(args.pcd)
    points = np.asarray(pcd.points)
    print(f"  总点数: {len(points):,}")
    
    print("加载房间数据...")
    rooms_path = Path(args.rooms)
    if rooms_path.exists():
        with open(rooms_path, 'rb') as f:
            rooms = pickle.load(f)
    else:
        # 从 scene_graph.json 获取房间
        scene_graph_path = Path(__file__).parent.parent.parent / "scene_graph.json"
        if scene_graph_path.exists():
            import json
            with open(scene_graph_path, 'r') as f:
                scene_data = json.load(f)
            
            rooms = []
            for obj in scene_data.get('objects', []):
                if 'room' in obj.get('category', '').lower():
                    rooms.append({
                        'id': int(obj.get('name', '0').split('_')[-1]),
                        'center': np.array(obj['center']),
                        'points': np.array([[obj['center'][0], 0, obj['center'][2]]])
                    })
            print(f"  从 scene_graph 加载 {len(rooms)} 个房间")
        else:
            print("错误: 未找到房间数据")
            sys.exit(1)
    
    gateways = run_gateway_detection(points, rooms, args.output)
