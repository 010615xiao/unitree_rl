#!/usr/bin/env python3
"""
场景可视化

输出文件清单:
  2D 图片 (PNG):
    01_floor_xz.png              - Floor 点云
    02_obstacle_xz.png           - Obstacle footprint
    03_combined.png              - Floor + Obstacle
    04_grid_map.png              - 栅格地图 (可行走/障碍物/未知)
    05_floor_components.png      - Floor 连通分量
    06_cost_map.png              - Cost Map (含外围 wall 补全)
    07_path_on_grid.png          - 路径 + 起点 + 终点 + gateway
    08_path_on_cost.png          - 路径叠加在 cost map 上
    09_path_comparison.png       - 多路径对比

  3D 点云 (PLY, 可用 MeshLab 打开):
    10_global_pointcloud.ply     - 全局点云
    11_path_line.ply             - 路径线
    12_start.ply                 - 起点
    13_target.ply                - 目标
    14_waypoints.ply             - Gateway 中间点
"""

import numpy as np
import json
import pickle
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Patch
from collections import defaultdict
from pathlib import Path
import open3d as o3d
import sys

script_dir = Path(__file__).resolve().parent
project_root = script_dir.parent
sys.path.insert(0, str(project_root))

from navigation.cost_map import CostMap
from navigation.config_loader import load_config


def _detect_up_axis(global_pcd_path):
    """检测点云垂直轴，返回 'y' 或 'z'。"""
    import json
    base_dir = Path(global_pcd_path).parent.parent
    plane_path = base_dir / 'trajectory_plane.json'
    if plane_path.exists():
        with open(plane_path, 'r') as f:
            plane = json.load(f)
        normal = np.array(plane['normal'])
        if abs(normal[2]) > abs(normal[1]):
            return 'z'
        return 'y'
    config_path = base_dir / 'config.yaml'
    if config_path.exists():
        import yaml
        with open(config_path, 'r') as f:
            cfg = yaml.safe_load(f)
        if cfg.get('trajectory_alignment', {}).get('enabled', False):
            return 'z'
    return 'y'


# ============================================================
# 数据加载
# ============================================================

def load_pointcloud(pcd_path):
    pcd = o3d.io.read_point_cloud(str(pcd_path))
    return np.asarray(pcd.points)


def load_grid_map(pkl_path):
    with open(pkl_path, 'rb') as f:
        return pickle.load(f)


def load_path(path_json):
    if path_json and Path(path_json).exists():
        with open(path_json, 'r') as f:
            return json.load(f)
    return None


def extract_floor_and_obstacles(points, floor_y_threshold=0.6, up_axis='y', config=None):
    """从点云提取 floor 和 obstacle

    参数:
        floor_y_threshold: floor 高度阈值 (米)，推荐 0.2-0.5m
        up_axis: 'y' (Y-up) 或 'z' (Z-up)
        config: 配置字典 (可选)
    """
    cfg = config or load_config()
    gm_cfg = cfg.get('grid_map', {})
    vis_cfg = cfg.get('visualize', {})

    if up_axis == 'z':
        # Z-up: Z 是高度, 投影到 X-Y 平面
        h_min_all = points[:, 1].min()
        h_max_all = points[:, 1].max()
        height_idx = 2  # Z
        h_idx = 1       # Y

        floor_2d_list = []
        floor_3d_list = []
        floor_y_map = {}

        band_size = gm_cfg.get('band_size', 0.3)
        h_bands = np.arange(h_min_all - band_size, h_max_all + band_size, band_size)

        for i in range(len(h_bands) - 1):
            h_low = h_bands[i]
            h_high = h_bands[i + 1]
            band_mask = (points[:, h_idx] >= h_low) & (points[:, h_idx] < h_high)
            band_pts = points[band_mask]
            if len(band_pts) < 100:
                continue

            z_10 = np.percentile(band_pts[:, height_idx], 10)
            floor_z = z_10 + floor_y_threshold
            h_mid = (h_low + h_high) / 2
            floor_y_map[h_mid] = floor_z

            floor_mask = band_pts[:, height_idx] < floor_z
            floor_pts = band_pts[floor_mask]
            if len(floor_pts) > 0:
                floor_2d_list.append(floor_pts[:, [0, h_idx]])  # [x, y]
                floor_3d_list.append(floor_pts)

        # Obstacle: 基于垂直 Z 跨度
        obstacle_resolution = vis_cfg.get('obstacle_resolution', 0.2)
        obstacle_subsample = vis_cfg.get('obstacle_subsample', 50)
        z_span_threshold = vis_cfg.get('obstacle_z_span_threshold_zup', 0.05)
        x_min, x_max = points[:, 0].min(), points[:, 0].max()
        y_min, y_max = points[:, 1].min(), points[:, 1].max()

        cell_zs = defaultdict(list)
        for pt in points[::obstacle_subsample]:
            gx = int((pt[0] - x_min) / obstacle_resolution)
            gy = int((pt[1] - y_min) / obstacle_resolution)
            cell_zs[(gx, gy)].append(pt[2])

        obstacle_2d_list = []
        obstacle_y_span_list = []
        for (gx, gy), zs in cell_zs.items():
            z_span = max(zs) - min(zs)
            if z_span > z_span_threshold:
                x = (gx - 1) * obstacle_resolution + x_min
                y = (gy - 1) * obstacle_resolution + y_min
                obstacle_2d_list.append([x, y])
                obstacle_y_span_list.append(z_span)

        floor_2d = np.vstack(floor_2d_list) if floor_2d_list else np.array([]).reshape(0, 2)
        floor_3d = np.vstack(floor_3d_list) if floor_3d_list else np.array([]).reshape(0, 3)
        obstacle_2d = np.array(obstacle_2d_list) if obstacle_2d_list else np.array([]).reshape(0, 2)
        obstacle_y_spans = np.array(obstacle_y_span_list) if obstacle_y_span_list else np.array([])

    else:
        # Y-up: Y 是高度, 投影到 X-Z 平面 (原始逻辑)
        z_min_all = points[:, 2].min()
        z_max_all = points[:, 2].max()

        floor_2d_list = []
        floor_3d_list = []
        floor_y_map = {}

        band_size = gm_cfg.get('band_size', 0.3)
        z_bands = np.arange(z_min_all - band_size, z_max_all + band_size, band_size)

        for i in range(len(z_bands) - 1):
            z_low = z_bands[i]
            z_high = z_bands[i + 1]
            band_mask = (points[:, 2] >= z_low) & (points[:, 2] < z_high)
            band_pts = points[band_mask]
            if len(band_pts) < 100:
                continue

            y_10 = np.percentile(band_pts[:, 1], 10)
            floor_y = y_10 + floor_y_threshold
            z_mid = (z_low + z_high) / 2
            floor_y_map[z_mid] = floor_y

            floor_mask = band_pts[:, 1] < floor_y
            floor_pts = band_pts[floor_mask]
            if len(floor_pts) > 0:
                floor_2d_list.append(floor_pts[:, [0, 2]])
                floor_3d_list.append(floor_pts)

        # Obstacle: 基于垂直 Y 跨度
        obstacle_resolution = vis_cfg.get('obstacle_resolution', 0.2)
        obstacle_subsample = vis_cfg.get('obstacle_subsample', 50)
        y_span_threshold = vis_cfg.get('obstacle_z_span_threshold_yup', 0.05)
        x_min, x_max = points[:, 0].min(), points[:, 0].max()
        z_min, z_max = points[:, 2].min(), points[:, 2].max()

        cell_ys = defaultdict(list)
        for pt in points[::obstacle_subsample]:
            gx = int((pt[0] - x_min) / obstacle_resolution)
            gz = int((pt[2] - z_min) / obstacle_resolution)
            cell_ys[(gx, gz)].append(pt[1])

        obstacle_2d_list = []
        obstacle_y_span_list = []
        for (gx, gz), ys in cell_ys.items():
            y_span = max(ys) - min(ys)
            if y_span > y_span_threshold:
                x = (gx - 1) * obstacle_resolution + x_min
                z = (gz - 1) * obstacle_resolution + z_min
                obstacle_2d_list.append([x, z])
                obstacle_y_span_list.append(y_span)

        floor_2d = np.vstack(floor_2d_list) if floor_2d_list else np.array([]).reshape(0, 2)
        floor_3d = np.vstack(floor_3d_list) if floor_3d_list else np.array([]).reshape(0, 3)
        obstacle_2d = np.array(obstacle_2d_list) if obstacle_2d_list else np.array([]).reshape(0, 2)
        obstacle_y_spans = np.array(obstacle_y_span_list) if obstacle_y_span_list else np.array([])

    return floor_2d, floor_3d, obstacle_2d, obstacle_y_spans, floor_y_map


# ============================================================
# 可视化
# ============================================================

def viz_01_floor_xz(floor_2d, floor_3d, output_dir, up_axis='y'):
    """Floor 点云 (按 up_axis 选择投影平面和高度轴)"""
    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    if up_axis == 'z':
        # Z-up: 投影到 X-Y 平面, 按 Z 高度着色
        scatter = ax.scatter(floor_2d[:, 0], floor_2d[:, 1],
                            c=floor_3d[:, 2], cmap='viridis',
                            s=0.5, alpha=0.6, rasterized=True)
        plt.colorbar(scatter, ax=ax, label='Z Height (m)')
        ax.set_title(f'Floor Points (XY plane, colored by Z)\n{len(floor_2d):,} points', fontsize=14)
        ax.set_xlabel('X (m)')
        ax.set_ylabel('Y (m)')
    else:
        # Y-up: 投影到 X-Z 平面, 按 Y 高度着色
        scatter = ax.scatter(floor_2d[:, 0], floor_2d[:, 1],
                            c=floor_3d[:, 1], cmap='viridis',
                            s=0.5, alpha=0.6, rasterized=True)
        plt.colorbar(scatter, ax=ax, label='Y Height (m)')
        ax.set_title(f'Floor Points (XZ plane, colored by Y)\n{len(floor_2d):,} points', fontsize=14)
        ax.set_xlabel('X (m)')
        ax.set_ylabel('Z (m)')
        ax.invert_yaxis()

    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_dir / '01_floor_xz.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("  [2D] 01_floor_xz.png")


def viz_02_obstacle_xz(obstacle_2d, obstacle_y_spans, output_dir, up_axis='y'):
    """Obstacle footprint (按 up_axis 选择投影平面)"""
    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    if up_axis == 'z':
        span_label = 'Z Span (m)'
        title = f'Obstacle Footprint (XY plane, colored by Z span)\n{len(obstacle_2d):,} cells'
        ylabel = 'Y (m)'
    else:
        span_label = 'Y Span (m)'
        title = f'Obstacle Footprint (XZ plane, colored by Y span)\n{len(obstacle_2d):,} cells'
        ylabel = 'Z (m)'

    if len(obstacle_2d) > 0:
        scatter = ax.scatter(obstacle_2d[:, 0], obstacle_2d[:, 1],
                            c=obstacle_y_spans, cmap='hot',
                            s=5, alpha=0.8, edgecolors='none')
        plt.colorbar(scatter, ax=ax, label=span_label)
    ax.set_title(title, fontsize=14)
    ax.set_xlabel('X (m)')
    ax.set_ylabel(ylabel)
    ax.set_aspect('equal')
    if up_axis != 'z':
        ax.invert_yaxis()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_dir / '02_obstacle_xz.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("  [2D] 02_obstacle_xz.png")


def viz_03_combined(floor_2d, obstacle_2d, output_dir, up_axis='y'):
    """Floor + Obstacle 合并散点"""
    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    if up_axis == 'z':
        ylabel = 'Y (m)'
        title = f'Floor + Obstacle Overlay\nGreen: Floor ({len(floor_2d):,}), Red: Obstacle ({len(obstacle_2d):,})'
    else:
        ylabel = 'Z (m)'
        title = f'Floor + Obstacle Overlay\nGreen: Floor ({len(floor_2d):,}), Red: Obstacle ({len(obstacle_2d):,})'

    ax.scatter(floor_2d[:, 0], floor_2d[:, 1], c='#2ecc71', s=0.3, alpha=0.4, label='Floor')
    if len(obstacle_2d) > 0:
        ax.scatter(obstacle_2d[:, 0], obstacle_2d[:, 1], c='#e74c3c', s=2, alpha=0.7, label='Obstacle')
    ax.set_title(title, fontsize=14)
    ax.set_xlabel('X (m)')
    ax.set_ylabel(ylabel)
    ax.set_aspect('equal')
    if up_axis != 'z':
        ax.invert_yaxis()
    ax.legend(loc='upper right')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_dir / '03_combined.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("  [2D] 03_combined.png")


def viz_04_grid_map(grid_data, output_dir, completed_grid=None, up_axis='y'):
    """栅格地图 (可行走/障碍物/未知)"""
    grid = completed_grid if completed_grid is not None else grid_data['grid']
    resolution = grid_data['resolution']
    x_min = grid_data['x_min']
    h_min = grid_data.get('h_min', grid_data.get('z_min', 0))
    height, width = grid.shape
    x_max = x_min + width * resolution
    h_max = h_min + height * resolution

    # 根据 up_axis 决定轴标签
    if up_axis == 'z':
        h_label = 'Y (m)'
    else:
        h_label = 'Z (m)'

    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    # grid[row, col]: row 0 = h_min, row H-1 = h_max
    vis_grid = np.zeros((height, width, 3), dtype=np.uint8)
    vis_grid[grid == 1] = [0, 255, 0]      # 绿色 = 可行走
    vis_grid[grid == 100] = [255, 0, 0]    # 红色 = 障碍物
    vis_grid[grid == 0] = [50, 50, 50]     # 灰色 = 未知

    im = ax.imshow(vis_grid, origin='lower',
                   extent=[x_min, x_max, h_min, h_max],
                   aspect='equal', alpha=0.8)

    added = np.sum(grid == 100) - np.sum(grid_data['grid'] == 100) if completed_grid is not None else 0
    label_obs = f'Obstacle ({np.sum(grid==100):,})'
    if completed_grid is not None and added > 0:
        label_obs += f' (incl. +{added:,} walls)'

    legend_elements = [
        Patch(facecolor='green', label=f'Walkable ({np.sum(grid==1):,})'),
        Patch(facecolor='red', label=label_obs),
        Patch(facecolor='#333333', label=f'Unknown ({np.sum(grid==0):,})'),
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
    ax.set_title(f'Grid Map ({resolution}m resolution)\n{width}x{height} cells', fontsize=14)
    ax.set_xlabel('X (m)')
    ax.set_ylabel(h_label)
    ax.grid(True, alpha=0.2, linestyle='--')

    # 比例尺
    scale_bar = 5.0
    sx = x_min + 0.05 * (x_max - x_min)
    sh = h_min + 0.08 * (h_max - h_min)
    ax.plot([sx, sx + scale_bar], [sh, sh], 'k-', linewidth=3, zorder=5)
    ax.text(sx + scale_bar/2, sh - 0.3, f'{scale_bar}m', ha='center', va='top',
           fontsize=10, fontweight='bold', zorder=6)

    plt.tight_layout()
    plt.savefig(output_dir / '04_grid_map.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("  [2D] 04_grid_map.png")


def viz_05_floor_components(grid_data, output_dir, completed_grid=None, up_axis='y', config=None):
    """Floor 连通分量"""
    from scipy.ndimage import label as nd_label, binary_dilation, binary_erosion

    cfg = config or load_config()
    vis_cfg = cfg.get('visualize', {})

    grid = completed_grid if completed_grid is not None else grid_data['grid']
    resolution = grid_data['resolution']
    x_min = grid_data['x_min']
    h_min = grid_data.get('h_min', grid_data.get('z_min', 0))
    height, width = grid.shape
    x_max = x_min + width * resolution
    h_max = h_min + height * resolution

    if up_axis == 'z':
        h_label = 'Y (m)'
    else:
        h_label = 'Z (m)'

    floor_mask = (grid == 1).astype(np.uint8)

    # 形态学闭运算填充小空洞
    kernel_size = vis_cfg.get('component_dilation_iterations', 2)
    kernel = np.ones((3, 3), dtype=np.uint8)
    filled = binary_dilation(floor_mask, structure=kernel, iterations=kernel_size)
    filled = binary_erosion(filled, structure=kernel, iterations=kernel_size)

    labeled, num_components = nd_label(filled)

    # 只保留 > min_cells 的组件
    min_cells = vis_cfg.get('component_min_cells', 100)
    valid_comps = {}
    for comp_id in range(1, num_components + 1):
        size = np.sum(labeled == comp_id)
        if size > min_cells:
            valid_comps[comp_id] = size

    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    colored = np.zeros_like(labeled)
    for idx, comp_id in enumerate(sorted(valid_comps.keys())):
        colored[labeled == comp_id] = idx + 1

    cmap = plt.colormaps['tab20'].resampled(len(valid_comps) + 1)
    im = ax.imshow(colored, cmap=cmap, origin='lower',
                   extent=[x_min, x_max, h_min, h_max], aspect='equal')

    legend_elements = []
    for idx, comp_id in enumerate(sorted(valid_comps.keys())):
        legend_elements.append(Patch(facecolor=cmap(idx + 1),
                                     label=f'Comp {comp_id}: {valid_comps[comp_id]:,} cells'))
    ax.legend(handles=legend_elements, loc='upper right', fontsize=8)
    ax.set_title(f'Floor Connected Components ({len(valid_comps)} components)', fontsize=14)
    ax.set_xlabel('X (m)')
    ax.set_ylabel(h_label)
    ax.grid(True, alpha=0.2, linestyle='--')

    plt.tight_layout()
    plt.savefig(output_dir / '05_floor_components.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("  [2D] 05_floor_components.png")


def viz_06_cost_map(grid_data, output_dir, complete_wall=True, sigma=0.5, weight=5.0, up_axis='y'):
    """Cost Map (含外围 wall 补全)"""
    cm = CostMap(
        grid=grid_data['grid'],
        resolution=grid_data['resolution'],
        x_min=grid_data['x_min'],
        h_min=grid_data.get('h_min', grid_data.get('z_min', 0)),
        sigma=sigma,
        distance_weight=weight,
        complete_boundary_wall=complete_wall
    )

    if up_axis == 'z':
        h_label = 'Y (m)'
    else:
        h_label = 'Z (m)'

    fig, axes = plt.subplots(1, 3, figsize=(36, 12))

    extent = [grid_data['x_min'], grid_data['x_min'] + grid_data['width'] * grid_data['resolution'],
              grid_data.get('h_min', grid_data.get('z_min', 0)),
              grid_data.get('h_min', grid_data.get('z_min', 0)) + grid_data['height'] * grid_data['resolution']]

    orig_obstacle = np.sum(grid_data['grid'] == 100)
    new_obstacle = np.sum(cm.grid == 100)
    added = new_obstacle - orig_obstacle

    # 归一化
    valid_dist = cm.distance_map[cm.grid == 1]
    valid_cost = cm.cost_map[cm.grid == 1]
    d_vmax = float(np.percentile(valid_dist, 99)) if len(valid_dist) > 0 else 1.0
    c_vmin = float(valid_cost.min()) if len(valid_cost) > 0 else 0.0
    c_vmax = float(np.percentile(valid_cost, 99)) if len(valid_cost) > 0 else 10.0

    # (1) Distance map
    dist_masked = np.ma.masked_where(cm.grid != 1, cm.distance_map)
    im1 = axes[0].imshow(dist_masked, origin='lower', extent=extent,
                        cmap='coolwarm', aspect='equal', vmin=0.0, vmax=d_vmax)
    plt.colorbar(im1, ax=axes[0], label='Distance to obstacle (m)')
    axes[0].set_title(f'Distance to Obstacle (m)\nσ={sigma}m', fontsize=14)
    axes[0].set_xlabel('X (m)')
    axes[0].set_ylabel(h_label)
    axes[0].grid(True, alpha=0.2, linestyle='--')

    # (2) Cost map
    cost_masked = np.ma.masked_where(cm.grid != 1, cm.cost_map)
    im2 = axes[1].imshow(cost_masked, origin='lower', extent=extent,
                        cmap='hot_r', aspect='equal', vmin=c_vmin, vmax=c_vmax)
    plt.colorbar(im2, ax=axes[1], label='Navigation cost')
    axes[1].set_title(f'Navigation Cost Map (vmin={c_vmin:.2f}, vmax={c_vmax:.2f})\nweight={weight}', fontsize=14)
    axes[1].set_xlabel('X (m)')
    axes[1].set_ylabel(h_label)
    axes[1].grid(True, alpha=0.2, linestyle='--')

    # (3) Grid with completed walls
    vis = np.zeros((cm.height, cm.width, 3), dtype=np.uint8)
    vis[cm.grid == 1] = [0, 255, 0]
    vis[cm.grid == 100] = [255, 0, 0]
    vis[cm.grid == 0] = [50, 50, 50]
    axes[2].imshow(vis, origin='lower', extent=extent, aspect='equal', alpha=0.8)

    added_wall_mask = (cm.grid == 100) & (grid_data['grid'] != 100)
    vis_highlight = vis.copy()
    vis_highlight[added_wall_mask] = [255, 165, 0]
    axes[2].imshow(vis_highlight, origin='lower', extent=extent, aspect='equal', alpha=0.7)

    legend_elements = [
        Patch(facecolor='green', label='Walkable'),
        Patch(facecolor='red', label=f'Obstacle ({new_obstacle:,})'),
        Patch(facecolor='orange', label=f'Added walls (+{added:,})'),
        Patch(facecolor='#333333', label='Unknown'),
    ]
    axes[2].legend(handles=legend_elements, loc='upper right', fontsize=9)
    axes[2].set_title(f'Grid Map with Completed Boundary Walls\n+{added:,} wall cells', fontsize=14)
    axes[2].set_xlabel('X (m)')
    axes[2].set_ylabel(h_label)
    axes[2].grid(True, alpha=0.2, linestyle='--')

    plt.tight_layout()
    plt.savefig(output_dir / '06_cost_map.png', dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  [2D] 06_cost_map.png (wall +{added:,})")
    return cm


def viz_07_path_on_grid(grid_data, path_data, gateways=None, output_dir=None, title_suffix="", completed_grid=None, up_axis='y'):
    """路径 + 起点 + 终点 + gateway"""
    grid = completed_grid if completed_grid is not None else grid_data['grid']
    resolution = grid_data['resolution']
    x_min = grid_data['x_min']
    h_min = grid_data.get('h_min', grid_data.get('z_min', 0))
    height, width = grid.shape
    x_max = x_min + width * resolution
    h_max = h_min + height * resolution
    extent = [x_min, x_max, h_min, h_max]

    if up_axis == 'z':
        h_label = 'Y (m)'
    else:
        h_label = 'Z (m)'

    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    vis_grid = np.zeros((height, width, 3), dtype=np.uint8)
    vis_grid[grid == 1] = [200, 230, 200]
    vis_grid[grid == 100] = [80, 80, 80]
    vis_grid[grid == 0] = [220, 220, 220]
    ax.imshow(vis_grid, origin='lower', extent=extent, aspect='equal', alpha=0.6)

    if path_data and path_data.get('success'):
        path = np.array(path_data['low_level_path'])
        waypoints = np.array(path_data.get('waypoints', []))

        # 根据 up_axis 选择坐标轴
        if up_axis == 'z':
            path_x, path_h = path[:, 0], path[:, 1]
            gw_x, gw_h = waypoints[:, 0], waypoints[:, 1]
        else:
            path_x, path_h = path[:, 0], path[:, 2]
            gw_x, gw_h = waypoints[:, 0], waypoints[:, 2]

        # 路径线
        ax.plot(path_x, path_h, 'r-', linewidth=3, alpha=0.9, zorder=5)
        ax.scatter(path_x, path_h, c='red', s=8, alpha=0.4, zorder=4)

        # 起点
        ax.scatter(path_x[0], path_h[0], c='green', s=300, zorder=10,
                  edgecolors='darkgreen', linewidths=3)
        ax.annotate('START', (path_x[0], path_h[0]),
                   fontsize=10, fontweight='bold', color='white',
                   ha='center', va='center', zorder=11,
                   bbox=dict(boxstyle='circle,pad=0.3', facecolor='green', alpha=0.8))

        # 终点
        ax.scatter(path_x[-1], path_h[-1], c='blue', s=300, zorder=10,
                  edgecolors='darkblue', linewidths=3)
        ax.annotate('GOAL', (path_x[-1], path_h[-1]),
                   fontsize=10, fontweight='bold', color='white',
                   ha='center', va='center', zorder=11,
                   bbox=dict(boxstyle='circle,pad=0.3', facecolor='blue', alpha=0.8))

        # Gateway
        if len(waypoints) > 2:
            gw_pts_x = gw_x[1:-1]
            gw_pts_h = gw_h[1:-1]
            ax.scatter(gw_pts_x, gw_pts_h, c='yellow', s=200, zorder=9,
                      edgecolors='orange', linewidths=2, marker='D')

        dist = path_data.get('total_distance', 0)
        pts = path_data.get('num_path_points', 0)
        gw_seq = path_data.get('gateway_sequence', [])
        title = f"Path: {dist:.1f}m, {pts} pts"
        if gw_seq:
            title += f", {len(gw_seq)} gateways"
        if title_suffix:
            title += f" {title_suffix}"
        ax.set_title(title, fontsize=14, fontweight='bold')
    else:
        ax.set_title(f"No Path Data{title_suffix}", fontsize=14, fontweight='bold')

    ax.set_xlabel('X (m)', fontsize=12)
    ax.set_ylabel(h_label, fontsize=12)
    ax.grid(True, alpha=0.2, linestyle='--')

    # 比例尺
    scale_bar = 5.0
    sx = x_min + 0.05 * (x_max - x_min)
    sh = h_min + 0.08 * (h_max - h_min)
    ax.plot([sx, sx + scale_bar], [sh, sh], 'k-', linewidth=3, zorder=5)
    ax.text(sx + scale_bar/2, sh - 0.3, f'{scale_bar}m', ha='center', va='top',
           fontsize=10, fontweight='bold', zorder=6)

    plt.tight_layout()
    if output_dir:
        plt.savefig(output_dir / '07_path_on_grid.png', dpi=150, bbox_inches='tight')
        plt.close()
        print("  [2D] 07_path_on_grid.png")
    return fig, ax


def viz_08_path_on_cost(grid_data, path_data, cost_map, output_dir, completed_grid=None, up_axis='y'):
    """路径"""
    grid = completed_grid if completed_grid is not None else grid_data['grid']
    extent = [grid_data['x_min'], grid_data['x_min'] + grid_data['width'] * grid_data['resolution'],
              grid_data.get('h_min', grid_data.get('z_min', 0)),
              grid_data.get('h_min', grid_data.get('z_min', 0)) + grid_data['height'] * grid_data['resolution']]

    if up_axis == 'z':
        h_label = 'Y (m)'
    else:
        h_label = 'Z (m)'

    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    valid_cost = cost_map.cost_map[cost_map.grid == 1]
    c_vmin = float(valid_cost.min()) if len(valid_cost) > 0 else 0.0
    c_vmax = float(np.percentile(valid_cost, 99)) if len(valid_cost) > 0 else 10.0

    cost_masked = np.ma.masked_where(cost_map.grid != 1, cost_map.cost_map)
    im = ax.imshow(cost_masked, origin='lower', extent=extent,
                  cmap='hot_r', aspect='equal', alpha=0.7, vmin=c_vmin, vmax=c_vmax)
    plt.colorbar(im, ax=ax, label='Navigation cost')

    if path_data and path_data.get('success'):
        path = np.array(path_data['low_level_path'])

        # 根据 up_axis 选择坐标轴
        if up_axis == 'z':
            path_x, path_h = path[:, 0], path[:, 1]
        else:
            path_x, path_h = path[:, 0], path[:, 2]

        ax.plot(path_x, path_h, 'w-', linewidth=3, alpha=0.9, zorder=5)
        ax.scatter(path_x, path_h, c='white', s=10, alpha=0.5, zorder=4)

        ax.scatter(path_x[0], path_h[0], c='green', s=300, zorder=10,
                  edgecolors='darkgreen', linewidths=3)
        ax.annotate('START', (path_x[0], path_h[0]),
                   fontsize=10, fontweight='bold', color='white',
                   ha='center', va='center', zorder=11,
                   bbox=dict(boxstyle='circle,pad=0.3', facecolor='green', alpha=0.8))

        ax.scatter(path_x[-1], path_h[-1], c='blue', s=300, zorder=10,
                  edgecolors='darkblue', linewidths=3)
        ax.annotate('GOAL', (path_x[-1], path_h[-1]),
                   fontsize=10, fontweight='bold', color='white',
                   ha='center', va='center', zorder=11,
                   bbox=dict(boxstyle='circle,pad=0.3', facecolor='blue', alpha=0.8))

    dist = path_data.get('total_distance', 0) if path_data else 0
    ax.set_title(f'Path on Cost Map ({dist:.1f}m)', fontsize=14, fontweight='bold')
    ax.set_xlabel('X (m)', fontsize=12)
    ax.set_ylabel(h_label, fontsize=12)
    ax.grid(True, alpha=0.2, linestyle='--')

    plt.tight_layout()
    plt.savefig(output_dir / '08_path_on_cost.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("  [2D] 08_path_on_cost.png")


def viz_09_path_comparison(grid_data, path_files, output_dir, cost_map=None, completed_grid=None, up_axis='y'):
    """多路径对比"""
    grid = completed_grid if completed_grid is not None else grid_data['grid']
    extent = [grid_data['x_min'], grid_data['x_min'] + grid_data['width'] * grid_data['resolution'],
              grid_data.get('h_min', grid_data.get('z_min', 0)),
              grid_data.get('h_min', grid_data.get('z_min', 0)) + grid_data['height'] * grid_data['resolution']]

    if up_axis == 'z':
        h_label = 'Y (m)'
    else:
        h_label = 'Z (m)'

    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    # 背景
    vis_grid = np.zeros((grid_data['height'], grid_data['width'], 3), dtype=np.uint8)
    vis_grid[grid == 1] = [200, 230, 200]
    vis_grid[grid == 100] = [80, 80, 80]
    vis_grid[grid == 0] = [220, 220, 220]
    ax.imshow(vis_grid, origin='lower', extent=extent, aspect='equal', alpha=0.5)

    colors = ['red', 'blue', 'green', 'purple', 'orange', 'cyan', 'magenta']
    for idx, (label, path_file) in enumerate(path_files.items()):
        if not Path(path_file).exists():
            continue
        with open(path_file, 'r') as f:
            pd = json.load(f)
        if not pd.get('success'):
            continue

        path = np.array(pd['low_level_path'])
        color = colors[idx % len(colors)]
        dist = pd.get('total_distance', 0)

        # 根据 up_axis 选择坐标轴
        if up_axis == 'z':
            path_x, path_h = path[:, 0], path[:, 1]
        else:
            path_x, path_h = path[:, 0], path[:, 2]

        ax.plot(path_x, path_h, color=color, linewidth=2.5, alpha=0.8,
               zorder=5, label=f'{label}: {dist:.1f}m')

        if idx == 0:
            ax.scatter(path_x[0], path_h[0], c='green', s=300, zorder=10,
                      edgecolors='darkgreen', linewidths=3)
            ax.annotate('START', (path_x[0], path_h[0]),
                       fontsize=10, fontweight='bold', color='white',
                       ha='center', va='center', zorder=11,
                       bbox=dict(boxstyle='circle,pad=0.3', facecolor='green', alpha=0.8))
            ax.scatter(path_x[-1], path_h[-1], c='blue', s=300, zorder=10,
                      edgecolors='darkblue', linewidths=3)
            ax.annotate('GOAL', (path_x[-1], path_h[-1]),
                       fontsize=10, fontweight='bold', color='white',
                       ha='center', va='center', zorder=11,
                       bbox=dict(boxstyle='circle,pad=0.3', facecolor='blue', alpha=0.8))

    ax.legend(loc='upper right', fontsize=11, framealpha=0.9)
    ax.set_title('Path Comparison', fontsize=14, fontweight='bold')
    ax.set_xlabel('X (m)', fontsize=12)
    ax.set_ylabel(h_label, fontsize=12)
    ax.grid(True, alpha=0.2, linestyle='--')

    scale_bar = 5.0
    sx = extent[0] + 0.05 * (extent[1] - extent[0])
    sh = extent[3] + 0.08 * (extent[2] - extent[3])
    ax.plot([sx, sx + scale_bar], [sh, sh], 'k-', linewidth=3, zorder=5)
    ax.text(sx + scale_bar/2, sh - 0.3, f'{scale_bar}m', ha='center', va='top',
           fontsize=10, fontweight='bold', zorder=6)

    plt.tight_layout()
    plt.savefig(output_dir / '09_path_comparison.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("  [2D] 09_path_comparison.png")


# ============================================================
# 导出3D点云
# ============================================================

def export_ply_points(points, colors, output_path):
    if len(points) == 0:
        return
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(np.array(points))
    pcd.colors = o3d.utility.Vector3dVector(np.array(colors))
    o3d.io.write_point_cloud(str(output_path), pcd)
    print(f"  [3D] {output_path.name} ({len(points)} pts)")


def export_10_global(global_pcd_path, output_dir):
    """全局点云"""
    if not global_pcd_path or not Path(global_pcd_path).exists():
        return
    pcd = o3d.io.read_point_cloud(str(global_pcd_path))
    points = np.asarray(pcd.points)

    orig_colors = np.asarray(pcd.colors)
    if orig_colors is None or len(orig_colors) == 0 or orig_colors.shape[0] != len(points):
        colors = np.ones_like(points) * 0.5  # 灰色
    else:
        colors = orig_colors

    pcd.colors = o3d.utility.Vector3dVector(colors)
    o3d.io.write_point_cloud(str(output_dir / '10_global_pointcloud.ply'), pcd)
    print(f"  [3D] 10_global_pointcloud.ply ({len(points):,} pts)")


def export_11_path_line(path_data, output_dir):
    """路径线 + 插值点"""
    if not path_data or not path_data.get('success'):
        return
    path_points = path_data['low_level_path']
    cloud = []
    colors = []
    for pt in path_points:
        cloud.append(pt)
        colors.append([1.0, 0.0, 0.0])
    # 段间插值
    for i in range(len(path_points) - 1):
        p1, p2 = np.array(path_points[i]), np.array(path_points[i+1])
        dist = np.linalg.norm(p2 - p1)
        n = max(int(dist / 0.05), 1)
        for t in np.linspace(0, 1, n):
            cloud.append(((1-t)*p1 + t*p2).tolist())
            colors.append([1.0, 0.0, 0.0])
    export_ply_points(cloud, colors, output_dir / '11_path_line.ply')


def export_12_start(path_data, output_dir):
    """起点"""
    if not path_data or not path_data.get('success'):
        return
    start = path_data['waypoints'][0]
    n = 200
    pts = start + np.random.normal(0, 0.08, (n, 3))
    colors = [[0.0, 1.0, 0.0]] * n
    export_ply_points(pts, colors, output_dir / '12_start.ply')


def export_13_target(path_data, output_dir):
    """目标"""
    if not path_data or not path_data.get('success'):
        return
    target = path_data['waypoints'][-1]
    n = 200
    pts = target + np.random.normal(0, 0.08, (n, 3))
    colors = [[0.0, 0.0, 1.0]] * n
    export_ply_points(pts, colors, output_dir / '13_target.ply')


def export_14_waypoints(path_data, output_dir):
    """Gateway 中间点"""
    if not path_data or not path_data.get('success'):
        return
    waypoints = path_data['waypoints']
    if len(waypoints) <= 2:
        return
    mid = waypoints[1:-1]
    cloud = []
    colors = []
    for wp in mid:
        wp_arr = np.array(wp) if not isinstance(wp, np.ndarray) else wp
        for _ in range(100):
            cloud.append((wp_arr + np.random.normal(0, 0.08, 3)).tolist())
            colors.append([1.0, 1.0, 0.0])
    export_ply_points(cloud, colors, output_dir / '14_waypoints.ply')


# ============================================================
# 主流程
# ============================================================

def run_all_visualization(
    pointcloud_path=None,
    grid_map_path=None,
    path_result_path=None,
    compare_paths=None,   # {label: path_file}
    gateways_path=None,
    global_pcd_path=None,
    output_dir=None,
    floor_y_threshold=0.6,
    cost_sigma=0.5,
    cost_weight=5.0,
    complete_wall=True,
    config=None,
):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    cfg = config or load_config()

    print(f"\n输出目录: {output_dir}")
    print("=" * 60)

    print("\n[1/3] 加载数据...")
    points = None
    floor_2d = floor_3d = obstacle_2d = obstacle_y_spans = None
    up_axis = 'y'  # 默认 Y-up

    if pointcloud_path and Path(pointcloud_path).exists():
        print(f"  加载点云: {pointcloud_path}")
        points = load_pointcloud(pointcloud_path)
        print(f"  总点数: {len(points):,}")

        # 检测垂直轴
        up_axis = _detect_up_axis(pointcloud_path)
        print(f"  垂直轴: {up_axis.upper()}-up")

        floor_2d, floor_3d, obstacle_2d, obstacle_y_spans, _ = \
            extract_floor_and_obstacles(points, floor_y_threshold=floor_y_threshold, up_axis=up_axis, config=cfg)
        print(f"  Floor 点: {len(floor_2d):,}, Obstacle 单元: {len(obstacle_2d):,}")

    grid_data = None
    if points is not None and len(points) > 0:
        # 从点云实时生成栅格地图（使用最新参数）
        print("  从点云实时生成栅格地图...")
        from navigation.grid_map import GridMap

        gm_cfg = cfg.get('grid_map', {})
        resolution = gm_cfg.get('resolution', 0.05)

        # 创建 GridMap 对象
        grid_map_obj = GridMap(floor_2d, obstacle_2d, resolution=resolution, up_axis=up_axis, config=cfg)

        # 膨胀障碍物
        print("  膨胀障碍物...")
        obstacle_mask = (grid_map_obj.grid == 100).astype(np.uint8)
        dil_kernel = gm_cfg.get('floor_dilation_kernel', 3)
        dil_iters = gm_cfg.get('floor_dilation_iterations', 3)
        kernel = np.ones((dil_kernel, dil_kernel), dtype=np.uint8)
        from scipy.ndimage import binary_dilation
        dilated = binary_dilation(obstacle_mask, structure=kernel, iterations=dil_iters)
        # Floor 保护：膨胀后的障碍物不覆盖已有的 floor
        floor_mask = (grid_map_obj.grid == 1).astype(bool)
        grid_map_obj.grid[dilated & ~floor_mask] = 100

        # 查找连通组件
        print("  查找连通组件...")
        components = grid_map_obj.find_connected_components(min_points=100)
        print(f"  找到 {len(components)} 个连通组件")

        # 构造 grid_data（与 pkl 格式一致）
        grid_data = {
            'grid': grid_map_obj.get_grid(),
            'x_min': grid_map_obj.x_min,
            'h_min': grid_map_obj.h_min,
            'resolution': grid_map_obj.resolution,
            'padding': grid_map_obj.padding,
            'floor_y': floor_y_threshold,
            'width': grid_map_obj.width,
            'height': grid_map_obj.height,
            'connected_components': grid_map_obj.connected_components,
            'component_gateways': grid_map_obj.component_gateways,
            'doors': grid_map_obj.doors,
            'up_axis': up_axis,
        }
        print(f"  栅格：{grid_data['grid'].shape}, floor={np.sum(grid_data['grid']==1):,}, obstacle={np.sum(grid_data['grid']==100):,}")
    elif grid_map_path and Path(grid_map_path).exists():
        print(f"  加载栅格地图：{grid_map_path}")
        grid_data = load_grid_map(grid_map_path)
        print(f"  栅格：{grid_data['grid'].shape}, floor={np.sum(grid_data['grid']==1):,}")

    path_data = None
    if path_result_path and Path(path_result_path).exists():
        print(f"  加载路径: {path_result_path}")
        path_data = load_path(path_result_path)
        if path_data:
            print(f"  路径: {path_data.get('total_distance', 0):.1f}m, "
                  f"{path_data.get('num_path_points', 0)} pts")

    gateways = None
    if gateways_path and Path(gateways_path).exists():
        print(f"  加载 gateway: {gateways_path}")
        with open(gateways_path, 'rb') as f:
            gateways = pickle.load(f).get('gateways', [])
        print(f"  Gateway: {len(gateways)}")

    print("\n[2/3] 生成 2D 可视化...")

    if floor_2d is not None and len(floor_2d) > 0:
        viz_01_floor_xz(floor_2d, floor_3d, output_dir, up_axis=up_axis)
        viz_02_obstacle_xz(obstacle_2d, obstacle_y_spans, output_dir, up_axis=up_axis)
        viz_03_combined(floor_2d, obstacle_2d, output_dir, up_axis=up_axis)

    if grid_data is not None:
        # 创建 CostMap 获取补全后的 grid
        print("  计算 Cost Map (含 wall 补全)...")
        cm = CostMap(
            grid=grid_data['grid'],
            resolution=grid_data['resolution'],
            x_min=grid_data['x_min'],
            h_min=grid_data.get('h_min', grid_data.get('z_min', 0)),
            sigma=cost_sigma,
            distance_weight=cost_weight,
            complete_boundary_wall=complete_wall
        )
        completed_grid = cm.grid.copy()
        added_walls = np.sum(completed_grid == 100) - np.sum(grid_data['grid'] == 100)
        print(f"  Wall 补全: +{added_walls:,} 障碍单元格")

        viz_04_grid_map(grid_data, output_dir, completed_grid=completed_grid, up_axis=up_axis)
        viz_05_floor_components(grid_data, output_dir, completed_grid=completed_grid, up_axis=up_axis, config=cfg)
        viz_06_cost_map(grid_data, output_dir,
                       complete_wall=complete_wall,
                       sigma=cost_sigma, weight=cost_weight, up_axis=up_axis)

        if path_data:
            viz_07_path_on_grid(grid_data, path_data, gateways, output_dir,
                              completed_grid=completed_grid, up_axis=up_axis)
            viz_08_path_on_cost(grid_data, path_data, cm, output_dir,
                              completed_grid=completed_grid, up_axis=up_axis)
        else:
            viz_07_path_on_grid(grid_data, None, gateways, output_dir,
                              completed_grid=completed_grid, up_axis=up_axis)

        if compare_paths:
            viz_09_path_comparison(grid_data, compare_paths, output_dir, cm,
                                  completed_grid=completed_grid, up_axis=up_axis)

    print("\n[3/3] 生成 3D PLY...")

    if global_pcd_path:
        export_10_global(global_pcd_path, output_dir)

    if path_data:
        export_11_path_line(path_data, output_dir)
        export_12_start(path_data, output_dir)
        export_13_target(path_data, output_dir)
        export_14_waypoints(path_data, output_dir)

    png_count = len(list(output_dir.glob('*.png')))
    ply_count = len(list(output_dir.glob('*.ply')))
    print(f"\n{'=' * 60}")
    print(f"完成! 共生成 {png_count} 张 2D 图片 + {ply_count} 个 3D PLY 文件")
    print(f"输出目录: {output_dir}")
    print(f"  2D 图片: {' '.join(sorted([f.name for f in output_dir.glob('*.png')]))}")
    print(f"  3D 文件: {' '.join(sorted([f.name for f in output_dir.glob('*.ply')]))}")
    print(f"{'=' * 60}")


def main():
    import argparse
    import yaml

    parser = argparse.ArgumentParser(description='统一场景可视化 (2D + 3D)')

    # 数据
    parser.add_argument('--pointcloud', type=str, default=None,
                       help='全局点云 PLY (用于 floor/obstacle 提取)')
    parser.add_argument('--grid-map', type=str, default=None,
                       help='栅格地图 PKL')
    parser.add_argument('--path', type=str, default=None,
                       help='路径结果 JSON')
    parser.add_argument('--gateways', type=str, default=None,
                       help='Gateway 数据 PKL (可选)')
    parser.add_argument('--global-pcd', type=str, default=None,
                       help='全局点云 PLY (用于 3D 输出)')

    parser.add_argument('--compare', type=str, nargs='*',
                       help='对比路径: label:path_file ...')

    # Cost map 参数
    parser.add_argument('--cost-sigma', type=float, default=0.5, help='Cost Map sigma')
    parser.add_argument('--cost-weight', type=float, default=5.0, help='Cost Map weight')
    parser.add_argument('--floor-y-threshold', type=float, default=None,
                       help='Floor 检测 Y 高度阈值 (米)，默认从 config.yaml 读取 (推荐 0.2-0.5m)')
    parser.add_argument('--no-boundary-wall', action='store_true', help='不补全外围 wall')

    # 输出
    parser.add_argument('--output', type=str, default='navigation/viz_all',
                       help='输出目录')

    args = parser.parse_args()

    base = project_root

    if args.floor_y_threshold is None:
        config_path = base / 'config.yaml'
        if config_path.exists():
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
            args.floor_y_threshold = config.get('reconstruction', {}).get('floor_y_threshold', 0.6)
        else:
            args.floor_y_threshold = 0.6
        print(f"  使用 floor_y_threshold: {args.floor_y_threshold}m")

    if args.pointcloud is None:
        pc = base / 'unified_output' / 'global' / 'global_pointcloud.ply'
        args.pointcloud = str(pc) if pc.exists() else None

    if args.grid_map is None:
        gm = base / 'unified_output' / 'navigation' / 'grid_map_floor.pkl'
        args.grid_map = str(gm) if gm.exists() else None

    if args.path is None:
        p = base / 'navigation' / 'path_result.json'
        args.path = str(p) if p.exists() else None

    if args.gateways is None:
        gw = base / 'navigation' / 'gateway_viz' / 'gateways.pkl'
        args.gateways = str(gw) if gw.exists() else None

    if args.global_pcd is None:
        gpc = base / 'unified_output' / 'global' / 'global_pointcloud.ply'
        args.global_pcd = str(gpc) if gpc.exists() else None

    compare_paths = None
    if args.compare:
        compare_paths = {}
        for item in args.compare:
            if ':' in item:
                label, path_file = item.split(':', 1)
                compare_paths[label] = str(base / path_file)
            else:
                compare_paths[item] = str(base / item)

    run_all_visualization(
        pointcloud_path=args.pointcloud,
        grid_map_path=args.grid_map,
        path_result_path=args.path,
        compare_paths=compare_paths,
        gateways_path=args.gateways,
        global_pcd_path=args.global_pcd,
        output_dir=base / args.output,
        floor_y_threshold=args.floor_y_threshold,
        cost_sigma=args.cost_sigma,
        cost_weight=args.cost_weight,
        complete_wall=not args.no_boundary_wall,
    )


if __name__ == '__main__':
    main()
