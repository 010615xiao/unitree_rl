#!/usr/bin/env python3
"""
栅格 A* 路径规划算法
"""

import numpy as np
import heapq
from typing import Optional

from .config_loader import load_config


class AStarPlanner:
    def __init__(self, grid_map, cost_map=None, config=None):
        """
        Args:
            grid_map: GridMap 对象
            cost_map: CostMap 对象
            config: 配置字典 (可选)
        """
        self.grid_map = grid_map
        self.grid = grid_map.get_grid()
        self.height, self.width = self.grid.shape
        self.directions = [
            (0, 1), (0, -1), (1, 0), (-1, 0),
            (1, 1), (1, -1), (-1, 1), (-1, -1)
        ]
        self.diag_cost = np.sqrt(2)
        self.cost_map = cost_map
        self.use_cost_map = cost_map is not None
        self._config = config or load_config()
        self._pp_cfg = self._config.get('path_planner', {})

        # 计算 heuristic 缩放因子：使用 cost_map 的最小代价
        # 这样 heuristic 与 g_score 在同一量级
        if self.use_cost_map:
            self.heuristic_scale = cost_map.base_cost
        else:
            self.heuristic_scale = 1.0

    def heuristic(self, a, b):
        dx = abs(a[0] - b[0])
        dy = abs(a[1] - b[1])
        chebyshev = max(dx, dy) + (self.diag_cost - 1) * min(dx, dy)
        return chebyshev * self.heuristic_scale

    def is_valid(self, x, y):
        return (0 <= x < self.width and
                0 <= y < self.height and
                self.grid[y, x] == 1)

    def plan(self, start_world, goal_world):
        # 接收 2D 坐标 [X, Z] 或 [X, Y]，直接映射到栅格
        start = self.grid_map._world_to_grid(start_world[0], start_world[1])
        goal = self.grid_map._world_to_grid(goal_world[0], goal_world[1])

        if not self.is_valid(*start):
            start = self._find_nearest_walkable(*start)
            if start is None:
                return None

        if not self.is_valid(*goal):
            goal = self._find_nearest_walkable(*goal)
            if goal is None:
                return None

        open_set = [(0, start)]
        came_from = {}
        g_score = {start: 0}
        f_score = {start: self.heuristic(start, goal)}
        closed_set = set()

        while open_set:
            current_f, current = heapq.heappop(open_set)

            if current == goal:
                path_grid = self._reconstruct_path(came_from, current)
                raw_path = self._grid_to_world_path(path_grid)
                return raw_path

            if current in closed_set:
                continue
            closed_set.add(current)

            for dx, dy in self.directions:
                neighbor = (current[0] + dx, current[1] + dy)

                if neighbor in closed_set or not self.is_valid(*neighbor):
                    continue

                # 计算移动代价
                is_diagonal = (dx != 0 and dy != 0)
                if self.use_cost_map:
                    # 使用 cost map: 结合距离和安全性
                    move_cost = self.cost_map.get_cost_between_cells(
                        current[1], current[0], neighbor[1], neighbor[0]
                    )
                else:
                    # 传统 A*: 均匀代价
                    move_cost = self.diag_cost if is_diagonal else 1.0

                tentative_g = g_score[current] + move_cost

                if tentative_g < g_score.get(neighbor, float('inf')):
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + self.heuristic(neighbor, goal)
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))

        return None

    def _find_nearest_walkable(self, gx, gy, max_dist=None):
        if max_dist is None:
            max_dist = self._pp_cfg.get('max_dist_nearest_walkable', 100)
        for dist in range(1, max_dist):
            for dx in range(-dist, dist + 1):
                for dy in range(-dist, dist + 1):
                    if abs(dx) != dist and abs(dy) != dist:
                        continue
                    nx, ny = gx + dx, gy + dy
                    if self.is_valid(nx, ny):
                        return (nx, ny)
        return None

    def _reconstruct_path(self, came_from, current):
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        path.reverse()
        return path

    def _grid_to_world_path(self, path_grid):
        # 根据 up_axis 返回正确的 3D 坐标格式
        # Z-up: [X, Y, 0.0], Y-up: [X, 0.0, Z]
        up_axis = getattr(self.grid_map, 'up_axis', 'y')
        if up_axis == 'z':
            return [[x, h, 0.0] for x, h in [self.grid_map._grid_to_world(gx, gy) for gx, gy in path_grid]]
        else:
            return [[x, 0.0, h] for x, h in [self.grid_map._grid_to_world(gx, gy) for gx, gy in path_grid]]

    def smooth_path(self, path, max_iterations=None, safety_margin=None):
        """
        平滑路径，带安全约束

        Args:
            path: 原始路径点列表
            max_iterations: 最大迭代次数
            safety_margin: 到障碍物的最小安全距离 (像素数)
        """
        if len(path) < 3:
            return path

        smoothed = np.array(path, dtype=np.float32)
        original = smoothed.copy()
        alpha = self._pp_cfg.get('smoothing_alpha', 0.3)
        beta = self._pp_cfg.get('smoothing_beta', 0.3)
        if max_iterations is None:
            max_iterations = self._pp_cfg.get('smoothing_max_iterations', 100)
        if safety_margin is None:
            safety_margin = self._pp_cfg.get('smoothing_safety_margin', 2.0)

        # cost map 做安全约束
        use_safety = self.use_cost_map and self.cost_map is not None

        if use_safety:
            safety_pixels = safety_margin

        for iteration in range(max_iterations):
            new_smoothed = smoothed.copy()
            max_change = 0
            for i in range(1, len(smoothed) - 1):
                data_term = alpha * (original[i] - smoothed[i])
                smooth_term = beta * (smoothed[i-1] + smoothed[i+1] - 2 * smoothed[i])
                candidate = smoothed[i] + data_term + smooth_term
                
                if use_safety:
                    gx, gz = self.grid_map.world_to_grid(candidate[0], candidate[1])
                    if 0 <= gz < self.cost_map.height and 0 <= gx < self.cost_map.width:
                        # 检查候选点是否在障碍物上
                        if self.grid[gz, gx] != 1:
                            candidate = smoothed[i]
                            # 如果当前点也在障碍物上，尝试拉回原始点
                            cx, cz = self.grid_map.world_to_grid(smoothed[i][0], smoothed[i][1])
                            if 0 <= cz < self.height and 0 <= cx < self.width and self.grid[cz, cx] != 1:
                                candidate = original[i]
                        else:
                            dist = self.cost_map.get_distance(gz, gx)
                            if dist < safety_pixels * self.cost_map.resolution:
                                candidate = smoothed[i]
                
                new_smoothed[i] = candidate
                max_change = max(max_change, np.max(np.abs(candidate - smoothed[i])))
            smoothed = new_smoothed
            if max_change < 0.001:
                break

        return smoothed.tolist()


def rdp_simplify(path, epsilon=None, config=None):
    if epsilon is None:
        cfg = config or load_config()
        epsilon = cfg.get('path_planner', {}).get('rdp_epsilon', 0.1)
    if len(path) < 3:
        return path.tolist() if hasattr(path, 'tolist') else path
    
    start = path[0]
    end = path[-1]
    
    line_vec = end - start
    line_len = np.linalg.norm(line_vec)
    
    if line_len < 1e-6:
        return [start.tolist(), end.tolist()] if hasattr(start, 'tolist') else [list(start), list(end)]
    
    line_unitvec = line_vec / line_len
    max_dist = 0
    max_idx = 0
    
    for i in range(1, len(path) - 1):
        pt = path[i]
        pt_vec = pt - start
        proj_len = np.dot(pt_vec, line_unitvec)
        
        if 0 <= proj_len <= line_len:
            proj_pt = start + proj_len * line_unitvec
            dist = np.linalg.norm(pt - proj_pt)
        else:
            dist = min(np.linalg.norm(pt - start), np.linalg.norm(pt - end))
        
        if dist > max_dist:
            max_dist = dist
            max_idx = i
    
    if max_dist > epsilon:
        left = rdp_simplify(path[:max_idx+1], epsilon)
        right = rdp_simplify(path[max_idx:], epsilon)
        return left[:-1] + right
    else:
        return [start.tolist(), end.tolist()] if hasattr(start, 'tolist') else [list(start), list(end)]
