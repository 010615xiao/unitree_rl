#!/usr/bin/env python3
"""
在 MoGe2 构建的 3D 点云中可视化 RoboBrain 预测的轨迹
- 使用 MoGe2 生成场景 3D 点云
- 使用 RoboBrain 预测从起点到目标点的 3D 轨迹
- 在点云中可视化轨迹（使用 matplotlib）
- 输出点云文件（PLY 格式）和轨迹数据（JSON 格式）
"""

import sys
import os
import cv2
import numpy as np
import torch

# 添加 MoGe 路径
sys.path.insert(0, "/workspace/wxd/Agent/Spagent/spagent/checkpoints/moge2/MoGe")

# 配置
IMAGE_PATH = "/workspace/wxd/Agent/images/test_navigation_2.png"
TARGET_OBJECT = "water dispenser"
GDINO_CKPT = "/workspace/wxd/Agent/Spagent/spagent/checkpoints/grounding_dino/groundingdino_swinb_cogcoor.pth"
GDINO_CONFIG = "/workspace/wxd/Agent/Spagent/spagent/spagent/external_experts/GroundingDINO/configs/GroundingDINO_SwinB_cfg.py"
MOGE2_CKPT = "/workspace/wxd/Agent/Spagent/spagent/checkpoints/moge2/moge-2-vitl-normal/model.pt"

# 检测阈值
BOX_THRESHOLD = 0.35
TEXT_THRESHOLD = 0.25

# Start point 配置 (2D 坐标固定)
START_POINT_2D = (451, 468)  # (x, y)

# 输出目录配置
OUTPUT_BASE_DIR = "/workspace/wxd/Agent/images"
OUTPUT_DIR = os.path.join(OUTPUT_BASE_DIR, "3d_trajectory_results")


def load_gdino_model():
    """加载 GroundingDINO 模型"""
    from groundingdino.util.inference import load_model
    print("🔄 加载 GroundingDINO 模型...")
    model = load_model(GDINO_CONFIG, GDINO_CKPT)
    print("✅ GroundingDINO 模型已加载")
    return model


def load_moge2_model(device):
    """加载 MoGe2 模型"""
    from moge.model.v2 import MoGeModel
    print("🔄 加载 MoGe2 模型...")
    model = MoGeModel.from_pretrained(MOGE2_CKPT).to(device)
    model.eval()
    print("✅ MoGe2 模型已加载")
    return model


def detect_with_gdino(model, image_path, target_object):
    """使用 GroundingDINO 检测目标物体"""
    from groundingdino.util.inference import load_image, predict
    from torchvision.ops import box_convert
    
    print(f"🔍 检测目标：{target_object}")
    
    image_source, image = load_image(image_path)
    h, w, _ = image_source.shape
    
    boxes, logits, phrases = predict(
        model=model,
        image=image,
        caption=target_object,
        box_threshold=BOX_THRESHOLD,
        text_threshold=TEXT_THRESHOLD
    )
    
    if len(boxes) == 0:
        print("⚠️ 未检测到目标物体")
        return []
    
    # 转换为绝对坐标 (xyxy 格式)
    boxes_abs = boxes * torch.Tensor([w, h, w, h])
    boxes_xyxy = box_convert(boxes=boxes_abs, in_fmt="cxcywh", out_fmt="xyxy")
    
    results = []
    for box, logit, phrase in zip(boxes_xyxy, logits, phrases):
        box_list = box.tolist()
        results.append({
            "box": box_list,
            "confidence": logit.item(),
            "phrase": str(phrase)
        })
        print(f"   检测到：{phrase} (置信度：{logit.item():.3f})")
        print(f"   边界框：x1={box_list[0]:.1f}, y1={box_list[1]:.1f}, x2={box_list[2]:.1f}, y2={box_list[3]:.1f}")
    
    return results


def get_depth_and_pointcloud_from_moge2(model, image_path, device):
    """使用 MoGe2 获取深度图和点云"""
    print("🔄 生成深度图和 3D 点云...")
    
    image_bgr = cv2.imread(image_path)
    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    
    input_tensor = torch.tensor(image_rgb / 255.0, dtype=torch.float32, device=device).permute(2, 0, 1)
    
    with torch.no_grad():
        output = model.infer(input_tensor)
    
    depth_map = output["depth"].cpu().numpy()
    # points 形状：[H, W, 3]，每个点是 (X, Y, Z) 相机坐标系
    point_cloud = output["points"].cpu().numpy()
    
    print(f"✅ 深度图已生成：{w}x{h}, 深度范围 {depth_map.min():.2f}-{depth_map.max():.2f}米")
    print(f"✅ 点云已生成：{point_cloud.shape}, X 范围 [{point_cloud[:,:,0].min():.2f}, {point_cloud[:,:,0].max():.2f}]")
    
    return depth_map, point_cloud


def compute_2d5_coords(detections, depth_map, point_cloud, start_point_2d=None):
    """从 2D 边界框、深度图和点云计算 2.5D 坐标"""
    results_2d5 = {}
    
    # 计算 start point 的 2.5D 坐标
    if start_point_2d is not None:
        sx, sy = start_point_2d
        median_depth, mean_depth, std_depth = get_point_depth(depth_map, sx, sy)
        
        # 从点云获取 3D 坐标
        point_3d = get_point_from_cloud(point_cloud, sx, sy)
        
        if median_depth is not None:
            results_2d5["start_point"] = {
                "x": float(sx),
                "y": float(sy),
                "depth": median_depth,
                "point_3d": point_3d.tolist() if point_3d is not None else None,
                "depth_mean": mean_depth,
                "depth_std": std_depth,
                "type": "start_point"
            }
            
            print(f"\n📍 Start Point 2.5D 坐标:")
            print(f"   2D 坐标：({sx}, {sy})")
            print(f"   深度 (中位数): {median_depth:.3f} 米")
            if point_3d is not None:
                print(f"   3D 坐标 (相机系): ({point_3d[0]:.3f}, {point_3d[1]:.3f}, {point_3d[2]:.3f})")
            print(f"   2.5D 坐标：(x={sx}, y={sy}, d={median_depth:.3f}m)")
    
    # 计算检测目标的 2.5D 坐标（支持多个目标）
    if detections:
        results_2d5["targets"] = []
        
        print(f"\n📍 检测到 {len(detections)} 个目标物体:")
        
        for i, det in enumerate(detections):
            box = det["box"]
            x1, y1, x2, y2 = box
            
            # 计算边界框中心
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            
            # 在边界框区域内采样深度值
            x1_int, y1_int = int(x1), int(y1)
            x2_int, y2_int = int(x2), int(y2)
            x1_int = max(0, x1_int)
            y1_int = max(0, y1_int)
            x2_int = min(depth_map.shape[1], x2_int)
            y2_int = min(depth_map.shape[0], y2_int)
            
            region_depth = depth_map[y1_int:y2_int, x1_int:x2_int]
            
            if region_depth.size > 0:
                median_depth = float(np.median(region_depth))
                mean_depth = float(np.mean(region_depth))
                std_depth = float(np.std(region_depth))
                
                # 从点云获取 3D 坐标（边界框中心）
                point_3d = get_point_from_cloud(point_cloud, center_x, center_y)
                
                target_info = {
                    "id": i,
                    "x": center_x,
                    "y": center_y,
                    "depth": median_depth,
                    "point_3d": point_3d.tolist() if point_3d is not None else None,
                    "depth_mean": mean_depth,
                    "depth_std": std_depth,
                    "box": box,
                    "confidence": det["confidence"],
                    "phrase": det["phrase"],
                    "type": "target"
                }
                results_2d5["targets"].append(target_info)
                
                print(f"\n   【目标 {i+1}】{det['phrase']} (置信度：{det['confidence']:.3f})")
                print(f"      2D 中心：({center_x:.1f}, {center_y:.1f})")
                print(f"      深度 (中位数): {median_depth:.3f} 米")
                if point_3d is not None:
                    print(f"      3D 坐标 (相机系): ({point_3d[0]:.3f}, {point_3d[1]:.3f}, {point_3d[2]:.3f})")
                print(f"      2.5D 坐标：(x={center_x:.1f}, y={center_y:.1f}, d={median_depth:.3f}m)")
    
    return results_2d5


def get_point_depth(depth_map, x, y, window_size=1):
    """获取指定点的深度值"""
    x_clamped = max(0, min(int(x), depth_map.shape[1] - 1))
    y_clamped = max(0, min(int(y), depth_map.shape[0] - 1))
    
    half_window = window_size
    x1, y1 = max(0, x_clamped - half_window), max(0, y_clamped - half_window)
    x2, y2 = min(depth_map.shape[1], x_clamped + half_window + 1), min(depth_map.shape[0], y_clamped + half_window + 1)
    
    region_depth = depth_map[y1:y2, x1:x2]
    
    if region_depth.size > 0:
        median_depth = float(np.median(region_depth))
        mean_depth = float(np.mean(region_depth))
        std_depth = float(np.std(region_depth))
        return median_depth, mean_depth, std_depth
    return None, None, None


def get_point_from_cloud(point_cloud, x, y):
    """从点云获取指定 2D 坐标的 3D 点"""
    x_clamped = max(0, min(int(x), point_cloud.shape[1] - 1))
    y_clamped = max(0, min(int(y), point_cloud.shape[0] - 1))
    
    return point_cloud[y_clamped, x_clamped]


def predict_trajectory(image_path, start_point, target_point, temperature=0.1):
    """使用 RoboBrain 预测轨迹"""
    from robobrain_trajectory_2 import UnifiedInference
    
    print("\n" + "="*60)
    print("🤖 使用 RoboBrain 预测轨迹...")
    print("="*60)
    
    model = UnifiedInference(
        model_id="RoboBrain2.5-8B",
        base_url="http://localhost:8000/v1"
    )
    
    result = model.predict_trajectory(
        image_path=image_path,
        start_point=start_point,
        target_point=target_point,
        plot=False,  # 不在这里绘制，我们在 3D 点云中绘制
        temperature=temperature
    )
    
    print(f"✅ 轨迹预测完成，点数：{len(result['trajectory'])}")
    return result["trajectory"]


def visualize_trajectory_3d(point_cloud, image_path, trajectory, start_point_2d5, target_point_2d5, output_path):
    """
    在 3D 点云中可视化轨迹
    
    Args:
        point_cloud: MoGe2 生成的点云 [H, W, 3]
        image_path: 原始图像路径
        trajectory: 轨迹点列表 [(x, y, d), ...]
        start_point_2d5: 起点 2.5D 坐标
        target_point_2d5: 目标点 2.5D 坐标
        output_path: 输出 HTML 路径
    """
    try:
        import open3d as o3d
    except ImportError:
        print("❌ 需要安装 Open3D: pip install open3d")
        return None
    
    print("\n🔄 创建 3D 可视化...")
    
    # 1. 创建点云
    image_rgb = cv2.imread(image_path)
    image_rgb = cv2.cvtColor(image_rgb, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    
    # 重塑点云为 Nx3 格式
    points = point_cloud.reshape(-1, 3)
    
    # 为每个点分配颜色（从图像）
    image_small = cv2.resize(image_rgb, (point_cloud.shape[1], point_cloud.shape[0]))
    colors = image_small.reshape(-1, 3) / 255.0
    
    # 过滤无效点（深度为 0 或 NaN）
    valid_mask = ~np.isnan(points[:, 0]) & ~np.isnan(points[:, 1]) & ~np.isnan(points[:, 2])
    points = points[valid_mask]
    colors = colors[valid_mask]
    
    # 创建 Open3D 点云
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    pcd.colors = o3d.utility.Vector3dVector(colors)
    
    # 2. 创建轨迹可视化
    # 将轨迹点从 2D 图像坐标 + 深度转换为 3D 相机坐标
    trajectory_3d = []
    for i, (x, y, d) in enumerate(trajectory):
        # 从点云中查找对应 2D 坐标的 3D 点
        x_clamped = max(0, min(int(x), point_cloud.shape[1] - 1))
        y_clamped = max(0, min(int(y), point_cloud.shape[0] - 1))
        
        # 获取该位置的 3D 点，但使用轨迹预测的深度值
        base_point = point_cloud[y_clamped, x_clamped]
        
        # 构建 3D 轨迹点：使用图像坐标对应的方向，但使用轨迹预测的深度
        # MoGe2 的点云已经是相机坐标系，Z 轴向前
        if not np.isnan(base_point[0]) and not np.isnan(base_point[1]) and not np.isnan(base_point[2]):
            # 归一化方向
            direction = base_point / np.linalg.norm(base_point)
            # 使用轨迹深度
            trajectory_3d.append(direction * d)
    
    if len(trajectory_3d) >= 2:
        trajectory_3d = np.array(trajectory_3d)
        
        # 创建轨迹线
        lines = [[i, i+1] for i in range(len(trajectory_3d) - 1)]
        line_set = o3d.geometry.LineSet()
        line_set.points = o3d.utility.Vector3dVector(trajectory_3d)
        line_set.lines = o3d.utility.Vector2iVector(lines)
        line_set.colors = o3d.utility.Vector3dVector([[1, 0, 0]] * len(lines))  # 红色轨迹
        
        # 添加起点（绿色球体）
        start_sphere = o3d.geometry.TriangleMesh.create_sphere(radius=0.1)
        start_sphere.translate(trajectory_3d[0])
        start_sphere.paint_uniform_color([0, 1, 0])
        
        # 添加终点（蓝色球体）
        end_sphere = o3d.geometry.TriangleMesh.create_sphere(radius=0.1)
        end_sphere.translate(trajectory_3d[-1])
        end_sphere.paint_uniform_color([0, 0, 1])
        
        # 添加中间点（黄色小球）
        for i, pt in enumerate(trajectory_3d[1:-1], 1):
            sphere = o3d.geometry.TriangleMesh.create_sphere(radius=0.05)
            sphere.translate(pt)
            sphere.paint_uniform_color([1, 1, 0])
    
    # 3. 创建坐标系
    coordinate_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.5, origin=[0, 0, 0])
    
    # 4. 可视化
    print("🎨 渲染 3D 场景...")
    
    # 设置视角
    vis = o3d.visualization.Visualizer()
    vis.create_window(width=1280, height=960)
    
    vis.add_geometry(pcd)
    if len(trajectory_3d) >= 2:
        vis.add_geometry(line_set)
        vis.add_geometry(start_sphere)
        vis.add_geometry(end_sphere)
    vis.add_geometry(coordinate_frame)
    
    # 设置相机视角（从斜上方看）
    ctr = vis.get_view_control()
    ctr.set_front([0, 0, 1])
    ctr.set_lookat([0, 0, 0.5])
    ctr.set_up([0, -1, 0])
    ctr.set_zoom(0.8)
    
    # 运行可视化
    vis.run()
    vis.destroy()
    
    print(f"✅ 3D 可视化窗口已打开")
    return True


def visualize_trajectory_3d_static(point_cloud, image_path, trajectory, output_image_path, output_pcd_path=None):
    """
    创建静态 3D 可视化图像（保存为 PNG），并可选保存点云文件
    
    Args:
        point_cloud: MoGe2 生成的点云 [H, W, 3]
        image_path: 原始图像路径
        trajectory: 轨迹点列表 [(x, y, d), ...]
        output_image_path: 输出图像路径
        output_pcd_path: 输出点云文件路径（可选，保存为 PLY 格式）
    
    Returns:
        点云数据字典（包含点云和轨迹点）
    """
    import matplotlib
    matplotlib.use('Agg')  # 非交互式后端
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d import Axes3D
    
    print("\n🔄 创建 3D 静态可视化（使用 matplotlib）...")
    
    # 1. 准备点云数据
    image_rgb = cv2.imread(image_path)
    image_rgb = cv2.cvtColor(image_rgb, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    
    # 重塑点云为 Nx3 格式
    points = point_cloud.reshape(-1, 3)
    
    # 为每个点分配颜色（从图像）
    image_small = cv2.resize(image_rgb, (point_cloud.shape[1], point_cloud.shape[0]))
    colors = image_small.reshape(-1, 3) / 255.0
    
    # 过滤无效点
    valid_mask = ~np.isnan(points[:, 0]) & ~np.isnan(points[:, 1]) & ~np.isnan(points[:, 2])
    points_valid = points[valid_mask]
    colors_valid = colors[valid_mask]
    
    # 2. 创建轨迹 3D 点
    trajectory_3d = []
    for i, (x, y, d) in enumerate(trajectory):
        x_clamped = max(0, min(int(x), point_cloud.shape[1] - 1))
        y_clamped = max(0, min(int(y), point_cloud.shape[0] - 1))
        
        base_point = point_cloud[y_clamped, x_clamped]
        
        if not np.isnan(base_point[0]) and not np.isnan(base_point[1]) and not np.isnan(base_point[2]):
            direction = base_point / (np.linalg.norm(base_point) + 1e-6)
            trajectory_3d.append(direction * d)
    
    trajectory_3d_array = np.array(trajectory_3d) if len(trajectory_3d) >= 2 else None
    
    # 3. 创建图形
    fig = plt.figure(figsize=(16, 8))

    # 3D 点云视图
    ax1 = fig.add_subplot(121, projection='3d')

    # 绘制点云（降采样以加快显示）
    if len(points_valid) > 50000:
        indices = np.random.choice(len(points_valid), 50000, replace=False)
        points_display = points_valid[indices]
        colors_display = colors_valid[indices]
    else:
        points_display = points_valid
        colors_display = colors_valid

    ax1.scatter(points_display[:, 0], points_display[:, 1], points_display[:, 2],
                c=colors_display, s=1, alpha=0.5, label='Point Cloud')

    # 绘制轨迹
    if trajectory_3d_array is not None:
        ax1.plot(trajectory_3d_array[:, 0], trajectory_3d_array[:, 1], trajectory_3d_array[:, 2],
                 'r-', linewidth=3, label='Trajectory')

        # 起点（绿色）
        ax1.scatter(trajectory_3d_array[0:1, 0], trajectory_3d_array[0:1, 1], trajectory_3d_array[0:1, 2],
                   c='green', s=100, marker='o', label='Start')
        # 终点（蓝色）
        ax1.scatter(trajectory_3d_array[-1:, 0], trajectory_3d_array[-1:, 1], trajectory_3d_array[-1:, 2],
                   c='blue', s=100, marker='^', label='Target')

        # 中间点
        if len(trajectory_3d_array) > 2:
            ax1.scatter(trajectory_3d_array[1:-1, 0], trajectory_3d_array[1:-1, 1], trajectory_3d_array[1:-1, 2],
                       c='yellow', s=50, marker='o', edgecolors='orange')

    ax1.set_xlabel('X (m)')
    ax1.set_ylabel('Y (m)')
    ax1.set_zlabel('Z (m)')
    ax1.set_title('3D Point Cloud with Trajectory')
    ax1.legend()
    ax1.view_init(elev=20, azim=-60)
    
    # 4. 2D 图像 + 轨迹俯视图
    ax2 = fig.add_subplot(122)
    ax2.imshow(image_rgb)
    
    # 绘制 2D 轨迹投影
    if len(trajectory) >= 2:
        traj_2d_x = [pt[0] for pt in trajectory]
        traj_2d_y = [pt[1] for pt in trajectory]
        ax2.plot(traj_2d_x, traj_2d_y, 'r-', linewidth=2, alpha=0.7, label='Trajectory')
        ax2.scatter(traj_2d_x[0], traj_2d_y[0], c='green', s=150, marker='o', label='Start', zorder=5)
        ax2.scatter(traj_2d_x[-1], traj_2d_y[-1], c='blue', s=150, marker='^', label='Target', zorder=5)
        
        # 绘制中间点
        for i, (x, y) in enumerate(zip(traj_2d_x[1:-1], traj_2d_y[1:-1]), 1):
            ax2.scatter(x, y, c='yellow', s=80, marker='o', edgecolors='orange', zorder=4)
    
    ax2.set_title('Original Image with 2D Trajectory')
    ax2.legend()
    
    plt.tight_layout()
    plt.savefig(output_image_path, dpi=150, bbox_inches='tight')
    plt.close()

    print(f"✅ 3D 可视化已保存：{output_image_path}")

    # 5. 保存点云文件（PLY 格式）- 分开保存场景和轨迹
    pcd_data = None
    if output_pcd_path:
        print(f"\n💾 保存点云数据...")
        
        # 5.1 保存场景点云（不带轨迹点）
        scene_pcd_path = output_pcd_path.replace('.ply', '_scene.ply')
        print(f"   → 保存场景点云：{scene_pcd_path}")
        
        with open(scene_pcd_path, 'w') as f:
            f.write("ply\n")
            f.write("format ascii 1.0\n")
            f.write(f"element vertex {len(points_valid)}\n")
            f.write("property float x\n")
            f.write("property float y\n")
            f.write("property float z\n")
            f.write("property uchar red\n")
            f.write("property uchar green\n")
            f.write("property uchar blue\n")
            f.write("end_header\n")
            
            for pt, col in zip(points_valid, colors_valid):
                r, g, b = int(col[0] * 255), int(col[1] * 255), int(col[2] * 255)
                f.write(f"{pt[0]:.6f} {pt[1]:.6f} {pt[2]:.6f} {r} {g} {b}\n")
        
        print(f"      ✅ 场景点云已保存 ({len(points_valid)} 个点)")
        
        # 5.2 保存轨迹点云（仅轨迹点，单独文件）
        if trajectory_3d_array is not None:
            traj_pcd_path = output_pcd_path.replace('.ply', '_trajectory.ply')
            print(f"   → 保存轨迹点云：{traj_pcd_path}")
            
            # 轨迹点颜色：起点绿色，终点蓝色，中间点黄色
            traj_colors = np.zeros((len(trajectory_3d_array), 3))
            traj_colors[0] = [0, 1, 0]  # 起点：绿色
            traj_colors[-1] = [0, 0, 1]  # 终点：蓝色
            if len(trajectory_3d_array) > 2:
                traj_colors[1:-1] = [1, 1, 0]  # 中间点：黄色
            
            with open(traj_pcd_path, 'w') as f:
                f.write("ply\n")
                f.write("format ascii 1.0\n")
                f.write(f"element vertex {len(trajectory_3d_array)}\n")
                f.write("property float x\n")
                f.write("property float y\n")
                f.write("property float z\n")
                f.write("property uchar red\n")
                f.write("property uchar green\n")
                f.write("property uchar blue\n")
                f.write("end_header\n")
                
                for pt, col in zip(trajectory_3d_array, traj_colors):
                    r, g, b = int(col[0] * 255), int(col[1] * 255), int(col[2] * 255)
                    f.write(f"{pt[0]:.6f} {pt[1]:.6f} {pt[2]:.6f} {r} {g} {b}\n")
            
            print(f"      ✅ 轨迹点云已保存 ({len(trajectory_3d_array)} 个点)")
        else:
            traj_pcd_path = None
        
        # 5.3 保存轨迹数据为 JSON 文件
        traj_json_path = output_pcd_path.replace('.ply', '_trajectory.json')
        import json
        traj_data = {
            'trajectory_3d': trajectory_3d_array.tolist() if trajectory_3d_array is not None else [],
            'trajectory_2d': trajectory,
            'start_point': trajectory[0] if trajectory else None,
            'target_point': trajectory[-1] if trajectory else None,
            'num_points': len(trajectory)
        }
        with open(traj_json_path, 'w') as f:
            json.dump(traj_data, f, indent=2)
        print(f"   → 轨迹数据：{traj_json_path}")
        print(f"      ✅ 轨迹 JSON 已保存")
        
        # 返回数据
        pcd_data = {
            'scene_points': points_valid,
            'scene_colors': colors_valid,
            'trajectory_points': trajectory_3d_array,
            'trajectory_colors': traj_colors if trajectory_3d_array is not None else None,
            'trajectory_2d': trajectory,
            'scene_pcd_path': scene_pcd_path,
            'traj_pcd_path': traj_pcd_path,
            'traj_json_path': traj_json_path
        }

    return pcd_data


def main():
    """主函数"""
    print("="*60)
    print("🎨 3D 轨迹可视化 (基于 MoGe2 点云)")
    print("="*60)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🖥️  使用设备：{device}")
    
    # 1. 加载模型
    gdino_model = load_gdino_model()
    moge2_model = load_moge2_model(device)
    
    # 2. 检测目标
    detections = detect_with_gdino(gdino_model, IMAGE_PATH, TARGET_OBJECT)
    
    if not detections:
        print("❌ 未检测到目标物体，退出")
        return None
    
    # 3. 生成深度图和点云
    depth_map, point_cloud = get_depth_and_pointcloud_from_moge2(moge2_model, IMAGE_PATH, device)
    
    # 4. 计算 2.5D 坐标
    coords_2d5 = compute_2d5_coords(detections, depth_map, point_cloud, start_point_2d=START_POINT_2D)
    
    # 5. 准备轨迹预测的输入
    start_point = {
        "x": coords_2d5["start_point"]["x"],
        "y": coords_2d5["start_point"]["y"],
        "depth": coords_2d5["start_point"]["depth"]
    }
    
    # 使用第一个检测目标
    if "targets" in coords_2d5 and len(coords_2d5["targets"]) > 0:
        target = coords_2d5["targets"][0]
        target_point = {
            "x": target["x"],
            "y": target["y"],
            "depth": target["depth"]
        }
    else:
        print("❌ 未找到目标物体")
        return None
    
    # 6. 预测轨迹
    trajectory = predict_trajectory(IMAGE_PATH, start_point, target_point)
    
    # 7. 创建输出目录
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 8. 3D 可视化
    print("\n" + "="*60)
    print("🎨 创建 3D 可视化...")
    print("="*60)

    # 保存轨迹数据
    base_name = os.path.splitext(os.path.basename(IMAGE_PATH))[0]
    output_json = os.path.join(OUTPUT_DIR, f"{base_name}_3d_trajectory.json")

    import json
    trajectory_data = {
        "start_point": start_point,
        "target_point": target_point,
        "trajectory": [list(pt) for pt in trajectory],
        "image_path": IMAGE_PATH
    }

    with open(output_json, 'w') as f:
        json.dump(trajectory_data, f, indent=2)
    print(f"✅ 轨迹数据已保存：{output_json}")

    # 9. 创建静态 3D 可视化图像 + 点云文件
    output_3d_image = os.path.join(OUTPUT_DIR, f"{base_name}_3d_traj_static.png")
    output_pcd_base = os.path.join(OUTPUT_DIR, f"{base_name}_pointcloud")

    pcd_data = visualize_trajectory_3d_static(
        point_cloud, IMAGE_PATH, trajectory,
        output_3d_image,
        output_pcd_base + ".ply"  # 基础路径，实际会生成多个文件
    )

    # 10. 输出摘要
    print("\n" + "="*60)
    print("📊 结果摘要")
    print("="*60)
    print(f"起点：({start_point['x']:.1f}, {start_point['y']:.1f}, {start_point['depth']:.3f}m)")
    print(f"目标：({target_point['x']:.1f}, {target_point['y']:.1f}, {target_point['depth']:.3f}m)")
    print(f"轨迹点数：{len(trajectory)}")
    print(f"\n输出文件:")
    print(f"  - 轨迹数据：{output_json}")
    print(f"  - 3D 可视化：{output_3d_image}")
    print(f"  - 场景点云：{output_pcd_base}_scene.ply")
    print(f"  - 轨迹点云：{output_pcd_base}_trajectory.ply")
    print(f"  - 轨迹 JSON: {output_pcd_base}_trajectory.json")
    print(f"  - 输出目录：{OUTPUT_DIR}")

    # 11. 提示用户
    print("\n💡 提示:")
    print("  - 查看点云：使用 MeshLab、CloudCompare 或 Open3D 打开 .ply 文件")
    print("  - 场景点云和轨迹点云已分开保存，可单独调整轨迹点的可视化效果")
    print("  - 3D 可视化：打开 PNG 图像查看 3D 点云 + 轨迹效果")

    return trajectory_data


if __name__ == "__main__":
    main()
