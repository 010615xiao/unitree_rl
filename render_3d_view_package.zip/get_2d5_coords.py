#!/usr/bin/env python3
"""
使用 GroundingDINO + MoGe2 获取目标物体的 2.5D 坐标 (x, y, depth)
- GroundingDINO: 检测目标的 2D 边界框
- MoGe2: 估计深度图
- 输出：边界框中心坐标 (x, y) + 深度值 d
"""

import sys
import os
import torch
import cv2
import numpy as np

# 添加路径
sys.path.insert(0, "/workspace/wxd/Agent/Spagent/spagent/checkpoints/moge2/MoGe")

# 配置
IMAGE_PATH = "/workspace/wxd/Agent/images/test_navigation_2.png"
TARGET_OBJECT = "waterpot"
GDINO_CKPT = "/workspace/wxd/Agent/Spagent/spagent/checkpoints/grounding_dino/groundingdino_swinb_cogcoor.pth"
GDINO_CONFIG = "/workspace/wxd/Agent/Spagent/spagent/spagent/external_experts/GroundingDINO/configs/GroundingDINO_SwinB_cfg.py"
MOGE2_CKPT = "/workspace/wxd/Agent/Spagent/spagent/checkpoints/moge2/moge-2-vitl-normal/model.pt"

BOX_THRESHOLD = 0.30
TEXT_THRESHOLD = 0.20

# Start point 配置 (2D 坐标固定)
START_POINT_2D = (451, 468)  # (x, y)

# 输出目录配置
OUTPUT_BASE_DIR = "/workspace/wxd/Agent/images"
OUTPUT_DIR = os.path.join(OUTPUT_BASE_DIR, "2d5_detection_results")


def load_gdino_model():
    """加载 GroundingDINO 模型"""
    from groundingdino.util.inference import load_model
    print("🔄 加载 GroundingDINO 模型...")
    model = load_model(GDINO_CONFIG, GDINO_CKPT)
    model.eval()
    print("✅ GroundingDINO 模型已加载")
    return model


def load_moge2_model(device):
    """加载 MoGe2 模型"""
    from moge.model.v2 import MoGeModel
    print("🔄 加载 MoGe2 模型...")
    model = MoGeModel.from_pretrained(MOGE2_CKPT).to(device)
    model.eval()
    print("✅ MoGe2 模型已加载")
    return model


def detect_with_gdino(model, image_path, prompt):
    """使用 GroundingDINO 检测目标物体"""
    from groundingdino.util.inference import load_image, predict
    from torchvision.ops import box_convert
    
    print(f"🔍 检测目标：{prompt}")
    
    image_source, image = load_image(image_path)
    h, w, _ = image_source.shape
    
    boxes, logits, phrases = predict(
        model=model,
        image=image,
        caption=prompt,
        box_threshold=BOX_THRESHOLD,
        text_threshold=TEXT_THRESHOLD
    )
    
    if len(boxes) == 0:
        print("⚠️ 未检测到目标物体")
        return []
    
    # 转换为绝对坐标 (xyxy 格式)
    boxes_abs = boxes * torch.Tensor([w, h, w, h])
    boxes_xyxy = box_convert(boxes=boxes_abs, in_fmt="cxcywh", out_fmt="xyxy")
    
    results = []
    for box, logit, phrase in zip(boxes_xyxy, logits, phrases):
        box_list = box.tolist()
        results.append({
            "box": box_list,  # [x1, y1, x2, y2]
            "confidence": logit.item(),
            "phrase": str(phrase)
        })
        print(f"   检测到：{phrase} (置信度：{logit.item():.3f})")
        print(f"   边界框：x1={box_list[0]:.1f}, y1={box_list[1]:.1f}, x2={box_list[2]:.1f}, y2={box_list[3]:.1f}")
    
    return results


def get_depth_from_moge2(model, image_path, device):
    """使用 MoGe2 获取深度图"""
    print("🔄 估计深度图...")
    
    image_bgr = cv2.imread(image_path)
    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    
    input_tensor = torch.tensor(image_rgb / 255.0, dtype=torch.float32, device=device).permute(2, 0, 1)
    
    with torch.no_grad():
        output = model.infer(input_tensor)
    
    depth_map = output["depth"].cpu().numpy()
    point_cloud = output["points"].cpu().numpy()
    
    print(f"✅ 深度图已生成：{w}x{h}, 深度范围 {depth_map.min():.2f}-{depth_map.max():.2f}米")
    
    return depth_map, point_cloud


def get_point_depth(depth_map, x, y, window_size=1):
    """获取指定点的深度值（使用局部窗口中位数）"""
    # 确保索引在有效范围内
    x_clamped = max(0, min(int(x), depth_map.shape[1] - 1))
    y_clamped = max(0, min(int(y), depth_map.shape[0] - 1))
    
    # 在点周围小区域采样深度
    half_window = window_size
    x1, y1 = max(0, x_clamped - half_window), max(0, y_clamped - half_window)
    x2, y2 = min(depth_map.shape[1], x_clamped + half_window + 1), min(depth_map.shape[0], y_clamped + half_window + 1)
    
    region_depth = depth_map[y1:y2, x1:x2]
    
    if region_depth.size > 0:
        median_depth = float(np.median(region_depth))
        mean_depth = float(np.mean(region_depth))
        std_depth = float(np.std(region_depth))
        return median_depth, mean_depth, std_depth
    return None, None, None


def compute_2d5_coords(detections, depth_map, start_point_2d=None):
    """从 2D 边界框和深度图计算 2.5D 坐标"""
    results_2d5 = {}
    
    # 计算 start point 的 2.5D 坐标
    if start_point_2d is not None:
        sx, sy = start_point_2d
        median_depth, mean_depth, std_depth = get_point_depth(depth_map, sx, sy)
        
        if median_depth is not None:
            results_2d5["start_point"] = {
                "x": float(sx),
                "y": float(sy),
                "depth": median_depth,
                "depth_mean": mean_depth,
                "depth_std": std_depth,
                "type": "start_point"
            }
            
            print(f"\n📍 Start Point 2.5D 坐标:")
            print(f"   2D 坐标：({sx}, {sy})")
            print(f"   深度 (中位数): {median_depth:.3f} 米")
            print(f"   深度 (平均值): {mean_depth:.3f} 米 (±{std_depth:.3f})")
            print(f"   2.5D 坐标：(x={sx}, y={sy}, d={median_depth:.3f}m)")
    
    # 计算检测目标的 2.5D 坐标（支持多个目标）
    if detections:
        results_2d5["targets"] = []
        
        print(f"\n📍 检测到 {len(detections)} 个目标物体:")
        
        for i, det in enumerate(detections):
            box = det["box"]  # [x1, y1, x2, y2]
            x1, y1, x2, y2 = box

            # 计算边界框中心
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2

            # 在边界框区域内采样深度值
            x1_int, y1_int = int(x1), int(y1)
            x2_int, y2_int = int(x2), int(y2)

            # 确保索引在有效范围内
            x1_int = max(0, x1_int)
            y1_int = max(0, y1_int)
            x2_int = min(depth_map.shape[1], x2_int)
            y2_int = min(depth_map.shape[0], y2_int)

            # 提取区域内的深度值
            region_depth = depth_map[y1_int:y2_int, x1_int:x2_int]

            if region_depth.size > 0:
                median_depth = float(np.median(region_depth))
                mean_depth = float(np.mean(region_depth))
                std_depth = float(np.std(region_depth))

                target_info = {
                    "id": i,
                    "x": center_x,
                    "y": center_y,
                    "depth": median_depth,
                    "depth_mean": mean_depth,
                    "depth_std": std_depth,
                    "box": box,
                    "confidence": det["confidence"],
                    "phrase": det["phrase"],
                    "type": "target"
                }
                results_2d5["targets"].append(target_info)

                print(f"\n   【目标 {i+1}】{det['phrase']} (置信度：{det['confidence']:.3f})")
                print(f"      2D 中心：({center_x:.1f}, {center_y:.1f})")
                print(f"      深度 (中位数): {median_depth:.3f} 米")
                print(f"      深度 (平均值): {mean_depth:.3f} 米 (±{std_depth:.3f})")
                print(f"      2.5D 坐标：(x={center_x:.1f}, y={center_y:.1f}, d={median_depth:.3f}m)")

    return results_2d5


def visualize_result(image_path, coords_2d5, depth_map, output_path):
    """可视化检测结果和深度信息"""
    image = cv2.imread(image_path)
    h, w = image.shape[:2]

    # 创建深度图可视化
    depth_vis = cv2.normalize(depth_map, None, 0, 255, cv2.NORM_MINMAX)
    depth_vis = depth_vis.astype(np.uint8)
    depth_vis_color = cv2.applyColorMap(depth_vis, cv2.COLORMAP_INFERNO)

    # 绘制 Start Point
    if "start_point" in coords_2d5:
        sp = coords_2d5["start_point"]
        x, y = int(sp["x"]), int(sp["y"])
        depth = sp["depth"]
        
        # Start point: 绿色圆圈
        cv2.circle(image, (x, y), 8, (0, 255, 0), -1)
        label = f"Start: d={depth:.2f}m"
        cv2.putText(image, label, (x, y - 10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # 绘制所有目标物体
    if "targets" in coords_2d5:
        colors = [(0, 0, 255), (255, 0, 0), (255, 0, 255), (0, 255, 255), (255, 255, 0)]
        
        for i, target in enumerate(coords_2d5["targets"]):
            box = target["box"]
            x1, y1, x2, y2 = map(int, box)
            depth = target["depth"]
            phrase = target.get("phrase", "object")
            
            # 使用不同颜色区分不同目标
            color = colors[i % len(colors)]
            
            # 绘制边界框
            cv2.rectangle(image, (x1, y1), (x2, y2), color, 3)

            # 标注中心点
            center_x, center_y = int((x1 + x2) / 2), int((y1 + y2) / 2)
            cv2.circle(image, (center_x, center_y), 5, (0, 255, 0), -1)

            # 添加标签
            label = f"{i+1}. {phrase}: d={depth:.2f}m"
            cv2.putText(image, label, (x1, y1 - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

    # 拼接图像
    result_vis = np.hstack([image, depth_vis_color])

    cv2.imwrite(output_path, result_vis)
    print(f"\n✅ 可视化结果已保存：{output_path}")

    return output_path


def save_json_result(coords_2d5, output_path):
    """保存 JSON 结果"""
    import json
    
    # 移除 numpy 类型，转换为标准 Python 类型
    def convert_to_serializable(obj):
        if isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: convert_to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_to_serializable(item) for item in obj]
        return obj
    
    result = {
        "start_point": None,
        "target": None
    }
    
    if "start_point" in coords_2d5:
        sp = coords_2d5["start_point"]
        result["start_point"] = {
            "x": sp["x"],
            "y": sp["y"],
            "depth": sp["depth"],
            "depth_mean": sp.get("depth_mean"),
            "depth_std": sp.get("depth_std")
        }
    
    if "target" in coords_2d5:
        t = coords_2d5["target"]
        result["target"] = {
            "phrase": t.get("phrase"),
            "x": t["x"],
            "y": t["y"],
            "depth": t["depth"],
            "depth_mean": t.get("depth_mean"),
            "depth_std": t.get("depth_std"),
            "box": t.get("box"),
            "confidence": t.get("confidence")
        }
    
    result_serializable = convert_to_serializable(result)
    
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result_serializable, f, indent=2)
    
    print(f"✅ JSON 结果已保存：{output_path}")
    return output_path


def get_2d5_coords(image_path: str, target_object: str, start_point_2d: tuple = None):
    """
    主函数：获取 start point 和 target object 的 2.5D 坐标
    
    Args:
        image_path: 输入图像路径
        target_object: 目标物体名称
        start_point_2d: Start point 的 2D 坐标 (x, y)
    
    Returns:
        dict: 包含 start_point 和 target 的 2.5D 坐标
            {
                "start_point": {"x": float, "y": float, "depth": float, ...},
                "target": {"x": float, "y": float, "depth": float, ...}
            }
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"🖥️  使用设备：{device}")
    
    # 1. 加载模型
    gdino_model = load_gdino_model()
    moge2_model = load_moge2_model(device)
    
    # 2. 使用 GroundingDINO 检测目标
    detections = detect_with_gdino(gdino_model, image_path, target_object)
    
    if not detections:
        print("❌ 未检测到目标物体，退出")
        return None
    
    # 3. 使用 MoGe2 获取深度图
    depth_map, point_cloud = get_depth_from_moge2(moge2_model, image_path, device)
    
    # 4. 计算 2.5D 坐标
    coords_2d5 = compute_2d5_coords(detections, depth_map, start_point_2d=start_point_2d)
    
    # 5. 可视化结果
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    output_vis = os.path.join(OUTPUT_DIR, f"{base_name}_2d5_result.png")
    visualize_result(image_path, coords_2d5, depth_map, output_vis)

    # 6. 保存 JSON 结果
    output_json = os.path.join(OUTPUT_DIR, f"{base_name}_2d5_result.json")
    save_json_result(coords_2d5, output_json)
    
    # 7. 输出最终结果摘要
    print("\n" + "=" * 60)
    print("📊 2.5D 坐标检测结果摘要")
    print("=" * 60)
    if "start_point" in coords_2d5:
        sp = coords_2d5["start_point"]
        print(f"【Start Point】")
        print(f"   2.5D 坐标：(x={sp['x']:.1f}, y={sp['y']:.1f}, d={sp['depth']:.3f}m)")
    
    if "targets" in coords_2d5:
        targets = coords_2d5["targets"]
        print(f"【检测到 {len(targets)} 个目标物体】")
        for t in targets:
            print(f"   {t['id']+1}. {t['phrase']} (置信度：{t['confidence']:.3f})")
            print(f"      2.5D 坐标：(x={t['x']:.1f}, y={t['y']:.1f}, d={t['depth']:.3f}m)")

    return coords_2d5


if __name__ == "__main__":
    coords = get_2d5_coords(
        image_path=IMAGE_PATH,
        target_object=TARGET_OBJECT,
        start_point_2d=START_POINT_2D
    )
