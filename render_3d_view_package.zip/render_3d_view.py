#!/usr/bin/env python3
"""
使用完整 3D 欧拉角和旋转矩阵渲染轨迹点新视角图像

重要说明：
- 轨迹点格式：(pixel_x, pixel_y, depth_m)
- 轨迹表示相机的运动轨迹，不是视线方向
- 每个轨迹点的 3D 位置从针孔相机模型反投影得到
- 每个轨迹点的朝向 = 从当前位置指向下一个位置的方向向量

坐标系统：
- 世界坐标系：以原始相机为原点，X 向右，Y 向下，Z 向前
- 相机坐标系：以轨迹点为原点，Z 轴朝向下一个轨迹点

3D 位置计算：
  cam_x = (pixel_x - cx) × depth / focal_length
  cam_y = (pixel_y - cy) × depth / focal_length
  cam_z = depth

朝向计算：
  direction = normalize(P_{i+1} - P_i)
  yaw = arctan2(dy, dx)
  pitch = arcsin(-dz)
  roll = 0

旋转矩阵：
  直接构造相机坐标系的基向量：
  - Z 轴 = direction（相机看向的方向）
  - X 轴 = normalize(cross([0, 0, 1], Z))（与 Z 轴垂直，向右）
  - Y 轴 = cross(Z, X)（右手定则，向下）
  R = [X, Y, Z]^T

运行示例：
    python render_3d_view.py --image images/frames/frame_0054.png --instruction "近处的座椅"
    python render_3d_view.py --image images/frames/frame_0054.png --instruction "近处的座椅" --yaw-offset 10
"""

import argparse
import os
import sys
import numpy as np
import cv2
from typing import Dict, List, Optional, Tuple

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from trajectory_planning_agent import TrajectoryPlanningAgent


class EnhancedViewRenderer:
    """使用完整 3D 朝向的增强型视角渲染器"""
    
    def __init__(self, output_dir: str = "/workspace/wxd/Agent/images/trajectory_planning_results"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def render_with_3d_orientation(self, point_cloud: np.ndarray, image_path: str,
                                    trajectory: List[Tuple[float, float, float]],
                                    depth_map: np.ndarray,
                                    intrinsics: Optional[np.ndarray] = None,
                                    view_index: int = -2,
                                    yaw_offset: float = 0.0) -> Optional[Dict[str, str]]:
        """
        从轨迹点渲染新视角图像（使用与 trajectory_planning_agent.py 一致的方法）
        
        Args:
            point_cloud: 点云 [H, W, 3]，每个点是 (X, Y, Z) 相机坐标系（米）
            image_path: 原始图像路径
            trajectory: 轨迹点列表 [(x, y, depth), ...]
            depth_map: 深度图 [H, W]
            intrinsics: 相机内参矩阵 [3, 3]（可选，如果为 None 则使用默认 FOV）
            view_index: 要渲染的轨迹点索引（-2 表示倒数第二个点）
            yaw_offset: 额外的 yaw 偏移（度），用于微调
        
        Returns:
            输出文件路径字典
        """
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        
        print("\n" + "="*70)
        print("🎨 增强型 3D 视角渲染")
        print("="*70)
        
        # 获取目标轨迹点
        target_idx = view_index if view_index >= 0 else len(trajectory) + view_index
        if target_idx < 0 or target_idx >= len(trajectory):
            print(f"   ⚠️ 轨迹点索引 {view_index} 超出范围，跳过渲染")
            return None
        
        target_point = trajectory[target_idx]
        target_pixel_x, target_pixel_y, target_depth = target_point
        print(f"   渲染位置：轨迹点 #{target_idx} (像素：{target_pixel_x:.1f}, {target_pixel_y:.1f}, 深度：{target_depth:.3f}m)")
        
        # 获取原始图像尺寸
        image_bgr = cv2.imread(image_path)
        h_orig, w_orig = image_bgr.shape[:2]
        h_pc, w_pc = point_cloud.shape[:2]
        
        print(f"   原始图像尺寸：{w_orig}x{h_orig}")
        print(f"   点云尺寸：{w_pc}x{h_pc}")

        # 相机内参
        if intrinsics is not None:
            # 使用 MoGe2 估算的真实内参（归一化→像素坐标）
            fx = intrinsics[0, 0] * w_orig
            fy = intrinsics[1, 1] * h_orig
            cx = intrinsics[0, 2] * w_orig
            cy = intrinsics[1, 2] * h_orig
            fov_x = 2 * np.arctan(w_orig / (2 * fx)) * 180 / np.pi
            print(f"   相机内参（MoGe2 估算）：fx={fx:.1f}, fy={fy:.1f}, cx={cx:.1f}, cy={cy:.1f}")
            print(f"   估算 FOV: {fov_x:.1f}°")
        else:
            # 默认假设 FOV=60°
            focal_length = w_orig / (2 * np.tan(np.deg2rad(60) / 2))
            cx, cy = w_orig / 2, h_orig / 2
            fx = fy = focal_length
            print(f"   相机内参（默认 FOV=60°）：fx=fy={focal_length:.1f}, cx={cx:.1f}, cy={cy:.1f}")
        
        # ============================================================
        # 计算轨迹点 3D 坐标（从针孔相机模型反投影）
        # ============================================================
        # 轨迹点表示相机在世界坐标系中的位置
        # 使用针孔相机模型将 (pixel_x, pixel_y, depth) 转换为 3D 坐标
        # 注意：这里使用深度图的深度值，而不是点云的 Z 值
        # 因为点云的 Z 值已经包含了 MoGe2 的预测，而深度图是原始的
        cam_x = (target_pixel_x - cx) * target_depth / fx
        cam_y = (target_pixel_y - cy) * target_depth / fy
        cam_z = target_depth
        
        print(f"   轨迹点 3D 坐标：({cam_x:.3f}, {cam_y:.3f}, {cam_z:.3f}) 米")

        # ============================================================
        # 计算 3D 朝向（从当前位置指向下一个位置）
        # ============================================================
        # 轨迹表示相机的运动轨迹
        # 朝向 = 从当前轨迹点指向下一个轨迹点的方向向量
        # ============================================================
        if target_idx < len(trajectory) - 1:
            # 朝向下一个点（前进方向）
            next_point = trajectory[target_idx + 1]
            next_x = (next_point[0] - cx) * next_point[2] / fx
            next_y = (next_point[1] - cy) * next_point[2] / fy
            next_z = next_point[2]
            
            # 方向向量（从当前点指向下一个点）
            dx = next_x - cam_x
            dy = next_y - cam_y
            dz = next_z - cam_z
            
            print(f"   朝向前进方向：下一个点 3D 坐标 ({next_x:.3f}, {next_y:.3f}, {next_z:.3f}) 米")
            
        elif target_idx > 0:
            # 最后一个点，朝向前一个点（往回看）
            prev_pt = trajectory[target_idx - 1]
            prev_x = (prev_pt[0] - cx) * prev_pt[2] / fx
            prev_y = (prev_pt[1] - cy) * prev_pt[2] / fy
            prev_z = prev_pt[2]
            
            dx = prev_x - cam_x
            dy = prev_y - cam_y
            dz = prev_z - cam_z
            
            print(f"   朝向前一个点：上一个点 3D 坐标 ({prev_x:.3f}, {prev_y:.3f}, {prev_z:.3f}) 米")
        else:
            # 起点，默认朝上（-Y 方向）
            dx, dy, dz = 0, -1, 0
            print(f"   起点，使用默认朝向")

        # 归一化方向向量
        norm = np.sqrt(dx**2 + dy**2 + dz**2)
        if norm > 0:
            dx, dy, dz = dx/norm, dy/norm, dz/norm

        # 计算欧拉角（用于显示）
        yaw = np.arctan2(dy, dx)
        pitch = np.arcsin(-dz)
        roll = 0.0

        yaw_deg = np.degrees(yaw)
        pitch_deg = np.degrees(pitch)
        roll_deg = np.degrees(roll)

        print(f"\n   方向向量：({dx:.3f}, {dy:.3f}, {dz:.3f})")
        print(f"   欧拉角：yaw={yaw_deg:.1f}°, pitch={pitch_deg:.1f}°, roll={roll_deg:.1f}°")

        # 应用额外的 yaw 偏移（用于微调）
        # 正确方法：在水平面内旋转方向向量
        # 注意：世界坐标系是 X 向右，Y 向下，Z 向前
        # yaw 是水平方向的旋转，即在 X-Y 平面内的旋转
        yaw_deg += yaw_offset

        if yaw_offset != 0:
            print(f"   应用 yaw 偏移 {yaw_offset}° → 最终 yaw={yaw_deg:.1f}°")
            
            # 计算原始方向的 yaw 和 pitch
            original_yaw = np.arctan2(dy, dx)
            original_pitch = np.arcsin(-dz)
            
            # 应用 yaw 偏移
            new_yaw = original_yaw + np.radians(yaw_offset)
            
            # 从新的 yaw 和原始 pitch 重建方向向量
            # 注意：pitch 保持不变，只改变水平朝向
            cos_pitch = np.cos(original_pitch)
            sin_pitch = np.sin(original_pitch)
            
            z_axis = np.array([
                np.cos(new_yaw) * cos_pitch,
                np.sin(new_yaw) * cos_pitch,
                -sin_pitch
            ])
            z_axis_display = z_axis
            print(f"   旋转后方向向量：({z_axis[0]:.3f}, {z_axis[1]:.3f}, {z_axis[2]:.3f})")
        else:
            z_axis = np.array([dx, dy, dz])
            z_axis_display = z_axis

        # ============================================================
        # 计算旋转矩阵
        # ============================================================
        # 目标：将方向向量旋转到 +Z 轴
        # 方法：直接构造相机坐标系的基向量
        # ============================================================
        # 新坐标系的 Z 轴 = 方向向量（相机看向的方向）
        # 新坐标系的 X 轴 = 与 Z 轴垂直，且与原始 X 轴（向右）尽可能接近
        # X = normalize(cross([0, 0, 1], Z))
        x_axis = np.cross([0, 0, 1], z_axis)
        x_norm = np.linalg.norm(x_axis)
        if x_norm > 1e-6:
            x_axis = x_axis / x_norm
        else:
            # Z 轴接近 [0, 0, 1]，使用默认 X 轴
            x_axis = np.array([1, 0, 0])

        # 新坐标系的 Y 轴 = Z × X（右手定则）
        y_axis = np.cross(z_axis, x_axis)

        # 旋转矩阵：从世界坐标到相机坐标
        # R = [x_axis, y_axis, z_axis]^T
        R = np.array([x_axis, y_axis, z_axis])
        
        print(f"\n   基向量：X=({x_axis[0]:.3f}, {x_axis[1]:.3f}, {x_axis[2]:.3f})")
        print(f"            Y=({y_axis[0]:.3f}, {y_axis[1]:.3f}, {y_axis[2]:.3f})")
        print(f"            Z=({z_axis_display[0]:.3f}, {z_axis_display[1]:.3f}, {z_axis_display[2]:.3f})")
        print(f"\n   旋转矩阵 R = [[{R[0,0]:.3f}, {R[0,1]:.3f}, {R[0,2]:.3f}],")
        print(f"                   [{R[1,0]:.3f}, {R[1,1]:.3f}, {R[1,2]:.3f}],")
        print(f"                   [{R[2,0]:.3f}, {R[2,1]:.3f}, {R[2,2]:.3f}]]")
        
        # 验证：R @ direction 应该接近 (0, 0, 1)
        v_rotated = R @ z_axis_display
        print(f"\n   验证：R @ direction = ({v_rotated[0]:.3f}, {v_rotated[1]:.3f}, {v_rotated[2]:.3f})")
        print(f"           期望：(0, 0, 1)")
        
        # ============================================================
        # 渲染：将点云变换到相机坐标系并投影
        # ============================================================
        print(f"\n   开始渲染...")
        
        # 1. 将点云重塑为 (N, 3)
        points = point_cloud.reshape(-1, 3).copy()
        
        # 2. 减去相机位置（平移）
        points[:, 0] -= cam_x
        points[:, 1] -= cam_y
        points[:, 2] -= cam_z
        
        # 3. 旋转到相机坐标系
        points_camera = points @ R.T
        
        # 4. 投影到 2D 图像平面
        valid_mask = points_camera[:, 2] > 0.01  # 近裁剪面
        points_valid = points_camera[valid_mask]

        # 使用正确的内参进行投影
        u = (points_valid[:, 0] * fx / points_valid[:, 2] + cx).astype(int)
        v = (points_valid[:, 1] * fy / points_valid[:, 2] + cy).astype(int)
        
        # 5. 过滤在图像外的点
        in_image = (u >= 0) & (u < w_orig) & (v >= 0) & (v < h_orig)
        u = u[in_image]
        v = v[in_image]
        points_valid = points_valid[in_image]
        
        print(f"   有效点数：{np.sum(valid_mask)} / {len(points)} ({100*np.sum(valid_mask)/len(points):.1f}%)")
        print(f"   图像内点数：{len(u)} / {np.sum(valid_mask)} ({100*len(u)/np.sum(valid_mask):.1f}%)")
        
        # 6. 获取原始颜色
        # 从原始点云获取颜色（假设点云索引对应图像像素）
        original_indices = np.where(valid_mask)[0]
        original_indices = original_indices[in_image]

        # 计算原始点云中的 (u_orig, v_orig)
        u_orig = original_indices % w_pc
        v_orig = original_indices // w_pc

        # 从原始图像获取颜色
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        point_colors = image_rgb[v_orig, u_orig]
        
        # 7. 创建渲染图像（使用 z-buffer 处理遮挡）
        rendered_image = np.zeros((h_orig, w_orig, 3), dtype=np.float32)
        depth_rendered = np.zeros((h_orig, w_orig), dtype=np.float32)
        
        # 按深度排序，从远到近绘制（画家算法）
        depths = points_valid[:, 2]
        sort_indices = np.argsort(depths)[::-1]
        
        draw_count = 0
        for idx in sort_indices:
            ui, vi = u[idx], v[idx]
            depth_val = depths[idx]
            color = point_colors[idx]
            
            if depth_rendered[vi, ui] == 0 or depth_val < depth_rendered[vi, ui]:
                rendered_image[vi, ui] = color
                depth_rendered[vi, ui] = depth_val
                draw_count += 1
        
        print(f"   绘制像素数：{draw_count} / {w_orig * h_orig} ({100*draw_count/(w_orig*h_orig):.2f}%)")
        print(f"   空洞率：{100*(1 - draw_count/(w_orig*h_orig)):.1f}% (保持原始点云)")
        
        # 8. 颜色增强
        gamma = 0.55
        rendered_image = np.power(rendered_image, 1/gamma)
        rendered_image = rendered_image * 1.2
        rendered_image = np.clip(rendered_image, 0, 1)
        
        print(f"   颜色增强：gamma={gamma} (1/{gamma:.2f}={1/gamma:.2f}x), 对比度=1.2x")
        
        # 9. 保存结果
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        offset_str = f"_yaw{int(yaw_offset)}" if yaw_offset != 0 else ""
        
        output_rendered = os.path.join(self.output_dir, f"{base_name}_view{target_idx}_rendered.png")
        output_depth = os.path.join(self.output_dir, f"{base_name}_view{target_idx}_depth.png")
        
        # 保存渲染图像
        rendered_bgr = (rendered_image * 255).astype(np.uint8)
        rendered_bgr = cv2.cvtColor(rendered_bgr, cv2.COLOR_RGB2BGR)
        cv2.imwrite(output_rendered, rendered_bgr)
        print(f"   ✅ 渲染图像已保存：{output_rendered}")
        
        # 保存深度图（归一化到 0-255）
        depth_vis = np.zeros((h_orig, w_orig), dtype=np.uint8)
        valid_depth = depth_rendered[depth_rendered > 0]
        if len(valid_depth) > 0:
            depth_min, depth_max = valid_depth.min(), valid_depth.max()
            depth_norm = (depth_rendered - depth_min) / (depth_max - depth_min + 1e-6) * 255
            depth_vis[depth_rendered > 0] = depth_norm[depth_rendered > 0].astype(np.uint8)
        depth_vis_colored = cv2.applyColorMap(depth_vis, cv2.COLORMAP_INFERNO)
        cv2.imwrite(output_depth, depth_vis_colored)
        print(f"   ✅ 深度图已保存：{output_depth}")
        
        return {
            "rendered_image": output_rendered,
            "depth_map": output_depth
        }


def main():
    parser = argparse.ArgumentParser(description="使用完整 3D 欧拉角渲染轨迹点视角")
    parser.add_argument("--image", type=str, required=True, help="输入图像路径")
    parser.add_argument("--instruction", type=str, default="近处的座椅", help="自然语言指令")
    parser.add_argument("--yaw-offset", type=float, default=0.0, help="额外的 yaw 偏移（度），用于微调")
    parser.add_argument("--output-dir", type=str, default="/workspace/wxd/Agent/images/trajectory_planning_results",
                        help="输出目录")
    
    args = parser.parse_args()
    
    # 初始化 Agent
    print("="*70)
    print("🤖 初始化轨迹规划 Agent")
    print("="*70)
    agent = TrajectoryPlanningAgent()
    
    # 运行轨迹预测
    print(f"\n📷 输入图像：{args.image}")
    print(f"💬 指令：{args.instruction}")
    
    result = agent.run(args.instruction, args.image, save_result=False)
    
    if not result.get("success", False):
        print(f"\n❌ 轨迹预测失败：{result.get('error', '未知错误')}")
        return
    
    # 获取必要的数据
    trajectory = result.get("trajectory", [])
    if len(trajectory) < 2:
        print(f"\n❌ 轨迹点数量不足：{len(trajectory)}")
        return
    
    # 重新生成点云和深度图（从 agent 获取）
    depth_map, point_cloud, intrinsics = agent.executor.get_depth_and_pointcloud(args.image)

    # 使用增强型渲染器
    renderer = EnhancedViewRenderer(output_dir=args.output_dir)

    # 渲染视角（使用 MoGe2 估算的相机内参）
    renderer.render_with_3d_orientation(
        point_cloud=point_cloud,
        image_path=args.image,
        trajectory=trajectory,
        depth_map=depth_map,
        intrinsics=intrinsics,
        view_index=-2,
        yaw_offset=args.yaw_offset
    )
    
    print("\n" + "="*70)
    print("✅ 渲染完成！")
    print("="*70)


if __name__ == "__main__":
    main()
