"""
RoboBrain 轨迹预测脚本 (优化版 - 英文 Prompt & 无障碍物)
通过 vLLM API 调用 RoboBrain2.5-8B 模型
"""

import os
import re
import json
import cv2
import numpy as np
import base64
from typing import Union, List, Optional, Tuple, Dict, Any
from openai import OpenAI


class UnifiedInference:
    """
    使用 vLLM API 调用 RoboBrain 2.5 模型的统一推理类
    """

    def __init__(self,
                 model_id: str = "RoboBrain2.5-8B",
                 base_url: str = "http://localhost:8000/v1",
                 api_key: str = "not-needed"):
        print("Connecting to vLLM API ...")
        self.model_id = model_id
        self.client = OpenAI(base_url=base_url, api_key=api_key)
        self.base_url = base_url

        try:
            models = self.client.models.list()
            available_models = [m.id for m in models.data]
            print(f"✅ vLLM API 连接成功，可用模型：{available_models}")
        except Exception as e:
            print(f"⚠️ vLLM API 连接失败：{e}")

    def inference(self, text: str, image: Union[list, str], task: str = "general",
                  plot: bool = False, do_sample: bool = True, temperature: float = 0.7,
                  override_prompt: bool = False):
        """
        使用 vLLM API 进行推理

        Args:
            override_prompt (bool): 如果为 True，则直接使用传入的 text，不添加任何默认后缀。
                                    对于轨迹预测，必须设置为 True。
        """
        if isinstance(image, str):
            image = [image]

        assert task in ["general", "pointing", "trajectory", "grounding"], \
            f"Invalid task type: {task}."

        # 只有当 override_prompt=False 时，才使用默认的 task 提示词增强
        if not override_prompt:
            if task == "pointing":
                text = f"{text}. Please provide its 2D coordinates. Your answer should be formatted as a tuple, i.e. [(x, y)]."
            elif task == "trajectory":
                text = f"{text}. Please predict 3D waypoints as list of tuples."
            elif task == "grounding":
                text = f"Please provide the bounding box coordinate: {text}."

        print(f"\n{'='*20} INPUT {'='*20}\n{text[:200]}...\n{'='*47}\n")

        # 构建消息
        image_content = []
        for img_path in image:
            if img_path.startswith("http"):
                image_content.append({"type": "image_url", "image_url": {"url": img_path}})
            else:
                with open(img_path, "rb") as f:
                    image_base64 = base64.b64encode(f.read()).decode('utf-8')
                ext = os.path.splitext(img_path)[1].lower()
                mime_type = 'image/png' if ext == '.png' else 'image/jpeg'
                image_content.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime_type};base64,{image_base64}"}
                })

        messages = [
            {
                "role": "user",
                "content": [*image_content, {"type": "text", "text": text}],
            },
        ]

        print("Running inference via vLLM API ...")
        try:
            response = self.client.chat.completions.create(
                model=self.model_id,
                messages=messages,
                max_tokens=1024,  # 增加 token 数以容纳思维链
                temperature=temperature if do_sample else 0.0,
            )
            answer_text = response.choices[0].message.content.strip()
        except Exception as e:
            print(f"❌ vLLM API 调用失败：{e}")
            answer_text = f"Error: {e}"
        
        # 打印模型原始输出
        print(f"\n📝 模型原始输出:")
        print("="*70)
        print(answer_text)
        print("="*70)

        # 绘制结果
        if plot and task in ["pointing", "trajectory", "grounding"]:
            print("Plotting enabled. Drawing results on the image ...")
            plot_points, plot_boxes, plot_trajectories = None, None, None

            if task == "trajectory":
                plot_trajectories = self._parse_trajectory(answer_text)
                image_name_to_save = os.path.basename(image[0]).replace(".", "_traj_annotated.")
            elif task == "pointing":
                point_pattern = r'\(\s*(\d+)\s*,\s*(\d+)\s*\)'
                points = re.findall(point_pattern, answer_text)
                plot_points = [(int(x), int(y)) for x, y in points]
                image_name_to_save = os.path.basename(image[0]).replace(".", "_point_annotated.")
            elif task == "grounding":
                box_pattern = r'\[\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\]'
                boxes = re.findall(box_pattern, answer_text)
                plot_boxes = [[int(x1), int(y1), int(x2), int(y2)] for x1, y1, x2, y2 in boxes]
                image_name_to_save = os.path.basename(image[0]).replace(".", "_box_annotated.")

            os.makedirs("result", exist_ok=True)
            image_path_to_save = os.path.join("result", image_name_to_save)

            # 轨迹任务使用绝对坐标，其他使用相对坐标
            coord_mode = "absolute" if task == "trajectory" else "relative"
            self.draw_on_image(
                image[0],
                points=plot_points,
                boxes=plot_boxes,
                trajectories=plot_trajectories,
                output_path=image_path_to_save,
                coord_mode=coord_mode
            )

        return {"answer": answer_text}

    def _parse_trajectory(self, text: str) -> List[List[Tuple]]:
        """
        健壮的轨迹解析函数，支持 CoT 和多种格式
        """
        # 1. 尝试寻找 JSON 列表结构
        start_idx = text.find('[')
        end_idx = text.rfind(']')

        if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
            list_str = text[start_idx : end_idx + 1]
            try:
                # 尝试直接解析 JSON (处理单引号替换)
                list_str_safe = list_str.replace("'", '"')
                data = json.loads(list_str_safe)
                if isinstance(data, list) and len(data) > 0:
                    trajectory = []
                    for point in data:
                        if isinstance(point, (list, tuple)) and len(point) >= 2:
                            x, y = float(point[0]), float(point[1])
                            d = float(point[2]) if len(point) > 2 else 0.0
                            trajectory.append((x, y, d))
                    return [trajectory] if trajectory else None
            except Exception as e:
                print(f"JSON parse failed, trying regex: {e}")

        # 2. 正则备份方案
        # 匹配 (x, y, d) 或 (x, y)
        pattern = r'\(\s*([+-]?\d+\.?\d*)\s*,\s*([+-]?\d+\.?\d*)\s*(?:,\s*([+-]?\d+\.?\d*))?\s*\)'
        matches = re.findall(pattern, text)
        if matches:
            trajectory = []
            for x, y, d in matches:
                trajectory.append((float(x), float(y), float(d) if d else 0.0))
            return [trajectory] if len(trajectory) >= 2 else None

        return None

    def predict_trajectory(self, image_path: str,
                           start_point: Dict[str, float],
                           target_point: Dict[str, float],
                           plot: bool = True,
                           temperature: float = 0.1) -> Dict:
        """
        预测从起点到目标点的 3D 轨迹 (英文 Prompt & 无障碍物)
        """
        x1, y1, d1 = start_point["x"], start_point["y"], start_point["depth"]
        xn, yn, dn = target_point["x"], target_point["y"], target_point["depth"]

        # 优化后的英文 Prompt
        prompt = f"""# Role
You are an expert Autonomous Driving Trajectory Planning Assistant.

# Task
Predict a sequence of 3D waypoints from the starting position to the target position to complete the task successfully.

# Input Data
- Starting Position (Start): ({x1:.1f}, {y1:.1f}, {d1:.3f})
- Target Position (Target): ({xn:.1f}, {yn:.1f}, {dn:.3f})

# Mandatory Constraints (STRICTLY FOLLOW)
1. **Exact Endpoints**: The first point in your list MUST be exactly ({x1:.1f}, {y1:.1f}, {d1:.3f}). The last point MUST be exactly ({xn:.1f}, {yn:.1f}, {dn:.3f}). Do not modify these values.
2. **Minimum Points**: The trajectory list must contain at least 10 points (including start and end).
3. **Smoothness**: Intermediate points must be evenly spaced. Ensure smooth interpolation without sudden jumps or sharp turns.
4. **Format**: Output MUST be a valid Python list of tuples. Example: [(x1, y1, d1), (x2, y2, d2), ...].

# Reasoning Step
Before generating the final list, briefly calculate:
1. The total delta between Start and Target.
2. The number of intermediate points needed.
3. Confirm the Start and Target values are locked.

# Final Answer
Output the Python list directly at the end.
"""

        print(f"\n{'='*60}")
        print("🤖 RoboBrain Trajectory Prediction (Optimized English)")
        print(f"{'='*60}")
        print(f"Start: ({x1:.1f}, {y1:.1f}, {d1:.3f})")
        print(f"Target: ({xn:.1f}, {yn:.1f}, {dn:.3f})")
        print(f"{'='*60}")
        
        # 打印完整 Prompt
        print(f"\n📋 完整 Prompt:")
        print("="*70)
        print(prompt)
        print("="*70)

        # 调用 inference 时设置 override_prompt=True，防止 Prompt 被覆盖
        result = self.inference(
            text=prompt,
            image=image_path,
            task="trajectory",
            plot=plot,
            do_sample=True,
            temperature=temperature,
            override_prompt=True  # 关键：使用自定义 Prompt
        )

        # 解析轨迹
        trajectory = self._parse_trajectory(result["answer"])
        flat_trajectory = trajectory[0] if trajectory else []

        # 后处理：检查起点和终点，如果差异较大则自动修正
        if len(flat_trajectory) >= 2:
            # 检查起点
            start_diff_x = abs(flat_trajectory[0][0] - x1)
            start_diff_y = abs(flat_trajectory[0][1] - y1)
            start_diff_d = abs(flat_trajectory[0][2] - d1)
            start_needs_fix = start_diff_x > 5 or start_diff_y > 5 or start_diff_d > 0.5
            
            # 检查终点
            end_diff_x = abs(flat_trajectory[-1][0] - xn)
            end_diff_y = abs(flat_trajectory[-1][1] - yn)
            end_diff_d = abs(flat_trajectory[-1][2] - dn)
            end_needs_fix = end_diff_x > 5 or end_diff_y > 5 or end_diff_d > 0.5
            
            if start_needs_fix:
                print(f"\n⚠️ 起点偏差较大 (Δx={start_diff_x:.1f}, Δy={start_diff_y:.1f}, Δd={start_diff_d:.3f})，自动修正")
                flat_trajectory[0] = (x1, y1, d1)
            else:
                print(f"\n✅ 起点预测准确 (Δx={start_diff_x:.1f}, Δy={start_diff_y:.1f}, Δd={start_diff_d:.3f})")
            
            if end_needs_fix:
                print(f"⚠️ 终点偏差较大 (Δx={end_diff_x:.1f}, Δy={end_diff_y:.1f}, Δd={end_diff_d:.3f})，自动修正")
                flat_trajectory[-1] = (xn, yn, dn)
            else:
                print(f"✅ 终点预测准确 (Δx={end_diff_x:.1f}, Δy={end_diff_y:.1f}, Δd={end_diff_d:.3f})")

        return {
            "start_point": (x1, y1, d1),
            "target_point": (xn, yn, dn),
            "trajectory": flat_trajectory,
            "raw_answer": result["answer"]
        }

    def draw_on_image(self, image_path: str, points: Optional[List[Tuple[int, int]]] = None,
                      boxes: Optional[List[List[int]]] = None,
                      trajectories: Optional[List[List[Tuple]]] = None,
                      output_path: Optional[str] = None,
                      coord_mode: str = "relative"):
        """
        在图像上绘制点、边界框和轨迹（增强可视化效果）
        - 轨迹点：带编号的圆圈
        - 轨迹线：渐变颜色 + 箭头
        - 起点/终点：特殊标记
        """
        try:
            image = cv2.imread(image_path)
            if image is None:
                raise FileNotFoundError(f"Unable to read image: {image_path}")

            h, w = image.shape[:2]

            def to_abs(x_val, y_val):
                """坐标转换逻辑"""
                if coord_mode == "absolute":
                    x, y = int(round(x_val)), int(round(y_val))
                    if x > w * 2 or y > h * 2:
                        print(f"⚠️ Warning: Coordinate ({x}, {y}) exceeds image size ({w}x{h}).")
                else:
                    x = int(round((x_val / 1000.0) * w))
                    y = int(round((y_val / 1000.0) * h))

                x = max(0, min(w - 1, x))
                y = max(0, min(h - 1, y))
                return x, y

            def draw_arrow(img, pt1, pt2, color, thickness=3, arrow_length=15, arrow_angle=30):
                """绘制带箭头的线段"""
                # 绘制主线
                cv2.line(img, pt1, pt2, color, thickness)
                
                # 计算箭头方向
                angle = np.arctan2(pt2[1] - pt1[1], pt2[0] - pt1[0])
                
                # 绘制两个箭头分支
                arrow_pt1 = (
                    int(pt2[0] - arrow_length * np.cos(angle - np.deg2rad(arrow_angle))),
                    int(pt2[1] - arrow_length * np.sin(angle - np.deg2rad(arrow_angle)))
                )
                arrow_pt2 = (
                    int(pt2[0] - arrow_length * np.cos(angle + np.deg2rad(arrow_angle))),
                    int(pt2[1] - arrow_length * np.sin(angle + np.deg2rad(arrow_angle)))
                )
                
                cv2.line(img, pt2, arrow_pt1, color, thickness)
                cv2.line(img, pt2, arrow_pt2, color, thickness)

            # 绘制轨迹（增强效果）
            if trajectories:
                for traj_idx, trajectory in enumerate(trajectories):
                    if not trajectory or len(trajectory) < 2:
                        continue

                    abs_pts = []
                    for p in trajectory:
                        x_val, y_val = p[0], p[1]
                        abs_pts.append(to_abs(x_val, y_val))

                    # 绘制轨迹线段（带箭头）
                    for i in range(1, len(abs_pts)):
                        # 渐变颜色：从起点到终点逐渐变化
                        t = i / (len(abs_pts) - 1)
                        segment_color = (
                            int(255 * (1 - t) + 0 * t),      # B
                            int(100 * (1 - t) + 200 * t),    # G
                            int(0 * (1 - t) + 255 * t)       # R
                        )
                        
                        # 绘制线段（带箭头）
                        draw_arrow(image, abs_pts[i - 1], abs_pts[i], segment_color, 
                                  thickness=3, arrow_length=12, arrow_angle=25)
                    
                    # 绘制轨迹点（带编号的圆圈）
                    for i, pt in enumerate(abs_pts):
                        # 起点和终点特殊标记
                        if i == 0:
                            # 起点：绿色大圆圈 + "S" 标签
                            cv2.circle(image, pt, 12, (0, 255, 0), -1)
                            cv2.circle(image, pt, 15, (0, 200, 0), 2)
                            cv2.putText(image, "S", (pt[0] - 8, pt[1] + 8),
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                        elif i == len(abs_pts) - 1:
                            # 终点：红色大圆圈 + "T" 标签
                            cv2.circle(image, pt, 12, (0, 0, 255), -1)
                            cv2.circle(image, pt, 15, (0, 0, 200), 2)
                            cv2.putText(image, "T", (pt[0] - 8, pt[1] + 8),
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                        else:
                            # 中间点：带编号的小圆圈
                            circle_color = (200, 200, 200)  # 灰色
                            cv2.circle(image, pt, 8, circle_color, -1)
                            cv2.circle(image, pt, 10, (150, 150, 150), 1)
                            
                            # 添加编号
                            cv2.putText(image, str(i), (pt[0] - 5, pt[1] + 5),
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

            # 绘制点
            if points:
                for point in points:
                    x_rel, y_rel = point
                    x, y = to_abs(x_rel, y_rel)
                    cv2.circle(image, (x, y), 8, (0, 0, 255), -1)

            # 绘制边界框
            if boxes:
                for box in boxes:
                    x1r, y1r, x2r, y2r = box
                    x1, y1 = to_abs(x1r, y1r)
                    x2, y2 = to_abs(x2r, y2r)
                    cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 3)

            if not output_path:
                name, ext = os.path.splitext(image_path)
                output_path = f"{name}_annotated{ext}"

            cv2.imwrite(output_path, image)
            print(f"Annotated image saved to: {output_path}")
            return output_path

        except Exception as e:
            print(f"Error processing image: {e}")
            return None


if __name__ == "__main__":
    print("=== Testing RoboBrain2.5-8B via vLLM API (Optimized English) ===")

    model = UnifiedInference(
        model_id="RoboBrain2.5-8B",
        base_url="http://localhost:8000/v1"
    )

    # 示例：使用优化后的 predict_trajectory 方法
    # 请确保此路径下有图片，否则修改为实际路径
    # image_path = "/workspace/wxd/Agent/images/test_navigation_2.png"
    image_path = "/workspace/wxd/Agent/images/frames/frame_0110.png"

    if os.path.exists(image_path):
        result = model.predict_trajectory(
            image_path=image_path,
            # start_point={"x": 451.0, "y": 468.0, "depth": 2.701},
            start_point={"x": 451.0, "y": 468.0, "depth": 2.701},
            target_point={"x": 273.2, "y": 143.6, "depth": 4.122},
            plot=True,
            temperature=0.1  # 低温度以保证稳定性
        )
        print(f"✅ Trajectory generated. Points count: {len(result['trajectory'])}")
        print(f"📄 Raw Output:\n{result['raw_answer']}")
    else:
        print(f"⚠️ Image file not found: {image_path}. Please update the path.")

