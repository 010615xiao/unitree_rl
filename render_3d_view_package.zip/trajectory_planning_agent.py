#!/usr/bin/env python3
"""
Trajectory Planning Agent (整合版)
基于 VLM 意图理解 + GroundingDINO 检测 + MoGe2 点云 + RoboBrain 轨迹预测

固定 Pipeline:
1. VLM 意图理解 - 解析用户指令，提取目标物体、关系型查询、序数词
2. GroundingDINO 检测 - 检测所有候选目标
3. MoGe2 深度估计 - 生成深度图和 3D 点云
4. 目标选择决策 - 根据意图选择最终目标（最近/最远/第 N 个/关系型）
5. RoboBrain 轨迹预测 - 从固定起点到目标点预测 3D 轨迹
6. 可视化输出 - 2D 检测结果 + 3D 点云轨迹
7. 文件输出 - 场景点云 + 轨迹点云 + JSON 数据

使用示例:
    python trajectory_planning_agent.py --image test.png --instruction "最远处的垃圾桶"
    python trajectory_planning_agent.py --image test.png --instruction "closest water dispenser"
    python trajectory_planning_agent.py --image test.png --instruction "second garbage can"
"""

import sys
import os
import json
import cv2
import numpy as np
import torch
import base64
from typing import Dict, List, Any, Optional, Tuple, Union
from openai import OpenAI

# 添加路径
sys.path.insert(0, "/workspace/wxd/Agent/Spagent/spagent/checkpoints")
sys.path.insert(0, "/workspace/wxd/Agent/Spagent/spagent/checkpoints/moge2/MoGe")

# ============== 配置常量 ==============
# 模型路径
GDINO_CKPT = "/workspace/wxd/Agent/Spagent/spagent/checkpoints/grounding_dino/groundingdino_swinb_cogcoor.pth"
GDINO_CONFIG = "/workspace/wxd/Agent/Spagent/spagent/spagent/external_experts/GroundingDINO/configs/GroundingDINO_SwinB_cfg.py"
MOGE2_CKPT = "/workspace/wxd/Agent/Spagent/spagent/checkpoints/moge2/moge-2-vitl-normal/model.pt"

# 检测阈值
BOX_THRESHOLD = 0.35
TEXT_THRESHOLD = 0.25

# 固定起点 2D 坐标
START_POINT_2D = (380, 400)

# 默认输出目录
DEFAULT_OUTPUT_DIR = "/workspace/wxd/Agent/images/trajectory_planning_results"


# ============== VLM 客户端 (意图理解) ==============
class VLMIntentClient:
    """VLM 客户端，用于解析用户指令意图（通过 RoboBrain API 统一调用）"""
    
    def __init__(self, base_url="http://localhost:8000/v1", model="RoboBrain2.5-8B"):
        self.client = OpenAI(base_url=base_url, api_key="not-needed")
        self.model = model
        print(f"🤖 VLM 意图理解客户端已初始化：{model} @ {base_url}")
    
    def health_check(self) -> Tuple[bool, str]:
        """检查 RoboBrain 服务状态"""
        try:
            models = self.client.models.list()
            return True, f"服务正常，可用模型：{[m.id for m in models.data]}"
        except Exception as e:
            return False, str(e)
    
    def parse_intent(self, instruction: str, image_path: str) -> Dict[str, Any]:
        """
        解析用户指令的意图
        
        识别:
        - 目标物体 (target_objects)
        - 关系型查询 (reference_object, relation_type)
        - 序数词 (ordinal)
        - 深度/位置属性 (depth_attribute, position_attribute)
        """
        with open(image_path, "rb") as f:
            import base64
            image_base64 = base64.b64encode(f.read()).decode('utf-8')
        
        prompt = f"""你是一个智能具身 Agent 的意图理解模块。请分析用户的指令，提取关键信息。

用户指令："{instruction}"

重要识别任务:
1. **目标物体**: 识别用户要找的物体类别（英文，如 "garbage can", "water dispenser", "chair"）
2. **关系型查询**:
   - 如果指令包含"closest to X"、"nearest to X"、"farthest from X"、"X 旁边的"、"X 附近的"等
   - 提取 reference_object (参考物体) 和 relation_type ("closest_to" / "farthest_from" / "next_to" 等)
3. **序数词**: 识别"first"、"second"、"third"、"第 1 个"、"第 2 个"、"第一个"、"第二个"等，提取序数 (1, 2, 3...)
4. **深度属性** (非常重要):
   - "farthest"、"furthest"、"最远"、"远处的"、"远端的" → depth_attribute = "farthest"
   - "nearest"、"closest"、"最近"、"近处的"、"近端的"、"旁边的"、"附近的" → depth_attribute = "nearest"
   - 注意："近处的 X" = "最近的 X"，"远处的 X" = "最远的 X"
5. **位置属性**:
   - "left"、"左边"、"左侧的" → position_attribute = "left"
   - "right"、"右边"、"右侧的" → position_attribute = "right"
   - "center"、"中间"、"中央的" → position_attribute = "center"

请输出 JSON 格式，包含以下字段:
- task_type: 任务类型 ("simple_selection" / "relational_selection" / "ordinal_selection")
- target_objects: 目标物体列表 (英文，如 ["garbage can", "chair", "sofa"])
- reference_object: 参考物体 (英文，关系型查询需要，如 "tent"，否则为 null)
- relation_type: 关系类型 ("closest_to" / "farthest_from" / "next_to" 等，否则为 null)
- ordinal: 序数 (int, 如 1, 2, 3...，默认为 1)
- depth_attribute: 深度属性 ("nearest" / "farthest" / null)
- position_attribute: 位置属性 ("left" / "right" / "center" / null)
- reasoning: 简要的推理说明（中文，解释为什么这样判断）

只输出 JSON，不要有其他内容。"""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}}
                ]}],
                max_tokens=600,
                temperature=0.1
            )
            
            result_text = response.choices[0].message.content.strip()
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()
            
            result = json.loads(result_text)
            result["original_instruction"] = instruction
            
            # 兼容处理
            if "target_object" in result and "target_objects" not in result:
                result["target_objects"] = [result["target_object"]]
            
            return result
            
        except Exception as e:
            print(f"⚠️ VLM 意图解析失败：{e}，使用默认解析")
            # 降级：简单提取目标物体
            instruction_lower = instruction.lower()
            
            # 深度属性判断
            depth_attr = None
            if any(word in instruction_lower or word in instruction for word in 
                   ["farthest", "furthest", "最远", "远处的", "远端的"]):
                depth_attr = "farthest"
            elif any(word in instruction_lower or word in instruction for word in 
                     ["nearest", "closest", "最近", "近处的", "近端的", "旁边的", "附近的"]):
                depth_attr = "nearest"
            
            # 目标物体提取（尝试提取最后一个名词）
            words = instruction.split()
            target = words[-1] if len(words) > 0 else instruction
            # 去除形容词后缀
            for suffix in ["的座椅", "的桌子", "的椅子", "的垃圾桶", "的饮水机"]:
                if target.endswith(suffix):
                    target = target[:-len(suffix)]
                    break
            
            return {
                "task_type": "simple_selection",
                "target_objects": [target],
                "reference_object": None,
                "relation_type": None,
                "ordinal": 1,
                "depth_attribute": depth_attr,
                "position_attribute": None,
                "reasoning": f"降级解析：{e}"
            }


# ============== 工具执行层 ==============
class ToolExecutor:
    """工具执行层：GroundingDINO 检测 + MoGe2 深度/点云"""
    
    def __init__(self, device=None):
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"🛠️  工具执行器已初始化，设备：{self.device}")
        self._gdino_model = None
        self._moge2_model = None
    
    def load_models(self):
        """懒加载模型"""
        if self._gdino_model is None:
            self._gdino_model = self._load_gdino()
        if self._moge2_model is None:
            self._moge2_model = self._load_moge2()
    
    def _load_gdino(self):
        """加载 GroundingDINO"""
        from groundingdino.util.inference import load_model
        print("🔄 加载 GroundingDINO 模型...")
        model = load_model(GDINO_CONFIG, GDINO_CKPT)
        print("✅ GroundingDINO 模型已加载")
        return model
    
    def _load_moge2(self):
        """加载 MoGe2"""
        from moge.model.v2 import MoGeModel
        print("🔄 加载 MoGe2 模型...")
        model = MoGeModel.from_pretrained(MOGE2_CKPT).to(self.device)
        model.eval()
        print("✅ MoGe2 模型已加载")
        return model
    
    def detect_with_gdino(self, image_path: str, target_object: str) -> List[Dict]:
        """使用 GroundingDINO 检测目标物体"""
        self.load_models()
        from groundingdino.util.inference import load_image, predict
        from torchvision.ops import box_convert
        
        print(f"🔍 检测目标：{target_object}")
        
        image_source, image = load_image(image_path)
        h, w, _ = image_source.shape
        
        boxes, logits, phrases = predict(
            model=self._gdino_model,
            image=image,
            caption=target_object,
            box_threshold=BOX_THRESHOLD,
            text_threshold=TEXT_THRESHOLD
        )
        
        if len(boxes) == 0:
            print("⚠️ 未检测到目标物体")
            return []
        
        # 转换为绝对坐标 (xyxy 格式)
        boxes_abs = boxes * torch.Tensor([w, h, w, h])
        boxes_xyxy = box_convert(boxes=boxes_abs, in_fmt="cxcywh", out_fmt="xyxy")
        
        results = []
        for box, logit, phrase in zip(boxes_xyxy, logits, phrases):
            box_list = box.tolist()
            results.append({
                "box": box_list,
                "confidence": logit.item(),
                "phrase": str(phrase),
                "center_x": (box_list[0] + box_list[2]) / 2,
                "center_y": (box_list[1] + box_list[3]) / 2
            })
            print(f"   检测到：{phrase} (置信度：{logit.item():.3f})")
            print(f"   边界框：x1={box_list[0]:.1f}, y1={box_list[1]:.1f}, x2={box_list[2]:.1f}, y2={box_list[3]:.1f}")
        
        return results
    
    def get_depth_and_pointcloud(self, image_path: str) -> Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
        """使用 MoGe2 获取深度图和点云"""
        self.load_models()
        print("🔄 生成深度图和 3D 点云...")

        image_bgr = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        h, w = image_rgb.shape[:2]

        input_tensor = torch.tensor(image_rgb / 255.0, dtype=torch.float32, device=self.device).permute(2, 0, 1)

        with torch.no_grad():
            output = self._moge2_model.infer(input_tensor)

        depth_map = output["depth"].cpu().numpy()
        point_cloud = output["points"].cpu().numpy()
        
        # 获取相机内参（如果模型输出）
        intrinsics = None
        if "intrinsics" in output:
            intrinsics = output["intrinsics"].cpu().numpy()
            print(f"✅ 相机内参已估算：fx={intrinsics[0,0]:.1f}, fy={intrinsics[1,1]:.1f}")

        print(f"✅ 深度图已生成：{w}x{h}, 深度范围 {depth_map.min():.2f}-{depth_map.max():.2f}米")
        print(f"✅ 点云已生成：{point_cloud.shape}, X 范围 [{point_cloud[:,:,0].min():.2f}, {point_cloud[:,:,0].max():.2f}]")

        return depth_map, point_cloud, intrinsics
    
    def compute_2d5_coords(self, detections: List[Dict], depth_map: np.ndarray, point_cloud: np.ndarray) -> List[Dict]:
        """为每个检测目标计算 2.5D 坐标 (2D + 深度 + 3D)"""
        results = []
        
        for i, det in enumerate(detections):
            box = det["box"]
            x1, y1, x2, y2 = box
            
            # 计算边界框中心
            center_x = det.get("center_x", (x1 + x2) / 2)
            center_y = det.get("center_y", (y1 + y2) / 2)
            
            # 在边界框区域内采样深度值
            x1_int, y1_int = max(0, int(x1)), max(0, int(y1))
            x2_int, y2_int = min(depth_map.shape[1], int(x2)), min(depth_map.shape[0], int(y2))
            
            region_depth = depth_map[y1_int:y2_int, x1_int:x2_int]
            
            if region_depth.size > 0:
                median_depth = float(np.median(region_depth))
                mean_depth = float(np.mean(region_depth))
                std_depth = float(np.std(region_depth))
                
                # 从点云获取 3D 坐标（边界框中心）
                point_3d = self._get_point_from_cloud(point_cloud, center_x, center_y)
                
                target_info = {
                    "id": i,
                    "x": center_x,
                    "y": center_y,
                    "depth": median_depth,
                    "point_3d": point_3d.tolist() if point_3d is not None else None,
                    "depth_mean": mean_depth,
                    "depth_std": std_depth,
                    "box": box,
                    "confidence": det["confidence"],
                    "phrase": det["phrase"]
                }
                results.append(target_info)
                
                print(f"\n   【目标 {i+1}】{det['phrase']} (置信度：{det['confidence']:.3f})")
                print(f"      2D 中心：({center_x:.1f}, {center_y:.1f})")
                print(f"      深度 (中位数): {median_depth:.3f} 米")
                if point_3d is not None:
                    print(f"      3D 坐标 (相机系): ({point_3d[0]:.3f}, {point_3d[1]:.3f}, {point_3d[2]:.3f})")
        
        return results
    
    def _get_point_depth(self, depth_map: np.ndarray, x: float, y: float, window_size: int = 1) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """获取指定点的深度值"""
        x_clamped = max(0, min(int(x), depth_map.shape[1] - 1))
        y_clamped = max(0, min(int(y), depth_map.shape[0] - 1))
        
        half_window = window_size
        x1, y1 = max(0, x_clamped - half_window), max(0, y_clamped - half_window)
        x2, y2 = min(depth_map.shape[1], x_clamped + half_window + 1), min(depth_map.shape[0], y_clamped + half_window + 1)
        
        region_depth = depth_map[y1:y2, x1:x2]
        
        if region_depth.size > 0:
            return float(np.median(region_depth)), float(np.mean(region_depth)), float(np.std(region_depth))
        return None, None, None
    
    def _get_point_from_cloud(self, point_cloud: np.ndarray, x: float, y: float) -> Optional[np.ndarray]:
        """从点云获取指定 2D 坐标的 3D 点"""
        x_clamped = max(0, min(int(x), point_cloud.shape[1] - 1))
        y_clamped = max(0, min(int(y), point_cloud.shape[0] - 1))
        
        point = point_cloud[y_clamped, x_clamped]
        if not np.isnan(point).any():
            return point
        return None
    
    def compute_start_point_2d5(self, depth_map: np.ndarray, point_cloud: np.ndarray, 
                                 start_2d: Tuple[int, int] = START_POINT_2D) -> Dict:
        """计算起点的 2.5D 坐标"""
        sx, sy = start_2d
        
        median_depth, mean_depth, std_depth = self._get_point_depth(depth_map, sx, sy)
        point_3d = self._get_point_from_cloud(point_cloud, sx, sy)
        
        if median_depth is not None:
            return {
                "x": float(sx),
                "y": float(sy),
                "depth": median_depth,
                "point_3d": point_3d.tolist() if point_3d is not None else None,
                "depth_mean": mean_depth,
                "depth_std": std_depth
            }
        
        return {"x": float(sx), "y": float(sy), "depth": 2.7}  # 默认深度


# ============== 决策层 ==============
class TrajectoryDecisionMaker:
    """轨迹规划决策层：根据意图选择目标"""
    
    def __init__(self, intent: Dict[str, Any]):
        self.intent = intent
        print(f"🧠 决策器已初始化，意图：{intent.get('task_type', 'unknown')}")
    
    def select_target(self, candidates: List[Dict], reference_candidates: Optional[List[Dict]] = None) -> Tuple[Optional[Dict], str]:
        """
        根据意图选择目标
        
        Returns:
            selected_target: 选中的目标
            reasoning: 决策理由
        """
        if not candidates:
            return None, "无候选目标"
        
        task_type = self.intent.get("task_type", "simple_selection")
        depth_attr = self.intent.get("depth_attribute")
        position_attr = self.intent.get("position_attribute")
        ordinal = self.intent.get("ordinal", 1)
        relation_type = self.intent.get("relation_type")
        
        print(f"\n🤔 开始决策...")
        print(f"   任务类型：{task_type}")
        print(f"   深度属性：{depth_attr}")
        print(f"   位置属性：{position_attr}")
        print(f"   序数：{ordinal}")
        print(f"   关系类型：{relation_type}")
        
        # 1. 关系型查询
        if relation_type and reference_candidates:
            return self._relational_select(candidates, reference_candidates, relation_type, ordinal)
        
        # 2. 序数词选择
        if ordinal > 1:
            return self._ordinal_select(candidates, ordinal)
        
        # 3. 深度属性选择
        if depth_attr:
            return self._depth_select(candidates, depth_attr)
        
        # 4. 位置属性选择
        if position_attr:
            return self._position_select(candidates, position_attr)
        
        # 5. 默认：选择第一个
        return candidates[0], "默认选择第一个候选目标"
    
    def _depth_select(self, candidates: List[Dict], depth_attr: str) -> Tuple[Dict, str]:
        """根据深度属性选择"""
        depths = [(i, c.get("depth", 0)) for i, c in enumerate(candidates)]
        
        if depth_attr == "farthest":
            best_idx, best_depth = max(depths, key=lambda x: x[1])
            return candidates[best_idx], f"选择深度最大的目标（深度={best_depth:.3f}米）"
        elif depth_attr == "nearest":
            best_idx, best_depth = min(depths, key=lambda x: x[1])
            return candidates[best_idx], f"选择深度最小的目标（深度={best_depth:.3f}米）"
        else:
            return candidates[0], f"未知深度属性'{depth_attr}'，默认选择第一个"
    
    def _position_select(self, candidates: List[Dict], position_attr: str) -> Tuple[Dict, str]:
        """根据位置属性选择"""
        # 按 x 坐标排序
        sorted_by_x = sorted(candidates, key=lambda c: c["x"])
        
        if position_attr == "left":
            return sorted_by_x[0], f"选择最左侧的目标（x={sorted_by_x[0]['x']:.1f}）"
        elif position_attr == "right":
            return sorted_by_x[-1], f"选择最右侧的目标（x={sorted_by_x[-1]['x']:.1f}）"
        elif position_attr == "center":
            # 选择 x 坐标最接近图像中心的
            mid_x = sorted_by_x[len(sorted_by_x) // 2]
            return mid_x, f"选择中间位置的目标（x={mid_x['x']:.1f}）"
        else:
            return candidates[0], f"未知位置属性'{position_attr}'，默认选择第一个"
    
    def _ordinal_select(self, candidates: List[Dict], ordinal: int) -> Tuple[Dict, str]:
        """序数词选择"""
        idx = min(ordinal - 1, len(candidates) - 1)
        idx = max(idx, 0)
        return candidates[idx], f"选择第{ordinal}个目标（共{len(candidates)}个）"
    
    def _relational_select(self, candidates: List[Dict], reference_candidates: List[Dict], 
                           relation_type: str, ordinal: int) -> Tuple[Dict, str]:
        """关系型查询：计算与参考物体的距离"""
        if not reference_candidates:
            return candidates[0], "无参考物体，默认选择第一个"
        
        ref = reference_candidates[0]
        ref_x, ref_y = ref["x"], ref["y"]
        ref_depth = ref["depth"]
        
        # 计算每个候选与参考物体的距离
        distances = []
        for i, cand in enumerate(candidates):
            dx = cand["x"] - ref_x
            dy = cand["y"] - ref_y
            ddepth = cand["depth"] - ref_depth
            
            dist_2d = (dx ** 2 + dy ** 2) ** 0.5
            combined_dist = dist_2d + abs(ddepth) * 100
            
            distances.append({
                "index": i,
                "distance_2d": dist_2d,
                "depth_diff": abs(ddepth),
                "combined_distance": combined_dist
            })
        
        # 根据关系类型排序
        if relation_type in ["closest_to", "nearest_to", "next_to"]:
            sorted_distances = sorted(distances, key=lambda x: x["combined_distance"])
            order_desc = "最近"
        elif relation_type in ["farthest_from"]:
            sorted_distances = sorted(distances, key=lambda x: x["combined_distance"], reverse=True)
            order_desc = "最远"
        else:
            sorted_distances = sorted(distances, key=lambda x: x["combined_distance"])
            order_desc = "最近"
        
        # 选择第 N 个
        selected_idx = min(max(ordinal - 1, 0), len(sorted_distances) - 1)
        best = sorted_distances[selected_idx]
        selected = candidates[best["index"]]
        
        reasoning = f"根据空间关系'{relation_type}'，计算每个候选与参考物体的距离，按{order_desc}到远排序。"
        reasoning += f"选择第{ordinal}个，即候选{best['index']}（2D 距离={best['distance_2d']:.1f}px）。"
        
        return selected, reasoning


# ============== RoboBrain 轨迹预测 ==============
class UnifiedInference:
    """
    使用 vLLM API 调用 RoboBrain 2.5 模型的统一推理类
    （完全集成 robobrain_trajectory_2.py 逻辑）
    """

    def __init__(self, base_url="http://localhost:8000/v1", model="RoboBrain2.5-8B"):
        print(f"🤖 RoboBrain 轨迹预测客户端已初始化：{model} @ {base_url}")
        self.model = model
        self.client = OpenAI(base_url=base_url, api_key="not-needed")
        self.base_url = base_url

        try:
            models = self.client.models.list()
            available_models = [m.id for m in models.data]
            print(f"✅ vLLM API 连接成功，可用模型：{available_models}")
        except Exception as e:
            print(f"⚠️ vLLM API 连接失败：{e}")

    def health_check(self) -> Tuple[bool, str]:
        """检查服务状态"""
        try:
            models = self.client.models.list()
            available = [m.id for m in models.data]
            if self.model in available or any(self.model in m for m in available):
                return True, f"服务正常，可用模型：{available}"
            return False, f"模型{self.model}不可用，可用：{available}"
        except Exception as e:
            return False, str(e)

    def inference(self, text: str, image: Union[list, str], task: str = "general",
                  plot: bool = False, do_sample: bool = True, temperature: float = 0.7,
                  override_prompt: bool = False):
        """
        使用 vLLM API 进行推理

        Args:
            override_prompt (bool): 如果为 True，则直接使用传入的 text，不添加任何默认后缀。
                                    对于轨迹预测，必须设置为 True。
        """
        if isinstance(image, str):
            image = [image]

        assert task in ["general", "pointing", "trajectory", "grounding"], \
            f"Invalid task type: {task}."

        # 只有当 override_prompt=False 时，才使用默认的 task 提示词增强
        if not override_prompt:
            if task == "pointing":
                text = f"{text}. Please provide its 2D coordinates. Your answer should be formatted as a tuple, i.e. [(x, y)]."
            elif task == "trajectory":
                text = f"{text}. Please predict 3D waypoints as list of tuples."
            elif task == "grounding":
                text = f"Please provide the bounding box coordinate: {text}."

        print(f"\n{'='*20} INPUT {'='*20}\n{text[:200]}...\n{'='*47}\n")

        # 构建消息
        image_content = []
        for img_path in image:
            if img_path.startswith("http"):
                image_content.append({"type": "image_url", "image_url": {"url": img_path}})
            else:
                with open(img_path, "rb") as f:
                    image_base64 = base64.b64encode(f.read()).decode('utf-8')
                ext = os.path.splitext(img_path)[1].lower()
                mime_type = 'image/png' if ext == '.png' else 'image/jpeg'
                image_content.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime_type};base64,{image_base64}"}
                })

        messages = [
            {
                "role": "user",
                "content": [*image_content, {"type": "text", "text": text}],
            },
        ]

        print("Running inference via vLLM API ...")
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=1024,  # 增加 token 数以容纳思维链
                temperature=temperature if do_sample else 0.0,
            )
            answer_text = response.choices[0].message.content.strip()
        except Exception as e:
            print(f"❌ vLLM API 调用失败：{e}")
            answer_text = f"Error: {e}"

        # 打印模型原始输出
        print(f"\n📝 模型原始输出:")
        print("="*70)
        print(answer_text)
        print("="*70)

        return {"answer": answer_text}

    def _parse_trajectory(self, text: str) -> List[List[Tuple]]:
        """
        健壮的轨迹解析函数，支持 CoT 和多种格式
        """
        import json
        import re

        # 1. 尝试寻找 JSON 列表结构
        start_idx = text.find('[')
        end_idx = text.rfind(']')

        if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
            list_str = text[start_idx : end_idx + 1]
            try:
                # 尝试直接解析 JSON (处理单引号替换)
                list_str_safe = list_str.replace("'", '"')
                data = json.loads(list_str_safe)
                if isinstance(data, list) and len(data) > 0:
                    trajectory = []
                    for point in data:
                        if isinstance(point, (list, tuple)) and len(point) >= 2:
                            x, y = float(point[0]), float(point[1])
                            d = float(point[2]) if len(point) > 2 else 0.0
                            trajectory.append((x, y, d))
                    return [trajectory] if trajectory else None
            except Exception as e:
                print(f"JSON parse failed, trying regex: {e}")

        # 2. 正则备份方案
        # 匹配 (x, y, d) 或 (x, y)
        pattern = r'\(\s*([+-]?\d+\.?\d*)\s*,\s*([+-]?\d+\.?\d*)\s*(?:,\s*([+-]?\d+\.?\d*))?\s*\)'
        matches = re.findall(pattern, text)
        if matches:
            trajectory = []
            for x, y, d in matches:
                trajectory.append((float(x), float(y), float(d) if d else 0.0))
            return [trajectory] if len(trajectory) >= 2 else None

        return None

    def predict_trajectory(self, image_path: str, start_point: Dict, target_point: Dict,
                           temperature: float = 0.1) -> List[Tuple[float, float, float]]:
        """
        预测从起点到目标点的 3D 轨迹（使用 robobrain_trajectory_2.py 的完整逻辑）
        """
        print(f"\n🤖 使用 RoboBrain 预测轨迹...")
        print(f"   起点：({start_point['x']:.1f}, {start_point['y']:.1f}, {start_point['depth']:.3f}m)")
        print(f"   目标点：({target_point['x']:.1f}, {target_point['y']:.1f}, {target_point['depth']:.3f}m)")

        # 提取坐标值用于 prompt
        x1, y1, d1 = start_point['x'], start_point['y'], start_point['depth']
        xn, yn, dn = target_point['x'], target_point['y'], target_point['depth']

        prompt = f"""# Role
You are an expert Autonomous Driving Trajectory Planning Assistant.

# Task
Predict a sequence of 3D waypoints from the starting position to the target position to complete the task successfully.

# Input Data
- Starting Position (Start): ({x1:.1f}, {y1:.1f}, {d1:.3f})
- Target Position (Target): ({xn:.1f}, {yn:.1f}, {dn:.3f})

# Mandatory Constraints (STRICTLY FOLLOW)
1. **Exact Endpoints**: The first point in your list MUST be exactly ({x1:.1f}, {y1:.1f}, {d1:.3f}). The last point MUST be exactly ({xn:.1f}, {yn:.1f}, {dn:.3f}). Do not modify these values.
2. **Minimum Points**: The trajectory list must contain at least 10 points (including start and end).
3. **Smoothness**: Intermediate points must be evenly spaced. Ensure smooth interpolation without sudden jumps or sharp turns.
4. **Format**: Output MUST be a valid Python list of tuples. Example: [(x1, y1, d1), (x2, y2, d2), ...].

# Reasoning Step
Before generating the final list, briefly calculate:
1. The total delta between Start and Target.
2. The number of intermediate points needed.
3. Confirm the Start and Target values are locked.

# Final Answer
Output the Python list directly at the end.
"""

        print(f"\n{'='*60}")
        print("🤖 RoboBrain Trajectory Prediction (Optimized English)")
        print(f"{'='*60}")
        print(f"Start: ({x1:.1f}, {y1:.1f}, {d1:.3f})")
        print(f"Target: ({xn:.1f}, {yn:.1f}, {dn:.3f})")
        print(f"{'='*60}")

        # 打印完整 Prompt
        print(f"\n📋 完整 Prompt:")
        print("="*70)
        print(prompt)
        print("="*70)

        # 调用 inference 时设置 override_prompt=True，防止 Prompt 被覆盖
        result = self.inference(
            text=prompt,
            image=image_path,
            task="trajectory",
            plot=False,
            do_sample=True,
            temperature=temperature,
            override_prompt=True  # 关键：使用自定义 Prompt
        )

        # 解析轨迹
        trajectory = self._parse_trajectory(result["answer"])
        flat_trajectory = trajectory[0] if trajectory else []

        # 后处理：检查起点和终点，如果差异较大则自动修正
        if len(flat_trajectory) >= 2:
            # 检查起点
            start_diff_x = abs(flat_trajectory[0][0] - x1)
            start_diff_y = abs(flat_trajectory[0][1] - y1)
            start_diff_d = abs(flat_trajectory[0][2] - d1)
            start_needs_fix = start_diff_x > 5 or start_diff_y > 5 or start_diff_d > 0.5

            # 检查终点
            end_diff_x = abs(flat_trajectory[-1][0] - xn)
            end_diff_y = abs(flat_trajectory[-1][1] - yn)
            end_diff_d = abs(flat_trajectory[-1][2] - dn)
            end_needs_fix = end_diff_x > 5 or end_diff_y > 5 or end_diff_d > 0.5

            if start_needs_fix:
                print(f"\n⚠️ 起点偏差较大 (Δx={start_diff_x:.1f}, Δy={start_diff_y:.1f}, Δd={start_diff_d:.3f})，自动修正")
                flat_trajectory[0] = (x1, y1, d1)
            else:
                print(f"\n✅ 起点预测准确 (Δx={start_diff_x:.1f}, Δy={start_diff_y:.1f}, Δd={start_diff_d:.3f})")

            if end_needs_fix:
                print(f"⚠️ 终点偏差较大 (Δx={end_diff_x:.1f}, Δy={end_diff_y:.1f}, Δd={end_diff_d:.3f})，自动修正")
                flat_trajectory[-1] = (xn, yn, dn)
            else:
                print(f"✅ 终点预测准确 (Δx={end_diff_x:.1f}, Δy={end_diff_y:.1f}, Δd={end_diff_d:.3f})")

        if flat_trajectory:
            print(f"✅ 轨迹预测完成，点数：{len(flat_trajectory)}")
            return flat_trajectory
        else:
            print("⚠️ 轨迹解析失败，使用线性插值")
            return self._linear_trajectory(start_point, target_point)

    def _linear_trajectory(self, start: Dict, target: Dict, num_points: int = 8) -> List[Tuple[float, float, float]]:
        """生成线性插值轨迹"""
        trajectory = []
        for i in range(num_points):
            t = i / (num_points - 1)
            x = start["x"] + t * (target["x"] - start["x"])
            y = start["y"] + t * (target["y"] - start["y"])
            d = start["depth"] + t * (target["depth"] - start["depth"])
            trajectory.append((x, y, d))
        return trajectory

    def draw_on_image(self, image_path: str, points: Optional[List[Tuple[int, int]]] = None,
                      boxes: Optional[List[List[int]]] = None,
                      trajectories: Optional[List[List[Tuple]]] = None,
                      output_path: Optional[str] = None,
                      coord_mode: str = "relative"):
        """
        在图像上绘制点、边界框和轨迹（增强可视化效果）
        - 轨迹点：带编号的圆圈
        - 轨迹线：渐变颜色 + 箭头
        - 起点/终点：特殊标记
        """
        try:
            image = cv2.imread(image_path)
            if image is None:
                raise FileNotFoundError(f"Unable to read image: {image_path}")

            h, w = image.shape[:2]

            def to_abs(x_val, y_val):
                """坐标转换逻辑"""
                if coord_mode == "absolute":
                    x, y = int(round(x_val)), int(round(y_val))
                    if x > w * 2 or y > h * 2:
                        print(f"⚠️ Warning: Coordinate ({x}, {y}) exceeds image size ({w}x{h}).")
                else:
                    x = int(round((x_val / 1000.0) * w))
                    y = int(round((y_val / 1000.0) * h))

                x = max(0, min(w - 1, x))
                y = max(0, min(h - 1, y))
                return x, y

            def draw_arrow(img, pt1, pt2, color, thickness=3, arrow_length=15, arrow_angle=30):
                """绘制带箭头的线段"""
                # 绘制主线
                cv2.line(img, pt1, pt2, color, thickness)

                # 计算箭头方向
                angle = np.arctan2(pt2[1] - pt1[1], pt2[0] - pt1[0])

                # 绘制两个箭头分支
                arrow_pt1 = (
                    int(pt2[0] - arrow_length * np.cos(angle - np.deg2rad(arrow_angle))),
                    int(pt2[1] - arrow_length * np.sin(angle - np.deg2rad(arrow_angle)))
                )
                arrow_pt2 = (
                    int(pt2[0] - arrow_length * np.cos(angle + np.deg2rad(arrow_angle))),
                    int(pt2[1] - arrow_length * np.sin(angle + np.deg2rad(arrow_angle)))
                )

                cv2.line(img, pt2, arrow_pt1, color, thickness)
                cv2.line(img, pt2, arrow_pt2, color, thickness)

            # 绘制轨迹（增强效果）
            if trajectories:
                for traj_idx, trajectory in enumerate(trajectories):
                    if not trajectory or len(trajectory) < 2:
                        continue

                    abs_pts = []
                    for p in trajectory:
                        x_val, y_val = p[0], p[1]
                        abs_pts.append(to_abs(x_val, y_val))

                    # 绘制轨迹线段（带箭头）
                    for i in range(1, len(abs_pts)):
                        # 渐变颜色：从起点到终点逐渐变化
                        t = i / (len(abs_pts) - 1)
                        segment_color = (
                            int(255 * (1 - t) + 0 * t),      # B
                            int(100 * (1 - t) + 200 * t),    # G
                            int(0 * (1 - t) + 255 * t)       # R
                        )

                        # 绘制线段（带箭头）
                        draw_arrow(image, abs_pts[i - 1], abs_pts[i], segment_color,
                                  thickness=3, arrow_length=12, arrow_angle=25)

                    # 绘制轨迹点（带编号的圆圈）
                    for i, pt in enumerate(abs_pts):
                        # 起点和终点特殊标记
                        if i == 0:
                            # 起点：绿色大圆圈 + "S" 标签
                            cv2.circle(image, pt, 12, (0, 255, 0), -1)
                            cv2.circle(image, pt, 15, (0, 200, 0), 2)
                            cv2.putText(image, "S", (pt[0] - 8, pt[1] + 8),
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                        elif i == len(abs_pts) - 1:
                            # 终点：红色大圆圈 + "T" 标签
                            cv2.circle(image, pt, 12, (0, 0, 255), -1)
                            cv2.circle(image, pt, 15, (0, 0, 200), 2)
                            cv2.putText(image, "T", (pt[0] - 8, pt[1] + 8),
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                        else:
                            # 中间点：带编号的小圆圈
                            circle_color = (200, 200, 200)  # 灰色
                            cv2.circle(image, pt, 8, circle_color, -1)
                            cv2.circle(image, pt, 10, (150, 150, 150), 1)

                            # 添加编号
                            cv2.putText(image, str(i), (pt[0] - 5, pt[1] + 5),
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

            # 绘制点
            if points:
                for point in points:
                    x_rel, y_rel = point
                    x, y = to_abs(x_rel, y_rel)
                    cv2.circle(image, (x, y), 8, (0, 0, 255), -1)

            # 绘制边界框
            if boxes:
                for box in boxes:
                    x1r, y1r, x2r, y2r = box
                    x1, y1 = to_abs(x1r, y1r)
                    x2, y2 = to_abs(x2r, y2r)
                    cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 3)

            if not output_path:
                name, ext = os.path.splitext(image_path)
                output_path = f"{name}_annotated{ext}"

            cv2.imwrite(output_path, image)
            print(f"Annotated image saved to: {output_path}")
            return output_path

        except Exception as e:
            print(f"Error processing image: {e}")
            return None


# ============== 可视化层 ==============
class TrajectoryVisualizer:
    """轨迹可视化：2D 检测 + 3D 点云轨迹"""
    
    def __init__(self, output_dir: str = DEFAULT_OUTPUT_DIR):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        print(f"📁 输出目录：{output_dir}")
    
    def visualize_2d_detection(self, image_path: str, candidates: List[Dict],
                                selected: Dict, instruction: str,
                                trajectory: Optional[List[Tuple[float, float, float]]] = None,
                                start_point: Optional[Dict] = None) -> str:
        """2D 检测结果可视化（支持中文显示 + 增强轨迹绘制）"""
        print("\n🎨 生成 2D 检测结果可视化...")

        # 加载中文字体
        from matplotlib import font_manager
        font_path = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
        if not os.path.exists(font_path):
            font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
        if not os.path.exists(font_path):
            font_path = None

        if font_path:
            font_prop = font_manager.FontProperties(fname=font_path, size=12)
        else:
            font_prop = None

        image = cv2.imread(image_path)
        h, w = image.shape[:2]

        # 绘制所有候选目标（蓝色框）
        for i, cand in enumerate(candidates):
            x1, y1, x2, y2 = map(int, cand["box"])
            cv2.rectangle(image, (x1, y1), (x2, y2), (255, 0, 0), 2)
            label = f"#{i} {cand['phrase']}"
            if "depth" in cand:
                label += f" {cand['depth']:.2f}m"
            # 使用 PIL 绘制中文标签
            self._cv2_add_chinese_text(image, (x1, y1 - 20), label, (255, 0, 0), font_prop)

        # 绘制选中目标（红色粗框）
        x1, y1, x2, y2 = map(int, selected["box"])
        cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 4)
        selected_label = f"SELECTED: {selected['phrase']} {selected['depth']:.2f}m"
        self._cv2_add_chinese_text(image, (x1, y1 - 25), selected_label, (0, 0, 255), font_prop, font_size=16)

        # 绘制起点（绿色圆圈）
        sx, sy = START_POINT_2D
        cv2.circle(image, (sx, sy), 15, (0, 255, 0), -1)
        cv2.putText(image, "START", (sx - 30, sy - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # 添加指令标题（使用 PIL 支持中文）
        self._cv2_add_chinese_text(image, (10, 30), f"Instruction: {instruction}", (255, 255, 255), font_prop, font_size=16)

        # 如果有轨迹数据，使用增强可视化绘制轨迹
        if trajectory and len(trajectory) >= 2:
            print("   绘制增强轨迹可视化...")
            self._draw_enhanced_trajectory(image, trajectory, w, h)

        # 保存
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_path = os.path.join(self.output_dir, f"{base_name}_2d_detection.png")
        cv2.imwrite(output_path, image)
        print(f"   ✅ 2D 可视化已保存：{output_path}")

        return output_path

    def _draw_enhanced_trajectory(self, image: np.ndarray, trajectory: List[Tuple[float, float, float]],
                                   width: int, height: int):
        """
        在图像上绘制增强轨迹（集成 robobrain_trajectory_2.py 逻辑）
        - 轨迹点：带编号的圆圈
        - 轨迹线：渐变颜色 + 箭头
        - 起点/终点：特殊标记
        """
        def to_abs(x_val, y_val):
            """坐标转换逻辑（绝对坐标）"""
            x, y = int(round(x_val)), int(round(y_val))
            x = max(0, min(width - 1, x))
            y = max(0, min(height - 1, y))
            return x, y

        def draw_arrow(img, pt1, pt2, color, thickness=3, arrow_length=15, arrow_angle=30):
            """绘制带箭头的线段"""
            cv2.line(img, pt1, pt2, color, thickness)
            angle = np.arctan2(pt2[1] - pt1[1], pt2[0] - pt1[0])
            arrow_pt1 = (
                int(pt2[0] - arrow_length * np.cos(angle - np.deg2rad(arrow_angle))),
                int(pt2[1] - arrow_length * np.sin(angle - np.deg2rad(arrow_angle)))
            )
            arrow_pt2 = (
                int(pt2[0] - arrow_length * np.cos(angle + np.deg2rad(arrow_angle))),
                int(pt2[1] - arrow_length * np.sin(angle + np.deg2rad(arrow_angle)))
            )
            cv2.line(img, pt2, arrow_pt1, color, thickness)
            cv2.line(img, pt2, arrow_pt2, color, thickness)

        abs_pts = [to_abs(pt[0], pt[1]) for pt in trajectory]

        # 绘制轨迹线段（带箭头和渐变颜色）
        for i in range(1, len(abs_pts)):
            t = i / (len(abs_pts) - 1)
            segment_color = (
                int(255 * (1 - t) + 0 * t),      # B
                int(100 * (1 - t) + 200 * t),    # G
                int(0 * (1 - t) + 255 * t)       # R
            )
            draw_arrow(image, abs_pts[i - 1], abs_pts[i], segment_color,
                      thickness=3, arrow_length=12, arrow_angle=25)

        # 绘制轨迹点（带编号的圆圈）
        for i, pt in enumerate(abs_pts):
            if i == 0:
                # 起点：绿色大圆圈 + "S" 标签
                cv2.circle(image, pt, 12, (0, 255, 0), -1)
                cv2.circle(image, pt, 15, (0, 200, 0), 2)
                cv2.putText(image, "S", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            elif i == len(abs_pts) - 1:
                # 终点：红色大圆圈 + "T" 标签
                cv2.circle(image, pt, 12, (0, 0, 255), -1)
                cv2.circle(image, pt, 15, (0, 0, 200), 2)
                cv2.putText(image, "T", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            else:
                # 中间点：带编号的小圆圈
                circle_color = (200, 200, 200)  # 灰色
                cv2.circle(image, pt, 8, circle_color, -1)
                cv2.circle(image, pt, 10, (150, 150, 150), 1)
                cv2.putText(image, str(i), (pt[0] - 5, pt[1] + 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    def _cv2_add_chinese_text(self, image, position, text, color=(0, 255, 0), font_prop=None, font_size=20):
        """在 OpenCV 图像上添加中文文本（使用 PIL）"""
        from PIL import Image, ImageDraw, ImageFont
        import numpy as np
        
        # BGR to RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        pil_image = Image.fromarray(image_rgb)
        draw = ImageDraw.Draw(pil_image)
        
        if font_prop:
            font = ImageFont.truetype(font_prop.fname, font_size)
        else:
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", font_size)
            except:
                font = ImageFont.load_default()
        
        draw.text(position, text, font=font, fill=color)
        
        # RGB to BGR
        image_array = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        image[:] = image_array
    
    def visualize_3d_trajectory(self, point_cloud: np.ndarray, image_path: str,
                                 trajectory: List[Tuple[float, float, float]],
                                 start_point: Dict, target_point: Dict) -> Dict[str, str]:
        """
        3D 点云轨迹可视化（左侧 3D 点云 + 右侧原始图像）

        Returns:
            输出文件路径字典
        """
        print("\n🎨 生成 3D 点云轨迹可视化...")

        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D

        # 准备点云数据
        image_bgr = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        h_orig, w_orig = image_bgr.shape[:2]

        points = point_cloud.reshape(-1, 3)
        image_small = cv2.resize(image_rgb, (point_cloud.shape[1], point_cloud.shape[0]))
        colors = image_small.reshape(-1, 3) / 255.0

        # 过滤无效点
        valid_mask = ~np.isnan(points[:, 0]) & ~np.isnan(points[:, 1]) & ~np.isnan(points[:, 2])
        points_valid = points[valid_mask]
        colors_valid = colors[valid_mask]

        # 创建轨迹 3D 点
        trajectory_3d = []
        for x, y, d in trajectory:
            x_clamped = max(0, min(int(x), point_cloud.shape[1] - 1))
            y_clamped = max(0, min(int(y), point_cloud.shape[0] - 1))
            base_point = point_cloud[y_clamped, x_clamped]

            if not np.isnan(base_point).any():
                direction = base_point / (np.linalg.norm(base_point) + 1e-6)
                trajectory_3d.append(direction * d)

        trajectory_3d_array = np.array(trajectory_3d) if len(trajectory_3d) >= 2 else None

        # 先创建左侧 3D 点云图（使用 matplotlib）
        # 调整 figsize 使 3D 图高度与原始图像匹配（假设 dpi=150）
        target_height_inches = h_orig / 150.0
        fig1 = plt.figure(figsize=(target_height_inches, target_height_inches))
        ax1 = fig1.add_subplot(111, projection='3d')

        # 降采样
        if len(points_valid) > 50000:
            indices = np.random.choice(len(points_valid), 50000, replace=False)
            points_display = points_valid[indices]
            colors_display = colors_valid[indices]
        else:
            points_display = points_valid
            colors_display = colors_valid

        ax1.scatter(points_display[:, 0], points_display[:, 1], points_display[:, 2],
                   c=colors_display, s=1, alpha=0.5, label='Point Cloud')

        # 绘制轨迹
        if trajectory_3d_array is not None:
            ax1.plot(trajectory_3d_array[:, 0], trajectory_3d_array[:, 1], trajectory_3d_array[:, 2],
                    'r-', linewidth=3, label='Trajectory')

            # 起点（绿色）
            ax1.scatter(trajectory_3d_array[0:1, 0], trajectory_3d_array[0:1, 1], trajectory_3d_array[0:1, 2],
                       c='green', s=80, marker='o', label='Start')
            # 终点（蓝色）
            ax1.scatter(trajectory_3d_array[-1:, 0], trajectory_3d_array[-1:, 1], trajectory_3d_array[-1:, 2],
                       c='blue', s=80, marker='^', label='Target')

            # 中间点
            if len(trajectory_3d_array) > 2:
                ax1.scatter(trajectory_3d_array[1:-1, 0], trajectory_3d_array[1:-1, 1], trajectory_3d_array[1:-1, 2],
                           c='yellow', s=40, marker='o', edgecolors='orange')

        ax1.set_xlabel('X (m)')
        ax1.set_ylabel('Y (m)')
        ax1.set_zlabel('Z (m)')
        ax1.set_title('3D Point Cloud with Trajectory')
        ax1.view_init(elev=20, azim=-60)

        # 保存 3D 图到临时文件
        import io
        temp_buffer_3d = io.BytesIO()
        plt.savefig(temp_buffer_3d, dpi=150, bbox_inches='tight', format='png')
        temp_buffer_3d.seek(0)
        image_3d = cv2.imdecode(np.frombuffer(temp_buffer_3d.getvalue(), dtype=np.uint8), cv2.IMREAD_COLOR)
        plt.close()

        # 右侧使用原始图像，并绘制轨迹
        image_2d = image_bgr.copy()

        # 添加标题
        cv2.putText(image_2d, 'Original Image with Trajectory', (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

        # 在 2D 图像上绘制轨迹
        print("   绘制增强轨迹可视化（渐变颜色 + 箭头 + 编号）...")
        self._draw_enhanced_trajectory_cv2(image_2d, trajectory, w_orig, h_orig)

        # 调整 3D 图高度与原始图像一致（保持原始图像不被压扁）
        h_3d, w_3d = image_3d.shape[:2]
        if h_3d != h_orig:
            image_3d = cv2.resize(image_3d, (w_3d, h_orig))

        # 水平拼接
        combined_image = np.hstack([image_3d, image_2d])

        # 保存可视化图像
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_3d_image = os.path.join(self.output_dir, f"{base_name}_3d_trajectory.png")
        cv2.imwrite(output_3d_image, combined_image)

        print(f"   ✅ 3D 可视化已保存：{output_3d_image}")

        # 保存点云文件（分开保存场景和轨迹）
        output_files = self._save_point_clouds(point_cloud, trajectory_3d_array, base_name, image_path)
        output_files['3d_image'] = output_3d_image

        return output_files

    def _draw_enhanced_trajectory_cv2(self, image: np.ndarray, trajectory: List[Tuple[float, float, float]],
                                       width: int, height: int):
        """
        在 OpenCV 图像上绘制增强轨迹（集成 robobrain_trajectory_2.py 逻辑）
        - 轨迹点：带编号的圆圈
        - 轨迹线：渐变颜色 + 箭头
        - 起点/终点：特殊标记
        
        Args:
            image: 原始图像（会被直接修改）
            trajectory: 轨迹点列表 [(x, y, d), ...]
            width: 图像宽度
            height: 图像高度
        """
        def to_abs(x_val, y_val):
            """坐标转换逻辑（绝对坐标）"""
            x, y = int(round(x_val)), int(round(y_val))
            x = max(0, min(width - 1, x))
            y = max(0, min(height - 1, y))
            return x, y

        def draw_arrow(img, pt1, pt2, color, thickness=3, arrow_length=15, arrow_angle=30):
            """绘制带箭头的线段"""
            cv2.line(img, pt1, pt2, color, thickness)
            angle = np.arctan2(pt2[1] - pt1[1], pt2[0] - pt1[0])
            arrow_pt1 = (
                int(pt2[0] - arrow_length * np.cos(angle - np.deg2rad(arrow_angle))),
                int(pt2[1] - arrow_length * np.sin(angle - np.deg2rad(arrow_angle)))
            )
            arrow_pt2 = (
                int(pt2[0] - arrow_length * np.cos(angle + np.deg2rad(arrow_angle))),
                int(pt2[1] - arrow_length * np.sin(angle + np.deg2rad(arrow_angle)))
            )
            cv2.line(img, pt2, arrow_pt1, color, thickness)
            cv2.line(img, pt2, arrow_pt2, color, thickness)

        if len(trajectory) < 2:
            return

        abs_pts = [to_abs(pt[0], pt[1]) for pt in trajectory]

        # 绘制轨迹线段（带箭头和渐变颜色）
        for i in range(1, len(abs_pts)):
            t = i / (len(abs_pts) - 1)
            segment_color = (
                int(255 * (1 - t) + 0 * t),      # B
                int(100 * (1 - t) + 200 * t),    # G
                int(0 * (1 - t) + 255 * t)       # R
            )
            draw_arrow(image, abs_pts[i - 1], abs_pts[i], segment_color,
                      thickness=3, arrow_length=12, arrow_angle=25)

        # 绘制轨迹点（带编号的圆圈）
        for i, pt in enumerate(abs_pts):
            if i == 0:
                # 起点：绿色大圆圈 + "S" 标签
                cv2.circle(image, pt, 12, (0, 255, 0), -1)
                cv2.circle(image, pt, 15, (0, 200, 0), 2)
                cv2.putText(image, "S", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            elif i == len(abs_pts) - 1:
                # 终点：红色大圆圈 + "T" 标签
                cv2.circle(image, pt, 12, (0, 0, 255), -1)
                cv2.circle(image, pt, 15, (0, 0, 200), 2)
                cv2.putText(image, "T", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            else:
                # 中间点：带编号的小圆圈
                circle_color = (200, 200, 200)  # 灰色
                cv2.circle(image, pt, 8, circle_color, -1)
                cv2.circle(image, pt, 10, (150, 150, 150), 1)
                cv2.putText(image, str(i), (pt[0] - 5, pt[1] + 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

    def render_view_from_trajectory(self, point_cloud: np.ndarray, image_path: str,
                                     trajectory: List[Tuple[float, float, float]],
                                     view_index: int = -2,
                                     depth_map: Optional[np.ndarray] = None,
                                     intrinsics: Optional[np.ndarray] = None,
                                     use_3d_orientation: bool = True) -> Optional[Dict[str, str]]:
        """
        从轨迹的指定点位置和朝向渲染新视角图像（点云渲染图 + 深度图）

        Args:
            point_cloud: MoGe2 生成的点云 [H, W, 3]，每个点是 (X, Y, Z) 相机坐标系（米）
            image_path: 原始图像路径
            trajectory: 轨迹点列表 [(x, y, depth), ...]，x/y 是像素坐标，depth 是深度（米）
            view_index: 要渲染的轨迹点索引（-2 表示倒数第二个点）
            depth_map: 深度图 [H, W]，可选，用于验证朝向计算
            intrinsics: 相机内参矩阵 [3, 3]，可选，用于更精确的 3D 坐标计算
            use_3d_orientation: 如果 True，使用 3D 空间坐标计算朝向；如果 False，使用像素坐标差（旧方法）

        Returns:
            输出文件路径字典 {"rendered_image": path, "depth_map": path}
        """
        print("\n🎨 渲染轨迹点新视角图像...")

        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        # 获取目标轨迹点
        target_idx = view_index if view_index >= 0 else len(trajectory) + view_index
        if target_idx < 0 or target_idx >= len(trajectory):
            print(f"   ⚠️ 轨迹点索引 {view_index} 超出范围，跳过渲染")
            return None

        target_point = trajectory[target_idx]
        target_pixel_x, target_pixel_y, target_depth = target_point
        print(f"   渲染位置：轨迹点 #{target_idx} (像素：{target_pixel_x:.1f}, {target_pixel_y:.1f}, 深度：{target_depth:.3f}m)")

        # 获取原始图像尺寸
        image_bgr = cv2.imread(image_path)
        h_orig, w_orig = image_bgr.shape[:2]
        h_pc, w_pc = point_cloud.shape[:2]

        print(f"   原始图像尺寸：{w_orig}x{h_orig}")
        print(f"   点云尺寸：{w_pc}x{h_pc}")

        # 相机内参
        if intrinsics is not None:
            # 使用 MoGe2 估算的真实内参（归一化→像素坐标）
            fx = intrinsics[0, 0] * w_orig
            fy = intrinsics[1, 1] * h_orig
            cx = intrinsics[0, 2] * w_orig
            cy = intrinsics[1, 2] * h_orig
            print(f"   相机内参（MoGe2 估算）：fx={fx:.1f}, fy={fy:.1f}, cx={cx:.1f}, cy={cy:.1f}")
        else:
            focal_length = w_orig / (2 * np.tan(np.deg2rad(60) / 2))
            cx, cy = w_orig / 2, h_orig / 2
            fx = fy = focal_length
            print(f"   相机内参（默认 FOV=60°）：fx=fy={focal_length:.1f}, cx={cx:.1f}, cy={cy:.1f}")

        # ============================================================
        # 计算朝向
        # ============================================================
        if use_3d_orientation:
            # 新方法：使用 3D 空间坐标计算朝向
            print("\n   使用 3D 空间坐标计算朝向")
            
            # 计算当前点的 3D 坐标
            cam_x = (target_pixel_x - cx) * target_depth / fx
            cam_y = (target_pixel_y - cy) * target_depth / fy
            cam_z = target_depth
            
            if target_idx < len(trajectory) - 1:
                # 朝向下一个点
                next_point = trajectory[target_idx + 1]
                next_x = (next_point[0] - cx) * next_point[2] / fx
                next_y = (next_point[1] - cy) * next_point[2] / fy
                next_z = next_point[2]
                
                dx = next_x - cam_x
                dy = next_y - cam_y
                dz = next_z - cam_z
                
                print(f"   朝向前进方向：下一个点 3D 坐标 ({next_x:.3f}, {next_y:.3f}, {next_z:.3f}) 米")
            elif target_idx > 0:
                # 朝向前一个点
                prev_point = trajectory[target_idx - 1]
                prev_x = (prev_point[0] - cx) * prev_point[2] / fx
                prev_y = (prev_point[1] - cy) * prev_point[2] / fy
                prev_z = prev_point[2]
                
                dx = prev_x - cam_x
                dy = prev_y - cam_y
                dz = prev_z - cam_z
                
                print(f"   朝向前一个点：上一个点 3D 坐标 ({prev_x:.3f}, {prev_y:.3f}, {prev_z:.3f}) 米")
            else:
                dx, dy, dz = 0, -1, 0
            
            # 归一化
            norm = np.sqrt(dx**2 + dy**2 + dz**2)
            if norm > 0:
                dx, dy, dz = dx/norm, dy/norm, dz/norm
            
            # 计算欧拉角
            yaw = np.arctan2(dy, dx)
            pitch = np.arcsin(-dz)
            
            print(f"   方向向量：({dx:.3f}, {dy:.3f}, {dz:.3f})")
            print(f"   欧拉角：yaw={np.degrees(yaw):.1f}°, pitch={np.degrees(pitch):.1f}°")
            
            # 3D 旋转矩阵（直接构造基向量）
            z_axis = np.array([dx, dy, dz])
            x_axis = np.cross([0, 0, 1], z_axis)
            x_norm = np.linalg.norm(x_axis)
            if x_norm > 1e-6:
                x_axis = x_axis / x_norm
            else:
                x_axis = np.array([1, 0, 0])
            y_axis = np.cross(z_axis, x_axis)
            R = np.array([x_axis, y_axis, z_axis])
            
            print(f"   旋转矩阵 R = [[{R[0,0]:.3f}, {R[0,1]:.3f}, {R[0,2]:.3f}],")
            print(f"                   [{R[1,0]:.3f}, {R[1,1]:.3f}, {R[1,2]:.3f}],")
            print(f"                   [{R[2,0]:.3f}, {R[2,1]:.3f}, {R[2,2]:.3f}]]")
        else:
            # 旧方法：使用像素坐标差计算 yaw
            print("\n   使用像素坐标差计算朝向（旧方法）")
            
            if target_idx < len(trajectory) - 1:
                next_point = trajectory[target_idx + 1]
                dx = next_point[0] - target_point[0]
                dy = next_point[1] - target_point[1]
            elif target_idx > 0:
                prev_point = trajectory[target_idx - 1]
                dx = prev_point[0] - target_point[0]
                dy = prev_point[1] - target_point[1]
            else:
                dx, dy = 0, -1

            yaw = np.arctan2(dy, dx) if (dx != 0 or dy != 0) else -np.pi/2
            
            # +90° 修正
            yaw_corrected = yaw + np.pi / 2
            
            print(f"   渲染视角：yaw={np.degrees(yaw):.1f}° → 修正后={np.degrees(yaw_corrected):.1f}°")
            
            # 2D 旋转矩阵
            cyaw, syaw = np.cos(yaw_corrected), np.sin(yaw_corrected)
            R = np.array([
                [cyaw, -syaw, 0],
                [syaw, cyaw, 0],
                [0, 0, 1]
            ])
            
            # 计算 3D 位置（从点云反投影）
            x_clamped = max(0, min(int(target_pixel_x), w_pc - 1))
            y_clamped = max(0, min(int(target_pixel_y), h_pc - 1))
            base_point = point_cloud[y_clamped, x_clamped].copy()

            if not np.isnan(base_point).any() and np.linalg.norm(base_point) > 0:
                direction = base_point / (np.linalg.norm(base_point) + 1e-6)
                cam_pos = direction * target_depth
            else:
                cam_x_fallback = (target_pixel_x - cx) * target_depth / fx
                cam_y_fallback = (target_pixel_y - cy) * target_depth / fy
                cam_pos = np.array([cam_x_fallback, cam_y_fallback, target_depth])

            cam_x, cam_y, cam_z = cam_pos

        print(f"   相机位置 (3D): ({cam_x:.3f}, {cam_y:.3f}, {cam_z:.3f}) 米")

        # ============================================================
        # 渲染：将点云变换到相机坐标系并投影
        # ============================================================
        print(f"\n   开始渲染...")

        # 调试：输出点云范围
        print(f"   点云 X 范围：[{point_cloud[:,:,0].min():.2f}, {point_cloud[:,:,0].max():.2f}]")
        print(f"   点云 Y 范围：[{point_cloud[:,:,1].min():.2f}, {point_cloud[:,:,1].max():.2f}]")
        print(f"   点云 Z 范围：[{point_cloud[:,:,2].min():.2f}, {point_cloud[:,:,2].max():.2f}]")

        # 1. 将点云重塑为 (N, 3)
        points = point_cloud.reshape(-1, 3).copy()

        # 2. 减去相机位置（平移）
        points[:, 0] -= cam_x
        points[:, 1] -= cam_y
        points[:, 2] -= cam_z

        # 3. 旋转到相机坐标系
        points_camera = points @ R.T

        # 4. 投影到 2D 图像平面
        # 只保留相机前方的点（Z > 0）
        valid_mask = points_camera[:, 2] > 0.01  # 近裁剪面

        valid_count = np.sum(valid_mask)
        print(f"   有效点数：{valid_count} / {len(points_camera)} ({100*valid_count/len(points_camera):.1f}%)")

        if valid_count == 0:
            print("   ⚠️ 没有有效的可见点（所有点都在相机后面），跳过渲染")
            return None

        points_cam_valid = points_camera[valid_mask]
        points_valid = points[valid_mask]
        valid_mask_orig = np.where(valid_mask)[0]

        # 5. 透视投影
        # 注意：相机坐标系中 X 向右，Y 向下，Z 向前
        # 投影公式：u = fx * X/Z + cx, v = fy * Y/Z + cy
        u = (points_cam_valid[:, 0] * fx / points_cam_valid[:, 2] + cx).astype(int)
        v = (points_cam_valid[:, 1] * fy / points_cam_valid[:, 2] + cy).astype(int)

        # 6. 过滤在图像外的点
        in_image = (u >= 0) & (u < w_orig) & (v >= 0) & (v < h_orig)
        in_image_count = np.sum(in_image)
        print(f"   图像内点数：{in_image_count} / {len(u)} ({100*in_image_count/len(u):.1f}%)")

        if in_image_count == 0:
            print("   ⚠️ 没有点在图像范围内，跳过渲染")
            return None

        u = u[in_image]
        v = v[in_image]
        points_cam_valid = points_cam_valid[in_image]
        points_valid = points_valid[in_image]
        valid_mask_orig = valid_mask_orig[in_image]

        # 7. 获取颜色（从原始图像获取，使用双线性插值改善画质）
        y_pc = (valid_mask_orig // w_pc).astype(float)
        x_pc = (valid_mask_orig % w_pc).astype(float)

        # 从原始图像获取颜色（使用插值）
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        image_resized = cv2.resize(image_rgb, (w_pc, h_pc), interpolation=cv2.INTER_LINEAR)
        colors = image_resized.reshape(-1, 3) / 255.0
        
        # 双线性插值获取颜色
        x0 = x_pc.astype(int)
        y0 = y_pc.astype(int)
        x1 = np.clip(x0 + 1, 0, w_pc - 1)
        y1 = np.clip(y0 + 1, 0, h_pc - 1)
        
        # 插值权重
        wx = x_pc - x0
        wy = y_pc - y0
        
        # 四个角的颜色
        c00 = colors[y0 * w_pc + x0]
        c01 = colors[y0 * w_pc + x1]
        c10 = colors[y1 * w_pc + x0]
        c11 = colors[y1 * w_pc + x1]
        
        # 双线性插值
        point_colors = (1-wx)[:,None]*(1-wy)[:,None]*c00 + \
                       wx[:,None]*(1-wy)[:,None]*c01 + \
                       (1-wx)[:,None]*wy[:,None]*c10 + \
                       wx[:,None]*wy[:,None]*c11

        # 8. 创建渲染图像（使用 z-buffer 处理遮挡，不做空洞填充）
        rendered_image = np.zeros((h_orig, w_orig, 3), dtype=np.float32)
        depth_rendered = np.zeros((h_orig, w_orig), dtype=np.float32)
        weight_map = np.zeros((h_orig, w_orig), dtype=np.float32)  # 用于加权平均

        # 按深度排序，从远到近绘制（画家算法）
        depths = points_cam_valid[:, 2]
        sort_indices = np.argsort(depths)[::-1]  # 从远到近

        draw_count = 0
        for idx in sort_indices:
            ui, vi = u[idx], v[idx]
            depth_val = depths[idx]
            color = point_colors[idx]

            # 如果这个像素还没有被绘制，或者当前点更近，则更新
            if depth_rendered[vi, ui] == 0 or depth_val < depth_rendered[vi, ui]:
                rendered_image[vi, ui] = color
                depth_rendered[vi, ui] = depth_val
                weight_map[vi, ui] = 1.0
                draw_count += 1

        print(f"   绘制像素数：{draw_count} / {w_orig * h_orig} ({100*draw_count/(w_orig*h_orig):.2f}%)")
        print(f"   空洞率：{100*(1 - draw_count/(w_orig*h_orig)):.1f}% (保持原始点云，不做填充)")

        # 颜色增强：gamma 校正 + 对比度增强（补偿点云稀疏导致的视觉偏暗）
        # 应用 gamma 校正（gamma=0.55 让图像更亮）
        gamma = 0.55
        rendered_image = np.power(rendered_image, 1/gamma)
        
        # 增加对比度（1.2 倍）
        rendered_image = rendered_image * 1.2
        
        # 裁剪到 [0, 1]
        rendered_image = np.clip(rendered_image, 0, 1)

        print(f"   颜色增强：gamma={gamma} (1/{gamma:.2f}={1/gamma:.2f}x), 对比度=1.2x")

        # 9. 保存渲染图像
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_rendered = os.path.join(self.output_dir, f"{base_name}_view{target_idx}_rendered.png")
        
        # 将渲染图像转换为 0-255
        rendered_image_uint8 = (np.clip(rendered_image, 0, 1) * 255).astype(np.uint8)
        cv2.imwrite(output_rendered, cv2.cvtColor(rendered_image_uint8, cv2.COLOR_RGB2BGR))
        print(f"   ✅ 渲染图像已保存：{output_rendered}")

        # 保存深度图（归一化到 0-255）
        depth_valid = depth_rendered[depth_rendered > 0]
        if len(depth_valid) > 0:
            depth_min = depth_valid.min()
            depth_max = depth_valid.max()
            depth_normalized = (depth_rendered - depth_min) / (depth_max - depth_min + 1e-6)
            depth_uint8 = (depth_normalized * 255).astype(np.uint8)

            # 使用彩色映射
            depth_colored = cv2.applyColorMap(depth_uint8, cv2.COLORMAP_INFERNO)

            output_depth = os.path.join(self.output_dir, f"{base_name}_view{target_idx}_depth.png")
            cv2.imwrite(output_depth, depth_colored)
            print(f"   ✅ 深度图已保存：{output_depth}")

            # ================================================================
            # 10. 生成渲染视角的点云文件（从新视角看到的点云）
            # ================================================================
            output_view_pcd = os.path.join(self.output_dir, f"{base_name}_view{target_idx}_rendered.ply")
            
            # 保存从新视角看到的点云（相机坐标系中的点 + 颜色）
            # 只保存图像内的有效点
            points_view = points_cam_valid.copy()  # 相机坐标系中的点
            colors_view = point_colors.copy()
            
            self._save_point_cloud_with_colors(points_view, colors_view, output_view_pcd)
            print(f"   ✅ 渲染视角点云已保存：{output_view_pcd} ({len(points_view)} 个点)")

            return {
                "rendered_image": output_rendered,
                "depth_map": output_depth,
                "rendered_point_cloud": output_view_pcd
            }

        return None

    def _save_point_cloud_with_colors(self, points: np.ndarray, colors: np.ndarray, output_path: str):
        """
        保存带颜色的点云为 PLY 文件
        
        Args:
            points: 点云坐标 [N, 3]
            colors: 点云颜色 [N, 3], 范围 0-1
            output_path: 输出文件路径
        """
        # 确保颜色在 0-255 范围
        colors_uint8 = (np.clip(colors, 0, 1) * 255).astype(np.uint8)
        
        # 创建结构化数组
        vertex_array = np.zeros(len(points), dtype=[
            ('x', 'f4'), ('y', 'f4'), ('z', 'f4'),
            ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')
        ])
        
        vertex_array['x'] = points[:, 0]
        vertex_array['y'] = points[:, 1]
        vertex_array['z'] = points[:, 2]
        vertex_array['red'] = colors_uint8[:, 0]
        vertex_array['green'] = colors_uint8[:, 1]
        vertex_array['blue'] = colors_uint8[:, 2]
        
        # 写入 PLY 文件
        with open(output_path, 'wb') as f:
            header = f"""ply
format binary_little_endian 1.0
element vertex {len(points)}
property float x
property float y
property float z
property uchar red
property uchar green
property uchar blue
end_header
""".encode('utf-8')
            f.write(header)
            f.write(vertex_array.tobytes())

    def _save_point_clouds(self, point_cloud: np.ndarray, trajectory_3d: Optional[np.ndarray],
                           base_name: str, image_path: str = None) -> Dict[str, str]:
        """保存场景点云和轨迹点云为独立 PLY 文件（完全集成 visualize_traj_3d.py 逻辑）"""
        print("\n💾 保存点云文件...")

        # 准备场景点云
        points = point_cloud.reshape(-1, 3)
        
        # 从原始图像获取颜色
        if image_path is None:
            image_path = "/workspace/wxd/Agent/images/test_6.png"
        image_bgr = cv2.resize(cv2.imread(image_path),
                               (point_cloud.shape[1], point_cloud.shape[0]))
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        colors = image_rgb.reshape(-1, 3) / 255.0

        valid_mask = ~np.isnan(points[:, 0]) & ~np.isnan(points[:, 1]) & ~np.isnan(points[:, 2])
        points_valid = points[valid_mask]
        colors_valid = colors[valid_mask]

        # 保存场景点云
        scene_pcd_path = os.path.join(self.output_dir, f"{base_name}_scene.ply")
        with open(scene_pcd_path, 'w') as f:
            f.write("ply\nformat ascii 1.0\n")
            f.write(f"element vertex {len(points_valid)}\n")
            f.write("property float x\nproperty float y\nproperty float z\n")
            f.write("property uchar red\nproperty uchar green\nproperty uchar blue\n")
            f.write("end_header\n")
            for pt, col in zip(points_valid, colors_valid):
                r, g, b = int(col[0] * 255), int(col[1] * 255), int(col[2] * 255)
                f.write(f"{pt[0]:.6f} {pt[1]:.6f} {pt[2]:.6f} {r} {g} {b}\n")
        print(f"   ✅ 场景点云：{scene_pcd_path} ({len(points_valid)} 个点)")

        # 保存轨迹点云
        traj_pcd_path = None
        if trajectory_3d is not None and len(trajectory_3d) > 0:
            traj_pcd_path = os.path.join(self.output_dir, f"{base_name}_trajectory.ply")
            
            # 轨迹点颜色：起点绿，中间黄，终点蓝
            traj_colors = np.zeros((len(trajectory_3d), 3))
            traj_colors[0] = [0, 1, 0]
            traj_colors[-1] = [0, 0, 1]
            if len(trajectory_3d) > 2:
                traj_colors[1:-1] = [1, 1, 0]
            
            with open(traj_pcd_path, 'w') as f:
                f.write("ply\nformat ascii 1.0\n")
                f.write(f"element vertex {len(trajectory_3d)}\n")
                f.write("property float x\nproperty float y\nproperty float z\n")
                f.write("property uchar red\nproperty uchar green\nproperty uchar blue\n")
                f.write("end_header\n")
                for pt, col in zip(trajectory_3d, traj_colors):
                    r, g, b = int(col[0] * 255), int(col[1] * 255), int(col[2] * 255)
                    f.write(f"{pt[0]:.6f} {pt[1]:.6f} {pt[2]:.6f} {r} {g} {b}\n")
            print(f"   ✅ 轨迹点云：{traj_pcd_path} ({len(trajectory_3d)} 个点)")
        
        # 保存轨迹 JSON
        traj_json_path = os.path.join(self.output_dir, f"{base_name}_trajectory.json")
        
        return {
            'scene_pcd': scene_pcd_path,
            'traj_pcd': traj_pcd_path,
            'traj_json': traj_json_path,
            'image_path': image_path
        }
    
    def save_json_result(self, image_path: str, result: Dict[str, Any]) -> str:
        """保存 JSON 结果"""
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        json_path = os.path.join(self.output_dir, f"{base_name}_result.json")
        
        # 简化输出（移除大数组）
        simplified = {
            "success": result.get("success", False),
            "instruction": result.get("instruction", ""),
            "intent": result.get("intent", {}),
            "start_point": result.get("start_point", {}),
            "selected_target": {k: v for k, v in result.get("selected_target", {}).items()},
            "trajectory": result.get("trajectory", []),
            "decision_reasoning": result.get("decision", {}).get("reasoning", ""),
            "output_files": result.get("output_files", {})
        }
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(simplified, f, indent=2, ensure_ascii=False, default=str)
        
        print(f"   ✅ JSON 结果：{json_path}")
        return json_path


# ============== 主 Agent ==============
class TrajectoryPlanningAgent:
    """轨迹规划主 Agent"""

    def __init__(self, base_url="http://localhost:8000/v1", model="RoboBrain2.5-8B",
                 output_dir=DEFAULT_OUTPUT_DIR):
        print("="*70)
        print("🚀 Trajectory Planning Agent 初始化")
        print("="*70)

        self.vlm = VLMIntentClient(base_url=base_url, model=model)
        self.executor = ToolExecutor()
        self.robobrain = UnifiedInference(base_url=base_url, model=model)
        self.visualizer = TrajectoryVisualizer(output_dir=output_dir)

        print(f"\n✅ Agent 初始化完成\n")
    
    def run(self, instruction: str, image_path: str, save_result: bool = True) -> Dict[str, Any]:
        """
        执行完整的轨迹规划 pipeline
        
        Args:
            instruction: 用户指令（如"最远处的垃圾桶"）
            image_path: 输入图像路径
            save_result: 是否保存结果
        
        Returns:
            完整结果字典
        """
        print("="*70)
        print(f"📋 用户指令：{instruction}")
        print(f"📷 输入图像：{image_path}")
        print("="*70)
        
        result = {
            "success": False,
            "instruction": instruction,
            "image_path": image_path
        }
        
        # Step 1: VLM 意图理解
        print("\n" + "="*70)
        print("Step 1: VLM 意图理解")
        print("="*70)
        
        intent = self.vlm.parse_intent(instruction, image_path)
        result["intent"] = intent
        print(f"✅ 意图解析完成：{intent.get('task_type', 'unknown')}")
        print(f"   目标物体：{intent.get('target_objects', [])}")
        print(f"   深度属性：{intent.get('depth_attribute')}")
        print(f"   序数：{intent.get('ordinal', 1)}")
        
        # Step 2: GroundingDINO 检测
        print("\n" + "="*70)
        print("Step 2: GroundingDINO 目标检测")
        print("="*70)
        
        target_objects = intent.get("target_objects", [])
        if not target_objects:
            result["error"] = "未识别到目标物体"
            return result
        
        # 检测主要目标
        main_target = target_objects[0]
        candidates = self.executor.detect_with_gdino(image_path, main_target)
        
        if not candidates:
            result["error"] = f"未检测到目标：{main_target}"
            return result
        
        result["candidates"] = candidates
        
        # Step 3: MoGe2 深度估计 + 点云生成
        print("\n" + "="*70)
        print("Step 3: MoGe2 深度估计与点云生成")
        print("="*70)

        depth_map, point_cloud, intrinsics = self.executor.get_depth_and_pointcloud(image_path)
        
        # 计算候选的 2.5D 坐标
        candidates_2d5 = self.executor.compute_2d5_coords(candidates, depth_map, point_cloud)
        result["candidates_2d5"] = candidates_2d5
        
        # 计算起点 2.5D 坐标
        start_point = self.executor.compute_start_point_2d5(depth_map, point_cloud)
        result["start_point"] = start_point
        print(f"\n📍 起点 2.5D 坐标：({start_point['x']:.1f}, {start_point['y']:.1f}, {start_point['depth']:.3f}m)")
        
        # Step 4: 决策 - 选择目标
        print("\n" + "="*70)
        print("Step 4: 目标选择决策")
        print("="*70)
        
        decision_maker = TrajectoryDecisionMaker(intent)

        # 如果有参考物体，检测参考物体
        reference_candidates = None
        if intent.get("reference_object"):
            ref_obj = intent["reference_object"]
            reference_candidates = self.executor.detect_with_gdino(image_path, ref_obj)
            if reference_candidates:
                # 计算参考物体的 2.5D 坐标（包含 x, y, depth 等键）
                reference_candidates = self.executor.compute_2d5_coords(reference_candidates, depth_map, point_cloud)
                result["reference_candidates"] = reference_candidates
        
        selected_target, reasoning = decision_maker.select_target(candidates_2d5, reference_candidates)
        
        if selected_target is None:
            result["error"] = "无法选择目标"
            return result
        
        result["selected_target"] = selected_target
        result["decision"] = {"reasoning": reasoning}
        print(f"\n✅ 选中目标：{selected_target['phrase']}")
        print(f"   2D 坐标：({selected_target['x']:.1f}, {selected_target['y']:.1f})")
        print(f"   深度：{selected_target['depth']:.3f}米")
        print(f"   理由：{reasoning}")
        
        # Step 5: RoboBrain 轨迹预测
        print("\n" + "="*70)
        print("Step 5: RoboBrain 轨迹预测")
        print("="*70)
        
        target_point = {
            "x": selected_target["x"],
            "y": selected_target["y"],
            "depth": selected_target["depth"]
        }
        
        trajectory = self.robobrain.predict_trajectory(image_path, start_point, target_point)
        result["trajectory"] = trajectory

        print(f"\n✅ 轨迹预测完成，共{len(trajectory)}个点")
        for i, pt in enumerate(trajectory):
            marker = " [START]" if i == 0 else (" [TARGET]" if i == len(trajectory) - 1 else "")
            print(f"   Point {i}: ({pt[0]:>7.1f}, {pt[1]:>7.1f}, {pt[2]:>7.3f}m){marker}")

        # 输出每个轨迹点的 3D 坐标和朝向
        print(f"\n📍 轨迹点 3D 坐标与朝向:")
        for i in range(len(trajectory)):
            pt = trajectory[i]
            
            # 3D 坐标（使用点云反投影）
            u, v = int(pt[0]), int(pt[1])
            depth = pt[2]
            # 从深度图获取该像素的深度
            if 0 <= v < depth_map.shape[0] and 0 <= u < depth_map.shape[1]:
                pt_depth = depth_map[v, u]
            else:
                pt_depth = depth
            
            # 反投影到 3D（使用相机内参）
            h, w = depth_map.shape
            focal_length = w / (2 * np.tan(np.deg2rad(60) / 2))
            cx, cy = w / 2, h / 2
            X = (u - cx) * pt_depth / focal_length
            Y = (v - cy) * pt_depth / focal_length
            Z = pt_depth
            
            marker = " [START]" if i == 0 else (" [TARGET]" if i == len(trajectory) - 1 else "")
            
            # 计算朝向（从当前点指向下一个点，最后一个点不计算）
            if i < len(trajectory) - 1:
                next_pt = trajectory[i+1]
                # 下一个点的 3D 坐标
                u_next, v_next = int(next_pt[0]), int(next_pt[1])
                if 0 <= v_next < depth_map.shape[0] and 0 <= u_next < depth_map.shape[1]:
                    next_depth = depth_map[v_next, u_next]
                else:
                    next_depth = next_pt[2]
                X_next = (u_next - cx) * next_depth / focal_length
                Y_next = (v_next - cy) * next_depth / focal_length
                Z_next = next_depth
                
                # 方向向量（从当前点指向下一个点）
                dx = X_next - X
                dy = Y_next - Y
                dz = Z_next - Z
                
                # 归一化方向向量
                norm = np.sqrt(dx**2 + dy**2 + dz**2)
                if norm > 0:
                    dx, dy, dz = dx/norm, dy/norm, dz/norm
                
                # 计算欧拉角（ZYX 顺序，即先绕 Z 轴 yaw，再绕 Y 轴 pitch，最后绕 X 轴 roll）
                # yaw: 绕 Z 轴旋转（水平方向）
                yaw = np.arctan2(dy, dx)
                # pitch: 绕 Y 轴旋转（俯仰角，向上为正）
                pitch = np.arcsin(-dz)  # dz 向前为正，所以取负
                # roll: 绕 X 轴旋转（假设地面运动，roll=0）
                roll = 0.0
                
                yaw_deg = np.degrees(yaw)
                pitch_deg = np.degrees(pitch)
                roll_deg = np.degrees(roll)
                
                # 计算旋转矩阵（从世界坐标系到相机坐标系的旋转）
                # R = Rz(yaw) * Ry(pitch) * Rx(roll)
                cyaw, syaw = np.cos(yaw), np.sin(yaw)
                cpitch, spitch = np.cos(pitch), np.sin(pitch)
                croll, sroll = np.cos(roll), np.sin(roll)
                
                R = np.array([
                    [cyaw*cpitch, cyaw*spitch*sroll - syaw*croll, cyaw*spitch*croll + syaw*sroll],
                    [syaw*cpitch, syaw*spitch*sroll + cyaw*croll, syaw*spitch*croll - cyaw*sroll],
                    [-spitch, cpitch*sroll, cpitch*croll]
                ])
                
                print(f"   Point {i}: 3D=({X:>7.3f}, {Y:>7.3f}, {Z:>7.3f})m, 欧拉角=(yaw={yaw_deg:>7.1f}°, pitch={pitch_deg:>7.1f}°, roll={roll_deg:>7.1f}°){marker}")
                print(f"             方向向量=({dx:>7.3f}, {dy:>7.3f}, {dz:>7.3f})")
                print(f"             旋转矩阵 R = [[{R[0,0]:>7.3f}, {R[0,1]:>7.3f}, {R[0,2]:>7.3f}],")
                print(f"                           [{R[1,0]:>7.3f}, {R[1,1]:>7.3f}, {R[1,2]:>7.3f}],")
                print(f"                           [{R[2,0]:>7.3f}, {R[2,1]:>7.3f}, {R[2,2]:>7.3f}]]")
            else:
                # 最后一个点（目标点），不计算朝向
                print(f"   Point {i}: 3D=({X:>7.3f}, {Y:>7.3f}, {Z:>7.3f})m [TARGET]")
        
        # Step 6: 可视化
        print("\n" + "="*70)
        print("Step 6: 可视化输出")
        print("="*70)

        # 2D 检测可视化（只绘制检测框和分割结果，不绘制轨迹）
        vis_2d_path = self.visualizer.visualize_2d_detection(
            image_path, candidates_2d5, selected_target, instruction,
            trajectory=None, start_point=start_point
        )
        result["output_files"] = {"2d_detection": vis_2d_path}

        # 3D 点云轨迹可视化（右侧 2D 图绘制轨迹）
        output_3d_files = self.visualizer.visualize_3d_trajectory(point_cloud, image_path, trajectory, start_point, target_point)
        result["output_files"].update(output_3d_files)

        # 从轨迹倒数第二个点渲染新视角图像
        if len(trajectory) >= 2:
            render_output = self.visualizer.render_view_from_trajectory(
                point_cloud, image_path, trajectory,
                view_index=-2,  # 倒数第二个点
                depth_map=depth_map  # 传入深度图用于验证
            )
            if render_output:
                result["output_files"].update(render_output)
        
        # Step 7: 保存完整 JSON 结果
        if save_result:
            print("\n" + "="*70)
            print("Step 7: 保存 JSON 结果")
            print("="*70)
            json_path = self.visualizer.save_json_result(image_path, result)
            result["output_files"]['json_result'] = json_path
        
        result["success"] = True
        
        # 输出摘要
        print("\n" + "="*70)
        print("📊 结果摘要")
        print("="*70)
        print(f"✅ 任务成功")
        print(f"   指令：{instruction}")
        print(f"   选中：{selected_target['phrase']} @ {selected_target['depth']:.3f}米")
        print(f"   轨迹点数：{len(trajectory)}")
        print(f"\n输出文件:")
        for key, path in result["output_files"].items():
            if path:
                print(f"   - {key}: {path}")
        
        return result


# ============== CLI 入口 ==============
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Trajectory Planning Agent - 轨迹规划 Agent")
    parser.add_argument("--image", type=str, default="/workspace/wxd/Agent/images/test_6.png",
                        help="输入图像路径")
    parser.add_argument("--instruction", type=str, default="farthest garbage can",
                        help="用户指令（如：'最远处的垃圾桶'、'closest water dispenser'、'second garbage can'）")
    parser.add_argument("--output_dir", type=str, default=DEFAULT_OUTPUT_DIR,
                        help="结果输出目录")
    parser.add_argument("--base_url", type=str, default="http://localhost:8000/v1",
                        help="RoboBrain 服务地址")
    parser.add_argument("--model", type=str, default="RoboBrain2.5-8B",
                        help="RoboBrain 模型名称")
    parser.add_argument("--no_save", action="store_true",
                        help="不保存结果")
    
    args = parser.parse_args()

    # 检查服务状态
    print("="*70)
    print("🔍 检查服务状态...")
    print("="*70)

    vlm_healthy, vlm_msg = VLMIntentClient(args.base_url, args.model).health_check()
    robobrain_healthy, robobrain_msg = UnifiedInference(args.base_url, args.model).health_check()

    if not vlm_healthy:
        print(f"⚠️ RoboBrain 服务不可用：{vlm_msg}")
    else:
        print(f"✅ RoboBrain 服务正常：{vlm_msg}")

    if not robobrain_healthy:
        print(f"⚠️ RoboBrain 服务不可用：{robobrain_msg}")
    else:
        print(f"✅ RoboBrain 服务正常：{robobrain_msg}")

    # 创建并运行 Agent
    agent = TrajectoryPlanningAgent(
        base_url=args.base_url,
        model=args.model,
        output_dir=args.output_dir
    )

    result = agent.run(
        instruction=args.instruction,
        image_path=args.image,
        save_result=not args.no_save
    )
