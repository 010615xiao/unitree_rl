#!/usr/bin/env python3
"""
测试增强的轨迹可视化效果
使用绝对坐标绘制轨迹，展示：
- 起点（绿色，标记"S"）
- 终点（红色，标记"T"）
- 中间点（灰色，带编号）
- 渐变颜色箭头线段
"""

import os
import cv2
import numpy as np
from robobrain_trajectory_2 import UnifiedInference

# 配置
IMAGE_PATH = "/workspace/wxd/Agent/images/test_navigation_2.png"
OUTPUT_DIR = "/workspace/wxd/Agent/images/trajcetory_results"

# 2.5D 坐标（从 get_2d5_coords.py 获取）
START_POINT = {"x": 451, "y": 468, "depth": 1.346}
TARGET_POINT = {"x": 586.3, "y": 237.5, "depth": 13.476}


def visualize_trajectory_enhanced(image_path, trajectory, output_path):
    """
    增强的轨迹可视化
    
    Args:
        image_path: 输入图像路径
        trajectory: 轨迹点列表 [(x, y, d), ...]
        output_path: 输出图像路径
    """
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return
    
    h, w = image.shape[:2]
    
    def draw_arrow(img, pt1, pt2, color, thickness=3, arrow_length=15, arrow_angle=30):
        """绘制带箭头的线段"""
        cv2.line(img, pt1, pt2, color, thickness)
        
        angle = np.arctan2(pt2[1] - pt1[1], pt2[0] - pt1[0])
        
        arrow_pt1 = (
            int(pt2[0] - arrow_length * np.cos(angle - np.deg2rad(arrow_angle))),
            int(pt2[1] - arrow_length * np.sin(angle - np.deg2rad(arrow_angle)))
        )
        arrow_pt2 = (
            int(pt2[0] - arrow_length * np.cos(angle + np.deg2rad(arrow_angle))),
            int(pt2[1] - arrow_length * np.sin(angle + np.deg2rad(arrow_angle)))
        )
        
        cv2.line(img, pt2, arrow_pt1, color, thickness)
        cv2.line(img, pt2, arrow_pt2, color, thickness)
    
    # 转换为绝对坐标
    abs_pts = [(int(pt[0]), int(pt[1])) for pt in trajectory]
    
    # 绘制轨迹线段（带箭头和渐变）
    for i in range(1, len(abs_pts)):
        t = i / (len(abs_pts) - 1)
        # 渐变颜色：蓝色 → 青色 → 绿色
        segment_color = (
            int(255 * (1 - t)),      # B
            int(100 + 155 * t),      # G
            int(0 + 255 * t)         # R
        )
        
        draw_arrow(image, abs_pts[i - 1], abs_pts[i], segment_color,
                  thickness=3, arrow_length=12, arrow_angle=25)
    
    # 绘制轨迹点
    for i, pt in enumerate(abs_pts):
        if i == 0:
            # 起点：绿色大圆圈 + "S" 标签
            cv2.circle(image, pt, 12, (0, 255, 0), -1)
            cv2.circle(image, pt, 15, (0, 200, 0), 2)
            cv2.putText(image, "S", (pt[0] - 8, pt[1] + 8),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        elif i == len(abs_pts) - 1:
            # 终点：红色大圆圈 + "T" 标签
            cv2.circle(image, pt, 12, (0, 0, 255), -1)
            cv2.circle(image, pt, 15, (0, 0, 200), 2)
            cv2.putText(image, "T", (pt[0] - 8, pt[1] + 8),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        else:
            # 中间点：带编号的小圆圈
            circle_color = (200, 200, 200)
            cv2.circle(image, pt, 8, circle_color, -1)
            cv2.circle(image, pt, 10, (150, 150, 150), 1)
            cv2.putText(image, str(i), (pt[0] - 5, pt[1] + 5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # 添加图例
    legend_y = 30
    cv2.putText(image, "Trajectory Visualization", (10, legend_y),
               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    # 起点图例
    cv2.circle(image, (15, legend_y + 25), 6, (0, 255, 0), -1)
    cv2.putText(image, "Start", (30, legend_y + 30),
               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # 终点图例
    cv2.circle(image, (100, legend_y + 25), 6, (0, 0, 255), -1)
    cv2.putText(image, "Target", (115, legend_y + 30),
               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # 保存结果
    cv2.imwrite(output_path, image)
    print(f"✅ 轨迹可视化已保存：{output_path}")
    return output_path


def main():
    print("=" * 60)
    print("🎨 增强轨迹可视化测试")
    print("=" * 60)
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # 方法 1: 使用 RoboBrain 预测轨迹并可视化
    print("\n📍 方法 1: 使用 RoboBrain 预测轨迹")
    print("-" * 60)
    
    model = UnifiedInference(
        model_id="RoboBrain2.5-8B",
        base_url="http://localhost:8000/v1"
    )
    
    result = model.predict_trajectory(
        image_path=IMAGE_PATH,
        start_point=START_POINT,
        target_point=TARGET_POINT,
        plot=True,
        temperature=0.1
    )
    
    print(f"\n📄 Raw Output:\n{result['raw_answer']}\n")
    
    output_path_1 = os.path.join(OUTPUT_DIR, "test_trajectory_v1.png")
    print(f"RoboBrain 预测轨迹点数：{len(result['trajectory'])}")
    print(f"轨迹：{result['trajectory']}")
    
    # 方法 2: 使用增强的可视化函数
    print("\n📍 方法 2: 使用增强可视化（独立函数）")
    print("-" * 60)
    
    # 使用预测的轨迹
    trajectory = result["trajectory"]
    output_path_2 = os.path.join(OUTPUT_DIR, "test_trajectory_v2_enhanced.png")
    visualize_trajectory_enhanced(IMAGE_PATH, trajectory, output_path_2)
    
    # 输出摘要
    print("\n" + "=" * 60)
    print("📊 结果摘要")
    print("=" * 60)
    print(f"起点：({START_POINT['x']}, {START_POINT['y']}, {START_POINT['depth']:.3f}m)")
    print(f"目标：({TARGET_POINT['x']:.1f}, {TARGET_POINT['y']:.1f}, {TARGET_POINT['depth']:.3f}m)")
    print(f"轨迹点数：{len(trajectory)}")
    print(f"\n输出文件:")
    print(f"  - RoboBrain 可视化：{output_path_1}")
    print(f"  - 增强可视化：{output_path_2}")
    
    # 打印轨迹详情
    print(f"\n轨迹详情:")
    for i, (x, y, d) in enumerate(trajectory):
        marker = "→ START" if i == 0 else ("→ TARGET" if i == len(trajectory) - 1 else "")
        print(f"  点{i}: ({x:>6.1f}, {y:>6.1f}, {d:>7.3f}m) {marker}")


if __name__ == "__main__":
    main()
