"""Sparse voxel fusion for RGB-D point cloud reconstruction.

This module keeps a persistent voxel map instead of appending every frame
forever. Surface hits first enter a candidate layer; only temporally stable
voxels are promoted to the exported map. Free-space samples along later depth
rays decrease occupancy for previously stored voxels, which helps stale
geometry fade out without using object detection or semantic deletion.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Set, Tuple

import numpy as np

VoxelKey = Tuple[int, int, int]
STATE_SCHEMA_VERSION = 1


def _cfg_get(config: Any, key: str, default: Any) -> Any:
    if config is None:
        return default
    if isinstance(config, dict):
        return config.get(key, default)
    return getattr(config, key, default)


@dataclass
class VoxelRecord:
    point_sum: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    color_sum: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float64))
    weight: float = 0.0
    hit_count: int = 0
    pixel_count: int = 0
    free_count: int = 0
    log_odds: float = 0.0
    first_seen_frame: Optional[Any] = None
    last_seen_frame: Optional[Any] = None
    first_seen_index: int = -1
    last_seen_index: int = -1
    is_stable: bool = False
    promoted_frame_index: Optional[int] = None
    inactive_candidate: bool = False
    inactive_frame_index: Optional[int] = None
    first_camera_center: Optional[np.ndarray] = None
    last_camera_center: Optional[np.ndarray] = None
    first_view_dir: Optional[np.ndarray] = None
    last_view_dir: Optional[np.ndarray] = None
    max_observation_baseline: float = 0.0
    max_view_angle_degrees: float = 0.0
    # Consecutive free-space streak for fast dynamic object cleanup
    consecutive_free_streak: int = 0


class SparseVoxelFusion:
    """Stateful sparse voxel fusion map.

    The implementation is intentionally geometry-only. It does not reason
    about object identities, categories, or lifecycle events.
    """

    def __init__(
        self,
        voxel_size: float,
        depth_min: float,
        depth_max: float,
        confidence_threshold: float = 0.0,
        min_hits: int = 2,
        min_weight: float = 2.0,
        occupancy_threshold: float = 0.0,
        hit_log_odds: float = 0.85,
        miss_log_odds: float = 0.55,
        min_log_odds: float = -4.0,
        max_log_odds: float = 5.0,
        free_space_carving: bool = True,
        ray_stride: int = 8,
        free_space_margin: float = 0.08,
        free_space_step: Optional[float] = None,
        max_free_depth: Optional[float] = 8.0,
        max_surface_points_per_frame: int = 250_000,
        require_stable_for_export: bool = True,
        min_observation_span: int = 0,
        candidate_max_age_frames: int = 30,
        prune_below_log_odds: float = -2.5,
        prune_min_free_count: int = 3,
        depth_edge_filter: bool = False,
        depth_edge_max_delta: float = 0.35,
        depth_weighting: bool = False,
        depth_weight_scale: float = 4.0,
        min_depth_weight: float = 0.25,
        complete_min_hits: int = 2,
        complete_min_weight: float = 1.0,
        complete_occupancy_threshold: float = 0.0,
        complete_max_free_hit_ratio: float = 1.0,
        retain_inactive_candidates_for_complete: bool = True,
        min_view_baseline_m: float = 0.0,
        min_view_angle_degrees: float = 0.0,
        consecutive_free_threshold: int = 3,
    ) -> None:
        if voxel_size <= 0:
            raise ValueError("voxel_size must be positive")
        if depth_max <= depth_min:
            raise ValueError("depth_max must be greater than depth_min")

        self.voxel_size = float(voxel_size)
        self.depth_min = float(depth_min)
        self.depth_max = float(depth_max)
        self.confidence_threshold = float(confidence_threshold)
        self.min_hits = int(min_hits)
        self.min_weight = float(min_weight)
        self.occupancy_threshold = float(occupancy_threshold)
        self.hit_log_odds = float(hit_log_odds)
        self.miss_log_odds = float(miss_log_odds)
        self.min_log_odds = float(min_log_odds)
        self.max_log_odds = float(max_log_odds)
        self.free_space_carving = bool(free_space_carving)
        self.ray_stride = max(1, int(ray_stride))
        self.free_space_margin = max(0.0, float(free_space_margin))
        step = free_space_step if free_space_step is not None else self.voxel_size * 2.0
        self.free_space_step = max(float(step), self.voxel_size)
        self.max_free_depth = None if max_free_depth is None else float(max_free_depth)
        self.max_surface_points_per_frame = max(0, int(max_surface_points_per_frame))
        self.require_stable_for_export = bool(require_stable_for_export)
        self.min_observation_span = max(0, int(min_observation_span))
        self.candidate_max_age_frames = max(0, int(candidate_max_age_frames))
        self.prune_below_log_odds = float(prune_below_log_odds)
        self.prune_min_free_count = max(0, int(prune_min_free_count))
        self.depth_edge_filter = bool(depth_edge_filter)
        self.depth_edge_max_delta = max(0.0, float(depth_edge_max_delta))
        self.depth_weighting = bool(depth_weighting)
        self.depth_weight_scale = max(1e-6, float(depth_weight_scale))
        self.min_depth_weight = float(np.clip(min_depth_weight, 0.0, 1.0))
        self.complete_min_hits = max(1, int(complete_min_hits))
        self.complete_min_weight = float(complete_min_weight)
        self.complete_occupancy_threshold = float(complete_occupancy_threshold)
        self.complete_max_free_hit_ratio = max(0.0, float(complete_max_free_hit_ratio))
        self.retain_inactive_candidates_for_complete = bool(retain_inactive_candidates_for_complete)
        self.min_view_baseline_m = max(0.0, float(min_view_baseline_m))
        self.min_view_angle_degrees = max(0.0, float(min_view_angle_degrees))
        self.consecutive_free_threshold = max(1, int(consecutive_free_threshold))

        self.records: Dict[VoxelKey, VoxelRecord] = {}
        self.frames_integrated = 0
        self.surface_pixels_integrated = 0
        self.surface_voxels_updated = 0
        self.free_voxels_updated = 0
        self.promoted_voxels = 0
        self.pruned_voxels = 0
        self.inactivated_candidate_voxels = 0

    @classmethod
    def from_config(
        cls,
        config: Any,
        voxel_size: float,
        depth_min: float,
        depth_max: float,
        confidence_threshold: float = 0.0,
    ) -> "SparseVoxelFusion":
        return cls(
            voxel_size=voxel_size,
            depth_min=depth_min,
            depth_max=depth_max,
            confidence_threshold=confidence_threshold,
            min_hits=_cfg_get(config, "min_hits", 2),
            min_weight=_cfg_get(config, "min_weight", 2.0),
            occupancy_threshold=_cfg_get(config, "occupancy_threshold", 0.0),
            hit_log_odds=_cfg_get(config, "hit_log_odds", 0.85),
            miss_log_odds=_cfg_get(config, "miss_log_odds", 0.55),
            min_log_odds=_cfg_get(config, "min_log_odds", -4.0),
            max_log_odds=_cfg_get(config, "max_log_odds", 5.0),
            free_space_carving=_cfg_get(config, "free_space_carving", True),
            ray_stride=_cfg_get(config, "ray_stride", 8),
            free_space_margin=_cfg_get(config, "free_space_margin", 0.08),
            free_space_step=_cfg_get(config, "free_space_step", None),
            max_free_depth=_cfg_get(config, "max_free_depth", 8.0),
            max_surface_points_per_frame=_cfg_get(config, "max_surface_points_per_frame", 250_000),
            require_stable_for_export=_cfg_get(config, "require_stable_for_export", True),
            min_observation_span=_cfg_get(config, "min_observation_span", 0),
            candidate_max_age_frames=_cfg_get(config, "candidate_max_age_frames", 30),
            prune_below_log_odds=_cfg_get(config, "prune_below_log_odds", -2.5),
            prune_min_free_count=_cfg_get(config, "prune_min_free_count", 3),
            depth_edge_filter=_cfg_get(config, "depth_edge_filter", False),
            depth_edge_max_delta=_cfg_get(config, "depth_edge_max_delta", 0.35),
            depth_weighting=_cfg_get(config, "depth_weighting", False),
            depth_weight_scale=_cfg_get(config, "depth_weight_scale", 4.0),
            min_depth_weight=_cfg_get(config, "min_depth_weight", 0.25),
            complete_min_hits=_cfg_get(config, "complete_min_hits", 2),
            complete_min_weight=_cfg_get(config, "complete_min_weight", 1.0),
            complete_occupancy_threshold=_cfg_get(config, "complete_occupancy_threshold", 0.0),
            complete_max_free_hit_ratio=_cfg_get(config, "complete_max_free_hit_ratio", 1.0),
            retain_inactive_candidates_for_complete=_cfg_get(
                config, "retain_inactive_candidates_for_complete", True
            ),
            min_view_baseline_m=_cfg_get(config, "min_view_baseline_m", 0.0),
            min_view_angle_degrees=_cfg_get(config, "min_view_angle_degrees", 0.0),
            consecutive_free_threshold=_cfg_get(config, "consecutive_free_threshold", 3),
        )

    def _constructor_params(self) -> Dict[str, Any]:
        return {
            "voxel_size": self.voxel_size,
            "depth_min": self.depth_min,
            "depth_max": self.depth_max,
            "confidence_threshold": self.confidence_threshold,
            "min_hits": self.min_hits,
            "min_weight": self.min_weight,
            "occupancy_threshold": self.occupancy_threshold,
            "hit_log_odds": self.hit_log_odds,
            "miss_log_odds": self.miss_log_odds,
            "min_log_odds": self.min_log_odds,
            "max_log_odds": self.max_log_odds,
            "free_space_carving": self.free_space_carving,
            "ray_stride": self.ray_stride,
            "free_space_margin": self.free_space_margin,
            "free_space_step": self.free_space_step,
            "max_free_depth": self.max_free_depth,
            "max_surface_points_per_frame": self.max_surface_points_per_frame,
            "require_stable_for_export": self.require_stable_for_export,
            "min_observation_span": self.min_observation_span,
            "candidate_max_age_frames": self.candidate_max_age_frames,
            "prune_below_log_odds": self.prune_below_log_odds,
            "prune_min_free_count": self.prune_min_free_count,
            "depth_edge_filter": self.depth_edge_filter,
            "depth_edge_max_delta": self.depth_edge_max_delta,
            "depth_weighting": self.depth_weighting,
            "depth_weight_scale": self.depth_weight_scale,
            "min_depth_weight": self.min_depth_weight,
            "complete_min_hits": self.complete_min_hits,
            "complete_min_weight": self.complete_min_weight,
            "complete_occupancy_threshold": self.complete_occupancy_threshold,
            "complete_max_free_hit_ratio": self.complete_max_free_hit_ratio,
            "retain_inactive_candidates_for_complete": self.retain_inactive_candidates_for_complete,
            "min_view_baseline_m": self.min_view_baseline_m,
            "min_view_angle_degrees": self.min_view_angle_degrees,
            "consecutive_free_threshold": self.consecutive_free_threshold,
        }

    def _counter_state(self) -> Dict[str, int]:
        return {
            "frames_integrated": self.frames_integrated,
            "surface_pixels_integrated": self.surface_pixels_integrated,
            "surface_voxels_updated": self.surface_voxels_updated,
            "free_voxels_updated": self.free_voxels_updated,
            "promoted_voxels": self.promoted_voxels,
            "pruned_voxels": self.pruned_voxels,
            "inactivated_candidate_voxels": self.inactivated_candidate_voxels,
        }

    def save_state(self, path: Any) -> None:
        """Persist the full sparse voxel map state to a compressed NPZ file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        items = list(self.records.items())
        n = len(items)
        keys = np.empty((n, 3), dtype=np.int64)
        point_sum = np.empty((n, 3), dtype=np.float64)
        color_sum = np.empty((n, 3), dtype=np.float64)
        weight = np.empty(n, dtype=np.float64)
        hit_count = np.empty(n, dtype=np.int64)
        pixel_count = np.empty(n, dtype=np.int64)
        free_count = np.empty(n, dtype=np.int64)
        log_odds = np.empty(n, dtype=np.float64)
        first_seen_index = np.empty(n, dtype=np.int64)
        last_seen_index = np.empty(n, dtype=np.int64)
        is_stable = np.empty(n, dtype=bool)
        promoted_frame_index = np.empty(n, dtype=np.int64)
        inactive_candidate = np.empty(n, dtype=bool)
        inactive_frame_index = np.empty(n, dtype=np.int64)
        first_camera_center = np.full((n, 3), np.nan, dtype=np.float64)
        last_camera_center = np.full((n, 3), np.nan, dtype=np.float64)
        first_view_dir = np.full((n, 3), np.nan, dtype=np.float64)
        last_view_dir = np.full((n, 3), np.nan, dtype=np.float64)
        max_observation_baseline = np.empty(n, dtype=np.float64)
        max_view_angle_degrees = np.empty(n, dtype=np.float64)
        consecutive_free_streak = np.empty(n, dtype=np.int64)
        first_seen_frames = []
        last_seen_frames = []

        for idx, (key, record) in enumerate(items):
            keys[idx] = key
            point_sum[idx] = np.asarray(record.point_sum, dtype=np.float64)
            color_sum[idx] = np.asarray(record.color_sum, dtype=np.float64)
            weight[idx] = float(record.weight)
            hit_count[idx] = int(record.hit_count)
            pixel_count[idx] = int(record.pixel_count)
            free_count[idx] = int(record.free_count)
            log_odds[idx] = float(record.log_odds)
            first_seen_index[idx] = int(record.first_seen_index)
            last_seen_index[idx] = int(record.last_seen_index)
            is_stable[idx] = bool(record.is_stable)
            promoted_frame_index[idx] = self._optional_int_to_sentinel(record.promoted_frame_index)
            inactive_candidate[idx] = bool(record.inactive_candidate)
            inactive_frame_index[idx] = self._optional_int_to_sentinel(record.inactive_frame_index)
            self._write_optional_vector(first_camera_center, idx, record.first_camera_center)
            self._write_optional_vector(last_camera_center, idx, record.last_camera_center)
            self._write_optional_vector(first_view_dir, idx, record.first_view_dir)
            self._write_optional_vector(last_view_dir, idx, record.last_view_dir)
            max_observation_baseline[idx] = float(record.max_observation_baseline)
            max_view_angle_degrees[idx] = float(record.max_view_angle_degrees)
            consecutive_free_streak[idx] = int(record.consecutive_free_streak)
            first_seen_frames.append(self._json_safe_frame_id(record.first_seen_frame))
            last_seen_frames.append(self._json_safe_frame_id(record.last_seen_frame))

        metadata = {
            "schema_version": STATE_SCHEMA_VERSION,
            "params": self._constructor_params(),
            "counters": self._counter_state(),
            "first_seen_frames": first_seen_frames,
            "last_seen_frames": last_seen_frames,
        }
        metadata_text = json.dumps(metadata, ensure_ascii=False)

        with path.open("wb") as f:
            np.savez_compressed(
                f,
                metadata=np.asarray(metadata_text),
                keys=keys,
                point_sum=point_sum,
                color_sum=color_sum,
                weight=weight,
                hit_count=hit_count,
                pixel_count=pixel_count,
                free_count=free_count,
                log_odds=log_odds,
                first_seen_index=first_seen_index,
                last_seen_index=last_seen_index,
                is_stable=is_stable,
                promoted_frame_index=promoted_frame_index,
                inactive_candidate=inactive_candidate,
                inactive_frame_index=inactive_frame_index,
                first_camera_center=first_camera_center,
                last_camera_center=last_camera_center,
                first_view_dir=first_view_dir,
                last_view_dir=last_view_dir,
                max_observation_baseline=max_observation_baseline,
                max_view_angle_degrees=max_view_angle_degrees,
                consecutive_free_streak=consecutive_free_streak,
            )

    @classmethod
    def load_state(cls, path: Any) -> "SparseVoxelFusion":
        """Load a sparse voxel map previously written by :meth:`save_state`."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Voxel fusion state does not exist: {path}")

        with np.load(path, allow_pickle=False) as data:
            metadata = json.loads(str(data["metadata"].item()))
            params = dict(metadata.get("params", {}))
            fusion = cls(**params)

            counters = metadata.get("counters", {})
            for name in fusion._counter_state().keys():
                if name in counters:
                    setattr(fusion, name, int(counters[name]))

            keys = np.asarray(data["keys"], dtype=np.int64).reshape(-1, 3)
            first_seen_frames = metadata.get("first_seen_frames", [])
            last_seen_frames = metadata.get("last_seen_frames", [])

            for idx, raw_key in enumerate(keys):
                key = (int(raw_key[0]), int(raw_key[1]), int(raw_key[2]))
                record = VoxelRecord(
                    point_sum=np.asarray(data["point_sum"][idx], dtype=np.float64).copy(),
                    color_sum=np.asarray(data["color_sum"][idx], dtype=np.float64).copy(),
                    weight=float(data["weight"][idx]),
                    hit_count=int(data["hit_count"][idx]),
                    pixel_count=int(data["pixel_count"][idx]),
                    free_count=int(data["free_count"][idx]),
                    log_odds=float(data["log_odds"][idx]),
                    first_seen_frame=first_seen_frames[idx] if idx < len(first_seen_frames) else None,
                    last_seen_frame=last_seen_frames[idx] if idx < len(last_seen_frames) else None,
                    first_seen_index=int(data["first_seen_index"][idx]),
                    last_seen_index=int(data["last_seen_index"][idx]),
                    is_stable=bool(data["is_stable"][idx]),
                    promoted_frame_index=cls._sentinel_to_optional_int(data["promoted_frame_index"][idx]),
                    inactive_candidate=bool(data["inactive_candidate"][idx]),
                    inactive_frame_index=cls._sentinel_to_optional_int(data["inactive_frame_index"][idx]),
                    first_camera_center=cls._optional_vector_from_row(data["first_camera_center"][idx]),
                    last_camera_center=cls._optional_vector_from_row(data["last_camera_center"][idx]),
                    first_view_dir=cls._optional_vector_from_row(data["first_view_dir"][idx]),
                    last_view_dir=cls._optional_vector_from_row(data["last_view_dir"][idx]),
                    max_observation_baseline=float(data["max_observation_baseline"][idx]),
                    max_view_angle_degrees=float(data["max_view_angle_degrees"][idx]),
                    consecutive_free_streak=int(data["consecutive_free_streak"][idx]) if "consecutive_free_streak" in data else 0,
                )
                fusion.records[key] = record

        return fusion

    @staticmethod
    def _json_safe_frame_id(value: Optional[Any]) -> Optional[Any]:
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        return str(value)

    @staticmethod
    def _optional_int_to_sentinel(value: Optional[int]) -> int:
        return -1 if value is None else int(value)

    @staticmethod
    def _sentinel_to_optional_int(value: Any) -> Optional[int]:
        value = int(value)
        return None if value < 0 else value

    @staticmethod
    def _write_optional_vector(target: np.ndarray, idx: int, value: Optional[np.ndarray]) -> None:
        if value is None:
            return
        target[idx] = np.asarray(value, dtype=np.float64).reshape(3)

    @staticmethod
    def _optional_vector_from_row(row: np.ndarray) -> Optional[np.ndarray]:
        row = np.asarray(row, dtype=np.float64).reshape(3)
        if not np.all(np.isfinite(row)):
            return None
        return row.copy()

    def integrate(
        self,
        depth: np.ndarray,
        color: np.ndarray,
        K: np.ndarray,
        T_c2w: np.ndarray,
        confidence: Optional[np.ndarray] = None,
        frame_id: Optional[Any] = None,
    ) -> Dict[str, int]:
        """Integrate one RGB-D frame into the voxel map."""
        depth = np.asarray(depth, dtype=np.float32)
        color = np.asarray(color)
        K = np.asarray(K, dtype=np.float64)
        T_c2w = np.asarray(T_c2w, dtype=np.float64)

        if depth.ndim != 2:
            raise ValueError("depth must be a 2D array")
        if color.shape[:2] != depth.shape:
            raise ValueError("color and depth must have the same image size")
        if K.shape != (3, 3):
            raise ValueError("K must be a 3x3 matrix")
        if T_c2w.shape != (4, 4):
            raise ValueError("T_c2w must be a 4x4 matrix")

        frame_index = self.frames_integrated
        valid_mask = np.isfinite(depth) & (depth > self.depth_min) & (depth < self.depth_max)
        confidence_values = None
        if confidence is not None:
            confidence_values = np.asarray(confidence, dtype=np.float32)
            if confidence_values.shape != depth.shape:
                raise ValueError("confidence and depth must have the same image size")
            valid_mask &= confidence_values >= self.confidence_threshold
        valid_mask = self._filter_depth_edges(depth, valid_mask)

        v, u = np.where(valid_mask)
        if len(u) == 0:
            pruned, inactivated = self._prune_records(frame_index)
            self.frames_integrated += 1
            return {
                "surface_pixels": 0,
                "surface_voxels": 0,
                "free_voxels": 0,
                "pruned_voxels": pruned,
                "inactivated_candidate_voxels": inactivated,
            }

        if self.max_surface_points_per_frame and len(u) > self.max_surface_points_per_frame:
            keep = np.linspace(0, len(u) - 1, self.max_surface_points_per_frame, dtype=np.int64)
            v = v[keep]
            u = u[keep]

        depths = depth[v, u].astype(np.float64)
        weights = self._surface_weights(
            depths,
            confidence_values[v, u] if confidence_values is not None else None,
        )
        points_world = self._backproject(u, v, depths, K, T_c2w)
        colors = color[v, u, :3].astype(np.float64)

        promoted_before = self.promoted_voxels
        camera_center = T_c2w[:3, 3].astype(np.float64)
        hit_keys = self._integrate_surface(
            points_world,
            colors,
            weights,
            frame_id,
            frame_index,
            camera_center,
        )
        free_count = 0
        if self.free_space_carving:
            free_keys = self._sample_free_space_keys(valid_mask, depth, K, T_c2w)
            free_count = self._integrate_free_space(free_keys, hit_keys, frame_index)
        pruned, inactivated = self._prune_records(frame_index)

        self.frames_integrated += 1
        self.surface_pixels_integrated += int(len(u))
        self.surface_voxels_updated += int(len(hit_keys))
        self.free_voxels_updated += int(free_count)

        return {
            "surface_pixels": int(len(u)),
            "surface_voxels": int(len(hit_keys)),
            "free_voxels": int(free_count),
            "promoted_voxels": int(self.promoted_voxels - promoted_before),
            "pruned_voxels": int(pruned),
            "inactivated_candidate_voxels": int(inactivated),
        }

    def to_point_cloud(self, mode: str = "stable") -> Tuple[np.ndarray, np.ndarray]:
        """Export occupied voxels as a colored point cloud.

        Modes:
            stable: only temporally promoted voxels, best for final maps.
            complete: stable voxels plus high-confidence candidates that have
                not accumulated strong free-space evidence.
        """
        mode = mode.lower().strip()
        if mode not in {"stable", "complete"}:
            raise ValueError("mode must be 'stable' or 'complete'")

        points = []
        colors = []

        for record in self.records.values():
            if not self._is_exportable(record, mode=mode):
                continue
            points.append(record.point_sum / record.weight)
            colors.append(np.clip(record.color_sum / record.weight, 0, 255))

        if not points:
            return (
                np.empty((0, 3), dtype=np.float32),
                np.empty((0, 3), dtype=np.uint8),
            )

        return (
            np.asarray(points, dtype=np.float32),
            np.asarray(colors, dtype=np.uint8),
        )

    def stats(self) -> Dict[str, Any]:
        stable_exportable = sum(1 for record in self.records.values() if self._is_exportable(record, "stable"))
        complete_exportable = sum(1 for record in self.records.values() if self._is_exportable(record, "complete"))
        stable = sum(1 for record in self.records.values() if record.is_stable)
        inactive_candidate = sum(1 for record in self.records.values() if record.inactive_candidate)
        candidate = len(self.records) - stable
        low_hit = sum(1 for record in self.records.values() if record.hit_count < self.min_hits)
        low_weight = sum(1 for record in self.records.values() if record.weight < self.min_weight)
        low_occupancy = sum(
            1 for record in self.records.values() if record.log_odds < self.occupancy_threshold
        )
        low_span = sum(
            1 for record in self.records.values() if self._observation_span(record) < self.min_observation_span
        )
        return {
            "frames_integrated": self.frames_integrated,
            "total_voxels": len(self.records),
            "candidate_voxels": candidate,
            "inactive_candidate_voxels": inactive_candidate,
            "stable_voxels": stable,
            "exported_voxels": stable_exportable,
            "stable_exported_voxels": stable_exportable,
            "complete_exported_voxels": complete_exportable,
            "filtered_low_hit_voxels": low_hit,
            "filtered_low_weight_voxels": low_weight,
            "filtered_low_occupancy_voxels": low_occupancy,
            "filtered_low_temporal_span_voxels": low_span,
            "surface_pixels_integrated": self.surface_pixels_integrated,
            "surface_voxels_updated": self.surface_voxels_updated,
            "free_voxels_updated": self.free_voxels_updated,
            "promoted_voxels": self.promoted_voxels,
            "pruned_voxels": self.pruned_voxels,
            "inactivated_candidate_voxels": self.inactivated_candidate_voxels,
            "voxel_size": self.voxel_size,
            "min_hits": self.min_hits,
            "min_weight": self.min_weight,
            "min_observation_span": self.min_observation_span,
            "occupancy_threshold": self.occupancy_threshold,
            "require_stable_for_export": self.require_stable_for_export,
            "free_space_carving": self.free_space_carving,
            "ray_stride": self.ray_stride,
            "free_space_step": self.free_space_step,
            "depth_edge_filter": self.depth_edge_filter,
            "depth_edge_max_delta": self.depth_edge_max_delta,
            "depth_weighting": self.depth_weighting,
            "complete_min_hits": self.complete_min_hits,
            "complete_min_weight": self.complete_min_weight,
            "complete_occupancy_threshold": self.complete_occupancy_threshold,
            "complete_max_free_hit_ratio": self.complete_max_free_hit_ratio,
            "retain_inactive_candidates_for_complete": self.retain_inactive_candidates_for_complete,
            "min_view_baseline_m": self.min_view_baseline_m,
            "min_view_angle_degrees": self.min_view_angle_degrees,
            "consecutive_free_threshold": self.consecutive_free_threshold,
        }

    def _surface_weights(self, depths: np.ndarray, values: Optional[np.ndarray]) -> np.ndarray:
        weights = np.ones(len(depths), dtype=np.float64)
        if values is not None:
            confidence_weights = values.astype(np.float64)
            finite = confidence_weights[np.isfinite(confidence_weights)]
            if finite.size and np.nanmax(finite) > 1.5:
                confidence_weights = confidence_weights / 255.0
            weights *= np.clip(confidence_weights, 0.05, 1.0)

        if self.depth_weighting:
            depth_factor = self.depth_weight_scale / (self.depth_weight_scale + np.maximum(depths, 0.0))
            weights *= np.clip(depth_factor, self.min_depth_weight, 1.0)

        return weights

    def _filter_depth_edges(self, depth: np.ndarray, valid_mask: np.ndarray) -> np.ndarray:
        if not self.depth_edge_filter or self.depth_edge_max_delta <= 0:
            return valid_mask

        edge_mask = np.zeros_like(valid_mask, dtype=bool)
        dx_valid = valid_mask[:, 1:] & valid_mask[:, :-1]
        dx_bad = dx_valid & (np.abs(depth[:, 1:] - depth[:, :-1]) > self.depth_edge_max_delta)
        edge_mask[:, 1:] |= dx_bad
        edge_mask[:, :-1] |= dx_bad

        dy_valid = valid_mask[1:, :] & valid_mask[:-1, :]
        dy_bad = dy_valid & (np.abs(depth[1:, :] - depth[:-1, :]) > self.depth_edge_max_delta)
        edge_mask[1:, :] |= dy_bad
        edge_mask[:-1, :] |= dy_bad

        return valid_mask & ~edge_mask

    def _backproject(
        self,
        u: np.ndarray,
        v: np.ndarray,
        depths: np.ndarray,
        K: np.ndarray,
        T_c2w: np.ndarray,
    ) -> np.ndarray:
        fx, fy = K[0, 0], K[1, 1]
        cx, cy = K[0, 2], K[1, 2]
        x_cam = (u.astype(np.float64) - cx) * depths / fx
        y_cam = (v.astype(np.float64) - cy) * depths / fy
        points_cam = np.stack([x_cam, y_cam, depths, np.ones_like(depths)], axis=1)
        points_world = (T_c2w @ points_cam.T).T
        return points_world[:, :3] / points_world[:, 3:4]

    def _integrate_surface(
        self,
        points_world: np.ndarray,
        colors: np.ndarray,
        weights: np.ndarray,
        frame_id: Optional[Any],
        frame_index: int,
        camera_center: np.ndarray,
    ) -> Set[VoxelKey]:
        if len(points_world) == 0:
            return set()
        if weights.size == 0:
            weights = np.ones(len(points_world), dtype=np.float64)

        keys = np.floor(points_world / self.voxel_size).astype(np.int64)
        unique_keys, inverse = np.unique(keys, axis=0, return_inverse=True)
        weight_sum = np.bincount(inverse, weights=weights, minlength=len(unique_keys))
        pixel_count = np.bincount(inverse, minlength=len(unique_keys)).astype(np.int64)

        point_sums = np.stack(
            [
                np.bincount(inverse, weights=points_world[:, axis] * weights, minlength=len(unique_keys))
                for axis in range(3)
            ],
            axis=1,
        )
        color_sums = np.stack(
            [
                np.bincount(inverse, weights=colors[:, axis] * weights, minlength=len(unique_keys))
                for axis in range(3)
            ],
            axis=1,
        )

        hit_keys: Set[VoxelKey] = set()
        for idx, raw_key in enumerate(unique_keys):
            key = (int(raw_key[0]), int(raw_key[1]), int(raw_key[2]))
            if weight_sum[idx] <= 0:
                continue

            record = self.records.get(key)
            if record is None:
                record = VoxelRecord(first_seen_frame=frame_id, first_seen_index=frame_index)
                self.records[key] = record
            elif record.first_seen_index < 0:
                record.first_seen_index = frame_index

            voxel_point = point_sums[idx] / weight_sum[idx]
            record.point_sum += point_sums[idx]
            record.color_sum += color_sums[idx]
            record.weight += float(weight_sum[idx])
            record.hit_count += 1
            record.pixel_count += int(pixel_count[idx])
            record.last_seen_frame = frame_id
            record.last_seen_index = frame_index
            record.inactive_candidate = False
            record.inactive_frame_index = None
            record.log_odds = min(self.max_log_odds, record.log_odds + self.hit_log_odds)
            self._update_view_evidence(record, camera_center, voxel_point)
            if self._promote_if_ready(record, frame_index):
                self.promoted_voxels += 1
            hit_keys.add(key)

        return hit_keys

    def _sample_free_space_keys(
        self,
        valid_mask: np.ndarray,
        depth: np.ndarray,
        K: np.ndarray,
        T_c2w: np.ndarray,
    ) -> Set[VoxelKey]:
        stride = self.ray_stride
        sampled = valid_mask[::stride, ::stride]
        vv, uu = np.where(sampled)
        if len(uu) == 0:
            return set()

        u = (uu * stride).astype(np.float64)
        v = (vv * stride).astype(np.float64)
        depths = depth[v.astype(np.int64), u.astype(np.int64)].astype(np.float64)
        ray_end = depths - self.free_space_margin
        if self.max_free_depth is not None and self.max_free_depth > 0:
            ray_end = np.minimum(ray_end, self.max_free_depth)

        sample_start = max(self.depth_min + self.free_space_step, self.free_space_step)
        valid_rays = np.isfinite(ray_end) & (ray_end >= sample_start)
        if not np.any(valid_rays):
            return set()

        u = u[valid_rays]
        v = v[valid_rays]
        ray_end = ray_end[valid_rays]

        fx, fy = K[0, 0], K[1, 1]
        cx, cy = K[0, 2], K[1, 2]
        ray_scale = np.stack(
            [
                (u - cx) / fx,
                (v - cy) / fy,
                np.ones_like(u),
            ],
            axis=1,
        )

        R = T_c2w[:3, :3]
        t = T_c2w[:3, 3]
        free_keys: Set[VoxelKey] = set()

        for z in np.arange(sample_start, float(np.max(ray_end)) + 1e-9, self.free_space_step):
            active = ray_end >= z
            if not np.any(active):
                continue
            points_cam = ray_scale[active] * z
            points_world = (R @ points_cam.T).T + t
            keys = np.floor(points_world / self.voxel_size).astype(np.int64)
            unique_keys = np.unique(keys, axis=0)
            for raw_key in unique_keys:
                free_keys.add((int(raw_key[0]), int(raw_key[1]), int(raw_key[2])))

        return free_keys

    def _integrate_free_space(self, free_keys: Iterable[VoxelKey], hit_keys: Set[VoxelKey],
                              current_frame_index: int = -1) -> int:
        updated = 0
        for key in free_keys:
            if key in hit_keys:
                continue
            record = self.records.get(key)
            if record is None:
                continue
            record.free_count += 1
            record.log_odds = max(self.min_log_odds, record.log_odds - self.miss_log_odds)
            # Track consecutive free-space streak for fast dynamic object cleanup
            if record.last_seen_index == current_frame_index - 1:
                record.consecutive_free_streak += 1
            else:
                record.consecutive_free_streak = 1
            record.last_seen_index = current_frame_index
            updated += 1
        return updated

    def _prune_records(self, frame_index: int) -> Tuple[int, int]:
        to_delete = []
        inactivated = 0
        for key, record in self.records.items():
            age = frame_index - record.last_seen_index if record.last_seen_index >= 0 else 0
            stale_candidate = (
                not record.is_stable
                and self.candidate_max_age_frames > 0
                and age > self.candidate_max_age_frames
            )
            low_occupancy = (
                record.free_count >= self.prune_min_free_count
                and record.log_odds <= self.prune_below_log_odds
            )
            # Fast dynamic object cleanup: stable voxel seen as free-space for N consecutive frames
            consecutive_cleanup = (
                record.is_stable
                and record.consecutive_free_streak >= self.consecutive_free_threshold
            )
            if low_occupancy or consecutive_cleanup:
                to_delete.append(key)
            elif stale_candidate:
                if self.retain_inactive_candidates_for_complete:
                    if not record.inactive_candidate:
                        record.inactive_candidate = True
                        record.inactive_frame_index = frame_index
                        inactivated += 1
                else:
                    to_delete.append(key)

        for key in to_delete:
            del self.records[key]

        self.pruned_voxels += len(to_delete)
        self.inactivated_candidate_voxels += inactivated
        return len(to_delete), inactivated

    def _update_view_evidence(
        self,
        record: VoxelRecord,
        camera_center: np.ndarray,
        voxel_point: np.ndarray,
    ) -> None:
        view_dir = voxel_point - camera_center
        norm = np.linalg.norm(view_dir)
        if norm > 1e-9:
            view_dir = view_dir / norm
        else:
            view_dir = np.zeros(3, dtype=np.float64)

        if record.first_camera_center is None:
            record.first_camera_center = camera_center.copy()
            record.last_camera_center = camera_center.copy()
            record.first_view_dir = view_dir.copy()
            record.last_view_dir = view_dir.copy()
            return

        if record.first_camera_center is not None:
            baseline = float(np.linalg.norm(camera_center - record.first_camera_center))
            record.max_observation_baseline = max(record.max_observation_baseline, baseline)
        if record.last_camera_center is not None:
            baseline = float(np.linalg.norm(camera_center - record.last_camera_center))
            record.max_observation_baseline = max(record.max_observation_baseline, baseline)

        for ref_dir in (record.first_view_dir, record.last_view_dir):
            if ref_dir is None:
                continue
            dot = float(np.clip(np.dot(view_dir, ref_dir), -1.0, 1.0))
            angle = float(np.degrees(np.arccos(dot)))
            record.max_view_angle_degrees = max(record.max_view_angle_degrees, angle)

        record.last_camera_center = camera_center.copy()
        record.last_view_dir = view_dir.copy()

    def _promote_if_ready(self, record: VoxelRecord, frame_index: int) -> bool:
        if record.is_stable:
            return False
        if not self._meets_stability(record):
            return False
        record.is_stable = True
        record.promoted_frame_index = frame_index
        return True

    def _meets_stability(self, record: VoxelRecord) -> bool:
        return (
            record.weight > 0
            and record.hit_count >= self.min_hits
            and record.weight >= self.min_weight
            and record.log_odds >= self.occupancy_threshold
            and self._observation_span(record) >= self.min_observation_span
            and self._meets_view_stability(record)
        )

    def _meets_view_stability(self, record: VoxelRecord) -> bool:
        checks = []
        if self.min_view_baseline_m > 0:
            checks.append(record.max_observation_baseline >= self.min_view_baseline_m)
        if self.min_view_angle_degrees > 0:
            checks.append(record.max_view_angle_degrees >= self.min_view_angle_degrees)
        return True if not checks else any(checks)

    def _observation_span(self, record: VoxelRecord) -> int:
        if record.first_seen_index < 0 or record.last_seen_index < 0:
            return 0
        return max(0, record.last_seen_index - record.first_seen_index)

    def _is_exportable(self, record: VoxelRecord, mode: str = "stable") -> bool:
        if mode == "stable":
            return self._is_stable_exportable(record)
        if mode == "complete":
            return self._is_stable_exportable(record) or self._is_complete_candidate_exportable(record)
        raise ValueError("mode must be 'stable' or 'complete'")

    def _is_stable_exportable(self, record: VoxelRecord) -> bool:
        return (
            (record.is_stable or not self.require_stable_for_export)
            and record.weight > 0
            and record.hit_count >= self.min_hits
            and record.weight >= self.min_weight
            and record.log_odds >= self.occupancy_threshold
        )

    def _is_complete_candidate_exportable(self, record: VoxelRecord) -> bool:
        if record.is_stable or record.weight <= 0:
            return False
        if record.hit_count < self.complete_min_hits:
            return False
        if record.weight < self.complete_min_weight:
            return False
        if record.log_odds < self.complete_occupancy_threshold:
            return False
        return record.free_count <= record.hit_count * self.complete_max_free_hit_ratio
