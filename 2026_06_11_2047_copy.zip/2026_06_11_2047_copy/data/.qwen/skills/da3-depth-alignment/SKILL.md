---
name: da3-depth-alignment
description: Align monocular depth estimation (DA3) to real-world scale using odometry when rotation is unreliable
source: auto-skill
extracted_at: '2026-06-12T08:52:57.350Z'
---

# Align Monocular Depth to Real Scale with Unreliable Rotation

## When to Use
- You have monocular depth estimation results (e.g., Depth Anything V3) that output relative depth and poses
- You have ground truth odometry but **rotation is unreliable** — only translation (especially x,y) is trustworthy
- Standard Umeyama/Sim(3) alignment would propagate bad rotation, making results worse

## Method: Adjacent-Frame 2D Distance Ratios

### Core Idea
For each pair of adjacent frames i, i+1:
```
d_real[i] = sqrt((x_real[i+1] - x_real[i])² + (y_real[i+1] - y_real[i])²)
d_da3[i]  = sqrt((tx_da3[i+1] - tx_da3[i])² + (ty_da3[i+1] - ty_da3[i])²)
s[i]      = d_real[i] / d_da3[i]
```

Global scale: `s = median(s[i])` (after filtering)

### Critical Implementation Details

1. **Unit Conversion**: Odometry values may be in millimeters, not meters. Check the magnitude:
   - If x,y values are ~15000, they're likely mm → multiply by 1e-3 to get meters
   - DA3 poses are typically in meters already

2. **Filter Stationary Frames**: Skip frame pairs where `d_da3 < threshold` (e.g., 0.005m)
   - Small movements cause division instability
   - Typical scenario: first N frames before robot starts moving

3. **Use Median, Not Mean**: Scale distribution often has high variance (P25~P75 can span 0.9 to 3.2)
   - Median is robust to outliers
   - Report both median and mean±std for diagnostics

4. **Apply Scale**:
   - Depth maps: `depth_corrected = s × depth_da3`
   - Pose translation: `t_corrected = s × t_da3` (keep rotation from DA3)

### Validation
- Check corrected trajectory length vs real trajectory length
- Compare corrected depth statistics with real depth (if available)
- Per-pair scale distribution should be reasonable (not all over the place)

## When NOT to Use
- If real rotation is reliable → use full Umeyama/Sim(3) alignment instead
- If you only need depth scale (not pose alignment) → simpler methods may work
- If DA3 poses are very noisy → consider using real depth maps for per-frame supervision instead

## Example Output Structure
```
da3_corrected/
├── camera_poses.txt        # Corrected 4×4 poses
├── depth/                  # Corrected depth maps (.npy)
├── conf/                   # Confidence maps (copied)
├── intrinsic.txt           # Intrinsics (copied)
└── alignment_report.txt    # Scale factor, per-pair details, validation
```
