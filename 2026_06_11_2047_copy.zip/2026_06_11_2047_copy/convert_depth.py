import numpy as np
import cv2
import os
import glob

bin_dir = 'data/bin'
output_dir = 'data/depth'
output_rgb_dir = 'data/depth_rgb'
os.makedirs(output_dir, exist_ok=True)
os.makedirs(output_rgb_dir, exist_ok=True)

bin_files = sorted(glob.glob(os.path.join(bin_dir, '*.bin')))
print(f"找到 {len(bin_files)} 个bin文件")

for bin_file in bin_files:
    basename = os.path.splitext(os.path.basename(bin_file))[0]
    print(f"处理: {bin_file}")

    with open(bin_file, 'rb') as f:
        data = np.fromfile(f, dtype=np.int16)

    depth_map = data.reshape(352, 640).astype(np.float32)

    # 无效值 5000 -> 0
    depth_map[depth_map == 5000] = 0

    # 保存npy
    npy_path = os.path.join(output_dir, basename + '.npy')
    np.save(npy_path, depth_map)

    # 归一化生成可视化png
    valid_mask = depth_map > 0
    if np.any(valid_mask):
        valid_min = depth_map[valid_mask].min()
        valid_max = depth_map[valid_mask].max()

        depth_vis = np.zeros_like(depth_map, dtype=np.uint8)
        depth_vis[valid_mask] = ((depth_map[valid_mask] - valid_min) / (valid_max - valid_min) * 255).astype(np.uint8)

        # 灰度PNG保存到data/depth
        png_path = os.path.join(output_dir, basename + '.png')
        cv2.imwrite(png_path, depth_vis)

        # 伪彩色PNG保存到data/depth_rgb
        depth_colored = cv2.applyColorMap(depth_vis, cv2.COLORMAP_JET)
        depth_colored[~valid_mask] = [255, 255, 255]
        rgb_path = os.path.join(output_rgb_dir, basename + '.png')
        cv2.imwrite(rgb_path, depth_colored)
    else:
        depth_vis = np.zeros((352, 640), dtype=np.uint8)
        png_path = os.path.join(output_dir, basename + '.png')
        cv2.imwrite(png_path, depth_vis)

        depth_colored = np.ones((352, 640, 3), dtype=np.uint8) * 255
        rgb_path = os.path.join(output_rgb_dir, basename + '.png')
        cv2.imwrite(rgb_path, depth_colored)

    if np.any(valid_mask):
        print(f"  有效深度范围: {valid_min:.1f} ~ {valid_max:.1f}")
    else:
        print(f"  无有效深度值")
    print(f"  保存到: {npy_path}, {png_path}, {rgb_path}")

print("\n全部处理完成！")
