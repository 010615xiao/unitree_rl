#!/usr/bin/env python3
"""
将里程计数据 (小车坐标系) 转换为 RGB 相机坐标系下的 (x', y', yaw')，
输出替换后的 odom 文件，可直接喂给 build_pointcloud.py。

流程 (与 odom_to_camera_pose_gpt.py 一致):
  1. Tfo = Tfc @ inv(Toc)   (odom 帧 → 相机帧)
  2. T_o_f = inv(Tfo)       (相机帧 → odom 帧)
  3. T_w_f = T_w_o @ T_o_f  (相机在世界坐标系的位姿)
  4. 提取 x', y', yaw' → odom_matched_camera.txt

用法:
    python odom_to_camera_pose.py --odom data/odom_matched.txt
    python build_pointcloud.py --camera_height 0.065
"""

import argparse
import os

import numpy as np

# ============================================================
# 标定矩阵 (平移单位 mm, 使用时转为 m)
# ============================================================
Tfc_raw = np.array([
    [-0.00474119, 0.999963, 0.00713701, -26.452],
    [-0.0170399, 0.00705522, -0.99983, -30.224],
    [-0.999844, -0.00486185, 0.0170058, -119.478],
    [0, 0, 0, 1]
])

Toc_raw = np.array([
    [-1, -1.80257e-12, 0.00103935, 57.786],
    [0.000510553, -0.871035, 0.491222, -2.083],
    [0.000905312, 0.491222, 0.871034, 20.02],
    [0, 0, 0, 1]
])

Tfc = Tfc_raw.copy()
Tfc[:3, 3] /= 1000.0

Toc = Toc_raw.copy()
Toc[:3, 3] /= 1000.0


def invert_transform(T):
    """刚体变换求逆: [R t; 0 1] -> [R.T -R.T@t; 0 1]"""
    T_inv = np.eye(4, dtype=np.float64)
    R = T[:3, :3]
    t = T[:3, 3]
    T_inv[:3, :3] = R.T
    T_inv[:3, 3] = -R.T @ t
    return T_inv


def parse_args():
    p = argparse.ArgumentParser(description="里程计 → 相机坐标系 (x', y', yaw') 替换")
    p.add_argument("--odom", type=str, required=True, help="odom_matched.txt 路径")
    p.add_argument("--output", type=str, default=None,
                   help="输出路径 (默认同目录 odom_matched_camera.txt)")
    return p.parse_args()


def main():
    args = parse_args()

    # Tfo: odom 帧 → 相机帧
    Tfo = Tfc @ invert_transform(Toc)
    # T_o_f: 相机帧 → odom 帧 (Tfo 的逆)
    T_o_f = invert_transform(Tfo)

    print("Tfo = Tfc @ inv(Toc)  (odom -> camera):")
    for row in Tfo:
        print("  " + " ".join(f"{v:12.6f}" for v in row))
    print()
    print("T_o_f = inv(Tfo)  (camera -> odom):")
    for row in T_o_f:
        print("  " + " ".join(f"{v:12.6f}" for v in row))
    print()

    odom_path = args.odom
    output_path = args.output or os.path.join(os.path.dirname(odom_path), "odom_matched_camera.txt")

    with open(odom_path) as f:
        raw_lines = [l.rstrip('\n') for l in f]

    lines_out = []
    converted = []

    for line in raw_lines:
        stripped = line.strip()
        if not stripped:
            lines_out.append(line)
            continue

        parts = stripped.split('\t')
        if len(parts) < 6:
            lines_out.append(line)
            continue

        x_m = float(parts[1]) / 1000.0
        y_m = float(parts[2]) / 1000.0
        yaw = float(parts[3])
        roll = float(parts[4])
        pitch = float(parts[5])

        # 构建 T_w_o: 里程计位姿 (plus_y 约定: yaw=0 -> +Y)
        heading = yaw + np.pi / 2.0
        ch, sh = np.cos(heading), np.sin(heading)
        cp, sp = np.cos(pitch), np.sin(pitch)
        cr, sr = np.cos(roll), np.sin(roll)

        # R_w_o = Rz(heading) @ Ry(-pitch) @ Rx(roll)
        Ry_neg_pitch = np.array([[cp, 0, -sp], [0, 1, 0], [sp, 0, cp]])
        Rx_roll = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
        Rz_heading = np.array([[ch, -sh, 0], [sh, ch, 0], [0, 0, 1]])
        R_w_o = Rz_heading @ Ry_neg_pitch @ Rx_roll

        T_w_o = np.eye(4, dtype=np.float64)
        T_w_o[:3, :3] = R_w_o
        T_w_o[:3, 3] = [x_m, y_m, 0.0]

        # 相机在世界坐标系的位姿
        T_w_f = T_w_o @ T_o_f

        x_new = T_w_f[0, 3]
        y_new = T_w_f[1, 3]
        # 从 col0 (机体 X 轴/前方) 提取 yaw
        yaw_new = np.arctan2(T_w_f[1, 0], T_w_f[0, 0])

        # 替换 x, y, yaw (x,y 保持 mm 格式)
        parts[1] = str(int(round(x_new * 1000)))
        parts[2] = str(int(round(y_new * 1000)))
        parts[3] = str(yaw_new)

        lines_out.append('\t'.join(parts))
        converted.append({'x': x_new, 'y': y_new, 'yaw': yaw_new,
                          'x_orig': x_m, 'y_orig': y_m, 'yaw_orig': yaw})

    with open(output_path, 'w') as f:
        f.write('\n'.join(lines_out) + '\n')

    # 打印对比
    print(f"前5帧对比 (原始 → 转换后):")
    print(f"{'Frame':>5} | {'x_orig':>8} {'y_orig':>8} {'yaw_orig':>8} | {'x_new':>8} {'y_new':>8} {'yaw_new':>8}")
    for i in range(min(5, len(converted))):
        d = converted[i]
        print(f"{i:5d} | {d['x_orig']:8.3f} {d['y_orig']:8.3f} {np.degrees(d['yaw_orig']):8.1f}° | "
              f"{d['x']:8.3f} {d['y']:8.3f} {np.degrees(d['yaw']):8.1f}°")

    # 轨迹长度
    orig_len = np.sum(np.sqrt(np.diff([c['x_orig'] for c in converted])**2 +
                               np.diff([c['y_orig'] for c in converted])**2))
    new_len = np.sum(np.sqrt(np.diff([c['x'] for c in converted])**2 +
                              np.diff([c['y'] for c in converted])**2))
    print(f"\n轨迹长度: 原始={orig_len:.3f}m, 转换后={new_len:.3f}m")

    # 验证: 转换后 yaw 与运动方向是否一致
    print(f"\n方向验证 (转换后 yaw vs 运动方向):")
    for i in range(100, len(converted), 100):
        dx = converted[i]['x'] - converted[i-100]['x']
        dy = converted[i]['y'] - converted[i-100]['y']
        dist = np.sqrt(dx**2 + dy**2)
        if dist < 0.01:
            continue
        move_yaw = np.arctan2(dy, dx)
        yaw_diff = np.degrees(move_yaw - converted[i]['yaw'])
        print(f"  Frame {i}: yaw={np.degrees(converted[i]['yaw']):7.1f}°  "
              f"move_dir={np.degrees(move_yaw):7.1f}°  diff={yaw_diff:+.1f}°")

    print(f"\n已保存 -> {output_path}")


if __name__ == "__main__":
    main()
