#!/usr/bin/env python3
"""
Match bin files with the closest jpg and OdomPose entries by timestamp.

Usage:
    python match_data.py <base_dir>

Directory structure expected under <base_dir>:
    jpg_bin/               - bin files: itof_output_DD_HH_MI_SS_mmm.bin
                           - jpg files: seg_input_DD_HH_MI_SS_mmm.jpg
    OdomPose.txt           - tab-separated, last column: DD_HH:MI:SS.mmm

Output (under <base_dir>/data/):
    bin/            - copies of matched bin files
    jpg/            - copies of matched jpg files
    mapping.txt     - bin-jpg pairing with time deltas
    odom_matched.txt - the closest OdomPose line for each bin
"""

import os
import re
import sys
import shutil
from bisect import bisect_left


def time_to_ms(DD, HH, MI, SS, mmm):
    return DD * 86400000 + HH * 3600000 + MI * 60000 + SS * 1000 + mmm


def parse_bin_time(fname):
    """itof_output_DD_HH_MI_SS_mmm.bin -> ms"""
    m = re.search(r'itof_output_(\d+)_(\d+)_(\d+)_(\d+)_(\d+)\.bin', fname)
    if not m:
        return None
    return time_to_ms(*[int(x) for x in m.groups()])


def parse_jpg_time(fname):
    """seg_input_DD_HH_MI_SS_mmm.jpg -> ms"""
    m = re.search(r'seg_input_(\d+)_(\d+)_(\d+)_(\d+)_(\d+)\.jpg', fname)
    if not m:
        return None
    return time_to_ms(*[int(x) for x in m.groups()])


def parse_odom_time(ts):
    """DD_HH:MI:SS.mmm -> ms"""
    m = re.search(r'(\d+)_(\d+):(\d+):(\d+)\.(\d+)', ts)
    if not m:
        return None
    return time_to_ms(*[int(x) for x in m.groups()])


def find_closest(sorted_times, target):
    """Binary search for the closest value in a sorted list. Returns (index, abs_delta)."""
    pos = bisect_left(sorted_times, target)
    best_idx = None
    best_delta = float('inf')
    for idx in (pos - 1, pos):
        if 0 <= idx < len(sorted_times):
            d = abs(sorted_times[idx] - target)
            if d < best_delta:
                best_delta = d
                best_idx = idx
    return best_idx, best_delta


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Match bin/jpg/odom by timestamp")
    parser.add_argument("base_dir", help="Base directory containing OdomPose.txt and bin/jpg folder")
    parser.add_argument("--bin_dir", default="jpg_bin",
                        help="Name of the folder containing bin and jpg files (default: jpg_bin)")
    args = parser.parse_args()

    base = args.base_dir
    jpg_bin_dir = os.path.join(base, args.bin_dir)
    odom_file = os.path.join(base, "OdomPose.txt")

    out_dir = os.path.join(base, "data")
    out_bin_dir = os.path.join(out_dir, "bin")
    out_jpg_dir = os.path.join(out_dir, "jpg")

    for d in (out_bin_dir, out_jpg_dir):
        os.makedirs(d, exist_ok=True)

    # ------------------------------------------------------------------
    # 1. Load bin files from jpg_bin/
    # ------------------------------------------------------------------
    bin_files = sorted(f for f in os.listdir(jpg_bin_dir) if f.endswith('.bin'))
    bin_times = []
    for bf in bin_files:
        t = parse_bin_time(bf)
        if t is None:
            print(f"  [SKIP] Cannot parse bin time: {bf}")
        else:
            bin_times.append((t, bf))
    bin_times.sort(key=lambda x: x[0])
    print(f"Loaded {len(bin_times)} bin files from jpg_bin/")

    # ------------------------------------------------------------------
    # 2. Load jpg files from jpg_bin/ and sort by time
    # ------------------------------------------------------------------
    jpg_files = sorted(f for f in os.listdir(jpg_bin_dir) if f.endswith('.jpg'))
    jpg_entries = []
    for jf in jpg_files:
        t = parse_jpg_time(jf)
        if t is None:
            print(f"  [SKIP] Cannot parse jpg time: {jf}")
        else:
            jpg_entries.append((t, jf))
    jpg_entries.sort(key=lambda x: x[0])
    jpg_sorted_times = [t for t, _ in jpg_entries]
    print(f"Loaded {len(jpg_entries)} jpg files from jpg_bin/")

    # ------------------------------------------------------------------
    # 3. Load OdomPose and sort by time
    # ------------------------------------------------------------------
    odom_entries = []
    with open(odom_file) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            if len(parts) < 2:
                continue
            ts = parts[-1]
            t = parse_odom_time(ts)
            if t is None:
                continue
            odom_entries.append((t, line))
    odom_entries.sort(key=lambda x: x[0])
    odom_sorted_times = [t for t, _ in odom_entries]
    print(f"Loaded {len(odom_entries)} OdomPose entries")

    # ------------------------------------------------------------------
    # 4. Match each bin to closest jpg and OdomPose
    # ------------------------------------------------------------------
    mapping_lines = []
    odom_matched_lines = []
    header = (
        f"{'#':>6} | {'Bin File':<40} | {'Bin Time (ms)':<13} | "
        f"{'JPG File':<40} | {'JPG Time (ms)':<13} | {'JPG Δ(ms)':<9} | {'Odom Δ(ms)'}"
    )
    separator = "-" * len(header)
    mapping_lines.append(header)
    mapping_lines.append(separator)

    def rename_jpg_ms(jpg_fname, ms_offset):
        """Rename jpg by adding ms_offset to the milliseconds part of the filename.
        seg_input_DD_HH_MI_SS_mmm.jpg -> seg_input_DD_HH_MI_SS_(mmm+offset).jpg
        """
        m = re.match(r'(seg_input_\d+_\d+_\d+_\d+_)(\d+)(\.jpg)$', jpg_fname)
        if not m:
            return jpg_fname
        prefix, ms_str, suffix = m.groups()
        new_ms = int(ms_str) + ms_offset
        return f"{prefix}{new_ms}{suffix}"

    matched_count = 0
    skipped_jpg = 0
    skipped_odom = 0
    used_jpg_names = set()

    for idx, (bin_t, bin_fname) in enumerate(bin_times):
        # Closest jpg
        jpg_idx, jpg_delta = find_closest(jpg_sorted_times, bin_t)
        if jpg_idx is None:
            print(f"  [WARN] No jpg found for {bin_fname}")
            skipped_jpg += 1
            continue
        jpg_t, jpg_fname = jpg_entries[jpg_idx]

        # Closest OdomPose
        odom_idx, odom_delta = find_closest(odom_sorted_times, bin_t)
        if odom_idx is None:
            print(f"  [WARN] No OdomPose found for {bin_fname}")
            skipped_odom += 1
            continue
        odom_t, odom_line = odom_entries[odom_idx]

        # Copy bin
        src_bin = os.path.join(jpg_bin_dir, bin_fname)
        dst_bin = os.path.join(out_bin_dir, bin_fname)
        shutil.copy2(src_bin, dst_bin)

        # Copy jpg — ensure unique filename per bin
        dst_jpg_name = jpg_fname
        if dst_jpg_name in used_jpg_names:
            dst_jpg_name = rename_jpg_ms(jpg_fname, 10)
            while dst_jpg_name in used_jpg_names:
                dst_jpg_name = rename_jpg_ms(dst_jpg_name, 10)
            print(f"  [INFO] Duplicate jpg {jpg_fname} -> renamed to {dst_jpg_name}")
        used_jpg_names.add(dst_jpg_name)
        src_jpg = os.path.join(jpg_bin_dir, jpg_fname)
        dst_jpg = os.path.join(out_jpg_dir, dst_jpg_name)
        shutil.copy2(src_jpg, dst_jpg)

        # Write mapping line
        mapping_lines.append(
            f"{idx:<6} | {bin_fname:<40} | {bin_t:<13} | "
            f"{jpg_fname:<40} | {jpg_t:<13} | {jpg_delta:<9} | {odom_delta}"
        )

        # Write odom matched line
        odom_matched_lines.append(odom_line)

        matched_count += 1

    # ------------------------------------------------------------------
    # 5. Save outputs
    # ------------------------------------------------------------------
    mapping_path = os.path.join(out_dir, "mapping.txt")
    with open(mapping_path, 'w') as f:
        f.write('\n'.join(mapping_lines) + '\n')

    odom_path = os.path.join(out_dir, "odom_matched.txt")
    with open(odom_path, 'w') as f:
        f.write('\n'.join(odom_matched_lines) + '\n')

    print(f"\nDone! Matched {matched_count} bin files.")
    if skipped_jpg:
        print(f"  Skipped {skipped_jpg} (no jpg available)")
    if skipped_odom:
        print(f"  Skipped {skipped_odom} (no OdomPose available)")
    print(f"Output saved to {out_dir}/")
    print(f"  bin/             : {len(os.listdir(out_bin_dir))} files")
    print(f"  jpg/             : {len(os.listdir(out_jpg_dir))} files")
    print(f"  mapping.txt      : {matched_count} entries")
    print(f"  odom_matched.txt : {len(odom_matched_lines)} entries")


if __name__ == "__main__":
    main()
