#!/usr/bin/env python3
"""
全局彩色点云构建
深度图 + RGB + 里程计 -> 全局坐标系彩色点云 (PLY)

支持两种模式:
  1. 稀疏体素融合 (默认): 增量式融合, 自动去噪, 自由空间雕刻
  2. 累加模式 (--no_fusion): 逐帧拼接 + 体素下采样 + DBSCAN

用法:
    python build_pointcloud.py
    python build_pointcloud.py --voxel_size 0.02
    python build_pointcloud.py --camera_height 0.065 --max_depth 8.0

注意: dense_depth 已处理边界噪声, 无需额外边缘过滤或边框裁剪.
"""

import argparse
import os
import sys
import time

import cv2
import numpy as np

# ============================================================
# 默认参数
# ============================================================
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

# 相机内参
FX, FY = 264.913116, 264.996857
CX, CY = 322.209381, 177.470764
IMG_W, IMG_H = 640, 352

# 深度无效标记 (ToF 传感器错误码)
DEPTH_INVALID = 63568

# 相机到机器人的固定旋转:
#   相机 Z(前) -> 机器人 X(前)
#   相机 X(右) -> 机器人 -Y(左)
#   相机 Y(下) -> 机器人 -Z(下)
R_CAM2ROBOT = np.array([[0, 0, 1],
                        [-1, 0, 0],
                        [0, -1, 0]])

# 相机内参矩阵
K_MATRIX = np.array([[FX, 0, CX],
                     [0, FY, CY],
                     [0,  0,  1]], dtype=np.float64)


def parse_args():
    p = argparse.ArgumentParser(description="构建全局彩色点云")
    p.add_argument("--data_dir", type=str, default=DATA_DIR, help="数据目录")
    p.add_argument("--odom_file", type=str, default="odom_matched_camera.txt",
                   help="里程计文件名 (相对于 data_dir), "
                        "默认使用 odom_to_camera_pose.py 转换后的相机位姿")
    p.add_argument("--full_pose_file", type=str, default=None,
                   help="完整 4x4 T_w_f 矩阵文件 (rgb_camera_poses.txt 格式), "
                        "使用此选项则忽略 odom_file 中的 (x,y,yaw)")
    p.add_argument("--camera_height", type=float, default=None,
                   help="相机高度(m), None则自动通过SAM3计算")
    p.add_argument("--voxel_size", type=float, default=0.02,
                   help="体素大小(m)")
    p.add_argument("--max_depth", type=float, default=2.0,
                   help="最大有效深度(m)")
    p.add_argument("--min_depth", type=float, default=0.01,
                   help="最小有效深度(m)")

    # 深度数据源
    p.add_argument("--raw_depth", action="store_true",
                   help="使用原始深度 depth/*.png (uint16 mm, >=5000无效), 而非 dense_depth/*.npy")
    p.add_argument("--conf_threshold", type=float, default=0.98,
                   help="置信度阈值, 只保留 conf > 该值的深度像素 (默认 0.98, 0 表示不过滤)")

    # 融合模式
    p.add_argument("--no_fusion", action="store_true",
                   help="禁用体素融合, 使用累加+下采样模式")

    # 体素融合参数
    p.add_argument("--min_hits", type=int, default=2,
                   help="体素最少命中次数 (融合模式)")
    p.add_argument("--min_weight", type=float, default=2.0,
                   help="体素最小权重 (融合模式)")
    p.add_argument("--free_space_carving", action="store_true", default=True,
                   help="启用自由空间雕刻 (融合模式)")
    p.add_argument("--no_free_space", action="store_true",
                   help="禁用自由空间雕刻")
    p.add_argument("--ray_stride", type=int, default=8,
                   help="自由空间射线采样步长")
    p.add_argument("--hit_log_odds", type=float, default=0.85,
                   help="命中 log-odds 增量")
    p.add_argument("--miss_log_odds", type=float, default=0.55,
                   help="未命中 log-odds 增量")
    p.add_argument("--consecutive_free_threshold", type=int, default=3,
                   help="连续自由空间次数阈值, 超过则删除体素")

    # 后处理参数 (仅 --no_fusion 模式)
    p.add_argument("--dbscan_eps", type=float, default=0.05,
                   help="DBSCAN去噪 eps(m), 0表示不去噪 (仅累加模式)")
    p.add_argument("--dbscan_min_points", type=int, default=30,
                   help="DBSCAN去噪 min_points (仅累加模式)")

    p.add_argument("--max_frames", type=int, default=None,
                   help="最多处理前N帧")
    p.add_argument("--start", type=int, default=None,
                   help="起始帧索引 (含)")
    p.add_argument("--end", type=int, default=None,
                   help="结束帧索引 (不含)")
    p.add_argument("--output", type=str, default=None,
                   help="输出PLY路径, 默认 data_dir/global_pointcloud.ply")
    p.add_argument("--sam3_url", type=str, default="http://localhost:20023",
                   help="SAM3服务地址")
    return p.parse_args()


# ============================================================
# 数据加载
# ============================================================

def load_odometry(path):
    """加载里程计数据, 返回 list of dict"""
    records = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            records.append({
                'enc_time': int(parts[0]),
                'x': float(parts[1]) / 1000.0,       # mm -> m
                'y': float(parts[2]) / 1000.0,       # mm -> m
                'yaw': float(parts[3]),               # rad
                'roll': float(parts[4]),
                'pitch': float(parts[5]),
                'v': float(parts[6]),
                'w': float(parts[7]),
                'fusion_x': float(parts[8]) / 1000.0,
                'fusion_y': float(parts[9]) / 1000.0,
                'quality': int(parts[10]),
                'time_str': parts[11],
            })
    return records


def load_mapping(path):
    """加载 Bin<->JPG 映射表, 返回 list of (bin_name, jpg_name)"""
    mapping = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#') or line.startswith('-'):
                continue
            parts = line.split('|')
            if len(parts) >= 5:
                mapping.append((parts[1].strip(), parts[3].strip()))
    return mapping


def load_full_poses(path):
    """加载完整 4x4 T_w_f 矩阵 (rgb_camera_poses.txt 格式)
    格式: enc_time\ttime_str\tm00 m01 ... m33 (16个浮点数)
    """
    poses = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split('\t')
            if len(parts) < 18:  # enc_time + time_str + 16 matrix values
                continue
            matrix_vals = [float(x) for x in parts[2:18]]
            T = np.array(matrix_vals).reshape(4, 4)
            poses.append(T)
    return poses


def load_depth_npy(npy_path, conf_path=None, conf_threshold=0.0):
    """加载 dense_depth npy (float32, 单位 m, inf 表示无效).
    若提供 conf_path 且 conf_threshold > 0, 则过滤低置信度像素."""
    depth = np.load(npy_path)
    if conf_path and conf_threshold > 0 and os.path.exists(conf_path):
        conf = np.load(conf_path)
        low_conf = conf < conf_threshold
        depth[low_conf] = np.inf
    return depth


def load_depth_raw(png_path):
    """加载原始深度 PNG (uint16, 单位 mm, >=5000 或 ==0 视为无效). 返回 float32 m, inf=无效."""
    raw = cv2.imread(png_path, cv2.IMREAD_UNCHANGED)
    depth = raw.astype(np.float32) / 1000.0
    invalid = (raw == 0) | (raw >= 5000)
    depth[invalid] = np.inf
    return depth


# ============================================================
# 位姿计算 (与参考实现 odom_to_poses.py 一致)
# ============================================================

def euler_to_rotmat(yaw, pitch, roll):
    """R_robot (yaw from Y-axis: yaw=0 -> +Y, yaw=-pi/2 -> +X)"""
    cy, sy = np.cos(yaw), np.sin(yaw)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cr, sr = np.cos(roll), np.sin(roll)
    return np.array([
        [-sy*cp,  -sy*sp*sr - cy*cr,  -sy*sp*cr + cy*sr],
        [ cy*cp,   cy*sp*sr - sy*cr,   cy*sp*cr + sy*sr],
        [    sp,              cp*sr,               cp*cr],
    ])


def compute_poses(odom, camera_height):
    """
    为每帧计算 4x4 相机位姿矩阵 (camera -> world).
    T = [R_cam2world | t]
        [     0     | 1]
    其中 R_cam2world = R_robot2world @ R_cam2robot
         t = [x, y, camera_height]

    注意: 使用 np.unwrap 处理 yaw, 消除 ±π 跳变
    """
    # 提取 yaw 并 unwrap, 消除 ±π 跳变
    raw_yaws = np.array([o['yaw'] for o in odom])
    unwrapped_yaws = np.unwrap(raw_yaws)

    # 统计跳变信息
    jumps = []
    for i in range(1, len(raw_yaws)):
        delta = raw_yaws[i] - raw_yaws[i-1]
        if abs(delta) > 3.0:  # 检测 ±π 跳变
            jumps.append((i-1, i, raw_yaws[i-1], raw_yaws[i], delta))

    if jumps:
        print(f"[位姿] 检测到 {len(jumps)} 处 yaw ±π 跳变, 已用 unwrap 修正:")
        for prev_i, curr_i, prev_yaw, curr_yaw, delta in jumps[:5]:
            print(f"  Frame {prev_i}->{curr_i}: {prev_yaw:+.4f} -> {curr_yaw:+.4f} (delta={delta:+.4f})")
        if len(jumps) > 5:
            print(f"  ... 还有 {len(jumps)-5} 处跳变")

    poses = []
    for i, o in enumerate(odom):
        # 使用 unwrap 后的 yaw
        R_robot = euler_to_rotmat(unwrapped_yaws[i], o['pitch'], o['roll'])
        R_cam = R_robot @ R_CAM2ROBOT

        T = np.eye(4)
        T[:3, :3] = R_cam
        T[0, 3] = o['x']
        T[1, 3] = o['y']
        T[2, 3] = camera_height
        poses.append(T)
    return poses


def compute_poses_camera(odom, camera_height):
    """
    从 odom_matched_camera.txt 构建位姿.
    x', y' 是转换后的相机位置.
    yaw' 是转换后的相机朝向 (+X 约定: yaw=0 -> +X).
    roll, pitch 保留原始里程计值.

    euler_to_rotmat 使用 +Y 约定 (yaw=0 -> +Y),
    所以传入 yaw - pi/2 将 +X 约定转为 +Y 约定.
    """
    # 提取 yaw 并 unwrap, 消除 ±π 跳变
    raw_yaws = np.array([o['yaw'] for o in odom])
    unwrapped_yaws = np.unwrap(raw_yaws)

    poses = []
    for i, o in enumerate(odom):
        # +X 约定 -> +Y 约定 (使用 unwrap 后的 yaw)
        yaw_plus_y = unwrapped_yaws[i] - np.pi / 2.0
        R_robot = euler_to_rotmat(yaw_plus_y, o['pitch'], o['roll'])
        R_cam = R_robot @ R_CAM2ROBOT

        T = np.eye(4)
        T[:3, :3] = R_cam
        T[0, 3] = o['x']
        T[1, 3] = o['y']
        T[2, 3] = camera_height
        poses.append(T)
    return poses


# ============================================================
# 相机高度自动计算 (SAM3 floor 分割)
# ============================================================

def compute_camera_height_sam3(mapping, data_dir, sam3_url, conf_threshold=0.0):
    """
    利用 SAM3 分割 floor 区域, 结合深度图计算相机高度。
    原理: 地板像素在相机坐标系中 Y = (v - cy) * depth / fy, 对所有地板像素取直方图峰值。
    返回中位数高度 (m)。
    """
    import requests

    print("[SAM3] 批量计算相机高度...")
    heights = []

    for i, (bin_name, jpg_name) in enumerate(mapping):
        npy_path = os.path.join(data_dir, "dense_depth", bin_name.replace('.bin', '.npy'))
        jpg_path = os.path.join(data_dir, "jpg", jpg_name)

        if not os.path.exists(jpg_path) or not os.path.exists(npy_path):
            continue

        try:
            resp = requests.post(f"{sam3_url}/predict", json={
                "image_path": jpg_path,
                "text": "floor"
            }, timeout=30)
            data = resp.json()

            if not data.get('success') or data.get('num_detections', 0) == 0:
                continue

            best_idx = int(np.argmax(data['scores']))
            mask = np.array(data['masks'][best_idx], dtype=np.uint8)

            conf_path = npy_path.replace('dense_depth', 'dense_conf')
            depth = load_depth_npy(npy_path, conf_path=conf_path, conf_threshold=conf_threshold)
            valid = np.isfinite(depth) & (depth > 0.1) & (depth < 10.0)
            floor_mask = mask.astype(bool) & valid

            v_coords, u_coords = np.where(floor_mask)
            z_vals = depth[v_coords, u_coords].astype(np.float64)
            y_camera = (v_coords - CY) * z_vals / FY

            pos = y_camera[(y_camera > 0) & (y_camera < 0.5)]
            hist, edges = np.histogram(pos, bins=np.arange(0, 0.5, 0.005))
            if hist.max() < 50:
                continue
            peak_idx = np.argmax(hist)
            h = (edges[peak_idx] + edges[peak_idx + 1]) / 2
            heights.append(h)

        except Exception as e:
            print(f"  Frame {i}: {e}")

    heights = np.array(heights)
    median_h = float(np.median(heights))
    print(f"[SAM3] 成功 {len(heights)}/{len(mapping)} 帧")
    print(f"[SAM3] 相机高度: median={median_h*1000:.1f}mm, "
          f"mean={heights.mean()*1000:.1f}mm, std={heights.std()*1000:.1f}mm")
    return median_h


# ============================================================
# 方式一: 稀疏体素融合 (SparseVoxelFusion)
# ============================================================

def build_pointcloud_fusion(mapping, poses, data_dir, args):
    """
    使用 SparseVoxelFusion 逐帧增量融合.
    体素地图维护 log-odds 占用、自由空间雕刻、时间稳定性,
    自动剔除噪声和动态物体.
    """
    from voxel_fusion import SparseVoxelFusion

    free_space = args.free_space_carving and not args.no_free_space

    fusion = SparseVoxelFusion(
        voxel_size=args.voxel_size,
        depth_min=args.min_depth,
        depth_max=args.max_depth,
        min_hits=args.min_hits,
        min_weight=args.min_weight,
        free_space_carving=free_space,
        ray_stride=args.ray_stride,
        hit_log_odds=args.hit_log_odds,
        miss_log_odds=args.miss_log_odds,
        consecutive_free_threshold=args.consecutive_free_threshold,
    )

    t0 = time.time()
    total = min(len(mapping), len(poses))

    for idx, (bin_name, jpg_name) in enumerate(mapping):
        if idx >= len(poses):
            break

        # 加载深度
        if args.raw_depth:
            png_path = os.path.join(data_dir, "depth", bin_name.replace('.bin', '.png'))
            depth = load_depth_raw(png_path)
        else:
            npy_path = os.path.join(data_dir, "dense_depth", bin_name.replace('.bin', '.npy'))
            conf_path = os.path.join(data_dir, "dense_conf", bin_name.replace('.bin', '.npy'))
            depth = load_depth_npy(npy_path, conf_path=conf_path, conf_threshold=args.conf_threshold)

        # 加载 RGB (BGR -> RGB)
        rgb = cv2.imread(os.path.join(data_dir, "jpg", jpg_name))
        if rgb is None:
            continue
        rgb = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)

        # 融合一帧
        stats = fusion.integrate(
            depth=depth,
            color=rgb,
            K=K_MATRIX,
            T_c2w=poses[idx].astype(np.float64),
            frame_id=idx,
        )

        if idx % 30 == 0:
            s = fusion.stats()
            print(f"  帧 {idx}/{total}: "
                  f"体素={s['total_voxels']:,} (stable={s['stable_voxels']:,}), "
                  f"pruned={s['pruned_voxels']:,}, "
                  f"{time.time()-t0:.1f}s")

    elapsed = time.time() - t0
    s = fusion.stats()
    print(f"[融合] 完成: {elapsed:.1f}s")
    print(f"[融合] 总帧数: {s['frames_integrated']}")
    print(f"[融合] 体素: {s['total_voxels']:,} "
          f"(stable={s['stable_voxels']:,}, "
          f"candidate={s['candidate_voxels']:,})")
    print(f"[融合] 命中更新: {s['surface_voxels_updated']:,}, "
          f"自由空间更新: {s['free_voxels_updated']:,}")
    print(f"[融合] 剪枝: {s['pruned_voxels']:,}")

    # 导出 stable 点云
    points, colors = fusion.to_point_cloud(mode="stable")
    if len(points) == 0:
        print("[融合] stable 为空, 尝试 complete 模式...")
        points, colors = fusion.to_point_cloud(mode="complete")

    if len(points) > 0:
        print(f"[融合] 导出: {len(points):,} 点")
        print(f"[融合] 范围(m): X[{points[:,0].min():.2f},{points[:,0].max():.2f}] "
              f"Y[{points[:,1].min():.2f},{points[:,1].max():.2f}] "
              f"Z[{points[:,2].min():.2f},{points[:,2].max():.2f}]")

    return points, colors


# ============================================================
# 方式二: 累加模式 (旧版, --no_fusion)
# ============================================================

def build_pointcloud_append(mapping, poses, data_dir, max_depth, raw_depth=False, conf_threshold=0.0):
    """
    逐帧将深度图反投影到相机坐标系, 通过 4x4 位姿变换到全局坐标系.
    所有帧点云直接拼接, 后续通过体素下采样 + DBSCAN 去噪.
    """
    H, W = IMG_H, IMG_W
    ys, xs = np.meshgrid(np.arange(H), np.arange(W), indexing='ij')

    all_points = []
    all_colors = []
    t0 = time.time()

    for idx, (bin_name, jpg_name) in enumerate(mapping):
        if idx >= len(poses):
            break

        # 加载深度
        if raw_depth:
            png_path = os.path.join(data_dir, "depth", bin_name.replace('.bin', '.png'))
            depth = load_depth_raw(png_path)
        else:
            npy_path = os.path.join(data_dir, "dense_depth", bin_name.replace('.bin', '.npy'))
            conf_path = os.path.join(data_dir, "dense_conf", bin_name.replace('.bin', '.npy'))
            depth = load_depth_npy(npy_path, conf_path=conf_path, conf_threshold=conf_threshold)

        # 加载 RGB
        rgb = cv2.imread(os.path.join(data_dir, "jpg", jpg_name))
        if rgb is None:
            continue

        # 有效深度掩码
        valid = np.isfinite(depth) & (depth > 0) & (depth < max_depth)

        # 反投影到相机坐标系 (X右, Y下, Z前), 单位: m
        Z = depth[valid]
        X = (xs[valid].astype(np.float32) - CX) / FX * Z
        Y = (ys[valid].astype(np.float32) - CY) / FY * Z
        pts_cam = np.stack([X, Y, Z], axis=-1)

        # 相机坐标系 -> 全局坐标系
        T = poses[idx]
        pts_world = (T[:3, :3] @ pts_cam.T).T + T[:3, 3]

        # 颜色 (BGR -> RGB)
        colors = rgb[valid][:, ::-1]

        all_points.append(pts_world)
        all_colors.append(colors)

        if idx % 30 == 0:
            n = sum(p.shape[0] for p in all_points)
            print(f"  帧 {idx}/{len(mapping)}: {n:,} 点, {time.time()-t0:.1f}s")

    print(f"[点云] 生成完成: {time.time()-t0:.1f}s")
    points = np.vstack(all_points)
    colors = np.vstack(all_colors)
    print(f"[点云] 总点数: {points.shape[0]:,}")
    print(f"[点云] 范围(m): X[{points[:,0].min():.2f},{points[:,0].max():.2f}] "
          f"Y[{points[:,1].min():.2f},{points[:,1].max():.2f}] "
          f"Z[{points[:,2].min():.2f},{points[:,2].max():.2f}]")
    return points, colors


# ============================================================
# 后处理: 体素降采样 + DBSCAN 去噪 (仅累加模式使用)
# ============================================================

def post_process(points, colors, voxel_size, dbscan_eps, dbscan_min_points):
    """体素降采样 + DBSCAN 去噪"""
    import open3d as o3d

    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    pcd.colors = o3d.utility.Vector3dVector(colors.astype(np.float64) / 255.0)

    print(f"[降采样] voxel_size={voxel_size}m ...")
    t0 = time.time()
    pcd_down = pcd.voxel_down_sample(voxel_size)
    print(f"[降采样] {time.time()-t0:.1f}s -> {len(pcd_down.points):,} 点")

    if dbscan_eps > 0:
        print(f"[DBSCAN] eps={dbscan_eps}m, min_points={dbscan_min_points} ...")
        t0 = time.time()
        labels = np.array(pcd_down.cluster_dbscan(eps=dbscan_eps, min_points=dbscan_min_points))
        if np.any(labels >= 0):
            label_counts = np.bincount(labels[labels >= 0])
            max_label = np.argmax(label_counts)
            inlier_mask = labels == max_label
            clean_pcd = pcd_down.select_by_index(np.where(inlier_mask)[0])
            noise_count = (~inlier_mask).sum()
            print(f"[DBSCAN] {time.time()-t0:.1f}s -> 最大簇={label_counts[max_label]:,} 点, "
                  f"去噪={noise_count:,}")
        else:
            print(f"[DBSCAN] 无有效簇, 保留全部点")
            clean_pcd = pcd_down
    else:
        clean_pcd = pcd_down

    return clean_pcd


# ============================================================
# PLY 写入
# ============================================================

def write_ply_with_trajectory(path, pcd, all_poses, mapping, used_poses=None):
    """写入点云 + 完整轨迹(红) + 使用段轨迹(蓝) + 方向箭头(黄)"""
    import open3d as o3d

    # 完整轨迹 - 红色
    full_pts = np.array([[T[0, 3], T[1, 3], T[2, 3]] for T in all_poses])
    full_colors = np.array([[1, 0, 0]] * len(full_pts), dtype=np.float64)

    all_pts = np.vstack([np.asarray(pcd.points), full_pts])
    all_cols = np.vstack([np.asarray(pcd.colors), full_colors])

    if used_poses is not None and len(used_poses) > 0:
        # 使用段轨迹 - 蓝色
        used_pts = np.array([[T[0, 3], T[1, 3], T[2, 3]] for T in used_poses])
        used_colors = np.array([[0, 0.4, 1]] * len(used_pts), dtype=np.float64)
        all_pts = np.vstack([all_pts, used_pts])
        all_cols = np.vstack([all_cols, used_colors])

        # 方向箭头 - 黄色线段 (每个位姿的Z轴前向)
        arrow_lines = []
        arrow_pts = []
        arrow_colors = []
        arrow_len = 0.3
        for T in used_poses:
            center = T[:3, 3]
            forward = T[:3, 2]  # 相机Z轴 = 前向
            tip = center + forward * arrow_len
            idx = len(arrow_pts)
            arrow_pts.extend([center, tip])
            arrow_colors.extend([[1, 1, 0], [1, 1, 0]])
            arrow_lines.append([idx, idx + 1])

        if arrow_lines:
            arrow_pts = np.array(arrow_pts)
            arrow_colors = np.array(arrow_colors)
            # 将箭头也加入主点云
            all_pts = np.vstack([all_pts, arrow_pts])
            all_cols = np.vstack([all_cols, arrow_colors])

            # 单独保存箭头LineSet
            arrow_pcd = o3d.geometry.PointCloud()
            arrow_pcd.points = o3d.utility.Vector3dVector(arrow_pts)
            arrow_pcd.colors = o3d.utility.Vector3dVector(arrow_colors)
            lineset = o3d.geometry.LineSet.create_from_point_cloud_correspondences(
                arrow_pcd, arrow_pcd, arrow_lines)
            lineset.colors = o3d.utility.Vector3dVector([[1, 1, 0]] * len(arrow_lines))
            arrow_path = path.replace('.ply', '_arrows.ply')
            o3d.io.write_line_set(arrow_path, lineset)
            print(f"[写入] 方向箭头 -> {arrow_path}")

    pcd_out = o3d.geometry.PointCloud()
    pcd_out.points = o3d.utility.Vector3dVector(all_pts)
    pcd_out.colors = o3d.utility.Vector3dVector(all_cols)
    o3d.io.write_point_cloud(path, pcd_out)

    # 单独保存完整轨迹
    traj_path = path.replace('.ply', '_trajectory.ply')
    pose_pcd = o3d.geometry.PointCloud()
    pose_pcd.points = o3d.utility.Vector3dVector(full_pts)
    pose_pcd.colors = o3d.utility.Vector3dVector(full_colors)
    o3d.io.write_point_cloud(traj_path, pose_pcd)

    # 单独保存使用段轨迹
    if used_poses is not None and len(used_poses) > 0:
        used_traj_path = path.replace('.ply', '_used_trajectory.ply')
        used_pcd = o3d.geometry.PointCloud()
        used_pcd.points = o3d.utility.Vector3dVector(used_pts)
        used_pcd.colors = o3d.utility.Vector3dVector(used_colors)
        o3d.io.write_point_cloud(used_traj_path, used_pcd)
        print(f"[写入] 使用段轨迹 -> {used_traj_path}")

    print(f"[写入] 点云+轨迹 -> {path}")
    print(f"[写入] 完整轨迹(红) -> {traj_path}")


def write_ply_raw(path, points, colors, poses, all_poses=None, used_poses=None):
    """直接写入 numpy 数组格式的点云 + 完整轨迹(红) + 使用段轨迹(蓝) + 方向箭头(黄)"""
    import open3d as o3d

    # 如果没有传 all_poses，则用 poses 作为完整轨迹
    if all_poses is None:
        all_poses = poses

    # 完整轨迹 - 红色
    full_pts = np.array([[T[0, 3], T[1, 3], T[2, 3]] for T in all_poses])
    full_colors = np.array([[1, 0, 0]] * len(full_pts), dtype=np.float64)

    all_pts = np.vstack([points, full_pts])
    all_cols = np.vstack([colors.astype(np.float64) / 255.0, full_colors])

    if used_poses is not None and len(used_poses) > 0:
        # 使用段轨迹 - 蓝色
        used_pts = np.array([[T[0, 3], T[1, 3], T[2, 3]] for T in used_poses])
        used_colors = np.array([[0, 0.4, 1]] * len(used_pts), dtype=np.float64)
        all_pts = np.vstack([all_pts, used_pts])
        all_cols = np.vstack([all_cols, used_colors])

        # 方向箭头 - 黄色线段
        arrow_lines = []
        arrow_pts = []
        arrow_colors = []
        arrow_len = 0.3
        for T in used_poses:
            center = T[:3, 3]
            forward = T[:3, 2]
            tip = center + forward * arrow_len
            idx = len(arrow_pts)
            arrow_pts.extend([center, tip])
            arrow_colors.extend([[1, 1, 0], [1, 1, 0]])
            arrow_lines.append([idx, idx + 1])

        if arrow_lines:
            arrow_pts = np.array(arrow_pts)
            arrow_colors = np.array(arrow_colors)
            all_pts = np.vstack([all_pts, arrow_pts])
            all_cols = np.vstack([all_cols, arrow_colors])

            arrow_pcd = o3d.geometry.PointCloud()
            arrow_pcd.points = o3d.utility.Vector3dVector(arrow_pts)
            arrow_pcd.colors = o3d.utility.Vector3dVector(arrow_colors)
            lineset = o3d.geometry.LineSet.create_from_point_cloud_correspondences(
                arrow_pcd, arrow_pcd, arrow_lines)
            lineset.colors = o3d.utility.Vector3dVector([[1, 1, 0]] * len(arrow_lines))
            arrow_path = path.replace('.ply', '_arrows.ply')
            o3d.io.write_line_set(arrow_path, lineset)
            print(f"[写入] 方向箭头 -> {arrow_path}")

    pcd_out = o3d.geometry.PointCloud()
    pcd_out.points = o3d.utility.Vector3dVector(all_pts)
    pcd_out.colors = o3d.utility.Vector3dVector(all_cols)
    o3d.io.write_point_cloud(path, pcd_out)

    traj_path = path.replace('.ply', '_trajectory.ply')
    pose_pcd = o3d.geometry.PointCloud()
    pose_pcd.points = o3d.utility.Vector3dVector(full_pts)
    pose_pcd.colors = o3d.utility.Vector3dVector(full_colors)
    o3d.io.write_point_cloud(traj_path, pose_pcd)

    if used_poses is not None and len(used_poses) > 0:
        used_traj_path = path.replace('.ply', '_used_trajectory.ply')
        used_pcd = o3d.geometry.PointCloud()
        used_pcd.points = o3d.utility.Vector3dVector(used_pts)
        used_pcd.colors = o3d.utility.Vector3dVector(used_colors)
        o3d.io.write_point_cloud(used_traj_path, used_pcd)
        print(f"[写入] 使用段轨迹(蓝) -> {used_traj_path}")

    print(f"[写入] 点云+轨迹 -> {path}")
    print(f"[写入] 完整轨迹(红) -> {traj_path}")


# ============================================================
# 主流程
# ============================================================

def main():
    args = parse_args()
    data_dir = args.data_dir
    use_fusion = not args.no_fusion

    print("=" * 60)
    print("全局彩色点云构建")
    print("=" * 60)
    print(f"数据目录: {data_dir}")
    print(f"内参: fx={FX} fy={FY} cx={CX} cy={CY}")
    print(f"图像: {IMG_W}x{IMG_H}")
    print(f"体素: {args.voxel_size}m, 深度范围: [{args.min_depth}, {args.max_depth}]m")
    print(f"模式: {'稀疏体素融合' if use_fusion else '累加+下采样'}")
    print(f"深度: {'原始 depth/*.png (>=5000无效)' if args.raw_depth else 'dense_depth/*.npy'}")
    if args.conf_threshold > 0:
        print(f"置信度过滤: conf > {args.conf_threshold}")

    # 加载数据
    odom = load_odometry(os.path.join(data_dir, args.odom_file))
    mapping = load_mapping(os.path.join(data_dir, "mapping.txt"))
    print(f"里程计: {len(odom)} 帧 ({args.odom_file}), 映射: {len(mapping)} 帧")

    # 保存完整 odom 用于生成完整轨迹
    odom_full = odom.copy()

    # 限制帧数
    if args.start is not None or args.end is not None:
        s = args.start or 0
        e = args.end or min(len(odom), len(mapping))
        s = max(0, s)
        e = min(e, len(odom), len(mapping))
        odom = odom[s:e]
        mapping = mapping[s:e]
        print(f"使用帧范围: [{s}, {e})，共 {e - s} 帧")
    elif args.max_frames is not None:
        n = min(args.max_frames, len(odom), len(mapping))
        odom = odom[:n]
        mapping = mapping[:n]
        print(f"限制前 {n} 帧")

    # 相机高度
    if args.camera_height is not None:
        camera_height = args.camera_height
        print(f"相机高度: {camera_height}m (手动指定)")
    else:
        camera_height = compute_camera_height_sam3(
            mapping, data_dir, args.sam3_url, conf_threshold=args.conf_threshold)
        print(f"相机高度: {camera_height}m (SAM3自动计算)")

    # 计算位姿 (4x4 矩阵)
    if args.full_pose_file:
        pose_path = args.full_pose_file
        if not os.path.isabs(pose_path):
            pose_path = os.path.join(data_dir, pose_path)
        poses = load_full_poses(pose_path)
        print(f"位姿: {len(poses)} 个 4x4 矩阵 (来自 {args.full_pose_file})")
    elif args.odom_file == "odom_matched_camera.txt":
        poses = compute_poses_camera(odom, camera_height)
        print(f"位姿: {len(poses)} 个 4x4 矩阵 (来自转换后的相机位姿)")
    else:
        poses = compute_poses(odom, camera_height)
        print(f"位姿: {len(poses)} 个 4x4 矩阵 (来自原始里程计)")

    output_path = args.output or os.path.join(data_dir, "global_pointcloud.ply")

    if use_fusion:
        # ---- 稀疏体素融合 ----
        if args.free_space_carving and not args.no_free_space:
            print(f"自由空间雕刻: 开启 (ray_stride={args.ray_stride}, "
                  f"consecutive_free={args.consecutive_free_threshold})")
        else:
            print(f"自由空间雕刻: 关闭")
        print(f"融合参数: min_hits={args.min_hits}, min_weight={args.min_weight}, "
              f"hit_odds={args.hit_log_odds}, miss_odds={args.miss_log_odds}")

        points, colors = build_pointcloud_fusion(mapping, poses, data_dir, args)

        if len(points) == 0:
            print("错误: 融合后没有生成任何点云!")
            sys.exit(1)

        # 计算完整位姿用于轨迹显示
        if args.full_pose_file:
            all_poses = load_full_poses(pose_path)
        elif args.odom_file == "odom_matched_camera.txt":
            all_poses = compute_poses_camera(odom_full, camera_height)
        else:
            all_poses = compute_poses(odom_full, camera_height)

        write_ply_raw(output_path, points, colors, poses,
                      all_poses=all_poses, used_poses=poses)

        # 统计
        print("\n" + "=" * 60)
        print("结果统计")
        print("=" * 60)
        print(f"输出文件: {output_path}")
        print(f"点数: {len(points):,}")
        print(f"坐标范围 (m):")
        print(f"  X: [{points[:, 0].min():.2f}, {points[:, 0].max():.2f}]")
        print(f"  Y: [{points[:, 1].min():.2f}, {points[:, 1].max():.2f}]")
        print(f"  Z: [{points[:, 2].min():.2f}, {points[:, 2].max():.2f}]")

    else:
        # ---- 累加模式 ----
        # 用完整 odom 计算完整位姿用于轨迹显示
        if args.full_pose_file:
            all_poses = load_full_poses(pose_path)
        elif args.odom_file == "odom_matched_camera.txt":
            all_poses = compute_poses_camera(odom_full, camera_height)
        else:
            all_poses = compute_poses(odom_full, camera_height)

        points, colors = build_pointcloud_append(
            mapping, poses, data_dir, args.max_depth, raw_depth=args.raw_depth,
            conf_threshold=args.conf_threshold)

        clean_pcd = post_process(
            points, colors,
            args.voxel_size, args.dbscan_eps, args.dbscan_min_points)
        del points, colors

        # 使用完整位姿生成轨迹
        write_ply_with_trajectory(output_path, clean_pcd, all_poses, mapping, used_poses=poses)

        print("\n" + "=" * 60)
        print("结果统计")
        print("=" * 60)
        print(f"输出文件: {output_path}")
        print(f"点数: {len(clean_pcd.points):,}")
        pts = np.asarray(clean_pcd.points)
        print(f"坐标范围 (m):")
        print(f"  X: [{pts[:, 0].min():.2f}, {pts[:, 0].max():.2f}]")
        print(f"  Y: [{pts[:, 1].min():.2f}, {pts[:, 1].max():.2f}]")
        print(f"  Z: [{pts[:, 2].min():.2f}, {pts[:, 2].max():.2f}]")


if __name__ == "__main__":
    main()
