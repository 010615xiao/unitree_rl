---
name: daily_chat
description: >
  Handle casual conversation, answer general questions, and provide explanations.
  Use this skill when the user greets you, asks open-ended questions, requests explanations,
  wants to chat, or asks about concepts that don't require specialized tools.
  **Do NOT use this skill for real-time information** (dates, time, news, stock prices) —
  use `browser_control` for that instead.
  If the user mentions images, websites, planning, navigation, or embodied actions,
  use the specialized skill instead.
version: 1.2.0
---

# Daily Chat

General conversational skill using the VLM's built-in knowledge.

## Triggering

**Use this skill when:**
- The user greets you ("你好", "hi", "hello")
- The user asks general knowledge questions
- The user wants explanations, summaries, or opinions
- The user is chatting casually

**Do NOT use this skill when:**
- The user asks to browse/search a website → use `browser_control`
- The user asks to describe an image or screenshot → use `env_description`
- The user gives a multi-step task → use `task_planning`
- The user asks about movement/navigation → use `trajectory_gen`

## Tool Usage Notes

- `respond(query)`: Simply passes the query through. The actual response is generated
  by the VLM in the main conversation loop — this tool just confirms the skill is active.

## Response Guidelines

- Keep responses concise and helpful
- For embodied AI context, relate answers to the simulation environment when relevant
- If unsure about something, say so rather than guessing
