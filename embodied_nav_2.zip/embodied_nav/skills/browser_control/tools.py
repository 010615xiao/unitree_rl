"""
Browser Control Skill - Tools

Tools for controlling a real web browser via Playwright.
"""

import os

# Global browser state
_browser_instance = None
_page_instance = None


def _get_browser():
    """Lazy-load Playwright browser instance."""
    global _browser_instance, _page_instance
    if _browser_instance is None:
        try:
            from playwright.sync_api import sync_playwright
            pw = sync_playwright().start()

            # Try launching with default Playwright browser first
            try:
                _browser_instance = pw.chromium.launch(headless=True)
                _page_instance = _browser_instance.new_page()
            except Exception:
                # Fallback: use manually installed Chromium
                import os
                chrome_path = os.path.expanduser("~/.cache/ms-playwright/chromium-1217/chrome")
                if os.path.exists(chrome_path):
                    _browser_instance = pw.chromium.launch(
                        headless=True,
                        executable_path=chrome_path,
                        args=["--no-sandbox", "--disable-setuid-sandbox"]
                    )
                    _page_instance = _browser_instance.new_page()
                else:
                    return None, None
        except ImportError:
            return None, None
        except Exception as e:
            print(f"[browser_control] Browser launch error: {e}")
            return None, None
    return _browser_instance, _page_instance


def navigate(url: str) -> str:
    """Navigate to a URL.
    
    Args:
        url: The URL to navigate to
        
    Returns:
        Page title and status
    """
    browser, page = _get_browser()
    if page is None:
        return "[Error] Playwright not installed. Run: pip install playwright && playwright install chromium"
    try:
        response = page.goto(url, timeout=30000)
        title = page.title()
        return f"[browser_control] Opened: {url}\nTitle: {title}\nStatus: {response.status}"
    except Exception as e:
        return f"[Error] Navigation failed: {str(e)}"


def click(selector: str) -> str:
    """Click an element by CSS selector.
    
    Args:
        selector: CSS selector for the element to click
        
    Returns:
        Click result
    """
    browser, page = _get_browser()
    if page is None:
        return "[Error] Browser not initialized"
    try:
        page.click(selector, timeout=10000)
        return f"[browser_control] Clicked: {selector}\nCurrent URL: {page.url}"
    except Exception as e:
        return f"[Error] Click failed: {str(e)}"


def type_text(selector: str, text: str) -> str:
    """Type text into an input field.
    
    Args:
        selector: CSS selector for the input element
        text: Text to type
        
    Returns:
        Typing result
    """
    browser, page = _get_browser()
    if page is None:
        return "[Error] Browser not initialized"
    try:
        page.fill(selector, text, timeout=10000)
        return f"[browser_control] Typed '{text}' into {selector}"
    except Exception as e:
        return f"[Error] Type failed: {str(e)}"


def get_content(selector: str = "body") -> str:
    """Extract text content from a CSS selector.
    
    Args:
        selector: CSS selector (default: 'body' for full page text)
        
    Returns:
        Extracted text content (truncated to 3000 chars)
    """
    browser, page = _get_browser()
    if page is None:
        return "[Error] Browser not initialized"
    try:
        text = page.inner_text(selector, timeout=10000)
        # Truncate for context limits
        truncated = text[:3000]
        return f"[browser_control] Content from '{selector}':\n{truncated}"
    except Exception as e:
        return f"[Error] Content extraction failed: {str(e)}"


def screenshot_page(path: str = None) -> str:
    """Take a screenshot of the current page.
    
    Args:
        path: Output file path (default: /workspace/wxd/Agent/images/latest_page.png)
        
    Returns:
        Path to the saved screenshot
    """
    browser, page = _get_browser()
    if page is None:
        return "[Error] Browser not initialized"
    
    if path is None:
        output_dir = "/workspace/wxd/Agent/images"
        os.makedirs(output_dir, exist_ok=True)
        path = os.path.join(output_dir, "latest_page.png")
    
    try:
        page.screenshot(path=path, full_page=True)
        return f"[browser_control] Screenshot saved: {path}"
    except Exception as e:
        return f"[Error] Screenshot failed: {str(e)}"


def close_browser() -> str:
    """Close the browser and release resources.
    
    Returns:
        Status message
    """
    global _browser_instance, _page_instance
    if _browser_instance:
        try:
            _browser_instance.close()
            _browser_instance = None
            _page_instance = None
            return "[browser_control] Browser closed."
        except Exception as e:
            return f"[Error] Browser close failed: {str(e)}"
    return "[browser_control] No browser is currently open."
