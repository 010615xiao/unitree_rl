---
name: browser_control
description: >
  Control a real web browser via Playwright. Use for: opening websites, searching online,
  filling forms, extracting web content, taking screenshots. **Also use when the user needs
  real-time or current information** (today's date, time, live news, stock prices, results)
  that training data may not have. If URLs, browsing, or web search mentioned, use this skill.
version: 1.2.0
---

# Browser Control

Controls a real web browser using Playwright for web automation tasks.

## Triggering

**Use this skill when:**
- The user asks to open a URL or website ("打开百度", "open google", "go to github.com")
- The user asks to search for something online
- The user asks to fill out a web form
- The user asks to read or extract content from a web page
- The user asks to take a screenshot of a web page
- The user mentions browsing, surfing, or navigating the web
- **The user needs real-time, current, or live information** (today's date, current time,
  latest news, stock prices, sports results, event outcomes, etc.) — your training data
  is outdated for time-sensitive queries
- **The user asks for accurate, up-to-date facts** that require searching the web to verify

**Do NOT use this skill when:**
- The user asks to describe a local image file → use `env_description`
- The user asks about movement in the simulation → use `trajectory_gen`
- The user asks for a task plan → use `task_planning`

## Tool Usage Notes

- `navigate(url)`: Opens a URL. Always include `https://` prefix if not provided.
  Returns the page title and HTTP status code.

- `click(selector)`: Clicks an element by CSS selector.
  - Use CSS selectors: `"#id"`, `".class"`, `"tag[attr=value]"`, `"button:text('Search')"`
  - After clicking a link or button, the page may navigate — call `screenshot_page()` or
    `get_content()` to see the result.
  - Don't click before the page loads — wait a moment or call `screenshot_page()` first to
    verify the page is ready.

- `type_text(selector, text)`: Types text into an input field.
  - Use the input element's selector (e.g., `"#kw"`, `"input[name=q]"`)
  - Use `fill()` internally, which clears the existing value first.

- `get_content(selector)`: Extracts text content from a selector.
  - Default selector is `"body"` (full page text). Be specific to avoid getting too much text.
  - Content is truncated to 3000 characters.

- `screenshot_page(path)`: Takes a screenshot of the current page.
  - Default path: `/workspace/wxd/Agent/images/latest_page.png`
  - After screenshot, call `env_description.describe_image()` to interpret what the page shows.
  - This is how the VLM "sees" the web page.

- `close_browser()`: Closes the browser. Call this when done to release resources.

## Typical Workflow

```
1. navigate("https://example.com")
2. screenshot_page() → produces image file
3. describe_image("/workspace/wxd/Agent/images/latest_page.png") → VLM tells you what's on the page
4. click("#search-button") or type_text("#search-input", "query")
5. Repeat steps 2-3 until you see the result
6. get_content("#results") if you need text
7. close_browser() when done
```

## Common Pitfalls

- **Selector format.** All selectors are CSS selectors, NOT XPath. Common formats:
  - `#element-id` for IDs
  - `.class-name` for classes
  - `input[name="q"]` for attributes
- **Page not ready yet.** After navigation or clicking, the page needs time to load.
  Call `screenshot_page()` to check if it's ready before trying to click or type.
- **Playwright not installed.** If you get an error about Playwright, the user needs to run:
  `pip install playwright && playwright install chromium`
- **Headless browser.** The browser runs in headless mode (no visible window) since this is
  a headless server. Screenshots are the only way to see what the page looks like.
- **Always close when done.** Call `close_browser()` to release memory.
