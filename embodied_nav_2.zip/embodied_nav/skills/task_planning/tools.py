"""
Task Planning Skill - Tools

Tools for decomposing goals into actionable step sequences.
"""

import json


def create_plan(goal: str, max_steps: int = 10) -> str:
    """Generate a structured plan for achieving a goal.
    
    Args:
        goal: High-level task description
        max_steps: Maximum number of steps in the plan
        
    Returns:
        JSON string with ordered steps
    """
    return json.dumps({
        "goal": goal,
        "steps": [
            f"Step {i+1}: [To be determined by VLM reasoning]"
            for i in range(min(3, max_steps))
        ],
        "note": "This is a placeholder. The VLM will generate actual steps via the ReAct loop."
    }, indent=2)


def validate_plan(plan: str, context: str = "") -> str:
    """Check if a plan is feasible.
    
    Args:
        plan: JSON string of the plan to validate
        context: Current environment/situation context
        
    Returns:
        Validation result with feasibility assessment
    """
    try:
        plan_data = json.loads(plan)
        return json.dumps({
            "valid": True,
            "steps_count": len(plan_data.get("steps", [])),
            "note": "Feasibility will be determined by VLM based on available skills and context."
        }, indent=2)
    except json.JSONDecodeError:
        return '{"valid": false, "reason": "Invalid plan format"}'


def refine_plan(goal: str, feedback: str) -> str:
    """Improve a plan based on execution feedback.
    
    Args:
        goal: Original goal
        feedback: What went wrong or what needs adjustment
        
    Returns:
        Refined plan
    """
    return json.dumps({
        "goal": goal,
        "feedback_incorporated": feedback,
        "note": "Plan refinement will be handled by VLM in the ReAct loop."
    }, indent=2)
