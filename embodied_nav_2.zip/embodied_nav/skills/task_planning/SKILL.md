---
name: task_planning
description: >
  Decompose high-level user goals into ordered sequences of actionable steps. Use this skill
  when the user gives a complex task that requires planning (e.g., "clean the room", "make
  breakfast", "go to the kitchen and get a cup of water"). If the user's request implies
  multiple sequential actions, use this skill first before executing anything. Also use it
  when the user explicitly asks for a plan, steps, or strategy.
version: 1.1.0
---

# Task Planning

Breaks down complex user goals into structured, sequential plans.

## Triggering

**Use this skill when:**
- The user gives a high-level goal that implies multiple actions (e.g., "clean the room",
  "prepare breakfast", "go to the kitchen")
- The user asks for a plan, steps, or strategy
- You need to organize actions before executing them
- The current task has failed and needs replanning

**Do NOT use this skill when:**
- The task is simple and direct (e.g., "what time is it?", "open this URL") → use
  `daily_chat` or `browser_control`
- The user asks about visual observation → use `env_description`
- The user asks about specific movement/trajectory → use `trajectory_gen`

## Tool Usage Notes

- `create_plan(goal, max_steps)`: Generates a JSON plan with ordered steps.
  - `goal`: The high-level task description from the user
  - `max_steps`: Limit the plan length (default 10). Keep plans short — the VLM works
    best with 3-7 steps.
  - Returns JSON with the plan structure. You should then execute each step using the
    appropriate other skills.

- `validate_plan(plan, context)`: Check if a plan is feasible given the current context.
  - `plan`: JSON string from `create_plan`
  - `context`: Description of current situation (e.g., available tools, environment state)
  - Use this before executing a complex plan to catch impossible steps.

- `refine_plan(goal, feedback)`: Improve a plan based on execution feedback.
  - `feedback`: What went wrong during execution (e.g., "couldn't reach the kitchen, door
    is closed")
  - Use this when a plan fails during execution.

## Common Pitfalls

- **Don't over-plan.** The plan is a high-level guide, not a detailed script. Let the
  ReAct loop handle the fine-grained decisions.
- **Plans are abstract, not executable.** The plan tells you WHAT to do, not HOW. You
  still need to call the right skills (browser_control, trajectory_gen, etc.) for each step.
- **Keep plans short.** If a plan has more than 10 steps, break it into sub-plans. The
  VLM's context window is limited (12K tokens).
