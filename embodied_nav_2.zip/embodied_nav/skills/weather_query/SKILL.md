---
name: weather_query
description: >
  Query real-time weather data for any location using wttr.in API.
  Use when the user asks about weather, temperature, forecast, or weather conditions
  for a specific city or location.
version: 1.3.0
---

# Weather Query

Fetches accurate, real-time weather data from wttr.in (no API key).

## ⚠️ BEFORE CALLING get_weather()

**If the user did NOT name a city in their message:**

1. Check the **Memory index** injected into your conversation context. If it contains a key like `user_location` or tags with `位置`, call `memory__recall_context(keys="user_location")` to get the actual city.
2. If memory has no location info → ask the user "请问你想查哪个城市？"
3. **NEVER assume or guess a city. **

Examples:
- "今天天气怎么样" → check memory index → recall_context → use that city
- "杭州今天热吗" → call `get_weather(location="Hangzhou")`
- "天气怎么样" → check memory, if nothing → ask first, do NOT pick a default

## Triggering

**Use this skill when:**
- The user asks about weather ("天气", "weather", "temperature", "forecast", "气温")
- The user asks about rain, snow, wind, humidity for a location

**Do NOT use this skill when:**
- The user asks about weather in the simulated environment → use `env_description`
- The user asks about general climate or seasons → use `daily_chat`

## Tool Usage

- `get_weather(location, format)`: `location` is city name (English preferred).
  `format`: `"short"`, `"normal"` (default), `"full"`

## How to Generate Suggestions

After getting weather data, use your reasoning to generate natural, helpful suggestions.
Think about what this weather means for daily life — rain → umbrella, hot → sunscreen, etc.
Be natural, not template-like.

## Common Pitfalls

- **Never guess weather from memory.** Always call `get_weather()` for current data.
- **English city names** work more reliably.
- **Tool output is data, not the final answer.** Interpret it for the user.
