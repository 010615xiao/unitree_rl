"""
Weather Query Skill - Tools

Fetches real-time weather data using wttr.in (free, no API key).
Returns structured weather data — the VLM generates natural suggestions from it.
"""

import requests
import time


# Cache: {location: (timestamp, data)}
_cache: dict[str, tuple[float, str]] = {}
_CACHE_TTL = 600  # 10 minutes


def _format_weather(data: dict, location: str, fmt: str) -> str:
    """Format weather data into a beautiful, readable string.

    Args:
        data: JSON response from wttr.in
        location: City name
        fmt: Output format (short/normal/full)

    Returns:
        Formatted weather text
    """
    now = data.get("current_condition", [{}])[0]
    temp = now.get("temp_C", "--")
    feels = now.get("FeelsLikeC", temp)
    desc = now.get("weatherDesc", [{}])[0].get("value", "Unknown").strip()
    humidity = now.get("humidity", "--")
    wind = now.get("windspeedKmph", "--")
    vis = now.get("visibility", "--")
    pressure = now.get("pressure", "--")
    uv = now.get("uvIndex", "--")

    # Weather emoji
    weather_code = int(now.get("weatherCode", 113))
    emoji_map = {
        113: "☀️", 116: "⛅", 119: "☁️", 122: "☁️",
        143: "🌫️", 176: "🌦️", 179: "🌨️", 182: "🌨️",
        185: "🌨️", 200: "⛈️", 227: "🌨️", 230: "❄️",
        248: "🌫️", 260: "🌫️", 263: "🌦️", 266: "🌧️",
        281: "🌧️", 284: "🌧️", 293: "🌦️", 296: "🌧️",
        299: "🌧️", 302: "🌧️", 305: "🌧️", 308: "⛈️",
        311: "🌧️", 314: "🌧️", 317: "🌨️", 320: "🌨️",
        323: "🌨️", 326: "🌨️", 329: "❄️", 332: "❄️",
        335: "❄️", 338: "❄️", 350: "🌨️", 353: "🌦️",
        356: "🌧️", 359: "⛈️", 362: "🌨️", 365: "❄️",
        368: "🌨️", 371: "❄️", 374: "🌨️", 377: "🌨️",
        386: "⛈️", 389: "⛈️", 392: "🌨️", 395: "❄️",
    }
    weather_emoji = emoji_map.get(weather_code, "🌡️")

    if fmt == "short":
        return (
            f"{weather_emoji} **{location} · 当前天气**\n"
            f"{desc}  |  {temp}°C（体感 {feels}°C）\n"
            f"湿度 {humidity}%  |  风速 {wind} km/h  |  UV {uv}"
        )

    # normal / full — build forecast lines
    forecast_lines = []
    hourly = data.get("weather", [])
    hours_shown = 0
    max_hours = 6 if fmt == "full" else 3

    for day_data in hourly[:3]:
        for hour in day_data.get("hourly", []):
            if hours_shown >= max_hours:
                break
            t = hour.get("time", "0")
            hour_num = int(t) // 100
            h_temp = hour.get("tempC", "--")
            h_desc = hour.get("weatherDesc", [{}])[0].get("value", "--").strip()
            h_rain = hour.get("chanceofrain", "0")
            h_code = int(hour.get("weatherCode", 113))
            h_emoji = emoji_map.get(h_code, "🌡️")
            forecast_lines.append(
                f"  {h_emoji} {hour_num:02d}:00  {h_temp}°C  {h_desc}  降水概率 {h_rain}%"
            )
            hours_shown += 1
        if hours_shown >= max_hours:
            break

    forecast_block = ""
    if forecast_lines:
        forecast_block = "\n📅 **未来预报**\n" + "\n".join(forecast_lines)

    result = (
        f"{weather_emoji} **{location} · 当前天气**\n"
        f"{desc}\n"
        f"\n"
        f"🌡️ 温度 {temp}°C  （体感 {feels}°C）\n"
        f"💧 湿度 {humidity}%\n"
        f"💨 风速 {wind} km/h\n"
        f"👁️ 能见度 {vis} km\n"
        f"🔘 气压 {pressure} hPa\n"
        f"☀️ UV 指数 {uv}"
    )

    if forecast_block:
        result += "\n" + forecast_block

    return result


def get_weather(location: str = None, format: str = "normal") -> str:
    """Fetch real-time weather data for a location.

    The VLM should generate natural suggestions from this data based on
    temperature, humidity, UV, rain probability, etc.

    Args:
        location: City name (English preferred, e.g. "Hangzhou", "Beijing", "New York").
                  MUST be explicitly specified by the user — do NOT guess.
        format: "short" (compact), "normal" (current + 3h forecast, default),
                "full" (detailed + 6h forecast)

    Returns:
        Formatted weather text ready for VLM to interpret and add suggestions
    """
    global _cache

    # Guard: location is required
    if not location or not location.strip():
        return (
            "[Error] 未提供城市名称。请先询问用户想查询哪个城市。"
        )

    # Check cache
    now_ts = time.time()
    cached = _cache.get(location)
    if cached and (now_ts - cached[0]) < _CACHE_TTL:
        return f"[weather_query] (缓存) {cached[1]}"

    # Fetch JSON data
    url = f"https://wttr.in/{location}?format=j1"
    params = {"lang": "zh"}

    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.ConnectionError:
        return "[Error] 无法连接天气服务，请检查网络"
    except Exception as e:
        return f"[Error] 天气查询失败: {str(e)}"

    # Format the result
    result = _format_weather(data, location, format)

    # Cache
    _cache[location] = (now_ts, result)

    return f"[weather_query] {result}"
