---
name: trajectory_gen
description: >
  Generate motion trajectories and action sequences for embodied agents in virtual environments.
  Use when the user asks the agent to move, navigate, grab objects, or perform physical actions.
version: 1.3.0
---

# Trajectory Generation

Generates abstract action sequences and motion commands for embodied agents in virtual environments.

## Triggering

**Use this skill when:**
- The user asks the agent to move to a location ("go to the kitchen", "walk to the table")
- The user asks the agent to grab, pick up, hold, or place an object
- The user asks the agent to look at something specific in the environment
- The user asks for navigation or path planning
- A task plan requires physical movement as one of its steps

**Do NOT use this skill when:**
- The user asks to browse a website → use `browser_control`
- The user asks for a plan without movement → use `task_planning`
- The user asks to describe what is seen → use `env_description`

## Tool Usage Notes

- `generate_trajectory(action_type, target, params)`: Creates a high-level action sequence.
  - `action_type`: One of `move_to`, `grasp`, `release`, `navigate`, `look_at`
  - `target`: The target object or location (e.g., "table", "kitchen", "red cup")
  - `params`: Optional JSON string with extra parameters (e.g., `{"speed": "slow"}`)
  - Returns a JSON action descriptor. This is ABSTRACT — it must be mapped to simulator-specific
    commands by the execution layer.

- `get_action_template(action_type)`: Returns the template definition for an action type.
  - Use this to check what parameters an action needs before calling `generate_trajectory`.

- `validate_action(action, constraints)`: Checks if an action is physically feasible.
  - Use this before executing to catch impossible actions (e.g., grasping something too far away).

## Required Information Before Calling

**You MUST know the agent's current state and the target before calling `generate_trajectory()`.**

- If the user says "去厨房" or "grab the cup" →
  you need to know where the agent is currently and where the target is.
  If this info is missing, ask the user or call `env_description` to observe first.
- If the user says "move" or "go somewhere" without specifying a target →
  **do NOT call the tool**. Ask: "你想让我去哪里？"
- If the user provides a target but you don't know the current environment →
  observe first with `env_description`, then plan the trajectory.
- For complex multi-step movements, use `task_planning` first to create a plan,
  then execute each step with `generate_trajectory()`.

## Available Action Types

| Type | Description | Required Params |
|------|-------------|----------------|
| `move_to` | Move agent to a target position | x, y, z coordinates |
| `grasp` | Grasp/pick up an object | target_object |
| `release` | Release a held object | target_location |
| `navigate` | Navigate through environment to a target room | target_room |
| `look_at` | Orient camera/view toward an object | target_object |

## Common Pitfalls

- **Actions are abstract, not simulator commands.** The output is a high-level descriptor
  like `{"action": "grasp", "target": "cup"}`. The simulator-specific mapping happens at
  execution time — don't try to send this directly to the simulator.
- **Order matters.** Always `move_to` or `navigate` first, then `grasp`, then `release`.
- **Distance constraints.** The agent can only grasp objects within reach. If a target is
  too far, the action will fail — use `validate_action` first.
