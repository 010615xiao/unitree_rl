"""
Trajectory Generation Skill - Tools

Tools for generating high-level embodied action sequences.
"""

import json


# Action templates for common embodied tasks
ACTION_TEMPLATES = {
    "move_to": {
        "action": "move_to",
        "params": ["x", "y", "z"],
        "description": "Move agent to a target position"
    },
    "grasp": {
        "action": "grasp",
        "params": ["target_object"],
        "description": "Grasp/pick up an object"
    },
    "release": {
        "action": "release",
        "params": ["target_location"],
        "description": "Release a held object at a location"
    },
    "navigate": {
        "action": "navigate",
        "params": ["target_room", "waypoints"],
        "description": "Navigate through environment to a target room"
    },
    "look_at": {
        "action": "look_at",
        "params": ["target_object"],
        "description": "Orient camera/view toward an object"
    },
}


def generate_trajectory(action_type: str, target: str, params: str = "{}") -> str:
    """Generate a high-level action sequence for an embodied agent.
    
    Args:
        action_type: Type of action (move_to, grasp, navigate, look_at, release)
        target: Target object or location
        params: JSON string of additional parameters
        
    Returns:
        JSON string describing the action sequence
    """
    try:
        extra_params = json.loads(params)
    except json.JSONDecodeError:
        extra_params = {}
    
    template = ACTION_TEMPLATES.get(action_type, {
        "action": action_type,
        "params": [],
        "description": f"Custom action: {action_type}"
    })
    
    trajectory = {
        "action": template["action"],
        "target": target,
        "params": extra_params,
        "status": "pending_execution",
        "note": "Abstract action — must be mapped to simulator-specific commands"
    }
    
    return json.dumps(trajectory, indent=2)


def get_action_template(action_type: str) -> str:
    """Get the template definition for a specific action type.
    
    Args:
        action_type: The action to get template for
        
    Returns:
        JSON string with the action template
    """
    template = ACTION_TEMPLATES.get(action_type)
    if template:
        return json.dumps(template, indent=2)
    return f'{{"error": "Unknown action type: {action_type}"}}'


def validate_action(action: str, constraints: str = "{}") -> str:
    """Check if an action is physically feasible.
    
    Args:
        action: JSON string describing the action
        constraints: JSON string of physical constraints
        
    Returns:
        Validation result
    """
    try:
        action_data = json.loads(action)
        return json.dumps({
            "action": action_data.get("action"),
            "feasible": True,
            "note": "Physical feasibility depends on simulator state — verify at execution time"
        }, indent=2)
    except json.JSONDecodeError:
        return '{"feasible": false, "reason": "Invalid action format"}'
