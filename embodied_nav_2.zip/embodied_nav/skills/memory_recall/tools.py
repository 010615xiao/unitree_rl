"""
Memory Recall Skill - Tools

Recall long-term persistent memory before tool calls.
"""


def recall_index(memory_dir: str = "./memory") -> str:
    """Get a lightweight index (key + type + tags) of all memories.

    This returns keys, types, and tags as hints, but NOT the actual content.
    Call recall_context(keys="...") to load details of relevant memories.

    Args:
        memory_dir: Directory to read from (default: ./memory)

    Returns:
        Index of all memories with key + type + tags, or message if none exist
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    index = ltm.get_index()

    if not index:
        return "[memory] No long-term memories stored yet."

    lines = [f"[memory] Memory index ({len(index)} entries). Call recall_context(keys=\"...\") to load details:\n"]
    for entry in index:
        tags_str = f" (tags: {', '.join(entry['tags'])})" if entry["tags"] else ""
        type_str = f" [{entry['type']}]"
        expiry_str = f" ⏰ expires {entry['expires']}" if entry.get("expires") else ""
        lines.append(f"  - {entry['key']}{type_str}{tags_str}{expiry_str}")

    return "\n".join(lines)


def recall_context(keys: str, memory_dir: str = "./memory") -> str:
    """Load full content of specific memories by key.

    Use this AFTER reviewing the memory index (recall_index) to load
    the full content of memories that are relevant to the user's query.

    CRITICAL: You MUST only use keys that exist in the memory store.
    Call recall_index() first to see available keys, then pick the closest match.
    NEVER invent key names.

    Args:
        keys: Comma-separated list of memory keys (e.g., "user_location,user_language")
        memory_dir: Directory to read from (default: ./memory)

    Returns:
        Full content of requested memories, or error for invalid keys
    """
    import json
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)

    # Handle both comma-separated and JSON array formats
    stripped = keys.strip()
    if stripped.startswith("["):
        try:
            key_list = json.loads(stripped)
            if isinstance(key_list, str):
                key_list = [key_list]
            elif not isinstance(key_list, list):
                key_list = [str(key_list)]
        except json.JSONDecodeError:
            key_list = [k.strip() for k in stripped.split(",") if k.strip()]
    else:
        key_list = [k.strip().strip('"').strip("'") for k in stripped.split(",") if k.strip()]

    if not key_list:
        return "[memory] No keys provided. Use recall_index() to see available memories."

    valid_keys = ltm.list_keys()
    invalid = [k for k in key_list if k not in valid_keys]
    if invalid:
        return (
            f"[memory] ERROR: Keys {invalid} do not exist.\n"
            f"Valid keys: {', '.join(sorted(valid_keys))}\n\n"
            f"You MUST only use keys listed above. NEVER invent key names."
        )

    lines = []
    for key in key_list:
        entry = ltm.get_entry(key)
        if entry:
            tags_str = f" (type: {entry.type}, tags: {', '.join(entry.tags)})" if entry.tags else f" (type: {entry.type})"
            lines.append(f"--- {key}{tags_str} ---\n{entry.content}\n")

    return f"[memory] Loaded {len(lines)} memories:\n" + "\n".join(lines)
