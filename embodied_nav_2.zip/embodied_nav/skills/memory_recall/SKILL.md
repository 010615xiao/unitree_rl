---
name: memory_recall
description: >
  Recall long-term memory BEFORE calling any tool that needs information the user didn't provide.
  Returns an index of all memories, then loads full content for relevant ones.
version: 1.0.0
---

# Memory Recall

Recall memory **BEFORE** calling any tool that needs information the user didn't explicitly provide.

**When to use:**
- The user's message is missing required info for a tool (e.g., location for weather)
- You're uncertain about a fact (who someone is, where they live, what they prefer)
- The user uses vague references ("去找她", "那里", "之前说的")

**When NOT to use:**
- The user already provided all needed info explicitly
- Casual chat — use `daily_chat`

**Tools:**
- `recall_index()` — Returns a lightweight index (keys + types + tags) of ALL memories. Use this FIRST.
- `recall_context(keys)` — Loads full content of specific memories. **You MUST call this to learn what a memory actually says** — the index only shows tags. Takes comma-separated keys (e.g., `"user_location,user_language"`).

**Critical rules:**
- You MUST only use key names that appear in the `recall_index()` output. NEVER invent keys.
- If the key you want doesn't exist: use `recall_index()` to see what actually exists and pick the closest match.
- If no memory is relevant, ask the user — do NOT guess.
