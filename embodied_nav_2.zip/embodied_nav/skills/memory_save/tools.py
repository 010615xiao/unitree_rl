"""
Memory Save Skill - Tools

Save new information to long-term persistent memory.
"""


def save_memory(key: str, content: str, tags: str, type: str = "user", memory_dir: str = "./memory", expires: str = None) -> str:
    """Save a new fact to long-term memory. Use when the user says "记住...", "记一下", "remember...", "don't forget", or shares important personal info (location, preference, relationship, deadline). NEVER use daily_chat to respond to save requests.

    Args:
        key: A short, descriptive English key (snake_case, e.g., "user_hometown", "girlfriend_location"). Pick a name that future-you would search for.
        content: The memory content. Include WHY this matters and USEFUL FOR scenarios.
        tags: Comma-separated tags (e.g., "用户信息, 位置")
        type: Memory type: user, feedback, project, reference (default: user)
        memory_dir: Directory to save to
        expires: Optional ISO date for auto-cleanup (e.g., "2026-06-01")

    Returns:
        Confirmation message with the saved key
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    tag_list = [t.strip() for t in tags.split(",") if t.strip()]

    valid_types = ("user", "feedback", "project", "reference")
    if type not in valid_types:
        type = "user"

    ltm.set(key, content, type=type, tags=tag_list, expires=expires)
    ltm.generate_memory_md()
    return f"[memory] Saved to '{key}'"


def update_memory(key: str, content: str, tags: str = None, memory_dir: str = "./memory") -> str:
    """Update existing memory content.

    Args:
        key: Memory key to update
        content: New content
        tags: Optional comma-separated tags (preserves existing if not provided)
        memory_dir: Directory

    Returns:
        Confirmation message
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    existing = ltm.get_entry(key)
    if existing is None:
        return f"[memory] Key '{key}' does not exist. Use memory_list__list_memories() to see available keys."

    tag_list = None
    if tags:
        tag_list = [t.strip() for t in tags.split(",") if t.strip()]

    success = ltm.update(key, content, tags=tag_list)
    if success:
        return f"[memory] Updated '{key}'"
    return f"[memory] Failed to update '{key}'"
