"""
Skill Base Class & Registry

All skills inherit from BaseSkill and follow the standard:
  - skill.md: YAML frontmatter + markdown body (declaration)
  - tools.py: Concrete tool function implementations (execution)
"""

import os
import re
import yaml
import inspect
import importlib
import importlib.util
from pathlib import Path
from abc import ABC, abstractmethod
from typing import Any, Callable


# ============================================================
# YAML Frontmatter parser
# ============================================================
def parse_frontmatter(md_path: str) -> tuple[dict, str]:
    """Parse YAML frontmatter and body from a .md file.
    
    Returns:
        (frontmatter_dict, body_text)
    """
    with open(md_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    pattern = r'^---\s*\n(.*?)\n---\s*\n(.*)'
    match = re.match(pattern, content, re.DOTALL)
    if not match:
        raise ValueError(f"Invalid skill.md format: missing YAML frontmatter in {md_path}")
    
    fm = yaml.safe_load(match.group(1))
    body = match.group(2).strip()
    return fm, body


# ============================================================
# Base Skill
# ============================================================
class BaseSkill(ABC):
    """All skills must inherit from this class."""
    
    def __init__(self, md_path: str):
        """Initialize skill from skill.md file."""
        self.md_path = md_path
        self.meta, self.body = parse_frontmatter(md_path)
        self.name = self.meta.get('name', 'unknown')
        self.description = self.meta.get('description', '')
        self.version = self.meta.get('version', '1.0.0')
        self.tools: dict[str, Callable] = {}
        self._load_tools()
    
    def _load_tools(self):
        """Dynamically load tools.py from the same directory as skill.md."""
        tools_dir = Path(self.md_path).parent
        tools_path = tools_dir / 'tools.py'
        if tools_path.exists():
            spec = importlib.util.spec_from_file_location(
                f"tools_{self.name}", str(tools_path)
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            # Register only functions defined in this module (not imports)
            for attr_name in dir(module):
                if attr_name.startswith('_'):
                    continue
                attr = getattr(module, attr_name)
                if callable(attr) and getattr(attr, '__module__', None) == module.__name__:
                    self.tools[attr_name] = attr
    
    @abstractmethod
    def execute(self, **kwargs) -> Any:
        """Execute the skill with given kwargs. Override in subclass."""
        pass
    
    def get_tool_schema(self) -> list[dict]:
        """Return OpenAI-compatible function calling schemas for actual tools only.
        
        The global 'Skill' tool is added by SkillRegistry (progressive disclosure).
        """
        tool_list = []

        for name, func in self.tools.items():
            doc = func.__doc__ or ""
            # Extract parameter info using inspect
            sig = inspect.signature(func)
            properties = {}
            required = []
            for param_name, param in sig.parameters.items():
                if param_name == 'self':
                    continue
                p_type = param.annotation
                type_str = "string"
                if p_type == int:
                    type_str = "integer"
                elif p_type == float:
                    type_str = "number"
                elif p_type == bool:
                    type_str = "boolean"
                elif p_type == list:
                    type_str = "array"
                properties[param_name] = {"type": type_str}
                # Param is required if no default value
                if param.default == inspect.Parameter.empty:
                    required.append(param_name)

            tool_list.append({
                "type": "function",
                "function": {
                    "name": f"{self.name}__{name}",
                    "description": doc.split('\n')[0] if doc else f"Execute {name}",
                    "parameters": {
                        "type": "object",
                        "properties": properties,
                        "required": required
                    }
                }
            })
        return tool_list
    
    def __repr__(self):
        return f"<Skill: {self.name} v{self.version} | tools: {list(self.tools.keys())}>"


# ============================================================
# Default concrete implementation (used when no skill.py exists)
# ============================================================
class DefaultSkill(BaseSkill):
    """Concrete skill implementation that delegates execution to the VLM."""
    
    def execute(self, **kwargs) -> Any:
        """Execute by returning a prompt for the VLM to handle."""
        return f"Skill '{self.name}' ready. Tools available: {list(self.tools.keys())}"


# ============================================================
# Skill Registry
# ============================================================
class SkillRegistry:
    """Auto-discovers and loads all skills from the skills/ directory."""
    
    def __init__(self, skills_dir: str):
        """
        Args:
            skills_dir: Path to the skills/ directory containing skill subfolders
        """
        self.skills_dir = Path(skills_dir)
        self.skills: dict[str, BaseSkill] = {}
        self._discover_and_load()
    
    def _discover_and_load(self):
        """Scan skills_dir for SKILL.md files and load each skill."""
        if not self.skills_dir.exists():
            raise FileNotFoundError(f"Skills directory not found: {self.skills_dir}")

        for skill_folder in sorted(self.skills_dir.iterdir()):
            if not skill_folder.is_dir():
                continue
            # Support both SKILL.md (Claude standard) and skill.md (legacy)
            md_path = skill_folder / 'SKILL.md'
            if not md_path.exists():
                md_path = skill_folder / 'skill.md'
            if not md_path.exists():
                continue
            
            try:
                # Dynamically determine skill class
                # Try to import from skill.py in the same folder
                skill_class_path = skill_folder / 'skill.py'
                if skill_class_path.exists():
                    spec = importlib.util.spec_from_file_location(
                        f"skill_{skill_folder.name}", str(skill_class_path)
                    )
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    # Find the class that inherits from BaseSkill
                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if (isinstance(attr, type) and 
                            issubclass(attr, BaseSkill) and 
                            attr is not BaseSkill):
                            skill_instance = attr(str(md_path))
                            self.skills[skill_instance.name] = skill_instance
                            break
                else:
                    # Fallback: use DefaultSkill directly
                    skill = DefaultSkill(str(md_path))
                    self.skills[skill.name] = skill
                    
                print(f"[SkillRegistry] Loaded: {md_path}")
            except Exception as e:
                print(f"[SkillRegistry] Failed to load {md_path}: {e}")
    
    def get(self, name: str) -> BaseSkill | None:
        """Get a skill by name."""
        return self.skills.get(name)
    
    def get_all(self) -> list[BaseSkill]:
        """Get all loaded skills."""
        return list(self.skills.values())
    
    def get_all_schemas(self) -> list[dict]:
        """Get OpenAI-compatible tool schemas for all skills.

        Includes:
        1. A single global 'Skill(skill_name)' tool for progressive disclosure
        2. All actual tool functions from each skill
        """
        schemas = []

        # Global Skill tool — model calls this to read a skill's full body
        skill_list = ', '.join(sorted(self.skills.keys()))
        schemas.append({
            "type": "function",
            "function": {
                "name": "Skill",
                "description": (
                    "Retrieve the full usage instructions for a skill by name. "
                    "Call this tool before using any concrete function from a skill. "
                    f"Available skills: {skill_list}."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "skill_name": {
                            "type": "string",
                            "description": "The name of the skill to retrieve instructions for"
                        }
                    },
                    "required": ["skill_name"]
                }
            }
        })

        for skill in self.skills.values():
            schemas.extend(skill.get_tool_schema())
        return schemas
    
    def list_skills(self) -> str:
        """Return a human-readable list of available skills."""
        lines = ["Available Skills:"]
        for s in self.skills.values():
            lines.append(f"  - {s.name} (v{s.version}): {s.description}")
        return '\n'.join(lines)
