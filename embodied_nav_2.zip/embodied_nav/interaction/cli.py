"""
Interaction Layer - CLI Interface

Provides a command-line interface for interacting with the agent.
"""

import os
import sys
import yaml

# Ensure project root is in path
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from decision.agent import Agent
from core.llm_client import VLMClient
from core.skill import SkillRegistry
from memory.memory_manager import MemoryManager
from utils.styled_output import (
    print_agent_response,
    print_skills_list,
    print_welcome,
    print_help,
    print_memory_list,
    Colors,
)


# ── Readline setup ──────────────────────────────────────────────────────
# Must run at import time so readline is active before any input() call
try:
    import readline

    # Persist history across sessions
    _hist_file = os.path.expanduser("~/.embodied_agent_history")
    try:
        readline.read_history_file(_hist_file)
    except FileNotFoundError:
        pass
    readline.set_history_length(200)

    # Bind keys properly for history and backspace
    readline.parse_and_bind('"\x7F": backward-delete-char')  # DEL
    readline.parse_and_bind('"\x08": backward-delete-char')  # BS
    readline.parse_and_bind("\x1b[A: previous-history")       # Up
    readline.parse_and_bind("\x1b[B: next-history")           # Down

    def _save_hist():
        readline.write_history_file(_hist_file)

    import atexit
    atexit.register(_save_hist)
except ImportError:
    readline = None


def get_user_input() -> str:
    """Get input from user via stdin, handling encoding errors gracefully."""
    try:
        # \001/\002 tell readline to ignore ANSI codes for line-length calculation
        prompt = f"  \001{Colors.BRIGHT_GREEN}\002⟹  \001{Colors.RESET}\002"
        return input(prompt).strip()
    except UnicodeDecodeError:
        print(f"\n  {Colors.DIM}[Input encoding error, please try again]{Colors.RESET}")
        return ""
    except (EOFError, KeyboardInterrupt):
        print()
        return "/quit"


def run_cli(
    agent: Agent,
    welcome_msg: str = "Embodied Agent ready. Type your task (or /quit to exit, /reset to clear memory, /memory to view memories):",
):
    """Main CLI loop."""
    # Get actual model name and skill list from VLM server and registry
    model_name = agent.vlm.get_model_name()
    skills_raw = agent.skills.list_skills()
    print_welcome(model_name=model_name, skills_raw=skills_raw)

    while True:
        user_input = get_user_input()

        if not user_input:
            continue

        if user_input == "/quit":
            print(f"\n  {Colors.DIM}Goodbye!{Colors.RESET}")
            break

        if user_input == "/reset":
            agent.reset()
            print(f"\n  {Colors.BRIGHT_CYAN}✓{Colors.RESET} {Colors.BRIGHT_GREEN}Conversation reset.{Colors.RESET}")
            continue

        if user_input == "/skills":
            print_skills_list(agent.skills.list_skills())
            continue

        if user_input == "/memory":
            memories = agent.memory.long_term.get_all()
            print_memory_list(memories)
            continue

        if user_input == "/help":
            print_help()
            continue

        if user_input.startswith("describe "):
            # Special command: send image to env_description skill
            parts = user_input.split(" ", 1)
            if len(parts) > 1:
                image_path = parts[1]
                if os.path.exists(image_path):
                    result = agent.run(f"Describe this image: {image_path}", images=[image_path])
                    print_agent_response(result)
                else:
                    print(f"  {Colors.BRIGHT_RED}✗{Colors.RESET} {Colors.BRIGHT_RED}Image not found:{Colors.RESET} {Colors.DIM}{image_path}{Colors.RESET}")
            continue

        # Normal text input → agent reasoning loop
        result = agent.run(user_input)
        print_agent_response(result)


def create_agent(
    vlm_url: str | None = None,
    skills_dir: str | None = None,
    memory_dir: str | None = None,
) -> Agent:
    """Factory function to create a fully configured agent.

    Loads defaults from config/agent.yaml, then overrides with explicit args.
    """
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    config_path = os.path.join(base_dir, "config", "agent.yaml")

    # Load config
    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)

    vlm_cfg = cfg.get("vlm", {})

    # Apply defaults from config, then explicit overrides
    vlm_url = vlm_url or vlm_cfg.get("base_url", "http://localhost:8008")
    vlm_model = vlm_cfg.get("model", "local-vlm")
    vlm_max_tokens = vlm_cfg.get("max_tokens", 120000)
    vlm_temperature = vlm_cfg.get("temperature", 0.1)

    if skills_dir is None:
        skills_dir = os.path.join(base_dir, "skills")
    if memory_dir is None:
        memory_dir = os.path.join(base_dir, "memory")

    # Create components
    vlm = VLMClient(
        base_url=vlm_url,
        model=vlm_model,
        max_tokens=vlm_max_tokens,
        temperature=vlm_temperature,
    )
    registry = SkillRegistry(skills_dir=skills_dir)
    memory = MemoryManager(memory_dir=memory_dir)

    # Build agent
    agent = Agent(
        vlm_client=vlm,
        skill_registry=registry,
        memory_manager=memory,
    )
    agent.initialize()

    return agent
