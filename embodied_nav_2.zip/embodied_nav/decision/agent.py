"""
Decision Layer - Agent Core

ReAct loop: Thought → Tool Call → Observe → Repeat → Final Answer
"""

import json
import re
import sys
import os
from typing import Optional

# Ensure stdout is unbuffered for real-time display
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(line_buffering=True)

# Ensure project root is in path
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from core.llm_client import VLMClient
from core.skill import SkillRegistry
from utils.styled_output import (
    print_tool_call,
    print_tool_observation,
    print_tool_error,
    print_step_indicator,
    Colors,
    _colorize,
)
from decision.memory_recall import recall_and_inject


# System prompt for the agent
SYSTEM_PROMPT = """You are an AI agent with a modular skill-based architecture.
You have access to several skills that allow you to interact with users, query real-time data, browse the web, plan tasks, and manage long-term memory.

## How to use skills:
- First, call `Skill(skill_name="...")` to read a skill's full instructions.
- Then call the skill's concrete tools (e.g., `weather_query__get_weather`).
- If the user didn't provide required info, check your recalled memories first. If no memory has it -> ask the user.

## BEFORE calling ANY tool, check for missing information:
1. **Missing required info**: Does the user's message provide everything the tool needs? If NO -> check recalled memories. If no memory has it -> ask the user.
2. **Ambiguous/vague input**: Did the user use a vague reference (e.g., "去找她", "那里", "之前的")? If YES -> check memories for the concrete meaning. If still unclear -> ask the user.
3. **Random/arbitrary defaults**: Are you about to pick a default value (e.g., city, time, person) that the user didn't specify? If YES -> check memories. If no memory -> ask the user. NEVER guess.

Rules:
- Think step by step before acting.
- Use only the tools provided in the function schemas.
- If a tool fails, analyze the error and try a different approach.
- Keep responses concise.

Available Skills will be listed below. Use your judgment to decide which skill matches the user's intent."""


class Agent:
    """Main agent that orchestrates skills, memory, and LLM calls."""
    
    def __init__(
        self,
        vlm_client: VLMClient,
        skill_registry: SkillRegistry,
        memory_manager,  # MemoryManager instance
        system_prompt: str = SYSTEM_PROMPT,
        max_reasoning_steps: int = 20,
    ):
        self.vlm = vlm_client
        self.skills = skill_registry
        self.memory = memory_manager
        self.system_prompt = system_prompt
        self.max_reasoning_steps = max_reasoning_steps
        self._running = False
    
    def initialize(self):
        """Load system prompt and skill list into memory."""
        skill_list = self.skills.list_skills()
        self.full_system = f"{self.system_prompt}\n\n{skill_list}"
        self.memory.add_system_message(self.full_system)
        # Simplified prompt for daily_chat — includes identity and skills,
        # but NOT the "call Skill() first" instruction which confuses the model.
        self.chat_system = f"""You are an AI agent with a modular skill-based architecture.
{skill_list}

Respond naturally and concisely. You do NOT need to call any tools to answer."""

        # Health check
        if not self.vlm.health_check():
            print("[WARNING] VLM server is not reachable. Agent will still accept input.")

    def run(self, user_input: str, images: list[str] | None = None) -> str:
        """Process a user input through the ReAct loop.

        Args:
            user_input: User's text input
            images: Optional image paths for vision input

        Returns:
            Final response string
        """
        self._running = True

        # Handle /reset command - clear conversation history
        if user_input.strip() == "/reset":
            self.memory.clear_conversation()
            self._tool_call_history = []
            return "[System] Conversation history has been cleared."

        # Clear task state (ephemeral per-run), preserve conversation history
        self._tool_call_history = []

        # Add user message to memory
        self.memory.add_user_message(user_input, images)

        # Check if conversation history needs compression
        self.memory.trigger_compression(self.vlm)

        # Build messages for LLM
        messages = self.memory.get_context()

        # Memory recall & injection — let the VLM decide which memories are relevant
        messages, recalled_keys = recall_and_inject(user_input, self.memory, self.vlm, messages)
        # Display as a visible step matching the ReAct loop style
        if recalled_keys:
            print(f'  {Colors.DIM}───{Colors.RESET} {Colors.DIM + Colors.BRIGHT_BLACK}{_colorize("Recall Memory", Colors.DIM + Colors.BRIGHT_BLACK, bold=True)}{Colors.RESET} {Colors.DIM}───{Colors.RESET}', flush=True)
            print_tool_call("memory_recall__recall_index", recalled_keys)
            keys_str = ", ".join(recalled_keys)
            print_tool_observation(f"Recalled: {keys_str}")

        # Also inject the full memory index (keys + tags) so the model knows
        # what keys exist when it decides to call recall_context during the ReAct loop.
        # This prevents the model from fabricating key names like "partner_info".
        mem_skill = self.skills.get("memory_recall")
        if mem_skill:
            index = mem_skill.tools.get("recall_index", lambda: "")()
            if not index.startswith("No long-term memories"):
                msg = "Available memory keys (call recall_index for full list):\n" + index
                messages.append({"role": "system", "content": msg})

        self._current_messages = messages  # Store for use in tool execution
        tools = self.skills.get_all_schemas()

        # ReAct loop
        step = 0
        while self._running and step < self.max_reasoning_steps:
            step += 1

            # Call VLM
            response = self.vlm.chat(messages, tools=tools)

            # Check if it's a tool call (JSON from llama-server)
            tool_calls = self._parse_tool_calls(response)

            if tool_calls:
                # Execute tools and build observation
                print_step_indicator(step, self.max_reasoning_steps)
                observations = []
                for tc in tool_calls:
                    # Safely extract tool name (defensive: model may return malformed JSON)
                    try:
                        tool_name = tc["function"]["name"]
                    except (KeyError, TypeError):
                        print_tool_error(f"Malformed tool call: {str(tc)[:100]}")
                        observations.append("Error: Malformed tool call from model")
                        continue

                    try:
                        raw = tc["function"]["arguments"]
                        # arguments might already be a dict (not a string)
                        args = raw if isinstance(raw, dict) else json.loads(raw)
                    except (json.JSONDecodeError, KeyError, TypeError):
                        args = {}
                    print_tool_call(tool_name, args)

                    result = self._execute_tool_call(tc)

                    # If the tool returns a "final answer" marker (e.g., daily_chat__respond),
                    # break out of the loop and return directly to the user
                    if result.startswith("[FINAL_ANSWER]"):
                        clean = result[len("[FINAL_ANSWER]"):]
                        print_tool_observation(clean)
                        self.memory.add_assistant_message(clean)
                        self._running = False
                        return clean

                    # Print result or error
                    if result.startswith("Error:"):
                        print_tool_error(result)
                    else:
                        print_tool_observation(result)

                    observations.append(f"Tool {tool_name}: {result}")


                # Detect repeated tool calls — track ALL calls across steps
                is_repeat = False
                corrective = ""
                for tc in tool_calls:
                    try:
                        tn = tc["function"]["name"]
                        raw = tc["function"].get("arguments", {})
                        args = raw if isinstance(raw, dict) else json.loads(raw) if isinstance(raw, str) else {}
                    except (KeyError, TypeError):
                        continue
                    call_key = f"{tn}:{json.dumps(args, sort_keys=True)}"
                    if call_key in self._tool_call_history:
                        is_repeat = True
                        # Inject corrective feedback
                        mem_skill = self.skills.get("memory_recall")
                        if mem_skill:
                            index = mem_skill.tools.get("recall_index", lambda: "")()
                            corrective = (
                                f"⚠️ You are repeating the same tool call: {tn}\\n"
                                f"Available memory keys:\\n{index}\\n\\n"
                                f"Either pick a different key or ask the user for info."
                            )
                        else:
                            corrective = f"⚠️ You are repeating the same tool call: {tn}. Try a different approach."
                        break
                    else:
                        self._tool_call_history.append(call_key)

                if is_repeat:
                    observation_text = "\n".join(observations) + f"\\n\\n{corrective}"
                else:
                    observation_text = "\n".join(observations)

                # Add assistant response and observation to messages
                messages.append({"role": "assistant", "content": response})
                messages.append({"role": "user", "content": f"Observation: {observation_text}"})

                # Also add to short-term memory
                self.memory.add_assistant_message(response)
                self.memory.add_user_message(f"Observation: {observation_text}")
            else:
                # Validate: if response is a tool call JSON, try to execute it.
                # If it looks like a tool call but can't be executed, feed it back
                # so the model self-corrects instead of returning raw JSON to user.
                try:
                    data = json.loads(response)
                    if isinstance(data, list) and data:
                        first = data[0]
                        if isinstance(first, dict) and "function" in first:
                            # Execute the tool call
                            result = self._execute_tool_call(first)
                            if result.startswith("[FINAL_ANSWER]"):
                                response = result[len("[FINAL_ANSWER]"):]
                            else:
                                messages.append({"role": "assistant", "content": response})
                                messages.append({"role": "user", "content": f"Observation: {result}\n\nThat was a tool call, not a response. Please generate a proper response to the user based on this observation."})
                                continue  # Back to top of loop
                        elif "type" in first and "arguments" in first:
                            # Malformed tool call JSON (has type+args but not OpenAI format)
                            messages.append({"role": "assistant", "content": response})
                            messages.append({"role": "user", "content": "That is a raw tool call JSON, not a response. Please generate a proper natural language response to the user."})
                            continue
                except (json.JSONDecodeError, TypeError):
                    # Also detect malformed tool call JSON by pattern matching
                    stripped = response.strip()
                    # Check for any tool-call-like structure (not just "function" keyword)
                    is_tool_like = False
                    if ("function" in stripped) or ("arguments" in stripped):
                        if "__" in stripped or "tool" in stripped.lower():
                            is_tool_like = True
                    # Also check if it starts with a list containing type+arguments
                    if stripped.startswith("[{") and '"type"' in stripped and '"arguments"' in stripped:
                        is_tool_like = True

                    if is_tool_like:
                        messages.append({"role": "assistant", "content": response})
                        messages.append({"role": "user", "content": "That looks like a tool call, not a response. Please generate a proper response to the user."})
                        continue

                self.memory.add_assistant_message(response)
                self._running = False
                return response

        # If max steps reached without final answer
        # Explain what happened and why, so the user knows what to do next
        tool_calls_made = []
        for msg in getattr(self, '_current_messages', []):
            if msg["role"] == "user" and "Observation:" in str(msg.get("content", "")):
                obs = msg["content"]
                for skill_name in ["weather_query", "memory_recall", "memory_save", "memory_delete", "memory_list", "browser_control", "daily_chat"]:
                    if f"[{skill_name.rstrip('_')}]" in obs or f"[{skill_name}]" in obs:
                        if skill_name not in str(tool_calls_made):
                            tool_calls_made.append(skill_name)
        context = ""
        if tool_calls_made:
            context = f" I retrieved: {', '.join(tool_calls_made)}."

        final = f"[Agent] I used all {self.max_reasoning_steps} reasoning steps without reaching a complete answer.{context} Please rephrase your query or ask a more specific question."
        self.memory.add_assistant_message(final)
        return final
    
    def _parse_tool_calls(self, response: str) -> list[dict]:
        """Parse tool calls from VLM response.

        Handles two formats:
        1. Standard OpenAI: [{"type": "function", "function": {"name": "...", "arguments": {...}}}]
        2. Malformed (35B model): [{"type": "function", "arguments": {"skill_name": "..."}, "id": "..."}]

        For malformed JSON: only recover if `skill_name` is in arguments.
        Route to Skill() so the model reads instructions and decides next step.
        No keyword guessing, no parameter mapping — let the model reason.
        """
        try:
            data = json.loads(response)
            if not isinstance(data, list) or not data:
                return []

            normalized = []
            for item in data:
                if not isinstance(item, dict):
                    return []

                if "function" in item:
                    # Standard format — pass through
                    normalized.append(item)
                elif item.get("type") == "function" and "arguments" in item:
                    # Malformed: model forgot "function" wrapper
                    # Only recover if skill_name is explicitly in arguments
                    args = item["arguments"]
                    if isinstance(args, dict) and "skill_name" in args:
                        normalized.append({
                            "type": "function",
                            "function": {
                                "name": "Skill",
                                "arguments": {"skill_name": args["skill_name"]}
                            }
                        })
                    # No skill_name? Return empty — let model retry with proper format
                else:
                    # Unknown format — return empty, treat as text response
                    return []

            return normalized
        except (json.JSONDecodeError, TypeError):
            pass
        return []

    def _extract_text_from_tool_call(self, response: str) -> str | None:
        """Try to extract meaningful text from a malformed or partial tool call response.

        Returns None if the response is a valid tool call that should be executed.
        Returns extracted text if it looks like the model meant to respond with text.
        """
        # Try to find a "content" field in the response
        try:
            data = json.loads(response)
            if isinstance(data, dict):
                return data.get("content")
        except (json.JSONDecodeError, TypeError):
            pass
        return None
    
    def _execute_tool_call(self, tool_call: dict) -> str:
        """Execute a single tool call by routing to the right skill.

        Tool name format: skill_name__tool_name

        Also injects the skill's SKILL.md body into the observation so the model
        has full context on how to use the skill (progressive disclosure).
        """
        full_name = tool_call["function"]["name"]

        # Arguments can be a JSON string, dict, or None
        raw_args = tool_call["function"].get("arguments", {})
        if isinstance(raw_args, str):
            try:
                args = json.loads(raw_args)
            except json.JSONDecodeError:
                args = {}
        elif isinstance(raw_args, dict):
            args = raw_args
        else:
            args = {}

        if "__" not in full_name:
            # Global Skill tool — format: just "Skill" with skill_name parameter
            if full_name == "Skill":
                skill_name = args.get("skill_name", "")
                skill = self.skills.get(skill_name)
                if not skill:
                    return f"Error: Unknown skill '{skill_name}'. Available: {', '.join(sorted(self.skills.skills.keys()))}"
                if not skill.body:
                    return f"[Skill] No usage instructions available for '{skill_name}'."
                return (
                    f"--- Skill: {skill.name} ---\n"
                    f"{skill.body}\n"
                    f"--- End Skill ---"
                )
            return f"Error: Invalid tool name format '{full_name}'. Expected 'skill_name__tool_name' or 'Skill'"

        skill_name, tool_name = full_name.split("__", 1)
        skill = self.skills.get(skill_name)

        if not skill:
            return f"Error: Skill '{skill_name}' not found"

        if tool_name not in skill.tools:
            return f"Error: Tool '{tool_name}' not found in skill '{skill_name}'"

        try:
            result = skill.tools[tool_name](**args)
            # Handle async results
            if hasattr(result, '__await__'):
                import asyncio
                result = asyncio.get_event_loop().run_until_complete(result)

            # Special case: daily_chat__respond — call VLM with conversation history
            # so the model knows what happened in the ReAct loop (memory, weather, etc.)
            if tool_name == "respond" and skill.name == "daily_chat":
                query = args.get("query", "")
                # Pass the full conversation history so model knows what tools were called
                chat_messages = [{"role": "system", "content": self.chat_system}]
                # Include relevant history (system message + recent context)
                for msg in self._current_messages:
                    # Skip system message (already added)
                    if msg["role"] == "system":
                        continue
                    chat_messages.append(msg)
                vlm_response = self.vlm.chat(chat_messages, tools=None)
                return f"[FINAL_ANSWER]{vlm_response}"

            return str(result)
        except Exception as e:
            return f"Error executing {full_name}: {str(e)}"
    
    def stop(self):
        """Stop the current reasoning loop."""
        self._running = False
    
    def reset(self):
        """Reset agent state (clear conversation, reinitialize)."""
        self._running = False
        self.memory.clear_conversation()
        self.initialize()
