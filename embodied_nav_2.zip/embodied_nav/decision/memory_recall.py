"""
Memory Recall & Injection Script

Called after each user input. Uses the VLM to decide which memories are relevant
to the current query, and injects their full content into the conversation context.
"""

import re
import json


def recall_and_inject(
    user_input: str,
    memory_manager,
    vlm_client,
    messages: list[dict],
) -> list[dict]:
    """Decide which memories are relevant to the user input, and inject them.

    Process:
    1. Get all memory keys from long-term memory
    2. Build a prompt: user intent + memory index (key + type + tags)
    3. Call VLM to decide which keys are relevant
    4. Load full content of selected keys
    5. Inject a system message with the relevant memories into messages

    Args:
        user_input: The current user query
        memory_manager: MemoryManager instance
        vlm_client: VLMClient instance
        messages: Current message list to potentially inject into

    Returns:
        Updated messages list (possibly with injected memory context)
    """
    ltm = memory_manager.long_term
    all_keys = ltm.list_keys()

    if not all_keys:
        return messages

    # Build memory index using the new get_index() API
    # This properly parses YAML frontmatter (tags, type, expires)
    index_lines = []
    for entry in ltm.get_index():
        tags_str = f" (tags: {', '.join(entry['tags'])})" if entry["tags"] else ""
        type_str = f" [{entry['type']}]"
        expiry_str = f" expires {entry['expires']}" if entry.get("expires") else ""
        index_lines.append(f"  - {entry['key']}{type_str}{tags_str}{expiry_str}")
    index_text = "\n".join(index_lines)

    # Ask VLM which memories are relevant
    recall_prompt = f"""You MUST select relevant memories to inject into the agent's context before it responds.

YOUR ROLE: The agent is about to respond to the user. You decide which stored memories should be injected to help the agent give a correct, personalized answer.

MEMORY INDEX (all stored memories with their types and tags):
{index_text}

USER QUERY: {user_input}

DECISION PROCESS (think step by step):
1. What information does the agent need to answer this query correctly?
2. Does the user provide that information in their message?
3. If NO → which memory could fill that gap? Select it.
4. If the query references something (place, person, preference) that matches a memory's tags → select it.
5. If the user is asking about something that could be related to ANY stored fact → select the closest match.

RULES:
- You MUST return at least one key if any memory could help answer this query.
- NEVER invent key names. Only use keys from the MEMORY INDEX above.
- If the query is fully self-contained, has no ambiguity, and needs zero personal context → return [].

Return ONLY a JSON array of keys, nothing else. Do NOT explain your reasoning.

Relevant keys (JSON array only):"""

    recall_messages = [
        {"role": "system", "content": "You are a memory retrieval assistant. Return only relevant memory keys as a JSON array."},
        {"role": "user", "content": recall_prompt}
    ]

    try:
        response = vlm_client.chat(recall_messages, tools=None)
        # Extract JSON array from response
        # Find the first JSON array in the response
        match = re.search(r'\[.*?\]', response, re.DOTALL)
        if match:
            relevant_keys = json.loads(match.group())
        else:
            relevant_keys = []
    except Exception:
        relevant_keys = []

    if not relevant_keys:
        return messages, []

    # Load full content of relevant memories
    relevant_parts = []
    for key in relevant_keys:
        content = ltm.get(key)
        if content:
            relevant_parts.append(f"--- {key} ---\n{content}")

    if relevant_parts:
        memory_context = (
            "RECALLED MEMORIES — Use these BEFORE guessing any values.\n\n"
            "The following facts were saved from the user's past conversations. "
            "If your tool call requires information the user did NOT provide in this message, "
            "check these memories first. Only ask the user if no memory has the answer.\n\n"
            + "\n\n".join(relevant_parts)
        )
        # Insert as system message before the latest user message
        messages.insert(len(messages) - 1, {"role": "system", "content": memory_context})

    return messages, list(relevant_keys)
