# Long-Term Memory Index

Auto-generated. Each entry links to a .md file with full content.

- [girlfriend_location](girlfriend_location.md) — [user] 用户的女朋友住在杭州市钱塘区。 (用户信息, 位置, 女朋友)
- [user_location](user_location.md) — [user] 用户当前居住城市是杭州。 (用户信息, 位置)
- [女朋友家_洛阳](女朋友家_洛阳.md) — [user] 用户的女朋友家在河南省洛阳市 (女朋友, 洛阳, 河南, 关系)
- [老家_洛阳](老家_洛阳.md) — [user] 用户的老家在河南省洛阳市 (老家, 洛阳, 河南)
