"""Build the Chinese PDF/DOCX editions and blank CSV record sheets.

Dependencies: pymupdf, reportlab, python-docx, pillow.
Run from any directory; source astm.pdf lives in the parent directory.
"""
from pathlib import Path
import csv
import html
import re
import json
import hashlib
import zipfile

import pymupdf as fitz
from PIL import Image as PILImage
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    Image, KeepTogether,
)
from reportlab.platypus.tableofcontents import TableOfContents
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
SOURCE = ROOT.parent / 'astm.pdf'
BLUE = colors.HexColor('#173B56')
FALLBACK_CHARS = set('ᵐ⁴⁵⁶⁻₀−')
SYMBOL_FONT = Path('/usr/local/lib/python3.10/dist-packages/matplotlib/mpl-data/fonts/ttf/DejaVuSans.ttf')

# Figure numbers, Chinese titles and translated labels. Source plot values stay intact.
FIGURES = [
 ('1', 2, '压缩蠕变装置及其在环境箱中使用时的细节',
  'Clevis for hanging＝悬挂叉头；Stationary frame＝固定框架；Load rod＝加载杆；Guide tube＝导向管；Specimen＝试样；Mobile frame＝活动框架；Rigid steel rod＝刚性钢杆；Floating seal＝浮动密封；Floor of environ. chamb.＝环境箱底板；Weight＝砝码；Fixture＝夹具；Rigid ref. bench＝刚性基准台。A：不使用环境箱时百分表的位置；B：使用环境箱时百分表的位置。'),
 ('2', 3, '弯曲蠕变试验装置', '照片显示试样支承架、跨中吊架、位移表及下悬砝码。Rack＝试验架。'),
 ('3', 6, '不同时间的直角坐标等时应力—应变曲线', '纵轴：拉伸、压缩或弯曲应力，psi；横轴：时间 t 时的拉伸蠕变应变，%。Increasing time＝时间增加；t₁、t₂、t₃ 为不同取样时刻。'),
 ('4', 7, '不同应力水平下的双对数蠕变模量—时间曲线', '纵轴：蠕变模量，psi；横轴：时间，h。向下箭头表示应力增加；各曲线分别对应 σ₁～σ₄。'),
 ('5', 8, '双对数失效时间（应力断裂）曲线', '纵轴：应力，10³ psi；横轴：失效时间，h。Statistical regression＝统计回归，图示 log s = m log t + log b；右侧箭头指 1000 h 导致失效的应力。'),
 ('6', 8, '不同应力水平下的双对数蠕变应变—时间曲线', '纵轴：蠕变应变，%；横轴：时间，h。向上箭头表示应力增加，曲线依次为 σ₁、σ₂、σ₃。'),
 ('X2.1', 9, '蠕变曲线', '纵轴：总应变；横轴：时间。Initial elastic strain＝初始弹性应变；Initial plastic strain＝初始塑性应变；Primary／Secondary／Tertiary＝第 I／II／III 阶段；Fracture＝断裂。图注的说明见附录 X2 译文。'),
 ('X2.2', 9, 'PTFE 在 650 psi、23 ℃ 下的拉伸蠕变曲线', '纵轴：蠕变应变，%；横轴：时间，单位为 1000 h。PTFE 为聚四氟乙烯。'),
 ('X2.3', 10, '蠕变模量—时间曲线', '纵轴：蠕变模量，图示数值乘 10³；横轴：时间，1000 h。原图注：模量＝施加应力／总蠕变应变。'),
 ('X2.4', 10, '对数坐标下的蠕变模量—时间曲线', '纵轴：蠕变模量，图示数值乘 10³；横轴：时间，h。'),
 ('X3.1', 10, '蠕变速率', '纵轴：蠕变速率；横轴：总应变。I、II、III 表示三个蠕变阶段。'),
 ('X3.2', 10, '蠕变强度', '纵轴：应力；横轴：蠕变速率，%/h。'),
 ('X3.3', 10, '断裂强度', '纵轴：应力；横轴：时间。'),
 ('X3.4', 11, '蠕变断裂包络线', '纵轴：应变；横轴：时间。Creep rupture envelope＝蠕变断裂包络线；Increasing stress＝应力增加。'),
 ('X3.5', 11, '不同塑料的蠕变断裂应力—时间关系', '纵轴：应力，10³ psi；横轴：时间，h。A：SAN，23 ℃；B：环氧模塑料，120 ℃；C：30% 玻纤增强尼龙（干态），120 ℃；D：30% 玻纤增强 PBT，150 ℃；E：矿物填充酚醛模塑料，120 ℃；F：聚甲醛，80 ℃；G：抗冲击聚苯乙烯，23 ℃；H：醇酸模塑料，120 ℃。'),
 ('X4.1', 12, '恒定应力—应变—时间坐标', 'Stress＝应力；Strain＝应变；Log time＝对数时间。Constant time section (isochronous section)＝等时间截面（等时截面）；Constant strain section (isometric section)＝等应变截面；Constant stress section (creep curve)＝等应力截面（蠕变曲线）。'),
 ('X4.2', 12, '等时试验数据', '上图：施加应力—时间；下图：应变响应—时间。每一级加载持续 τ，卸载恢复持续 4τ；σ_n 表示第 n 级应力；ε_n(τ) 为该次加载后的总应变，ε_m 表示残余应变。原正文以 t 表示这一持续时间。'),
 ('X4.3', 12, '数值插值得到的蠕变数据', '纵轴：拉伸应变；横轴：时间，s；曲线旁数字为应力，lb/in²。20 ℃ 丙烯—乙烯共聚物，× 对应 2175 lb/in²，• 为其他实测数据，100 s 截面间距由等时实验确定。'),
 ('X4.4', 13, '图 X4.3 的等时间截面（等时截面）', '纵轴：拉伸应力，lb/in²；横轴：应变。曲线标注包括以秒表示的时间、1 day＝1 天、1 year＝1 年。'),
 ('X4.5', 13, '图 X4.3 的等应变截面', '纵轴：拉伸应力，lb/in²；横轴：时间，s。Limiting strain＝限制应变，图示为 0.010、0.015、0.020、0.025、0.030；1 day／1 week／1 year＝1 天／1 周／1 年。'),
 ('X5.1', 14, 'Boltzmann 叠加原理', '纵轴：蠕变百分应变；横轴：时间，s。图示在 400 s 时应力由 1000 增至 2000，原曲线与新增应力响应相加。'),
 ('X5.2', 14, '松弛主曲线', '纵轴：松弛模量 E(t)，图示单位 dyn/cm²；横轴：时间 min 或 t/a_T。插图：log a_T 与温度的关系；T_g＝0 ℃。主曲线构建的原图注见 X5 译文。'),
 ('X5.3', 15, '柔量曲线', '左图：不同温度下聚异戊二烯的蠕变柔量，数据来自分子量 1.12×10⁶ 的组分；横轴 log t（s），纵轴 log J_p(t)，柔量单位 cm²/dyn。右图：参考温度 −30 ℃ 时，不同分子量聚异戊二烯的蠕变柔量主曲线，横轴 log(t/a_T)（s）。曲线编号／分子量 Mw：I-21／5.76×10⁴；23／1.03×10⁵；25／1.59×10⁵；31／3.95×10⁵；32／6.20×10⁵；34／1.12×10⁶。两图均引自 Nemoto 等，Macromol., 4, 215 (1971)。'),
 ('X6.1', 16, '双曲正弦蠕变定律', '保留原图曲线。对应关系为 C = C₀ sinh(σ/σ₀)，见 X6.3；图内没有额外英文说明。'),
 ('X6.2', 17, '蠕变曲线的三个组成部分', '总应变为弹性、初级及次级部分之和；Time＝时间；Max.＝最大。各组成项及原图注见附录 X6 译文。'),
 ('X6.3', 17, '四元件模型', 'Strain＝应变；Stress＝应力；Creep＝蠕变；Recovery＝恢复；Model＝模型；Time＝时间。E₁、E₂ 为弹簧模量，η₁、η₂ 为黏壶参数；卸载后的曲线显示瞬时恢复、延迟恢复及残余变形。'),
 ('X7.1a', 18, '设计例题（第一页）', '图中正文、步骤、变量、表头及图注的中文翻译见附录 X7 例题 1；保留所有原表数值和曲线。'),
 ('X7.1b', 19, '设计例题（续页）', '上部为例题 1 的步骤 4、5 与答案，下部为例题 2；全文翻译见附录 X7。'),
]


def make_figures():
    source = fitz.open(SOURCE)
    page_counts = {}
    for ident, page, title, legend in FIGURES:
        image_infos = [x for x in source[page - 1].get_image_info() if x['width'] != 120]
        index = page_counts.get(page, 0)
        info = image_infos[index]
        page_counts[page] = index + 1
        target = ASSETS / f'fig_{ident}.png'
        source[page - 1].get_pixmap(matrix=fitz.Matrix(2.5, 2.5), clip=fitz.Rect(info['bbox'])).save(target)
    # Preserve the ambiguous printed equations for audit, beyond the graph images.
    source[14].get_pixmap(matrix=fitz.Matrix(2.2, 2.2), clip=fitz.Rect(28, 410, 570, 585)).save(ASSETS/'equations_X5.png')
    chunks = []
    for ident, page, title, legend in FIGURES:
        chunks.append(f'### 图 {ident} {title}〔原文第 {page} 页〕\n\n![图 {ident} {title}](assets/fig_{ident}.png)\n\n{legend}')
    chunks.append('### 附录 X5 疑点公式的原页局部\n\n![附录 X5 原式](assets/equations_X5.png)\n\n保留原版式以核对 X5.5、X5.6 及反应级数表达式；疑点说明见附录 X5 译注。')
    md = ROOT/'ASTM_D2990-09_中文译本.md'
    content = md.read_text()
    # Idempotently update the generated figure section.
    marker = '\n### 图 1 '
    if '{{FIGURES}}' in content:
        content = content.replace('{{FIGURES}}', '\n\n'.join(chunks))
    elif marker in content:
        content = content[:content.index(marker)] + '\n' + '\n\n'.join(chunks) + '\n'
    md.write_text(content)


def parse_md(text):
    lines = text.splitlines()
    blocks = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[:\- ]+', c) for c in cells):
                    rows.append(cells)
                i += 1
            blocks.append(('table', rows))
            continue
        m = re.match(r'^(#{1,3}) (.*)$', line)
        if m:
            blocks.append((f'h{len(m[1])}', m[2]))
        elif line.startswith('!['):
            m = re.match(r'!\[(.*?)\]\((.*?)\)', line)
            blocks.append(('image', (m[1], m[2])))
        else:
            blocks.append(('p', line))
        i += 1
    return blocks


def xml_text(s):
    return ''.join(f'<font name="Symbols">{html.escape(ch)}</font>' if ch in FALLBACK_CHARS else html.escape(ch) for ch in s.replace('`', ''))


class ChineseDoc(SimpleDocTemplate):
    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and getattr(flowable, '_toc_entry', None):
            text, key = flowable._toc_entry
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(text, key, level=0)
            self.notify('TOCEntry', (0, text, self.page, key))


def pdf_build(blocks, path):
    font_path = ASSETS/'chinese_font.ttf'
    if not font_path.exists():
        font_path.write_bytes(fitz.Font('cjk').buffer)
    if 'Chinese' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('Chinese', str(font_path)))
        pdfmetrics.registerFont(TTFont('Symbols', str(SYMBOL_FONT)))
    pdfmetrics.registerFontFamily('Chinese', normal='Chinese', bold='Chinese', italic='Chinese', boldItalic='Chinese')
    body = ParagraphStyle('BodyCN', fontName='Chinese', fontSize=10.2, leading=16.4,
                          spaceAfter=6, wordWrap='CJK', textColor=colors.HexColor('#24313B'))
    h2 = ParagraphStyle('H2CN', parent=body, fontSize=15, leading=22, textColor=BLUE,
                        spaceBefore=15, spaceAfter=10, keepWithNext=True)
    h3 = ParagraphStyle('H3CN', parent=body, fontSize=11.5, leading=18, textColor=BLUE,
                        spaceBefore=10, spaceAfter=6, keepWithNext=True)
    small = ParagraphStyle('SmallCN', parent=body, fontSize=8.3, leading=12.2, spaceAfter=3)
    toc_style = ParagraphStyle('TOCCN', parent=body, fontSize=10, leading=17, spaceAfter=3)
    title = next(v for k,v in blocks if k == 'h1')
    subtitle = next(v for k,v in blocks if k == 'h2')
    header_title = 'ASTM D2990—09 | 中文译本' if '中文译本' in title else 'ASTM D2990—09 | 详细实验手册'
    doc = ChineseDoc(str(path), pagesize=A4, leftMargin=46, rightMargin=46,
                    topMargin=51, bottomMargin=47, title=title, author='中文工作资料',
                    pageCompression=1)
    width = A4[0]-92
    story = [Spacer(1,100), Paragraph('ASTM D2990—09', ParagraphStyle('CoverK',parent=body,fontSize=17,leading=24,textColor=BLUE)),
             Spacer(1,25), Paragraph(title, ParagraphStyle('Cover',parent=body,fontSize=26,leading=38,textColor=BLUE)),
             Spacer(1,20), Paragraph(subtitle, ParagraphStyle('Sub',parent=body,fontSize=17,leading=27)),
             Spacer(1,45), Paragraph('依据用户提供的 2009 年版原文制作<br/>中文工作资料 · 2026 年 9 月 17 日',body),
             Spacer(1,16), Paragraph('保留原条款编号和技术参数。标准要求、译注及操作建议分别标明。',body),PageBreak(),
             Paragraph('内容导航',h2)]
    toc=TableOfContents();toc.levelStyles=[toc_style];story.extend([toc,PageBreak()])
    skip_h2=True
    bookmark=0
    for i,(kind,value) in enumerate(blocks):
        if kind=='h1': continue
        if kind=='h2' and skip_h2:
            skip_h2=False;continue
        if kind=='h2':
            if value=='原始图表与中文释义': story.append(PageBreak())
            p=Paragraph(xml_text(value),h2);p._toc_entry=(value,f'section_{bookmark}');bookmark+=1;story.append(p)
        elif kind=='h3': story.append(Paragraph(xml_text(value),h3))
        elif kind=='p': story.append(Paragraph(xml_text(value),body))
        elif kind=='table':
            n=len(value[0]);col_widths=[width/n]*n
            cells=[[Paragraph(xml_text(c),small) for c in row] for row in value]
            table=Table(cells,colWidths=col_widths,repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([
                ('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E7EFF5')),
                ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F6F8FA')]),
                ('GRID',(0,0),(-1,-1),0.35,colors.HexColor('#C3D0DA')),
                ('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),
                ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),5),
            ]));story.extend([table,Spacer(1,9)])
        elif kind=='image':
            alt,rel=value
            with PILImage.open(ROOT/rel) as im: w,h=im.size
            maxheight=590 if 'X7.1' in rel else 355
            scale=min(width/w,maxheight/h)
            picture=Image(str(ROOT/rel),width=w*scale,height=h*scale)
            picture.hAlign='CENTER'
            story.extend([picture,Spacer(1,7)])
    def footer(canvas,doc):
        canvas.saveState();canvas.setFont('Chinese',8);canvas.setFillColor(BLUE)
        canvas.drawString(46,A4[1]-30,header_title)
        canvas.setStrokeColor(colors.HexColor('#C3D0DA'));canvas.line(46,A4[1]-36,A4[0]-46,A4[1]-36)
        canvas.drawString(46,27,'依据所提供版本；中文工作资料')
        canvas.drawRightString(A4[0]-46,27,str(doc.page));canvas.restoreState()
    doc.multiBuild(story,onFirstPage=footer,onLaterPages=footer)


def docx_build(blocks,path):
    doc=Document();sec=doc.sections[0]
    sec.page_height=Cm(29.7);sec.page_width=Cm(21)
    sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.8)
    sec.left_margin=Cm(1.8);sec.right_margin=Cm(1.8)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3']:
        st=doc.styles[name];st.font.name='Calibri';st._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'等线')
    doc.styles['Normal'].font.size=Pt(10.5)
    doc.styles['Normal'].paragraph_format.line_spacing=1.25
    doc.styles['Normal'].paragraph_format.space_after=Pt(6)
    for name in ['Heading 1','Heading 2','Heading 3']:
        doc.styles[name].font.color.rgb=RGBColor.from_string('173B56')
    title=next(v for k,v in blocks if k=='h1')
    subtitle=next(v for k,v in blocks if k=='h2')
    doc.core_properties.title=title;doc.core_properties.subject='依据 astm.pdf 的中文工作资料'
    doc.add_paragraph('ASTM D2990—09','Subtitle')
    doc.add_paragraph(title,'Title');doc.add_paragraph(subtitle,'Subtitle')
    doc.add_paragraph('依据用户提供的 2009 年版原文制作\n中文工作资料 · 2026 年 9 月 17 日')
    doc.add_paragraph('保留原条款编号和技术参数。标准要求、译注及操作建议分别标明。')
    doc.add_page_break();doc.add_heading('内容导航',1)
    sections=[v for k,v in blocks if k=='h2'][1:]
    for s in sections:
        p=doc.add_paragraph(s);p.paragraph_format.space_after=Pt(2)
    doc.add_page_break()
    skip_h2=True
    for kind,value in blocks:
        if kind=='h1':continue
        if kind=='h2' and skip_h2:skip_h2=False;continue
        if kind in ['h2','h3']:
            if value=='原始图表与中文释义':doc.add_page_break()
            doc.add_heading(value,1 if kind=='h2' else 2)
        elif kind=='p':doc.add_paragraph(value.replace('`',''))
        elif kind=='table':
            table=doc.add_table(rows=1,cols=len(value[0]));table.style='Table Grid'
            for i,c in enumerate(value[0]):table.rows[0].cells[i].text=c
            trPr=table.rows[0]._tr.get_or_add_trPr();rep=OxmlElement('w:tblHeader');trPr.append(rep)
            for row in value[1:]:
                cells=table.add_row().cells
                for i,c in enumerate(row):cells[i].text=c
            for row in table.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        p.paragraph_format.space_after=Pt(3)
                        for run in p.runs:run.font.size=Pt(9)
            doc.add_paragraph()
        elif kind=='image':
            alt,rel=value
            with PILImage.open(ROOT/rel) as im:w,h=im.size
            width=min(16.5, (20 if 'X7.1' in rel else 13.5)*w/h)
            p=doc.add_paragraph();p.alignment=1
            p.add_run().add_picture(str(ROOT/rel),width=Cm(width))
    sec.header.paragraphs[0].text='ASTM D2990—09 | 中文工作资料'
    p=sec.footer.paragraphs[0];p.alignment=2
    p.add_run('第 ')
    f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f)
    p.add_run(' 页')
    doc.save(path)


def write_csv(name,header,rows):
    record=ROOT/'records';record.mkdir(exist_ok=True)
    with (record/name).open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.writer(f);writer.writerow(header);writer.writerows(rows)


def make_records():
    h=['试样编号','材料批次','取样方向','试验模式','位置号','宽度_mm','厚度_mm','直径_mm','初始标距_mm','跨距_mm','测量日期','操作者','备注']
    write_csv('01_试样尺寸记录.csv',h,[['','','','',i]+['']*(len(h)-5) for i in range(1,6)])
    h=['试样编号','温度设定_C','湿度设定_RH','介质组成浓度','应力目标_MPa','有效载荷目标_N','重复号','开始加载时间戳','达到全载时间戳','实际加载时长_s','计划结束_h','对照组编号','修正状态','设备工位','备注']
    write_csv('02_试验矩阵及加载.csv',h,[['']*len(h) for _ in range(14)])
    h=['试样编号','计划时点','计划经过_h','实际时间戳','实际经过_h','有效载荷_N','温度_C','湿度_RH','原始传感器读数','原始读数单位','参考读数','加载试样变形_mm','对照1带符号变化_mm','对照2带符号变化_mm','对照3带符号变化_mm','对照均值_mm','修正变形_mm','应变_小数','应变_百分数','蠕变模量_MPa','修正状态','备注']
    schedule=[('1 min',1/60),('6 min',.1),('12 min',.2),('30 min',.5)]+[(f'{x} h',x) for x in [1,2,5,20,50,100,200,500,700,1000]]
    write_csv('03_蠕变时间序列.csv',h,[['',label,t]+['']*(len(h)-3) for label,t in schedule])
    h=['试样编号','温度_C','应力_MPa','重复号','终止时间_h','终点类别_断裂或第三阶段或未失效','断裂时间_tr_h','失效时间_tf_h','第三阶段判据','断裂位置模式','是否删失观察','事件原始文件','照片路径','有效性结论及理由','复核者']
    write_csv('04_断裂失效及删失记录.csv',h,[['']*len(h) for _ in range(14)])
    h=['时间戳','试样或工位','事件类型','实测值','规定范围','开始时间','结束时间','持续时长','影响数据范围','处理决定','决定依据','操作者','复核者']
    write_csv('05_异常偏离记录.csv',h,[['']*len(h) for _ in range(8)])
    h=['試样编号'.replace('試','试'),'温度_C','应力_MPa','1000h应变_百分数','1000h模量_MPa','修正状态','终点类别','断裂或失效时间_h','是否用于回归','备注']
    write_csv('06_结果汇总.csv',h,[['']*len(h) for _ in range(10)])
    h=['试样或批次编号','处理阶段','开始时间','结束时间','持续时间_h','温度设定_C','实测温度最小_C','实测温度最大_C','湿度设定_RH','实测湿度最小_RH','实测湿度最大_RH','环境介质','水分平衡判据','水分平衡证据','操作者','备注']
    write_csv('07_状态调节与预处理.csv',h,[['']*len(h) for _ in range(6)])


def validate():
    summary={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source_pages':len(fitz.open(SOURCE)),'outputs':[]}
    for path in ROOT.glob('*.pdf'):
        d=fitz.open(path);texts=[p.get_text() for p in d]
        assert all(len(t.strip())>20 for t in texts),f'Empty page: {path}'
        alltext='\n'.join(texts)
        assert '\ufffd' not in alltext, f'Replacement glyphs in {path}'
        assert '{{FIGURES}}' not in alltext
        outside=[]
        for i,p in enumerate(d):
            for block in p.get_text('dict')['blocks']:
                if block['type']!=0:continue
                x0,y0,x1,y1=block['bbox']
                if x0<20 or y0<10 or x1>p.rect.width-15 or y1>p.rect.height-10:outside.append(i+1)
        summary['outputs'].append({'file':path.name,'pages':len(d),'characters':len(alltext),'possible_overflow_pages':sorted(set(outside))})
        for i in sorted(set([0,2,min(4,len(d)-1),len(d)-1])):
            d[i].get_pixmap(matrix=fitz.Matrix(1.2,1.2)).save(ASSETS/f'preview_{path.stem}_{i+1:02}.png')
    sample={'tensile_corrected_modulus_MPa':10/((.750-.040)/50),
            'flexural_load_N':2*10*12.7*3.18**2/(3*50.88),
            'flexural_modulus_MPa':10/(6*1*3.18/50.88**2),
            'compression_modulus_MPa':(500/12.7**2)/(.4/50),
            'interpolated_stress_MPa':7+(.01-.009)/(.013-.009)*(9-7)}
    summary['example_arithmetic']=sample
    (ROOT/'制作核对记录.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps(summary,ensure_ascii=False,indent=2))


def main():
    ASSETS.mkdir(exist_ok=True)
    make_figures();make_records()
    for name in ['ASTM_D2990-09_中文译本','ASTM_D2990-09_详细实验手册']:
        blocks=parse_md((ROOT/f'{name}.md').read_text())
        pdf_build(blocks,ROOT/f'{name}.pdf')
        docx_build(blocks,ROOT/f'{name}.docx')
    validate()
    with zipfile.ZipFile(ROOT/'ASTM_D2990-09_中文资料.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in ROOT.rglob('*'):
            if not p.is_file() or p.suffix=='.zip':continue
            if p.parent==ASSETS and not (p.name.startswith('fig_') or p.name=='equations_X5.png'):continue
            z.write(p,p.relative_to(ROOT))


if __name__=='__main__':main()
