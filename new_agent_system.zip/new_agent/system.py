#!/usr/bin/env python3
"""
智能工具调用系统 - 主入口文件
整合所有模块并提供完整的智能推理能力
"""

import asyncio
import logging
import json
import re
import yaml
from typing import Dict, Any, List
import sys
import os
import time

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 引入新库用于增强命令行界面和颜色输出
try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.completion import WordCompleter
    from prompt_toolkit.history import FileHistory
    from colorama import init, Fore, Style
    HAS_PROMPT_TOOLKIT = True
except ImportError:
    HAS_PROMPT_TOOLKIT = False

from core.intelligent_system import IntelligentToolSystem
from tools.tool_manager import ToolManager
from utils.monitoring import VLLMMonitoring
from utils.context_manager import ContextManager
from utils.config_manager import config_manager, get_config
from prompts import INTELLIGENT_SYSTEM_PROMPT

# 初始化colorama
init(autoreset=True)

logger = logging.getLogger(__name__)


class IntegratedIntelligentSystem(IntelligentToolSystem):
    """集成的智能工具系统"""
    
    def __init__(self, 
                 llm_host: str = "localhost", 
                 llm_port: int = 8000,
                 model_name: str = "Qwen2.5-7B-Instruct",
                 max_reasoning_iterations: int = 5):
        """
        初始化集成智能系统
        
        Args:
            llm_host: LLM模型服务主机地址
            llm_port: LLM模型服务端口
            model_name: 使用的模型名称
            max_reasoning_iterations: 最大推理轮数，防止无限循环
        """
        # 加载配置文件
        self.config = self._load_config()
        
        # 从配置中获取设置
        llm_host = self.config.get('llm', {}).get('host', 'localhost')
        llm_port = self.config.get('llm', {}).get('port', 8000)
        model_name = self.config.get('llm', {}).get('model_name', 'Qwen2.5-7B-Instruct')
        max_reasoning_iterations = self.config.get('system', {}).get('max_reasoning_iterations', 5)
        
        super().__init__(llm_host, llm_port, model_name, max_reasoning_iterations)
        
        # 初始化工具管理器
        self.tool_manager = ToolManager()
        self.tool_manager.initialize_tools()
        
        # 用于缓存RoboBrain模型实例
        self._robo_brain_models = {}
        
        # 新增：记录所有通过load命令加载的媒体文件路径
        self.load_summary = []
        
        # 确保会话ID正确初始化
        if hasattr(self, 'session_manager') and self.session_manager:
            # 检查是否已有会话ID，如果没有则尝试加载最新会话
            if not hasattr(self, 'current_session_id') or not self.current_session_id:
                try:
                    sessions = self.session_manager.list_sessions()
                    if sessions:
                        # 使用最新的会话
                        latest_session = sessions[0]
                        self.current_session_id = latest_session['session_id']
                        print(f"🔄 自动加载会话: {latest_session['session_name']}")
                except Exception as e:
                    print(f"⚠️ 会话加载失败: {e}")
        
    def _init_memory_management(self):
        """初始化记忆管理机制"""
        # 初始化内存中的历史记录
        self.tool_execution_memory = []
        self.user_interaction_memory = []
        
    def _load_memory_from_json(self):
        """从JSON文件加载记忆历史（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _save_memory_to_json(self):
        """将记忆保存到JSON文件（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _save_tool_execution_memory(self):
        """保存工具执行记忆（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _save_user_interaction_memory(self):
        """保存用户交互记忆（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _save_all_memory(self):
        """保存所有记忆（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            with open('config.yaml', 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            return config
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            # 返回默认配置
            return {
                'llm': {
                    'host': 'localhost',
                    'port': 8000,
                    'model_name': 'Qwen2.5-7B-Instruct'
                },
                'robobrain': {
                    'host': 'localhost',
                    'port': 8001,
                    'model_name': 'RoboBrain2.0 7B'
                },
                'system': {
                    'max_reasoning_iterations': 10
                }
            }
        
    def _create_intelligent_system_prompt(self) -> str:
        """创建支持多轮推理和结果反馈的智能系统提示"""
        
        # 使用导入的prompt
        prompt = INTELLIGENT_SYSTEM_PROMPT
        
        if self.current_image:
            prompt += f"\n当前图片路径: {self.current_image}\n"
            
        return prompt
    
    def _build_context_summary(self, current_iteration: int) -> str:
        """构建上下文摘要"""
        if not self.history_items:
            return "暂无历史推理记录"
        
        # 修复：构建完整的上下文，确保所有历史结果都包含进去
        context = "\n" + "="*60 + "\n"
        context += f"历史推理记录（当前轮次: {current_iteration + 1}）:\n"
        context += "="*60 + "\n"
        
        # 修复：按轮次顺序输出所有历史记录
        for i, record in enumerate(self.history_items):
            context += f"\n第 {i + 1} 轮推理:\n"
            
            # 添加思考过程
            if 'thinking' in record and record['thinking']:
                context += f"  分析: {record['thinking']}...\n"
            
            # 添加工具结果
            if 'tool_results' in record and record['tool_results']:
                for tool_result in record['tool_results']:
                    if tool_result['success']:
                        result_data = tool_result['result']
                        tool_name = tool_result['tool_name']
                        
                        if tool_name == 'browser_use_answer':
                            if 'final_result' in result_data:
                                context += f"  🔍 Query Result: {result_data['final_result']}...\n"
                            elif 'answer' in result_data:
                                context += f"  🔍 Search Result: {result_data['answer']}...\n"
                            elif 'result' in result_data and isinstance(result_data['result'], str):
                                context += f"  🔍 Query Result: {result_data['result']}...\n"
                            else:
                                context += f"  🔍 Browser Result: {str(result_data)}...\n"
                            
                        elif tool_name == 'visual_description':
                            if 'description' in result_data:
                                context += f"  📷 Visual Description: {result_data['description']}...\n"
                        elif tool_name in ['pointing', 'grounding', 'affordance', 'trajectory']:
                            # Handle various detection and planning tools results
                            if 'points' in result_data and result_data['points']:
                                context += f"  📍 {tool_name} Result: {result_data['points']}\n"
                            elif 'boxes' in result_data and result_data['boxes']:
                                context += f"  📦 {tool_name} Result: {result_data['boxes']}\n"
                            elif 'trajectory_points' in result_data and result_data['trajectory_points']:
                                context += f"  🛣️ {tool_name} Result: {result_data['trajectory_points']}\n"
                            else:
                                context += f"  🛠️ {tool_name} Result: {str(result_data)}...\n"
                        elif tool_name == 'planning':
                            # Special handling for planning tool results
                            if 'steps' in result_data and result_data['steps']:
                                context += f"  📋 {tool_name} Steps: {result_data['steps']}\n"
                            elif 'plan' in result_data and result_data['plan']:
                                context += f"  📋 {tool_name} Plan: {result_data['plan']}...\n"
                            elif 'action' in result_data and result_data['action']:
                                context += f"  🛠️ {tool_name} Action: {result_data['action']}\n"
                            else:
                                context += f"  🛠️ {tool_name} Result: {str(result_data)}...\n"
                        else:
                            context += f"  🛠️ {tool_name} Result: {str(result_data)}...\n"
        
        # 添加当前上下文中的工具结果（关键修复）
        if self.task_context:
            context += f"\n当前上下文中的工具结果:\n"
            # 显示所有工具结果，而非仅显示browser_use_answer
            # 不限制显示数量，显示完整结果
            for key, value in self.task_context.items():
                if key.endswith('_result') and isinstance(value, dict):
                    # 显示所有工具结果，不再限制只显示browser_use_answer
                    tool_name = key.replace('_result', '')
                    # 通用处理逻辑 - 显示完整结果
                    try:
                        # 优先检查result字段
                        if 'result' in value and isinstance(value['result'], dict):
                            result_data = value['result']
                            # 显示完整结果，不截断
                            context += f"  🔍 {tool_name} 结果: {json.dumps(result_data, ensure_ascii=False, indent=2)}\n"
                        elif 'result' in value and isinstance(value['result'], str):
                            # 显示完整字符串结果
                            context += f"  🔍 {tool_name} 结果: {value['result']}\n"
                        elif 'final_result' in value:
                            # 显示完整最终结果
                            context += f"  🔍 {tool_name} 结果: {value['final_result']}\n"
                        elif 'points' in value and value['points']:
                            points = value['points']
                            context += f"  🔍 {tool_name} 结果: 检测到 {len(points)} 个点，坐标: {points}\n"
                        elif 'boxes' in value and value['boxes']:
                            boxes = value['boxes']
                            context += f"  🔍 {tool_name} 结果: 检测到 {len(boxes)} 个边界框\n"
                        elif 'trajectory_points' in value and value['trajectory_points']:
                            trajectory_points = value['trajectory_points']
                            context += f"  🔍 {tool_name} 结果: 检测到 {len(trajectory_points)} 个轨迹点\n"
                        elif 'description' in value:
                            context += f"  📷 {tool_name} 结果: {value['description']}\n"
                        elif 'final_answer' in value:
                            context += f"  🔍 {tool_name} 结果: {value['final_answer']}\n"
                        elif 'answer' in value:
                            context += f"  🔍 {tool_name} 结果: {value['answer']}\n"
                        elif 'boxes' in value and value['boxes']:
                            # 特别处理grounding和affordance工具
                            boxes = value['boxes']
                            context += f"  🔍 {tool_name} 结果: 检测到 {len(boxes)} 个边界框\n"
                        elif 'points' in value and value['points']:
                            # 特别处理pointing工具
                            points = value['points']
                            context += f"  🔍 {tool_name} 结果: 检测到 {len(points)} 个点，坐标: {points}\n"
                        elif 'trajectory_points' in value and value['trajectory_points']:
                            # 特别处理trajectory工具
                            trajectory_points = value['trajectory_points']
                            context += f"  🔍 {tool_name} 结果: 检测到 {len(trajectory_points)} 个轨迹点\n"
                        elif 'description' in value:
                            # 特别处理visual_description工具
                            context += f"  📷 {tool_name} 结果: {value['description']}\n"
                        elif 'final_answer' in value:
                            # 特别处理browser_use_answer工具
                            context += f"  🔍 {tool_name} 结果: {value['final_answer']}\n"
                        elif 'answer' in value:
                            # 特别处理浏览器工具
                            context += f"  🔍 {tool_name} 结果: {value['answer']}\n"
                        else:
                            # 通用显示方式，显示完整结果
                            context += f"  🛠️ {tool_name} 结果: {json.dumps(value, ensure_ascii=False, indent=2)}\n"
                    except Exception as e:
                        # 处理意外的结构，确保不会因为格式问题停止显示
                        context += f"  🛠️ {tool_name} 结果: 无法解析结果 - {str(e)}\n"
        
        context += "="*60 + "\n"
        return context

    def _extract_tool_results_summary(self, reasoning_history: List[Dict]) -> str:
        """提取工具结果的摘要"""
        if not reasoning_history:
            return ""
        
        summary = "\n" + "="*50 + "\n"
        summary += "关键工具结果摘要:\n"
        summary += "="*50 + "\n"
        
        for i, record in enumerate(reasoning_history):
            if record.get('tool_results'):
                for tool_result in record['tool_results']:
                    if tool_result['success']:
                        result_data = tool_result['result']
                        
                        if tool_result['tool_name'] == 'browser_use_answer':
                            # 提取最终结果
                            final_result = ""
                            if 'final_result' in result_data:
                                final_result = result_data['final_result']
                            elif 'answer' in result_data:
                                final_result = result_data['answer']
                            elif 'result' in result_data and isinstance(result_data['result'], str):
                                final_result = result_data['result']
                            
                            if final_result:
                                summary += f"\n🔥 第{i+1}轮查询结果:\n{final_result}\n"
                        
                        elif tool_result['tool_name'] == 'visual_description':
                            if 'description' in result_data:
                                summary += f"\n📷 第{i+1}轮视觉识别结果:\n{result_data['description'][:300]}...\n"
        
        summary += "="*50 + "\n"
        return summary

    # 已移除JSON相关的上下文构建函数

    def _format_tool_results_summary(self, tool_results: List[Dict], simplified: bool = False) -> str:
        """格式化工具执行结果的汇总报告"""
        from colorama import Fore, Style
        if not tool_results:
            return ""
            
        if simplified:
            # 简化版输出
            summary = "\n📊 工具执行结果摘要:\n"
            summary += "-" * 30 + "\n"
            
            for i, tool_result in enumerate(tool_results):
                if tool_result['success']:
                    summary += f"✅ 工具 {i+1} ({tool_result['tool_name']}): 成功\n"
                else:
                    summary += f"❌ 工具 {i+1} ({tool_result['tool_name']}): 失败\n"
                    
            return summary
        else:
            # 完整版输出
            summary = f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n"
            summary += f"{Fore.CYAN}工具执行结果汇总:{Style.RESET_ALL}\n"
            summary += f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n"
            
            for i, tool_result in enumerate(tool_results):
                summary += f"\n工具 {i+1} ({tool_result['tool_name']}): "
                if tool_result['success']:
                    summary += f"{Fore.GREEN}✅ 成功{Style.RESET_ALL}\n"
                    result_data = tool_result['result']
                    
                    # 根据工具类型格式化输出
                    if tool_result['tool_name'] == "browser_use_answer":
                        if 'final_result' in result_data:
                            summary += f"  最终结果: {result_data['final_result']}\n"
                        elif 'answer' in result_data:
                            summary += f"  结果: {result_data['answer'][:100]}...\n"
                        elif 'result' in result_data and isinstance(result_data['result'], str):
                            summary += f"  结果: {result_data['result'][:100]}...\n"
                        else:
                            # 添加通用结果显示
                            summary += f"  工具结果: {str(result_data)[:100]}...\n"
                            
                    elif tool_result['tool_name'] in ["trajectory", "grounding", "affordance", "pointing"]:
                        if 'boxes' in result_data and result_data['boxes']:
                            summary += f"  检测到边界框数量: {len(result_data['boxes'])}\n"
                        elif 'points' in result_data and result_data['points']:
                            summary += f"  检测到点数量: {len(result_data['points'])}\n"
                        elif 'trajectory_points' in result_data and result_data['trajectory_points']:
                            summary += f"  轨迹点数量: {len(result_data['trajectory_points'])}\n"
                            
                    elif tool_result['tool_name'] == "planning":
                        if 'steps' in result_data and result_data['steps']:
                            summary += "  计划步骤:\n"
                            for j, step in enumerate(result_data['steps'], 1):
                                summary += f"    步骤 {j}: {step}\n"
                                
                    elif tool_result['tool_name'] == "visual_description":
                        if 'description' in result_data:
                            summary += f"  图像描述: {result_data['description'][:100]}...\n"
                else:
                    summary += f"{Fore.RED}❌ 失败: {tool_result.get('error', '未知错误')}{Style.RESET_ALL}\n"
                    
        return summary

    async def _execute_tool_call(self, tool_call: Dict[str, Any]) -> Dict[str, Any]:
        """执行单个工具调用 - 通用方法，让LLM决定参数"""
        tool_name = tool_call["tool_name"]
        parameters = tool_call.get("parameters", {})
        
        print(f"🔍 执行工具调用: {tool_name}")
        print(f"🔍 LLM提供的参数: {parameters}")
        
        # 基础参数处理（所有工具通用）
        if self.current_image and "image_path" not in parameters:
            parameters["image_path"] = self.current_image
        elif "image_path" not in parameters:
            parameters["image_path"] = "/workspace/wxd/Agent/images/test_6.png"
        
        # 移除硬编码的特定逻辑，让LLM负责参数构建
        if tool_name == "browser_use_answer":
            # 只做最基本的参数验证，不干预具体内容
            if "task" not in parameters or not parameters["task"].strip():
                # 如果LLM没有提供task，使用默认值但不干预具体内容
                parameters["task"] = "根据上下文进行网络查询"
            
            # browser工具不需要image_path参数
            if "image_path" in parameters:
                del parameters["image_path"]
                print("🔄 移除browser工具不需要的image_path参数")
        
        # 其他工具的基础参数验证
        elif tool_name in ["grounding", "affordance", "pointing"]:
            if "task" not in parameters:
                parameters["task"] = "执行检测任务"
        
        elif tool_name == "visual_description":
            if "task" not in parameters:
                parameters["task"] = "描述图像内容"
        
        print(f"🚀 调用工具 {tool_name}，最终参数: {parameters}")
        
        try:
            result = await self.tool_manager.execute_tool(
                tool_name=tool_name,
                params=parameters
            )
            print(f"✅ 工具 {tool_name} 执行成功")
            
            return {
                "success": True,
                "tool_name": tool_name,
                "result": result
            }
            
        except Exception as e:
            logger.error(f"执行工具 {tool_name} 出错: {e}")
            print(f"❌ 工具 {tool_name} 执行失败: {e}")
            return {
                "success": False,
                "tool_name": tool_name,
                "result": {},
                "error": str(e)
            }

    async def _execute_tool_chain(self, tool_calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """执行工具链"""
        tool_results = []
        
        for i, tool_call in enumerate(tool_calls):
            print(f"🔍 正在执行工具调用 {i+1}: {tool_call}")
            
            # 验证工具调用参数
            validated_tool_call = {}
            tool_name = tool_call.get("tool_name", "")
            parameters = tool_call.get("parameters", {})
            
            # 参数验证和修复
            if tool_name == "browser_use_answer":
                # 确保使用task参数
                if "query" in parameters and "task" not in parameters:
                    parameters["task"] = parameters["query"]
                    print(f"🔄 修复browser工具参数: query -> task")
                elif "task" not in parameters:
                    # 从上下文推断任务 - 这是browser_use_answer的特殊逻辑
                    if hasattr(self, 'reasoning_history') and hasattr(self.reasoning_history, '__len__') and len(self.reasoning_history) > 0:
                        last_thinking = self.reasoning_history[-1].get('thinking', '')
            
            validated_tool_call = {
                "tool_name": tool_name,
                "parameters": parameters
            }
            
            result = await self._execute_tool_call(validated_tool_call)
            tool_results.append(result)
            
            # 保存最新的工具结果，便于LLM识别
            # 简单地将工具结果添加到上下文中
            tool_name = tool_call['tool_name']
            tool_result_data = result['result'] if 'result' in result else result
            
            # 重要：确保工具结果正确保存，避免重复键
            # 生成带时间戳的唯一键名，避免冲突
            import time
            timestamp = int(time.time() * 1000) % 1000000
            context_key = f"{tool_name}_{timestamp}_result"
            
            # 确保只保存一次，避免重复键名
            self.task_context[context_key] = tool_result_data
            
            print(f"   🔍 已保存工具结果到上下文: {context_key} (键数量: {len(self.task_context)})")
            
            # ⚠️ 重要修改：失败时也要更新推理历史记录，确保LLM可以感知到失败
            if hasattr(self, 'reasoning_history') and self.reasoning_history:
                # 更新最新的推理历史记录，添加当前工具结果（即使是失败的）
                last_history = self.reasoning_history[-1]
                if 'tool_results' not in last_history:
                    last_history['tool_results'] = []
                last_history['tool_results'].append(result)
                if result['success']:
                    print(f"   🔍 推理历史已更新，添加成功工具结果")
                else:
                    print(f"   🔍 推理历史已更新，添加失败工具结果")
                    
            # ⚠️ 重要修复：确保推理历史的上下文更新在所有工具处理完成后进行
            # 修复：确保工具结果被正确保存到推理历史中
            # 这样LLM在后续推理中就能看到工具执行结果
            if hasattr(self, 'reasoning_history') and len(self.reasoning_history) > 0:
                # 确保推理历史记录中包含完整的上下文信息
                current_history = self.reasoning_history[-1]
                if 'context' not in current_history:
                    current_history['context'] = {}
                # 保存当前的上下文状态（更新后）
                current_history['context'].update(self.task_context)
                print(f"   🔍 推理历史完整上下文已更新")
                
            print(f"   🔍 工具执行完成，当前上下文键数量: {len(self.task_context)}")
        
        # ⚠️ 重要：在所有工具执行完成后，再次检查并更新上下文
        if hasattr(self, 'reasoning_history') and len(self.reasoning_history) > 0:
            current_history = self.reasoning_history[-1]
            if 'context' not in current_history:
                current_history['context'] = {}
            current_history['context'].update(self.task_context)
            print(f"   🔍 最终上下文更新完成，键数量: {len(self.task_context)}")
        
        return tool_results

    def _is_redundant_tool_call(self, tool_calls: List[Dict], reasoning_history: List[Dict]) -> bool:
        """增强重复调用检测逻辑 - 修复版本"""
        if not reasoning_history:
            return False
        
        print(f"🔍 重复调用检测 - 当前推理历史记录数量: {len(reasoning_history)}")
        
        # 检查当前工具调用是否与历史中的成功调用重复
        for tool_call in tool_calls:
            tool_name = tool_call.get('tool_name')
            parameters = tool_call.get('parameters', {})
            
            print(f"🔍 检查工具调用: {tool_name}，参数: {parameters}")
            
            # 检查历史中是否已有成功的相同工具调用
            for i, record in enumerate(reasoning_history):
                print(f"🔍 检查历史记录 {i+1}")
                if record.get('tool_results'):
                    print(f"🔍 历史记录 {i+1} 包含工具结果: {len(record['tool_results'])} 个")
                    for j, tool_result in enumerate(record['tool_results']):
                        print(f"🔍 工具结果 {j+1}: {tool_result['tool_name']} - 成功: {tool_result['success']}")
                        if (tool_result['tool_name'] == tool_name and 
                            tool_result['success']):
                            
                            # 检查工具参数是否完全一致
                            # 修复：正确获取历史参数
                            if 'result' in tool_result and 'parameters' in tool_result['result']:
                                history_params = tool_result['result']['parameters']
                            else:
                                history_params = {}
                                
                            print(f"🔍 比较参数 - 历史: {history_params}, 当前: {parameters}")
                            
                            # 对所有工具都进行参数完全匹配检查
                            if parameters == history_params:
                                print(f"⚠️ 检测到重复的{tool_name}工具调用（完全相同参数）")
                                print(f"   阻止执行")
                                return True  # 阻止重复执行
                            else:
                                print(f"   参数不同，允许执行")
                                return False  # 不阻止
                            
        return False

    def _generate_final_answer_from_results(self, all_tool_results: List[Dict]) -> str:
        """基于已有工具结果生成最终答案"""
        if not all_tool_results:
            return "无法确定下一步行动，请提供更明确的指令。"
        
        # 提取关键信息
        visual_result = None
        browser_result = None
        
        for result in all_tool_results:
            if result['tool_name'] == 'visual_description' and result['success']:
                visual_result = result['result']
            elif result['tool_name'] == 'browser_use_answer' and result['success']:
                browser_result = result['result']
        
        # 构建最终答案
        if visual_result and browser_result:
            answer = "🎯 基于收集的信息，分析结果如下：\n\n"
            
            # 添加视觉描述摘要
            if 'description' in visual_result:
                answer += f"📷 图片内容识别:\n{visual_result['description'][:300]}...\n\n"
            return answer
        else:
            return "收集了部分信息，但不足以给出完整答案。"

    def _generate_timeout_answer(self, all_tool_results: List[Dict]) -> str:
        """达到最大迭代次数时生成答案"""
        if not all_tool_results:
            return "达到最大推理轮数，但未能收集到有效信息。"
        
        answer = "达到最大推理轮数，以下是收集的信息总结。"
        for result in all_tool_results:
            if result['success']:
                result_data = result['result']
                if 'description' in result_data:
                    answer += f"\n视觉描述: {result_data['description'][:200]}..."
                elif 'final_result' in result_data:
                    answer += f"\n查询结果: {result_data['final_result']}"
        return answer

    async def intelligent_reasoning_loop(self, command: str) -> Dict[str, Any]:
        """通用多轮推理循环"""
        print(f"🧠 开始智能多轮推理: {command}")
        
        # 初始化推理状态
        all_tool_results = []
        final_answer = None

        # 每轮推理把前几轮的执行结果包含在当前轮次的提示中
        for iteration in range(self.max_reasoning_iterations):
            print(f"\n🔄 第 {iteration + 1} 轮推理")
            self.monitor.log_reasoning_iteration(iteration + 1)
            
            # 构建系统提示
            system_prompt = self._create_intelligent_system_prompt()
            
            # 添加调试信息：打印传递给LLM的上下文
            print(f"\n🔍 调试信息 - 传递给LLM的上下文:")
            print("┌" + "─" * 100 + "┐")
            print("│ {:<38} │".format("推理轮数: " + str(iteration + 1)))
            print("│ {:<38} │".format("工具数量: " + str(len(all_tool_results))))
            print("│ {:<38} │".format("历史记录: " + str(len(self.history_items))))
            print("│ {:<38} │".format("上下文键: " + str(len(self.task_context))))
            print("├" + "─" * 100 + "┤")
            
            if self.task_context:
                # 只显示一次当前任务上下文包含
                print("│ 当前任务上下文包含:")
                # 显示所有工具调用结果，包括编号，最多显示20个
                context_items = list(self.task_context.items())
                displayed_count = 0
                
                # 为每个工具结果添加执行顺序信息
                items_with_order = []
                for key, value in context_items:
                    if key.endswith('_result') and isinstance(value, dict):
                        # 识别工具类型
                        tool_name = key.replace('_result', '').split('_')[0] if len(key.split('_')) > 2 else key.replace('_result', '')
                        # 使用时间戳作为排序依据（如果有的话）
                        timestamp = 0
                        if len(key.split('_')) > 2:
                            try:
                                # 从键名中提取时间戳
                                # 假设格式为 toolname_timestamp_result 或 toolname_result (带编号)
                                # 从最后一个数字部分提取时间戳
                                parts = key.split('_')
                                for i in range(len(parts) - 1, -1, -1):  # 逆向遍历
                                    if parts[i].isdigit():
                                        timestamp = int(parts[i])
                                        break
                            except:
                                timestamp = 0
                        items_with_order.append((key, value, tool_name, timestamp))
                
                # 按时间戳排序（如果时间戳存在）
                if items_with_order:
                    items_with_order.sort(key=lambda x: x[3])
                    sorted_items = [(item[0], item[1]) for item in items_with_order]
                else:
                    sorted_items = context_items
                
                # 用于去重，避免显示重复的工具结果
                displayed_tool_results = set()
                
                # 分别处理带编号的工具结果和不带编号的最新结果
                # 首先显示带编号的历史结果
                history_results = []
                current_results = []
                
                for key, value in sorted_items:
                    # 只处理以_result结尾的键
                    if key.endswith('_result') and isinstance(value, dict):
                        # 区分历史结果和当前结果
                        # 简单检测：如果键名中包含数字，则为带编号的历史结果
                        if any(char.isdigit() for char in key):
                            # 包含数字的键是历史结果
                            history_results.append((key, value))
                        else:
                            # 不包含数字的键是当前结果
                            current_results.append((key, value))
                
                # 显示历史结果（带编号）
                for key, value in history_results[:15]:  # 显示前15个历史结果
                    # 避免重复显示
                    if key in displayed_tool_results:
                        continue
                    displayed_tool_results.add(key)
                    
                    # 显示完整工具调用信息
                    key_str = str(key)[:50] + "..." if len(str(key)) > 50 else str(key)
                    print("│   {:<50} │".format(key_str))
                    # 显示工具调用的详细信息
                    try:
                        # 获取工具名称
                        tool_name = value.get('tool', value.get('tool_name', 'unknown'))
                        success = value.get('success', False)
                        task = value.get('task', '无任务')
                        
                        # 显示详细信息
                        print("│     工具: {:<15} │".format(tool_name))
                        print("│     状态: {:<15} │".format("成功" if success else "失败"))
                        print("│     任务: {:<15} │".format(str(task)))
                        
                        # 显示结果摘要 - 修复：显示实际结果内容而不是"图像描述"
                        result_data = value.get('result', value)
                        if isinstance(result_data, dict):
                            if 'boxes' in result_data:
                                print("│     结果: {}".format(result_data['boxes']))
                            elif 'points' in result_data:
                                print("│     结果: {}".format(result_data['points']))
                            elif 'trajectory_points' in result_data:
                                print("│     结果: {}".format(result_data['trajectory_points']))
                            elif 'description' in result_data:
                                # 显示实际描述内容而不是固定文本
                                desc_preview = result_data['description']
                                print("│     结果: {}".format(desc_preview))
                            elif 'final_answer' in result_data:
                                # 显示实际答案内容
                                answer_preview = result_data['final_answer']
                                print("│     结果: {}".format(answer_preview))
                            elif 'answer' in result_data:
                                # 显示实际答案内容
                                answer_preview = result_data['answer']
                                print("│     结果: {}".format(answer_preview))
                            else:
                                # 通用显示 - 显示实际内容
                                print("│     结果: {}".format(str(result_data)))
                        else:
                            print("│     结果: {}".format(str(result_data)))
                    except Exception as e:
                        print("│     信息解析错误: {}".format(str(e)))
                    displayed_count += 1
                
                if len(context_items) > 20:
                    print("│   ... (还有 " + str(len(context_items) - 20) + " 项)" + " " * 36 + " │")
                elif len(context_items) == 0:
                    print("│   无结果" + " " * 68 + " │")
            if self.load_summary:
                print("│ 已加载的媒体文件列表:" + " " * 60 + " │")
                for i, load_info in enumerate(self.load_summary, 1):
                    print("│   {:<3} │ {:<50} │ {:<15} │".format(i, load_info['path'][:48], str(load_info['timestamp'])[:15]))
                print("└" + "─" * 100 + "┘")
            else:
                print("└" + "─" * 100 + "┘")
            
            user_prompt = f"""
用户问题: {command}

当前状态:
- 推理轮数: {iteration + 1}
- 已执行工具: {len(all_tool_results)}个
- 可用信息: {'有历史结果' if self.history_items else '初始状态'}
- 工具执行结果: {self._format_history_results_for_llm()}

请基于当前上下文动态决策：
1. 分析问题类型和所需信息
2. 选择合适的工具并构建具体参数
3. 确保参数明确反映当前推理需求
4. 充分利用已有结果，避免重复调用
5. 注意区分历史结果和当前结果的使用场景

重要：你负责工具选择和参数构建，不要依赖预定义规则！
"""

            user_prompt += f"""
    当前是第{iteration + 1}轮推理，请基于已有信息决定下一步：
    - 如果信息足够，给出最终答案
    - 如果还需要信息，选择合适的工具并构建具体参数
    - 确保每个工具调用都有明确目的
    """
            
            # 调用LLM进行决策
            start_time = time.time()
            llm_response = await self._call_llm_api(system_prompt, user_prompt)
            llm_time = time.time() - start_time
            self.monitor.log_llm_inference(llm_time)
            
            # 解析LLM响应
            response_text = llm_response["response"]
            print(f"📄 LLM响应内容:\n{response_text}")
            
            # 修复：改进最终答案提取逻辑，避免因XML结构不完整导致的问题
            sections = self._extract_xml_sections(response_text)
            
            # 优先检查final_answer标签
            final_answer = ""
            if 'final_answer' in sections and sections['final_answer'].strip():
                final_answer_text = sections['final_answer'].strip()
                if final_answer_text not in ['待定', '暂定', '未知', '不确定']:
                    print("✅ LLM决定给出最终答案")
                    final_answer = final_answer_text
                    # 添加到历史记录
                    self._add_to_history({
                        "iteration": iteration + 1,
                        "thinking": sections.get('thinking', ''),
                        "final_answer": final_answer,
                        "llm_response": response_text
                    })
                    break
            else:
                # 如果没有明确的final_answer标签，但有明确的最终答案内容
                # 检查响应是否包含最终答案的关键字
                if "最终答案" in response_text or "最终结果" in response_text:
                    # 尝试从响应中提取最终答案内容
                    final_answer_text = response_text
                    # 简单提取最终答案内容
                    if "<thinking>" in response_text and "</thinking>" in response_text:
                        # 提取thinking部分之后的内容
                        thinking_end = response_text.find("</thinking>") + len("</thinking>")
                        if thinking_end > len("</thinking>"):
                            final_answer_text = response_text[thinking_end:].strip()
                    # 如果最终答案不为空，则使用它
                    if final_answer_text.strip() and len(final_answer_text.strip()) > 10:
                        print("✅ LLM返回了最终答案（通过内容识别）")
                        final_answer = final_answer_text
                        self._add_to_history({
                            "iteration": iteration + 1,
                            "thinking": sections.get('thinking', ''),
                            "final_answer": final_answer,
                            "llm_response": response_text
                        })
                        break
            
            # 检查工具调用
            tool_calls = self._extract_tool_calls_from_response(response_text)
            
            # 如果没有工具调用且没有最终答案，尝试生成默认最终答案
            if not tool_calls and not final_answer:
                print("⚠️ LLM没有返回工具调用，尝试给出最终答案")
                final_answer = self._generate_final_answer_from_results(all_tool_results)
                # 添加到历史记录
                self._add_to_history({
                    "iteration": iteration + 1,
                    "thinking": sections.get('thinking', ''),
                    "final_answer": final_answer,
                    "llm_response": response_text
                })
                break
            
            # 提取工具调用
            tool_calls = self._extract_tool_calls_from_response(response_text)
            
            if not tool_calls:
                print("⚠️ LLM没有返回工具调用，尝试给出最终答案")
                final_answer = self._generate_final_answer_from_results(all_tool_results)
                # 添加到历史记录
                self._add_to_history({
                    "iteration": iteration + 1,
                    "thinking": sections.get('thinking', ''),
                    "final_answer": final_answer,
                    "llm_response": response_text
                })
                break
            
            # 检查重复调用
            # 修复：使用正确的推理历史来检测重复调用，确保包括当前轮次的工具结果
            if self._is_redundant_tool_call(tool_calls, self.reasoning_history):
                print("⚠️ 检测到重复工具调用，强制生成最终答案")
                final_answer = self._generate_final_answer_from_results(all_tool_results)
                # 添加到历史记录
                self._add_to_history({
                    "iteration": iteration + 1,
                    "thinking": sections.get('thinking', ''),
                    "final_answer": final_answer,
                    "llm_response": response_text
                })
                break
            
            # 执行工具调用（使用通用方法）
            print(f"🔧 执行 {len(tool_calls)} 个工具调用")
            tool_results = await self._execute_tool_chain(tool_calls)
            all_tool_results.extend(tool_results)
            
            # 将结果保存到任务上下文中
            # ⚠️ 重要修复：只保存必要的工具结果键，避免重复存储
            # 移除last_前缀的键，避免产生重复的上下文键
            # 但添加前先检查是否已存在相同键名
            for tool_result in tool_results:
                if tool_result['success']:
                    tool_name = tool_result['tool_name']
                    result_data = tool_result['result']
                    # 重要修复：确保工具结果以正确格式保存到上下文
                    # 避免覆盖已存在的相同键
                    context_key = f"{tool_name}_result"
                    if context_key in self.task_context:
                        # 如果已存在，使用时间戳确保唯一性
                        timestamp = int(time.time() * 1000) % 1000000
                        context_key = f"{tool_name}_{timestamp}_result"
                    self.task_context[context_key] = result_data
                    # 不再添加last_前缀的键，避免重复存储
                    # 之前的代码中添加了last_{tool_name}_result键，这是造成问题的原因
            
            # 添加到历史记录（确保历史记录包含工具结果）
            history_record = {
                "iteration": iteration + 1,
                "thinking": sections.get('thinking', ''),
                "tool_results": tool_results,
                "llm_response": response_text
            }
            self._add_to_history(history_record)
            
            # 修复：更新推理历史，确保工具结果正确保存到reasoning_history中
            if len(self.reasoning_history) > 0:
                # 更新当前轮次的推理历史记录
                current_history = self.reasoning_history[-1]
                current_history["tool_results"] = tool_results
                current_history["thinking"] = sections.get('thinking', '')
                current_history["iteration"] = iteration + 1
            
            # 确保在每轮结束后更新reasoning_history
            # 这样可以确保后续推理轮次能正确访问到之前的结果
            # 重要：不要用history_items覆盖reasoning_history，要保持推理历史连续性
            # self.reasoning_history = self.history_items
            
            # 重要：在每轮推理后保存会话数据 - 结构化会话存储
            if self.session_enabled:
                self._save_structured_session_data(command, iteration + 1, tool_results, sections.get('thinking', ''), final_answer)
            
            if iteration == self.max_reasoning_iterations - 1:
                print("⚠️ 达到最大推理轮数，强制结束")
                final_answer = self._generate_timeout_answer(all_tool_results)
                # 添加到历史记录
                self._add_to_history({
                    "iteration": iteration + 1,
                    "thinking": "达到最大轮数",
                    "final_answer": final_answer,
                    "llm_response": response_text
                })
                break
        
        # 保存完整的历史记录到reasoning_history
        self.reasoning_history = self.history_items
        
        return {
            "final_answer": final_answer,
            "reasoning_history": self.history_items,
            "all_tool_results": all_tool_results,
            "total_iterations": len(self.history_items)
        }

    def _handle_session_selection(self):
        """处理会话选择逻辑"""
        print(f"\n{Fore.CYAN}🔄 会话管理{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
        
        # 检查是否有已保存的会话
        sessions = self.session_manager.list_sessions()
        
        if sessions:
            print(f"检测到 {len(sessions)} 个已保存的会话:")
            print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
            # 使用表格形式显示会话信息
            print(f"{Fore.MAGENTA}{'序号':<4} {'会话名称':<25} {'创建时间':<15} {'状态':<10}{Style.RESET_ALL}")
            print("-" * 60)
            
            for i, session in enumerate(sessions[:5], 1):  # 只显示前5个
                import datetime
                created_time = datetime.datetime.fromtimestamp(session['created_at'])
                # 状态颜色显示
                status_color = Fore.GREEN if session['status'] == 'active' else Fore.YELLOW
                print(f"{Fore.CYAN}{i:<4} {session['session_name'][:23]:<25} {created_time.strftime('%m-%d %H:%M'):<15} {status_color}{session['status']:<10}{Style.RESET_ALL}")
            
            if len(sessions) > 5:
                print(f"{Fore.CYAN}... 还有 {len(sessions) - 5} 个会话{Style.RESET_ALL}")
            
            print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
            print("请选择会话操作:")
            print("1. 继续使用最新会话")
            print("2. 选择特定会话")
            print("3. 创建新会话")
            print("4. 查看所有会话")
            print("5. 退出程序")
            
            try:
                choice = input(f"\n{Fore.YELLOW}请输入选择 (1-5): {Style.RESET_ALL}").strip()
                
                if choice == '1':
                    # 继续使用最新会话 - 已经在初始化时处理
                    print(f"{Fore.GREEN}✅ 继续使用最新会话{Style.RESET_ALL}")
                elif choice == '2':
                    # 选择特定会话
                    session_choice = input(f"{Fore.YELLOW}请输入会话序号: {Style.RESET_ALL}").strip()
                    if session_choice.isdigit() and 1 <= int(session_choice) <= len(sessions):
                        selected_session = sessions[int(session_choice) - 1]
                        print(f"{Fore.GREEN}🔄 加载会话: {selected_session['session_name']}{Style.RESET_ALL}")
                        session_data = self.session_manager.load_session(selected_session['session_id'])
                        if session_data:
                            # 恢复会话数据
                            self.task_context = session_data.get('task_context', {})
                            self.reasoning_history = session_data.get('reasoning_history', [])
                            self.tool_execution_memory = session_data.get('tool_execution_memory', [])
                            self.conversation_history = session_data.get('conversation_history', [])
                            self.load_summary = session_data.get('load_summary', [])  # 修复：恢复加载的图片信息
                            self.history_items = [item for item in self.reasoning_history if 'context' in item]
                            print(f"{Fore.GREEN}✅ 会话已恢复{Style.RESET_ALL}")
                            # 更新会话状态显示 - 修复：正确显示当前会话名称
                            print(f"{Fore.CYAN}当前会话: {selected_session['session_name']}{Style.RESET_ALL}")
                            # 重要：同时更新当前会话ID
                            self.current_session_id = selected_session['session_id']
                        else:
                            print(f"{Fore.RED}❌ 会话加载失败{Style.RESET_ALL}")
                    else:
                        print(f"{Fore.RED}❌ 无效选择{Style.RESET_ALL}")
                elif choice == '3':
                    # 创建新会话
                    session_name = input(f"{Fore.YELLOW}请输入新会话名称 (回车使用默认名称): {Style.RESET_ALL}").strip()
                    if not session_name:
                        session_name = "新会话 " + time.strftime("%Y-%m-%d %H:%M:%S")
                    new_session_id = self.session_manager.create_session(session_name)
                    print(f"{Fore.GREEN}✅ 创建新会话: {session_name}{Style.RESET_ALL}")
                    print(f"{Fore.CYAN}当前会话: {session_name}{Style.RESET_ALL}")
                elif choice == '4':
                    # 查看所有会话
                    self._list_all_sessions()
                elif choice == '5':
                    print(f"{Fore.YELLOW}👋 程序退出{Style.RESET_ALL}")
                    exit(0)
                else:
                    print(f"{Fore.RED}❌ 无效选择，使用默认会话{Style.RESET_ALL}")
            except Exception as e:
                print(f"{Fore.RED}⚠️ 会话选择出错: {e}{Style.RESET_ALL}")
                print(f"{Fore.YELLOW}使用默认会话{Style.RESET_ALL}")
        else:
            print(f"{Fore.YELLOW}📝 暂无已保存的会话，创建新会话...{Style.RESET_ALL}")
            session_name = "新会话 " + time.strftime("%Y-%m-%d %H:%M:%S")
            self.session_manager.create_session(session_name)
            print(f"{Fore.GREEN}✅ 创建新会话: {session_name}{Style.RESET_ALL}")
            print(f"{Fore.CYAN}当前会话: {session_name}{Style.RESET_ALL}")
    
    def _list_all_sessions(self):
        """列出所有会话"""
        sessions = self.session_manager.list_sessions()
        if not sessions:
            print("📝 暂无会话")
            return
            
        print("\n📋 所有会话列表:")
        print("=" * 80)
        print(f"{'序号':<4} {'会话名称':<30} {'创建时间':<20} {'状态':<10}")
        print("-" * 80)
        
        for i, session in enumerate(sessions, 1):
            import datetime
            created_time = datetime.datetime.fromtimestamp(session['created_at'])
            print(f"{i:<4} {session['session_name'][:28]:<30} {created_time.strftime('%Y-%m-%d %H:%M'):<20} {session['status']:<10}")
        
        print("=" * 80)
        print("输入会话序号查看详细信息，或输入 'back' 返回")
        
        try:
            detail_choice = input("请选择会话查看详细信息: ").strip()
            if detail_choice.isdigit() and 1 <= int(detail_choice) <= len(sessions):
                selected_session = sessions[int(detail_choice) - 1]
                session_info = self.session_manager.get_session_info(selected_session['session_id'])
                if session_info:
                    print("\n📋 会话详细信息:")
                    print("-" * 50)
                    print(f"会话ID: {session_info['session_id']}")
                    print(f"会话名称: {session_info['session_name']}")
                    print(f"创建时间: {datetime.datetime.fromtimestamp(session_info['created_at']).strftime('%Y-%m-%d %H:%M:%S')}")
                    print(f"更新时间: {datetime.datetime.fromtimestamp(session_info['updated_at']).strftime('%Y-%m-%d %H:%M:%S')}")
                    print(f"状态: {session_info['status']}")
                    print(f"上下文项数: {len(session_info.get('context', {}))}")
                    print(f"推理历史: {len(session_info.get('reasoning_history', []))} 轮")
                    print(f"工具执行记录: {len(session_info.get('tool_execution_memory', []))} 条")
                    print("-" * 50)
        except Exception as e:
            print(f"⚠️ 查看会话详情出错: {e}")
    
    def start_interactive_session(self):
        """启动交互式会话"""
        # 首先检查并处理会话选择
        self._handle_session_selection()
        
        # 定义命令补全列表
        commands = ['load', 'image', 'task', 'monitor', 'history', 'help', 'quit', '退出', 'debug', 'clear', 'sessions']
        tool_names = list(self.tool_manager.get_tool_descriptions().keys())
        completer = WordCompleter(commands + tool_names, ignore_case=True)
        
        # 创建会话
        if HAS_PROMPT_TOOLKIT:
            session = PromptSession(
                history=FileHistory('.agent_history'),
                completer=completer,
                # 设置提示符
                prompt_continuation=lambda width, lineno, is_soft_wrap: '',
            )
        else:
            session = None
        
        # 启动界面美化
        self._print_welcome_screen()
        
        # 调试模式标志
        debug_mode = False
        
        while True:
            try:
                # 使用增强的输入界面
                if HAS_PROMPT_TOOLKIT and session:
                    try:
                        user_input = session.prompt(
                            f"👤 你: ",
                        ).strip()
                    except KeyboardInterrupt:
                        print(f"\n👋 程序退出")
                        break
                    except EOFError:
                        print(f"\n👋 程序退出")
                        break
                else:
                    # 降级到基础输入
                    user_input = input("👤 你: ").strip()
                
                if not user_input:
                    continue
                elif user_input.lower() in ['quit', '退出']:
                    print(f"{Fore.YELLOW}👋 程序退出{Style.RESET_ALL}")
                    break
                elif user_input.lower() == 'help':
                    self._display_help()
                    continue
                elif user_input.lower() == 'monitor':
                    self.display_monitoring()
                    continue
                elif user_input.lower() == 'history':
                    self._display_reasoning_history()
                    continue
                elif user_input.lower() == 'debug':
                    debug_mode = not debug_mode
                    print(f"{'启用' if debug_mode else '禁用'}调试模式")
                    continue
                elif user_input.lower() == 'clear':
                    # 清屏命令
                    import os
                    os.system('cls' if os.name == 'nt' else 'clear')
                    print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
                    self._print_welcome_screen()
                    continue
                elif user_input.lower().startswith('load '):
                    image_path = user_input[5:].strip()
                    self.load_image(image_path)
                    continue
                elif user_input.lower() == 'image':
                    self._display_loaded_images()
                    # 添加选择图片的功能
                    if self.load_summary:
                        try:
                            choice = input("请输入要选择的图片序号 (或输入 'cancel' 取消): ").strip()
                            if choice.isdigit():
                                choice_index = int(choice) - 1
                                if 0 <= choice_index < len(self.load_summary):
                                    selected_image = self.load_summary[choice_index]['path']
                                    self.current_image = selected_image
                                    self.context['current_image'] = selected_image
                                    print(f"✅ 已选择图片: {selected_image}")
                                else:
                                    print("❌ 无效的序号")
                            elif choice.lower() != 'cancel':
                                print("❌ 请输入有效的序号或 'cancel'")
                        except Exception as e:
                            print(f"❌ 选择图片时出错: {e}")
                    continue
                elif user_input.lower() == 'sessions':
                    self._list_all_sessions()
                    continue
                else:
                    # 处理命令
                    start_time = time.time()
                    result = asyncio.run(self.chat_with_intelligent_llm(user_input, debug=debug_mode))
                    total_time = time.time() - start_time
                    self.monitor.log_total_processing(total_time)
                    
                    # 美化输出格式
                    # 按不同模块分隔显示
                    lines = result.strip().split('\n')
                    
                    # 分析并分组内容
                    current_section = None
                    section_content = []
                    sections = []
                    
                    # 特别处理工具执行结果部分
                    for i, line in enumerate(lines):
                        # 检查是否是工具执行结果的开始
                        if line.startswith("📊 工具执行结果摘要"):
                            if current_section is not None:
                                sections.append((current_section, section_content))
                                section_content = []
                            current_section = "工具执行结果"
                            section_content.append(line)
                        elif line.startswith("📊 推理过程总结"):
                            if current_section is not None:
                                sections.append((current_section, section_content))
                                section_content = []
                            current_section = "推理总结"
                            section_content.append(line)
                        elif line.startswith("🎯 最终答案"):
                            if current_section is not None:
                                sections.append((current_section, section_content))
                                section_content = []
                            current_section = "最终答案"
                            section_content.append(line)
                        elif line.startswith("✅") or line.startswith("❌"):
                            if current_section is not None:
                                sections.append((current_section, section_content))
                                section_content = []
                            current_section = "工具执行结果"  # 确保状态正确
                            section_content.append(line)
                        elif current_section == "工具执行结果" and line.strip() == "":
                            # 如果在工具执行结果中遇到空行，可能是多个结果
                            section_content.append(line)
                        elif line.startswith("🔍") and "工具执行结果" in line:
                            if current_section is not None:
                                sections.append((current_section, section_content))
                                section_content = []
                            current_section = "工具执行结果"
                            section_content.append(line)
                        elif current_section is not None and (line.startswith("🎯") or line.startswith("📊") or line.startswith("🔍")):
                            # 如果遇到新的部分，保存当前部分
                            sections.append((current_section, section_content))
                            section_content = []
                            if line.startswith("🎯"):
                                current_section = "最终答案"
                            elif line.startswith("📊"):
                                current_section = "推理总结"
                            elif line.startswith("🔍"):
                                current_section = "其他内容"
                            section_content.append(line)
                        elif current_section is not None and line.strip() == "":
                            # 空行处理
                            section_content.append(line)
                        elif current_section is not None:
                            # 在当前部分中继续添加内容
                            section_content.append(line)
                        else:
                            # 处理开头内容
                            if line.startswith("🎯") or line.startswith("📊") or line.startswith("🔍") or line.startswith("✅") or line.startswith("❌"):
                                if line.startswith("🎯"):
                                    current_section = "最终答案"
                                elif line.startswith("📊"):
                                    current_section = "推理总结"
                                elif line.startswith("🔍") and "工具执行结果" in line:
                                    current_section = "工具执行结果"
                                elif line.startswith("🔍") and "工具执行结果" not in line:
                                    current_section = "其他内容"
                                elif line.startswith("✅") or line.startswith("❌"):
                                    current_section = "工具执行结果"
                                else:
                                    current_section = "其他内容"
                                section_content.append(line)
                            else:
                                # 默认情况，放到其他内容
                                current_section = "其他内容"
                                section_content.append(line)
                    
                    # 添加最后一个部分
                    if current_section is not None and section_content:
                        sections.append((current_section, section_content))
                    
                    # 逐个显示各个部分
                    # 特别处理工具执行结果，合并所有工具结果
                    tool_results_section = None
                    for section_name, section_lines in sections:
                        if section_name == "最终答案":
                            print(f"\n{Fore.GREEN}🎯 最终答案:{Style.RESET_ALL}")
                            print("┌" + "─" * 150 + "┐")
                            for line in section_lines:
                                if line.strip():
                                    print("│ " + line.ljust(78) + " │")
                            print("└" + "─" * 150 + "┘")
                        elif section_name == "推理总结":
                            print(f"\n{Fore.CYAN}📊 推理过程总结:{Style.RESET_ALL}")
                            print("┌" + "─" * 150 + "┐")
                            for line in section_lines:
                                if line.strip():
                                    print("│ " + line.ljust(78) + " │")
                            print("└" + "─" * 150 + "┘")
                        elif section_name == "工具执行结果":
                            # 收集所有工具执行结果
                            if tool_results_section is None:
                                tool_results_section = []
                            tool_results_section.extend(section_lines)
                        else:
                            # 对于其他内容，使用通用格式
                            print(f"\n{Fore.WHITE}{section_name}:{Style.RESET_ALL}")
                            print("┌" + "─" * 150 + "┐")
                            for line in section_lines:
                                if line.strip():
                                    print("│ " + line.ljust(78) + " │")
                            print("└" + "─" * 150 + "┘")
                    
                    # 如果有工具执行结果，统一显示
                    if tool_results_section is not None:
                        print(f"\n{Fore.MAGENTA}🔍 工具执行结果:{Style.RESET_ALL}")
                        print("┌" + "─" * 150 + "┐")
                        for line in tool_results_section:
                            if line.strip():
                                print("│ " + line.ljust(78) + " │")
                        print("└" + "─" * 150 + "┘")
                    
                    print(f"{Fore.BLUE}⏱️ 总处理时间: {total_time:.2f}秒{Style.RESET_ALL}")
                    
                    # 如果在调试模式下，显示详细信息
                    if debug_mode:
                        print(f"\n{Fore.YELLOW}🔍 调试信息 (调试模式已启用):{Style.RESET_ALL}")
                        print("┌" + "─" * 80 + "┐")
                        # 显示推理历史
                        if hasattr(self, 'reasoning_history') and self.reasoning_history:
                            print("│ 推理历史记录:" + " " * 68 + " │")
                            for i, record in enumerate(self.reasoning_history):
                                print("│  轮次 {0}: ".format(i+1) + " " * (74 - len("轮次 {0}: ".format(i+1))) + " │")
                                if record.get('thinking'):
                                    thinking_preview = record['thinking'][:70] + "..." if len(record['thinking']) > 70 else record['thinking']
                                    print("│    思考过程: {0}".format(thinking_preview) + " " * (74 - len("    思考过程: {0}".format(thinking_preview))) + " │")
                                if record.get('tool_results'):
                                    tool_count = len(record['tool_results'])
                                    print("│    工具调用: {0} 个 ".format(tool_count) + " " * (74 - len("    工具调用: {0} 个 ".format(tool_count))) + " │")
                                    for j, tool_result in enumerate(record['tool_results']):
                                        status = "✅" if tool_result['success'] else "❌"
                                        tool_name = tool_result['tool_name']
                                        print("│      {0} {1}".format(status, tool_name) + " " * (74 - len("      {0} {1}".format(status, tool_name))) + " │")
                        print("└" + "─" * 80 + "┘")
                        
                        # 新增：结构化显示传递给LLM的上下文信息
                        print(f"\n{Fore.CYAN}📋 传递给LLM的上下文信息:{Style.RESET_ALL}")
                        print("┌" + "─" * 80 + "┐")
                        print("│ {:<38} │".format("推理轮数: " + str(len(self.history_items))))
                        print("│ {:<38} │".format("工具数量: " + str(len([r for r in self.history_items if 'tool_results' in r and r['tool_results'] for t in r['tool_results'] if t['success']]))))
                        print("│ {:<38} │".format("历史记录: " + str(len(self.history_items))))
                        print("│ {:<38} │".format("上下文键: " + str(len(self.task_context))))
                        print("├" + "─" * 80 + "┤")
                        
                        # 显示上下文键值对（最多5个）
                        context_items = list(self.task_context.items())[:5]
                        if context_items:
                            print("│ 当前任务上下文包含:" + " " * 56 + " │")
                            for key, value in context_items:
                                key_str = str(key)[:35] + "..." if len(str(key)) > 35 else str(key)
                                print("│ {:<38} │".format(key_str))
                                # 显示值的前200字符
                                if isinstance(value, dict):
                                    value_str = str(value)[:195] + "..." if len(str(value)) > 195 else str(value)
                                    value_lines = [value_str[i:i+35] for i in range(0, len(value_str), 35)]
                                    for line in value_lines:
                                        print("│   {:<36} │".format(line))
                                else:
                                    value_str = str(value)[:195] + "..." if len(str(value)) > 195 else str(value)
                                    print("│   {:<36} │".format(value_str))
                            if len(self.task_context) > 5:
                                print("│   ... (还有 " + str(len(self.task_context) - 5) + " 项)" + " " * 36 + " │")
                        else:
                            print("│ 无上下文信息" + " " * 70 + " │")
                        print("└" + "─" * 80 + "┘")
            
            except KeyboardInterrupt:
                print(f"\n{Fore.YELLOW}👋 程序退出{Style.RESET_ALL}")
                break
            except Exception as e:
                print(f"{Fore.RED}❌ 错误: {e}{Style.RESET_ALL}")
                
            except KeyboardInterrupt:
                print(f"\n{Fore.YELLOW}👋 程序退出{Style.RESET_ALL}")
                break
            except Exception as e:
                print(f"{Fore.RED}❌ 错误: {e}{Style.RESET_ALL}")
    
    def _print_welcome_screen(self):
        """打印欢迎界面"""
        # 简化版欢迎界面，去除花纹和纹路
        # 获取当前会话名称
        current_session_name = "默认会话"  # 默认值
        if hasattr(self, 'current_session_id'):
            # 尝试从会话管理器获取会话名称
            try:
                session_info = self.session_manager.get_session_info(self.current_session_id)
                if session_info:
                    current_session_name = session_info.get('session_name', '默认会话')
            except:
                pass  # 如果获取失败，保持默认
        
        welcome_art = f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════════════════════════════════╗{Style.RESET_ALL}
{Fore.CYAN}║{Style.RESET_ALL}                          {Fore.YELLOW}Agent System{Style.RESET_ALL}                                  {Fore.CYAN}║{Style.RESET_ALL}
{Fore.CYAN}╠══════════════════════════════════════════════════════════════════════════════====╗{Style.RESET_ALL}
{Fore.CYAN}║{Style.RESET_ALL} {Fore.MAGENTA}当前状态{Style.RESET_ALL}: {Fore.GREEN}运行中{Style.RESET_ALL} | {Fore.MAGENTA}工具可用{Style.RESET_ALL}: {Fore.GREEN}{len(self.tool_manager.get_tool_descriptions())}{Style.RESET_ALL}/{Fore.GREEN}{len(self.tool_manager.get_tool_descriptions())}{Style.RESET_ALL} | {Fore.MAGENTA}会话{Style.RESET_ALL}: {Fore.GREEN}{current_session_name}{Style.RESET_ALL}    {Fore.CYAN}║{Style.RESET_ALL}
{Fore.CYAN}║{Style.RESET_ALL} {Fore.MAGENTA}支持的命令{Style.RESET_ALL}: {Fore.GREEN}load, task, monitor, history, help, quit{Style.RESET_ALL}       {Fore.CYAN}║{Style.RESET_ALL}
{Fore.CYAN}╚══════════════════════════════════════════════════════════════════════════════════╝{Style.RESET_ALL}
        """
        print(welcome_art)
        
        # 现代化显示核心特性
        print(f"{Fore.CYAN}✨ 核心特性:{Style.RESET_ALL}")
        features = [
            f"{Fore.GREEN}✅{Style.RESET_ALL} 多轮推理循环 - 工具结果实时反馈给LLM",
            f"{Fore.GREEN}✅{Style.RESET_ALL} 动态任务规划 - 基于结果调整后续策略",  
            f"{Fore.GREEN}✅{Style.RESET_ALL} 智能决策 - LLM决定何时停止工具调用",
            f"{Fore.GREEN}✅{Style.RESET_ALL} 完整历史记录 - 记录完整的推理过程",
            f"{Fore.GREEN}✅{Style.RESET_ALL} 重复调用检测 - 避免重复执行相同工具"
        ]
        for feature in features:
            print(f"  {feature}")
            
        print(f"{Fore.CYAN}📋 支持的命令:{Style.RESET_ALL}")
        commands = [
            f"  {Fore.YELLOW}load <图片路径>{Style.RESET_ALL} - 加载图片",
            f"  {Fore.YELLOW}task <任务描述>{Style.RESET_ALL} - 智能任务模式（推荐）",
            f"  {Fore.YELLOW}monitor{Style.RESET_ALL} - 显示监控信息",
            f"  {Fore.YELLOW}history{Style.RESET_ALL} - 显示推理历史",
            f"  {Fore.YELLOW}sessions{Style.RESET_ALL} - 管理会话",
            f"  {Fore.YELLOW}help{Style.RESET_ALL} - 显示帮助",
            f"  {Fore.YELLOW}quit{Style.RESET_ALL} - 退出程序"
        ]
        for cmd in commands:
            print(cmd)
            
        print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}")
        
        # 显示当前会话信息
        print(f"{Fore.MAGENTA}📋 当前会话信息:{Style.RESET_ALL}")
        print(f"  {Fore.CYAN}会话状态: {Fore.GREEN}活跃{Style.RESET_ALL}")
        # 会话ID使用动态生成方式
        session_id = getattr(self, 'current_session_id', f"session_{int(time.time())}_{time.strftime('%H%M%S')[:6]}")
        print(f"  {Fore.CYAN}会话ID: {Fore.WHITE}{session_id}{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'=' * 60}{Style.RESET_ALL}")
    
    def _display_help(self):
        """显示帮助信息"""
        print("""
🤖 智能多轮推理系统帮助

系统工作流程：
1. 接收用户问题
2. LLM分析问题并决定是否需要工具
3. 执行工具并将结果反馈给LLM
4. LLM基于结果决定下一步行动
5. 重复3-4直到问题解决

可用命令:
- load <路径>: 加载图片
- task <描述>: 执行智能任务
- monitor: 查看系统监控
- history: 查看推理历史
- help: 显示此帮助
- quit: 退出程序
        """)
    
    def _display_reasoning_history(self):
        """显示推理历史"""
        if not self.reasoning_history:
            print("📝 暂无推理历史记录")
            return
        
        print("\n📝 完整推理历史记录")
        print("=" * 80)
        
        for i, record in enumerate(self.reasoning_history, 1):
            print(f"\n第 {i} 轮推理:")
            print(f"思考过程: {record.get('thinking', '无记录')[:200]}...")
            
            if record.get('tool_results'):
                print("工具执行结果:")
                for tool_result in record['tool_results']:
                    status = "✅ 成功" if tool_result['success'] else "❌ 失败"
                    print(f"  - {tool_result['tool_name']}: {status}")
            
            if record.get('final_answer'):
                print(f"最终答案: {record['final_answer'][:200]}...")
        
        print("=" * 80)

    def load_image(self, image_path: str) -> bool:
        """加载图片"""
        if os.path.exists(image_path):
            self.current_image = image_path
            self.context['current_image'] = image_path  # 保存到上下文
            
            # 新增：将加载的图片路径添加到load_summary中，包含时间戳和顺序信息
            import time
            load_info = {
                'path': image_path,
                'timestamp': time.time(),
                'order': len(self.load_summary) + 1
            }
            self.load_summary.append(load_info)
            
            print(f"✅ 已加载图片: {image_path}")
            print(f"   当前已加载 {len(self.load_summary)} 张图片")
            # 显示已加载图片列表
            self._display_loaded_images()
            return True
        else:
            print(f"❌ 图片不存在: {image_path}")
            return False

    def _display_loaded_images(self):
        """显示已加载的图片列表"""
        if not self.load_summary:
            print("📋 当前暂无加载的图片")
            return
            
        print("\n📋 已加载的图片列表:")
        print("┌" + "─" * 80 + "┐")
        print("│ {:<3} │ {:<50} │ {:<15} │".format("序号", "图片路径", "加载时间"))
        print("├" + "─" * 80 + "┤")
        
        for i, load_info in enumerate(self.load_summary, 1):
            # 格式化时间
            import datetime
            load_time = datetime.datetime.fromtimestamp(load_info['timestamp']).strftime('%Y-%m-%d %H:%M:%S')
            # 截取路径显示长度
            path_display = load_info['path'] if len(load_info['path']) <= 48 else "..." + load_info['path'][-45:]
            print("│ {:<3} │ {:<50} │ {:<15} │".format(i, path_display, load_time))
        
        print("└" + "─" * 80 + "┘")

    def _save_structured_session_data(self, command: str, iteration: int, tool_results: List[Dict], thinking: str, final_answer: str):
        """保存结构化的会话数据到会话管理器，支持每轮对话的详细记录"""
        try:
            # 确保会话管理器已初始化
            if not hasattr(self, 'session_manager') or not self.session_manager:
                print("⚠️ 会话管理器未初始化，跳过会话保存")
                return

            # 创建结构化的会话轮次数据 - 优化版本，减少冗余
            # 1. 用户输入
            # 2. 工具调用信息
            # 3. 工具执行结果
            # 4. 最终答案
            # 5. 思考过程
            
            # 提取核心工具结果信息，避免冗余存储
            core_tool_results = []
            for result in tool_results:
                if result.get('success'):
                    tool_name = result.get('tool_name', 'unknown')
                    # 只保存核心结果信息，避免重复存储
                    core_result = {
                        "tool_name": tool_name,
                        "success": True,
                        "timestamp": time.time()
                    }
                    # 根据工具类型提取关键信息
                    if tool_name == "browser_use_answer" and 'result' in result:
                        if isinstance(result['result'], dict):
                            if 'final_answer' in result['result']:
                                core_result['answer'] = result['result']['final_answer']
                            elif 'answer' in result['result']:
                                core_result['answer'] = result['result']['answer']
                            else:
                                core_result['answer'] = str(result['result'])
                        else:
                            core_result['answer'] = str(result['result'])
                    elif tool_name == "visual_description" and 'result' in result:
                        if isinstance(result['result'], dict) and 'description' in result['result']:
                            core_result['description'] = result['result']['description']
                        else:
                            core_result['description'] = str(result['result'])
                    elif tool_name in ["trajectory", "grounding", "affordance", "pointing", "planning"]:
                        # 保存检测和规划工具的核心信息
                        if 'result' in result and isinstance(result['result'], dict):
                            # 提取特定字段
                            if 'boxes' in result['result']:
                                core_result['boxes_count'] = len(result['result']['boxes'])
                            elif 'points' in result['result']:
                                core_result['points_count'] = len(result['result']['points'])
                            elif 'trajectory_points' in result['result']:
                                core_result['trajectory_points_count'] = len(result['result']['trajectory_points'])
                            elif 'steps' in result['result']:
                                core_result['steps_count'] = len(result['result']['steps'])
                        else:
                            # 通用存储
                            core_result['raw_result'] = str(result.get('result', ''))
                    
                    core_tool_results.append(core_result)
                else:
                    # 失败的工具调用也记录，但只记录基本信息
                    core_tool_results.append({
                        "tool_name": result.get('tool_name', 'unknown'),
                        "success": False,
                        "error": result.get('error', '未知错误'),
                        "timestamp": time.time()
                    })
            
            # 创建标准化的会话轮次数据结构
            session_round_data = {
                "round_number": iteration,
                "user_input": command,
                "tool_calls": [],  # 留空，由调用时传入
                "tool_results": core_tool_results,
                "final_answer": final_answer,
                "thinking": thinking,
                "timestamp": time.time(),
                "tool_count": len(tool_results)
            }

            # 将当前轮次数据保存到推理历史中
            if not hasattr(self, 'session_round_history'):
                self.session_round_history = []
            
            self.session_round_history.append(session_round_data)
            
            # 修复：确保使用正确的会话ID，不要在没有会话ID时创建新会话
            # 检查当前是否已有有效的会话ID
            current_session_id = getattr(self, 'current_session_id', None)
            
            if current_session_id:
                # 获取当前会话数据
                current_session = self.session_manager.load_session(current_session_id)
                
                # 更新会话数据 - 优化版本，减少冗余信息
                session_data = {
                    "session_id": current_session_id,
                    "session_name": current_session.get("session_name", f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}") if current_session else f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}",
                    "created_at": current_session.get("created_at", time.time()) if current_session else time.time(),
                    "updated_at": time.time(),
                    "context": self.context,
                    "task_context": self.task_context,
                    "reasoning_history": self.reasoning_history,
                    "tool_execution_memory": self.tool_execution_memory,
                    "conversation_history": self.conversation_history,
                    "session_round_history": self.session_round_history,
                    "load_summary": self.load_summary,  # 修复：保存加载的图片信息
                    "status": "active"
                }
                
                # 保存会话数据
                self.session_manager.save_session(session_data)
                print(f"✅ 第 {iteration} 轮会话数据已保存到会话 {current_session_id}")
            else:
                # 如果没有会话ID，尝试从会话管理器中获取当前活动会话
                # 获取所有会话并尝试使用最新的活动会话
                sessions = self.session_manager.list_sessions()
                if sessions:
                    # 使用最新的活动会话
                    latest_session = sessions[0]  # 按时间排序，第一个是最新
                    current_session_id = latest_session['session_id']
                    self.current_session_id = current_session_id
                    
                    # 获取当前会话数据
                    current_session = self.session_manager.load_session(current_session_id)
                    
                    # 更新会话数据 - 优化版本，减少冗余信息
                    session_data = {
                        "session_id": current_session_id,
                        "session_name": current_session.get("session_name", f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}") if current_session else f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}",
                        "created_at": current_session.get("created_at", time.time()) if current_session else time.time(),
                        "updated_at": time.time(),
                        "context": self.context,
                        "task_context": self.task_context,
                        "reasoning_history": self.reasoning_history,
                        "tool_execution_memory": self.tool_execution_memory,
                        "conversation_history": self.conversation_history,
                        "session_round_history": self.session_round_history,
                        "status": "active"
                    }
                    
                    # 保存会话数据
                    self.session_manager.save_session(session_data)
                    print(f"✅ 第 {iteration} 轮会话数据已保存到会话 {current_session_id}")
                else:
                    # 如果确实没有会话，创建新会话
                    session_name = f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}"
                    current_session_id = self.session_manager.create_session(session_name)
                    self.current_session_id = current_session_id
                    print(f"✅ 创建新会话: {session_name}")
                    print(f"   - 正在保存会话数据到新会话")
                    
                    # 更新会话数据 - 优化版本，减少冗余信息
                    session_data = {
                        "session_id": current_session_id,
                        "session_name": session_name,
                        "created_at": time.time(),
                        "updated_at": time.time(),
                        "context": self.context,
                        "task_context": self.task_context,
                        "reasoning_history": self.reasoning_history,
                        "tool_execution_memory": self.tool_execution_memory,
                        "conversation_history": self.conversation_history,
                        "session_round_history": self.session_round_history,
                        "status": "active"
                    }
                    
                    # 保存会话数据
                    self.session_manager.save_session(session_data)
                    print(f"✅ 第 {iteration} 轮会话数据已保存到新会话 {current_session_id}")
                
        except Exception as e:
            logger.error(f"保存结构化会话数据失败: {e}")
            print(f"❌ 保存会话数据失败: {e}")

    def _extract_tool_result_core_data(self, result_data: Dict[str, Any], tool_name: str) -> Dict[str, Any]:
        """提取工具结果的核心数据，避免冗余存储"""
        # 根据工具类型提取核心数据
        core_data = {
            "tool_name": tool_name,
            "success": result_data.get("success", False),
            "timestamp": time.time()
        }
        
        # 根据不同工具类型提取关键信息
        if tool_name == "browser_use_answer":
            # 提取浏览器工具的核心结果
            if "final_answer" in result_data:
                core_data["answer"] = result_data["final_answer"]
            elif "answer" in result_data:
                core_data["answer"] = result_data["answer"]
            elif "result" in result_data and isinstance(result_data["result"], dict):
                # 如果result是字典，提取其中的关键字段
                if "final_answer" in result_data["result"]:
                    core_data["answer"] = result_data["result"]["final_answer"]
                elif "answer" in result_data["result"]:
                    core_data["answer"] = result_data["result"]["answer"]
                else:
                    # 提取result中的文本内容
                    core_data["answer"] = str(result_data["result"])
            else:
                # 提取通用信息
                core_data["answer"] = str(result_data.get("result", result_data))
                
        elif tool_name == "visual_description":
            # 提取视觉描述的核心内容
            if "description" in result_data:
                core_data["description"] = result_data["description"]
            elif "result" in result_data and isinstance(result_data["result"], dict):
                if "description" in result_data["result"]:
                    core_data["description"] = result_data["result"]["description"]
            else:
                core_data["description"] = str(result_data.get("result", result_data))
                
        elif tool_name in ["trajectory", "grounding", "affordance", "pointing", "planning"]:
            # 提取检测和规划工具的核心结果
            if "boxes" in result_data:
                core_data["boxes"] = result_data["boxes"]
            elif "points" in result_data:
                core_data["points"] = result_data["points"]
            elif "trajectory_points" in result_data:
                core_data["trajectory_points"] = result_data["trajectory_points"]
            elif "steps" in result_data:
                core_data["steps"] = result_data["steps"]
            elif "result" in result_data and isinstance(result_data["result"], dict):
                # 提取result中的关键字段
                if "boxes" in result_data["result"]:
                    core_data["boxes"] = result_data["result"]["boxes"]
                elif "points" in result_data["result"]:
                    core_data["points"] = result_data["result"]["points"]
                elif "trajectory_points" in result_data["result"]:
                    core_data["trajectory_points"] = result_data["result"]["trajectory_points"]
                elif "steps" in result_data["result"]:
                    core_data["steps"] = result_data["result"]["steps"]
            else:
                # 如果没有特定的结构化字段，保存原始结果
                core_data["raw_result"] = str(result_data)
                
        else:
            # 对于其他工具，保存通用的核心信息
            core_data["result"] = str(result_data)
            
        return core_data

    def _format_history_results_for_llm(self) -> str:
        """格式化历史工具执行结果供LLM使用"""
        if not self.task_context:
            return "无历史结果"
        
        # 分离带编号的历史结果
        history_results = []
        for key, value in self.task_context.items():
            if key.endswith('_result') and isinstance(value, dict):
                # 使用数字检测来识别带编号的历史结果
                if any(char.isdigit() for char in key):
                    # 这是带编号的历史结果
                    tool_name = key.replace('_result', '').split('_')[0]  # 提取工具名称
                    try:
                        # 获取完整的工具执行信息
                        success = value.get('success', False)
                        task = value.get('task', '无任务描述')
                        result_data = value.get('result', value)
                        
                        # 构建完整的工具执行信息描述
                        if isinstance(result_data, dict):
                            if 'boxes' in result_data:
                                description = f"工具: {tool_name}, 任务: {task}, 状态: {'成功' if success else '失败'}, 结果: 检测到边界框 {result_data['boxes']}"
                            elif 'points' in result_data:
                                description = f"工具: {tool_name}, 任务: {task}, 状态: {'成功' if success else '失败'}, 结果: 检测到点 {result_data['points']}"
                            elif 'trajectory_points' in result_data:
                                description = f"工具: {tool_name}, 任务: {task}, 状态: {'成功' if success else '失败'}, 结果: 检测到轨迹点 {result_data['trajectory_points']}"
                            elif 'description' in result_data:
                                description = f"工具: {tool_name}, 任务: {task}, 状态: {'成功' if success else '失败'}, 结果: {result_data['description']}"
                            elif 'final_answer' in result_data:
                                description = f"工具: {tool_name}, 任务: {task}, 状态: {'成功' if success else '失败'}, 结果: {result_data['final_answer']}"
                            elif 'answer' in result_data:
                                description = f"工具: {tool_name}, 任务: {task}, 状态: {'成功' if success else '失败'}, 结果: {result_data['answer']}"
                            else:
                                description = f"工具: {tool_name}, 任务: {task}, 状态: {'成功' if success else '失败'}, 结果: {str(result_data)}"
                        else:
                            description = f"工具: {tool_name}, 任务: {task}, 状态: {'成功' if success else '失败'}, 结果: {str(result_data)}"
                        history_results.append(description)
                    except Exception as e:
                        history_results.append(f"工具: {tool_name}, 任务: 无法解析, 状态: 未知, 结果: 错误 - {str(e)}")
        
        if not history_results:
            return "无历史结果"
        
        return " ".join(history_results)

if __name__ == "__main__":
    # 设置日志级别
    logging.basicConfig(level=logging.INFO)
    
    # 创建系统实例
    system = IntegratedIntelligentSystem(max_reasoning_iterations=5)
    
    # 启动监控
    system.start_monitoring()
    
    # 启动交互式会话
    try:
        system.start_interactive_session()
    finally:
        system.stop_monitoring()
                # 提取通用信息

