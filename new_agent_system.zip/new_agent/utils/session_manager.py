#!/usr/bin/env python3
"""
会话管理器
负责会话的创建、保存、加载和管理
"""

import os
import json
import time
import uuid
from typing import Dict, List, Optional, Any
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class SessionManager:
    """会话管理器"""
    
    def __init__(self, storage_path: str = "./sessions"):
        """
        初始化会话管理器
        
        Args:
            storage_path: 会话存储路径
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(exist_ok=True)
        self.current_session_id = None
        self.current_session_data = None
        self._current_session_file = None
        
    def create_session(self, session_name: str = "新会话") -> str:
        """
        创建新会话
        
        Args:
            session_name: 会话名称
            
        Returns:
            会话ID
        """
        session_id = f"session_{int(time.time())}_{uuid.uuid4().hex[:8]}"
        
        session_data = {
            "session_id": session_id,
            "session_name": session_name,
            "created_at": time.time(),
            "updated_at": time.time(),
            "context": {},
            "reasoning_history": [],
            "tool_execution_memory": [],
            "conversation_history": [],
            "task_context": {},
            "status": "active"
        }
        
        # 保存会话数据
        self._save_session(session_id, session_data)
        
        logger.info(f"创建新会话: {session_id}")
        return session_id
    
    def load_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        加载指定会话
        
        Args:
            session_id: 会话ID
            
        Returns:
            会话数据，如果不存在返回None
        """
        session_file = self.storage_path / f"{session_id}.json"
        
        if not session_file.exists():
            logger.warning(f"会话文件不存在: {session_file}")
            return None
            
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                session_data = json.load(f)
                
            self.current_session_id = session_id
            self.current_session_data = session_data
            
            logger.info(f"成功加载会话: {session_id}")
            return session_data
        except Exception as e:
            logger.error(f"加载会话失败: {e}")
            return None
    
    def save_session(self, session_data: Dict[str, Any]) -> bool:
        """
        保存会话数据 - 优化版本，减少冗余信息
        
        Args:
            session_data: 会话数据
            
        Returns:
            保存是否成功
        """
        try:
            session_id = session_data.get("session_id")
            if not session_id:
                logger.error("会话ID不存在")
                return False
                
            # 更新最后修改时间
            session_data["updated_at"] = time.time()
            
            # 优化：清理会话数据中的冗余信息
            # 移除可能的冗余存储字段
            if "reasoning_history" in session_data:
                # 只保存最近的推理历史记录
                if isinstance(session_data["reasoning_history"], list) and len(session_data["reasoning_history"]) > 5:
                    session_data["reasoning_history"] = session_data["reasoning_history"][-5:]
                    
            if "tool_execution_memory" in session_data:
                # 只保存最近的工具执行记录
                if isinstance(session_data["tool_execution_memory"], list) and len(session_data["tool_execution_memory"]) > 10:
                    session_data["tool_execution_memory"] = session_data["tool_execution_memory"][-10:]
                    
            if "conversation_history" in session_data:
                # 只保存最近的对话记录
                if isinstance(session_data["conversation_history"], list) and len(session_data["conversation_history"]) > 20:
                    session_data["conversation_history"] = session_data["conversation_history"][-20:]
            
            # 新增：确保工具执行历史以期望格式存储
            if "tool_execution_memory" in session_data and session_data["tool_execution_memory"]:
                # 格式化工具执行历史，使其符合期望格式
                formatted_history = []
                for item in session_data["tool_execution_memory"]:
                    if isinstance(item, dict):
                        # 如果是工具执行记录，将其转换为期望格式
                        if "result" in item and isinstance(item["result"], dict):
                            # 提取关键字段并转换为期望格式
                            formatted_item = {
                                "tool_name": item.get("tool_name", ""),
                                "success": item.get("success", False),
                                "task": item.get("task", item.get("parameters", {}).get("task", "")),
                                "answer": item.get("result", {}).get("result", item.get("result", {}).get("answer", ""))
                            }
                            # 只添加非空字段
                            formatted_item = {k: v for k, v in formatted_item.items() if v}  
                            formatted_history.append(formatted_item)
                        else:
                            # 如果已经是期望格式，直接使用
                            formatted_history.append(item)
                    else:
                        formatted_history.append(item)
                
                session_data["tool_execution_memory"] = formatted_history
            
            self._save_session(session_id, session_data)
            logger.info(f"会话保存成功: {session_id}")
            return True
        except Exception as e:
            logger.error(f"保存会话失败: {e}")
            return False
    
    def list_sessions(self) -> List[Dict[str, Any]]:
        """
        列出所有会话
        
        Returns:
            会话列表
        """
        sessions = []
        
        try:
            for file_path in self.storage_path.glob("session_*.json"):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        session_data = json.load(f)
                        sessions.append({
                            "session_id": session_data.get("session_id"),
                            "session_name": session_data.get("session_name", "未知会话"),
                            "created_at": session_data.get("created_at"),
                            "updated_at": session_data.get("updated_at"),
                            "status": session_data.get("status", "unknown")
                        })
                except Exception as e:
                    logger.warning(f"读取会话文件失败 {file_path}: {e}")
                    continue
                    
            # 按创建时间排序，最新的在前
            sessions.sort(key=lambda x: x["created_at"], reverse=True)
            return sessions
        except Exception as e:
            logger.error(f"列出会话失败: {e}")
            return []
    
    def delete_session(self, session_id: str) -> bool:
        """
        删除指定会话
        
        Args:
            session_id: 会话ID
            
        Returns:
            删除是否成功
        """
        try:
            session_file = self.storage_path / f"{session_id}.json"
            if session_file.exists():
                session_file.unlink()
                logger.info(f"删除会话: {session_id}")
                return True
            else:
                logger.warning(f"会话文件不存在: {session_file}")
                return False
        except Exception as e:
            logger.error(f"删除会话失败: {e}")
            return False
    
    def _save_session(self, session_id: str, session_data: Dict[str, Any]) -> None:
        """
        保存会话到文件
        
        Args:
            session_id: 会话ID
            session_data: 会话数据
        """
        session_file = self.storage_path / f"{session_id}.json"
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session_data, f, ensure_ascii=False, indent=2)
    
    def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        获取会话信息
        
        Args:
            session_id: 会话ID
            
        Returns:
            会话信息
        """
        session_file = self.storage_path / f"{session_id}.json"
        
        if not session_file.exists():
            return None
            
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"获取会话信息失败: {e}")
            return None

if __name__ == "__main__":
    # 测试会话管理器
    session_manager = SessionManager("./test_sessions")
    
    # 创建测试会话
    session_id = session_manager.create_session("测试会话")
    print(f"创建会话: {session_id}")
    
    # 列出所有会话
    sessions = session_manager.list_sessions()
    print("所有会话:")
    for session in sessions:
        print(f"  {session['session_name']} ({session['session_id']})")
    
    # 加载会话
    loaded_session = session_manager.load_session(session_id)
    if loaded_session:
        print(f"加载会话成功: {loaded_session['session_name']}")
    
    # 删除会话
    # session_manager.delete_session(session_id)
    # print("会话已删除")
