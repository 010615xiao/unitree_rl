#!/usr/bin/env python3
"""
监控工具
负责监控系统性能和执行时间
"""

import threading
import time
from typing import Dict, Any, List
import logging

logger = logging.getLogger(__name__)


class VLLMMonitoring:
    """vLLM推理监控类"""
    
    def __init__(self):
        self.monitoring_enabled = False
        self.monitoring_thread = None
        self.monitoring_data = {
            'llm_inference_time': [],
            'tool_execution_time': [],
            'total_processing_time': [],
            'active_tasks': [],
            'reasoning_iterations': []  # 新增：记录推理轮数
        }
        
    def start_monitoring(self):
        """启动监控"""
        self.monitoring_enabled = True
        self.monitoring_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitoring_thread.start()
        print("📊 vLLM推理监控已启动")
        
    def stop_monitoring(self):
        """停止监控"""
        self.monitoring_enabled = False
        if self.monitoring_thread:
            self.monitoring_thread.join()
        print("🛑 vLLM推理监控已停止")
        
    def _monitor_loop(self):
        """监控循环"""
        while self.monitoring_enabled:
            try:
                # 在这里可以添加实时监控逻辑
                time.sleep(2)  # 每2秒更新一次
            except Exception as e:
                logger.error(f"监控循环出错: {e}")
                break
                
    def log_llm_inference(self, duration: float):
        """记录LLM推理时间"""
        self.monitoring_data['llm_inference_time'].append(duration)
        
    def log_tool_execution(self, tool_name: str, duration: float):
        """记录工具执行时间"""
        self.monitoring_data['tool_execution_time'].append({
            'tool': tool_name,
            'duration': duration
        })
        
    def log_total_processing(self, duration: float):
        """记录总处理时间"""
        self.monitoring_data['total_processing_time'].append(duration)
        
    def log_reasoning_iteration(self, iteration: int):
        """记录推理轮数"""
        self.monitoring_data['reasoning_iterations'].append(iteration)
        
    def get_monitoring_summary(self):
        """获取监控摘要"""
        if not self.monitoring_data['llm_inference_time']:
            return "暂无监控数据"
            
        avg_llm_time = sum(self.monitoring_data['llm_inference_time']) / len(self.monitoring_data['llm_inference_time'])
        avg_tool_time = sum([t['duration'] for t in self.monitoring_data['tool_execution_time']]) / len(self.monitoring_data['tool_execution_time']) if self.monitoring_data['tool_execution_time'] else 0
        
        reasoning_stats = ""
        if self.monitoring_data['reasoning_iterations']:
            avg_iterations = sum(self.monitoring_data['reasoning_iterations']) / len(self.monitoring_data['reasoning_iterations'])
            reasoning_stats = f"- 平均推理轮数: {avg_iterations:.1f}\n"
        
        return f"""
监控摘要:
- 平均LLM推理时间: {avg_llm_time:.2f}秒
- 平均工具执行时间: {avg_tool_time:.2f}秒
- 总处理次数: {len(self.monitoring_data['total_processing_time'])}
{reasoning_stats}
        """
        
    def display_monitoring(self):
        """显示监控信息"""
        if not self.monitoring_data['llm_inference_time']:
            print("📊 暂无监控数据")
        else:
            print(self.get_monitoring_summary())


