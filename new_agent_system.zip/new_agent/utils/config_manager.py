#!/usr/bin/env python3
"""
配置管理模块
统一管理所有系统配置，避免硬编码
"""

import yaml
import os
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)


class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_file: str = 'config.yaml'):
        """
        初始化配置管理器
        
        Args:
            config_file: 配置文件路径
        """
        self.config_file = config_file
        self.config = {}
        self._load_config()
        
    def _load_config(self) -> None:
        """加载配置文件"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config = yaml.safe_load(f) or {}
                logger.info(f"配置文件加载成功: {self.config_file}")
            else:
                # 如果配置文件不存在，创建默认配置
                self._create_default_config()
                logger.info(f"创建默认配置文件: {self.config_file}")
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            # 创建默认配置
            self._create_default_config()
            
    def _create_default_config(self) -> None:
        """创建默认配置"""
        self.config = {
            'llm': {
                'host': 'localhost',
                'port': 8000,
                'model_name': 'Qwen2.5-7B-Instruct'
            },
            'robobrain': {
                'host': 'localhost',
                'port': 8001,
                'model_name': 'RoboBrain2.0 7B',
                'model_path': '/workspace/wxd/reason-vla/RoboBrain2.0-7B-GGUF/RoboBrain2.0-7B-q4_k_m.gguf',
                'mmproj_path': '/workspace/wxd/reason-vla/RoboBrain2.0-7B-GGUF/mmproj-RoboBrain2.0-7b-F16.gguf',
                'media_path': '/workspace/wxd/Agent/images'
            },
            'system': {
                'max_reasoning_iterations': 10,
                'enable_monitoring': True,
                'debug_mode': False
            },
            'tools': {
                'browser_use': {
                    'max_steps': 20,
                    'model': 'deepseek-r1:14b',
                    'headless': True
                }
            },
            'paths': {
                'result_dir': 'result',
                'log_dir': 'logs',
                'temp_dir': 'temp'
            }
        }
        
        # 保存默认配置
        self._save_config()
        
    def _save_config(self) -> bool:
        """保存配置文件"""
        try:
            os.makedirs(os.path.dirname(self.config_file) if os.path.dirname(self.config_file) else '.', exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)
            return True
        except Exception as e:
            logger.error(f"保存配置文件失败: {e}")
            return False
            
    def get(self, key_path: str, default: Any = None) -> Any:
        """
        获取配置值
        
        Args:
            key_path: 键路径，如 'llm.host'
            default: 默认值
            
        Returns:
            配置值
        """
        keys = key_path.split('.')
        value = self.config
        
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
            
    def set(self, key_path: str, value: Any) -> bool:
        """
        设置配置值
        
        Args:
            key_path: 键路径，如 'llm.host'
            value: 要设置的值
            
        Returns:
            是否设置成功
        """
        keys = key_path.split('.')
        config = self.config
        
        try:
            # 导航到要设置的键的父级
            for key in keys[:-1]:
                if key not in config:
                    config[key] = {}
                config = config[key]
            
            # 设置最终键的值
            config[keys[-1]] = value
            return self._save_config()
        except Exception as e:
            logger.error(f"设置配置值失败: {e}")
            return False
            
    def get_all(self) -> Dict[str, Any]:
        """获取所有配置"""
        return self.config.copy()
        
    def reload(self) -> None:
        """重新加载配置"""
        self._load_config()
        
    def update_from_dict(self, updates: Dict[str, Any]) -> bool:
        """
        从字典更新配置
        
        Args:
            updates: 要更新的配置字典
            
        Returns:
            是否更新成功
        """
        try:
            def update_nested_dict(original, updates):
                for key, value in updates.items():
                    if isinstance(value, dict) and key in original:
                        update_nested_dict(original[key], value)
                    else:
                        original[key] = value
            
            update_nested_dict(self.config, updates)
            return self._save_config()
        except Exception as e:
            logger.error(f"更新配置失败: {e}")
            return False


# 全局配置管理器实例
config_manager = ConfigManager()


def get_config(key_path: str, default: Any = None) -> Any:
    """获取配置值的便捷函数"""
    return config_manager.get(key_path, default)


def set_config(key_path: str, value: Any) -> bool:
    """设置配置值的便捷函数"""
    return config_manager.set(key_path, value)


def get_all_config() -> Dict[str, Any]:
    """获取所有配置的便捷函数"""
    return config_manager.get_all()


def reload_config() -> None:
    """重新加载配置的便捷函数"""
    config_manager.reload()
