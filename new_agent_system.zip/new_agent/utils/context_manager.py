#!/usr/bin/env python3
"""
上下文管理器
负责管理推理过程中的上下文信息
"""

from typing import Dict, Any, List
import json


class ContextManager:
    """上下文管理器"""
    
    def __init__(self):
        self.context = {}
        self.history = []
        
    def set_context(self, key: str, value: Any):
        """设置上下文变量"""
        self.context[key] = value
        
    def get_context(self, key: str, default: Any = None) -> Any:
        """获取上下文变量"""
        return self.context.get(key, default)
        
    def update_context(self, updates: Dict[str, Any]):
        """批量更新上下文"""
        self.context.update(updates)
        
    def add_to_history(self, item: Dict[str, Any]):
        """添加到历史记录"""
        self.history.append(item)
        
    def get_history(self) -> List[Dict[str, Any]]:
        """获取历史记录"""
        return self.history.copy()
        
    def clear_context(self):
        """清空上下文"""
        self.context.clear()
        
    def clear_history(self):
        """清空历史记录"""
        self.history.clear()
        
    def get_context_summary(self) -> str:
        """获取上下文摘要"""
        if not self.context:
            return "暂无上下文信息"
            
        summary = "当前上下文:\n"
        for key, value in self.context.items():
            summary += f"  {key}: {value}\n"
        return summary
        
    def get_history_summary(self) -> str:
        """获取历史记录摘要"""
        if not self.history:
            return "暂无历史记录"
            
        summary = f"历史记录 (共{len(self.history)}条):\n"
        for i, item in enumerate(self.history[-5:], 1):  # 只显示最近5条
            summary += f"  {i}. {item.get('type', 'unknown')}: {str(item.get('content', ''))[:100]}...\n"
        return summary
    
    def compress_context(self, max_length: int = 10000) -> str:
        """压缩上下文以适应LLM长度限制"""
        if not self.context:
            return "暂无上下文信息"
            
        # 按重要性排序上下文项
        # 优先保留关键信息
        priority_keys = ['current_image', 'task_description', 'tool_results']
        important_items = []
        other_items = []
        
        for key, value in self.context.items():
            if key in priority_keys:
                important_items.append((key, value))
            else:
                other_items.append((key, value))
        
        # 构建压缩后的上下文
        compressed = "压缩上下文信息:\n"
        total_length = len(compressed)
        
        # 首先添加优先项
        for key, value in important_items:
            value_str = str(value)
            if len(value_str) > 100:
                value_str = value_str[:100] + "..."
            compressed += f"  {key}: {value_str}\n"
            total_length += len(f"  {key}: {value_str}\n")
            
            if total_length >= max_length:
                compressed += "  ... [上下文已截断] ...\n"
                return compressed
                
        # 然后添加其他项（如果还有空间）
        for key, value in other_items:
            value_str = str(value)
            if len(value_str) > 100:
                value_str = value_str[:100] + "..."
            compressed += f"  {key}: {value_str}\n"
            total_length += len(f"  {key}: {value_str}\n")
            
            if total_length >= max_length:
                compressed += "  ... [上下文已截断] ...\n"
                return compressed
                
        return compressed
        
    def smart_truncate_context(self, max_chars: int = 10000) -> Dict[str, Any]:
        """智能截断上下文，保留最重要的信息"""
        if not self.context:
            return {}
            
        # 优先级排序
        priority_order = [
            'current_image',
            'task_description', 
            'last_tool_result',
            'tool_results'
        ]
        
        # 按优先级提取上下文
        truncated = {}
        current_length = 0
        
        # 先添加高优先级项
        for key in priority_order:
            if key in self.context:
                value = self.context[key]
                value_str = str(value)
                if len(value_str) > 200:
                    value_str = value_str[:200] + "..."
                truncated[key] = value_str
                current_length += len(key) + len(value_str) + 4  # 4 for ": "
                
                if current_length >= max_chars * 0.8:  # 保留80%的空间给其他项
                    break
        
        # 如果还有空间，添加其他项的摘要
        if current_length < max_chars * 0.9:  # 保留10%的空间作为缓冲
            remaining_space = max_chars - current_length
            for key, value in self.context.items():
                if key not in priority_order:
                    if key not in truncated:
                        value_str = str(value)
                        if len(value_str) > 100:
                            value_str = value_str[:100] + "..."
                        truncated[key] = value_str
                        current_length += len(key) + len(value_str) + 4
                        if current_length >= max_chars:
                            break
        
        return truncated


