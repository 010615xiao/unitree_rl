#!/usr/bin/env python3
"""
RoboBrain模型加载器
负责加载和管理RoboBrain模型实例
"""

import sys
import os
from typing import Dict, Any, Optional

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

class RoboBrainModelLoader:
    """RoboBrain模型加载器"""
    
    def __init__(self):
        self._models = {}
        
    def load_model(self, model_id: str):
        """
        加载RoboBrain模型
        
        Args:
            model_id: 模型标识符
            
        Returns:
            模型实例
        """
        if model_id in self._models:
            return self._models[model_id]
            
        # 实际加载RoboBrain模型
        try:
            # 尝试直接导入RoboBrain模块
            # 先尝试从当前目录导入
            import importlib.util
            spec = importlib.util.spec_from_file_location("robobrain", "./tools/robobrain.py")
            robobrain_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(robobrain_module)
            
            # 创建模型实例
            model_class = getattr(robobrain_module, "UnifiedInference")
            model_instance = model_class(model_id=model_id)
            self._models[model_id] = model_instance
            print(f"✅ RoboBrain模型 {model_id} 加载成功")
            
        except (ImportError, AttributeError) as e:
            # 如果直接导入失败，尝试从my_agent_tool_system目录导入
            try:
                from .tools.robobrain import UnifiedInference
                model_instance = UnifiedInference(model_id=model_id)
                self._models[model_id] = model_instance
                print(f"✅ RoboBrain模型 {model_id} 加载成功")
            except ImportError:
                # 如果找不到实际的模型类，返回模拟实例用于测试
                print(f"⚠️ 无法加载实际模型 {model_id}，返回模拟实例")
                model_instance = {
                    "model_id": model_id,
                    "loaded": True,
                    "type": "RoboBrain",
                    "error": "模型未找到"
                }
                self._models[model_id] = model_instance
                
        except Exception as e:
            print(f"❌ 加载RoboBrain模型 {model_id} 时出错: {e}")
            model_instance = {
                "model_id": model_id,
                "loaded": False,
                "type": "RoboBrain",
                "error": str(e)
            }
            self._models[model_id] = model_instance
            
        return model_instance
        
    def get_model(self, model_id: str):
        """
        获取已加载的模型
        
        Args:
            model_id: 模型标识符
            
        Returns:
            模型实例或None
        """
        return self._models.get(model_id)
        
    def unload_model(self, model_id: str):
        """
        卸载模型
        
        Args:
            model_id: 模型标识符
        """
        if model_id in self._models:
            del self._models[model_id]
            print(f"🗑️ RoboBrain模型 {model_id} 已卸载")
            
    def list_loaded_models(self):
        """列出所有已加载的模型"""
        return list(self._models.keys())


