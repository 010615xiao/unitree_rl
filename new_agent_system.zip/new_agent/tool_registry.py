"""
Tool Registry for RoboBrain Tool System
Based on browser-use tool registry pattern
"""

import asyncio
import logging
from typing import Any, Callable, Dict, List, Optional, Type, Union
from pydantic import BaseModel, create_model
from dataclasses import dataclass
from typing import get_type_hints

logger = logging.getLogger(__name__)


@dataclass
class ToolInfo:
    """Information about a registered tool"""
    name: str
    description: str
    param_model: Type[BaseModel]
    func: Callable
    is_async: bool


class ToolRegistry:
    """Registry for managing tools in the RoboBrain system"""
    
    def __init__(self):
        self._tools: Dict[str, ToolInfo] = {}
        self._tool_models: Dict[str, Type[BaseModel]] = {}
        
    def register_tool(
        self,
        name: str,
        description: str,
        param_model: Type[BaseModel],
        func: Callable,
        is_async: bool = True
    ):
        """Register a new tool"""
        tool_info = ToolInfo(
            name=name,
            description=description,
            param_model=param_model,
            func=func,
            is_async=is_async
        )
        self._tools[name] = tool_info
        
        # Create a model for this tool
        self._tool_models[name] = param_model
        
        logger.debug(f"Registered tool: {name}")
        
    def get_tool(self, name: str) -> Optional[ToolInfo]:
        """Get tool information by name"""
        return self._tools.get(name)
        
    def list_tools(self) -> List[str]:
        """List all registered tool names"""
        return list(self._tools.keys())
        
    def get_tool_descriptions(self) -> Dict[str, str]:
        """Get descriptions of all registered tools"""
        return {name: tool.description for name, tool in self._tools.items()}
        
    def create_tool_model(self) -> Type[BaseModel]:
        """Create a dynamic Pydantic model that includes all registered tools"""
        if not self._tools:
            # Return a basic model if no tools
            return create_model("ToolModel", __base__=BaseModel)
            
        # Create fields for each tool
        fields = {}
        for tool_name, tool_info in self._tools.items():
            # Create a field for the tool with its parameter model
            fields[tool_name] = (Optional[tool_info.param_model], None)
            
        # Create the dynamic model
        return create_model("ToolModel", __base__=BaseModel, **fields)
        
    async def execute_tool(
        self, 
        tool_name: str, 
        params: Dict[str, Any],
        **kwargs
    ) -> Any:
        """Execute a registered tool with given parameters"""
        tool_info = self.get_tool(tool_name)
        if not tool_info:
            raise ValueError(f"Tool '{tool_name}' not found")
            
        try:
            # Prepare arguments for the function
            func_params = {**params}
            
            # Add any additional kwargs to the function parameters
            for key, value in kwargs.items():
                if key not in func_params:
                    func_params[key] = value
                    
            # Execute the tool function
            if tool_info.is_async:
                result = await tool_info.func(**func_params)
            else:
                result = tool_info.func(**func_params)
                
            logger.debug(f"Tool {tool_name} executed successfully")
            return result
            
        except Exception as e:
            logger.error(f"Error executing tool {tool_name}: {e}")
            raise


