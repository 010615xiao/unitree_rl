"""
Trajectory planning tool for RoboBrain Tool System
"""

import re
from typing import List, Tuple, Dict, Any
import os
import datetime
from .base_tool import BaseTool
from .robobrain import UnifiedInference
from prompts import TRAJECTORY_TOOL_PROMPT


class TrajectoryTool(BaseTool):
    """Tool for trajectory planning using RoboBrain2.0"""
    
    def __init__(self):
        super().__init__(
            name="trajectory",
            description="Plan a path from current position to target using RoboBrain2.0. "
                       "Returns a list of (x, y) coordinates for the robot to follow."
        )
        
    def draw_on_image(
        self,
        image_path: str,
        points: None = None,
        boxes: None = None,
        trajectories: None = None,
        output_path: None = None
    ):
        """
        绘制轨迹图
        """
        try:
            # 从UnifiedInference导入draw_on_image方法
            from .robobrain import UnifiedInference
            # 从配置中获取模型路径
            from utils.config_manager import get_config
            model_path = get_config('robobrain.model_path', '/workspace/wxd/reason-vla/RoboBrain2.0-7B')
            model = UnifiedInference(model_id=model_path)
            return model.draw_on_image(image_path, points, boxes, trajectories, output_path)
        except Exception as e:
            print(f"❌ 绘制轨迹图像时出错: {e}")
            return None
        
    async def execute(self, model_instance=None, **kwargs) -> Dict[str, Any]:
        """
        Execute trajectory planning using API
        
        Args:
            model_instance: Pre-initialized RoboBrain model instance (optional)
            task: The task description
            image_path: Path to the image for analysis
            plot: Whether to plot results on image
            
        Returns:
            Dict with trajectory points and metadata
        """
        try:
            # 通过工具管理器调用API，而不是本地模型
            from tools.tool_manager import ToolManager
            tool_manager = ToolManager()
            # 使用已加载的配置
            # 通过API调用
            task = kwargs.get('task', '')
            image_path = kwargs.get('image_path', '')
            start_point = kwargs.get('start_point', (451, 468))
            
            # 用新的prompt替换原来的prompt构建逻辑
            prompt = TRAJECTORY_TOOL_PROMPT.format(text=task)
            
            # 直接调用工具管理器中的API方法
            result = await tool_manager._call_robobrain_api(prompt, image_path, 'trajectory')
            
            if result.get('success'):
                # 提取轨迹点
                trajectory_points = []
                if "answer" in result:
                    answer_text = result["answer"]
                    # Extract coordinate pairs from the answer text
                    trajectory_pattern = r'(\d+),\s*(\d+)'
                    trajectory_points = re.findall(trajectory_pattern, answer_text)
                    trajectory_points = [(int(x), int(y)) for x, y in trajectory_points]
                
                # 保存轨迹规划结果
                # 先定义filename变量，避免作用域问题
                filename = ""
                self._save_trajectory_result(task, result, trajectory_points, image_path, start_point)
                
                # 绘制图像 - 修复：在API调用后仍然绘制图像
                try:
                    # 使用本地的draw_on_image函数绘制轨迹图
                    from tools.robobrain import UnifiedInference
                    import datetime
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    image_name_to_save = os.path.basename(image_path).replace(".", f"_with_trajectory_annotated_{timestamp}.")
                    output_path = os.path.join("result", image_name_to_save)
                    
                    # 使用本地的draw_on_image函数绘制轨迹
                    # 从配置中获取模型路径
                    from utils.config_manager import get_config
                    model_path = get_config('robobrain.model_path', '/workspace/wxd/reason-vla/RoboBrain2.0-7B')
                    model = UnifiedInference(model_id=model_path)
                    model.draw_on_image(
                        image_path,
                        points=None,
                        boxes=None,
                        trajectories=[trajectory_points],
                        output_path=output_path
                    )
                    print(f"✅ 轨迹图像已保存到: {output_path}")
                except Exception as e:
                    print(f"⚠️ 绘制轨迹图像时出错: {e}")
                
                # 直接输出结果
                print(f"🎯 轨迹规划结果:")
                print(f"   任务: {task}")
                print(f"   起始点: {start_point}")
                print(f"   轨迹点数量: {len(trajectory_points)}")
                if trajectory_points:
                    print(f"   轨迹点: {trajectory_points[:3]}{'...' if len(trajectory_points) > 3 else ''}")
                print(f"   原始输出: {result['answer'][:100]}...")
                
                # 显示保存的文件路径
                print(f"   图像已保存到: {output_path}")
                print(f"   结果已保存到: {filename}")
                
                return {
                    "success": True,
                    "tool": "trajectory",
                    "task": task,
                    # mo"start_point": start_point,
                    "trajectory_points": trajectory_points,
                    "thinking": "",
                    # "raw_output": result["answer"],
                    "image_path": output_path,
                    "result_path": filename
                }
            else:
                return {
                    "success": False,
                    "tool": "trajectory",
                    "error": result.get('error', 'Unknown error'),
                    "task": task,
                    "trajectory_points": [],
                    "thinking": ""
                }
            
        except Exception as e:
            return {
                "success": False,
                "tool": "trajectory",
                "error": str(e),
                "task": kwargs.get('task', ''),
                "trajectory_points": [],
                "thinking": ""
            }
    
    def _save_trajectory_result(self, task_description: str, raw_result: Dict, trajectory_points: List[Tuple[int, int]], image_path: str, start_point: Tuple[int, int]):
        """保存轨迹规划结果到JSON文件"""
        try:
            # 构造要保存的结构
            trajectory_result = {
                "task": task_description,
                "timestamp": datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
                "start_point": start_point,
                "trajectory_points": trajectory_points,
                "thinking": raw_result.get("thinking", ""),
                "image_path": image_path
            }

            # 保存为 JSON
            os.makedirs("result/trajectory_results", exist_ok=True)
            filename = f"result/trajectory_results/trajectory_result_{trajectory_result['timestamp']}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                import json
                json.dump(trajectory_result, f, ensure_ascii=False, indent=2)

            print(f"✅ Trajectory 结果已保存到: {filename}")
        except Exception as e:
            print(f"❌ 保存Trajectory结果时出错: {e}")
            print(f"❌ 保存Trajectory结果时出错: {e}")
