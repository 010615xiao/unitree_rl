"""
Grounding detection tool for RoboBrain Tool System
"""

import re
from typing import List, Tuple, Dict, Any
import os
import datetime
from .base_tool import BaseTool
from .robobrain import UnifiedInference
from prompts import GROUNDING_TOOL_PROMPT


class GroundingTool(BaseTool):
    """Tool for grounding detection using RoboBrain2.0"""
    
    def __init__(self):
        super().__init__(
            name="grounding",
            description="Detect object locations in image using RoboBrain2.0. "
                       "Returns bounding box coordinates of detected objects."
        )
        
    def draw_on_image(
        self,
        image_path: str,
        points: None = None,
        boxes: None = None,
        trajectories: None = None,
        output_path: None = None
    ):
        """
        绘制目标定位图
        """
        try:
            # 从UnifiedInference导入draw_on_image方法
            from .robobrain import UnifiedInference
            model = UnifiedInference(model_id="/workspace/wxd/reason-vla/RoboBrain2.0-7B")
            return model.draw_on_image(image_path, points, boxes, trajectories, output_path)
        except Exception as e:
            print(f"❌ 绘制Grounding图像时出错: {e}")
            return None
        
    async def execute(self, model_instance=None, **kwargs) -> Dict[str, Any]:
        """
        Execute grounding detection using API
        
        Args:
            model_instance: Pre-initialized RoboBrain model instance (optional)
            task: The task description
            image_path: Path to the image for analysis
            plot: Whether to plot results on image
            
        Returns:
            Dict with detected objects and metadata
        """
        try:
            # 通过工具管理器调用API，而不是本地模型
            from tools.tool_manager import ToolManager
            tool_manager = ToolManager()
            # 重新加载配置
            tool_manager._load_config()
            
            # 通过API调用
            task = kwargs.get('task', '')
            image_path = kwargs.get('image_path', '')
            
            # 使用新的prompt
            prompt = GROUNDING_TOOL_PROMPT.format(text=task)
            
            # 直接调用工具管理器中的API方法
            result = await tool_manager._call_robobrain_api(prompt, image_path, 'grounding')
            
            if result.get('success'):
                # 提取边界框
                boxes = []
                if "answer" in result:
                    answer_text = result["answer"]
                    # Extract coordinate quadruples from the answer text
                    box_pattern = r'\[\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\]'
                    boxes = re.findall(box_pattern, answer_text)
                    boxes = [[int(x1), int(y1), int(x2), int(y2)] for x1, y1, x2, y2 in boxes]
                
                # 保存目标定位结果
                # 先定义filename变量，避免作用域问题
                filename = ""
                self._save_grounding_result(task, result, boxes, image_path)
                
                # 绘制图像 - 修复：在API调用后仍然绘制图像
                try:
                    # 使用本地的draw_on_image函数绘制边界框图
                    from tools.robobrain import UnifiedInference
                    import datetime
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    image_name_to_save = os.path.basename(image_path).replace(".", f"_with_grounding_annotated_{timestamp}.")
                    output_path = os.path.join("result", image_name_to_save)
                    
                    # 使用本地的draw_on_image函数绘制边界框
                    model = UnifiedInference(model_id="/workspace/wxd/reason-vla/RoboBrain2.0-7B")
                    model.draw_on_image(
                        image_path,
                        points=None,
                        boxes=boxes,
                        trajectories=None,
                        output_path=output_path
                    )
                    print(f"✅ Grounding图像已保存到: {output_path}")
                except Exception as e:
                    print(f"⚠️ 绘制Grounding图像时出错: {e}")
                
                # 直接输出结果
                print(f"🎯 目标定位结果:")
                print(f"   任务: {task}")
                print(f"   检测到的边界框数量: {len(boxes)}")
                if boxes:
                    print(f"   边界框坐标: {boxes[:3]}{'...' if len(boxes) > 3 else ''}")
                print(f"   原始输出: {result['answer'][:100]}...")
                
                # 显示保存的文件路径
                print(f"   图像已保存到: {output_path}")
                print(f"   结果已保存到: {filename}")
                
                return {
                    "success": True,
                    "tool": "grounding",
                    "task": task,
                    "boxes": boxes,
                    "thinking": "",
                    # "raw_output": result["answer"],
                    "image_path": output_path,
                    "result_path": filename
                }
            else:
                return {
                    "success": False,
                    "tool": "grounding",
                    "error": result.get('error', 'Unknown error'),
                    "task": task,
                    "boxes": [],
                    "thinking": ""
                }
            
        except Exception as e:
            return {
                "success": False,
                "tool": "grounding",
                "error": str(e),
                "task": kwargs.get('task', ''),
                "boxes": [],
                "thinking": ""
            }
    
    def _save_grounding_result(self, task_description: str, raw_result: Dict, boxes: List[List[int]], image_path: str):
        """保存目标定位结果到JSON文件"""
        try:
            # 构造要保存的结构
            grounding_result = {
                "task": task_description,
                "timestamp": datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
                "boxes": boxes,
                "thinking": raw_result.get("thinking", ""),
                "image_path": image_path
            }

            # 保存为 JSON
            os.makedirs("result/grounding_results", exist_ok=True)
            filename = f"result/grounding_results/grounding_result_{grounding_result['timestamp']}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                import json
                json.dump(grounding_result, f, ensure_ascii=False, indent=2)

            print(f"✅ Grounding 结果已保存到: {filename}")
        except Exception as e:
            print(f"❌ 保存Grounding结果时出错: {e}")
