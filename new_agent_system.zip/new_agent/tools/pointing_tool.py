"""
Pointing detection tool for RoboBrain Tool System
"""

import re
from typing import List, Tuple, Dict, Any
import os
import datetime
from .base_tool import BaseTool
from .robobrain import UnifiedInference
from prompts import POINTING_TOOL_PROMPT


class PointingTool(BaseTool):
    """Tool for pointing detection using RoboBrain2.0"""
    
    def __init__(self):
        super().__init__(
            name="pointing",
            description="Detect interest points in image using RoboBrain2.0. "
                       "Returns a list of (x, y) coordinates of detected points."
        )
        
    def draw_on_image(
        self,
        image_path: str,
        points: None = None,
        boxes: None = None,
        trajectories: None = None,
        output_path: None = None
    ):
        """
        绘制点检测图
        """
        try:
            # 从UnifiedInference导入draw_on_image方法
            from .robobrain import UnifiedInference
            model = UnifiedInference(model_id="/workspace/wxd/reason-vla/RoboBrain2.0-7B")
            return model.draw_on_image(image_path, points, boxes, trajectories, output_path)
        except Exception as e:
            print(f"❌ 绘制Pointing图像时出错: {e}")
            return None
        
    async def execute(self, model_instance=None, **kwargs) -> Dict[str, Any]:
        """
        Execute pointing detection using API
        
        Args:
            model_instance: Pre-initialized RoboBrain model instance (optional)
            task: The task description
            image_path: Path to the image for analysis
            plot: Whether to plot results on image
            
        Returns:
            Dict with detected points and metadata
        """
        try:
            # 通过工具管理器调用API，而不是本地模型
            from tools.tool_manager import ToolManager
            tool_manager = ToolManager()
            # 重新加载配置
            tool_manager._load_config()
            
            # 通过API调用
            task = kwargs.get('task', '')
            image_path = kwargs.get('image_path', '')
            
            # 使用新的prompt
            prompt = POINTING_TOOL_PROMPT.format(text=task)
            
            # 直接调用工具管理器中的API方法
            result = await tool_manager._call_robobrain_api(prompt, image_path, 'pointing')
            
            if result.get('success'):
                # 提取点坐标
                points = []
                if "answer" in result:
                    answer_text = result["answer"]
                    print(f"🔍 Pointing工具接收到的answer文本: {answer_text}")
                    # Extract coordinate pairs from the answer text
                    point_pattern = r'\(\s*(\d+)\s*,\s*(\d+)\s*\)'
                    points = re.findall(point_pattern, answer_text)
                    points = [(int(x), int(y)) for x, y in points]
                    print(f"🔍 提取到的点坐标: {points}")
                
                # 保存点检测结果
                # 先定义filename变量，避免作用域问题
                filename = ""
                self._save_pointing_result(task, result, points, image_path)
                
                # 绘制图像 - 修复：在API调用后仍然绘制图像
                try:
                    # 使用本地的draw_on_image函数绘制点图
                    from tools.robobrain import UnifiedInference
                    import datetime
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    image_name_to_save = os.path.basename(image_path).replace(".", f"_with_pointing_annotated_{timestamp}.")
                    output_path = os.path.join("result", image_name_to_save)
                    
                    # 使用本地的draw_on_image函数绘制点
                    model = UnifiedInference(model_id="/workspace/wxd/reason-vla/RoboBrain2.0-7B")
                    model.draw_on_image(
                        image_path,
                        points=points,
                        boxes=None,
                        trajectories=None,
                        output_path=output_path
                    )
                    print(f"✅ Pointing图像已保存到: {output_path}")
                except Exception as e:
                    print(f"⚠️ 绘制Pointing图像时出错: {e}")
                
                # 直接输出结果
                print(f"🎯 点检测结果:")
                print(f"   任务: {task}")
                print(f"   检测到的点数量: {len(points)}")
                if points:
                    print(f"   点坐标: {points[:3]}{'...' if len(points) > 3 else ''}")
                print(f"   原始输出: {result['answer'][:100]}...")
                
                # 显示保存的文件路径
                print(f"   图像已保存到: {output_path}")
                print(f"   结果已保存到: {filename}")
                
                return {
                    "success": True,
                    "tool": "pointing",
                    "task": task,
                    "points": points,
                    "thinking": "",
                    # "raw_output": result["answer"],
                    "image_path": output_path,
                    "result_path": filename
                }
            else:
                return {
                    "success": False,
                    "tool": "pointing",
                    "error": result.get('error', 'Unknown error'),
                    "task": task,
                    "points": [],
                    "thinking": ""
                }
            
        except Exception as e:
            return {
                "success": False,
                "tool": "pointing",
                "error": str(e),
                "task": kwargs.get('task', ''),
                "points": [],
                "thinking": ""
            }
    
    def _save_pointing_result(self, task_description: str, raw_result: Dict, points: List[Tuple[int, int]], image_path: str):
        """保存点检测结果到JSON文件"""
        try:
            # 构造要保存的结构
            pointing_result = {
                "task": task_description,
                "timestamp": datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
                "points": points,
                "thinking": raw_result.get("thinking", ""),
                "image_path": image_path
            }

            # 保存为 JSON
            os.makedirs("result/pointing_results", exist_ok=True)
            filename = f"result/pointing_results/pointing_result_{pointing_result['timestamp']}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                import json
                json.dump(pointing_result, f, ensure_ascii=False, indent=2)

            print(f"✅ Pointing 结果已保存到: {filename}")
        except Exception as e:
            print(f"❌ 保存Pointing结果时出错: {e}")
