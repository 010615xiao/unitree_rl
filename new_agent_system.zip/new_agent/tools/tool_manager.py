#!/usr/bin/env python3
"""
工具管理模块
负责工具初始化、执行和参数处理
"""

import asyncio
import logging
import sys
import os
import yaml
import aiohttp
from typing import Dict, Any, List

# Add the project root to Python path for proper imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tool_registry import ToolRegistry
from prompts import TRAJECTORY_TOOL_PROMPT, PLANNING_TOOL_PROMPT, AFFORDANCE_TOOL_PROMPT, GROUNDING_TOOL_PROMPT, POINTING_TOOL_PROMPT, VISUAL_DESCRIPTION_PROMPT, BROWSER_USE_PROMPT

logger = logging.getLogger(__name__)


class ToolManager:
    """工具管理器"""
    
    def __init__(self):
        self.tool_registry = ToolRegistry()
        self.config = self._load_config()
        self._robo_brain_models = {}
        # 不再缓存模型实例，改为直接实现图像绘制功能
        
    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            with open('config.yaml', 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            return config
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            # 返回默认配置
            return {
                'robobrain': {
                    'host': 'localhost',
                    'port': 8001,
                    'model_name': 'RoboBrain2.0 7B'
                }
            }
        
    def initialize_tools(self):
        """初始化所有可用工具"""
        # 注册所有工具
        self.tool_registry.register_tool(
            name="trajectory",
            description="规划从当前位置到指定位置的轨迹点序列",
            param_model=None,
            func=self._execute_trajectory,
            is_async=True
        )
        
        self.tool_registry.register_tool(
            name="planning",
            description="任务分解和调度",
            param_model=None,
            func=self._execute_planning,
            is_async=True
        )
        
        self.tool_registry.register_tool(
            name="pointing",
            description="定位图像中感兴趣区域的指定坐标点",
            param_model=None,
            func=self._execute_pointing,
            is_async=True
        )
        
        self.tool_registry.register_tool(
            name="affordance",
            description="识别图像中物体的可操作区域（如抓取点/按压点）",
            param_model=None,
            func=self._execute_affordance,
            is_async=True
        )
        
        self.tool_registry.register_tool(
            name="grounding",
            description="检测并框选图像中特定物体的边界框",
            param_model=None,
            func=self._execute_grounding,
            is_async=True
        )
        
        # 注册browser_use_answer工具
        self.tool_registry.register_tool(
            name="browser_use_answer",
            description="浏览器自动化工具，可以搜索网页并提取问题的答案",
            param_model=None,
            func=self._execute_browser_use,
            is_async=True
        )
        
        # 注册visual_description工具
        self.tool_registry.register_tool(
            name="visual_description",
            description="对图像进行通用描述，提取图像中的物体、场景和空间关系等视觉信息",
            param_model=None,
            func=self._execute_visual_description,
            is_async=True
        )
        
        logger.info(f"已初始化 {len(self.tool_registry.list_tools())} 个工具")
        
    async def _call_robobrain_api(self, text: str, image_path: str, task: str) -> Dict[str, Any]:
        """通过API调用RoboBrain模型"""
        try:
            # 获取RoboBrain配置
            robobrain_config = self.config.get('robobrain', {})
            host = robobrain_config.get('host', 'localhost')
            port = robobrain_config.get('port', 8001)
            model_name = robobrain_config.get('model_name', 'RoboBrain2.0 7B')
            
            # 构造API URL
            url = f"http://{host}:{port}/v1/chat/completions"
            
            # 根据任务类型使用对应的prompt
            if task == "pointing":
                prompt = POINTING_TOOL_PROMPT.format(text=text)
            elif task == "planning":
                prompt = PLANNING_TOOL_PROMPT.format(text=text)
            elif task == "affordance":
                prompt = AFFORDANCE_TOOL_PROMPT.format(text=text)
            elif task == "trajectory":
                prompt = TRAJECTORY_TOOL_PROMPT.format(text=text)
            elif task == "grounding":
                prompt = GROUNDING_TOOL_PROMPT.format(text=text)
            elif task == "general":
                prompt = VISUAL_DESCRIPTION_PROMPT.format(text=text)
            else:
                # 对于其他任务类型，使用通用的文本格式
                prompt = text

            # 构造请求数据
            data = {
                "model": model_name,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"http://localhost:8080/{os.path.basename(image_path)}"
                                }
                            }
                        ]
                    }
                ],
                "max_tokens": 1024
            }
            
            # 打印完整的请求信息（调试用）
            print("="*60)
            print("🔍 API请求详情:")
            print(f"  URL: {url}")
            print(f"  Model: {model_name}")
            print(f"  Prompt: {prompt[:200]}...")
            print(f"  Image path: {image_path}")
            print(f"  Image URL: http://localhost:8080/{os.path.basename(image_path)}")
            print("="*60)
            
            headers = {
                "Content-Type": "application/json"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=data, headers=headers) as response:
                    if response.status == 200:
                        result = await response.json()
                        # 处理API响应
                        content = result.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
                        return {
                            "success": True,
                            "answer": content,
                            "raw_response": result
                        }
                    else:
                        return {
                            "success": False,
                            "error": f"API调用失败: 状态码 {response.status}",
                            "status_code": response.status
                        }
                        
        except Exception as e:
            logger.error(f"调用RoboBrain API出错: {e}")
            return {
                "success": False,
                "error": str(e)
            }
        
    async def _execute_trajectory(self, **kwargs) -> Dict[str, Any]:
        """执行轨迹规划工具"""
        # 使用API调用RoboBrain
        text = kwargs.get('task', '')
        image_path = kwargs.get('image_path', '')
        task = 'trajectory'
        
        # 使用API模式调用RoboBrain
        from .robobrain import UnifiedInference
        
        # 从配置中获取RoboBrain设置
        robobrain_config = self.config.get('robobrain', {})
        api_host = robobrain_config.get('host', 'localhost')
        api_port = robobrain_config.get('port', 8001)
        
        model = UnifiedInference(
            model_id=robobrain_config.get('model_path', '/workspace/wxd/reason-vla/RoboBrain2.0-7B'),
            use_api=True,
            api_host=api_host,
            api_port=api_port
        )
        result = await model.inference(text, image_path, task=task, plot=False)
        
        # 保存轨迹规划结果
        if result.get('success'):
            # 提取轨迹点
            import re
            trajectory_points = []
            trajectory_pattern = r'(\d+),\s*(\d+)'
            trajectory_points = re.findall(trajectory_pattern, result['answer'])
            trajectory_points = [(int(x), int(y)) for x, y in trajectory_points]
            
            # 保存结果
            from .trajectory_tool import TrajectoryTool
            tool = TrajectoryTool()
            tool._save_trajectory_result(text, result, trajectory_points, image_path, kwargs.get('start_point', (451, 468)))
            
            # 绘制图像 - 添加图像绘制功能
            try:
                # 创建高效图像绘制函数
                output_path = self._draw_image_direct(image_path, trajectories=[trajectory_points], task="trajectory")
                print(f"✅ 轨迹图像已保存到: {output_path}")
            except Exception as e:
                print(f"⚠️ 绘制轨迹图像时出错: {e}")
            
            # 展示轨迹结果
            print(f"🎯 轨迹规划结果:")
            print(f"   任务: {text}")
            print(f"   轨迹点数量: {len(trajectory_points)}")
            
            return {
                "success": True,
                "tool": "trajectory",
                "task": text,
                # "start_point": kwargs.get('start_point', (451, 468)),
                # "trajectory_points": trajectory_points,
                "thinking": "",
                # "raw_output": result['answer'],
                "image_path": output_path if 'output_path' in locals() else None,
                "result": {
                    "trajectory_points": trajectory_points
                }
            }
        else:
            return {
                "success": False,
                "tool": "trajectory",
                "error": result.get('error', 'Unknown error'),
                "task": text,
                "trajectory_points": [],
                "thinking": ""
            }
        
    async def _execute_planning(self, **kwargs) -> Dict[str, Any]:
        """执行任务规划工具"""
        # 使用API调用RoboBrain
        text = kwargs.get('task', '')
        image_path = kwargs.get('image_path', '')
        task = 'planning'
        
        result = await self._call_robobrain_api(text, image_path, task)
        
        # 保存规划结果
        if result.get('success'):
            # 保存结果
            from .planning_tool import PlanningTool
            tool = PlanningTool()
            # 解析规划结果
            parsed_result = tool._parse_planning_result(result['answer'])
            tool._save_planning_result(text, result, parsed_result, image_path)
            
            # 展示规划结果
            print(f"🎯 任务规划结果:")
            print(f"   任务: {text}")
            print(f"   计划: {parsed_result.get('plan', '')[:100]}...")
            print(f"   动作: {parsed_result.get('action', '')}")
            print(f"   步骤数量: {len(parsed_result.get('steps', []))}")
            if parsed_result.get('steps'):
                print(f"   步骤: {parsed_result['steps'][:3]}{'...' if len(parsed_result['steps']) > 3 else ''}")
            print(f"   思考过程: {parsed_result.get('thinking', '')[:100]}...")
            
            return {
                "success": True,
                "tool": "planning",
                "task": text,
                # "raw_output": result['answer'],
                "parsed": parsed_result,
                # "plan": parsed_result.get("plan", ""),
                # "steps": parsed_result.get("steps", []),
                # "action": parsed_result.get("action", ""),
                # "thinking": parsed_result.get("thinking", ""),
                "result": {
                    "plan": parsed_result.get("plan", ""),
                    "steps": parsed_result.get("steps", []),
                    "action": parsed_result.get("action", ""),
                    "thinking": parsed_result.get("thinking", ""),
                    "parameters": kwargs  # 添加参数信息，便于后续检查
                }
            }
        else:
            return {
                "success": False,
                "tool": "planning",
                "error": result.get('error', 'Unknown error'),
                "task": text
            }
        
    async def _execute_pointing(self, **kwargs) -> Dict[str, Any]:
        """执行点检测工具"""
        # 使用API调用RoboBrain
        text = kwargs.get('task', '')
        image_path = kwargs.get('image_path', '')
        task = 'pointing'
        
        result = await self._call_robobrain_api(text, image_path, task)
        
        # 保存点检测结果
        if result.get('success'):
            # 提取点坐标
            import re
            points = []
            point_pattern = r'\(\s*(\d+)\s*,\s*(\d+)\s*\)'
            points = re.findall(point_pattern, result['answer'])
            points = [(int(x), int(y)) for x, y in points]
            
            # 保存结果
            from .pointing_tool import PointingTool
            tool = PointingTool()
            tool._save_pointing_result(text, result, points, image_path)
            
            # 绘制图像 - 添加图像绘制功能
            try:
                # 创建高效图像绘制函数
                output_path = self._draw_image_direct(image_path, points=points, task="pointing")
                print(f"✅ Pointing图像已保存到: {output_path}")
            except Exception as e:
                print(f"⚠️ 绘制Pointing图像时出错: {e}")
            
            # 展示点检测结果
            print(f"🎯 点检测结果:")
            print(f"   任务: {text}")
            print(f"   检测到的点数量: {len(points)}")
            if points:
                print(f"   点坐标: {points[:3]}{'...' if len(points) > 3 else ''}")
            print(f"   原始输出: {result['answer'][:100]}...")
            
            return {
                "success": True,
                "tool": "pointing",
                "task": text,
                # "points": points,
                "thinking": "",
                # "raw_output": result['answer'],
                "image_path": output_path if 'output_path' in locals() else None,
                "result": {
                    "points": points
                }
            }
        else:
            return {
                "success": False,
                "tool": "pointing",
                "error": result.get('error', 'Unknown error'),
                "task": text,
                "points": []
            }
        
    async def _execute_affordance(self, **kwargs) -> Dict[str, Any]:
        """执行可达区域检测工具"""
        # 使用API调用RoboBrain
        text = kwargs.get('task', '')
        image_path = kwargs.get('image_path', '')
        task = 'affordance'
        
        result = await self._call_robobrain_api(text, image_path, task)
        
        # 保存可达区域结果
        if result.get('success'):
            # 提取边界框
            import re
            boxes = []
            box_pattern = r'\[\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\]'
            boxes = re.findall(box_pattern, result['answer'])
            boxes = [[int(x1), int(y1), int(x2), int(y2)] for x1, y1, x2, y2 in boxes]
            
            # 保存结果
            from .affordance_tool import AffordanceTool
            tool = AffordanceTool()
            tool._save_affordance_result(text, result, boxes, image_path)
            
            # 绘制图像 - 添加图像绘制功能
            try:
                # 创建高效图像绘制函数
                output_path = self._draw_image_direct(image_path, boxes=boxes, task="affordance")
                print(f"✅ Affordance图像已保存到: {output_path}")
            except Exception as e:
                print(f"⚠️ 绘制Affordance图像时出错: {e}")
            
            # 展示可达区域结果
            print(f"🎯 可达区域检测结果:")
            print(f"   任务: {text}")
            print(f"   检测到的边界框数量: {len(boxes)}")
            if boxes:
                print(f"   边界框坐标: {boxes[:3]}{'...' if len(boxes) > 3 else ''}")
            print(f"   原始输出: {result['answer'][:100]}...")
            
            return {
                "success": True,
                "tool": "affordance",
                "task": text,
                # "boxes": boxes,
                "thinking": "",
                # "raw_output": result['answer'],
                "image_path": output_path if 'output_path' in locals() else None,
                "result": {
                    "boxes": boxes
                }
            }
        else:
            return {
                "success": False,
                "tool": "affordance",
                "error": result.get('error', 'Unknown error'),
                "task": text,
                "boxes": []
            }
        
    async def _execute_grounding(self, **kwargs) -> Dict[str, Any]:
        """执行目标定位工具"""
        # 使用API调用RoboBrain
        text = kwargs.get('task', '')
        image_path = kwargs.get('image_path', '')
        task = 'grounding'
        
        result = await self._call_robobrain_api(text, image_path, task)
        
        # 保存目标定位结果
        if result.get('success'):
            # 提取边界框
            import re
            boxes = []
            box_pattern = r'\[\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\]'
            boxes = re.findall(box_pattern, result['answer'])
            boxes = [[int(x1), int(y1), int(x2), int(y2)] for x1, y1, x2, y2 in boxes]
            
            # 保存结果
            from .grounding_tool import GroundingTool
            tool = GroundingTool()
            tool._save_grounding_result(text, result, boxes, image_path)
            
            # 绘制图像 - 添加图像绘制功能
            try:
                # 创建高效图像绘制函数
                output_path = self._draw_image_direct(image_path, boxes=boxes, task="grounding")
                print(f"✅ Grounding图像已保存到: {output_path}")
            except Exception as e:
                print(f"⚠️ 绘制Grounding图像时出错: {e}")
            
            # 展示目标定位结果
            print(f"🎯 目标定位结果:")
            print(f"   任务: {text}")
            print(f"   检测到的边界框数量: {len(boxes)}")
            if boxes:
                print(f"   边界框坐标: {boxes[:3]}{'...' if len(boxes) > 3 else ''}")
            print(f"   原始输出: {result['answer'][:100]}...")
            
            return {
                "success": True,
                "tool": "grounding",
                "task": text,
                # "boxes": boxes,
                "thinking": "",
                # "raw_output": result['answer'],
                "image_path": output_path if 'output_path' in locals() else None,
                "result": {
                    "boxes": boxes
                }
            }
        else:
            return {
                "success": False,
                "tool": "grounding",
                "error": result.get('error', 'Unknown error'),
                "task": text,
                "boxes": []
            }
    
    def _draw_image_direct(self, image_path: str, points=None, boxes=None, trajectories=None, task: str = "general") -> str:
        """
        直接绘制图像的函数，不依赖RoboBrain模型加载
        """
        try:
            # 直接导入所需库
            import cv2
            import numpy as np
            import datetime
            import os
            
            # 读取图像
            image = cv2.imread(image_path)
            if image is None:
                raise FileNotFoundError(f"Unable to read image: {image_path}")
            h, w = image.shape[:2]

            # Draw bounding boxes
            if boxes:
                for box in boxes:
                    x1, y1, x2, y2 = box
                    cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)

            # Draw points
            if points:
                for point in points:
                    x, y = point
                    cv2.circle(image, (x, y), 5, (0, 0, 255), -1)

            # Draw trajectories with arrows and labels
            if trajectories:
                for traj_idx, trajectory in enumerate(trajectories):
                    if len(trajectory) < 2:
                        continue

                    pts = np.array(trajectory, np.int32)
                    pts = pts.reshape((-1, 1, 2))

                    # Draw smooth line
                    cv2.polylines(image, [pts], isClosed=False, color=(255, 140, 0), thickness=3)  # Orange path

                    # Draw start and end markers
                    start = tuple(map(int, trajectory[0]))
                    end = tuple(map(int, trajectory[-1]))

                    cv2.circle(image, start, 8, (0, 255, 0), -1)  # Green start
                    cv2.circle(image, end, 10, (0, 0, 255), -1)   # Red end

                    # Add arrow at mid-point
                    mid_idx = len(trajectory) // 2
                    pt1 = tuple(map(int, trajectory[mid_idx - 1]))
                    pt2 = tuple(map(int, trajectory[mid_idx]))

                    cv2.arrowedLine(image, pt1, pt2, (255, 69, 0), 2, tipLength=0.3)

                    # Label the trajectory
                    cv2.putText(image, f'Traj {traj_idx+1}', (start[0], start[1] - 15),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 140, 0), 2)

                    # Draw intermediate points
                    for i, point in enumerate(trajectory):
                        x, y = map(int, point)
                        cv2.circle(image, (x, y), 4, (255, 255, 0), -1)  # Yellow dots

            # 生成输出路径
            import datetime
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # 根据任务类型生成图像文件名
            if task == "trajectory":
                image_name_to_save = os.path.basename(image_path).replace(".", f"_with_trajectory_annotated_{timestamp}.")
            elif task == "pointing":
                image_name_to_save = os.path.basename(image_path).replace(".", f"_with_pointing_annotated_{timestamp}.")
            elif task == "affordance":
                image_name_to_save = os.path.basename(image_path).replace(".", f"_with_affordance_annotated_{timestamp}.")
            elif task == "grounding":
                image_name_to_save = os.path.basename(image_path).replace(".", f"_with_grounding_annotated_{timestamp}.")
            else:
                image_name_to_save = os.path.basename(image_path).replace(".", f"_annotated_{timestamp}.")
            
            output_path = os.path.join("result", image_name_to_save)
            
            # 保存输出
            os.makedirs("result", exist_ok=True)
            cv2.imwrite(output_path, image)
            print(f"✅ Annotated image saved to: {output_path}")
            return output_path
        except Exception as e:
            print(f"❌ Error processing image: {e}")
            return ""
        
    async def _execute_browser_use(self, **kwargs) -> Dict[str, Any]:
        """执行浏览器问答工具"""
        from colorama import Fore, Style
        from .browser_use_tool import BrowserUseTool
        tool = BrowserUseTool()
        
        # 检查是否有search_terms参数
        if 'search_terms' in kwargs and kwargs['search_terms']:
            search_terms = kwargs['search_terms']
            # 如果是列表，转换为具体的搜索任务
            if isinstance(search_terms, list):
                # 构建具体的搜索任务
                if len(search_terms) == 1:
                    kwargs['task'] = f"查询{search_terms[0]}的具体数值"
                else:
                    # 为每个食物构建详细的搜索任务
                    food_list = "、".join(search_terms)
                    kwargs['task'] = f"查询{food_list}的数值，并比较哪个最高"
            print(f"{Fore.MAGENTA}🔄 使用search_terms构建任务: {kwargs['task']}{Style.RESET_ALL}")
        
        print(f"{Fore.GREEN}🔧 最终browser任务: {kwargs['task']}{Style.RESET_ALL}")
        result = await tool.execute(**kwargs)
        
        # 添加更详细的日志，确保工具执行状态被正确记录
        if result.get('success'):
            print(f"{Fore.GREEN}✅ 工具 browser_use_answer 执行成功{Style.RESET_ALL}")
            if 'final_answer' in result:
                print(f"   {Fore.CYAN}最终答案: {result['final_answer'][:100]}...{Style.RESET_ALL}")
            if 'steps_taken' in result:
                print(f"   {Fore.CYAN}执行步骤数: {result['steps_taken']}{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}❌ 工具 browser_use_answer 执行失败: {result.get('error', '未知错误')}{Style.RESET_ALL}")
        
        # 格式化为期望的格式
        formatted_result = {
            "tool_name": result.get("tool", "browser_use_answer"),
            "success": result.get("success", False),
            "task": result.get("task", kwargs.get("task", "")),
            "answer": result.get("result", result.get("final_answer", result.get("answer", "")))
        }
        # 移除空字段
        formatted_result = {k: v for k, v in formatted_result.items() if v is not None and v != ""}
        
        return formatted_result
        
    async def _execute_visual_description(self, **kwargs) -> Dict[str, Any]:
        """执行视觉描述工具"""
        # 使用API调用RoboBrain
        text = kwargs.get('task', '描述图像内容')
        image_path = kwargs.get('image_path', '')
        task = 'general'
        
        result = await self._call_robobrain_api(text, image_path, task)
        
        # 保存视觉描述结果
        if result.get('success'):
            # 保存结果
            from .visual_description_tool import VisualDescriptionTool
            tool = VisualDescriptionTool()
            tool._save_visual_description_result(text, result, image_path)
            
            # 展示视觉描述结果
            print(f"🎯 图像视觉描述结果:")
            print(f"   图像路径: {image_path}")
            print(f"   描述内容: {result['answer'][:520]}...")
            
            return {
                "success": True,
                "tool": "visual_description",
                "task": text,
                # "description": result['answer'],
                # "raw_output": result['answer'],
                "result": {
                    "description": result['answer']
                }
            }
        else:
            return {
                "success": False,
                "tool": "visual_description",
                "error": result.get('error', 'Unknown error'),
                "task": text
            }
        
    def get_tool_descriptions(self) -> Dict[str, str]:
        """获取所有可用工具的描述"""
        return self.tool_registry.get_tool_descriptions()
        
    async def execute_tool(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """执行指定工具"""
        try:
            # 确保工具已初始化
            if not hasattr(self, 'tool_registry') or self.tool_registry is None:
                self.initialize_tools()
            
            # 执行工具
            result = await self.tool_registry.execute_tool(tool_name=tool_name, params=params)
            
            # 确保返回结构正确
            if isinstance(result, dict) and 'success' in result:
                return result
            else:
                # 如果返回结果不是标准格式，包装一下
                return {
                    "success": True,
                    "tool": tool_name,
                    "result": result
                }
        except Exception as e:
            return {
                "success": False,
                "tool": tool_name,
                "error": str(e)
            }
        

