"""
视觉描述工具 - 封装RoboBrain的general功能
用于描述图像内容并获取视觉信息
"""

import asyncio
import os
import logging
import datetime
from typing import Dict, Any, Optional
from pathlib import Path
from .base_tool import BaseTool
from .robobrain import UnifiedInference
from prompts import VISUAL_DESCRIPTION_PROMPT


class VisualDescriptionTool(BaseTool):
    """视觉描述工具 - 使用RoboBrain模型描述图像内容"""
    
    def __init__(self):
        super().__init__(
            name="visual_description",
            description="使用RoboBrain模型描述图像内容，提取视觉信息"
        )
        self.logger = logging.getLogger(__name__)
        self._model_instance = None
        
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        执行视觉描述任务使用API
        
        Args:
            image_path: 图像文件路径
            task: 任务类型，固定为"general"
            model_path: RoboBrain模型路径（可选）
            
        Returns:
            包含图像描述的字典
        """
        try:
            # 提取参数
            image_path = kwargs.get('image_path', '')
            task = kwargs.get('task', 'general')
            model_path = kwargs.get('model_path', '/workspace/wxd/reason-vla/RoboBrain2.0-7B')
            
            # 验证图像路径
            if not image_path or not os.path.exists(image_path):
                return {
                    "success": False,
                    "tool": "visual_description",
                    "error": f"图像文件不存在: {image_path}"
                }
            
            self.logger.info(f"🚀 开始视觉描述任务: {image_path}")
            
            # 通过工具管理器调用API，而不是本地模型
            from tools.tool_manager import ToolManager
            tool_manager = ToolManager()
            # 重新加载配置
            tool_manager._load_config()
            
            # 通过API调用
            prompt = VISUAL_DESCRIPTION_PROMPT
            
            result = await tool_manager._call_robobrain_api(prompt, image_path, 'general')
            
            if result.get('success'):
                # 提取结果
                answer = result.get('answer', '')
                thinking = ""  # API调用不返回thinking字段
                
                self.logger.info("✅ 视觉描述任务完成")
                
                # 保存视觉描述结果
                self._save_visual_description_result(task, result, image_path)
                
                # 原始视觉描述任务不需要绘制图像，因此不需要额外处理
                
                # 展示视觉描述结果
                print(f"🎯 图像视觉描述结果:")
                print(f"   图像路径: {image_path}")
                print(f"   描述内容: {answer[:200]}...")
                
                return {
                    "success": True,
                    "tool": "visual_description",
                    "image_path": image_path,
                    "description": answer,
                    "thinking": thinking,
                    "raw_result": result,
                    "result": {
                        "description": answer
                    }
                }
            else:
                error_msg = result.get('error', 'Unknown error')
                self.logger.error(f"❌ 视觉描述工具执行失败: {error_msg}")
                return {
                    "success": False,
                    "tool": "visual_description",
                    "error": error_msg,
                    "image_path": image_path
                }
            
        except Exception as e:
            error_msg = str(e)
            self.logger.error(f"❌ 视觉描述工具执行失败: {error_msg}")
            return {
                "success": False,
                "tool": "visual_description",
                "error": error_msg,
                "image_path": kwargs.get('image_path', '')
            }
    
    def _save_visual_description_result(self, task_description: str, raw_result: Dict, image_path: str):
        """保存视觉描述结果到JSON文件"""
        try:
            # 构造要保存的结构
            description_result = {
                "task": task_description,
                "timestamp": datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
                "description": raw_result.get("answer", ""),
                "thinking": raw_result.get("thinking", ""),
                "image_path": image_path
            }

            # 保存为 JSON
            os.makedirs("result/visual_description_results", exist_ok=True)
            filename = f"result/visual_description_results/visual_description_result_{description_result['timestamp']}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                import json
                json.dump(description_result, f, ensure_ascii=False, indent=2)

            print(f"✅ Visual Description 结果已保存到: {filename}")
        except Exception as e:
            print(f"❌ 保存Visual Description结果时出错: {e}")
