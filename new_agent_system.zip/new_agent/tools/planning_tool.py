"""
Planning tool for RoboBrain Tool System
"""

import re
from typing import Dict, Any, List, Optional
import os
import datetime
from .base_tool import BaseTool
from .robobrain import UnifiedInference
from prompts import PLANNING_TOOL_PROMPT


class PlanningTool(BaseTool):
    """Tool for task planning using RoboBrain2.0"""
    
    def __init__(self):
        super().__init__(
            name="planning",
            description="Plan a task execution sequence using RoboBrain2.0. "
                       "Returns detailed steps and actions for robot execution."
        )
        
    async def execute(self, model_instance=None, **kwargs) -> Dict[str, Any]:
        """
        Execute task planning using API
        
        Args:
            model_instance: Pre-initialized RoboBrain model instance (optional)
            task: The task description
            image_path: Path to the image for analysis
            plot: Whether to plot results on image
            
        Returns:
            Dict with plan and execution steps
        """
        try:
            # 通过工具管理器调用API，而不是本地模型
            from tools.tool_manager import ToolManager
            tool_manager = ToolManager()
            # 重新加载配置
            tool_manager._load_config()
            
            # 通过API调用
            task = kwargs.get('task', '')
            image_path = kwargs.get('image_path', '')
            
            # 使用新的prompt
            prompt = PLANNING_TOOL_PROMPT.format(text=task)
            
            # 直接调用工具管理器中的API方法
            result = await tool_manager._call_robobrain_api(prompt, image_path, 'planning')
            
            if result.get('success'):
                # Parse the plan from the result
                answer = result.get('answer', '')
                parsed_result = self._parse_planning_result(answer)
                
                # 保存规划结果
                self._save_planning_result(task, result, parsed_result, image_path)
                
                # 直接输出结果
                print(f"🎯 任务规划结果:")
                print(f"   任务: {task}")
                print(f"   计划: {parsed_result.get('plan', '')[:100]}...")
                print(f"   动作: {parsed_result.get('action', '')}")
                print(f"   步骤数量: {len(parsed_result.get('steps', []))}")
                if parsed_result.get('steps'):
                    print(f"   步骤: {parsed_result['steps'][:3]}{'...' if len(parsed_result['steps']) > 3 else ''}")
                print(f"   思考过程: {parsed_result.get('thinking', '')[:100]}...")
                
                # 为了确保返回结果中包含所有需要的信息，我们扩展返回值
                return {
                    "success": True,
                    "tool": "planning",
                    "task": task,
                    "result": result,
                    # "raw_output": answer,
                    # "parsed": parsed_result,
                    "plan": parsed_result.get("plan", ""),
                    "steps": parsed_result.get("steps", []),
                    "action": parsed_result.get("action", ""),
                    "thinking": parsed_result.get("thinking", "")
                }
            else:
                return {
                    "success": False,
                    "tool": "planning",
                    "error": result.get('error', 'Unknown error'),
                    "task": task
                }
            
        except Exception as e:
            return {
                "success": False,
                "tool": "planning",
                "error": str(e),
                "task": kwargs.get('task', '')
            }
    
    def _parse_planning_result(self, answer_text: str) -> Dict[str, Any]:
        """
        解析任务规划结果文本 - 专门处理复杂返回格式
        """
        print(f"🔍 PlanningTool解析开始...")
        print(f"原始响应长度: {len(answer_text)}")
        print(f"原始响应内容:\n{answer_text[:500]}...")  # 限制输出长度
        print("-" * 50)
        
        result = {
            "plan": "",
            "steps": [],
            "action": "",
            "thinking": ""
        }
        
        try:
            # 专门处理这个复杂的返回格式
            # 从日志中可以看出返回格式是这样的：
            # <answer> 
            # ```xml
            # [一些文本]
            # <plan>
            # <step1>...</step1>
            # ...
            # </plan>
            # ```xml
            # </answer>
            
            cleaned_text = answer_text.strip()
            
            # 1. 直接提取 <answer> 标签中的内容
            answer_match = re.search(r'<answer>(.*?)</answer>', cleaned_text, re.DOTALL)
            if answer_match:
                answer_content = answer_match.group(1).strip()
                print(f"✅ 从 <answer> 标签中提取内容: {answer_content[:100]}...")
                cleaned_text = answer_content
            
            # 2. 直接处理 <plan> 标签，不依赖复杂的正则匹配
            # 先尝试直接从整个文本中提取 <plan> 标签内容
            plan_match = re.search(r'<plan>(.*?)</plan>', cleaned_text, re.DOTALL)
            if plan_match:
                plan_content = plan_match.group(1).strip()
                print(f"✅ 直接提取 <plan> 标签内容: {plan_content[:100]}...")
                result["plan"] = plan_content
                
                # 从plan内容中提取所有步骤
                step_pattern = r'<step(\d+)>(.*?)</step\1>'
                found_steps = re.findall(step_pattern, plan_content, re.DOTALL)
                if found_steps:
                    steps = [step[1].strip() for step in sorted(found_steps, key=lambda x: int(x[0]))]
                    print(f"✅ 从 <plan> 内容中提取步骤: {steps}")
                    result["steps"] = steps
                else:
                    # 从plan内容中提取步骤描述
                    # 尝试从文本中提取步骤描述
                    step_lines = []
                    plan_lines = plan_content.split('\n')
                    for line in plan_lines:
                        line = line.strip()
                        if line and ('step' in line.lower() or line[0].isdigit()):
                            # 保证是步骤描述
                            if len(line) > 10 and ('grasp' in line.lower() or 
                                                 'place' in line.lower() or 
                                                 'move' in line.lower() or 
                                                 'put' in line.lower() or
                                                 '取' in line or '放' in line):
                                step_lines.append(line)
                    if step_lines:
                        result["steps"] = step_lines
                        print(f"✅ 从plan文本中提取步骤: {step_lines}")
            
            # 3. 如果没有提取到步骤，尝试从纯文本中提取步骤
            if not result["steps"]:
                # 从整个cleaned_text中提取包含动作的行
                lines = cleaned_text.split('\n')
                step_lines = []
                for line in lines:
                    line = line.strip()
                    if line and len(line) > 10:
                        # 检查是否包含动作指令
                        if any(word in line.lower() for word in ['grasp', 'place', 'move', 'put', '取', '放', '抓取', '放置', '移动']):
                            # 进一步检查是否是步骤
                            if 'step' in line.lower() or line[0].isdigit() or '第' in line:
                                step_lines.append(line)
                if step_lines:
                    result["steps"] = step_lines
                    print(f"✅ 从文本中提取步骤: {step_lines}")
            
            # 4. 提取action
            action_match = re.search(r'<action>(.*?)</action>', cleaned_text, re.DOTALL)
            if action_match:
                result["action"] = action_match.group(1).strip()
                print(f"✅ 成功提取action: {result['action']}")
            
            # 5. 提取thinking
            thinking_match = re.search(r'<thinking>(.*?)</thinking>', cleaned_text, re.DOTALL)
            if thinking_match:
                result["thinking"] = thinking_match.group(1).strip()
                print(f"✅ 成功提取thinking: {result['thinking'][:100]}...")
            
            # 6. 如果还没提取到plan，尝试从文本中提取计划描述
            if not result["plan"]:
                # 从文本中提取可能的计划描述
                lines = cleaned_text.split('\n')
                plan_lines = []
                for line in lines:
                    line = line.strip()
                    if line and len(line) > 10:
                        # 检查是否包含任务描述或步骤
                        if any(word in line.lower() for word in ['grasp', 'place', 'move', 'put', '取', '放', '第', '步骤']):
                            plan_lines.append(line)
                if plan_lines:
                    result["plan"] = '\n'.join(plan_lines[:3])
                    print(f"✅ 从文本中提取计划: {result['plan'][:100]}...")
                    
        except Exception as e:
            print(f"❌ 解析过程中出错: {e}")
            import traceback
            traceback.print_exc()
        
        print(f"最终解析结果:")
        print(f"  thinking长度: {len(result['thinking'])}")
        print(f"  plan长度: {len(result['plan'])}")
        print(f"  steps数量: {len(result['steps'])}")
        print(f"  action: '{result['action']}'")
        print("🔍 PlanningTool解析结束")
        
        return result
    
    def _save_planning_result(self, task_description: str, raw_result: Dict, parsed_result: Dict, image_path: str):
        """保存规划结果到JSON文件"""
        try:
            # 构造要保存的结构
            plan_result = {
                "task": task_description,
                "timestamp": datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
                "plan": parsed_result.get("plan", ""),
                "steps": parsed_result.get("steps", []),
                "action": parsed_result.get("action", ""),
                "thinking": raw_result.get("thinking", ""),
                "image_path": image_path
            }

            # 保存为 JSON
            os.makedirs("result/planning_results", exist_ok=True)
            filename = f"result/planning_results/planning_result_{plan_result['timestamp']}.json"
            with open(filename, 'w', encoding='utf-8') as f:
                import json
                json.dump(plan_result, f, ensure_ascii=False, indent=2)

            print(f"✅ Planning 结果已保存到: {filename}")
        except Exception as e:
            print(f"❌ 保存Planning结果时出错: {e}")
