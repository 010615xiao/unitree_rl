"""
Browser Use Answer Tool for RoboBrain Tool System
This tool wraps the browser-use library to enable web browsing for answering questions.
"""

import asyncio
import os
import tempfile
from typing import Dict, Any, Optional
from pathlib import Path
import logging
from .base_tool import BaseTool
from browser_use import Agent, Browser, ChatBrowserUse
from prompts import BROWSER_USE_PROMPT


class BrowserUseTool(BaseTool):
    """Tool for browser automation to answer questions using browser-use library"""
    
    def __init__(self):
        super().__init__(
            name="browser_use_answer",
            description="Browser automation tool that can search the web and extract answers to questions."
        )
        self.logger = logging.getLogger(__name__)
        
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute browser automation task to answer questions
        
        Args:
            task: The question or task description for the browser agent
            max_steps: Maximum number of steps for the agent (default: 20)
            model: LLM model to use (default: "deepseek-r1:14b")
            headless: Whether to run browser in headless mode (default: True)
            user_data_dir: Directory for browser profile (optional)
            
        Returns:
            Dict with browser automation results including answer
        """
        try:
            # Extract parameters
            task = kwargs.get('task', '')
            max_steps = kwargs.get('max_steps', 20)
            model = kwargs.get('model', 'deepseek-r1:14b')
            headless = kwargs.get('headless', True)
            user_data_dir = kwargs.get('user_data_dir', None)
            
            self.logger.info(f"🚀 Starting browser question answering task: {task}")
            
            # Configure browser exactly like in browser_use_decision.py
            # Use the same approach as in the original implementation
            playwright_chromium = Path.home() / ".cache/ms-playwright"
            chromium_dirs = list(playwright_chromium.glob("chromium-*/chrome-linux/chrome"))
            chromium_path = str(chromium_dirs[0]) if chromium_dirs else None
            
            # Create browser exactly like in the original implementation
            browser = Browser(
                headless=headless,
                enable_default_extensions=False,  # Consistent with original
                executable_path=chromium_path,
            )
            
            # 使用新的prompt
            question_prompt = BROWSER_USE_PROMPT.format(task=task)
            
            # Create agent with task - consistent with original implementation
            agent = Agent(
                task=question_prompt,
                llm=ChatBrowserUse(),
                browser=browser,
                step_timeout=180,
            )
            
            # Run the agent
            self.logger.info(f"🤖 Running browser agent with {max_steps} maximum steps...")
            history = await agent.run(max_steps=max_steps)
            
            # Get final result
            final_result = history.final_result()
            
            # 验证是否确实得到了结果
            if not final_result or not isinstance(final_result, str) or len(final_result.strip()) < 5:
                self.logger.warning("⚠️ Browser automation completed but got empty or invalid result")
                # 尝试获取历史记录中的最后一条信息
                if history.history:
                    last_item = history.history[-1]
                    if hasattr(last_item, 'message') and last_item.message:
                        final_result = str(last_item.message)
                        self.logger.info("🔍 Using last history message as result")
            
            # Close browser properly - use the correct method
            # The browser object returned by Browser() is a BrowserSession
            # We need to close it using its stop() method
            await browser.stop()
            
            # 验证结果是否有效
            if not final_result or not isinstance(final_result, str) or len(final_result.strip()) < 5:
                self.logger.error("❌ Browser automation completed but no valid result obtained")
                return {
                    "success": False,
                    "tool": "browser_use_answer",
                    "error": "Browser automation completed but no valid result obtained",
                    "task": task,
                    "steps_taken": len(history.history)
                }
            
            self.logger.info("✅ Browser automation completed successfully")
            
            return {
                "success": True,
                "tool": "browser_use_answer",
                "task": task,
                "result": final_result,
                "steps_taken": len(history.history),
                # "final_answer": final_result  # Explicitly return the answer
            }
            
        except Exception as e:
            error_msg = str(e)
            self.logger.error(f"❌ Browser use answer tool failed: {error_msg}")
            return {
                "success": False,
                "tool": "browser_use_answer",
                "error": error_msg,
                "task": kwargs.get('task', '')
            }            

