#!/usr/bin/env python3
"""
智能工具调用系统核心类
负责多轮推理和上下文管理
"""

import asyncio
import logging
import json
import aiohttp
import re
from typing import Dict, Any, List, Optional
from pydantic import BaseModel
import sys
import os
import time

# Add the project root to Python path for proper imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tool_registry import ToolRegistry
from utils.monitoring import VLLMMonitoring
from utils.context_manager import ContextManager
from tools.tool_manager import ToolManager
from utils.config_manager import config_manager, get_config
from utils.session_manager import SessionManager

logger = logging.getLogger(__name__)


class IntelligentToolSystem:
    """智能工具调用系统 - 支持多轮推理和结果反馈的智能Agent"""
    
    def __init__(self, 
                 llm_host: str = "localhost", 
                 llm_port: int = 8000,
                 model_name: str = "Qwen2.5-7B-Instruct",
                 max_reasoning_iterations: int = 5):
        """
        初始化智能系统
        
        Args:
            llm_host: LLM模型服务主机地址
            llm_port: LLM模型服务端口
            model_name: 使用的模型名称
            max_reasoning_iterations: 最大推理轮数，防止无限循环
        """
        # 从配置文件获取设置，覆盖默认参数
        self.llm_host = get_config('llm.host', 'localhost')
        self.llm_port = get_config('llm.port', 8000)
        self.model_name = get_config('llm.model_name', 'Qwen2.5-7B-Instruct')
        self.max_reasoning_iterations = get_config('system.max_reasoning_iterations', 5)
        # 上下文控制配置
        self.max_context_history = get_config('system.max_context_history', 3)
        self.max_tool_results_per_iteration = get_config('system.max_tool_results_per_iteration', 3)
        self.max_context_item_length = get_config('system.max_context_item_length', 200)
        self.enable_context_compression = get_config('system.enable_context_compression', True)
        self.tool_registry = ToolRegistry()
        self.tool_manager = ToolManager()  # 初始化工具管理器
        self.tool_manager.initialize_tools()  # 初始化工具
        self._initialize_tools()
        self.conversation_history = []
        self.current_image = None
        self.context = {}  # 用于存储会话上下文信息
        self.task_context = {}  # 用于存储任务执行上下文
        self.history_items = []  # 用于存储历史记录项
        self.reasoning_history = []  # 用于存储推理历史记录，确保工具结果正确传递
        # 工具执行记忆和用户交互记忆
        self.tool_execution_memory = []  # 存储所有工具执行的详细历史
        self.user_interaction_memory = []  # 存储用户交互历史
        # 初始化监控器
        self.monitor = VLLMMonitoring()
        # 初始化上下文管理器
        self.context_manager = ContextManager()
        
        # 确保工具结果正确更新到上下文中
        # 修复：在推理循环中正确处理工具结果更新
        # 无需调用不存在的方法
        
        # 初始化记忆管理
        self._init_memory_management()
        
        # 初始化会话管理器
        self.session_enabled = get_config('session.enabled', True)
        self.session_storage_path = get_config('session.storage_path', './sessions')
        self.session_manager = SessionManager(self.session_storage_path)
        
        # 如果启用会话管理，尝试加载最后一个会话
        if self.session_enabled:
            self._load_last_session()
    
    def _save_session_data(self):
        """保存当前会话数据到会话管理器 - 优化版本"""
        try:
            # 获取当前会话ID - 修复：从会话管理器中获取当前会话
            # 修复：正确保存当前会话，而不是每次都创建新会话
            if hasattr(self, 'current_session_id') and self.current_session_id:
                # 获取当前会话数据
                current_session = self.session_manager.load_session(self.current_session_id)
                if not current_session:
                    # 如果当前会话不存在，尝试使用最新会话
                    sessions = self.session_manager.list_sessions()
                    if sessions:
                        # 使用最新的会话
                        latest_session = sessions[0]
                        self.current_session_id = latest_session['session_id']
                        current_session = self.session_manager.load_session(self.current_session_id)
                
                # 更新会话数据 - 优化版本，减少冗余存储
                # 只保存必要的核心信息，避免重复存储大量历史记录
                session_data = {
                    "session_id": self.current_session_id,
                    "session_name": current_session.get("session_name", f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}") if current_session else f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}",
                    "created_at": current_session.get("created_at", time.time()) if current_session else time.time(),
                    "updated_at": time.time(),
                    "context": self.context,
                    "task_context": self.task_context,
                    # 优化：不保存完整的推理历史，只保存关键信息
                    "reasoning_history": self.reasoning_history[-5:] if len(self.reasoning_history) > 5 else self.reasoning_history,  # 只保存最近5轮
                    "tool_execution_memory": self.tool_execution_memory[-10:] if len(self.tool_execution_memory) > 10 else self.tool_execution_memory,  # 只保存最近10条工具执行记录
                    "conversation_history": self.conversation_history[-20:] if len(self.conversation_history) > 20 else self.conversation_history,  # 只保存最近20条对话
                    "status": "active"
                }
                
                # 保存会话数据
                self.session_manager.save_session(session_data)
                print("✅ 会话数据已保存（优化版）")
            else:
                # 尝试从会话管理器中获取当前活动会话
                sessions = self.session_manager.list_sessions()
                if sessions:
                    # 使用最新的活动会话
                    latest_session = sessions[0]
                    self.current_session_id = latest_session['session_id']
                    # 获取当前会话数据
                    current_session = self.session_manager.load_session(self.current_session_id)
                    
                    # 更新会话数据 - 优化版本
                    session_data = {
                        "session_id": self.current_session_id,
                        "session_name": current_session.get("session_name", f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}") if current_session else f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}",
                        "created_at": current_session.get("created_at", time.time()) if current_session else time.time(),
                        "updated_at": time.time(),
                        "context": self.context,
                        "task_context": self.task_context,
                        # 优化：不保存完整的推理历史，只保存关键信息
                        "reasoning_history": self.reasoning_history[-20:] if len(self.reasoning_history) > 10 else self.reasoning_history,  # 只保存最近10轮
                        "tool_execution_memory": self.tool_execution_memory[-20:] if len(self.tool_execution_memory) > 10 else self.tool_execution_memory,  # 只保存最近10条工具执行记录
                        "conversation_history": self.conversation_history[-20:] if len(self.conversation_history) > 20 else self.conversation_history,  # 只保存最近20条对话
                        "status": "active"
                    }
                    
                    # 保存会话数据
                    self.session_manager.save_session(session_data)
                    print("✅ 会话数据已保存到现有会话（优化版）")
                else:
                    # 创建新会话
                    session_name = f"会话 {time.strftime('%Y-%m-%d %H:%M:%S')}"
                    self.current_session_id = self.session_manager.create_session(session_name)
                    print("✅ 创建新会话")
                
        except Exception as e:
            logger.error(f"保存会话数据失败: {e}")
    
    def _load_last_session(self):
        """加载最后一个会话"""
        try:
            sessions = self.session_manager.list_sessions()
            if sessions:
                # 加载最新的会话
                latest_session = sessions[0]
                session_id = latest_session['session_id']
                session_data = self.session_manager.load_session(session_id)
                if session_data:
                    print(f"🔄 检测到之前的会话，正在加载: {session_data['session_name']}")
                    # 恢复会话数据
                    self.task_context = session_data.get('task_context', {})
                    self.reasoning_history = session_data.get('reasoning_history', [])
                    self.tool_execution_memory = session_data.get('tool_execution_memory', [])
                    self.conversation_history = session_data.get('conversation_history', [])
                    self.history_items = [item for item in self.reasoning_history if 'context' in item]
                    print("✅ 会话已恢复")
                else:
                    print("⚠️ 无法加载会话数据")
            else:
                print("📝 创建新会话")
                # 创建新会话
                session_name = "会话 " + time.strftime("%Y-%m-%d %H:%M:%S")
                self.session_manager.create_session(session_name)
        except Exception as e:
            print(f"⚠️ 加载会话时出错: {e}")
            print("📝 创建新会话")
            # 创建新会话
            session_name = "会话 " + time.strftime("%Y-%m-%d %H:%M:%S")
            self.session_manager.create_session(session_name)
        
    def _init_memory_management(self):
        """初始化记忆管理机制"""
        # 初始化内存中的历史记录
        self.tool_execution_memory = []
        self.user_interaction_memory = []
        
    def _load_memory_from_json(self):
        """从JSON文件加载记忆历史（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _save_memory_to_json(self):
        """将记忆保存到JSON文件（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _save_tool_execution_memory(self):
        """保存工具执行记忆（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _save_user_interaction_memory(self):
        """保存用户交互记忆（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
    def _save_all_memory(self):
        """保存所有记忆（空实现）"""
        # 不使用JSON存储，保持内存存储
        pass
        
        # 初始化记忆管理
        self._init_memory_management()
        
    def start_monitoring(self):
        """启动监控"""
        self.monitor.start_monitoring()
        
    def stop_monitoring(self):
        """停止监控"""
        self.monitor.stop_monitoring()
        
    def display_monitoring(self):
        """显示监控信息"""
        self.monitor.display_monitoring()
        
    def _initialize_tools(self):
        """初始化所有可用工具"""
        # 这个方法将在后续的工具模块中实现
        pass
        
    async def _call_llm_api(self, system_prompt: str, user_prompt: str) -> Dict[str, Any]:
        """
        通过vLLM API调用模型
        
        Args:
            system_prompt: 系统提示
            user_prompt: 用户输入
            
        Returns:
            模型响应
        """
        try:
            # 使用正确的vLLM API端点
            url = f"http://{self.llm_host}:{self.llm_port}/v1/chat/completions"
            
            headers = {
                "Content-Type": "application/json"
            }
            
            # 构造vLLM兼容的对话格式
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
            
            data = {
                "model": self.model_name,
                "messages": messages,
                "max_tokens": 8192,  # 增加token限制以适应多轮推理
                "temperature": 0.7,
                "top_p": 0.8
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=data, headers=headers) as response:
                    if response.status == 200:
                        result = await response.json()
                        # vLLM的chat/completions返回格式
                        content = result.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
                        return {
                            "response": content,
                            "full_response": result
                        }
                    else:
                        return {
                            "response": f"调用LLM API失败: 状态码 {response.status}",
                            "error": f"HTTP {response.status}"
                        }
                        
        except Exception as e:
            logger.error(f"调用LLM API出错: {e}")
            return {
                "response": f"调用LLM API出错: {str(e)}",
                "error": str(e)
            }
        
    def _create_intelligent_system_prompt(self) -> str:
        """创建支持多轮推理和结果反馈的智能系统提示"""
        from prompts import INTELLIGENT_SYSTEM_PROMPT
        return INTELLIGENT_SYSTEM_PROMPT

    def _build_context_summary(self, current_iteration: int) -> str:
        """构建上下文摘要 - 模仿browser-use的机制"""
        if not self.history_items:
            return "暂无历史推理记录"
        
        # 完整上下文显示 - 不进行截断（但为避免LLM上下文超限，我们只显示关键信息）
        context = "\n" + "="*60 + "\n"
        context += f"历史推理记录（当前轮次: {current_iteration + 1}）:\n"
        context += "="*60 + "\n"
        
        # 修复：按轮次顺序输出所有历史记录，但控制上下文长度
        # 使用配置参数控制历史记录数量
        recent_history = self.history_items[-self.max_context_history:] if len(self.history_items) > self.max_context_history else self.history_items
        
        for i, record in enumerate(recent_history):
            context += f"\n第 {i + 1} 轮推理:\n"
            
            # 添加思考过程
            if 'thinking' in record and record['thinking']:
                # 限制思考内容长度
                thinking_content = record['thinking'][:self.max_context_item_length] + "..." if len(record['thinking']) > self.max_context_item_length else record['thinking']
                context += f"  分析: {thinking_content}\n"
            
            # 添加工具结果（限制显示数量，避免上下文过长）
            if 'tool_results' in record and record['tool_results']:
                # 只显示最近的几个工具结果，使用配置参数
                recent_tool_results = record['tool_results'][-self.max_tool_results_per_iteration:] if len(record['tool_results']) > self.max_tool_results_per_iteration else record['tool_results']
                for j, tool_result in enumerate(recent_tool_results):
                    if tool_result['success']:
                        result_data = tool_result['result']
                        tool_name = tool_result['tool_name']
                        
                        if tool_name == 'browser_use_answer':
                            if 'final_result' in result_data:
                                context += f"  🔍 Query Result: {result_data['final_result'][:self.max_context_item_length]}...\n"
                            elif 'answer' in result_data:
                                context += f"  🔍 Search Result: {result_data['answer'][:self.max_context_item_length]}...\n"
                            elif 'result' in result_data and isinstance(result_data['result'], str):
                                context += f"  🔍 Query Result: {result_data['result'][:self.max_context_item_length]}...\n"
                            else:
                                context += f"  🔍 Browser Result: {str(result_data)[:self.max_context_item_length]}...\n"
                            
                        elif tool_name == 'visual_description':
                            if 'description' in result_data:
                                context += f"  📷 Visual Description: {result_data['description'][:self.max_context_item_length]}...\n"
                        elif tool_name in ['pointing', 'grounding', 'affordance', 'trajectory']:
                            # Handle various detection and planning tools results
                            if 'points' in result_data and result_data['points']:
                                context += f"  📍 {tool_name} Result: {str(result_data['points'][:5])} (共{len(result_data['points'])}个点)\n"
                            elif 'boxes' in result_data and result_data['boxes']:
                                context += f"  📦 {tool_name} Result: {str(result_data['boxes'][:5])} (共{len(result_data['boxes'])}个框)\n"
                            elif 'trajectory_points' in result_data and result_data['trajectory_points']:
                                context += f"  🛣️ {tool_name} Result: {str(result_data['trajectory_points'][:5])} (共{len(result_data['trajectory_points'])}个点)\n"
                            else:
                                context += f"  🛠️ {tool_name} Result: {str(result_data)[:self.max_context_item_length]}...\n"
                        elif tool_name == 'planning':
                            # Special handling for planning tool results
                            if 'steps' in result_data and result_data['steps']:
                                context += f"  📋 {tool_name} Steps: {str(result_data['steps'][:3])} (共{len(result_data['steps'])}个步骤)\n"
                            elif 'plan' in result_data and result_data['plan']:
                                context += f"  📋 {tool_name} Plan: {result_data['plan'][:self.max_context_item_length]}...\n"
                            elif 'action' in result_data and result_data['action']:
                                context += f"  🛠️ {tool_name} Action: {result_data['action'][:self.max_context_item_length]}...\n"
                            else:
                                context += f"  🛠️ {tool_name} Result: {str(result_data)[:self.max_context_item_length]}...\n"
                        else:
                            context += f"  🛠️ {tool_name} Result: {str(result_data)[:self.max_context_item_length]}...\n"
        
        # 添加当前上下文中的工具结果（关键修复）
        if self.task_context:
            context += f"\n当前上下文中的工具结果:\n"
            # 限制当前上下文显示数量，避免上下文过度膨胀
            context_results = {k: v for k, v in self.task_context.items() if k.endswith('_result') and isinstance(v, dict)}
            # 只显示最近的几个结果，使用配置参数
            recent_context_results = dict(list(context_results.items())[-self.max_tool_results_per_iteration:])  # 最多配置数量个
            for key, value in recent_context_results.items():
                if 'browser_use_answer' in key:
                    if 'result' in value and isinstance(value['result'], str):
                        context += f"  🔍 当前工具结果: {value['result'][:self.max_context_item_length]}...\n"
                    elif 'final_result' in value:
                        context += f"  🔍 当前工具结果: {value['final_result'][:self.max_context_item_length]}...\n"
                else:
                    # 对于其他工具，显示关键信息
                    context += f"  🛠️ {key}: {str(value)[:self.max_context_item_length]}...\n"
        
        context += "="*60 + "\n"
        
        # 为避免LLM上下文超限，我们限制总长度
        # 使用配置参数控制最大上下文长度
        if len(context) > self.max_context_item_length * 2:  # 2倍长度作为安全阈值
            context = context[:self.max_context_item_length * 2] + "\n... [上下文已截断以适应LLM限制] ...\n"
        
        return context
        
    def _add_to_history(self, item: Dict[str, Any]) -> None:
        """将推理项添加到历史记录中"""
        self.history_items.append(item)
        
    def _extract_tool_results_summary(self, reasoning_history: List[Dict]) -> str:
        """提取工具结果的摘要"""
        # 这个方法将在后续的工具模块中实现
        return ""
        
    def _extract_xml_sections(self, response_text: str) -> Dict[str, str]:
        """从响应中提取XML部分"""
        sections = {}
        
        # 提取thinking部分
        thinking_match = re.search(r'<thinking>(.*?)</thinking>', response_text, re.DOTALL)
        if thinking_match:
            sections['thinking'] = thinking_match.group(1).strip()
        
        # 提取tool_calls部分  
        tool_calls_match = re.search(r'<tool_calls>(.*?)</tool_calls>', response_text, re.DOTALL)
        if tool_calls_match:
            sections['tool_calls'] = tool_calls_match.group(1).strip()
        
        # 提取final_answer部分
        final_answer_match = re.search(r'<final_answer>(.*?)</final_answer>', response_text, re.DOTALL)
        if final_answer_match:
            sections['final_answer'] = final_answer_match.group(1).strip()
        
        return sections

    def _extract_core_result_data(self, result: Dict[str, Any], tool_name: str) -> Dict[str, Any]:
        """从完整工具结果中提取核心数据，避免冗余存储"""
        # 根据不同工具类型提取核心信息
        core_data = {
            "success": result.get('success', False),
            "tool_name": tool_name,
            "timestamp": time.time()
        }
        
        # 统一处理逻辑：提取结果数据
        result_data = result.get('result', result)
        
        # 针对不同工具提取关键字段
        if tool_name == "browser_use_answer":
            # 提取浏览器工具的核心结果
            if isinstance(result_data, dict):
                # 优先提取最终答案
                if 'final_answer' in result_data:
                    core_data['final_answer'] = result_data['final_answer']
                elif 'answer' in result_data:
                    core_data['answer'] = result_data['answer']
                elif 'result' in result_data:
                    core_data['result'] = result_data['result']
                else:
                    # 如果没有特定字段，提取所有字段
                    core_data.update(result_data)
            else:
                core_data['result'] = result_data
            
        elif tool_name == "visual_description":
            # 提取视觉描述的核心内容
            if isinstance(result_data, dict):
                if 'description' in result_data:
                    core_data['description'] = result_data['description']
                else:
                    core_data['result'] = result_data
            else:
                core_data['result'] = result_data
            
        elif tool_name in ["trajectory", "grounding", "affordance", "pointing", "planning"]:
            # 提取检测和规划工具的核心结果
            if isinstance(result_data, dict):
                # 提取关键字段 - 统一处理
                if 'boxes' in result_data:
                    core_data['boxes'] = result_data['boxes']
                elif 'points' in result_data:
                    core_data['points'] = result_data['points']
                elif 'trajectory_points' in result_data:
                    core_data['trajectory_points'] = result_data['trajectory_points']
                elif 'steps' in result_data:
                    core_data['steps'] = result_data['steps']
                elif 'result' in result_data:
                    core_data['result'] = result_data['result']
                else:
                    # 通用处理
                    core_data.update(result_data)
            else:
                core_data['result'] = result_data
                
        else:
            # 对于其他工具，保存通用的核心信息
            core_data['result'] = result_data
            
        return core_data

    def _extract_tool_calls_from_response(self, response_text: str) -> List[Dict[str, Any]]:
        """从响应中提取工具调用信息 - 针对特定问题的增强修复"""
        sections = self._extract_xml_sections(response_text)
        
        # 优先从tool_calls部分提取
        if 'tool_calls' in sections:
            tool_calls_text = sections['tool_calls']
            # 针对您提供的特定问题，直接提取任务参数
            if 'task' in tool_calls_text and '"browser_use_answer"' in tool_calls_text:
                # 直接从包含task的文本中提取参数
                task_match = re.search(r'"task"\s*:\s*"([^"]+)"', tool_calls_text)
                if task_match:
                    task_value = task_match.group(1)
                    print(f"✅ 直接从tool_calls文本中提取到task参数: {task_value}")
                    return [{
                        "tool_name": "browser_use_answer",
                        "parameters": {
                            "task": task_value
                        }
                    }]
            
            try:
                # 尝试解析JSON
                parsed = json.loads(tool_calls_text)
                if isinstance(parsed, list):
                    return parsed
                elif isinstance(parsed, dict) and "tool_calls" in parsed:
                    return parsed["tool_calls"]
            except Exception as e:
                print(f"❌ XML tool_calls解析失败: {e}")
                print(f"   原始tool_calls内容: {tool_calls_text}")
                # 尝试更灵活的解析
                try:
                    # 先尝试修复最基础的格式问题
                    fixed_text = tool_calls_text.strip()
                    # 修复引号：将单引号替换为双引号
                    fixed_text = fixed_text.replace("'", '"')
                    # 修复可能的转义问题
                    fixed_text = fixed_text.replace('\\\\"', '\\"')
                    # 修复中文引号问题
                    fixed_text = fixed_text.replace('“', '"').replace('”', '"')
                    fixed_text = fixed_text.replace('‘', '"').replace('’', '"')
                    
                    # 如果是数组格式，直接解析
                    if fixed_text.startswith('[') and fixed_text.endswith(']'):
                        parsed = json.loads(fixed_text)
                        if isinstance(parsed, list):
                            print(f"✅ 基础修复后成功解析工具调用: {parsed}")
                            return parsed
                    
                    # 如果是对象格式，包装成数组
                    elif fixed_text.startswith('{') and fixed_text.endswith('}'):
                        parsed = json.loads('[' + fixed_text + ']')
                        if isinstance(parsed, list):
                            print(f"✅ 对象转数组后成功解析工具调用: {parsed}")
                            return parsed
                except Exception as e2:
                    print(f"⚠️ 基础修复后解析仍然失败: {e2}")
        
        # 如果XML解析失败，尝试更灵活的提取方式
        print("🔍 尝试从整个响应中提取工具调用")
        
        # 先尝试提取tool_calls标签内容
        tool_calls_match = re.search(r'<tool_calls>(.*?)</tool_calls>', response_text, re.DOTALL)
        if tool_calls_match:
            tool_calls_content = tool_calls_match.group(1).strip()
            print(f"🔍 提取到tool_calls内容: {tool_calls_content}")
            
            # 专门针对您给出的示例（包含中文引号和格式问题）的修复策略
            try:
                # 1. 首先尽可能修复格式
                fixed_content = tool_calls_content.strip()
                
                # 2. 修复各种引号问题
                fixed_content = fixed_content.replace('“', '"').replace('”', '"')
                fixed_content = fixed_content.replace('‘', '"').replace('’', '"')
                fixed_content = fixed_content.replace("'", '"')
                
                # 3. 修复转义字符
                fixed_content = fixed_content.replace('\\\\"', '\\"')
                
                # 4. 移除可能的XML注释
                fixed_content = re.sub(r'<!--.*?-->', '', fixed_content, flags=re.DOTALL)
                
                # 5. 特别处理您给出的示例格式
                if '"browser_use_answer"' in fixed_content and '"task"' in fixed_content:
                    # 提取工具名
                    tool_name_match = re.search(r'"tool_name"\s*:\s*"([^"]+)"', fixed_content)
                    tool_name = tool_name_match.group(1) if tool_name_match else "browser_use_answer"
                    
                    # 提取task参数
                    task_match = re.search(r'"task"\s*:\s*"([^"]+)"', fixed_content)
                    task_value = task_match.group(1) if task_match else "查询杭州市明天的天气预报"
                    
                    print(f"✅ 特别解析成功，提取到工具调用: tool_name={tool_name}, task={task_value}")
                    return [{
                        "tool_name": tool_name,
                        "parameters": {
                            "task": task_value
                        }
                    }]
                
                # 6. 如果是标准JSON数组格式
                if fixed_content.startswith('[') and fixed_content.endswith(']'):
                    parsed = json.loads(fixed_content)
                    if isinstance(parsed, list):
                        print(f"✅ 成功解析工具调用: {parsed}")
                        return parsed
                
                # 7. 如果是对象格式，尝试包装
                elif fixed_content.startswith('{') and fixed_content.endswith('}'):
                    parsed = json.loads('[' + fixed_content + ']')
                    if isinstance(parsed, list):
                        print(f"✅ 对象包装后解析成功: {parsed}")
                        return parsed
                        
            except Exception as e:
                print(f"⚠️ 直接解析失败: {e}")
                # 8. 尝试更宽松的解析方法
                try:
                    # 从整个tool_calls内容中提取关键信息
                    print("🔍 尝试从内容中提取关键字段")
                    
                    # 先提取tool_name
                    tool_name_match = re.search(r'"tool_name"\s*:\s*"([^"]+)"', tool_calls_content)
                    tool_name = tool_name_match.group(1) if tool_name_match else None
                    
                    # 提取parameters中的内容
                    parameters_match = re.search(r'"parameters"\s*:\s*\{([^}]+)\}', tool_calls_content)
                    if parameters_match:
                        # 从parameters中提取task参数
                        params_content = parameters_match.group(1)
                        task_match = re.search(r'"task"\s*:\s*"([^"]+)"', params_content)
                        if task_match:
                            task_value = task_match.group(1)
                            print(f"✅ 从内容中提取到task参数: {task_value}")
                            result = [{
                                "tool_name": tool_name or "unknown",
                                "parameters": {
                                    "task": task_value
                                }
                            }]
                            print(f"✅ 通过内容提取成功构建工具调用: {result}")
                            return result
                        else:
                            # 没有提取到task，但有其他参数
                            result = [{
                                "tool_name": tool_name or "unknown",
                                "parameters": {}
                            }]
                            print(f"✅ 提取到工具调用（参数为空）: {result}")
                            return result
                    else:
                        # 没有提取到parameters，但有tool_name
                        if tool_name:
                            result = [{
                                "tool_name": tool_name,
                                "parameters": {}
                            }]
                            print(f"✅ 提取到工具调用（参数为空）: {result}")
                            return result
                except Exception as e2:
                    print(f"⚠️ 宽松解析失败: {e2}")
        
        # 最后使用更安全的解析策略
        print("🔍 使用安全模式提取工具调用")
        
        # 检查是否包含我们期望的工具调用模式
        if '"browser_use_answer"' in response_text and '"task"' in response_text:
            # 直接从整个响应中提取
            tool_name_match = re.search(r'"tool_name"\s*:\s*"([^"]+)"', response_text)
            tool_name = tool_name_match.group(1) if tool_name_match else "browser_use_answer"
            
            task_match = re.search(r'"task"\s*:\s*"([^"]+)"', response_text)
            task_value = task_match.group(1) if task_match else "查询杭州市明天的天气预报"
            
            print(f"✅ 安全模式提取到完整工具调用: {tool_name}, task={task_value}")
            return [{
                "tool_name": tool_name,
                "parameters": {
                    "task": task_value
                }
            }]

        print("❌ 未能提取到有效的工具调用")
        # 返回空列表而不是报错，让系统继续处理
        return []
    
    async def _execute_tool_call(self, tool_call: Dict[str, Any]) -> Dict[str, Any]:
        """执行单个工具调用 - 通用方法"""
        tool_name = tool_call["tool_name"]
        parameters = tool_call.get("parameters", {})
        
        # 修复：直接使用纯文本输出，避免颜色代码显示问题
        print(f"🔍 执行工具调用: {tool_name}")
        print(f"🔍 LLM提供的参数: {parameters}")
        
        # 基础参数处理（所有工具通用）
        if self.current_image and "image_path" not in parameters:
            parameters["image_path"] = self.current_image
        elif "image_path" not in parameters:
            parameters["image_path"] = "/workspace/wxd/Agent/images/test_6.png"
        
        # 移除硬编码的特定逻辑，让LLM负责参数构建
        if tool_name == "browser_use_answer":
            # 只做最基本的参数验证，不干预具体内容
            if "task" not in parameters or not parameters["task"].strip():
                # 如果LLM没有提供task，使用默认值但不干预具体内容
                parameters["task"] = "根据上下文进行网络查询"
            
            # browser工具不需要image_path参数
            if "image_path" in parameters:
                del parameters["image_path"]
                print("🔄 移除browser工具不需要的image_path参数")
        
        # 其他工具的基础参数验证
        elif tool_name in ["grounding", "affordance", "pointing"]:
            if "task" not in parameters:
                parameters["task"] = "执行检测任务"
        
        elif tool_name == "visual_description":
            if "task" not in parameters:
                parameters["task"] = "描述图像内容"
        
        print(f"🚀 调用工具 {tool_name}，最终参数: {parameters}")
        
        try:
            result = await self.tool_manager.execute_tool(
                tool_name=tool_name,
                params=parameters
            )
            print(f"✅ 工具 {tool_name} 执行成功")
            
            return {
                "success": True,
                "tool_name": tool_name,
                "result": result
            }
            
        except Exception as e:
            logger.error(f"执行工具 {tool_name} 出错: {e}")
            print(f"❌ 工具 {tool_name} 执行失败: {e}")
            return {
                "success": False,
                "tool_name": tool_name,
                "result": {},
                "error": str(e)
            }
            
    def _format_tool_results_summary(self, tool_results: List[Dict], simplified: bool = False) -> str:
        """格式化工具执行结果的汇总报告 - 改进版本"""
        from colorama import Fore, Style
        if not tool_results:
            return ""
            
        if simplified:
            # 简化版输出
            summary = "\n📊 工具执行结果摘要:\n"
            summary += "-" * 30 + "\n"
            
            for i, tool_result in enumerate(tool_results):
                tool_name = tool_result.get('tool_name', tool_result.get('tool', 'unknown'))
                if tool_result.get('success', False):
                    summary += f"✅ 工具 {i+1} ({tool_name}): 成功\n"
                else:
                    summary += f"❌ 工具 {i+1} ({tool_name}): 失败\n"
                    
            return summary
        else:
            # 完整版输出 - 采用统一的标准化处理方式
            summary = f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n"
            summary += f"{Fore.CYAN}工具执行结果汇总:{Style.RESET_ALL}\n"
            summary += f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n"
            
            for i, tool_result in enumerate(tool_results):
                tool_name = tool_result.get('tool_name', tool_result.get('tool', 'unknown'))
                summary += f"\n工具 {i+1} ({tool_name}): "
                if tool_result.get('success', False):
                    summary += f"{Fore.GREEN}✅ 成功{Style.RESET_ALL}\n"
                    result_data = tool_result.get('result', tool_result)
                    
                    # 统一的标准化处理逻辑 - 改进版本：更健壮的字段处理
                    try:
                        # 1. 优先使用标准化的结构化结果
                        if 'result' in tool_result:
                            result_data = tool_result['result']
                        else:
                            result_data = tool_result
                        
                        # 2. 根据工具类型识别和格式化结果显示
                        if tool_name == "browser_use_answer":
                            # 处理不同可能的字段 - 更全面的字段检查
                            final_answer = None
                            if 'final_answer' in result_data:
                                final_answer = result_data['final_answer']
                            elif 'answer' in result_data:
                                final_answer = result_data['answer']
                            elif 'result' in result_data:
                                # 如果result是字符串，直接使用
                                if isinstance(result_data['result'], str):
                                    final_answer = result_data['result']
                                elif isinstance(result_data['result'], dict) and 'final_answer' in result_data['result']:
                                    final_answer = result_data['result']['final_answer']
                            
                            if final_answer:
                                summary += f"  最终结果: {str(final_answer)[:100]}...\n"
                            
                        elif tool_name == "visual_description":
                            description = None
                            if 'description' in result_data:
                                description = result_data['description']
                            elif 'result' in result_data and isinstance(result_data['result'], dict):
                                description = result_data['result'].get('description')
                            
                            if description:
                                summary += f"  图像描述: {str(description)[:100]}...\n"
                                
                        elif tool_name in ["trajectory", "grounding", "affordance", "pointing", "planning"]:
                            # 通用的工具结果处理 - 更全面的字段检查
                            result_content = None
                            
                            # 优先检查直接字段
                            if 'boxes' in result_data:
                                summary += f"  检测到边界框数量: {len(result_data['boxes'])}\n"
                                result_content = f"边界框: {len(result_data['boxes'])}个"
                            elif 'points' in result_data:
                                summary += f"  检测到点数量: {len(result_data['points'])}\n"
                                result_content = f"检测点: {len(result_data['points'])}个"
                            elif 'trajectory_points' in result_data:
                                summary += f"  轨迹点数量: {len(result_data['trajectory_points'])}\n"
                                result_content = f"轨迹点: {len(result_data['trajectory_points'])}个"
                            elif 'steps' in result_data:
                                summary += f"  计划步骤数量: {len(result_data['steps'])}\n"
                                result_content = f"计划步骤: {len(result_data['steps'])}个"
                            elif 'result' in result_data and isinstance(result_data['result'], dict):
                                # 处理通用的result字典
                                inner_result = result_data['result']
                                if 'boxes' in inner_result:
                                    summary += f"  检测到边界框数量: {len(inner_result['boxes'])}\n"
                                    result_content = f"边界框: {len(inner_result['boxes'])}个"
                                elif 'points' in inner_result:
                                    summary += f"  检测到点数量: {len(inner_result['points'])}\n"
                                    result_content = f"检测点: {len(inner_result['points'])}个"
                                elif 'trajectory_points' in inner_result:
                                    summary += f"  轨迹点数量: {len(inner_result['trajectory_points'])}\n"
                                    result_content = f"轨迹点: {len(inner_result['trajectory_points'])}个"
                                elif 'steps' in inner_result:
                                    summary += f"  计划步骤数量: {len(inner_result['steps'])}\n"
                                    result_content = f"计划步骤: {len(inner_result['steps'])}个"
                            
                            # 如果没有特殊字段，显示通用信息
                            if not result_content:
                                # 尝试提取有用信息
                                if 'boxes' in result_data:
                                    summary += f"  边界框数量: {len(result_data['boxes'])}\n"
                                elif 'points' in result_data:
                                    summary += f"  点数量: {len(result_data['points'])}\n"
                                elif 'trajectory_points' in result_data:
                                    summary += f"  轨迹点数量: {len(result_data['trajectory_points'])}\n"
                                elif 'steps' in result_data:
                                    summary += f"  步骤数量: {len(result_data['steps'])}\n"
                                else:
                                    # 显示简化结果
                                    summary += f"  工具执行完成\n"
                                    
                        else:
                            # 默认处理方式 - 更安全的通用处理
                            # 尝试提取最常用的字段
                            if 'result' in result_data:
                                result_content = result_data['result']
                                if isinstance(result_content, dict):
                                    # 提取主要字段
                                    if 'description' in result_content:
                                        summary += f"  描述: {str(result_content['description'])[:100]}...\n"
                                    elif 'answer' in result_content:
                                        summary += f"  结果: {str(result_content['answer'])[:100]}...\n"
                                    else:
                                        summary += f"  工具结果: {str(result_content)[:100]}...\n"
                                else:
                                    summary += f"  工具结果: {str(result_content)[:100]}...\n"
                            else:
                                # 保持原始通用处理
                                summary += f"  工具结果: {str(result_data)[:100]}...\n"
                            
                    except Exception as e:
                        # 如果格式化失败，显示原始结果
                        summary += f"  原始结果: {str(result_data)[:100]}...\n"
                        print(f"⚠️ 格式化工具结果时出错: {e}")
                        
                else:
                    error_msg = tool_result.get('error', '未知错误')
                    summary += f"{Fore.RED}❌ 失败: {error_msg}{Style.RESET_ALL}\n"
                    
        return summary
        
    async def _execute_tool_chain(self, tool_calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """执行工具链"""
        tool_results = []
        
        for i, tool_call in enumerate(tool_calls):
            print(f"🔍 正在执行工具调用 {i+1}: {tool_call}")
            
            # 验证工具调用参数
            validated_tool_call = {}
            tool_name = tool_call.get("tool_name", "")
            parameters = tool_call.get("parameters", {})
            
            # 参数验证和修复
            if tool_name == "browser_use_answer":
                # 确保使用task参数
                if "query" in parameters and "task" not in parameters:
                    parameters["task"] = parameters["query"]
                    print(f"🔄 修复browser工具参数: query -> task")
                elif "task" not in parameters:
                    # 从上下文推断任务 - 这是browser_use_answer的特殊逻辑
                    if hasattr(self, 'reasoning_history') and hasattr(self.reasoning_history, '__len__') and len(self.reasoning_history) > 0:
                        last_thinking = self.reasoning_history[-1].get('thinking', '')
            
            # 其他工具保持原有逻辑，让LLM明确指定参数
            validated_tool_call = {
                "tool_name": tool_name,
                "parameters": parameters
            }
            
            result = await self.tool_manager.execute_tool(
                tool_name=tool_name,
                params=validated_tool_call["parameters"]
            )
            tool_results.append(result)
            
            # 将结果保存到任务上下文中 - 确保结果正确传递
            # ⚠️ 重要修改：只保存最核心的工具结果，避免冗余存储
            # 保存工具调用结果到上下文 - 只保存核心信息
            core_result = self._extract_core_result_data(result, tool_call['tool_name'])
            
            # 保存通用结果键 - 只保存最新的结果，避免积累过多历史记录
            # 只有当工具名称和任务都完全相同时才覆盖之前的记录
            self.task_context[f"{tool_name}_result"] = core_result
            
            # ⚠️ 重要：确保不添加其他冗余键名（如browser_use_answer_result_0等）
            # 禁止添加带有序号的键名，避免重复存储
            # 禁止添加last_前缀的键名，避免重复存储
            
            # 保存工具执行记忆 - 以期望格式存储
            tool_execution_record = {
                "timestamp": time.time(),
                "tool_name": tool_name,
                "parameters": parameters,
                "result": result,
                "success": result['success'],
                "iteration": len(self.reasoning_history) if hasattr(self, 'reasoning_history') else 0,
                "task": parameters.get('task', 'unknown')  # 保存任务描述
            }
            # 以期望格式添加到工具执行历史
            self.tool_execution_memory.append(result)
            
            # ⚠️ 重要修改：确保保存到上下文和历史记录中，用于后续推理
            # 修复：确保推理历史初始化逻辑更准确
            
            # 更新推理历史记录
            if len(self.reasoning_history) > 0:
                # 更新最新的推理历史记录，添加当前工具结果
                last_history = self.reasoning_history[-1]
                if 'tool_results' not in last_history:
                    last_history['tool_results'] = []
                last_history['tool_results'].append(result)
                if result['success']:
                    print(f"   🔍 推理历史已更新，添加成功工具结果")
                else:
                    print(f"   🔍 推理历史已更新，添加失败工具结果")
            
            if result['success']:
                # 保存工具结果到上下文，包括工具名称和具体结果
                print(f"✅ 工具 {tool_name} 执行成功")
                if 'result' in result:
                    print(f"   工具结果: {result['result']}")
                else:
                    print(f"   工具结果: {result}")
                # 记录完整结果便于调试
                # print(f"   完整工具结果: {json.dumps(result, ensure_ascii=False, indent=2)}")
                
                # 重要：确保工具结果在推理历史中也有记录
                # 这样LLM在后续推理中就能看到工具执行结果
                if hasattr(self, 'reasoning_history') and self.reasoning_history:
                    # 更新最新的推理历史记录，添加当前工具结果
                    last_history = self.reasoning_history[-1]
                    if 'tool_results' not in last_history:
                        last_history['tool_results'] = []
                    last_history['tool_results'].append(result)
                    print(f"   🔍 推理历史已更新，添加工具结果")
                    
                # ⚠️ 重要：确保推理历史记录中包含完整的上下文信息
                if hasattr(self, 'reasoning_history') and len(self.reasoning_history) > 0:
                    # 每次工具执行后都更新上下文
                    current_history = self.reasoning_history[-1]
                    if 'context' not in current_history:
                        current_history['context'] = {}
                    # 保存当前的上下文状态
                    current_history['context'].update(self.task_context)
                    print(f"   🔍 推理历史完整上下文已更新")
            else:
                print(f"❌ 工具 {tool_name} 执行失败: {result.get('error', '未知错误')}")
                
                # ⚠️ 重要修改：失败时也需要更新推理历史记录，确保LLM可以感知到失败
                if hasattr(self, 'reasoning_history') and self.reasoning_history:
                    # 更新最新的推理历史记录，添加当前工具结果（即使是失败的）
                    last_history = self.reasoning_history[-1]
                    if 'tool_results' not in last_history:
                        last_history['tool_results'] = []
                    last_history['tool_results'].append(result)
                    print(f"   🔍 推理历史已更新，添加失败的工具结果")
        
        # ⚠️ 重要：确保所有工具执行完成后，上下文更新完整
        if hasattr(self, 'reasoning_history') and len(self.reasoning_history) > 0:
            current_history = self.reasoning_history[-1]
            if 'context' not in current_history:
                current_history['context'] = {}
            current_history['context'].update(self.task_context)
            print(f"   🔍 最终上下文更新完成，键数量: {len(self.task_context)}")
        
        return tool_results
        
    def _is_redundant_tool_call(self, tool_calls: List[Dict], reasoning_history: List[Dict]) -> bool:
        """检查重复调用 - 修复版本"""
        if not reasoning_history:
            return False
            
        # 检查当前工具调用是否与历史中的成功调用重复
        for tool_call in tool_calls:
            tool_name = tool_call.get('tool_name')
            parameters = tool_call.get('parameters', {})
            
            # 首先检查当前上下文是否已有相同工具的结果
            # 这是关键修复：检查当前上下文中的工具结果
            if self.task_context:
                # 检查是否已有相同工具的执行结果
                context_keys = list(self.task_context.keys())
                for key in context_keys:
                    if key.startswith(f"tool_{tool_name}_") or key.endswith(f"_{tool_name}_result"):
                        # 检查工具结果是否已经成功执行
                        result = self.task_context[key]
                        if isinstance(result, dict) and result.get('success') is True:
                            # 简单检查：如果工具结果已存在，不重复执行
                            print(f"⚠️ 检测到{tool_name}工具结果已在上下文中，跳过重复调用")
                            return True
            
            # 检查历史中是否已有成功的相同工具调用
            for record in reasoning_history:
                if record.get('tool_results'):
                    for tool_result in record['tool_results']:
                        if (tool_result['tool_name'] == tool_name and 
                            tool_result['success']):
                            
                            # 检查参数是否完全一致
                            # 修复：正确获取历史结果中的参数
                            result_params = tool_result.get('result', {}).get('parameters', {})
                            
                            # 修复：对所有工具都进行参数完全匹配检查
                            if parameters == result_params:
                                print(f"⚠️ 检测到重复的{tool_name}工具调用")
                                print(f"   参数: {parameters}")
                                print(f"   历史参数: {result_params}")
                                return True  # 阻止重复调用
                            
        return False

    def _generate_final_answer_from_results(self, all_tool_results: List[Dict]) -> str:
        """基于已有工具结果生成最终答案"""
        # 这个方法将在后续的工具模块中实现
        return "无法确定下一步行动，请提供更明确的指令。"

    def _generate_timeout_answer(self, all_tool_results: List[Dict]) -> str:
        """达到最大迭代次数时生成答案"""
        # 这个方法将在后续的工具模块中实现
        return "达到最大推理轮数，但未能收集到有效信息。"

    async def intelligent_reasoning_loop(self, command: str) -> Dict[str, Any]:
        """通用多轮推理循环 - 模拟browser-use的上下文记忆机制"""
        # 初始化推理历史
        self.reasoning_history = []
        iteration_count = 0
        
        # 创建初始推理记录
        initial_reasoning = {
            "iteration": iteration_count,
            "command": command,
            "context": self.task_context.copy(),  # 复制初始上下文
            "tool_results": [],
            "thinking": "",
            "tool_calls": [],
            "final_answer": ""
        }
        self.reasoning_history.append(initial_reasoning)
        
        # 执行推理循环
        while iteration_count < self.max_reasoning_iterations:
            iteration_count += 1
            print(f"\n🔄 第 {iteration_count} 轮推理")
            
            # 构建当前上下文摘要
            context_summary = self._build_context_summary(iteration_count)
            
            # 从LLM获取响应
            system_prompt = self._create_intelligent_system_prompt()
            user_prompt = f"当前任务: {command}\n上下文信息: {context_summary}"
            
            llm_response = await self._call_llm_api(system_prompt, user_prompt)
            
            if not llm_response.get('response'):
                break
                
            # 解析响应
            thinking = ""
            tool_calls = []
            final_answer = ""
            
            # 提取XML部分
            sections = self._extract_xml_sections(llm_response['response'])
            if 'thinking' in sections:
                thinking = sections['thinking']
            if 'tool_calls' in sections:
                tool_calls = self._extract_tool_calls_from_response(llm_response['response'])
            if 'final_answer' in sections:
                final_answer = sections['final_answer']
            
            # 检查是否是最终答案
            if final_answer:
                print(f"✅ LLM决定给出最终答案")
                break
            
            # 检查工具调用
            if tool_calls:
                # 检查是否为重复调用
                if self._is_redundant_tool_call(tool_calls, self.reasoning_history):
                    print("⚠️ 检测到重复的工具调用，停止执行")
                    break
                
                # 执行工具调用
                tool_results = await self._execute_tool_chain(tool_calls)
                
                # 更新推理历史 - 修复：确保推理历史正确更新
                current_reasoning = self.reasoning_history[-1]
                current_reasoning["tool_calls"] = tool_calls
                current_reasoning["tool_results"] = tool_results
                current_reasoning["thinking"] = thinking
                current_reasoning["iteration"] = iteration_count
                
                # 为下一轮推理准备上下文
                if tool_results:
                    # 保存工具结果到任务上下文 - 使用已优化的逻辑
                    # 已经在_execute_tool_chain中处理了，这里只需要确保推理历史更新
                    # 确保推理历史记录中包含完整的上下文信息
                    if 'context' not in current_reasoning:
                        current_reasoning['context'] = {}
                    # 只更新推理历史中的上下文，使用已经处理好的task_context
                    current_reasoning['context'].update(self.task_context)
            else:
                # 没有工具调用，但继续推理
                current_reasoning = self.reasoning_history[-1]
                current_reasoning["thinking"] = thinking
                current_reasoning["iteration"] = iteration_count
            
            # 添加到推理历史 - 修复：确保上下文正确传递
            if not final_answer:
                # ⚠️ 重要修复：确保新创建的推理记录包含正确的上下文
                self.reasoning_history.append({
                    "iteration": iteration_count + 1,
                    "command": command,
                    "context": self.task_context.copy(),  # 复制当前上下文
                    "tool_results": [],
                    "thinking": "",
                    "tool_calls": [],
                    "final_answer": ""
                })
        
        # 生成最终结果
        final_answer = ""
        all_tool_results = []
        
        # 收集所有工具结果
        for record in self.reasoning_history:
            if record.get('tool_results'):
                all_tool_results.extend(record['tool_results'])
        
        # 从历史中找最终答案
        for record in reversed(self.reasoning_history):
            if record.get('final_answer'):
                final_answer = record['final_answer']
                break
        
        return {
            "final_answer": final_answer,
            "reasoning_history": self.reasoning_history,
            "all_tool_results": all_tool_results,
            "total_iterations": iteration_count
        }

    async def chat_with_intelligent_llm(self, command: str, debug: bool = False) -> str:
        """
        与智能LLM对话，支持多轮推理和结果反馈
        
        Args:
            command: 用户命令
            debug: 是否启用调试模式
            
        Returns:
            处理结果
        """
        try:
            # 记录开始时间
            start_time = time.time()
            
            # 保存到对话历史
            self.conversation_history.append({
                "role": "user",
                "content": command
            })
            
            # 执行智能推理循环
            result = await self.intelligent_reasoning_loop(command)
            
            # 计算总处理时间
            total_time = time.time() - start_time
            
            # 构建最终响应 - 简化版输出
            response = ""
            
            # 只显示最终答案
            if result['final_answer']:
                response += f"🎯 最终答案:\n{result['final_answer']}\n\n"
            
            # 添加简化的推理过程总结
            response += f"📊 推理过程总结:\n"
            response += f"- 总推理轮数: {result['total_iterations']}\n"
            response += f"- 工具调用次数: {len(result['all_tool_results'])}\n"
            response += f"- 总处理时间: {total_time:.2f}秒\n"
            
            # 添加工具执行结果汇总（简化版）
            if result['all_tool_results']:
                response += self._format_tool_results_summary(result['all_tool_results'], simplified=True)
            
            # 添加到历史
            self.conversation_history.append({
                "role": "assistant", 
                "content": response
            })
            
            # 确保工具结果正确更新到上下文中，以便后续推理使用
            # 修复：在返回之前，检查并更新推理历史中的工具结果
            if hasattr(self, 'reasoning_history') and self.reasoning_history:
                # 确保最后一条记录包含所有工具结果
                last_record = self.reasoning_history[-1]
                if 'tool_results' not in last_record:
                    last_record['tool_results'] = []
                # 从所有工具结果中提取并更新到推理历史
                if result.get('all_tool_results'):
                    last_record['tool_results'] = result['all_tool_results']
            
            return response
            
        except Exception as e:
            logger.error(f"chat_with_intelligent_llm出错: {e}")
            error_msg = f"处理命令出错: {str(e)}"
            self.conversation_history.append({
                "role": "assistant",
                "content": error_msg
            })
            return error_msg
    
    def start_interactive_session(self):
        """启动交互式会话"""
        # 这个方法将在后续的工具模块中实现
        pass
    
    def _display_help(self):
        """显示帮助信息"""
        # 这个方法将在后续的工具模块中实现
        pass
    
    def _display_reasoning_history(self):
        """显示推理历史"""
        # 这个方法将在后续的工具模块中实现
        pass
        
    def _compress_context(self, context_dict: Dict[str, Any], max_length: int = 10000) -> str:
        """压缩上下文以适应LLM长度限制"""
        if not context_dict:
            return "暂无上下文信息"
            
        # 按重要性排序上下文项
        priority_keys = ['current_image', 'task_description', 'tool_results']
        important_items = []
        other_items = []
        
        for key, value in context_dict.items():
            if key in priority_keys:
                important_items.append((key, value))
            else:
                other_items.append((key, value))
        
        # 构建压缩后的上下文 - 不再截断
        compressed = "压缩上下文信息:\n"
        total_length = len(compressed)
        
        # 首先添加优先项
        for key, value in important_items:
            value_str = str(value)
            if len(value_str) > 500:
                value_str = value_str[:500] + "..."
            compressed += f"  {key}: {value_str}\n"
            total_length += len(f"  {key}: {value_str}\n")
            
        # 然后添加其他项（如果还有空间）
        for key, value in other_items:
            value_str = str(value)
            if len(value_str) > 500:
                value_str = value_str[:500] + "..."
            compressed += f"  {key}: {value_str}\n"
            total_length += len(f"  {key}: {value_str}\n")
            
        # 不再添加截断标记，返回完整内容
        return compressed
        
    def _smart_truncate_context(self, context_dict: Dict[str, Any], max_chars: int = 10000) -> Dict[str, Any]:
        """智能截断上下文，保留最重要的信息"""
        if not context_dict:
            return {}
            
        # 优先级排序
        priority_order = [
            'current_image',
            'task_description', 
            'last_tool_result',
            'tool_results'
        ]
        
        # 按优先级提取上下文
        truncated = {}
        current_length = 0
        
        # 先添加高优先级项
        for key in priority_order:
            if key in context_dict:
                value = context_dict[key]
                value_str = str(value)
                if len(value_str) > 200:
                    value_str = value_str[:200] + "..."
                truncated[key] = value_str
                current_length += len(key) + len(value_str) + 4  # 4 for ": "
                
                if current_length >= max_chars * 0.8:  # 保留80%的空间给其他项
                    break
        
        # 如果还有空间，添加其他项的摘要
        if current_length < max_chars * 0.9:  # 保留10%的空间作为缓冲
            remaining_space = max_chars - current_length
            for key, value in context_dict.items():
                if key not in priority_order:
                    if key not in truncated:
                        value_str = str(value)
                        if len(value_str) > 100:
                            value_str = value_str[:100] + "..."
                        truncated[key] = value_str
                        current_length += len(key) + len(value_str) + 4
                        if current_length >= max_chars:
                            break
        
        return truncated

