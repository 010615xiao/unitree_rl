# 去掉 floor 以下噪声过滤

在线增量重建中去掉了"floor 以下噪声点云过滤"步骤。

原离线流程用 floor 物体的最低 Y 作为地面零位，删除全局点云中地面以下的点和中心在地面以下的物体。但在增量场景下，早期 batch 的 floor 单例只覆盖部分区域，floor_zero_level 不准，会导致有效物体/点云被误删。floor/wall 点云改为从 tracker 结构单例直接获取（不经过过滤链），房间分割直接用这些点云，不再依赖 floor_zero_level 过滤。

floor/wall 结构单例始终存活（不参与 miss/死亡），所以从 tracker 直接取是可靠的。
