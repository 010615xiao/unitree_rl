# 物体身份用 tracker obj_id 而非每 batch 重新编号

在线增量重建中，scene graph 的物体身份（name/persistent_id）基于 ObjectTracker 的 obj_id（如 D5），而不是每次后处理从 0 重新编号（chair_0, chair_1...）。跨 batch 恢复检查点后，同一物理物体的 obj_id 不变，任务规划/导航可以稳定引用。

选择了 tracker obj_id 而非独立永久编号系统，因为 tracker 已经通过检查点实现了跨 batch 稳定性，不需要额外编号管理。合并后物体的 name 用 `{category}_{min(source_instance_ids)}`，同一组实例合并出来的 name 跨 batch 不变。
