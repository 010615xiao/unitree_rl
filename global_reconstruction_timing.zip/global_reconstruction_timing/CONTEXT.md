# 在线增量重建

间歇采集场景下的 3D 场景重建。机器人跑一趟采集一批数据，在线重建器逐帧处理，每 batch 触发后处理产出可用 scene graph，停顿后可继续。

## Language

**Batch**:
一组连续帧的处理单元。每 batch 结束后存检查点（可暂停）并触发后处理。
_Avoid_: 批次, round

**中间结果 (Intermediate Result)**:
某个 batch 后处理产出的 scene graph + 物体 ply + 房间分割。坐标系为最新轨迹对齐系。每 batch 覆盖旧结果，不保留历史快照。可用于任务规划/导航。

**检查点 (Checkpoint)**:
某 batch 结束时保存的全部状态（融合图 NPZ + tracker NPZ + 进度 JSON）。支持暂停后恢复继续跟踪。

**持久身份 (Persistent Identity)**:
基于 ObjectTracker obj_id 的跨 batch 稳定物体身份。合并后物体的 name 用 `{category}_{min(source_instance_ids)}`。任务规划/导航通过 persistent identity 稳定引用物体。
_Avoid_: 临时编号, category_N

**轨迹对齐 (Trajectory Alignment)**:
用当前所有已处理 poses 做 RANSAC 拟合轨迹平面，旋转到 Y-up 坐标系。每 batch 全量重算，覆盖旧坐标系。
