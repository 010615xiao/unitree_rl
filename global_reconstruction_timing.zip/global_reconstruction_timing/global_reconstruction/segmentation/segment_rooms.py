#!/usr/bin/env python3
"""
房间分割：floor/wall 分水岭

- Y 轴：垂直方向（高度）
- X 轴：水平方向
- Z 轴：前后方向（房间延伸）
"""

import os
import numpy as np
import open3d as o3d
import cv2
from scipy.spatial import cKDTree
from scipy.ndimage import gaussian_filter1d
import matplotlib.pyplot as plt
from tqdm import tqdm

from global_reconstruction.core.config_loader import get_config
_cfg = get_config()
_rs = _cfg.room_segmentation

# 配置参数
GRID_RESOLUTION = _rs.grid_resolution
ROOM_HEIGHT_MIN_OFFSET = _rs.height_min_offset
ROOM_HEIGHT_MAX_OFFSET = _rs.height_max_offset
HIST_THRESHOLD_RATIO = _rs.hist_threshold_ratio
GAUSSIAN_BLUR_KERNEL = _rs.gaussian_blur_kernel
GAUSSIAN_BLUR_SIGMA = _rs.get('gaussian_blur_sigma', 1)
DIST_BLUR_KERNEL = tuple(_rs.get('dist_blur_kernel', [11, 1]))
DIST_BLUR_SIGMA = _rs.get('dist_blur_sigma', 10)
MIN_SEED_AREA = _rs.get('min_seed_area', 0.5)

# 房间候选过滤阈值
MIN_ROOM_OCCUPANCY_RATIO = float(_rs.get('min_room_occupancy_ratio', 0.3))  # 房间点云占据率下限，低于丢弃
MIN_ROOM_CELLS = int(_rs.get('min_room_cells', 25))                          # 连通域最小栅格数
MIN_FILTERED_CELLS = int(_rs.get('min_filtered_cells', 25))                   # 过滤后栅格数下限

_trajectory_cfg = _cfg.get('trajectory_alignment', {}) or {}
if _trajectory_cfg.get('enabled', True):
    VERTICAL_AXIS = 1    # Y-up
    HORIZONTAL_AXES = [0, 2]  # X, Z
else:
    VERTICAL_AXIS = 2    # Z-up
    HORIZONTAL_AXES = [0, 1]  # X, Y

if not bool(_rs.get('debug_plots', False)):
    from unittest.mock import MagicMock
    import matplotlib.cm as _real_cm
    plt = MagicMock()
    plt.cm = _real_cm


def load_pointcloud(ply_path):
    """加载点云"""
    pcd = o3d.io.read_point_cloud(ply_path)
    points = np.asarray(pcd.points)
    colors = np.asarray(pcd.colors)
    if len(colors) == 0:
        colors = None
    return points, colors


def segment_floors(points, voxel_size=0.05, vertical_axis=VERTICAL_AXIS):
    """楼层分割"""
    print("  体素下采样...")
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    pcd = pcd.voxel_down_sample(voxel_size)
    points = np.asarray(pcd.points)

    # 高度直方图
    y_coords = points[:, vertical_axis]
    y_min, y_max = y_coords.min(), y_coords.max()
    bin_size = 0.01
    num_bins = int((y_max - y_min) / bin_size) + 1
    
    hist, bin_edges = np.histogram(y_coords, bins=num_bins, range=(y_min, y_max))
    hist_smooth = gaussian_filter1d(hist.astype(float), sigma=2)
    
    # 峰值检测
    from scipy.signal import find_peaks
    peaks, _ = find_peaks(hist_smooth, distance=20, height=np.max(hist_smooth) * 0.1)

    print(f"  检测到 {len(peaks)} 个峰值")

    floors = []
    if len(peaks) > 0:
        # 找到最高峰值，确定主集群位置
        main_peak_idx = np.argmax(hist_smooth[peaks])
        peak_h = bin_edges[peaks[main_peak_idx]]

        # 主集群范围：峰值附近 ±2.0m
        cluster_min = max(y_min, peak_h - 2.0)
        cluster_max = min(y_max, peak_h + 2.0)
        cluster_mask = (y_coords >= cluster_min) & (y_coords <= cluster_max)
        cluster_points = y_coords[cluster_mask]

        if len(cluster_points) > 0:
            # 使用主集群的实际范围
            floor_zero = cluster_points.min()
            floor_top = cluster_points.max()

            floors.append({
                'zero_level': floor_zero,
                'height': floor_top - floor_zero,
                'peak': peak_h,
                'is_floor_peak': True
            })

    print(f"  检测到 {len(floors)} 个楼层")
    for i, f in enumerate(floors):
        print(f"    Floor {i}: zero_level={f['zero_level']:.2f}m, height={f['height']:.2f}m, "
              f"peak={f['peak']:.2f}m")
    return floors


def segment_rooms(floor_points, floor_zero_level, room_height=None, save_path=None, floor_colors=None,
                  vertical_axis=VERTICAL_AXIS, horizontal_axes=None,
                  global_points=None, global_colors=None):
    """
    房间分割

    参数:
        floor_points: 用于房间分割的点云
        floor_zero_level: 地板 Y 位置
        room_height: 房间净高（地板到天花板）
        save_path: 保存路径
        floor_colors: 点云颜色
        vertical_axis: 垂直轴索引 (默认 1=Y)
        horizontal_axes: 水平轴列表 (默认 [0,2]=XZ)
        global_points: 全局点云
        global_colors: 全局点云颜色
    """
    # 房间分割参数
    config = get_config()
    room_seg_cfg = config.get('room_segmentation', {})
    percentile_threshold = room_seg_cfg.get('percentile_threshold', 98)
    
    if horizontal_axes is None:
        horizontal_axes = [i for i in range(3) if i != vertical_axis]
    print(f"  Floor zero level: {floor_zero_level:.2f}m", end="")
    if room_height is not None:
        print(f", room_height: {room_height:.2f}m")
    else:
        print(" (使用所有 floor 以上的点)")

    xyz = floor_points.copy()
    xyz_full = floor_points.copy()
    colors = floor_colors.copy() if floor_colors is not None and len(floor_colors) == len(floor_points) else None
    colors_full = colors.copy() if colors is not None else None

    if room_height is not None:
        mask1 = (xyz[:, vertical_axis] < floor_zero_level + room_height - ROOM_HEIGHT_MAX_OFFSET) & \
                (xyz[:, vertical_axis] >= floor_zero_level + ROOM_HEIGHT_MIN_OFFSET)
        mask_full = xyz_full[:, vertical_axis] < floor_zero_level + room_height - 0.2
    else:
        # 排除地板表面噪声（< 0.3m）
        mask1 = xyz[:, vertical_axis] >= floor_zero_level + ROOM_HEIGHT_MIN_OFFSET
        mask_full = np.ones(len(xyz_full), dtype=bool)

    xyz = xyz[mask1]
    if colors is not None:
        colors = colors[mask1]

    xyz_full = xyz_full[mask_full]
    if colors_full is not None:
        colors_full = colors_full[mask_full]

    assert colors_full is None or len(colors_full) == len(xyz_full), \
        f"colors_full ({len(colors_full)}) != xyz_full ({len(xyz_full)})"

    print(f"  高度过滤后：{len(xyz)} 点，xyz_full：{len(xyz_full)} 点")
    if colors_full is not None:
        print(f"  colors_full 范围：[{colors_full.min():.3f}, {colors_full.max():.3f}]")

    # 投影到 2D
    pcd_2d = xyz[:, horizontal_axes]
    xyz_full_2d = xyz_full[:, horizontal_axes]

    # 计算网格尺寸
    grid_size = (
        int(np.max(pcd_2d[:, 0]) - np.min(pcd_2d[:, 0])),
        int(np.max(pcd_2d[:, 1]) - np.min(pcd_2d[:, 1]))
    )
    grid_size = (grid_size[0] + 1, grid_size[1] + 1)
    print(f"  栅格尺寸：{grid_size}")

    # 计算 2D 直方图
    num_bins = (int(grid_size[0] // GRID_RESOLUTION),
                int(grid_size[1] // GRID_RESOLUTION))
    num_bins = (num_bins[1] + 1, num_bins[0] + 1)

    hist, hist_edges_h1, hist_edges_h0 = np.histogram2d(pcd_2d[:, 1], pcd_2d[:, 0], bins=num_bins)
    hist_full, _, _ = np.histogram2d(xyz_full_2d[:, 1], xyz_full_2d[:, 0], bins=num_bins)

    # === 点云占据栅格：floor 点云生成 ===
    point_occupancy = (hist > 0).astype(np.uint8)
    # 形态学闭运算：填充小空洞
    kernel_close = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    point_occupancy = cv2.morphologyEx(point_occupancy, cv2.MORPH_CLOSE, kernel_close, iterations=2)
    print(f"  Floor 占据栅格（闭运算后）：{point_occupancy.sum()} / {point_occupancy.size} 个单元格")

    os.makedirs(save_path, exist_ok=True)

    # 墙体骨架处理
    padding = 10

    point_occupancy = cv2.copyMakeBorder(point_occupancy, padding, padding, padding, padding,
                                         cv2.BORDER_CONSTANT, value=0)

    # === 添加 floor 边界到 walls_skeleton ===
    # floor 占据栅格膨胀，得到边界环，与 VLM wall 合并
    boundary_dilate_iters = int(room_seg_cfg.get('boundary_dilate_iterations', 3))
    kernel_boundary = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    point_occupancy_dilated = cv2.dilate(point_occupancy, kernel_boundary, iterations=boundary_dilate_iters)
    floor_boundary = point_occupancy_dilated - point_occupancy  # 边界环
    print(f"  Floor 边界栅格：{floor_boundary.sum()} 个")

    hist_norm = cv2.normalize(hist, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_blur = cv2.GaussianBlur(hist_norm, (GAUSSIAN_BLUR_KERNEL, GAUSSIAN_BLUR_KERNEL), GAUSSIAN_BLUR_SIGMA)
    hist_threshold = HIST_THRESHOLD_RATIO * np.max(hist_blur)
    _, walls_skeleton = cv2.threshold(hist_blur, hist_threshold, 255, cv2.THRESH_BINARY)
    walls_skeleton = cv2.copyMakeBorder(walls_skeleton, padding, padding, padding, padding, cv2.BORDER_CONSTANT, value=0)
    kernel_cross = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    walls_skeleton = cv2.morphologyEx(walls_skeleton, cv2.MORPH_CLOSE, kernel_cross, iterations=1)

    # 合并 floor 边界到 walls_skeleton
    walls_skeleton[floor_boundary > 0] = 255
    print(f"  合并 floor 边界后 walls_skeleton：{walls_skeleton.sum() / 255:.0f} 个墙体栅格")
    
    # 外部边界处理
    hist_full_norm = cv2.normalize(hist_full, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_full_blur = cv2.GaussianBlur(hist_full_norm, (21, 21), 2)
    _, outside_boundary = cv2.threshold(hist_full_blur, 0, 255, cv2.THRESH_BINARY)
    outside_boundary = cv2.copyMakeBorder(outside_boundary, padding, padding, padding, padding, cv2.BORDER_CONSTANT, value=0)
    kernel_rect_5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    outside_boundary = cv2.morphologyEx(outside_boundary, cv2.MORPH_CLOSE, kernel_rect_5, iterations=3)
    
    # 提取外部轮廓
    outside_boundary_filled = np.zeros_like(outside_boundary)
    contours, _ = cv2.findContours(outside_boundary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(outside_boundary_filled, contours, -1, 255, -1)
    outside_boundary_filled = outside_boundary_filled.astype(np.uint8)
    
    # 可视化
    plt.figure(figsize=(15, 5))
    plt.subplot(1, 4, 1)
    plt.imshow(walls_skeleton, cmap='gray', origin='lower')
    plt.title('Walls Skeleton')
    plt.axis('off')
    plt.subplot(1, 4, 2)
    plt.imshow(outside_boundary_filled, cmap='gray', origin='lower')
    plt.title('Outside Boundary')
    plt.axis('off')
    
    # 合并墙体骨架和外部边界
    full_map = cv2.bitwise_or(walls_skeleton, cv2.bitwise_not(outside_boundary_filled))
    kernel_rect_3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    full_map = cv2.morphologyEx(full_map, cv2.MORPH_CLOSE, kernel_rect_3, iterations=1)  # 从 2 改为 1，避免合并门洞

    # 补全外围墙体
    full_map = complete_boundary_walls(full_map)

    full_map_filtered = full_map.copy()
    no_floor_mask = (point_occupancy == 0) & (full_map == 0)  # 无 floor 且非墙体
    full_map_filtered[no_floor_mask] = 255  # 标记为墙体
    print(f"  过滤无 floor 区域：{no_floor_mask.sum()} 个栅格 → 墙体")
    full_map = full_map_filtered

    plt.subplot(1, 4, 3)
    plt.imshow(full_map, cmap='gray', origin='lower')
    plt.title('Full Map (with boundary walls)')
    plt.axis('off')
    
    # 距离变换 + 分水岭
    room_vertices = distance_transform(full_map, GRID_RESOLUTION, save_path, percentile_threshold)
    
    plt.subplot(1, 4, 4)
    markers_vis = np.zeros_like(full_map, dtype=float)
    for i, room in enumerate(room_vertices):
        if len(room[0]) > 0:
            markers_vis[room[0], room[1]] = i + 1
    plt.imshow(markers_vis, cmap='jet', origin='lower')
    plt.title(f'Rooms: {len(room_vertices)}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_path, 'room_segmentation.png'), dpi=150)
    plt.close()
    
    print(f"  分割得到 {len(room_vertices)} 个房间")

    # 准备映射用点云：优先使用全局点云，避免墙面点主导
    if global_points is not None:
        # 对全局点云做高度过滤，保留当前楼层相关范围
        h_min = floor_zero_level - 0.5
        h_max = floor_zero_level + (room_height if room_height is not None else 3.0) + 0.5
        gp_mask = (global_points[:, vertical_axis] >= h_min) & (global_points[:, vertical_axis] <= h_max)
        kdtree_pts = global_points[gp_mask]
        kdtree_clr = global_colors[gp_mask] if global_colors is not None and len(global_colors) == len(global_points) else None
        print(f"  3D 映射：使用全局点云 {len(kdtree_pts):,} 点 (高度 {h_min:.1f}~{h_max:.1f}m)")

        kdtree_2d = kdtree_pts[:, horizontal_axes]
        hist_global, gp_edges_h1, gp_edges_h0 = np.histogram2d(kdtree_2d[:, 1], kdtree_2d[:, 0], bins=num_bins)
        point_occupancy = (hist_global > 0).astype(np.uint8)
        # 加 padding 与 full_map 对齐
        point_occupancy = cv2.copyMakeBorder(point_occupancy, padding, padding, padding, padding,
                                             cv2.BORDER_CONSTANT, value=0)
        # 2D 栅格归属边界：与 point_occupancy 同一张栅格
        assign_edges = (gp_edges_h0, gp_edges_h1)
    else:
        kdtree_pts = None
        kdtree_clr = None
        # 无全局点云时退回 floor 点云的栅格边界
        assign_edges = (hist_edges_h0, hist_edges_h1)

    # 将 2D 房间映射回 3D 点云
    rooms = map_rooms_to_3d(room_vertices, full_map, xyz_full, floor_zero_level,
                           room_height, pcd_2d, point_occupancy, save_path,
                           colors_full=colors_full,
                           vertical_axis=vertical_axis,
                           horizontal_axes=horizontal_axes,
                           kdtree_points=kdtree_pts,
                           kdtree_colors=kdtree_clr,
                           grid_edges=assign_edges,
                           grid_padding=padding)
    
    return rooms


def distance_transform(occupancy_map, resolution, tmp_path, percentile_threshold=98):
    """距离变换"""
    bw = cv2.bitwise_not(occupancy_map.copy())
    full_map = occupancy_map.copy()
    
    bw = np.uint8(bw)
    dist = cv2.distanceTransform(bw, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
    print(f"  距离范围：{np.min(dist):.2f} ~ {np.max(dist):.2f}")
    
    cv2.normalize(dist, dist, 0, 255, cv2.NORM_MINMAX)
    plt.figure()
    plt.imshow(dist, cmap='jet', origin='lower')
    plt.title('Distance Transform')
    plt.savefig(os.path.join(tmp_path, 'dist.png'))
    plt.close()
    
    dist = np.uint8(dist)
    blur = cv2.GaussianBlur(dist, DIST_BLUR_KERNEL, DIST_BLUR_SIGMA)
    plt.figure()
    plt.imshow(blur, cmap='jet', origin='lower')
    plt.title('Distance Blur')
    plt.savefig(os.path.join(tmp_path, 'dist_blur.png'))
    plt.close()
    
    # 使用百分位阈值代替 Otsu：只保留距离值最高的区域作为种子
    nonzero_vals = blur[blur > 0]
    if len(nonzero_vals) > 0:
        thresh_val = np.percentile(nonzero_vals, percentile_threshold)
    else:
        thresh_val = 0
    _, dist_thresh = cv2.threshold(blur, thresh_val, 255, cv2.THRESH_BINARY)
    print(f"  距离阈值（{percentile_threshold}th percentile）：{thresh_val:.2f} / max={blur.max():.2f}")
    plt.figure()
    plt.imshow(dist_thresh, cmap='jet', origin='lower')
    plt.title('Distance Threshold')
    plt.savefig(os.path.join(tmp_path, 'dist_thresh.png'))
    plt.close()
    
    dist_8u = dist_thresh.astype(np.uint8)
    contours, _ = cv2.findContours(dist_8u, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    print(f"  种子数：{len(contours)}")
    
    # min_area from config
    min_area_m = MIN_SEED_AREA
    min_area = (min_area_m / resolution) ** 2
    contours = [c for c in contours if cv2.contourArea(c) > min_area]
    print(f"  过滤后种子数：{len(contours)}")
    
    markers = np.zeros(dist.shape, dtype=np.int32)
    for i, contour in enumerate(contours):
        cv2.drawContours(markers, [contour], -1, i + 1, -1)
    cv2.circle(markers, (3, 3), 1, len(contours) + 1, -1)
    
    full_map_3ch = cv2.cvtColor(full_map, cv2.COLOR_GRAY2BGR)
    markers = cv2.watershed(full_map_3ch, markers)
    
    room_vertices = []
    for i in range(len(contours)):
        room_vertices.append(tuple(np.where(markers == i + 1)))
    
    plt.figure()
    plt.imshow(markers, cmap='jet', origin='lower')
    plt.title('Watershed Markers')
    plt.savefig(os.path.join(tmp_path, 'markers.png'))
    plt.close()
    
    return room_vertices


def complete_boundary_walls(full_map, iterations=1, margin=2):
    """
    补全外围墙体

    在 cost_map 中: 对 floor (1) 做膨胀，膨胀覆盖 unknown (0) 的部分标记为 wall (100)
    在 full_map 中: 对 room (0) 做膨胀，膨胀覆盖 wall (255) 的部分保留为 wall

    参数:
        full_map: 原始栅格地图 (0=房间/可行走, 255=墙体/障碍)
        iterations: 膨胀迭代次数 (对应 cost_map 中 floor 的膨胀次数)
        margin: 边缘补全宽度

    返回:
        补全后的栅格地图
    """
    # Step 1 2: 对墙体 (255) 做膨胀 → wall 向 room 方向扩展
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    wall_mask = (full_map == 255).astype(np.uint8)
    wall_dilated = cv2.dilate(wall_mask, kernel, iterations=iterations)
    full_map[wall_dilated.astype(bool)] = 255

    # Step 3: 在栅格四条边补一圈墙体 (防止边缘开放)
    full_map[0:margin, :] = 255
    full_map[-margin:, :] = 255
    full_map[:, 0:margin] = 255
    full_map[:, -margin:] = 255

    print(f"  补全外围 wall: 新增 {int(wall_dilated.sum() - wall_mask.sum())} 个障碍单元格")

    return full_map


def check_connected_components(occupancy_grid_map, min_cells=MIN_ROOM_CELLS):
    """
    检查栅格地图中的连通分量，返回每个分量掩码
    """
    grid = (occupancy_grid_map > 0).astype(np.uint8)
    n_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(grid, connectivity=4)
    
    components = []
    for i in range(1, n_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area >= min_cells:
            mask = (labels == i).astype(np.uint8)
            components.append(mask)
    
    return components


def map_rooms_to_3d(room_vertices, full_map, floor_points, floor_zero_level,
                    room_height, pcd_2d, point_occupancy, save_path, colors_full=None,
                    vertical_axis=VERTICAL_AXIS, horizontal_axes=None,
                    kdtree_points=None, kdtree_colors=None,
                    grid_edges=None, grid_padding=0):
    """
    将 2D 房间映射回 3D 点云

    point_occupancy: 二值栅格图，1=该栅格有至少一个点云投影
    kdtree_points: 用于映射的点云（默认使用 floor_points）
    kdtree_colors: 对应的颜色
    grid_edges: (edges_h0, edges_h1) 栅格边界（horizontal_axes[0]/[1]）
    grid_padding: 栅格 padding（与 point_occupancy/full_map 对齐）
    """
    if horizontal_axes is None:
        horizontal_axes = [i for i in range(3) if i != vertical_axis]
    rooms = []
    room_id_counter = 0

    # 优先使用全局点云，避免墙面点主导
    kdtree_src = kdtree_points if kdtree_points is not None else floor_points
    kdtree_colors_src = kdtree_colors if kdtree_colors is not None else colors_full

    use_grid_assign = grid_edges is not None
    if use_grid_assign:
        # 2D 栅格归属：预计算每个源点落在 point_occupancy 栅格中的坐标（向量化）
        # hist 行轴=horizontal_axes[1]、列轴=horizontal_axes[0]；加 padding 对齐 full_map
        edges_h0, edges_h1 = grid_edges
        h0 = kdtree_src[:, horizontal_axes[0]]
        h1 = kdtree_src[:, horizontal_axes[1]]
        nb_h0, nb_h1 = len(edges_h0) - 1, len(edges_h1) - 1   # 各轴 bin 数
        # 在栅格范围内（含右边界，与 histogram2d 末 bin 闭区间一致）
        gp_valid = (h0 >= edges_h0[0]) & (h0 <= edges_h0[-1]) & \
                   (h1 >= edges_h1[0]) & (h1 <= edges_h1[-1])
        bin_h0 = np.clip(np.searchsorted(edges_h0, h0, side='right') - 1, 0, nb_h0 - 1)
        bin_h1 = np.clip(np.searchsorted(edges_h1, h1, side='right') - 1, 0, nb_h1 - 1)
        gp_valid_idx = np.where(gp_valid)[0]
        gp_row = bin_h1[gp_valid] + grid_padding
        gp_col = bin_h0[gp_valid] + grid_padding
    else:
        floor_tree = cKDTree(kdtree_src)

    for i, room_vertex in enumerate(tqdm(room_vertices, desc="Assign floor points to rooms")):
        if len(room_vertex[0]) == 0:
            continue

        # 创建房间掩码
        room = np.zeros_like(full_map)
        room[room_vertex[0], room_vertex[1]] = 255

        # 连通性检查
        components = check_connected_components(room, min_cells=MIN_ROOM_CELLS)
        if len(components) > 1:
            print(f"  房间 {i}: 检测到 {len(components)} 个不连通区域，进行拆分")

        masks_to_process = components if len(components) > 1 else [(room > 0).astype(np.uint8)]

        for comp_idx, comp_mask in enumerate(masks_to_process):
            # === 栅格级验证：房间内必须有足够比例的点云占据 ===
            room_cells = comp_mask.sum()
            occ_cells_in_room = (comp_mask & point_occupancy).sum()
            occ_ratio = occ_cells_in_room / room_cells if room_cells > 0 else 0

            if occ_ratio < MIN_ROOM_OCCUPANCY_RATIO:
                room_id_display = f"{room_id_counter}.{comp_idx}" if len(masks_to_process) > 1 else str(room_id_counter)
                print(f"  房间 {room_id_display}: 丢弃（点云占据率 {occ_ratio:.0%} < {MIN_ROOM_OCCUPANCY_RATIO:.0%}，疑似纯墙面/空洞区域，"
                      f"总栅格{room_cells} / 占据栅格{occ_cells_in_room}）")

                discard_vis = np.zeros_like(point_occupancy, dtype=np.uint8)
                discard_vis[comp_mask > 0] = 128
                discard_vis[(comp_mask > 0) & (point_occupancy > 0)] = 255
                discard_vis[(comp_mask == 0) & (point_occupancy > 0)] = 64
                plt.figure(figsize=(8, 6))
                plt.imshow(discard_vis, cmap='gray', origin='lower')
                plt.title(f"Room {room_id_display} DISCARDED: occ={occ_ratio:.0%}, "
                          f"cells={room_cells}, occ_cells={occ_cells_in_room}")
                plt.axis('off')
                plt.tight_layout()
                plt.savefig(os.path.join(save_path, f'room_{room_id_display}_discarded.png'), dpi=100)
                plt.close()
                continue

            # === 栅格验证通过，映射到 3D 点云 ===
            # 只保留有 floor 点云的栅格，避免把空洞/无 floor 区域映射进去
            comp_mask_filtered = comp_mask & point_occupancy
            if comp_mask_filtered.sum() < MIN_FILTERED_CELLS:
                print(f"  房间 {room_id_counter}: 过滤后栅格太少 ({comp_mask_filtered.sum()})，跳过")
                continue

            actual_room_height = 2.5 if room_height is None else room_height

            if use_grid_assign:
                # 2D 栅格归属（向量化）
                in_room = comp_mask_filtered[gp_row, gp_col] != 0
                sel_idx = gp_valid_idx[in_room]
                room_points = kdtree_src[sel_idx]
                room_colors = kdtree_colors_src[sel_idx] if kdtree_colors_src is not None else None
            else:
                # 映射到 2D 点云
                room_2d = map_grid_to_point_cloud(comp_mask_filtered, GRID_RESOLUTION, pcd_2d)

                if len(room_2d) < 10:
                    continue

                v_levels = np.arange(floor_zero_level, floor_zero_level + actual_room_height, 0.05)

                room_3d_samples = []
                for v in v_levels:
                    room_3d = np.zeros((len(room_2d), 3))
                    room_3d[:, horizontal_axes[0]] = room_2d[:, 0]
                    room_3d[:, horizontal_axes[1]] = room_2d[:, 1]
                    room_3d[:, vertical_axis] = v
                    room_3d_samples.append(room_3d)
                room_3d_samples = np.vstack(room_3d_samples)

                # KDTree 查询：使用全局点云（kdtree_src）而非墙面主导的点云
                _, idx = floor_tree.query(room_3d_samples, k=1, workers=-1)
                room_points = kdtree_src[idx]
                if kdtree_colors_src is not None:
                    room_colors = kdtree_colors_src[idx]
                else:
                    room_colors = None

                _, unique_idx = np.unique(room_points, axis=0, return_index=True)
                room_points = room_points[unique_idx]
                if room_colors is not None:
                    room_colors = room_colors[unique_idx]
            
            if room_colors is not None:
                print(f"  房间 {room_id_counter}: {len(room_points)} 点, 颜色范围 [{room_colors.min():.3f}, {room_colors.max():.3f}]")

            if len(room_points) < 50:
                continue

            room_center = room_points.mean(axis=0)
            h_min = room_points[:, horizontal_axes].min(axis=0)
            h_max = room_points[:, horizontal_axes].max(axis=0)
            v_lo = floor_zero_level
            v_hi = floor_zero_level + (actual_room_height if room_height is None else room_height)
            bbox_min = np.zeros(3)
            bbox_max = np.zeros(3)
            bbox_min[horizontal_axes[0]] = h_min[0]
            bbox_min[horizontal_axes[1]] = h_min[1]
            bbox_min[vertical_axis] = v_lo
            bbox_max[horizontal_axes[0]] = h_max[0]
            bbox_max[horizontal_axes[1]] = h_max[1]
            bbox_max[vertical_axis] = v_hi
            room_center[vertical_axis] = floor_zero_level
            room_area = np.prod(h_max - h_min)

            # === 可视化房间占据栅格 ===
            room_occupancy_vis = np.zeros_like(point_occupancy, dtype=np.uint8)
            room_occupancy_vis[comp_mask_filtered > 0] = 255
            room_occupancy_vis[(comp_mask > 0) & (point_occupancy == 0)] = 64
            room_occupancy_vis[(comp_mask == 0) & (point_occupancy > 0)] = 32

            plt.figure(figsize=(8, 6))
            plt.imshow(room_occupancy_vis, cmap='gray', origin='lower')
            plt.title(f"Room {room_id_counter}: filtered_cells={comp_mask_filtered.sum()}, "
                      f"original_cells={room_cells}, points={len(room_points)}")
            plt.axis('off')
            plt.tight_layout()
            plt.savefig(os.path.join(save_path, f'room_{room_id_counter}_occupancy.png'), dpi=100)
            plt.close()

            rooms.append({
                'id': room_id_counter,
                'points': room_points,
                'colors': room_colors,
                'center': room_center,
                'area': room_area,
                'bbox': {
                    'min': bbox_min.tolist(),
                    'max': bbox_max.tolist()
                }
            })
            room_id_counter += 1

    print(f"  最终房间数：{len(rooms)}")
    return rooms


def map_grid_to_point_cloud(occupancy_grid_map, resolution, point_cloud):
    """网格到点云映射"""
    occupancy_grid_map = (occupancy_grid_map > 0).astype(np.uint8)
    y_cells, x_cells = np.where(occupancy_grid_map == 1)
    
    # 像素偏移 (padding=10 + 0.5 中心偏移)
    mapped_x_coords = (x_cells - 10.5) * resolution + np.min(point_cloud[:, 0])
    mapped_y_coords = (y_cells - 10.5) * resolution + np.min(point_cloud[:, 1])
    
    return np.column_stack((mapped_x_coords, mapped_y_coords))


def save_rooms(rooms, output_dir):
    """保存房间点云"""
    os.makedirs(output_dir, exist_ok=True)

    for room in rooms:
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(room['points'])

        if 'colors' in room and room['colors'] is not None and len(room['colors']) > 0:
            room_colors = np.asarray(room['colors'], dtype=np.float64)
            # uint8 [0-255] → float [0-1]
            if room_colors.max() > 1.0:
                room_colors = room_colors / 255.0
            pcd.colors = o3d.utility.Vector3dVector(room_colors)
        else:
            # fallback: 使用房间颜色
            color_idx = room['id'] % 10
            colors = plt.cm.tab10(color_idx)[:3]
            pcd.colors = o3d.utility.Vector3dVector(np.tile(colors, (len(room['points']), 1)))

        output_path = os.path.join(output_dir, f"room_{room['id']}.ply")
        o3d.io.write_point_cloud(output_path, pcd)
        print(f"  已保存：{output_path} ({len(room['points']):,} 点)")


def main():
    """主函数 — 使用 VLM 检测的 floor/wall 物体进行房间分割"""
    import argparse
    import json
    import glob as glob_mod
    parser = argparse.ArgumentParser(description='房间分割（使用 VLM 物体）')
    parser.add_argument('--objects_dir', type=str,
                       default='unified_output/objects',
                       help='VLM 物体目录')
    parser.add_argument('--output_dir', type=str,
                       default='unified_output/rooms',
                       help='输出目录')
    parser.add_argument('--voxel_size', type=float,
                       default=0.02,
                       help='降采样体素大小 (m)')
    args = parser.parse_args()

    print("=" * 70)
    print("房间分割（VLM 物体模式）")
    print("=" * 70)

    objects_dir = args.objects_dir
    voxel_size = args.voxel_size

    # 查找 VLM floor 物体
    floor_ply = os.path.join(objects_dir, 'object_0001_floor_0.ply')
    if not os.path.exists(floor_ply):
        floor_candidates = glob_mod.glob(os.path.join(objects_dir, '*floor*.ply'))
        if floor_candidates:
            floor_ply = floor_candidates[0]
        else:
            print(f"错误：未找到 floor 物体在 {objects_dir}")
            return

    print(f"\n加载 VLM Floor: {floor_ply}")
    floor_pcd = o3d.io.read_point_cloud(floor_ply)
    floor_points = np.asarray(floor_pcd.points)
    floor_colors = np.asarray(floor_pcd.colors) if len(floor_pcd.colors) == len(floor_points) else None
    print(f"  原始点数：{len(floor_points):,}")

    # 体素降采样
    floor_pcd_ds = floor_pcd.voxel_down_sample(voxel_size)
    floor_points = np.asarray(floor_pcd_ds.points)
    floor_colors = np.asarray(floor_pcd_ds.colors) if len(floor_pcd_ds.colors) == len(floor_points) else None
    print(f"  降采样 {voxel_size}m 后：{len(floor_points):,} 点")

    # 计算 floor zero level
    floor_zero_level = float(floor_points[:, VERTICAL_AXIS].min())
    room_height = 3.83  # 默认房间高度
    print(f"  Floor zero level: {floor_zero_level:.2f}m, room_height: {room_height:.2f}m")

    # 查找 VLM wall 物体
    wall_ply = os.path.join(objects_dir, 'object_0000_wall_0.ply')
    if not os.path.exists(wall_ply):
        wall_candidates = glob_mod.glob(os.path.join(objects_dir, '*wall*.ply'))
        if wall_candidates:
            wall_ply = wall_candidates[0]
        else:
            wall_ply = None

    if wall_ply and os.path.exists(wall_ply):
        print(f"\n加载 VLM Wall: {wall_ply}")
        wall_pcd = o3d.io.read_point_cloud(wall_ply)
        wall_points = np.asarray(wall_pcd.points)
        wall_colors = np.asarray(wall_pcd.colors) if len(wall_pcd.colors) == len(wall_points) else None
        print(f"  原始点数：{len(wall_points):,}")
        # 降采样
        wall_pcd_ds = wall_pcd.voxel_down_sample(voxel_size)
        wall_points = np.asarray(wall_pcd_ds.points)
        wall_colors = np.asarray(wall_pcd_ds.colors) if len(wall_pcd_ds.colors) == len(wall_points) else None
        print(f"  降采样 {voxel_size}m 后：{len(wall_points):,} 点")
    else:
        print(f"\n警告：未找到 wall 物体，将仅使用 floor 点云")
        wall_points = None
        wall_colors = None

    # 合并 floor + wall 作为分割输入
    if wall_points is not None:
        combined_points = np.vstack([floor_points, wall_points])
        if floor_colors is not None and wall_colors is not None:
            combined_colors = np.vstack([floor_colors, wall_colors])
        else:
            combined_colors = None
        print(f"\n合并点云：{len(combined_points):,} 点 (floor {len(floor_points):,} + wall {len(wall_points):,})")
    else:
        combined_points = floor_points
        combined_colors = floor_colors
        print(f"\n仅使用 Floor 点云：{len(combined_points):,} 点")

    # 房间分割
    room_save_path = os.path.join(args.output_dir, 'floor_0')
    rooms = segment_rooms(
        combined_points, floor_zero_level,
        room_height=room_height,
        save_path=room_save_path,
        floor_colors=combined_colors,
        vertical_axis=VERTICAL_AXIS,
        horizontal_axes=HORIZONTAL_AXES,
        global_points=combined_points,
        global_colors=combined_colors
    )

    # 保存房间
    rooms_output_dir = os.path.join(args.output_dir, 'floor_0_rooms')
    save_rooms(rooms, rooms_output_dir)

    for room in rooms:
        room['floor_id'] = 0

    print(f"\n  总房间数：{len(rooms)}")
    print("\n" + "=" * 70)
    print("完成!")
    print("=" * 70)


if __name__ == '__main__':
    main()
