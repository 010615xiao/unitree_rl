"""
在线增量重建：逐帧处理 + 检查点暂停/继续 + 每 N 帧后处理

用法::
    recon = OnlineReconstructor.from_config(cfg, data_dir, output_dir)
    recon.run(max_frames=200, batch_size=50, postprocess_every_batches=2)
    
    recon = OnlineReconstructor.load_checkpoint(checkpoint_dir)
    recon.run(...)
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from tqdm import tqdm

from global_reconstruction.core.config_loader import get_config
from global_reconstruction.core.data_adapter import DatasetAdapter
from global_reconstruction.incremental.object_tracker import ObjectTracker
from global_reconstruction.reconstruction.pipeline_steps import (
    PipelineConfig, FrameState, process_frame, run_postprocessing, print_timing_summary,
)


class OnlineReconstructor:
    """
    在线增量重建：逐帧处理 + 检查点 + 后处理调度

    pipeline_steps.process_frame / run_postprocessing
    """

    def __init__(self, cfg, adapter, poses, file_to_pose, depth_files,
                 output_dir, checkpoint_dir):
        self.cfg = cfg
        self.adapter = adapter
        self.poses = poses
        self.file_to_pose = file_to_pose
        self.depth_files = depth_files
        self.output_dir = Path(output_dir)
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        # 共享配置 + 状态
        self.pcfg = PipelineConfig.from_cfg(cfg)
        static_library = cfg.object_segmentation.get('static_library', []) or []
        self.state = FrameState.initial(static_library)

        from global_reconstruction.reconstruction.pointcloud_builder import PointCloudBuilder
        self.builder = PointCloudBuilder.from_config(cfg)
        self.tracker = ObjectTracker(voxel_size=self.pcfg.voxel_size, config=self.pcfg.object_tracking_cfg)

        # 默认关闭可见性可视化和视频渲染
        self.pcfg.vis_viz_enabled = False
        self.pcfg.render_video = False

        # 服务状态
        self.vlm_ok = False
        self.services_ok = False

        # 环境描述增量状态：{obj_name: last_seen_frame}，记录上次描述时的 last_seen_frame
        self.last_described: Dict[str, str] = {}
        # 环境描述缓存
        self._env_desc_cache: dict = {}

        # 进度
        self.frame_idx = 0

    @classmethod
    def from_config(cls, cfg, data_dir, output_dir, checkpoint_dir=None) -> "OnlineReconstructor":
        """从配置创建新的重建器。"""
        adapter = DatasetAdapter(Path(data_dir))

        from global_reconstruction.reconstruction.build_pointcloud import load_poses_from_odom_camera
        odom_cam_file = adapter.data_dir / "odom_matched_camera.txt"
        if odom_cam_file.exists():
            poses = load_poses_from_odom_camera(str(adapter.data_dir))
            if poses is None:
                from global_reconstruction.reconstruction.reconstruct_and_segment import load_poses
                poses = load_poses(adapter.poses_file)
        else:
            from global_reconstruction.reconstruction.reconstruct_and_segment import load_poses
            poses = load_poses(adapter.poses_file)

        depth_files = adapter.get_depth_file_list(max_frames=100000)
        file_to_pose = adapter.build_pose_timestamp_map(poses)

        if checkpoint_dir is None:
            checkpoint_dir = Path(output_dir) / "checkpoint"

        return cls(cfg, adapter, poses, file_to_pose, depth_files, output_dir, checkpoint_dir)

    @classmethod
    def load_checkpoint(cls, checkpoint_dir, data_dir=None) -> "OnlineReconstructor":
        """
        从检查点恢复重建器

        data_dir: 可选，覆盖检查点记录的数据集
            - 不传 / 与检查点相同：正常续跑，从检查点 frame_idx 继续
            - 与检查点不同：跨数据集续跑——保留已累积的融合图/tracker/已发现类别等状态，
              frame_idx 归零，从新数据集第 0 帧开始融合
        """
        checkpoint_dir = Path(checkpoint_dir)
        meta_path = checkpoint_dir / "checkpoint.json"
        if not meta_path.exists():
            raise FileNotFoundError(f"检查点不存在: {meta_path}")

        with open(meta_path) as f:
            meta = json.load(f)

        cfg = get_config()
        ckpt_data_dir = meta['data_dir']
        effective_data_dir = data_dir if data_dir is not None else ckpt_data_dir
        recon = cls.from_config(cfg, effective_data_dir, meta['output_dir'], checkpoint_dir)

        # 跨数据集续跑：指定的数据集与检查点不同 → 从新数据集第 0 帧开始（frame_idx 归零）
        new_dataset = data_dir is not None and \
            Path(data_dir).resolve() != Path(ckpt_data_dir).resolve()

        # frame_idx 归零
        recon.frame_idx = 0 if new_dataset else meta.get('frame_idx', 0)
        recon.state.num_frames_processed = meta.get('num_frames_processed', 0)
        recon.state.num_objects_detected = meta.get('num_objects_detected', 0)
        recon.state.num_detection_frames = meta.get('num_detection_frames', 0)
        recon.state.num_vlm_detections = meta.get('num_vlm_detections', 0)
        recon.state.discovered_categories = meta.get('discovered_categories', recon.state.discovered_categories)
        recon.state.last_vlm_pos = np.array(meta['_last_vlm_pos']) if meta.get('_last_vlm_pos') else None
        recon.state.last_vlm_dir = np.array(meta['_last_vlm_dir']) if meta.get('_last_vlm_dir') else None

        # 恢复融合图
        fusion_state = checkpoint_dir / "fusion_state.npz"
        if fusion_state.exists():
            from global_reconstruction.reconstruction.voxel_fusion import SparseVoxelFusion
            recon.builder.fusion_map = SparseVoxelFusion.load_state(fusion_state)
            print(f"  恢复融合图: {fusion_state}")

        # 恢复 tracker
        tracker_state = checkpoint_dir / "tracker_state.npz"
        if tracker_state.exists():
            recon.tracker = ObjectTracker.load_state(tracker_state)
            print(f"  恢复 tracker: {tracker_state}")

        # 恢复环境描述增量状态
        recon.last_described = meta.get('last_described', {})

        if new_dataset:
            print(f"  跨数据集续跑：{ckpt_data_dir} (frame {meta.get('frame_idx', 0)}) → "
                  f"{effective_data_dir} (frame 0)，保留已累积融合图/tracker/类别")
        else:
            print(f"  恢复进度: frame_idx={recon.frame_idx}")
        return recon

    # ================================================================
    # 服务检查
    # ================================================================

    def check_services(self) -> None:
        """检查 VLM 和 SAM3 服务可用性"""
        import requests
        self.services_ok = True
        try:
            test_payload = {
                "model": self.cfg.models.vlm_model_legacy,
                "messages": [{"role": "user", "content": [{"type": "text", "text": "test"}]}],
                "max_tokens": 10
            }
            vlm_url = self.cfg.get('services', {}).get('vlm_api_url', 'http://localhost:8010/v1/chat/completions')
            response = requests.post(vlm_url, json=test_payload, timeout=5)
            if response.status_code == 200:
                print("  ✓ VLM API")
                self.vlm_ok = True
            else:
                print(f"  ✗ VLM API (状态码: {response.status_code})")
        except Exception as e:
            print(f"  ✗ VLM API ({str(e)[:50]})")

        try:
            r = requests.get("http://localhost:20023/health", timeout=5)
            if r.status_code == 200:
                print("  ✓ SAM 3.1")
            else:
                print("  ✗ SAM 3.1")
                self.services_ok = False
        except:
            print("  ✗ SAM 3.1")
            self.services_ok = False

    # ================================================================
    # 逐帧处理（pipeline_steps.process_frame）
    # ================================================================

    def has_more_frames(self) -> bool:
        return self.frame_idx < len(self.depth_files)

    def process_one_frame(self) -> Optional[dict]:
        result = process_frame(
            builder=self.builder,
            tracker=self.tracker,
            adapter=self.adapter,
            poses=self.poses,
            file_to_pose=self.file_to_pose,
            depth_files=self.depth_files,
            frame_idx=self.frame_idx,
            pcfg=self.pcfg,
            state=self.state,
            services_ok=self.services_ok,
            vlm_ok=self.vlm_ok,
            total_frames=len(self.depth_files),
        )
        if result is not None:
            self.frame_idx += 1
        else:
            self.frame_idx += 1
        return result

    # ================================================================
    # 后处理（pipeline_steps.run_postprocessing）
    # ================================================================

    def run_post_processing(self, is_final: bool = False) -> Optional[dict]:
        """离线后处理，pipeline_steps.run_postprocessing"""
        scene_graph = run_postprocessing(
            builder=self.builder,
            tracker=self.tracker,
            poses=self.poses,
            pcfg=self.pcfg,
            state=self.state,
            output_dir=self.output_dir,
            is_final=is_final,
        )
        # 后处理生成 scene_graph，增量跑环境描述
        if scene_graph is not None and self.pcfg.environment_description_enabled:
            self.run_environment_descriptions(scene_graph)
        return scene_graph

    # ================================================================
    # 增量环境描述（每 batch 只对新/更新的物体调 VLM）
    # ================================================================

    def run_environment_descriptions(self, scene_graph: dict) -> None:
        """
        对 scene_graph 中的物体增量生成环境描述

        obj_name + last_seen_frame:
        - 新物体（不在 last_described ）-> 生成
        - 旧物体但 last_seen_frame 变了 -> 更新
        - 旧物体且 last_seen_frame 没变 -> 跳过
        """
        from global_reconstruction.reconstruction.reconstruct_and_segment import (
            annotate_scene_graph_with_environment_descriptions,
        )

        objects = scene_graph.get('objects', [])
        if not objects:
            return

        to_describe = []
        skipped = 0
        for obj in objects:
            name = obj.get('name', '')
            last_seen = obj.get('last_seen_frame', '') or obj.get('representative_frame', '')
            prev_seen = self.last_described.get(name)
            if prev_seen is None or last_seen != prev_seen:
                to_describe.append(name)
            else:
                skipped += 1

        if not to_describe:
            print(f"  环境描述: {len(objects)} 个物体均无更新，回填缓存描述")
        else:
            print(f"  环境描述: {len(to_describe)} 个物体需要描述（新/更新），{skipped} 个跳过")

        cache_file = self.output_dir / "object_environment_descriptions.json"
        for obj in objects:
            name = obj.get('name', '')
            if name in to_describe:
                # 删除该物体的缓存条目，重新生成
                from global_reconstruction.reconstruction.reconstruct_and_segment import build_object_environment_cache_key
                cat = str(obj.get('category', '')).lower()
                if cat == 'floor':
                    key = "floor_" + build_object_environment_cache_key(obj)
                elif cat in ('person', 'people', 'human'):
                    key = "person_" + build_object_environment_cache_key(obj)
                else:
                    key = build_object_environment_cache_key(obj)
                self._env_desc_cache.pop(key, None)

        scene_graph, floor_results, person_results = annotate_scene_graph_with_environment_descriptions(
            scene_graph,
            cache_file=cache_file,
            max_images=self.cfg.object_segmentation.get('environment_description_max_images', 5),
        )

        # 更新 last_described
        for obj in scene_graph.get('objects', []):
            name = obj.get('name', '')
            last_seen = obj.get('last_seen_frame', '') or obj.get('representative_frame', '')
            self.last_described[name] = last_seen

        # 重新保存 scene_graph
        import json
        sg_file = self.output_dir / "scene_graph.json"
        with open(sg_file, 'w') as f:
            json.dump(scene_graph, f, indent=2, default=str)
        print(f"  环境描述完成，scene_graph 已更新")

    # ================================================================
    # 检查点
    # ================================================================

    def save_checkpoint(self) -> Path:
        """保存检查点（融合图 + tracker + 进度 + VLM 上下文）"""
        # 融合图
        fusion_path = self.checkpoint_dir / "fusion_state.npz"
        if self.builder.fusion_map is not None:
            self.builder.fusion_map.save_state(fusion_path)

        # tracker
        tracker_path = self.checkpoint_dir / "tracker_state.npz"
        self.tracker.save_state(tracker_path)

        # 元数据
        meta = {
            'data_dir': str(self.adapter.data_dir),
            'output_dir': str(self.output_dir),
            'frame_idx': self.frame_idx,
            'num_frames_processed': self.state.num_frames_processed,
            'num_objects_detected': self.state.num_objects_detected,
            'num_detection_frames': self.state.num_detection_frames,
            'num_vlm_detections': self.state.num_vlm_detections,
            'discovered_categories': self.state.discovered_categories,
            '_last_vlm_pos': self.state.last_vlm_pos.tolist() if self.state.last_vlm_pos is not None else None,
            '_last_vlm_dir': self.state.last_vlm_dir.tolist() if self.state.last_vlm_dir is not None else None,
            'last_described': self.last_described,
        }
        meta_path = self.checkpoint_dir / "checkpoint.json"
        tmp_path = meta_path.with_suffix('.json.tmp')
        with open(tmp_path, 'w') as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)
        os.replace(tmp_path, meta_path)

        print(f"  检查点已保存: {self.checkpoint_dir} (frame_idx={self.frame_idx})")
        return self.checkpoint_dir

    # ================================================================
    # 调度
    # ================================================================

    def run(self, max_frames: Optional[int] = None, batch_size: int = 50,
            postprocess_every_batches: int = 2, watch: bool = False,
            poll_seconds: float = 1.0) -> None:
        """
        运行增量重建

        Args:
            max_frames: 本次最多处理多少帧（None=处理到末尾）
            batch_size: 每批处理多少帧后存检查点
            postprocess_every_batches: 每 K 个 batch 在 batch 边界触发一次后处理
            watch: True=监听新数据（流式），False=处理现有数据后停止
            poll_seconds: watch 模式轮询间隔
        """
        processed_this_run = 0
        batches_done = 0

        while self.has_more_frames():
            if max_frames is not None and processed_this_run >= max_frames:
                print(f"\n达到本次上限 {max_frames} 帧，暂停。")
                break

            # 处理一批
            batch_count = 0
            remaining = min(batch_size,
                            max_frames - processed_this_run if max_frames else batch_size)
            pbar = tqdm(total=remaining, desc=f"批次处理 (从 frame {self.frame_idx})")
            while batch_count < batch_size and self.has_more_frames():
                if max_frames is not None and processed_this_run >= max_frames:
                    break
                self.process_one_frame()
                batch_count += 1
                processed_this_run += 1
                pbar.update(1)
            pbar.close()
            batches_done += 1

            # 每 K 个 batch 在 batch 边界触发后处理（中间结果）
            if postprocess_every_batches > 0 and batches_done % postprocess_every_batches == 0:
                print(f"\n[后处理] 第 {batches_done} 个 batch (frame {self.frame_idx})...")
                self.run_post_processing(is_final=False)
            self.save_checkpoint()

            if not self.has_more_frames():
                if watch:
                    print(f"\n等待新数据 (轮询 {poll_seconds}s)...")
                    time.sleep(poll_seconds)
                    self.depth_files = self.adapter.get_depth_file_list(max_frames=100000)
                    if not self.has_more_frames():
                        print("无新数据，退出。")
                        break
                else:
                    print(f"\n所有帧处理完毕。")
                    break

        # 最终后处理（自动判定 is_final：所有帧跑完且非 watch）
        if processed_this_run > 0:
            is_final = (not self.has_more_frames()) and (not watch)
            print(f"\n[{'最终' if is_final else '中间'}后处理]...")
            self.run_post_processing(is_final=is_final)
            self.save_checkpoint()

        print_timing_summary(self.state)

    # ================================================================
    # 耗时统计
    # ================================================================

    def print_timing_summary(self) -> None:
        print_timing_summary(self.state)
