"""
逐帧处理 + 后处理
  - process_frame: 单帧处理
  - run_postprocessing: 后处理（合并/对齐/房间分割/scene graph）

两个状态容器:
  - PipelineConfig: 从 cfg 提取
  - FrameState: 逐帧可变状态（VLM 上下文/计数/计时）
"""

from __future__ import annotations

import base64
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
from tqdm import tqdm


# ===========================================================================
# 状态容器
# ===========================================================================

@dataclass
class PipelineConfig:
    """全局常量"""

    voxel_size: float
    skip_frames: int
    depth_min: float
    depth_max: float
    depth_scale: float
    confidence_threshold: float
    object_detection_interval: int
    object_categories: list
    object_min_points: int
    sam3_min_confidence: float
    vlm_keyframe_only: bool
    vlm_kf_baseline_m: float
    vlm_kf_angle_deg: float
    object_tracking_cfg: dict
    merge_categories: list
    object_merge_containment_threshold: float
    object_source_view_limit: int
    vertical_axis: int
    horizontal_axes: list
    trajectory_alignment_enabled: bool
    object_lifecycle_config: dict
    render_video: bool
    render_fps: int
    render_every: int
    render_point_size: int
    render_max_depth: float
    vis_viz_enabled: bool
    vis_viz_cfg: dict
    vlm_max_history: int
    vlm_history_thumb_size: tuple
    per_frame_timing_print: bool
    output_dir: Path
    object_view_output_dir: Path
    data_dir_name: str
    tsdf_enabled: bool
    fusion_enabled: bool
    environment_description_enabled: bool

    @classmethod
    def from_cfg(cls, cfg) -> "PipelineConfig":
        """从 config 提取所有常量"""
        from global_reconstruction.incremental.visibility_visualizer import load_visibility_viz_config

        _TRAJ = cfg.get('trajectory_alignment', {}) or {}
        if _TRAJ.get('enabled', True):
            va, ha = 1, [0, 2]
        else:
            va, ha = 2, [0, 1]

        _vis_viz_cfg = load_visibility_viz_config(cfg)
        _render = cfg.reconstruction.get('render_video', {}) or {}

        return cls(
            voxel_size=cfg.reconstruction.voxel_size,
            skip_frames=cfg.reconstruction.skip_frames,
            depth_min=cfg.reconstruction.depth_min,
            depth_max=cfg.reconstruction.depth_max,
            depth_scale=cfg.reconstruction.depth_scale,
            confidence_threshold=getattr(cfg.reconstruction, 'confidence_threshold', 0.0),
            object_detection_interval=cfg.object_segmentation.detection_interval,
            object_categories=cfg.object_segmentation.categories,
            object_min_points=cfg.object_segmentation.min_points,
            sam3_min_confidence=cfg.object_segmentation.get('sam3_min_confidence', 0.55),
            vlm_keyframe_only=cfg.object_segmentation.get('vlm_keyframe_only', True),
            vlm_kf_baseline_m=cfg.object_segmentation.get('vlm_kf_baseline_m', 0.1),
            vlm_kf_angle_deg=cfg.object_segmentation.get('vlm_kf_angle_deg', 15.0),
            object_tracking_cfg=dict(cfg.get('object_tracking', {})),
            merge_categories=cfg.object_segmentation.merge_categories,
            object_merge_containment_threshold=cfg.object_segmentation.get('merge_containment_threshold', 0.50),
            object_source_view_limit=cfg.object_segmentation.source_view_limit,
            vertical_axis=va,
            horizontal_axes=ha,
            trajectory_alignment_enabled=bool(_TRAJ.get('enabled', True)),
            object_lifecycle_config=dict(cfg.get('object_lifecycle', {})),
            render_video=bool(_render.get('enabled', False)),
            render_fps=int(_render.get('fps', 15)),
            render_every=int(_render.get('every', 5)),
            render_point_size=int(_render.get('point_size', 1)),
            render_max_depth=float(_render.get('max_depth', 15.0)),
            vis_viz_enabled=_vis_viz_cfg['enabled'],
            vis_viz_cfg=_vis_viz_cfg,
            vlm_max_history=3,
            vlm_history_thumb_size=(512, 384),
            per_frame_timing_print=True,
            output_dir=Path(cfg.output.base_dir),
            object_view_output_dir=Path(cfg.output.base_dir) / cfg.output.get('object_views_dir', 'object_views'),
            data_dir_name=str(cfg.data.default_dir).split('/')[-1],
            tsdf_enabled=bool(cfg.reconstruction.get('tsdf', {}).get('enabled', False)),
            fusion_enabled=bool(cfg.reconstruction.get('fusion', {}).get('enabled', True)),
            environment_description_enabled=bool(cfg.object_segmentation.get('environment_description_enabled', False)),
        )


@dataclass
class FrameState:
    """逐帧可变状态"""

    # VLM 上下文
    discovered_categories: dict = field(default_factory=dict)
    detection_history_images: list = field(default_factory=list)
    last_vlm_pos: Optional[np.ndarray] = None
    last_vlm_dir: Optional[np.ndarray] = None
    # 进度计数
    num_frames_processed: int = 0
    num_objects_detected: int = 0
    num_detection_frames: int = 0
    num_vlm_detections: int = 0
    sam3_disk_size: Optional[tuple] = None
    # 视频渲染
    video_renderer: Any = None
    video_frame_count: int = 0
    # 耗时统计
    timing_totals: dict = field(default_factory=lambda: {k: 0.0 for k in ['total', 'voxel', 'vlm', 'sam3', 'visibility', 'tracker', 'other']})
    timing_detect: dict = field(default_factory=lambda: {k: 0.0 for k in ['total', 'voxel', 'vlm', 'sam3', 'visibility', 'tracker', 'other']})
    timing_pconly: dict = field(default_factory=lambda: {k: 0.0 for k in ['total', 'voxel', 'vlm', 'sam3', 'visibility', 'tracker', 'other']})
    timing_n_all: int = 0
    timing_n_detect: int = 0
    timing_n_pconly: int = 0

    @classmethod
    def initial(cls, static_library: list) -> "FrameState":
        """创建初始状态（static_library 为 VLM 静态语料库）。"""
        return cls(discovered_categories={cat: 1 for cat in static_library})


# ===========================================================================
# 逐帧处理
# ===========================================================================

def process_frame(
    builder,
    tracker,
    adapter,
    poses: dict,
    file_to_pose: dict,
    depth_files: list,
    frame_idx: int,
    pcfg: PipelineConfig,
    state: FrameState,
    services_ok: bool,
    vlm_ok: bool,
    total_frames: Optional[int] = None,
) -> Optional[dict]:
    """
    处理单帧

    修改 state（更新计数/VLM 上下文/计时），返回计时 dict 或 None（跳过）
    不递增 frame_idx
    """
    from global_reconstruction.reconstruction.reconstruct_and_segment import (
        vlm_detect_objects, sam3_segment_batch, mask_to_3d_points,
        create_object_grounded_views, IncrementalVideoRenderer,
    )
    from global_reconstruction.incremental.visibility_visualizer import (
        filter_visible_objects, visualize_visibility,
    )
    from global_reconstruction.incremental.object_state_detector import detect_object_states

    if frame_idx >= len(depth_files):
        return None

    i = frame_idx
    depth_file = depth_files[i]

    process_pointcloud = (i % pcfg.skip_frames == 0)
    detect_objects = (i % pcfg.object_detection_interval == 0)
    if not process_pointcloud and not detect_objects:
        return None

    timestamp_str = depth_file.stem
    if timestamp_str not in file_to_pose:
        return None
    pose_timestamp = file_to_pose[timestamp_str]
    if pose_timestamp not in poses:
        return None

    _t0 = time.perf_counter()
    _t_voxel = _t_vlm = _t_sam3 = _t_vis = _t_trk = 0.0
    _t_trk_gv = 0.0

    # 读数据
    depth = adapter.load_depth(depth_file, target_resolution=adapter.rgb_resolution)
    if depth is None:
        return None
    if depth.dtype == np.uint16:
        depth = depth.astype(np.float32) / pcfg.depth_scale
    elif depth.dtype == np.uint8:
        depth = depth.astype(np.float32)
    depth = np.where(np.isfinite(depth), depth, 0.0).astype(np.float32)

    color_file = adapter.match_color_file(timestamp_str)
    if color_file is None:
        return None
    color = adapter.load_color(color_file)
    if color is None:
        return None
    if color.shape[:2] != depth.shape:
        color = cv2.resize(color, (depth.shape[1], depth.shape[0]))

    confidence = None
    if pcfg.confidence_threshold > 0:
        confidence = adapter.load_confidence(i)

    T_c2w = poses[pose_timestamp]
    K_frame = adapter.get_K_for_frame(i)

    # 全局点云融合
    if process_pointcloud:
        _t_a = time.perf_counter()
        builder.integrate_frame(depth, color, K_frame, T_c2w, confidence, timestamp_str)
        _t_voxel = time.perf_counter() - _t_a

        if pcfg.render_video:
            if state.video_renderer is None:
                state.video_renderer = IncrementalVideoRenderer(
                    output_path=str(pcfg.output_dir / "global" / f"reconstruction_{pcfg.data_dir_name}.mp4"),
                    fps=pcfg.render_fps, point_size=pcfg.render_point_size,
                    max_depth=pcfg.render_max_depth)
                state.video_renderer.init(color.shape, depth.shape)
            state.video_frame_count += 1
            if state.video_frame_count % pcfg.render_every == 0:
                cur_pts, cur_cols = builder.get_current_cloud()
                if len(cur_pts) > 0:
                    color_bgr = cv2.cvtColor(color, cv2.COLOR_RGB2BGR) if color.ndim == 3 else color
                    state.video_renderer.render_frame(
                        color_bgr, cur_pts, cur_cols, T_c2w, K_frame,
                        state.video_frame_count, total_frames or 0)

    # 物体检测 + 跟踪
    if detect_objects and services_ok:
        state.num_detection_frames += 1

        # VLM 关键帧门控
        _cam_fwd = T_c2w[:3, :3][:, 2]
        _cam_pos = T_c2w[:3, 3]
        if pcfg.vlm_keyframe_only:
            _is_vlm_kf = state.last_vlm_pos is None
            if not _is_vlm_kf and pcfg.vlm_kf_baseline_m > 0:
                _is_vlm_kf = float(np.linalg.norm(_cam_pos - state.last_vlm_pos)) >= pcfg.vlm_kf_baseline_m
            if not _is_vlm_kf and pcfg.vlm_kf_angle_deg > 0 and state.last_vlm_dir is not None:
                _cos_a = float(np.clip(np.dot(_cam_fwd, state.last_vlm_dir), -1.0, 1.0))
                _is_vlm_kf = float(np.degrees(np.arccos(_cos_a))) >= pcfg.vlm_kf_angle_deg
        else:
            _is_vlm_kf = True

        if vlm_ok and _is_vlm_kf:
            _t_a = time.perf_counter()
            _thumb = cv2.resize(color, pcfg.vlm_history_thumb_size, interpolation=cv2.INTER_AREA)
            _, _thumb_buf = cv2.imencode('.jpg', _thumb, [cv2.IMWRITE_JPEG_QUALITY, 80])
            _thumb_b64 = base64.b64encode(_thumb_buf.tobytes()).decode('utf-8')
            state.detection_history_images.append((str(color_file), _thumb_b64))
            if len(state.detection_history_images) > pcfg.vlm_max_history:
                state.detection_history_images = state.detection_history_images[-pcfg.vlm_max_history:]
            history_for_vlm = state.detection_history_images[:-1] if len(state.detection_history_images) > 1 else None

            detected_objects = vlm_detect_objects(color_file, state.discovered_categories, history_images=history_for_vlm)
            _t_vlm = time.perf_counter() - _t_a
            state.num_vlm_detections += 1
            state.last_vlm_pos = _cam_pos.copy()
            state.last_vlm_dir = np.asarray(_cam_fwd, dtype=np.float64).copy()
            for obj in detected_objects:
                cat = obj['category']
                state.discovered_categories[cat] = state.discovered_categories.get(cat, 0) + 1
            categories_to_detect = list(set([obj['category'] for obj in detected_objects]))
            if 'floor' not in categories_to_detect:
                categories_to_detect.append('floor')
                detected_objects.append({'category': 'floor'})
        else:
            detected_objects = []
            categories_to_detect = []

        # 历史快照
        _t_a = time.perf_counter()
        _snapshot_objects = tracker.snapshot_records(pcfg.object_tracking_cfg)
        _t_trk += time.perf_counter() - _t_a

        # expected 类别
        _t_a = time.perf_counter()
        expected_categories = set()
        if _snapshot_objects:
            T_w2c = np.linalg.inv(T_c2w)
            fx, fy = K_frame[0, 0], K_frame[1, 1]
            cx, cy = K_frame[0, 2], K_frame[1, 2]
            h, w = depth.shape[:2]
            for hist_obj in _snapshot_objects:
                pts = hist_obj['points']
                if len(pts) == 0:
                    continue
                cat = hist_obj.get('category', '')
                if cat in {'floor', 'wall', 'ceiling'}:
                    continue
                pts_hom = np.hstack([pts, np.ones((len(pts), 1))])
                pts_cam = (T_w2c @ pts_hom.T).T[:, :3]
                in_front = pts_cam[:, 2] > 0.1
                pts_in_front = pts_cam[in_front]
                if len(pts_in_front) == 0:
                    continue
                z = pts_in_front[:, 2]
                u = (pts_in_front[:, 0] * fx / z + cx).astype(np.int32)
                v = (pts_in_front[:, 1] * fy / z + cy).astype(np.int32)
                in_image = (u >= 0) & (u < w) & (v >= 0) & (v < h)
                visible_ratio = float(np.sum(in_image)) / len(pts)
                if visible_ratio >= 0.20:
                    expected_categories.add(cat)
        _t_vis += time.perf_counter() - _t_a

        # SAM3 批量分割
        batch_prompts = []
        seen = set()
        for cat in pcfg.object_categories:
            if cat not in seen:
                batch_prompts.append((cat, cat))
                seen.add(cat)
        for obj_info in detected_objects:
            category = obj_info['category']
            sam3_text = obj_info.get('sam3_prompt', category)
            if category not in seen:
                batch_prompts.append((category, sam3_text))
                seen.add(category)
        for cat in expected_categories:
            if cat not in seen:
                batch_prompts.append((cat, cat))
                seen.add(cat)
                print(f"          + 补充历史物体类别：{cat}")

        _t_a = time.perf_counter()
        batch_results = sam3_segment_batch(color_file, batch_prompts)
        _t_sam3 = time.perf_counter() - _t_a

        orig_h, orig_w = color.shape[:2]
        if state.sam3_disk_size is None:
            _orig_sample = cv2.imread(str(color_file))
            state.sam3_disk_size = _orig_sample.shape[:2] if _orig_sample is not None else (orig_h, orig_w)
        _sam3_orig_h, _sam3_orig_w = state.sam3_disk_size
        _need_resize = (_sam3_orig_h != orig_h or _sam3_orig_w != orig_w)
        _sx, _sy = (orig_w / _sam3_orig_w, orig_h / _sam3_orig_h) if _need_resize else (1.0, 1.0)

        current_frame_detections = []
        for (category, sam3_text), detections in zip(batch_prompts, [batch_results.get(t, []) for _, t in batch_prompts]):
            if not detections:
                continue
            for _det in detections:
                current_frame_detections.append({
                    'mask': _det.get('mask'), 'category': category, 'score': _det.get('score', 0)})

        # 可见性可视化
        if pcfg.vis_viz_enabled:
            _t_a = time.perf_counter()
            _viz_dir = pcfg.output_dir / "visibility_viz"
            _color_bgr = cv2.cvtColor(color, cv2.COLOR_RGB2BGR)
            _merged_objects = _snapshot_objects
            _visible_items, _vis_records = filter_visible_objects(
                all_objects=_merged_objects, K=K_frame, T_c2w=T_c2w, depth=depth,
                max_distance=pcfg.vis_viz_cfg['max_distance'], min_visible_ratio=0.20,
                dead_object_indices=None)
            _STRUCTURAL_CATS = frozenset({'floor', 'wall', 'ceiling'})
            _visible_non_structural = [obj for _, obj in _visible_items if obj.get('category', '') not in _STRUCTURAL_CATS]
            _state_results_for_viz = None
            if pcfg.vis_viz_cfg.get('state_detection_enabled', False):
                _T_w2c = np.linalg.inv(T_c2w)
                _state_results = detect_object_states(
                    merged_objects=_visible_non_structural, K=K_frame, T_w2c=_T_w2c,
                    depth_map=depth, max_distance=pcfg.vis_viz_cfg['max_distance'],
                    depth_tolerance=pcfg.vis_viz_cfg['depth_tolerance'],
                    min_valid_samples=pcfg.vis_viz_cfg['min_valid_samples'],
                    persist_ratio=pcfg.vis_viz_cfg['persist_ratio_threshold'],
                    valid_ratio_threshold=pcfg.vis_viz_cfg['valid_ratio_threshold'],
                    depth_min=pcfg.depth_min, depth_max=pcfg.depth_max,
                    confidence_map=confidence, confidence_threshold=pcfg.confidence_threshold)
                _n_persist = sum(1 for sf in _state_results if sf['state'].value == 'persisting')
                _n_occl = sum(1 for sf in _state_results if sf['state'].value == 'occluded')
                _n_disp = sum(1 for sf in _state_results if sf['state'].value == 'disappeared')
                _n_unk = sum(1 for sf in _state_results if sf['state'].value == 'unknown')
                print(f"       状态检测（非结构物体）：持续={_n_persist} 遮挡={_n_occl} 消失={_n_disp} 未知={_n_unk} / 总={len(_state_results)}")
                _visible_merged_indices = [idx for idx, _ in _visible_items if _merged_objects[idx].get('category', '') not in _STRUCTURAL_CATS]
                _state_results_for_viz = []
                for _sf in _state_results:
                    _vis_non_struct_idx = _sf['obj_idx']
                    if _vis_non_struct_idx < len(_visible_merged_indices):
                        _merged_obj_idx = _visible_merged_indices[_vis_non_struct_idx]
                        _state_results_for_viz.append({'obj_idx': _merged_obj_idx, 'state': _sf['state'].value})
            _viz_path, _num_visible, _vis_records = visualize_visibility(
                color_bgr=_color_bgr, K=K_frame, T_c2w=T_c2w, depth=depth,
                all_objects=_merged_objects, current_detections=current_frame_detections,
                frame_id=timestamp_str, output_dir=_viz_dir,
                point_size=pcfg.vis_viz_cfg['point_size'], mask_alpha=pcfg.vis_viz_cfg['mask_alpha'],
                max_points_per_obj=pcfg.vis_viz_cfg['max_points_per_obj'],
                max_distance=pcfg.vis_viz_cfg['max_distance'],
                state_results=_state_results_for_viz, dead_object_indices=None)
            print(f"      📊 可见性可视化：{_viz_path.name} "
                  f"(可见={_num_visible}/{len(_merged_objects)}, 检测={len(current_frame_detections)})")
            _t_vis += time.perf_counter() - _t_a

        # 检测构建 + tracker 更新
        _t_a = time.perf_counter()
        _tracker_detections = []
        for (category, sam3_text), detections in zip(batch_prompts, [batch_results.get(t, []) for _, t in batch_prompts]):
            if not detections:
                continue
            for mask_data in detections:
                points_3d = mask_to_3d_points(mask_data['mask'], depth, K_frame, T_c2w, confidence, pcfg.confidence_threshold)
                if len(points_3d) <= pcfg.object_min_points:
                    continue
                grounded_box = mask_data.get('box')
                grounded_mask = mask_data.get('mask')
                if _need_resize:
                    if grounded_box is not None:
                        grounded_box = [int(grounded_box[0]*_sx), int(grounded_box[1]*_sy),
                                        int(grounded_box[2]*_sx), int(grounded_box[3]*_sy)]
                    if grounded_mask is not None:
                        grounded_mask = cv2.resize(grounded_mask.astype(np.float32), (orig_w, orig_h),
                                                   interpolation=cv2.INTER_NEAREST).astype(np.uint8)
                grounded_view = create_object_grounded_views(
                    image_path=color_file, image_rgb=color, frame=timestamp_str,
                    category=category, object_index=len(_tracker_detections),
                    box=grounded_box, mask=grounded_mask, score=mask_data.get('score'))
                _tracker_detections.append({
                    'category': category, 'points_3d': points_3d,
                    'source_view': grounded_view, 'image_path': str(color_file),
                    'score': float(mask_data.get('score', 0.0) or 0.0)})
        _t_trk_gv = time.perf_counter() - _t_a

        _t_a = time.perf_counter()
        _trk_res = tracker.update_frame(
            detections=_tracker_detections, depth=depth, color=color,
            K=K_frame, T_c2w=T_c2w, confidence=confidence,
            conf_threshold=pcfg.confidence_threshold, frame_id=timestamp_str)
        _t_trk = _t_trk_gv + (time.perf_counter() - _t_a)
        state.num_objects_detected += _trk_res['n_new']
        if _trk_res['n_new'] > 0 and state.num_objects_detected <= 8:
            print(f"          ✓ tracker: 新建 {_trk_res['n_new']} / 匹配 {_trk_res['n_matched']} / 存活 {_trk_res['n_alive']}")

    # 计时汇总
    _t_total = time.perf_counter() - _t0
    _t_other = max(0.0, _t_total - _t_voxel - _t_vlm - _t_sam3 - _t_vis - _t_trk)
    _is_detect_frame = detect_objects and services_ok
    _row = {'total': _t_total, 'voxel': _t_voxel, 'vlm': _t_vlm,
            'sam3': _t_sam3, 'visibility': _t_vis, 'tracker': _t_trk, 'other': _t_other}
    for _k, _v in _row.items():
        state.timing_totals[_k] += _v
    state.timing_n_all += 1
    if _is_detect_frame:
        for _k, _v in _row.items():
            state.timing_detect[_k] += _v
        state.timing_n_detect += 1
        if pcfg.per_frame_timing_print:
            print(f"   ⏱ frame {i:04d} total={_t_total*1000:6.1f}ms "
                  f"voxel={_t_voxel*1000:6.1f} vlm={_t_vlm*1000:6.1f} "
                  f"sam3={_t_sam3*1000:6.1f} vis={_t_vis*1000:6.1f} "
                  f"trk={_t_trk*1000:6.1f}(gv={_t_trk_gv*1000:5.0f}) other={_t_other*1000:6.1f}")
    else:
        for _k, _v in _row.items():
            state.timing_pconly[_k] += _v
        state.timing_n_pconly += 1

    state.num_frames_processed += 1
    return _row


# ===========================================================================
# 后处理
# ===========================================================================

def run_postprocessing(
    builder,
    tracker,
    poses: dict,
    pcfg: PipelineConfig,
    state: FrameState,
    output_dir: Path,
    is_final: bool = False,
) -> Optional[dict]:
    """
    后处理（合并/对齐/房间分割/scene graph）

    返回 scene_graph dict，或 None（点云为空）
    """
    from global_reconstruction.reconstruction.reconstruct_and_segment import (
        merge_and_number_objects, save_final_object_lifecycle,
        filter_by_stable_voxel_count,
        align_to_trajectory_plane, segment_floor_levels,
        save_point_cloud, build_scene_graph,
    )
    from global_reconstruction.segmentation.segment_rooms import segment_rooms, save_rooms

    # 1. 导出物体
    all_objects = tracker.records(None, pcfg.object_tracking_cfg)
    print(f"\n  tracker 存活实例：{len(all_objects)} 个")
    _n_stable = sum(1 for o in all_objects if o.get('state') == 'STABLE')
    _n_cand = sum(1 for o in all_objects if o.get('state') == 'CANDIDATE')
    print(f"  其中 STABLE={_n_stable}, CANDIDATE={_n_cand}")

    final_id_counter = 0
    for obj in all_objects:
        obj['_final_id'] = f'F{final_id_counter}'
        final_id_counter += 1

    if is_final:
        _lifecycle_dir = output_dir / "lifecycle"
        tracker.save(_lifecycle_dir)
        print(f"  生命周期数据已保存：{_lifecycle_dir}")

    # 2. 全局点云
    if not builder.build(output_dir):
        print("  点云为空，跳过后处理")
        return None
    global_points = builder.global_points
    global_colors = builder.global_colors

    global_pcd_file = output_dir / "global" / "global_pointcloud.ply"

    # 3. 轨迹对齐
    (global_points, _stable_raw, _complete_raw, _complete_denoised,
     R_align, R_align_inv) = align_to_trajectory_plane(
        poses, global_points, None, None, None, all_objects)

    save_point_cloud(global_pcd_file, global_points, global_colors)
    print(f"  ✓ 已保存全局点云: {global_pcd_file}")

    # 4. 合并 + 编号
    final_objects = merge_and_number_objects(all_objects)

    # 5. 最终生命周期（仅最终后处理写，中间 batch 跳过）
    if is_final:
        save_final_object_lifecycle(final_objects, output_dir)

    # 7. 体素稳定性验证（默认关闭；中间 batch 跳过，仅最终跑）
    if is_final and (pcfg.fusion_enabled and builder.fusion_map is not None
            and pcfg.object_lifecycle_config.get('voxel_stability_filter_enabled', False)):
        stable_objects, removed_objects = builder.filter_objects_by_voxel_stability(
            final_objects,
            min_stable_ratio=pcfg.object_lifecycle_config.get('min_stable_ratio', 0.25),
            R_inv=R_align_inv, merge_categories=pcfg.merge_categories)
        if removed_objects:
            final_objects = stable_objects
    else:
        print("  [5] 体素稳定性验证：已跳过" + ("（中间 batch）" if not is_final else ""))

    # 8. 稳定体素数过滤（仅最终跑；中间 batch 保留所有存活物体，避免小 batch 误杀）
    if is_final:
        _min_vox = int(pcfg.object_lifecycle_config.get('min_stable_voxels', 50))
        final_objects = filter_by_stable_voxel_count(final_objects, _min_vox, pcfg.merge_categories)
    print(f"  最终物体数：{len(final_objects)}" + ("（未过滤）" if not is_final else ""))

    # 9. 保存物体 ply + 视图
    import shutil
    objects_dir = output_dir / "objects"
    objects_dir.mkdir(exist_ok=True)
    for i, obj in enumerate(final_objects):
        colors = np.tile([128, 128, 128], (len(obj['points']), 1))
        save_point_cloud(objects_dir / f"object_{i:04d}_{obj['name']}.ply", obj['points'], colors)
        obj_view_dir = pcfg.object_view_output_dir / obj['name']
        obj_view_dir.mkdir(parents=True, exist_ok=True)
        saved = set()
        for view_idx, source_view in enumerate(obj.get('source_views', [])):
            if not isinstance(source_view, dict):
                continue
            annotated_path = source_view.get('annotated_image')
            if not annotated_path or not Path(annotated_path).exists():
                continue
            frame_key = source_view.get('frame', f'view_{view_idx}')
            if frame_key in saved:
                continue
            saved.add(frame_key)
            src = Path(annotated_path)
            dst = obj_view_dir / f"annotated_{src.stem}_{view_idx:03d}.png"
            shutil.copy2(src, dst)

    # 10. floor/wall 从 tracker 结构单例直接获得
    _trk_floor_pts = None
    _trk_wall_pts = None
    for cat in ['floor', 'wall']:
        inst = tracker.structural.get(cat)
        if inst is None:
            continue
        sv = tracker._structural_voxels.get(cat, {})
        rec = inst.to_record(R_align, pcfg.object_tracking_cfg, None, structural_voxels=sv)
        if len(rec['points']) > 0:
            if cat == 'floor':
                _trk_floor_pts = rec['points']
            else:
                _trk_wall_pts = rec['points']

    # 11. 楼层 + 房间分割
    floor_levels = segment_floor_levels(global_points, global_colors, output_dir)

    all_rooms = []
    for floor_idx, floor_data in enumerate(floor_levels):
        floor_zero_level = floor_data['floor_zero_level']
        room_height = floor_data.get('room_height')

        # floor/wall 优先用 tracker 结构单例；否则回退全局点云高度过滤
        if _trk_floor_pts is not None:
            floor_points = _trk_floor_pts
            floor_colors = np.tile([0.5, 0.5, 0.5], (len(floor_points), 1))
        else:
            height_min = floor_zero_level + 0.3
            height_max = floor_zero_level + 2.5
            sel_mask = (global_points[:, pcfg.vertical_axis] >= height_min) & \
                       (global_points[:, pcfg.vertical_axis] < height_max)
            floor_points = global_points[sel_mask]
            floor_colors = global_colors[sel_mask] if len(global_colors) == len(global_points) else None

        if _trk_wall_pts is not None:
            combined_points = np.vstack([floor_points, _trk_wall_pts])
            wall_colors = np.tile([0.5, 0.5, 0.5], (len(_trk_wall_pts), 1))
            combined_colors = np.vstack([floor_colors, wall_colors]) if floor_colors is not None else wall_colors
        else:
            combined_points = floor_points
            combined_colors = floor_colors

        scene_height = float(global_points[:, pcfg.vertical_axis].max() - floor_zero_level)
        room_save_path = output_dir / "rooms" / f"floor_{floor_idx}"
        rooms = segment_rooms(combined_points, floor_zero_level, room_height=scene_height,
                              save_path=str(room_save_path), floor_colors=combined_colors,
                              vertical_axis=pcfg.vertical_axis, horizontal_axes=pcfg.horizontal_axes,
                              global_points=combined_points, global_colors=combined_colors)
        save_rooms(rooms, str(output_dir / "rooms" / f"floor_{floor_idx}_rooms"))
        for room in rooms:
            room['floor_id'] = floor_idx
            all_rooms.append(room)

    rooms = all_rooms

    # 11. gateway 检测
    from global_reconstruction.reconstruction.reconstruct_and_segment import (
        resample_trajectory, detect_gateways, fit_trajectory_plane_from_poses,
    )
    traj_path = output_dir / "trajectory_resampled.ply"
    trajectory_plane = fit_trajectory_plane_from_poses(poses)
    resample_trajectory(poses, output_dir, trajectory_plane=trajectory_plane)
    detect_gateways(traj_path, floor_levels, global_points, rooms, trajectory_plane, output_dir, force=True)

    # 12. scene graph
    global_pcd = {'points': global_points, 'colors': global_colors}
    merged_info = {'num_frames': state.num_frames_processed, 'detection_frames': state.num_detection_frames}
    scene_graph = build_scene_graph(global_pcd, rooms, final_objects, merged_info, floor_levels)

    scene_graph_file = output_dir / "scene_graph.json"
    import json
    with open(scene_graph_file, 'w') as f:
        json.dump(scene_graph, f, indent=2, default=str)
    print(f"  scene_graph 已保存: {len(final_objects)} 物体, {len(rooms)} 房间")

    # 13. 导出分层场景图 (visualize_graph_html.py)
    from global_reconstruction.reconstruction.reconstruct_and_segment import export_hierarchical_graph
    export_hierarchical_graph(output_dir, floor_levels, rooms, final_objects, scene_graph)

    return scene_graph


# ===========================================================================
# 耗时统计打印
# ===========================================================================

def print_timing_summary(state: FrameState) -> None:
    _TIMING_KEYS = ['total', 'voxel', 'vlm', 'sam3', 'visibility', 'tracker', 'other']
    def _fmt(totals, n):
        if n <= 0:
            return "  (无)"
        return "  ".join(f"{k}={totals[k]*1000/n:6.1f}" for k in _TIMING_KEYS)
    print("\n" + "=" * 70)
    print("[耗时统计] 逐帧各步耗时均值 (ms)")
    print("=" * 70)
    print(f"  检测帧   (n={state.timing_n_detect:4d}):" + _fmt(state.timing_detect, state.timing_n_detect))
    print(f"  纯点云帧 (n={state.timing_n_pconly:4d}):" + _fmt(state.timing_pconly, state.timing_n_pconly))
    print("=" * 70)
    print(f"  处理帧数：{state.num_frames_processed}")
    print(f"  检测帧数：{state.num_detection_frames}")
    print(f"  VLM 检测次数：{state.num_vlm_detections}")
    print(f"  检测到物体实例：{state.num_objects_detected}")
