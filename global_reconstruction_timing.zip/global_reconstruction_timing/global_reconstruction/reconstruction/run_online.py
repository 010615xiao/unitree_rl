#!/usr/bin/env python3
"""
在线增量重建入口

用法::

    # 首次运行（处理 200 帧后暂停）
    python -m global_reconstruction.reconstruction.run_online --max-frames 200

    # 继续（从检查点恢复）
    python -m global_reconstruction.reconstruction.run_online --resume

    # 流式监听新数据
    python -m global_reconstruction.reconstruction.run_online --watch

    # 跨数据集续跑（保留已建地图，从新数据集第 0 帧继续融合；需同一坐标系/原点）
    python -m global_reconstruction.reconstruction.run_online --resume --data-dir datasets/itof_0726_ep0016
"""

import argparse
import os
from pathlib import Path

from global_reconstruction.core.config_loader import get_config, project_root
from global_reconstruction.reconstruction.online_reconstructor import OnlineReconstructor


def main():
    cfg = get_config()
    online_cfg = cfg.get('online_reconstruction', {}) or {}

    parser = argparse.ArgumentParser(description="在线增量 3D 场景重建")
    parser.add_argument('--data-dir', type=str, default=None, help='数据集目录（默认 config.yaml 的 default_dir）')
    parser.add_argument('--output', type=str, default=None, help='输出目录（默认 config.yaml 的 base_dir）')
    parser.add_argument('--checkpoint', type=str, default=None, help='检查点目录（默认 <output>/checkpoint）')
    parser.add_argument('--max-frames', type=int, default=None, help='本次最多处理多少帧（None=处理到末尾）')
    parser.add_argument('--batch-size', type=int, default=online_cfg.get('batch_size', 50), help='每批帧数（存检查点)')
    parser.add_argument('--postprocess-every-batches', type=int, default=online_cfg.get('postprocess_every_batches', 2), help='每 K 个 batch 触发一次后处理（对齐 batch 边界）')
    parser.add_argument('--watch', action='store_true', default=online_cfg.get('watch', False), help='监听新数据（流式模式）')
    parser.add_argument('--poll-seconds', type=float, default=online_cfg.get('poll_seconds', 1.0), help='watch 模式轮询间隔')
    parser.add_argument('--resume', action='store_true', help='从检查点恢复')
    parser.add_argument('--postprocess-only', action='store_true',
                        help='从检查点恢复后重跑后处理（导出 hierarchical_graph/scene_graph）')
    args = parser.parse_args()

    BASE_DIR = project_root()
    OUTPUT_DIR = BASE_DIR / cfg.output.base_dir
    DATA_DIR = Path(args.data_dir) if args.data_dir else Path(cfg.data.default_dir)
    output_dir = Path(args.output) if args.output else OUTPUT_DIR
    checkpoint_dir = Path(args.checkpoint) if args.checkpoint else output_dir / "checkpoint"

    os.environ['GLOBAL_RECON_DATA_DIR'] = str(DATA_DIR)

    print("=" * 70)
    print("在线增量 3D 场景重建")
    print("=" * 70)
    print(f"  数据目录: {DATA_DIR}")
    print(f"  输出目录: {output_dir}")
    print(f"  检查点: {checkpoint_dir}")

    if args.resume or args.postprocess_only:
        print("\n[恢复] 从检查点加载...")
        # --resume 时若指定 --data-dir 且与检查点不同 → 跨数据集续跑（frame_idx 归零）；
        # --postprocess-only 只重跑后处理，不切换数据集
        resume_data_dir = args.data_dir if args.resume else None
        recon = OnlineReconstructor.load_checkpoint(checkpoint_dir, data_dir=resume_data_dir)
    else:
        print("\n[初始化] 创建重建器...")
        recon = OnlineReconstructor.from_config(cfg, DATA_DIR, output_dir, checkpoint_dir)

    print("\n[0] 检查服务...")
    recon.check_services()

    if args.postprocess_only:
        print("\n[后处理] 仅重跑后处理（导出 hierarchical_graph / scene_graph 等），不处理新帧...")
        recon.run_post_processing(is_final=True)
        recon.save_checkpoint()
        print(f"\n完成。输出: {output_dir}")
        print(f"可视化: python visualize_graph_html.py {output_dir / 'hierarchical_graph'}")
        return

    print(f"\n[运行] max_frames={args.max_frames}, batch_size={args.batch_size}, "
          f"postprocess_every_batches={args.postprocess_every_batches}, watch={args.watch}")
    recon.run(
        max_frames=args.max_frames,
        batch_size=args.batch_size,
        postprocess_every_batches=args.postprocess_every_batches,
        watch=args.watch,
        poll_seconds=args.poll_seconds,
    )

    print(f"\n完成。输出: {output_dir}")
    print(f"检查点: {checkpoint_dir} (frame_idx={recon.frame_idx})")
    print(f"下次继续: python -m global_reconstruction.reconstruction.run_online --resume")


if __name__ == '__main__':
    main()
