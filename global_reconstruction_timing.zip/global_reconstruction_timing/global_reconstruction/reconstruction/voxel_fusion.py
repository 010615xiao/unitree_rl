"""Sparse voxel fusion for RGB-D point cloud reconstruction (Numba-accelerated).

This module keeps a persistent voxel map instead of appending every frame
forever. Surface hits first enter a candidate layer; only temporally stable
voxels are promoted to the exported map. Free-space samples along later depth
rays decrease occupancy for previously stored voxels, which helps stale
geometry fade out without using object detection or semantic deletion.

The hot paths are accelerated with Numba JIT. Internal storage uses
struct-of-arrays (parallel NumPy arrays) instead of dict-of-dataclass.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Set, Tuple

import numpy as np

from global_reconstruction.reconstruction._voxel_fusion_soa import (
    VoxelSoA, VoxelRecord, VoxelKey,
)
from global_reconstruction.reconstruction._voxel_fusion_kernels import (
    backproject_kernel,
    surface_weights_kernel,
    filter_depth_edges_kernel,
    integrate_surface_kernel,
    sample_free_space_keys_kernel,
    integrate_free_space_kernel,
    prune_records_kernel,
    build_key_to_idx,
)

STATE_SCHEMA_VERSION = 1
_SENTINEL = -1


def _cfg_get(config: Any, key: str, default: Any) -> Any:
    if config is None:
        return default
    if isinstance(config, dict):
        return config.get(key, default)
    return getattr(config, key, default)


def _savez_fast_compressed(path: Any, compresslevel: int = 1, **arrays: Any) -> None:
    import io
    import zipfile
    with zipfile.ZipFile(path, mode="w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=compresslevel) as zf:
        for key, val in arrays.items():
            buf = io.BytesIO()
            np.save(buf, np.asanyarray(val), allow_pickle=False)
            zf.writestr(key + ".npy", buf.getvalue())


class SparseVoxelFusion:
    """Stateful sparse voxel fusion map (Numba-accelerated).

    The implementation is intentionally geometry-only. It does not reason
    about object identities, categories, or lifecycle events.
    """

    def __init__(
        self,
        voxel_size: float,
        depth_min: float,
        depth_max: float,
        confidence_threshold: float = 0.0,
        min_hits: int = 2,
        min_weight: float = 5.0,
        occupancy_threshold: float = 0.0,
        hit_log_odds: float = 0.85,
        miss_log_odds: float = 0.55,
        min_log_odds: float = -4.0,
        max_log_odds: float = 5.0,
        free_space_carving: bool = True,
        ray_stride: int = 8,
        free_space_margin: float = 0.08,
        free_space_step: Optional[float] = None,
        max_free_depth: Optional[float] = 8.0,
        max_surface_points_per_frame: int = 250_000,
        require_stable_for_export: bool = True,
        min_observation_span: int = 0,
        candidate_max_age_frames: int = 30,
        prune_below_log_odds: float = -2.5,
        prune_min_free_count: int = 3,
        depth_edge_filter: bool = False,
        depth_edge_max_delta: float = 0.35,
        depth_weighting: bool = False,
        depth_weight_scale: float = 4.0,
        min_depth_weight: float = 0.25,
        complete_min_hits: int = 2,
        complete_min_weight: float = 1.0,
        complete_occupancy_threshold: float = 0.0,
        complete_max_free_hit_ratio: float = 1.0,
        retain_inactive_candidates_for_complete: bool = True,
        min_view_baseline_m: float = 0.0,
        min_view_angle_degrees: float = 0.0,
        consecutive_free_threshold: int = 3,
        carve_keyframe_baseline_m: float = 0.0,
        carve_keyframe_angle_deg: float = 0.0,
        gate_surface_on_keyframes: bool = False,
        prune_full_every_keyframes: int = 5,
    ) -> None:
        if voxel_size <= 0:
            raise ValueError("voxel_size must be positive")
        if depth_max <= depth_min:
            raise ValueError("depth_max must be greater than depth_min")

        self.voxel_size = float(voxel_size)
        self.depth_min = float(depth_min)
        self.depth_max = float(depth_max)
        self.confidence_threshold = float(confidence_threshold)
        self.min_hits = int(min_hits)
        self.min_weight = float(min_weight)
        self.occupancy_threshold = float(occupancy_threshold)
        self.hit_log_odds = float(hit_log_odds)
        self.miss_log_odds = float(miss_log_odds)
        self.min_log_odds = float(min_log_odds)
        self.max_log_odds = float(max_log_odds)
        self.free_space_carving = bool(free_space_carving)
        self.ray_stride = max(1, int(ray_stride))
        self.free_space_margin = max(0.0, float(free_space_margin))
        step = free_space_step if free_space_step is not None else self.voxel_size * 2.0
        self.free_space_step = max(float(step), self.voxel_size)
        self.max_free_depth = None if max_free_depth is None else float(max_free_depth)
        self.max_surface_points_per_frame = max(0, int(max_surface_points_per_frame))
        self.require_stable_for_export = bool(require_stable_for_export)
        self.min_observation_span = max(0, int(min_observation_span))
        self.candidate_max_age_frames = max(0, int(candidate_max_age_frames))
        self.prune_below_log_odds = float(prune_below_log_odds)
        self.prune_min_free_count = max(0, int(prune_min_free_count))
        self.depth_edge_filter = bool(depth_edge_filter)
        self.depth_edge_max_delta = max(0.0, float(depth_edge_max_delta))
        self.depth_weighting = bool(depth_weighting)
        self.depth_weight_scale = max(1e-6, float(depth_weight_scale))
        self.min_depth_weight = float(np.clip(min_depth_weight, 0.0, 1.0))
        self.complete_min_hits = max(1, int(complete_min_hits))
        self.complete_min_weight = float(complete_min_weight)
        self.complete_occupancy_threshold = float(complete_occupancy_threshold)
        self.complete_max_free_hit_ratio = max(0.0, float(complete_max_free_hit_ratio))
        self.retain_inactive_candidates_for_complete = bool(retain_inactive_candidates_for_complete)
        self.min_view_baseline_m = max(0.0, float(min_view_baseline_m))
        self.min_view_angle_degrees = max(0.0, float(min_view_angle_degrees))
        self.consecutive_free_threshold = max(1, int(consecutive_free_threshold))
        self.carve_keyframe_baseline_m = max(0.0, float(carve_keyframe_baseline_m))
        self.carve_keyframe_angle_deg = max(0.0, float(carve_keyframe_angle_deg))
        self.gate_surface_on_keyframes = bool(gate_surface_on_keyframes)
        self.prune_full_every_keyframes = max(1, int(prune_full_every_keyframes))

        # Keyframe-gated carving state: carve only on frames with view change
        self._last_carve_pos: Optional[np.ndarray] = None
        self._last_carve_dir: Optional[np.ndarray] = None

        # SoA storage
        self._soa = VoxelSoA()

        # Counters
        self.frames_integrated = 0
        self.surface_pixels_integrated = 0
        self.surface_voxels_updated = 0
        self.free_voxels_updated = 0
        self.promoted_voxels = 0
        self.pruned_voxels = 0
        self.inactivated_candidate_voxels = 0
        self._carve_keyframes = 0

    @classmethod
    def from_config(
        cls,
        config: Any,
        voxel_size: float,
        depth_min: float,
        depth_max: float,
        confidence_threshold: float = 0.0,
    ) -> "SparseVoxelFusion":
        return cls(
            voxel_size=voxel_size,
            depth_min=depth_min,
            depth_max=depth_max,
            confidence_threshold=confidence_threshold,
            min_hits=_cfg_get(config, "min_hits", 2),
            min_weight=_cfg_get(config, "min_weight", 5.0),
            occupancy_threshold=_cfg_get(config, "occupancy_threshold", 0.0),
            hit_log_odds=_cfg_get(config, "hit_log_odds", 0.85),
            miss_log_odds=_cfg_get(config, "miss_log_odds", 0.55),
            min_log_odds=_cfg_get(config, "min_log_odds", -4.0),
            max_log_odds=_cfg_get(config, "max_log_odds", 5.0),
            free_space_carving=_cfg_get(config, "free_space_carving", True),
            ray_stride=_cfg_get(config, "ray_stride", 8),
            free_space_margin=_cfg_get(config, "free_space_margin", 0.08),
            free_space_step=_cfg_get(config, "free_space_step", None),
            max_free_depth=_cfg_get(config, "max_free_depth", 8.0),
            max_surface_points_per_frame=_cfg_get(config, "max_surface_points_per_frame", 250_000),
            require_stable_for_export=_cfg_get(config, "require_stable_for_export", True),
            min_observation_span=_cfg_get(config, "min_observation_span", 0),
            candidate_max_age_frames=_cfg_get(config, "candidate_max_age_frames", 30),
            prune_below_log_odds=_cfg_get(config, "prune_below_log_odds", -2.5),
            prune_min_free_count=_cfg_get(config, "prune_min_free_count", 3),
            depth_edge_filter=_cfg_get(config, "depth_edge_filter", False),
            depth_edge_max_delta=_cfg_get(config, "depth_edge_max_delta", 0.35),
            depth_weighting=_cfg_get(config, "depth_weighting", False),
            depth_weight_scale=_cfg_get(config, "depth_weight_scale", 4.0),
            min_depth_weight=_cfg_get(config, "min_depth_weight", 0.25),
            complete_min_hits=_cfg_get(config, "complete_min_hits", 2),
            complete_min_weight=_cfg_get(config, "complete_min_weight", 1.0),
            complete_occupancy_threshold=_cfg_get(config, "complete_occupancy_threshold", 0.0),
            complete_max_free_hit_ratio=_cfg_get(config, "complete_max_free_hit_ratio", 1.0),
            retain_inactive_candidates_for_complete=_cfg_get(
                config, "retain_inactive_candidates_for_complete", True
            ),
            min_view_baseline_m=_cfg_get(config, "min_view_baseline_m", 0.0),
            min_view_angle_degrees=_cfg_get(config, "min_view_angle_degrees", 0.0),
            consecutive_free_threshold=_cfg_get(config, "consecutive_free_threshold", 3),
            carve_keyframe_baseline_m=_cfg_get(config, "carve_keyframe_baseline_m", 0.0),
            carve_keyframe_angle_deg=_cfg_get(config, "carve_keyframe_angle_deg", 0.0),
            gate_surface_on_keyframes=_cfg_get(config, "gate_surface_on_keyframes", False),
            prune_full_every_keyframes=_cfg_get(config, "prune_full_every_keyframes", 5),
        )

    # ============================================================
    # Backward compatibility: .records property
    # ============================================================
    @property
    def records(self) -> Dict[VoxelKey, VoxelRecord]:
        """Dict-like view of voxels (for backward compatibility).

        Materializes on first access, cached until next mutation.
        """
        return self._soa.materialize_records()

    # ============================================================
    # Main integration entry point
    # ============================================================
    def integrate(
        self,
        depth: np.ndarray,
        color: np.ndarray,
        K: np.ndarray,
        T_c2w: np.ndarray,
        confidence: Optional[np.ndarray] = None,
        frame_id: Optional[Any] = None,
    ) -> Dict[str, int]:
        """Integrate one RGB-D frame into the voxel map."""
        depth = np.asarray(depth, dtype=np.float32)
        color = np.asarray(color)
        K = np.asarray(K, dtype=np.float64)
        T_c2w = np.asarray(T_c2w, dtype=np.float64)

        if depth.ndim != 2:
            raise ValueError("depth must be a 2D array")
        if color.shape[:2] != depth.shape:
            raise ValueError("color and depth must have the same image size")
        if K.shape != (3, 3):
            raise ValueError("K must be a 3x3 matrix")
        if T_c2w.shape != (4, 4):
            raise ValueError("T_c2w must be a 4x4 matrix")

        frame_index = self.frames_integrated
        camera_center = T_c2w[:3, 3].astype(np.float64)

        # Keyframe decision (gates surface + carving when thresholds > 0):
        # carve only on keyframes; surface also keyframe-gated if gate_surface_on_keyframes.
        _gating = (self.carve_keyframe_baseline_m > 0 or self.carve_keyframe_angle_deg > 0)
        if _gating:
            _fwd = T_c2w[:3, :3][:, 2]  # camera forward (local +Z) in world
            _is_kf = self._last_carve_pos is None
            if not _is_kf and self.carve_keyframe_baseline_m > 0:
                _is_kf = float(np.linalg.norm(camera_center - self._last_carve_pos)) >= self.carve_keyframe_baseline_m
            if not _is_kf and self.carve_keyframe_angle_deg > 0 and self._last_carve_dir is not None:
                _cos_a = float(np.clip(np.dot(_fwd, self._last_carve_dir), -1.0, 1.0))
                _is_kf = float(np.degrees(np.arccos(_cos_a))) >= self.carve_keyframe_angle_deg
            if _is_kf:
                self._last_carve_pos = camera_center.copy()
                self._last_carve_dir = np.asarray(_fwd, dtype=np.float64).copy()
                self._carve_keyframes += 1
        else:
            _is_kf = True

        do_surface = (not self.gate_surface_on_keyframes) or _is_kf
        do_carve = self.free_space_carving and _is_kf

        # Non-keyframe with surface gating: skip surface + carving + prune, only advance.
        # prune is keyframe-gated: low_occ/consec_cleanup only change on carve-frames
        # (keyframes); stale (aging) is delayed until the next keyframe's prune, acceptable.
        if not do_surface:
            self.frames_integrated += 1
            return {
                "surface_pixels": 0, "surface_voxels": 0, "free_voxels": 0,
                "promoted_voxels": 0, "pruned_voxels": 0,
                "inactivated_candidate_voxels": 0,
            }

        valid_mask = np.isfinite(depth) & (depth > self.depth_min) & (depth < self.depth_max)
        confidence_values = None
        if confidence is not None:
            confidence_values = np.asarray(confidence, dtype=np.float32)
            if confidence_values.shape != depth.shape:
                raise ValueError("confidence and depth must have the same image size")
            valid_mask &= confidence_values >= self.confidence_threshold

        # Depth edge filter (Numba kernel)
        if self.depth_edge_filter and self.depth_edge_max_delta > 0:
            valid_mask = filter_depth_edges_kernel(
                depth.astype(np.float64), valid_mask, self.depth_edge_max_delta
            )

        v, u = np.where(valid_mask)
        if len(u) == 0:
            pruned, inactivated = self._run_prune(frame_index)
            self.frames_integrated += 1
            return {
                "surface_pixels": 0, "surface_voxels": 0, "free_voxels": 0,
                "pruned_voxels": pruned, "inactivated_candidate_voxels": inactivated,
            }

        if self.max_surface_points_per_frame and len(u) > self.max_surface_points_per_frame:
            keep = np.linspace(0, len(u) - 1, self.max_surface_points_per_frame, dtype=np.int64)
            v = v[keep]
            u = u[keep]


        depths = depth[v, u].astype(np.float64)

        # Surface weights (Numba kernel)
        conf_for_kernel = confidence_values[v, u].astype(np.float64) if confidence_values is not None else np.zeros(len(depths), dtype=np.float64)
        has_conf = confidence_values is not None
        weights = surface_weights_kernel(
            depths, conf_for_kernel, has_conf,
            self.depth_weighting, self.depth_weight_scale, self.min_depth_weight,
        )


        # Backproject (Numba kernel)
        points_world = backproject_kernel(
            u.astype(np.float64), v.astype(np.float64), depths,
            K[0, 0], K[1, 1], K[0, 2], K[1, 2],
            T_c2w[:3, :3], T_c2w[:3, 3],
        )
        colors = color[v, u, :3].astype(np.float64)


        promoted_before = self.promoted_voxels
        camera_center = T_c2w[:3, 3].astype(np.float64)

        # Aggregate per unique voxel (1D injective hash -> faster than np.unique(axis=0))
        voxel_keys_f = np.floor(points_world / self.voxel_size).astype(np.int64)
        _kmin = voxel_keys_f.min(axis=0)
        _shifted = voxel_keys_f - _kmin                      # non-negative
        _spans = _shifted.max(axis=0) + 1                    # per-axis span (>=1)
        # mixed-radix hash: s2 + spans[2]*(s1 + spans[1]*s0), injective for s_i in [0,spans[i])
        _hashes = _shifted[:, 2] + _spans[2] * (_shifted[:, 1] + _spans[1] * _shifted[:, 0])
        _uniq_hashes, inverse = np.unique(_hashes, return_inverse=True)
        # recover unique 3D keys from 1D hashes
        _uk = np.empty((len(_uniq_hashes), 3), dtype=np.int64)
        _uk[:, 2] = _uniq_hashes % _spans[2]
        _q = _uniq_hashes // _spans[2]
        _uk[:, 1] = _q % _spans[1]
        _uk[:, 0] = _q // _spans[1]
        unique_keys = _uk + _kmin
        weight_sum = np.bincount(inverse, weights=weights, minlength=len(unique_keys))
        pixel_count = np.bincount(inverse, minlength=len(unique_keys)).astype(np.int64)
        point_sums = np.stack([
            np.bincount(inverse, weights=points_world[:, ax] * weights, minlength=len(unique_keys))
            for ax in range(3)
        ], axis=1)
        color_sums = np.stack([
            np.bincount(inverse, weights=colors[:, ax] * weights, minlength=len(unique_keys))
            for ax in range(3)
        ], axis=1)


        # Ensure SoA capacity
        needed = self._soa.n + len(unique_keys)
        self._soa.ensure_capacity(needed)

        # Integrate surface (Numba kernel)
        hit_indices, n_promoted = integrate_surface_kernel(
            unique_keys, point_sums, color_sums, weight_sum, pixel_count,
            self._soa.key_to_idx,
            self._soa.keys, self._soa.point_sum, self._soa.color_sum,
            self._soa.weight, self._soa.hit_count, self._soa.pixel_count,
            self._soa.log_odds, self._soa.first_seen_index, self._soa.last_seen_index,
            self._soa.is_stable, self._soa.promoted_frame_index,
            self._soa.inactive_candidate, self._soa.inactive_frame_index,
            self._soa.max_observation_baseline, self._soa.max_view_angle_degrees,
            self._soa.first_camera_center, self._soa.last_camera_center,
            self._soa.first_view_dir, self._soa.last_view_dir,
            self._soa.n_arr, self._soa._cap,
            frame_index, camera_center,
            self.hit_log_odds, self.max_log_odds,
            self.min_hits, self.min_weight, self.occupancy_threshold,
            self.min_observation_span, self.min_view_baseline_m, self.min_view_angle_degrees,
        )

        # Set frame IDs (Python-side, non-numeric)
        for m in range(len(unique_keys)):
            idx = hit_indices[m]
            if idx < 0:
                continue
            if frame_id is not None and self._soa.first_seen_frame[idx] is None:
                self._soa.set_first_seen_frame(idx, frame_id)
            if frame_id is not None:
                self._soa.set_last_seen_frame(idx, frame_id)

        self.promoted_voxels += n_promoted
        n_hit = int(np.sum(hit_indices >= 0))


        # Free space carving (keyframe-gated: only on keyframes, decision made above)
        free_count = 0
        _carved_keys = None
        if do_carve:
            max_free = self.max_free_depth if self.max_free_depth is not None else self.depth_max * 2.0
            max_keys_est = int(max_free / self.free_space_step) * (len(u) // self.ray_stride + 1) + 10000
            max_keys_est = min(max_keys_est, 10_000_000)

            free_keys_arr, n_free = sample_free_space_keys_kernel(
                valid_mask, depth.astype(np.float64),
                K[0, 0], K[1, 1], K[0, 2], K[1, 2],
                T_c2w[:3, :3], T_c2w[:3, 3],
                self.ray_stride, self.free_space_margin, self.free_space_step,
                max_free, self.depth_min, self.voxel_size, max_keys_est,
            )

            if n_free > 0:
                # Deduplicate free keys
                free_unique = np.unique(free_keys_arr[:n_free], axis=0)
                _carved_keys = free_unique
                # Build hit mask (which free keys are also surface hits)
                hit_mask = np.zeros(len(free_unique), dtype=np.bool_)
                for fi in range(len(free_unique)):
                    fk = (int(free_unique[fi, 0]), int(free_unique[fi, 1]), int(free_unique[fi, 2]))
                    if fk in self._soa.key_to_idx:
                        # Check if this is also a surface hit
                        idx = self._soa.key_to_idx[fk]
                        if self._soa.last_seen_index[idx] == frame_index and self._soa.hit_count[idx] > 0:
                            # Could be either surface or free - check if it was in unique_keys
                            # Simple heuristic: if hit_count was just incremented this frame
                            pass

                self._soa.ensure_capacity(self._soa.n)
                free_count = integrate_free_space_kernel(
                    free_unique, hit_mask, self._soa.key_to_idx,
                    self._soa.free_count, self._soa.log_odds,
                    self._soa.last_seen_index, self._soa.consecutive_free_streak,
                    self.min_log_odds, self.miss_log_odds, frame_index,
                )


        # Prune (incremental: carve-driven deletions every keyframe + periodic full for stale marking)
        pruned, inactivated = 0, 0
        if _is_kf:
            # Carve-driven: only check voxels carved this frame for low_occ / consec_cleanup
            # (the ONLY deletion paths; O(carved) ~ scale-independent)
            if _carved_keys is not None and len(_carved_keys) > 0:
                _p_c, _ = self._prune_carved(_carved_keys, frame_index)
                pruned += _p_c
            # Periodic full scan (every N keyframes) for stale inactive-marking (bookkeeping)
            if self._carve_keyframes % self.prune_full_every_keyframes == 0:
                _p_f, _i_f = self._run_prune(frame_index)
                pruned += _p_f
                inactivated += _i_f

        self.frames_integrated += 1
        self.surface_pixels_integrated += int(len(u))
        self.surface_voxels_updated += n_hit
        self.free_voxels_updated += int(free_count)

        return {
            "surface_pixels": int(len(u)),
            "surface_voxels": n_hit,
            "free_voxels": int(free_count),
            "promoted_voxels": int(self.promoted_voxels - promoted_before),
            "pruned_voxels": int(pruned),
            "inactivated_candidate_voxels": int(inactivated),
        }

    def _prune_carved(self, carved_keys: np.ndarray, frame_index: int) -> Tuple[int, int]:
        """Incremental prune: check only voxels carved this frame for low_occ / consec_cleanup
        (the ONLY deletion paths). O(carved ~ few k) vs full scan O(n). Key-based + swap_delete.
        Stale (inactive marking, bookkeeping) handled by periodic full _run_prune.
        """
        soa = self._soa
        key_to_idx = soa.key_to_idx
        pruned = 0
        for fi in range(len(carved_keys)):
            key = (int(carved_keys[fi, 0]), int(carved_keys[fi, 1]), int(carved_keys[fi, 2]))
            if key not in key_to_idx:
                continue
            idx = int(key_to_idx[key])
            if (
                (soa.free_count[idx] >= self.prune_min_free_count
                 and soa.log_odds[idx] <= self.prune_below_log_odds)
                or (soa.is_stable[idx]
                    and soa.consecutive_free_streak[idx] >= self.consecutive_free_threshold)
            ):
                soa.swap_delete(idx)
                pruned += 1
        self.pruned_voxels += pruned
        return pruned, 0

    def _run_prune(self, frame_index: int) -> Tuple[int, int]:
        """Run pruning via Numba kernel, then sync Python-side data."""
        soa = self._soa
        if soa.n == 0:
            return 0, 0

        pruned, inactivated = prune_records_kernel(
            soa.n, soa.keys,
            soa.point_sum, soa.color_sum,
            soa.is_stable, soa.hit_count, soa.pixel_count, soa.weight,
            soa.log_odds, soa.free_count,
            soa.first_seen_index, soa.last_seen_index,
            soa.promoted_frame_index,
            soa.inactive_candidate, soa.inactive_frame_index,
            soa.max_observation_baseline, soa.max_view_angle_degrees,
            soa.first_camera_center, soa.last_camera_center,
            soa.first_view_dir, soa.last_view_dir,
            soa.consecutive_free_streak,
            soa.key_to_idx, soa.n_arr,
            frame_index, self.candidate_max_age_frames,
            self.prune_below_log_odds, self.prune_min_free_count,
            self.consecutive_free_threshold, self.retain_inactive_candidates_for_complete,
        )

        # Sync Python-side lists for moved/deleted rows
        new_n = int(soa.n_arr[0])
        old_first = soa.first_seen_frame[:soa._cap]
        old_last = soa.last_seen_frame[:soa._cap]

        if new_n < len(soa.first_seen_frame):
            pass

        soa._mark_dirty()
        self.pruned_voxels += pruned
        self.inactivated_candidate_voxels += inactivated
        return pruned, inactivated

    # ============================================================
    # Point cloud export
    # ============================================================
    def to_point_cloud(self, mode: str = "stable") -> Tuple[np.ndarray, np.ndarray]:
        """Export occupied voxels as a colored point cloud."""
        mode = mode.lower().strip()
        if mode not in {"stable", "complete"}:
            raise ValueError("mode must be 'stable' or 'complete'")

        soa = self._soa
        n = soa.n
        if n == 0:
            return (
                np.empty((0, 3), dtype=np.float32),
                np.empty((0, 3), dtype=np.uint8),
            )

        # 向量化: 用布尔掩码选出可导出体素，再批量算 point/color，替代 O(N) Python 循环
        _is_stable = soa.is_stable[:n]
        _weight = soa.weight[:n]
        _hit = soa.hit_count[:n]
        _log_odds = soa.log_odds[:n]
        _free = soa.free_count[:n]

        _stable_mask = (
            (_is_stable if self.require_stable_for_export else np.ones(n, dtype=bool))
            & (_weight > 0)
            & (_hit >= self.min_hits)
            & (_weight >= self.min_weight)
            & (_log_odds >= self.occupancy_threshold)
        )
        if mode == "complete":
            _cand_mask = (
                (~_is_stable)
                & (_weight > 0)
                & (_hit >= self.complete_min_hits)
                & (_weight >= self.complete_min_weight)
                & (_log_odds >= self.complete_occupancy_threshold)
                & (_free <= _hit * self.complete_max_free_hit_ratio)
            )
            export_mask = _stable_mask | _cand_mask
        else:
            export_mask = _stable_mask
        # weight>0 已在掩码内保证，再做一次防御性过滤
        export_mask &= (_weight > 0)

        if not np.any(export_mask):
            return (
                np.empty((0, 3), dtype=np.float32),
                np.empty((0, 3), dtype=np.uint8),
            )

        w_sel = _weight[export_mask]
        pts = (soa.point_sum[:n][export_mask] / w_sel[:, None]).astype(np.float32)
        cols = np.clip(soa.color_sum[:n][export_mask] / w_sel[:, None], 0, 255).astype(np.uint8)
        return pts, cols

    def _is_exportable_idx(self, idx: int, mode: str) -> bool:
        """Check if voxel at given index is exportable."""
        soa = self._soa
        if mode == "stable":
            return self._is_stable_exportable_idx(idx)
        if mode == "complete":
            return self._is_stable_exportable_idx(idx) or self._is_complete_candidate_exportable_idx(idx)
        raise ValueError("mode must be 'stable' or 'complete'")

    def _is_stable_exportable_idx(self, idx: int) -> bool:
        soa = self._soa
        return (
            (soa.is_stable[idx] or not self.require_stable_for_export)
            and soa.weight[idx] > 0
            and soa.hit_count[idx] >= self.min_hits
            and soa.weight[idx] >= self.min_weight
            and soa.log_odds[idx] >= self.occupancy_threshold
        )

    def _is_complete_candidate_exportable_idx(self, idx: int) -> bool:
        soa = self._soa
        if soa.is_stable[idx] or soa.weight[idx] <= 0:
            return False
        if soa.hit_count[idx] < self.complete_min_hits:
            return False
        if soa.weight[idx] < self.complete_min_weight:
            return False
        if soa.log_odds[idx] < self.complete_occupancy_threshold:
            return False
        return soa.free_count[idx] <= soa.hit_count[idx] * self.complete_max_free_hit_ratio

    # ============================================================
    # Stats
    # ============================================================
    def stats(self) -> Dict[str, Any]:
        soa = self._soa
        n = soa.n
        stable = int(np.sum(soa.is_stable[:n]))
        inactive = int(np.sum(soa.inactive_candidate[:n]))
        candidate = n - stable
        low_hit = int(np.sum(soa.hit_count[:n] < self.min_hits))
        low_weight = int(np.sum(soa.weight[:n] < self.min_weight))
        low_occ = int(np.sum(soa.log_odds[:n] < self.occupancy_threshold))

        # Observation span
        spans = np.where(
            soa.first_seen_index[:n] >= 0,
            soa.last_seen_index[:n] - soa.first_seen_index[:n],
            0,
        )
        low_span = int(np.sum(spans < self.min_observation_span))

        # Exportable counts (向量化: 用布尔掩码一次性求和)
        soa_n = soa
        _is_stable = soa.is_stable[:n]
        _weight = soa.weight[:n]
        _hit = soa.hit_count[:n]
        _log_odds = soa.log_odds[:n]
        _free = soa.free_count[:n]

        # stable 可导出
        _stable_mask = (
            (_is_stable if self.require_stable_for_export else np.ones(n, dtype=bool))
            & (_weight > 0)
            & (_hit >= self.min_hits)
            & (_weight >= self.min_weight)
            & (_log_odds >= self.occupancy_threshold)
        )
        stable_exp = int(np.sum(_stable_mask))

        _cand_mask = (
            (~_is_stable)
            & (_weight > 0)
            & (_hit >= self.complete_min_hits)
            & (_weight >= self.complete_min_weight)
            & (_log_odds >= self.complete_occupancy_threshold)
            & (_free <= _hit * self.complete_max_free_hit_ratio)
        )
        complete_exp = int(np.sum(_stable_mask | _cand_mask))

        return {
            "frames_integrated": self.frames_integrated,
            "carve_keyframes": self._carve_keyframes,
            "carve_keyframe_ratio": (self._carve_keyframes / self.frames_integrated) if self.frames_integrated else 0.0,
            "gate_surface_on_keyframes": self.gate_surface_on_keyframes,
            "total_voxels": n,
            "candidate_voxels": candidate,
            "inactive_candidate_voxels": inactive,
            "stable_voxels": stable,
            "exported_voxels": stable_exp,
            "stable_exported_voxels": stable_exp,
            "complete_exported_voxels": complete_exp,
            "filtered_low_hit_voxels": low_hit,
            "filtered_low_weight_voxels": low_weight,
            "filtered_low_occupancy_voxels": low_occ,
            "filtered_low_temporal_span_voxels": low_span,
            "surface_pixels_integrated": self.surface_pixels_integrated,
            "surface_voxels_updated": self.surface_voxels_updated,
            "free_voxels_updated": self.free_voxels_updated,
            "promoted_voxels": self.promoted_voxels,
            "pruned_voxels": self.pruned_voxels,
            "inactivated_candidate_voxels": self.inactivated_candidate_voxels,
            "voxel_size": self.voxel_size,
            "min_hits": self.min_hits,
            "min_weight": self.min_weight,
            "min_observation_span": self.min_observation_span,
            "occupancy_threshold": self.occupancy_threshold,
            "require_stable_for_export": self.require_stable_for_export,
            "free_space_carving": self.free_space_carving,
            "ray_stride": self.ray_stride,
            "free_space_step": self.free_space_step,
            "depth_edge_filter": self.depth_edge_filter,
            "depth_edge_max_delta": self.depth_edge_max_delta,
            "depth_weighting": self.depth_weighting,
            "complete_min_hits": self.complete_min_hits,
            "complete_min_weight": self.complete_min_weight,
            "complete_occupancy_threshold": self.complete_occupancy_threshold,
            "complete_max_free_hit_ratio": self.complete_max_free_hit_ratio,
            "retain_inactive_candidates_for_complete": self.retain_inactive_candidates_for_complete,
            "min_view_baseline_m": self.min_view_baseline_m,
            "min_view_angle_degrees": self.min_view_angle_degrees,
            "consecutive_free_threshold": self.consecutive_free_threshold,
        }

    # ============================================================
    # Serialization (compatible with old format)
    # ============================================================
    def _constructor_params(self) -> Dict[str, Any]:
        return {
            "voxel_size": self.voxel_size,
            "depth_min": self.depth_min,
            "depth_max": self.depth_max,
            "confidence_threshold": self.confidence_threshold,
            "min_hits": self.min_hits,
            "min_weight": self.min_weight,
            "occupancy_threshold": self.occupancy_threshold,
            "hit_log_odds": self.hit_log_odds,
            "miss_log_odds": self.miss_log_odds,
            "min_log_odds": self.min_log_odds,
            "max_log_odds": self.max_log_odds,
            "free_space_carving": self.free_space_carving,
            "ray_stride": self.ray_stride,
            "free_space_margin": self.free_space_margin,
            "free_space_step": self.free_space_step,
            "max_free_depth": self.max_free_depth,
            "max_surface_points_per_frame": self.max_surface_points_per_frame,
            "require_stable_for_export": self.require_stable_for_export,
            "min_observation_span": self.min_observation_span,
            "candidate_max_age_frames": self.candidate_max_age_frames,
            "prune_below_log_odds": self.prune_below_log_odds,
            "prune_min_free_count": self.prune_min_free_count,
            "depth_edge_filter": self.depth_edge_filter,
            "depth_edge_max_delta": self.depth_edge_max_delta,
            "depth_weighting": self.depth_weighting,
            "depth_weight_scale": self.depth_weight_scale,
            "min_depth_weight": self.min_depth_weight,
            "complete_min_hits": self.complete_min_hits,
            "complete_min_weight": self.complete_min_weight,
            "complete_occupancy_threshold": self.complete_occupancy_threshold,
            "complete_max_free_hit_ratio": self.complete_max_free_hit_ratio,
            "retain_inactive_candidates_for_complete": self.retain_inactive_candidates_for_complete,
            "min_view_baseline_m": self.min_view_baseline_m,
            "min_view_angle_degrees": self.min_view_angle_degrees,
            "consecutive_free_threshold": self.consecutive_free_threshold,
            "carve_keyframe_baseline_m": self.carve_keyframe_baseline_m,
            "carve_keyframe_angle_deg": self.carve_keyframe_angle_deg,
            "gate_surface_on_keyframes": self.gate_surface_on_keyframes,
            "prune_full_every_keyframes": self.prune_full_every_keyframes,
        }

    def save_state(self, path: Any, include_frame_ids: bool = False) -> None:
        """
        Persist the full sparse voxel map state to a compressed NPZ file
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        soa = self._soa
        n = soa.n

        keys_arr = soa.keys[:n].copy()

        if include_frame_ids:
            # Convert frame IDs to JSON-safe
            def safe_id(v):
                if v is None or isinstance(v, (str, int, float, bool)):
                    return v
                return str(v)
            first_seen_frames = [safe_id(soa.first_seen_frame[i]) for i in range(n)]
            last_seen_frames = [safe_id(soa.last_seen_frame[i]) for i in range(n)]
        else:
            first_seen_frames = []
            last_seen_frames = []

        metadata = {
            "schema_version": STATE_SCHEMA_VERSION,
            "params": self._constructor_params(),
            "counters": {
                "frames_integrated": self.frames_integrated,
                "surface_pixels_integrated": self.surface_pixels_integrated,
                "surface_voxels_updated": self.surface_voxels_updated,
                "free_voxels_updated": self.free_voxels_updated,
                "promoted_voxels": self.promoted_voxels,
                "pruned_voxels": self.pruned_voxels,
                "inactivated_candidate_voxels": self.inactivated_candidate_voxels,
                "_carve_keyframes": self._carve_keyframes,
            },
            "carve_state": {
                "last_carve_pos": None if self._last_carve_pos is None else self._last_carve_pos.tolist(),
                "last_carve_dir": None if self._last_carve_dir is None else self._last_carve_dir.tolist(),
            },
            "first_seen_frames": first_seen_frames,
            "last_seen_frames": last_seen_frames,
        }
        metadata_text = json.dumps(metadata, ensure_ascii=False)

        # float64→float32、int64→int32（加载时 numpy 自动转回 SoA 的 float64/int64
        with path.open("wb") as f:
            _savez_fast_compressed(
                f,
                metadata=np.asarray(metadata_text),
                keys=keys_arr.astype(np.int32),
                point_sum=soa.point_sum[:n].astype(np.float32),
                color_sum=soa.color_sum[:n].astype(np.float32),
                weight=soa.weight[:n].astype(np.float32),
                hit_count=soa.hit_count[:n].astype(np.int32),
                pixel_count=soa.pixel_count[:n].astype(np.int32),
                free_count=soa.free_count[:n].astype(np.int32),
                log_odds=soa.log_odds[:n].astype(np.float32),
                first_seen_index=soa.first_seen_index[:n].astype(np.int32),
                last_seen_index=soa.last_seen_index[:n].astype(np.int32),
                is_stable=soa.is_stable[:n].copy(),
                promoted_frame_index=soa.promoted_frame_index[:n].astype(np.int32),
                inactive_candidate=soa.inactive_candidate[:n].copy(),
                inactive_frame_index=soa.inactive_frame_index[:n].astype(np.int32),
                first_camera_center=soa.first_camera_center[:n].astype(np.float32),
                last_camera_center=soa.last_camera_center[:n].astype(np.float32),
                first_view_dir=soa.first_view_dir[:n].astype(np.float32),
                last_view_dir=soa.last_view_dir[:n].astype(np.float32),
                max_observation_baseline=soa.max_observation_baseline[:n].astype(np.float32),
                max_view_angle_degrees=soa.max_view_angle_degrees[:n].astype(np.float32),
                consecutive_free_streak=soa.consecutive_free_streak[:n].astype(np.int32),
            )

    @classmethod
    def load_state(cls, path: Any) -> "SparseVoxelFusion":
        """Load a sparse voxel map previously written by save_state."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Voxel fusion state does not exist: {path}")

        with np.load(path, allow_pickle=False) as data:
            metadata = json.loads(str(data["metadata"].item()))
            params = dict(metadata.get("params", {}))
            fusion = cls(**params)

            counters = metadata.get("counters", {})
            for name, val in counters.items():
                setattr(fusion, name, int(val))

            carve_state = metadata.get("carve_state", {})
            _lsp = carve_state.get("last_carve_pos")
            _lsd = carve_state.get("last_carve_dir")
            fusion._last_carve_pos = None if _lsp is None else np.asarray(_lsp, dtype=np.float64)
            fusion._last_carve_dir = None if _lsd is None else np.asarray(_lsd, dtype=np.float64)

            keys = np.asarray(data["keys"], dtype=np.int64)
            n = len(keys)
            first_seen_frames = metadata.get("first_seen_frames", [])
            last_seen_frames = metadata.get("last_seen_frames", [])

            soa = fusion._soa
            soa.ensure_capacity(n)

            # 向量化批量赋值
            soa.keys[:n] = keys
            soa.point_sum[:n] = data["point_sum"][:n]
            soa.color_sum[:n] = data["color_sum"][:n]
            soa.weight[:n] = data["weight"][:n]
            soa.hit_count[:n] = data["hit_count"][:n]
            soa.pixel_count[:n] = data["pixel_count"][:n]
            soa.free_count[:n] = data["free_count"][:n]
            soa.log_odds[:n] = data["log_odds"][:n]
            soa.first_seen_index[:n] = data["first_seen_index"][:n]
            soa.last_seen_index[:n] = data["last_seen_index"][:n]
            soa.is_stable[:n] = data["is_stable"][:n]
            soa.promoted_frame_index[:n] = data["promoted_frame_index"][:n]
            soa.inactive_candidate[:n] = data["inactive_candidate"][:n]
            soa.inactive_frame_index[:n] = data["inactive_frame_index"][:n]
            soa.first_camera_center[:n] = data["first_camera_center"][:n]
            soa.last_camera_center[:n] = data["last_camera_center"][:n]
            soa.first_view_dir[:n] = data["first_view_dir"][:n]
            soa.last_view_dir[:n] = data["last_view_dir"][:n]
            soa.max_observation_baseline[:n] = data["max_observation_baseline"][:n]
            soa.max_view_angle_degrees[:n] = data["max_view_angle_degrees"][:n]
            if "consecutive_free_streak" in data:
                soa.consecutive_free_streak[:n] = data["consecutive_free_streak"][:n]

            # key_to_idx: Numba typed.Dict，JIT 批量重建
            soa.key_to_idx = soa._make_key_to_idx() if hasattr(soa, '_make_key_to_idx') else soa.key_to_idx
            soa.key_to_idx.clear()
            build_key_to_idx(keys, soa.key_to_idx)

            # first_seen_frame / last_seen_frame: Python list，批量赋值
            # 检查点未存帧ID（save_state include_frame_ids=False）→ first_seen_frames 为空
            # 补 None 到 n，保证列表长度=cap（否则 integrate 访问 first_seen_frame[idx] 越界）
            fs = list(first_seen_frames[:n])
            fs += [None] * (n - len(fs))
            soa.first_seen_frame = fs + [None] * (soa._cap - n)
            ls = list(last_seen_frames[:n])
            ls += [None] * (n - len(ls))
            soa.last_seen_frame = ls + [None] * (soa._cap - n)

            soa.n = n
            soa._mark_dirty()

        return fusion
