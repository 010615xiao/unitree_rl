"""Numba-accelerated kernels for sparse voxel fusion.

All functions use @njit(cache=True) for JIT compilation with disk caching.
They operate on parallel NumPy arrays (struct-of-arrays) and numba.typed.Dict
for key→index mapping. No Python objects are used inside @njit functions.
"""

from __future__ import annotations

import numpy as np
from numba import njit

_SENTINEL = np.int64(-1)
_NAN = np.float64(np.nan)


@njit(cache=True)
def build_key_to_idx(keys, key_to_idx):
    """
    从 keys (N,3 int64) 批量重建 key→index 映射到已有 typed.Dict
    """
    for i in range(len(keys)):
        key_to_idx[(keys[i, 0], keys[i, 1], keys[i, 2])] = i


# ============================================================
# 1. Backprojection: depth pixels → 3D world points
# ============================================================
@njit(cache=True)
def backproject_kernel(u, v, depths, fx, fy, cx, cy, R, t):
    """Backproject depth pixels to world coordinates.

    Args:
        u, v: pixel coordinates (1D arrays, same length)
        depths: depth values in meters (1D array)
        fx, fy, cx, cy: camera intrinsics (scalars)
        R: 3x3 rotation matrix (camera → world)
        t: 3-element translation vector (camera → world)

    Returns:
        points_world: (N, 3) array of world coordinates
    """
    n = len(u)
    points = np.empty((n, 3), dtype=np.float64)
    for i in range(n):
        z = depths[i]
        x_cam = (u[i] - cx) * z / fx
        y_cam = (v[i] - cy) * z / fy
        # Camera → World: p_w = R @ p_cam + t
        points[i, 0] = R[0, 0] * x_cam + R[0, 1] * y_cam + R[0, 2] * z + t[0]
        points[i, 1] = R[1, 0] * x_cam + R[1, 1] * y_cam + R[1, 2] * z + t[1]
        points[i, 2] = R[2, 0] * x_cam + R[2, 1] * y_cam + R[2, 2] * z + t[2]
    return points


# ============================================================
# 2. Surface weights: confidence + depth weighting
# ============================================================
@njit(cache=True)
def surface_weights_kernel(depths, confidence, has_confidence,
                           depth_weighting, depth_weight_scale, min_depth_weight):
    """Compute per-point fusion weights.

    Args:
        depths: depth values (1D array, meters)
        confidence: confidence values (1D array, same length as depths)
                    If has_confidence is False, this array is ignored.
        has_confidence: bool, whether to use confidence values
        depth_weighting: bool, whether to apply depth-based weighting
        depth_weight_scale: scale parameter for depth weighting
        min_depth_weight: minimum weight floor

    Returns:
        weights: (N,) array of weights in [min_depth_weight, 1.0]
    """
    n = len(depths)
    weights = np.ones(n, dtype=np.float64)

    if has_confidence and len(confidence) == n:
        for i in range(n):
            c = confidence[i]
            if np.isfinite(c):
                weights[i] = min(max(c, 0.05), 1.0)

    if depth_weighting:
        for i in range(n):
            d = max(depths[i], 0.0)
            factor = depth_weight_scale / (depth_weight_scale + d)
            factor = min(max(factor, min_depth_weight), 1.0)
            weights[i] *= factor

    return weights


# ============================================================
# 3. Depth edge filter
# ============================================================
@njit(cache=True)
def filter_depth_edges_kernel(depth, valid_mask, edge_max_delta):
    """Filter depth pixels near depth discontinuities.

    Args:
        depth: (H, W) depth array
        valid_mask: (H, W) boolean mask
        edge_max_delta: max depth difference between neighbors

    Returns:
        filtered: (H, W) boolean mask (True = keep)
    """
    H, W = depth.shape
    filtered = valid_mask.copy()

    # Horizontal edges
    for r in range(H):
        for c in range(W - 1):
            if valid_mask[r, c] and valid_mask[r, c + 1]:
                if abs(depth[r, c + 1] - depth[r, c]) > edge_max_delta:
                    filtered[r, c] = False
                    filtered[r, c + 1] = False

    # Vertical edges
    for r in range(H - 1):
        for c in range(W):
            if valid_mask[r, c] and valid_mask[r + 1, c]:
                if abs(depth[r + 1, c] - depth[r, c]) > edge_max_delta:
                    filtered[r, c] = False
                    filtered[r + 1, c] = False

    return filtered


# ============================================================
# 4. Integrate surface hits (the core kernel)
# ============================================================
@njit(cache=True)
def integrate_surface_kernel(
    unique_keys,       # (M, 3) int64 — unique voxel keys
    point_sums,        # (M, 3) float64 — aggregated point sums per unique voxel
    color_sums,        # (M, 3) float64 — aggregated color sums per unique voxel
    weight_sums,       # (M,) float64 — aggregated weight sums per unique voxel
    pixel_counts,      # (M,) int64 — pixel counts per unique voxel
    key_to_idx,        # numba typed dict (int64,int64,int64) → int64
    # SoA arrays (all length = capacity)
    soa_keys,          # (cap, 3) int64
    soa_point_sum,     # (cap, 3) float64
    soa_color_sum,     # (cap, 3) float64
    soa_weight,        # (cap,) float64
    soa_hit_count,     # (cap,) int64
    soa_pixel_count,   # (cap,) int64
    soa_log_odds,      # (cap,) float64
    soa_first_seen_idx,  # (cap,) int64
    soa_last_seen_idx,   # (cap,) int64
    soa_is_stable,       # (cap,) bool
    soa_promoted_idx,    # (cap,) int64
    soa_inactive_cand,   # (cap,) bool
    soa_inactive_idx,    # (cap,) int64
    soa_max_baseline,    # (cap,) float64
    soa_max_view_angle,  # (cap,) float64
    soa_first_cam_c,     # (cap, 3) float64
    soa_last_cam_c,      # (cap, 3) float64
    soa_first_view_d,    # (cap, 3) float64
    soa_last_view_d,     # (cap, 3) float64
    n_arr,             # (1,) int64 — current count (mutable)
    capacity,          # int — array capacity
    # Parameters
    frame_index,       # int
    camera_center,     # (3,) float64
    hit_log_odds,      # float
    max_log_odds,      # float
    min_hits,          # int
    min_weight,        # float
    occupancy_threshold,  # float
    min_observation_span, # int
    min_view_baseline,    # float
    min_view_angle_deg,   # float
):
    """Integrate surface hits into the voxel map.

    Returns:
        hit_indices: (M,) int64 — array indices of updated voxels
        promoted_count: int — number of newly promoted voxels
    """
    M = len(unique_keys)
    hit_indices = np.empty(M, dtype=np.int64)
    promoted_count = 0

    for m in range(M):
        kx = unique_keys[m, 0]
        ky = unique_keys[m, 1]
        kz = unique_keys[m, 2]

        ws = weight_sums[m]
        if ws <= 0.0:
            hit_indices[m] = _SENTINEL
            continue

        # Lookup or create voxel
        key = (kx, ky, kz)
        idx = _SENTINEL
        if key in key_to_idx:
            idx = key_to_idx[key]
        else:
            # Create new voxel
            idx = n_arr[0]
            if idx >= capacity:
                # Should not happen — caller ensures capacity
                hit_indices[m] = _SENTINEL
                continue
            soa_keys[idx, 0] = kx
            soa_keys[idx, 1] = ky
            soa_keys[idx, 2] = kz
            soa_point_sum[idx, 0] = 0.0
            soa_point_sum[idx, 1] = 0.0
            soa_point_sum[idx, 2] = 0.0
            soa_color_sum[idx, 0] = 0.0
            soa_color_sum[idx, 1] = 0.0
            soa_color_sum[idx, 2] = 0.0
            soa_weight[idx] = 0.0
            soa_hit_count[idx] = 0
            soa_pixel_count[idx] = 0
            soa_log_odds[idx] = 0.0
            soa_first_seen_idx[idx] = frame_index
            soa_last_seen_idx[idx] = frame_index
            soa_is_stable[idx] = False
            soa_promoted_idx[idx] = _SENTINEL
            soa_inactive_cand[idx] = False
            soa_inactive_idx[idx] = _SENTINEL
            soa_max_baseline[idx] = 0.0
            soa_max_view_angle[idx] = 0.0
            soa_first_cam_c[idx, 0] = _NAN
            soa_first_cam_c[idx, 1] = _NAN
            soa_first_cam_c[idx, 2] = _NAN
            soa_last_cam_c[idx, 0] = _NAN
            soa_last_cam_c[idx, 1] = _NAN
            soa_last_cam_c[idx, 2] = _NAN
            soa_first_view_d[idx, 0] = _NAN
            soa_first_view_d[idx, 1] = _NAN
            soa_first_view_d[idx, 2] = _NAN
            soa_last_view_d[idx, 0] = _NAN
            soa_last_view_d[idx, 1] = _NAN
            soa_last_view_d[idx, 2] = _NAN
            key_to_idx[key] = idx
            n_arr[0] = idx + 1

        # Compute voxel center (weighted average so far + new hit)
        voxel_x = (soa_point_sum[idx, 0] + point_sums[m, 0]) / (soa_weight[idx] + ws)
        voxel_y = (soa_point_sum[idx, 1] + point_sums[m, 1]) / (soa_weight[idx] + ws)
        voxel_z = (soa_point_sum[idx, 2] + point_sums[m, 2]) / (soa_weight[idx] + ws)

        # Update accumulators
        soa_point_sum[idx, 0] += point_sums[m, 0]
        soa_point_sum[idx, 1] += point_sums[m, 1]
        soa_point_sum[idx, 2] += point_sums[m, 2]
        soa_color_sum[idx, 0] += color_sums[m, 0]
        soa_color_sum[idx, 1] += color_sums[m, 1]
        soa_color_sum[idx, 2] += color_sums[m, 2]
        soa_weight[idx] += ws
        soa_hit_count[idx] += 1
        soa_pixel_count[idx] += pixel_counts[m]
        soa_last_seen_idx[idx] = frame_index
        if soa_first_seen_idx[idx] < 0:
            soa_first_seen_idx[idx] = frame_index
        soa_log_odds[idx] = min(max_log_odds, soa_log_odds[idx] + hit_log_odds)
        soa_inactive_cand[idx] = False
        soa_inactive_idx[idx] = _SENTINEL

        # Update view evidence
        view_dx = voxel_x - camera_center[0]
        view_dy = voxel_y - camera_center[1]
        view_dz = voxel_z - camera_center[2]
        view_norm = np.sqrt(view_dx * view_dx + view_dy * view_dy + view_dz * view_dz)
        if view_norm > 1e-9:
            view_dx /= view_norm
            view_dy /= view_norm
            view_dz /= view_norm
        else:
            view_dx = 0.0
            view_dy = 0.0
            view_dz = 0.0

        # First camera center
        if np.isnan(soa_first_cam_c[idx, 0]):
            soa_first_cam_c[idx, 0] = camera_center[0]
            soa_first_cam_c[idx, 1] = camera_center[1]
            soa_first_cam_c[idx, 2] = camera_center[2]
            soa_first_view_d[idx, 0] = view_dx
            soa_first_view_d[idx, 1] = view_dy
            soa_first_view_d[idx, 2] = view_dz

        # Update baselines and angles
        for ref in range(2):  # 0=first, 1=last
            if ref == 0:
                ref_cx = soa_first_cam_c[idx, 0]
                ref_cy = soa_first_cam_c[idx, 1]
                ref_cz = soa_first_cam_c[idx, 2]
                ref_dx = soa_first_view_d[idx, 0]
                ref_dy = soa_first_view_d[idx, 1]
                ref_dz = soa_first_view_d[idx, 2]
            else:
                ref_cx = soa_last_cam_c[idx, 0]
                ref_cy = soa_last_cam_c[idx, 1]
                ref_cz = soa_last_cam_c[idx, 2]
                ref_dx = soa_last_view_d[idx, 0]
                ref_dy = soa_last_view_d[idx, 1]
                ref_dz = soa_last_view_d[idx, 2]

            if not np.isnan(ref_cx):
                bl_dx = camera_center[0] - ref_cx
                bl_dy = camera_center[1] - ref_cy
                bl_dz = camera_center[2] - ref_cz
                baseline = np.sqrt(bl_dx * bl_dx + bl_dy * bl_dy + bl_dz * bl_dz)
                if baseline > soa_max_baseline[idx]:
                    soa_max_baseline[idx] = baseline

                if not np.isnan(ref_dx):
                    dot = view_dx * ref_dx + view_dy * ref_dy + view_dz * ref_dz
                    dot = min(max(dot, -1.0), 1.0)
                    angle = np.degrees(np.arccos(dot))
                    if angle > soa_max_view_angle[idx]:
                        soa_max_view_angle[idx] = angle

        soa_last_cam_c[idx, 0] = camera_center[0]
        soa_last_cam_c[idx, 1] = camera_center[1]
        soa_last_cam_c[idx, 2] = camera_center[2]
        soa_last_view_d[idx, 0] = view_dx
        soa_last_view_d[idx, 1] = view_dy
        soa_last_view_d[idx, 2] = view_dz

        # Check promotion
        if not soa_is_stable[idx]:
            span = soa_last_seen_idx[idx] - soa_first_seen_idx[idx]
            if span < 0:
                span = 0
            meets = (
                soa_weight[idx] > 0.0
                and soa_hit_count[idx] >= min_hits
                and soa_weight[idx] >= min_weight
                and soa_log_odds[idx] >= occupancy_threshold
                and span >= min_observation_span
            )
            if meets:
                # Check view stability
                view_ok = True
                if min_view_baseline > 0.0:
                    if soa_max_baseline[idx] < min_view_baseline:
                        view_ok = False
                if min_view_angle_deg > 0.0:
                    if soa_max_view_angle[idx] < min_view_angle_deg:
                        view_ok = False
                if view_ok:
                    soa_is_stable[idx] = True
                    soa_promoted_idx[idx] = frame_index
                    promoted_count += 1

        hit_indices[m] = idx

    return hit_indices, promoted_count


# ============================================================
# 5. Sample free-space keys along depth rays
# ============================================================
@njit(cache=True)
def sample_free_space_keys_kernel(
    valid_mask,     # (H, W) bool
    depth,          # (H, W) float64
    fx, fy, cx, cy, # camera intrinsics
    R,              # (3, 3) rotation
    t,              # (3,) translation
    stride,         # int — ray sampling stride
    margin,         # float — free space margin before surface
    step,           # float — step along ray
    max_free_depth, # float — max ray depth
    depth_min,      # float — min valid depth
    voxel_size,     # float
    max_keys,       # int — pre-allocated output size
):
    """Sample voxel keys along depth rays for free-space carving.

    Returns:
        free_keys: (K, 3) int64 — unique voxel keys in free space
        n_keys: int — number of valid keys
    """
    H, W = valid_mask.shape

    # First pass: count sampled pixels
    n_rays = 0
    for r in range(0, H, stride):
        for c in range(0, W, stride):
            if valid_mask[r, c]:
                n_rays += 1

    if n_rays == 0:
        return np.empty((0, 3), dtype=np.int64), 0

    # Pre-allocate output (overestimate)
    max_per_ray = int(max_free_depth / step) + 2 if max_free_depth > 0 else 100
    out_size = min(n_rays * max_per_ray, max_keys)
    all_keys = np.empty((out_size, 3), dtype=np.int64)
    n_total = 0

    sample_start = max(depth_min + step, step)

    for r in range(0, H, stride):
        for c in range(0, W, stride):
            if not valid_mask[r, c]:
                continue

            d = depth[r, c]
            if not np.isfinite(d):
                continue
            ray_end = d - margin
            if max_free_depth > 0.0:
                ray_end = min(ray_end, max_free_depth)
            if ray_end < sample_start:
                continue

            # Ray direction in camera frame
            ray_sx = (c - cx) / fx
            ray_sy = (r - cy) / fy
            ray_sz = 1.0

            z = sample_start
            while z <= ray_end + 1e-9:
                # Point in camera frame
                pc_x = ray_sx * z
                pc_y = ray_sy * z
                pc_z = ray_sz * z

                # Camera → World
                pw_x = R[0, 0] * pc_x + R[0, 1] * pc_y + R[0, 2] * pc_z + t[0]
                pw_y = R[1, 0] * pc_x + R[1, 1] * pc_y + R[1, 2] * pc_z + t[1]
                pw_z = R[2, 0] * pc_x + R[2, 1] * pc_y + R[2, 2] * pc_z + t[2]

                # Voxel key
                vk_x = int(np.floor(pw_x / voxel_size))
                vk_y = int(np.floor(pw_y / voxel_size))
                vk_z = int(np.floor(pw_z / voxel_size))

                if n_total < out_size:
                    all_keys[n_total, 0] = vk_x
                    all_keys[n_total, 1] = vk_y
                    all_keys[n_total, 2] = vk_z
                    n_total += 1

                z += step

    return all_keys[:n_total], n_total


# ============================================================
# 6. Integrate free-space hits
# ============================================================
@njit(cache=True)
def integrate_free_space_kernel(
    free_keys,       # (K, 3) int64
    hit_mask,        # (K,) bool — True if this key is also a surface hit
    key_to_idx,      # numba typed dict
    soa_free_count,  # (cap,) int64
    soa_log_odds,    # (cap,) float64
    soa_last_seen_idx,  # (cap,) int64
    soa_consec_free,    # (cap,) int64
    min_log_odds,    # float
    miss_log_odds,   # float
    frame_index,     # int
):
    """Decrease log-odds for free-space voxels.

    Returns:
        updated_count: int
    """
    K = len(free_keys)
    updated = 0

    for k in range(K):
        if hit_mask[k]:
            continue

        key = (free_keys[k, 0], free_keys[k, 1], free_keys[k, 2])
        if key not in key_to_idx:
            continue

        idx = key_to_idx[key]
        soa_free_count[idx] += 1
        soa_log_odds[idx] = max(min_log_odds, soa_log_odds[idx] - miss_log_odds)

        # Track consecutive free-space streak
        if soa_last_seen_idx[idx] == frame_index - 1:
            soa_consec_free[idx] += 1
        else:
            soa_consec_free[idx] = 1

        soa_last_seen_idx[idx] = frame_index
        updated += 1

    return updated


# ============================================================
# 7. Prune stale/low-occupancy voxels
# ============================================================
@njit(cache=True)
def prune_records_kernel(
    n,                  # int — current voxel count
    soa_keys,           # (cap, 3) int64
    soa_point_sum,      # (cap, 3) float64
    soa_color_sum,      # (cap, 3) float64
    soa_is_stable,      # (cap,) bool
    soa_hit_count,      # (cap,) int64
    soa_pixel_count,    # (cap,) int64
    soa_weight,         # (cap,) float64
    soa_log_odds,       # (cap,) float64
    soa_free_count,     # (cap,) int64
    soa_first_seen_idx, # (cap,) int64
    soa_last_seen_idx,  # (cap,) int64
    soa_promoted_idx,   # (cap,) int64
    soa_inactive_cand,  # (cap,) bool
    soa_inactive_idx,   # (cap,) int64
    soa_max_baseline,   # (cap,) float64
    soa_max_view_angle, # (cap,) float64
    soa_first_cam_c,    # (cap, 3) float64
    soa_last_cam_c,     # (cap, 3) float64
    soa_first_view_d,   # (cap, 3) float64
    soa_last_view_d,    # (cap, 3) float64
    soa_consec_free,    # (cap,) int64
    key_to_idx,         # numba typed dict
    n_arr,              # (1,) int64
    frame_index,        # int
    candidate_max_age,  # int
    prune_min_log_odds, # float
    prune_min_free,     # int
    consec_free_thresh, # int
    retain_inactive,    # bool
):
    """Remove stale/low-occupancy voxels.

    Uses swap-with-last deletion. Iterates backward to handle index changes.

    Returns:
        pruned_count: int
        inactivated_count: int
    """
    pruned = 0
    inactivated = 0

    # Collect indices to delete (iterate backward for safe swap-delete)
    i = n - 1
    while i >= 0:
        age = frame_index - soa_last_seen_idx[i] if soa_last_seen_idx[i] >= 0 else 0
        span = soa_last_seen_idx[i] - soa_first_seen_idx[i] if soa_first_seen_idx[i] >= 0 else 0
        if span < 0:
            span = 0

        # Check consecutive free-space cleanup
        consec_cleanup = (
            soa_is_stable[i]
            and soa_consec_free[i] >= consec_free_thresh
        )

        # Check low occupancy
        low_occ = (
            soa_free_count[i] >= prune_min_free
            and soa_log_odds[i] <= prune_min_log_odds
        )

        # Check stale candidate
        stale = (
            not soa_is_stable[i]
            and candidate_max_age > 0
            and age > candidate_max_age
        )

        if low_occ or consec_cleanup:
            # Delete this voxel
            kx = soa_keys[i, 0]
            ky = soa_keys[i, 1]
            kz = soa_keys[i, 2]
            key = (kx, ky, kz)
            if key in key_to_idx:
                del key_to_idx[key]

            last = n_arr[0] - 1
            if i != last:
                # Swap last into i — but we handle this manually here
                # since we're iterating backward, just copy last to i
                _swap_row_soa(
                    last, i,
                    soa_keys,
                    soa_point_sum, soa_color_sum,
                    soa_weight, soa_hit_count, soa_pixel_count, soa_free_count,
                    soa_log_odds,
                    soa_first_seen_idx, soa_last_seen_idx,
                    soa_is_stable, soa_promoted_idx,
                    soa_inactive_cand, soa_inactive_idx,
                    soa_max_baseline, soa_max_view_angle,
                    soa_first_cam_c, soa_last_cam_c,
                    soa_first_view_d, soa_last_view_d,
                    soa_consec_free,
                )
                # Update key_to_idx for moved row
                mk = (int(soa_keys[i, 0]), int(soa_keys[i, 1]), int(soa_keys[i, 2]))
                key_to_idx[mk] = i

            n_arr[0] -= 1
            pruned += 1
            # Don't decrement i — the swapped-in voxel needs checking too
            # Actually, since we're going backward and the swapped row came
            # from a higher index (already checked), we can decrement.
            i -= 1
        elif stale:
            if retain_inactive:
                if not soa_inactive_cand[i]:
                    soa_inactive_cand[i] = True
                    soa_inactive_idx[i] = frame_index
                    inactivated += 1
            i -= 1
        else:
            i -= 1

    return pruned, inactivated


@njit(cache=True)
def _swap_row_soa(
    src, dst,
    soa_keys,
    soa_point_sum, soa_color_sum,
    soa_weight, soa_hit_count, soa_pixel_count, soa_free_count,
    soa_log_odds,
    soa_first_seen_idx, soa_last_seen_idx,
    soa_is_stable, soa_promoted_idx,
    soa_inactive_cand, soa_inactive_idx,
    soa_max_baseline, soa_max_view_angle,
    soa_first_cam_c, soa_last_cam_c,
    soa_first_view_d, soa_last_view_d,
    soa_consec_free,
):
    """Copy SoA row from src to dst (for swap-delete inside Numba)."""
    # Keys
    soa_keys[dst, 0] = soa_keys[src, 0]
    soa_keys[dst, 1] = soa_keys[src, 1]
    soa_keys[dst, 2] = soa_keys[src, 2]
    # Accumulators
    soa_point_sum[dst, 0] = soa_point_sum[src, 0]
    soa_point_sum[dst, 1] = soa_point_sum[src, 1]
    soa_point_sum[dst, 2] = soa_point_sum[src, 2]
    soa_color_sum[dst, 0] = soa_color_sum[src, 0]
    soa_color_sum[dst, 1] = soa_color_sum[src, 1]
    soa_color_sum[dst, 2] = soa_color_sum[src, 2]
    soa_weight[dst] = soa_weight[src]
    soa_hit_count[dst] = soa_hit_count[src]
    soa_pixel_count[dst] = soa_pixel_count[src]
    soa_free_count[dst] = soa_free_count[src]
    soa_log_odds[dst] = soa_log_odds[src]
    # Frame indices
    soa_first_seen_idx[dst] = soa_first_seen_idx[src]
    soa_last_seen_idx[dst] = soa_last_seen_idx[src]
    # State
    soa_is_stable[dst] = soa_is_stable[src]
    soa_promoted_idx[dst] = soa_promoted_idx[src]
    soa_inactive_cand[dst] = soa_inactive_cand[src]
    soa_inactive_idx[dst] = soa_inactive_idx[src]
    # View evidence
    soa_max_baseline[dst] = soa_max_baseline[src]
    soa_max_view_angle[dst] = soa_max_view_angle[src]
    soa_first_cam_c[dst, 0] = soa_first_cam_c[src, 0]
    soa_first_cam_c[dst, 1] = soa_first_cam_c[src, 1]
    soa_first_cam_c[dst, 2] = soa_first_cam_c[src, 2]
    soa_last_cam_c[dst, 0] = soa_last_cam_c[src, 0]
    soa_last_cam_c[dst, 1] = soa_last_cam_c[src, 1]
    soa_last_cam_c[dst, 2] = soa_last_cam_c[src, 2]
    soa_first_view_d[dst, 0] = soa_first_view_d[src, 0]
    soa_first_view_d[dst, 1] = soa_first_view_d[src, 1]
    soa_first_view_d[dst, 2] = soa_first_view_d[src, 2]
    soa_last_view_d[dst, 0] = soa_last_view_d[src, 0]
    soa_last_view_d[dst, 1] = soa_last_view_d[src, 1]
    soa_last_view_d[dst, 2] = soa_last_view_d[src, 2]
    soa_consec_free[dst] = soa_consec_free[src]
