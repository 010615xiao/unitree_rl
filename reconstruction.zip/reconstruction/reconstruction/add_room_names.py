#!/usr/bin/env python3
"""为 scene_graph.json 中的房间添加语义化名称"""

import json
from pathlib import Path

OUTPUT_DIR = Path("/workspace/wxd/VLN/vln_agent_0421/reconstruction/unified_output")
SCENE_GRAPH = OUTPUT_DIR / "scene_graph.json"

ROOM_NAMES = {
    0: "茶水间",
    1: "厨房",
    2: "电梯间",
    3: "多功能区",
    4: "会议室",
}

def main():
    if not SCENE_GRAPH.exists():
        print(f"错误: scene_graph.json 不存在: {SCENE_GRAPH}")
        return

    with open(SCENE_GRAPH, 'r', encoding='utf-8') as f:
        scene_graph = json.load(f)

    rooms = scene_graph.get('rooms', [])
    if not rooms:
        print("场景图中没有房间")
        return

    print(f"共 {len(rooms)} 个房间，正在添加语义名称...")

    for room in rooms:
        room_id = room['id']
        room['name'] = ROOM_NAMES.get(room_id, f"未命名区域_{room_id}")
        print(f"  room_{room_id} -> {room['name']}")

    with open(SCENE_GRAPH, 'w', encoding='utf-8') as f:
        json.dump(scene_graph, f, indent=2, ensure_ascii=False)

    print(f"\n✓ 已更新: {SCENE_GRAPH}")

if __name__ == '__main__':
    main()
