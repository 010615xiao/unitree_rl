#!/usr/bin/env python3
"""
单帧分割结果可视化 Demo

给定一张 RGB 图像，自动查找对应的深度图和相机位姿，依次运行:
  1. Depth Anything V3  → 彩色深度图
  2. VLM 开放词汇检测   → 文本输出物体类别
  3. GroundingDINO 检测 → 绘制边界框在图片上
  4. SAM2 分割          → 绘制彩色掩码在图片上
  5. 3D 点云生成        → 每个物体用不同颜色渲染点云

用法:
  # 最常用：指定时间戳，自动查找 depth 和 pose
  python demo_single_frame_segmentation.py --frame 1757050962351.9097

  # 指定完整图片路径，自动从文件名推断
  python demo_single_frame_segmentation.py --image /workspace/wxd/VLN/datasets/icra_ic7f/images/1757050962351.9097.png

  # 从数据集中自动选取第一帧
  python demo_single_frame_segmentation.py --auto-select

  # 自定义检测类别
  python demo_single_frame_segmentation.py --frame 1757050962351.9097 --categories "chair,table,sofa"

  # 指定其他数据集
  python demo_single_frame_segmentation.py --frame xxx --data-dir /path/to/other_dataset
"""

import argparse
import numpy as np
import open3d as o3d
import cv2
import json
from pathlib import Path
from datetime import datetime
import requests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# 直接从 data_adapter 导入，避免 import reconstruct_and_segment 时触发其 __main__
from data_adapter import DatasetAdapter

# ================= 配置 =================
BASE_DIR = Path(__file__).parent
DATA_DIR = Path("/workspace/wxd/VLN/datasets/icra_ic7f")
adapter = DatasetAdapter(DATA_DIR)

OUTPUT_DIR = BASE_DIR / "demo_output"
OUTPUT_DIR.mkdir(exist_ok=True)

# 服务地址
VLM_API_URL = "http://localhost:8008/v1/chat/completions"
GROUNDING_DINO_URL = "http://localhost:20021/detect"
SAM2_URL = "http://localhost:20020/infer"
DEPTH_ANYTHING_V3_URL = "http://localhost:20022"

# 深度参数 (与主项目一致)
DEPTH_MIN = 0.3
DEPTH_MAX = 6.0
DEPTH_SCALE = 1000.0

# 坐标轴变换
USE_AXIS_TRANSFORM = True
T_SWITCH_AXIS = np.array([
    [1, 0, 0, 0],
    [0, 0, 1, 0],
    [0, -1, 0, 0],
    [0, 0, 0, 1]
], dtype=np.float64)

# 可视化配色
OBJECT_COLORS = {
    'floor': (0.2, 0.6, 0.2),    # 绿色
    'wall': (0.6, 0.2, 0.2),     # 红色
    'door': (0.2, 0.2, 0.8),     # 蓝色
    'window': (0.8, 0.8, 0.2),   # 黄色
    'chair': (0.8, 0.4, 0.1),    # 橙色
    'desk': (0.5, 0.2, 0.6),     # 紫色
    'table': (0.2, 0.8, 0.6),    # 青色
    'sofa': (0.9, 0.6, 0.7),     # 粉色
    'bed': (0.3, 0.7, 0.9),      # 天蓝
    'cabinet': (0.7, 0.5, 0.3),  # 棕色
}

CV_COLORS = {
    'floor': (0, 255, 0),
    'wall': (0, 0, 255),
    'door': (255, 0, 0),
    'window': (0, 255, 255),
    'chair': (0, 128, 255),
    'desk': (128, 0, 255),
    'table': (255, 255, 0),
    'sofa': (128, 128, 255),
    'bed': (255, 128, 128),
    'cabinet': (0, 165, 255),
}


def get_color(category):
    """RGB 浮点颜色"""
    if category in OBJECT_COLORS:
        return OBJECT_COLORS[category]
    np.random.seed(hash(category) % (2**32))
    return tuple(np.random.rand(3))


def get_cv_color(category):
    """BGR uint8 颜色"""
    if category in CV_COLORS:
        return CV_COLORS[category]
    np.random.seed(hash(category) % (2**32))
    rgb = np.random.rand(3)
    return (int(rgb[2] * 255), int(rgb[1] * 255), int(rgb[0] * 255))


# ──────────────── Step 1: VLM ────────────────

def clean_json_output(content):
    """清理 VLM 输出，提取有效 JSON (对象或数组)"""
    if content.startswith('```json'):
        content = content[7:]
    if content.startswith('```'):
        content = content[3:]
    if content.endswith('```'):
        content = content[:-3]
    content = content.strip()

    # 如果看起来像数组（以 [ 开头或包含 [ 在 { 之前），优先用 []
    bracket_pos = content.find('[')
    brace_pos = content.find('{')

    if bracket_pos >= 0 and (brace_pos < 0 or bracket_pos < brace_pos):
        # 数组优先：找最外层 [ ... ]
        # 从第一个 [ 开始，找最后一个 ]
        end = content.rfind(']') + 1
        if end > bracket_pos:
            return content[bracket_pos:end]

    # 对象：找第一个 { 和最后一个 }
    if brace_pos >= 0:
        end = content.rfind('}') + 1
        if end > brace_pos:
            return content[brace_pos:end]

    return content


def image_to_base64(image_path):
    """图片转 base64"""
    import base64
    with open(image_path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')


def vlm_detect_objects(image_path):
    """
    VLM 开放词汇检测
    返回: [{"category": str, "confidence": float}, ...]
    """
    prompt = """Look at this indoor image carefully and describe what you can see.
Then list only the objects that are actually visible (at least 50% of the object can be seen).

First, describe the scene in 1-2 sentences.
Then output a JSON list of objects with their confidence scores.

JSON format ONLY:
{"objects":[{"category":"name","confidence":0.0-1.0},...]}

Common indoor objects: chair, desk, table, sofa, bed, cabinet, shelf, counter, stool, door, window, stair, railing, pillar, sink, toilet, mirror, curtain, plant, tv, monitor, lamp, clock, fan, trash_can, refrigerator, wall, floor, rug, picture

Rules:
- ONLY include objects you can actually see in the image
- Give different confidence scores based on how clearly visible each object is
- 0.9-1.0 = fully visible, 0.7-0.89 = mostly visible, 0.5-0.69 = partially visible
- Do NOT list all categories - only what you see
- Max 10 objects
- lowercase, underscore for multi-word"""

    try:
        image_b64 = image_to_base64(image_path)
        suffix = Path(image_path).suffix.lower()
        mime = "jpeg" if suffix in (".jpg", ".jpeg") else "png"

        payload = {
            "model": "RoboBrain2.5-8B",
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": f"data:image/{mime};base64,{image_b64}"}},
                    {"type": "text", "text": prompt}
                ]
            }],
            "max_tokens": 500,
            "temperature": 0.1,
            "stream": False
        }

        resp = requests.post(VLM_API_URL, json=payload, timeout=120)
        resp.raise_for_status()
        content = resp.json()['choices'][0]['message']['content'].strip()

        # 打印 VLM 原始输出（方便调试）
        print(f"\n  VLM 原始输出:")
        for line in content.split('\n'):
            print(f"    {line}")

        # 提取 JSON：找第一个 { 或 [ 到最后一个 } 或 ]
        cleaned = clean_json_output(content)
        # 兼容两种格式: {"objects":[...]} 或直接 [...]
        if cleaned.startswith('['):
            raw_list = json.loads(cleaned)
            data = {'objects': raw_list}
        else:
            data = json.loads(cleaned)

        objects = []
        seen = set()
        for obj in data.get('objects', []):
            cat = str(obj.get('category', '')).lower().strip().replace(' ', '_')
            if not cat or cat == 'ceiling' or cat in seen:
                continue
            seen.add(cat)
            objects.append({
                'category': cat,
                'confidence': float(obj.get('confidence', 0.5))
            })

        return objects

    except Exception as e:
        print(f"  VLM 检测失败: {e}")
        return []


# ──────────────── Step 2: GroundingDINO ────────────────

def grounding_dino_detect(image_path, category):
    """
    GroundingDINO 单类别检测
    返回: [{"box": [x1,y1,x2,y2], "score": float, "label": str}, ...]
    """
    try:
        payload = {
            "image_path": str(image_path),
            "text_prompt": category,
            "box_threshold": 0.3,
            "text_threshold": 0.25
        }

        resp = requests.post(GROUNDING_DINO_URL, json=payload, timeout=30)
        resp.raise_for_status()
        result = resp.json()

        if not result.get('success', False):
            return []

        boxes = result.get('boxes', [])
        labels = result.get('labels', [])
        scores = result.get('scores', [])

        detections = []
        for i, box in enumerate(boxes[:5]):  # 最多 5 个
            detections.append({
                'box': box,
                'score': scores[i] if i < len(scores) else 0.5,
                'label': labels[i] if i < len(labels) else category
            })

        return detections

    except Exception as e:
        print(f"  GroundingDINO 失败 ({category}): {e}")
        return []


# ──────────────── Step 3: SAM2 ────────────────

def sam2_segment(image_path, box):
    """
    SAM2 单框分割
    返回: {"mask": ndarray, "score": float} 或 None
    """
    try:
        img = cv2.imread(str(image_path))
        if img is None:
            return None
        h, w = img.shape[:2]

        payload = {
            "image_path": str(image_path),
            "box": box
        }

        resp = requests.post(SAM2_URL, json=payload, timeout=30)
        resp.raise_for_status()
        result = resp.json()

        if not result.get('success', False):
            return None

        if 'mask' in result:
            import base64
            mask_data = base64.b64decode(result['mask'])
            mask_np = cv2.imdecode(np.frombuffer(mask_data, dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
            if mask_np is not None and mask_np.shape == (h, w):
                return {
                    'mask': mask_np,
                    'score': result.get('score', 0)
                }

        return None

    except Exception as e:
        print(f"  SAM2 失败: {e}")
        return None


# ──────────────── Step 4: 2D 可视化 ────────────────

def visualize_2d(image_path, all_detections, all_masks, output_dir):
    """
    生成 3 张 2D 可视化:
      - 边界框图
      - SAM2 掩码叠加图
      - 组合图
    """
    img = cv2.imread(str(image_path))
    if img is None:
        return

    # --- 边界框 ---
    img_bbox = img.copy()
    for category, detections in all_detections.items():
        color = get_cv_color(category)
        for det in detections:
            x1, y1, x2, y2 = [int(v) for v in det['box']]
            cv2.rectangle(img_bbox, (x1, y1), (x2, y2), color, 2)
            label = f"{category} {det['score']:.2f}"
            cv2.putText(img_bbox, label, (x1, max(y1 - 5, 20)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

    f1 = output_dir / "01_bounding_boxes.png"
    cv2.imwrite(str(f1), img_bbox)
    print(f"  ✓ 边界框: {f1}")

    # --- SAM2 掩码 ---
    img_mask = img.copy()
    for category, masks in all_masks.items():
        color = get_cv_color(category)
        for m in masks:
            overlay = img_mask.copy()
            overlay[m['mask'] > 128] = color
            cv2.addWeighted(overlay, 0.4, img_mask, 0.6, 0, img_mask)

            contours, _ = cv2.findContours(
                (m['mask'] > 128).astype(np.uint8),
                cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(img_mask, contours, -1, color, 2)

    f2 = output_dir / "02_sam2_masks.png"
    cv2.imwrite(str(f2), img_mask)
    print(f"  ✓ 掩码: {f2}")

    # --- 组合 ---
    img_combined = img.copy()
    for category, masks in all_masks.items():
        color = get_cv_color(category)
        for m in masks:
            overlay = img_combined.copy()
            overlay[m['mask'] > 128] = color
            cv2.addWeighted(overlay, 0.35, img_combined, 0.65, 0, img_combined)

    for category, detections in all_detections.items():
        color = get_cv_color(category)
        for det in detections:
            x1, y1, x2, y2 = [int(v) for v in det['box']]
            cv2.rectangle(img_combined, (x1, y1), (x2, y2), color, 2)
            label = f"{category} {det['score']:.2f}"
            cv2.putText(img_combined, label, (x1, max(y1 - 5, 20)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

    f3 = output_dir / "03_combined.png"
    cv2.imwrite(str(f3), img_combined)
    print(f"  ✓ 组合: {f3}")


# ──────────────── Step 5: 3D 点云 ────────────────

def mask_to_3d(mask_2d, depth_img, K, T_c2w):
    """2D 掩码 → 3D 点云 (世界坐标)"""
    depth = depth_img.astype(np.float32)
    mask_binary = (mask_2d > 128).astype(np.uint8)

    valid = (mask_binary > 0) & (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
    if valid.sum() == 0:
        return np.empty((0, 3))

    v, u = np.where(valid)
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    z = depth[v, u]
    x_cam = (u - cx) * z / fx
    y_cam = (v - cy) * z / fy

    pts_cam = np.stack([x_cam, y_cam, z], axis=-1)
    pts_hom = np.hstack([pts_cam, np.ones((len(pts_cam), 1))])
    pts_world = (T_c2w @ pts_hom.T).T[:, :3]
    return pts_world


def generate_3d(image_path, depth_file, K, pose_line, all_masks, output_dir):
    """为每个物体生成彩色 3D 点云 (含场景背景)"""
    # Depth Anything V3 彩色深度图 + 密集深度点云
    da3_pts, da3_depth_map = load_da3_depth(image_path, output_dir)
    if da3_pts is None or len(da3_pts) == 0:
        print("  ⚠ DA3 深度图加载失败")
        return

    # 使用 DA3 密集深度图生成 3D 点云
    h, w = da3_depth_map.shape

    # 构建物体掩码的像素集合 (在 DA3 分辨率下)
    obj_pixels = set()
    for category, masks in all_masks.items():
        for m in masks:
            mask = m['mask'] > 128
            # 如果掩码分辨率与 DA3 不同，需要 resize
            if mask.shape != (h, w):
                mask = cv2.resize(mask.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST) > 0
            ys, xs = np.where(mask)
            for y, x in zip(ys, xs):
                obj_pixels.add((y, x))

    T_c2w = parse_pose(pose_line)
    bg_color = np.array([0.7, 0.7, 0.7])

    # DA3 的内参 (与 DA3 server 一致: FOV=60°)
    fx_da3 = w / (2 * np.tan(np.deg2rad(60) / 2))
    fy_da3 = fx_da3
    cx_da3 = w / 2
    cy_da3 = h / 2

    # 生成背景点云 (排除物体区域)
    valid_mask = np.ones((h, w), dtype=bool)
    for y, x in obj_pixels:
        valid_mask[y, x] = False

    vv, uu = np.where(valid_mask)
    valid_depth = da3_depth_map[vv, uu]
    depth_valid = (valid_depth > DEPTH_MIN) & (valid_depth < DEPTH_MAX)
    vv, uu = vv[depth_valid], uu[depth_valid]
    valid_depth = valid_depth[depth_valid]

    if len(vv) > 0:
        X_cam = (uu - cx_da3) * valid_depth / fx_da3
        Y_cam = (vv - cy_da3) * valid_depth / fy_da3
        Z_cam = valid_depth
        pts_cam = np.stack([X_cam, Y_cam, Z_cam, np.ones_like(X_cam)], axis=1)
        bg_pts = (T_c2w @ pts_cam.T).T[:, :3]
        bg_clr = np.tile(bg_color, (len(bg_pts), 1))
    else:
        bg_pts = np.empty((0, 3))
        bg_clr = np.empty((0, 3))

    # 物体点云 (使用 DA3 密集深度)
    category_pts = {}
    category_clr = {}
    for category, masks in all_masks.items():
        rgb = get_color(category)
        category_clr[category] = rgb
        pts_list = []
        for m in masks:
            mask = m['mask'] > 128
            if mask.shape != (h, w):
                mask = cv2.resize(mask.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST) > 0

            valid_obj = (mask) & (da3_depth_map > DEPTH_MIN) & (da3_depth_map < DEPTH_MAX)
            if valid_obj.sum() == 0:
                continue
            vv, uu = np.where(valid_obj)
            z = da3_depth_map[vv, uu]
            X_cam = (uu - cx_da3) * z / fx_da3
            Y_cam = (vv - cy_da3) * z / fy_da3
            pts_cam = np.stack([X_cam, Y_cam, z, np.ones_like(X_cam)], axis=1)
            pts_world = (T_c2w @ pts_cam.T).T[:, :3]
            if len(pts_world) > 0:
                pts_list.append(pts_world)
        if pts_list:
            category_pts[category] = np.vstack(pts_list)

    # 合并: 背景 + 物体
    points_to_stack = [bg_pts]
    colors_to_stack = [bg_clr]
    for cat, pts in category_pts.items():
        rgb = category_clr[cat]
        points_to_stack.append(pts)
        colors_to_stack.append(np.tile(rgb, (len(pts), 1)))

    merged_pts = np.vstack(points_to_stack)
    merged_clr = np.vstack(colors_to_stack)

    ply = output_dir / "04_segmented_pointcloud.ply"
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(merged_pts)
    pcd.colors = o3d.utility.Vector3dVector(merged_clr)
    o3d.io.write_point_cloud(str(ply), pcd)

    # 打印统计
    print("\n  点云统计:")
    print(f"    • {'背景 (场景)':<20} {len(bg_pts):>6,} 点  RGB({bg_color[0]:.2f}, {bg_color[1]:.2f}, {bg_color[2]:.2f})")
    for cat, pts in category_pts.items():
        rgb = category_clr[cat]
        print(f"    • {cat:<20} {len(pts):>6,} 点  RGB({rgb[0]:.2f}, {rgb[1]:.2f}, {rgb[2]:.2f})")
    print(f"\n  ✓ 总计: {len(merged_pts):,} 点 → {ply}")
    print(f"  (可用 MeshLab / CloudCompare 查看)")


def load_da3_depth(image_path, output_dir):
    """
    使用 Depth Anything V3 生成深度图和彩色深度可视化

    返回:
        points: ndarray [N, 3] - 相机坐标系下的 3D 点云 (DA3 生成的)
        depth_map: ndarray [H, W] - 深度图 (米)
    """
    try:
        resp = requests.post(f"{DEPTH_ANYTHING_V3_URL}/generate_point_cloud", json={
            "image_path": str(image_path)
        }, timeout=60)

        data = resp.json()
        if not data.get("success"):
            print(f"  ⚠ DA3 返回失败: {data.get('error', 'unknown')}")
            return None, None

        points = np.array(data["points"], dtype=np.float32)
        shape = data["shape"]
        h, w = shape

        # 从点云重建深度图 (z 轴 = 深度)
        depth_map = points[:, 2].reshape(h, w)

        # 彩色可视化 (Inferno 色图)
        depth_vis = cv2.normalize(depth_map, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        depth_vis_color = cv2.applyColorMap(depth_vis, cv2.COLORMAP_INFERNO)

        f = output_dir / "00_depth_anything_v3.png"
        cv2.imwrite(str(f), depth_vis_color)
        print(f"  ✓ Depth Anything V3 深度图: {f} (范围: {depth_map.min():.2f} ~ {depth_map.max():.2f} m)")

        return points, depth_map

    except Exception as e:
        print(f"  ⚠ Depth Anything V3 失败: {e}")
        return None, None


def parse_pose(pose_line):
    """解析 TUM 位姿行 → 4x4 矩阵"""
    parts = pose_line.strip().split()

    if len(parts) == 8:
        tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
        qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])
    elif len(parts) == 7:
        tx, ty, tz = float(parts[0]), float(parts[1]), float(parts[2])
        qx, qy, qz, qw = float(parts[3]), float(parts[4]), float(parts[5]), float(parts[6])
    elif len(parts) == 16:
        return np.array([float(v) for v in parts]).reshape(4, 4)
    else:
        raise ValueError(f"无法解析位姿: {pose_line}")

    q = np.array([qx, qy, qz, qw])
    q /= np.linalg.norm(q)
    x, y, z, w = q
    R = np.array([
        [1-2*y*y-2*z*z, 2*x*y-2*z*w, 2*x*z+2*y*w],
        [2*x*y+2*z*w, 1-2*x*x-2*z*z, 2*y*z-2*x*w],
        [2*x*z-2*y*w, 2*y*z+2*x*w, 1-2*x*x-2*y*y]
    ])
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = [tx, ty, tz]

    if USE_AXIS_TRANSFORM:
        T = T_SWITCH_AXIS @ T
    return T


# ──────────────── Auto Select ────────────────

def auto_select_frame():
    """从数据集中自动选取第一帧"""
    depth_files = adapter.get_depth_file_list(max_frames=1)
    if not depth_files:
        return None, None, None

    depth_file = depth_files[0]
    timestamp = depth_file.stem
    color_file = adapter.match_color_file(timestamp)
    if color_file is None:
        return None, None, None

    # 加载位姿
    poses_file = adapter.poses_file
    poses = {}
    with open(poses_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) >= 8:
                poses[parts[0]] = line
                break  # 取第一个

    if not poses:
        return None, None, None

    return color_file, depth_file, list(poses.values())[0]


# ──────────────── Main ────────────────

def find_depth_and_pose(timestamp, data_dir):
    """
    根据 RGB 时间戳自动查找对应的深度图和位姿

    参数:
        timestamp: 如 "1757050962351.9097" (不含扩展名)
        data_dir:  数据集根目录

    返回:
        (color_file, depth_file, pose_str) 或 (None, None, None)
    """
    data_dir = Path(data_dir)
    images_dir = data_dir / "images"
    depth_dir = data_dir / "depth"
    poses_file = data_dir / "poses.txt"

    # 找 RGB 文件
    color_file = None
    for ext in [".png", ".jpg", ".jpeg"]:
        candidate = images_dir / f"{timestamp}{ext}"
        if candidate.exists():
            color_file = candidate
            break

    if color_file is None:
        print(f"  ✗ RGB 图像不存在: {images_dir}/{timestamp}.*")
        return None, None, None

    # 找深度图 (同名)
    depth_file = None
    for ext in [".png", ".jpg", ".jpeg"]:
        candidate = depth_dir / f"{timestamp}{ext}"
        if candidate.exists():
            depth_file = candidate
            break

    if depth_file is None:
        print(f"  ✗ 深度图不存在: {depth_dir}/{timestamp}.*")
        return None, None, None

    # 找位姿 (匹配时间戳前缀)
    pose_str = None
    if poses_file.exists():
        with open(poses_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line.startswith(timestamp):
                    pose_str = line
                    break

    if pose_str is None:
        print(f"  ✗ 位姿文件中未找到时间戳: {timestamp}")
        return None, None, None

    return color_file, depth_file, pose_str


def main():
    parser = argparse.ArgumentParser(description='单帧分割可视化 Demo')
    parser.add_argument('--image', type=str, help='RGB 图像路径 (或仅时间戳，配合 --frame)')
    parser.add_argument('--depth', type=str, help='深度图路径 (自动查找时可省略)')
    parser.add_argument('--pose', type=str, help='相机位姿 (自动查找时可省略)')
    parser.add_argument('--frame', type=str,
                        help='RGB 文件名/时间戳 (不含扩展名), 如 1757050962351.9097')
    parser.add_argument('--data-dir', type=str,
                        default="/workspace/wxd/VLN/datasets/icra_ic7f",
                        help='数据集根目录')
    parser.add_argument('--categories', type=str, default='floor,wall,door',
                        help='检测类别，逗号分隔 (默认: floor,wall,door)')
    parser.add_argument('--auto-select', action='store_true', help='从数据集自动选取第一帧')
    parser.add_argument('--output', type=str, help='输出目录')
    args = parser.parse_args()

    print("=" * 60)
    print("  单帧分割可视化 Demo")
    print("=" * 60)

    color_file = None
    depth_file = None
    pose_str = None

    # 方式 1: --frame 时间戳，自动查找 depth 和 pose
    if args.frame:
        print(f"\n[查找] 时间戳: {args.frame}")
        color_file, depth_file, pose_str = find_depth_and_pose(args.frame, args.data_dir)

    # 方式 2: --auto-select
    elif args.auto_select:
        print("\n[自动选取] 从数据集中选取第一帧...")
        color_file, depth_file, pose_str = auto_select_frame()

    # 方式 3: --image (完整路径) + --depth + --pose
    elif args.image and args.depth and args.pose:
        color_file = Path(args.image)
        depth_file = Path(args.depth)
        pose_str = args.pose

    # 方式 4: 仅 --image 完整路径，尝试从文件名推断 depth 和 pose
    elif args.image:
        img_path = Path(args.image)
        if img_path.exists():
            timestamp = img_path.stem
            print(f"\n[查找] 从图像文件名推断时间戳: {timestamp}")
            color_file, depth_file, pose_str = find_depth_and_pose(timestamp, args.data_dir)
            if color_file is None:
                # 找不到 depth/pose，但至少 image 存在
                color_file = img_path
                print(f"  ⚠ 未找到对应的 depth/pose，将仅处理 2D 结果")
        else:
            print(f"  ✗ 图像不存在: {img_path}")
            return

    if color_file is None or depth_file is None or pose_str is None:
        print("\n  无法获取完整的 image + depth + pose")
        print("  用法:")
        print(f"    --frame 1757050962351.9097              # 推荐：自动查找")
        print(f"    --auto-select                            # 选第一帧")
        print(f"    --image path --depth path --pose line    # 完整指定")
        return

    # 输出目录
    if args.output:
        out_dir = Path(args.output)
    else:
        out_dir = OUTPUT_DIR / datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n  输出: {out_dir}")

    categories = [c.strip().lower() for c in args.categories.split(',') if c.strip()]
    print(f"  类别: {categories}")
    K = adapter.K
    print(f"  内参: fx={K[0,0]:.1f}, fy={K[1,1]:.1f}, cx={K[0,2]:.1f}, cy={K[1,2]:.1f}")

    # ====== Step 1: VLM ======
    print("\n" + "-" * 40)
    print("[1] VLM 开放词汇检测")
    print("-" * 40)
    vlm_objects = vlm_detect_objects(color_file)

    # 不进行类别过滤，VLM 看到什么就检测什么
    if not vlm_objects:
        print("\n  VLM 未检测到任何物体")
        return

    print(f"\n  检测到 {len(vlm_objects)} 个物体:")
    for obj in vlm_objects:
        print(f"    • {obj['category']:<15} (confidence: {obj['confidence']:.2f})")

    # ====== Step 2: GroundingDINO ======
    print("\n" + "-" * 40)
    print("[2] GroundingDINO 检测")
    print("-" * 40)

    all_detections = {}  # category → [detections]
    for obj in vlm_objects:
        cat = obj['category']
        dets = grounding_dino_detect(color_file, cat)
        if dets:
            all_detections[cat] = dets
            print(f"  {cat}: {len(dets)} 个框")

    if not all_detections:
        print("  无检测结果，退出")
        return

    # ====== Step 3: SAM2 ======
    print("\n" + "-" * 40)
    print("[3] SAM2 分割")
    print("-" * 40)

    all_masks = {}  # category → [masks]
    for cat, dets in all_detections.items():
        cat_masks = []
        for det in dets:
            m = sam2_segment(color_file, det['box'])
            if m:
                cat_masks.append(m)
        if cat_masks:
            all_masks[cat] = cat_masks
            print(f"  {cat}: {len(cat_masks)} 个掩码")

    if not all_masks:
        print("  无掩码，退出")
        return

    # ====== Step 4: 2D 可视化 ======
    print("\n" + "-" * 40)
    print("[4] 2D 可视化")
    print("-" * 40)
    visualize_2d(color_file, all_detections, all_masks, out_dir)

    # ====== Step 5: 3D 点云 ======
    print("\n" + "-" * 40)
    print("[5] 3D 点云")
    print("-" * 40)
    generate_3d(color_file, depth_file, K, pose_str, all_masks, out_dir)

    # ====== 摘要 ======
    summary = {
        'image': str(color_file),
        'depth': str(depth_file),
        'pose': pose_str,
        'timestamp': datetime.now().isoformat(),
        'vlm_objects': [{'category': o['category'], 'confidence': o['confidence']} for o in vlm_objects],
        'detections': {cat: [{'box': d['box'], 'score': d['score']} for d in dets] for cat, dets in all_detections.items()},
        'masks': {cat: [{'score': m['score']} for m in masks] for cat, masks in all_masks.items()},
        'output_files': {
            'depth_anything_v3': str(out_dir / "00_depth_anything_v3.png"),
            'bounding_boxes': str(out_dir / "01_bounding_boxes.png"),
            'sam2_masks': str(out_dir / "02_sam2_masks.png"),
            'combined': str(out_dir / "03_combined.png"),
            'pointcloud_ply': str(out_dir / "04_segmented_pointcloud.ply"),
            'pointcloud_3d': str(out_dir / "05_pointcloud_3d.png"),
        }
    }

    summary_file = out_dir / "00_summary.json"
    with open(summary_file, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"\n  ✓ 摘要: {summary_file}")

    print("\n" + "=" * 60)
    print(f"完成! 结果已保存到: {out_dir}")
    print("=" * 60)


if __name__ == '__main__':
    main()
