#!/usr/bin/env python3
"""
房间分割参数调试工具 — 从已有全局点云快速测试不同分割参数

用法:
  python tune_room_segmentation.py                           # 默认参数
  python tune_room_segmentation.py --hist 0.20 --blur 5      # 调直方图阈值和模糊核
  python tune_room_segmentation.py --grid 0.08               # 调整栅格分辨率
  python tune_room_segmentation.py --pcd /path/to/cloud.ply  # 指定点云文件

输出:
  房间数量、每个房间的面积、房间中心坐标、俯视图可视化
"""

import numpy as np
import open3d as o3d
import cv2
import os
import json
import argparse
from pathlib import Path
from scipy.ndimage import label as ndimage_label


# ================= 默认参数 (与 reconstruct_and_segment.py 保持一致) =================
DEFAULT_HIST_THRESHOLD_RATIO = 0.20
DEFAULT_GAUSSIAN_BLUR_KERNEL = 7
DEFAULT_GAUSSIAN_BLUR_SIGMA = 0
DEFAULT_GRID_RESOLUTION = 0.05
DEFAULT_MIN_COMPONENT_AREA = 25  # 最小连通区域面积 (像素)
DEFAULT_MIN_ROOM_AREA = 0.5       # 最小房间面积 (m²)
DEFAULT_MIN_PEAK_HEIGHT = 1       # watershed 种子最小高度


def load_point_cloud(pcd_path):
    """加载点云"""
    pcd = o3d.io.read_point_cloud(str(pcd_path))
    points = np.asarray(pcd.points)
    colors = np.asarray(pcd.colors)
    if len(colors) == 0:
        colors = np.ones_like(points) * 0.5
    print(f"  点云: {len(points):,} 点")
    return points, colors


def run_room_segmentation(points, colors, hist_threshold_ratio, gaussian_blur_kernel,
                           grid_resolution, min_component_area, min_room_area,
                           save_dir, visualize=True):
    """
    运行房间分割，返回房间信息
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    # 只取地面附近 + 墙面的点 (Y 是垂直方向)
    ground_y = points[:, 1].min()
    mask = (points[:, 1] >= ground_y) & (points[:, 1] <= ground_y + 2.0)
    pcd_filtered = points[mask]
    colors_filtered = colors[mask]
    print(f"  地面附近点: {len(pcd_filtered):,} (Y 范围: {ground_y:.2f} ~ {ground_y + 2.0:.2f})")

    # 投影到 XZ 平面
    pcd_2d = pcd_filtered[:, [0, 2]]

    # 计算 2D 直方图
    grid_size = (
        int(np.max(pcd_2d[:, 0]) - np.min(pcd_2d[:, 0])),
        int(np.max(pcd_2d[:, 1]) - np.min(pcd_2d[:, 1]))
    )
    grid_size = (grid_size[0] + 1, grid_size[1] + 1)
    print(f"  栅格尺寸: {grid_size}")

    num_bins = (int(grid_size[0] // grid_resolution),
                int(grid_size[1] // grid_resolution))
    num_bins = (num_bins[1] + 1, num_bins[0] + 1)

    hist, _, _ = np.histogram2d(pcd_2d[:, 1], pcd_2d[:, 0], bins=num_bins)
    hist_full, _, _ = np.histogram2d(pcd_2d[:, 1], pcd_2d[:, 0], bins=num_bins)

    # 墙体骨架处理
    padding = 10
    hist_norm = cv2.normalize(hist, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_blur = cv2.GaussianBlur(hist_norm, (gaussian_blur_kernel, gaussian_blur_kernel), DEFAULT_GAUSSIAN_BLUR_SIGMA)
    hist_threshold = hist_threshold_ratio * np.max(hist_blur)
    _, walls_skeleton = cv2.threshold(hist_blur, hist_threshold, 255, cv2.THRESH_BINARY)
    walls_skeleton = cv2.copyMakeBorder(walls_skeleton, padding, padding, padding, padding, cv2.BORDER_CONSTANT, value=0)
    kernel_cross = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    walls_skeleton = cv2.morphologyEx(walls_skeleton, cv2.MORPH_CLOSE, kernel_cross, iterations=1)

    # 外部边界处理
    hist_full_norm = cv2.normalize(hist_full, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_full_blur = cv2.GaussianBlur(hist_full_norm, (21, 21), 2)
    _, outside_boundary = cv2.threshold(hist_full_blur, 0, 255, cv2.THRESH_BINARY)
    outside_boundary = cv2.copyMakeBorder(outside_boundary, padding, padding, padding, padding, cv2.BORDER_CONSTANT, value=0)
    kernel_rect_5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    outside_boundary = cv2.morphologyEx(outside_boundary, cv2.MORPH_CLOSE, kernel_rect_5, iterations=3)

    # 提取外部轮廓
    outside_boundary_filled = np.zeros_like(outside_boundary)
    contours, _ = cv2.findContours(outside_boundary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(outside_boundary_filled, contours, -1, 255, -1)
    outside_boundary_filled = outside_boundary_filled.astype(np.uint8)

    # Watershed 分水岭
    distance = cv2.distanceTransform((255 - walls_skeleton).astype(np.uint8), cv2.DIST_L2, 3)
    distance_norm = cv2.normalize(distance, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    # 找局部最大值作为种子
    ret, markers = cv2.threshold(distance_norm, 0, 0, cv2.THRESH_BINARY)
    markers = markers.astype(np.int32)

    num_peaks = 0
    min_peak_val = np.max(distance_norm) * 0.8
    peaks_mask = (distance_norm >= min_peak_val) & (distance_norm > DEFAULT_MIN_PEAK_HEIGHT)
    peaks_labels, num_peaks = ndimage_label(peaks_mask)

    if num_peaks > 0:
        for i in range(1, num_peaks + 1):
            markers[peaks_labels == i] = i
    else:
        print("  ⚠ 未找到 watershed 种子")
        return []

    markers = cv2.watershed(cv2.cvtColor(walls_skeleton, cv2.COLOR_GRAY2BGR), markers)

    # 计算每个区域的连通面积，过滤小区域
    unique_labels = np.unique(markers[markers > 0])
    valid_labels = []
    for lb in unique_labels:
        component_mask = (markers == lb)
        num_components, component_sizes = ndimage_label(component_mask)
        if num_components == 1 and component_sizes[0] >= min_component_area:
            valid_labels.append(lb)
        else:
            for comp_idx in range(1, num_components + 1):
                comp_mask = (component_sizes == comp_idx)
                if comp_mask.sum() >= min_component_area:
                    valid_labels.append(lb)  # 保留原始标签
                    break

    # 提取房间信息
    rooms = []
    for i, lb in enumerate(valid_labels):
        mask_2d = (markers == lb)
        if mask_2d.sum() == 0:
            continue

        # 映射回原始 2D 坐标
        h, w = mask_2d.shape
        ys, xs = np.where(mask_2d)
        x_world = xs + pcd_2d[:, 0].min()
        z_world = ys + pcd_2d[:, 1].min()

        room_points_2d = np.column_stack([x_world, z_world])
        area_m2 = len(room_points_2d) * (grid_resolution ** 2)

        if area_m2 < min_room_area:
            continue

        room_center_2d = room_points_2d.mean(axis=0)
        room_center_3d = np.array([room_center_2d[0], ground_y, room_center_2d[1]])

        # 获取房间内 3D 点的实际范围
        x_range = (room_points_2d[:, 0].min(), room_points_2d[:, 0].max())
        z_range = (room_points_2d[:, 1].min(), room_points_2d[:, 1].max())

        # 3D 包围盒
        pts_3d_in_room = points[
            (points[:, 0] >= x_range[0]) & (points[:, 0] <= x_range[1]) &
            (points[:, 2] >= z_range[0]) & (points[:, 2] <= z_range[1])
        ]
        y_min_room = float(pts_3d_in_room[:, 1].min()) if len(pts_3d_in_room) > 0 else ground_y
        y_max_room = float(pts_3d_in_room[:, 1].max()) if len(pts_3d_in_room) > 0 else ground_y + 2.0

        rooms.append({
            'room_id': i,
            'center': [float(room_center_3d[0]), float(room_center_3d[1]), float(room_center_3d[2])],
            'bbox': {
                'min': [float(x_range[0]), y_min_room, float(z_range[0])],
                'max': [float(x_range[1]), y_max_room, float(z_range[1])]
            },
            'area': float(area_m2),
            'num_points_2d': int(len(room_points_2d)),
            'num_points_3d': int(len(pts_3d_in_room)),
        })

    # ================= 可视化 =================
    if visualize and len(rooms) > 0:
        save_dir = Path(save_dir)
        save_dir.mkdir(parents=True, exist_ok=True)

        # 俯视图
        fig, ax = plt.subplots(figsize=(14, 10))
        room_centers_2d = np.array([[r['center'][0], r['center'][2]] for r in rooms])
        cmap = plt.cm.tab20(np.linspace(0, 1, max(len(rooms), 1)))

        for r_idx, r in enumerate(rooms):
            x_min_r, x_max_r = r['bbox']['min'][0], r['bbox']['max'][0]
            z_min_r, z_max_r = r['bbox']['min'][2], r['bbox']['max'][2]
            rect = plt.Rectangle(
                (x_min_r, z_min_r), x_max_r - x_min_r, z_max_r - z_min_r,
                fill=True, alpha=0.3, color=cmap[r_idx % len(cmap)],
                linewidth=2, edgecolor='black'
            )
            ax.add_patch(rect)
            ax.annotate(
                f"R{r['room_id']}\n{r['area']:.1f}m²",
                (r['center'][0], r['center'][2]),
                fontsize=9, ha='center', va='center', fontweight='bold',
                color='white',
                bbox=dict(boxstyle='round', facecolor='black', alpha=0.7, pad=0.3)
            )

        ax.scatter(room_centers_2d[:, 0], room_centers_2d[:, 1],
                   c='red', s=80, marker='x', linewidths=2, zorder=5)

        ax.set_xlabel('X (m)')
        ax.set_ylabel('Z (m)')
        ax.set_title(f'Room Segmentation ({len(rooms)} rooms)')
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)
        ax.set_xlim(pcd_2d[:, 0].min() - 1, pcd_2d[:, 0].max() + 1)
        ax.set_ylim(pcd_2d[:, 1].max() + 1, pcd_2d[:, 1].min() - 1)

        viz_file = save_dir / "room_segmentation_tune.png"
        plt.tight_layout()
        plt.savefig(str(viz_file), dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  ✓ 可视化: {viz_file}")

    return rooms


def print_rooms_summary(rooms):
    """打印房间摘要"""
    print(f"\n  {'='*60}")
    print(f"  房间数: {len(rooms)}")
    print(f"  {'='*60}")
    total_area = 0
    for r in rooms:
        cx, cy, cz = r['center']
        print(f"  R{r['room_id']:2d}: 面积={r['area']:7.1f}m²  |  "
              f"中心=({cx:6.2f}, {cy:5.2f}, {cz:6.2f})  |  "
              f"3D点={r['num_points_3d']:6,}")
        total_area += r['area']
    print(f"  {'-'*60}")
    print(f"  总面积: {total_area:.1f}m²")
    print(f"  {'='*60}\n")


def main():
    parser = argparse.ArgumentParser(description='房间分割参数调试工具')
    parser.add_argument('--pcd', type=str,
                        default='unified_output/global/global_pointcloud.ply',
                        help='全局点云文件路径')
    parser.add_argument('--output', type=str, default='tune_room_seg',
                        help='输出目录名 (在 unified_output/ 下)')
    parser.add_argument('--hist', type=float, default=DEFAULT_HIST_THRESHOLD_RATIO,
                        help=f'直方图阈值比例 (默认: {DEFAULT_HIST_THRESHOLD_RATIO})')
    parser.add_argument('--blur', type=int, default=DEFAULT_GAUSSIAN_BLUR_KERNEL,
                        help=f'高斯模糊核大小 (默认: {DEFAULT_GAUSSIAN_BLUR_KERNEL})')
    parser.add_argument('--grid', type=float, default=DEFAULT_GRID_RESOLUTION,
                        help=f'栅格分辨率 (默认: {DEFAULT_GRID_RESOLUTION})')
    parser.add_argument('--min-area', type=float, default=DEFAULT_MIN_COMPONENT_AREA,
                        help=f'最小连通区域面积 (默认: {DEFAULT_MIN_COMPONENT_AREA})')
    parser.add_argument('--min-room', type=float, default=DEFAULT_MIN_ROOM_AREA,
                        help=f'最小房间面积 m² (默认: {DEFAULT_MIN_ROOM_AREA})')
    parser.add_argument('--no-viz', action='store_true',
                        help='跳过可视化生成')
    args = parser.parse_args()

    base_dir = Path(__file__).parent
    pcd_path = base_dir / args.pcd
    output_dir = base_dir / "unified_output" / args.output

    print("=" * 60)
    print("房间分割参数调试工具")
    print("=" * 60)
    print(f"\n参数:")
    print(f"  点云:            {pcd_path}")
    print(f"  输出:            {output_dir}")
    print(f"  hist_ratio:      {args.hist}")
    print(f"  blur_kernel:     {args.blur}")
    print(f"  grid_resolution: {args.grid}")
    print(f"  min_comp_area:   {args.min_area}")
    print(f"  min_room_area:   {args.min_room}")

    # 加载点云
    print(f"\n[加载点云]")
    points, colors = load_point_cloud(pcd_path)

    # 运行分割
    print(f"\n[运行房间分割]")
    rooms = run_room_segmentation(
        points, colors,
        hist_threshold_ratio=args.hist,
        gaussian_blur_kernel=args.blur,
        grid_resolution=args.grid,
        min_component_area=args.min_area,
        min_room_area=args.min_room,
        save_dir=output_dir,
        visualize=not args.no_viz
    )

    print_rooms_summary(rooms)

    # 保存结果
    result_file = output_dir / "room_segmentation_result.json"
    with open(result_file, 'w') as f:
        json.dump({
            'params': {
                'hist_threshold_ratio': args.hist,
                'gaussian_blur_kernel': args.blur,
                'grid_resolution': args.grid,
                'min_component_area': args.min_area,
                'min_room_area': args.min_room,
            },
            'num_rooms': len(rooms),
            'rooms': rooms,
        }, f, indent=2)
    print(f"  ✓ 结果已保存: {result_file}")


if __name__ == '__main__':
    main()
