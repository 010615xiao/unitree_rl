"""
数据集适配器 - 处理不同数据集的格式差异

支持:
- icra_ic7f / icra_ic4f (标准格式,深度图与RGB同分辨率)
"""

import numpy as np
import cv2
from pathlib import Path


class DatasetAdapter:
    """数据集适配器,自动处理格式差异"""

    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.images_dir = self.data_dir / "images"
        self.depth_dir = self.data_dir / "depth"
        self.poses_file = self.data_dir / "poses.txt"

        # 自动检测内参文件
        self.intrinsic_file = self._find_intrinsic_file()
        self.dataset_type = self._detect_dataset_type()

        # 先获取分辨率,再加载内参
        self.depth_resolution = self._get_depth_resolution()
        self.rgb_resolution = self._get_rgb_resolution()

        # 加载内参并检测是否需要适配
        self.K_original = self._load_intrinsics()
        self.needs_depth_upsample = self._check_needs_upsample()

        # 如果需要上采样,计算缩放比例
        if self.needs_depth_upsample:
            self.depth_scale_factor = self.rgb_resolution[0] // self.depth_resolution[0]
            print(f"  ⚙️  检测到深度图分辨率不匹配,将上采样 {self.depth_scale_factor}x")
            print(f"     深度图: {self.depth_resolution} -> RGB: {self.rgb_resolution}")
        else:
            self.depth_scale_factor = 1

        # 生成适配后的内参(如果需要上采样深度图,则内参也要相应缩放)
        self.K = self._compute_adapted_intrinsics()

    def _find_intrinsic_file(self):
        """查找内参文件"""
        candidates = ["camera.yaml", "d435i.yaml"]
        for name in candidates:
            path = self.data_dir / name
            if path.exists():
                return path
        raise FileNotFoundError(f"未找到相机内参文件,支持的文件名: {candidates}")

    def _detect_dataset_type(self):
        """检测数据集类型"""
        return "standard"

    def _load_intrinsics(self):
        """加载原始内参"""
        import yaml
        with open(self.intrinsic_file, 'r') as f:
            params = yaml.safe_load(f)

        fx = params.get('Camera1.fx', params.get('fx', 385.38))
        fy = params.get('Camera1.fy', params.get('fy', 384.85))
        cx = params.get('Camera1.cx', params.get('cx', 320.58))
        cy = params.get('Camera1.cy', params.get('cy', 240.08))

        return np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])

    def _get_depth_resolution(self):
        """获取深度图分辨率"""
        depth_files = list(self.depth_dir.glob("*.png"))
        if not depth_files:
            raise FileNotFoundError(f"深度图目录为空: {self.depth_dir}")

        sample = cv2.imread(str(depth_files[0]), cv2.IMREAD_UNCHANGED)
        return (sample.shape[0], sample.shape[1])  # (H, W)

    def _get_rgb_resolution(self):
        """获取RGB图像分辨率"""
        rgb_files = list(self.images_dir.glob("*.png"))
        if not rgb_files:
            rgb_files = list(self.images_dir.glob("*.jpg"))
        if not rgb_files:
            raise FileNotFoundError(f"RGB图像目录为空: {self.images_dir}")

        sample = cv2.imread(str(rgb_files[0]))
        return (sample.shape[0], sample.shape[1])  # (H, W)

    def _check_needs_upsample(self):
        """检查是否需要深度图上采样"""
        return self.depth_resolution != self.rgb_resolution

    def _compute_adapted_intrinsics(self):
        """计算适配后的内参"""
        if not self.needs_depth_upsample:
            return self.K_original

        # 如果深度图需要上采样到RGB尺寸,内参也要缩放
        scale_h = self.rgb_resolution[0] / self.depth_resolution[0]
        scale_w = self.rgb_resolution[1] / self.depth_resolution[1]

        K_adapted = self.K_original.copy()
        K_adapted[0, 0] *= scale_w  # fx
        K_adapted[1, 1] *= scale_h  # fy
        K_adapted[0, 2] *= scale_w  # cx
        K_adapted[1, 2] *= scale_h  # cy

        return K_adapted

    def load_depth(self, depth_file, target_resolution=None):
        """
        加载深度图,自动处理上采样

        参数:
            depth_file: 深度图路径
            target_resolution: 目标分辨率 (H, W),默认使用RGB图像分辨率

        返回:
            depth: 深度图 (单位:米, 尺寸与RGB图像匹配)
        """
        depth = cv2.imread(str(depth_file), cv2.IMREAD_UNCHANGED)
        if depth is None:
            return None

        # 如果需要上采样
        if self.needs_depth_upsample and target_resolution is not None:
            depth = cv2.resize(
                depth,
                (target_resolution[1], target_resolution[0]),  # (W, H)
                interpolation=cv2.INTER_NEAREST  # 深度图使用最近邻插值,避免平滑引入虚假深度
            )

        return depth

    def load_depth_raw_mm(self, depth_file, target_resolution=None):
        """
        加载深度图(返回毫米单位,未缩放)

        参数:
            depth_file: 深度图路径
            target_resolution: 目标分辨率 (H, W)

        返回:
            depth_mm: 深度图 (单位:毫米)
        """
        depth = cv2.imread(str(depth_file), cv2.IMREAD_UNCHANGED)
        if depth is None:
            return None

        if self.needs_depth_upsample and target_resolution is not None:
            depth = cv2.resize(
                depth,
                (target_resolution[1], target_resolution[0]),
                interpolation=cv2.INTER_NEAREST
            )

        return depth

    def get_depth_file_list(self, max_frames=None):
        """获取深度图文件列表"""
        depth_files = sorted(self.depth_dir.glob("*.png"))
        if max_frames is not None:
            depth_files = depth_files[:max_frames]
        return depth_files

    def build_pose_timestamp_map(self, poses):
        """
        构建深度图文件到pose的映射

        处理两种情况:
        1. 深度图文件名 = 时间戳 (如 icra_ic7f): 直接匹配
        2. 深度图文件名 = 序号 (如 00000.png): 按列表顺序一一对应

        参数:
            poses: dict of {timestamp: T_c2w}

        返回:
            file_to_pose: dict of {filename_stem: timestamp}
        """
        depth_files = self.get_depth_file_list()
        pose_timestamps = sorted(poses.keys())

        # 检测深度图文件名是否是时间戳
        first_name = depth_files[0].stem
        is_timestamp = '.' in first_name and len(first_name) > 10

        file_to_pose = {}

        if is_timestamp:
            # 文件名就是时间戳，直接匹配
            for depth_file in depth_files:
                if depth_file.stem in poses:
                    file_to_pose[depth_file.stem] = depth_file.stem
        else:
            # 文件名是序号，按列表顺序一一对应
            for i, depth_file in enumerate(depth_files):
                if i < len(pose_timestamps):
                    file_to_pose[depth_file.stem] = pose_timestamps[i]

        matched = len(file_to_pose)
        print(f"  📌 建立文件名-时间戳映射: {matched}/{len(depth_files)} 个深度图匹配到 poses")
        return file_to_pose

    def match_color_file(self, timestamp_str):
        """
        根据时间戳/文件名匹配对应的RGB图像

        处理两种格式:
        1. 时间戳格式: 如 icra_ic7f 的 "1757050926519.6672"
        2. 序号格式: 如 "00000" 或 "depth_00000"

        返回:
            color_file: RGB图像路径,如果不存在则返回None
        """
        # 处理深度图文件名格式 (depth_XXXXX -> XXXXX)
        if timestamp_str.startswith('depth_'):
            idx_str = timestamp_str.split('_')[1]
        elif timestamp_str.isdigit():
            idx_str = timestamp_str
        else:
            # 时间戳格式，直接匹配
            candidates = [
                self.images_dir / f"{timestamp_str}.png",
                self.images_dir / f"{timestamp_str}.jpg",
            ]
            for candidate in candidates:
                if candidate.exists():
                    return candidate
            return None

        # 序号格式，匹配 frame_XXXXX.jpg/png
        # RGB 通常是跳帧采样的 (每6帧)，需要找到对应的 RGB 帧
        idx = int(idx_str)
        candidates = [
            self.images_dir / f"frame_{idx:05d}.jpg",
            self.images_dir / f"frame_{idx:05d}.png",
            self.images_dir / f"{idx_str}.png",
            self.images_dir / f"{idx_str}.jpg",
        ]

        for candidate in candidates:
            if candidate.exists():
                return candidate

        return None

    def print_info(self):
        """打印数据集信息"""
        print(f"\n{'='*60}")
        print(f"数据集适配器信息")
        print(f"{'='*60}")
        print(f"  数据集类型: {self.dataset_type}")
        print(f"  数据目录: {self.data_dir}")
        print(f"  内参文件: {self.intrinsic_file}")
        print(f"  RGB分辨率: {self.rgb_resolution}")
        print(f"  深度图分辨率: {self.depth_resolution}")
        print(f"  需要上采样: {'是' if self.needs_depth_upsample else '否'}")
        if self.needs_depth_upsample:
            print(f"  上采样倍数: {self.depth_scale_factor}x")
        print(f"\n  原始内参:")
        print(f"    fx={self.K_original[0,0]:.2f}, fy={self.K_original[1,1]:.2f}")
        print(f"    cx={self.K_original[0,2]:.2f}, cy={self.K_original[1,2]:.2f}")
        print(f"\n  适配后内参:")
        print(f"    fx={self.K[0,0]:.2f}, fy={self.K[1,1]:.2f}")
        print(f"    cx={self.K[0,2]:.2f}, cy={self.K[1,2]:.2f}")
        print(f"{'='*60}\n")


if __name__ == "__main__":
    import sys

    # 测试数据集
    datasets = [
        "/workspace/wxd/VLN/datasets/icra_ic7f",
    ]

    for dataset_path in datasets:
        print(f"\n测试数据集: {dataset_path}")
        try:
            adapter = DatasetAdapter(dataset_path)
            adapter.print_info()

            # 测试加载深度图
            depth_files = adapter.get_depth_file_list(max_frames=3)
            for i, df in enumerate(depth_files):
                depth_m = adapter.load_depth(df, target_resolution=adapter.rgb_resolution)
                depth_mm = adapter.load_depth_raw_mm(df, target_resolution=adapter.rgb_resolution)
                print(f"  深度图 {i}: {df.name}")
                print(f"    形状: {depth_m.shape}, 范围: [{depth_m.min():.2f}, {depth_m.max():.2f}] 米")
                print(f"    (毫米: [{depth_mm.min()}, {depth_mm.max()}])")

        except Exception as e:
            print(f"  ❌ 错误: {e}")
