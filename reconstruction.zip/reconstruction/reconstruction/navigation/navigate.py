#!/usr/bin/env python3
"""
全局场景导航 + 自动可视化 (一条指令出所有结果)

支持三种目标输入:
  1. 精确物体名: --target "refrigerator_1"
  2. 坐标: --target "1.5,0,3.2"
  3. 模糊意图: --target "帮我找个能坐的地方"  (自动走 IntentMatcher + VLM)

输出:
  navigation/paths/{name}.json       - 路径数据
  navigation/viz_all/01-09_*.png     - 2D 可视化
  navigation/viz_all/10-14_*.ply     - 3D 点云 (MeshLab)

用法:
  # 基础: 规划到某个物体, 自动出图
  python -m navigation.navigate --target "refrigerator_1"

  # 模糊意图 (自动 VLM 意图识别)
  python -m navigation.navigate --target "帮我找个能坐的地方"

  # 自定义起点 + 参数
  python -m navigation.navigate --target "chair_0" --start "0,-0.5,-5" \
    --re-detect-gateways --cost-weight 10.0 --cost-sigma 1.0

  # 使用第一帧相机位姿作为起点
  python -m navigation.navigate --target "chair_0" --start-from-first-frame

  # 使用指定帧号作为起点 (第350帧)
  python -m navigation.navigate --target "chair_0" --start-frame 350

  # 使用时间戳作为起点 (对应图片文件名)
  python -m navigation.navigate --target "chair_0" --start-timestamp 1757050999184.8821

  # 只规划不画图
  python -m navigation.navigate --target "desk_1" --no-viz

  # 交互模式
  python -m navigation.navigate --interactive

  # 多路径对比
  python -m navigation.navigate --target "plant_10" --compare
"""

import sys
import json
import re
import pickle
import subprocess
import numpy as np
from pathlib import Path
from typing import Optional

# 确保项目根目录在 path 中
_project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_project_root))

from navigation.navigator import FloorNavigator
from navigation.export_ply import export_navigation_results


# IntentMatcher 延迟导入 (需要 scene_graph.json 存在时才加载)
# from navigation.intent_matcher import IntentMatcher


# ============================================================
# 意图识别
# ============================================================

def _resolve_target(target_input: str, scene_graph_arg: str, base_dir: Path,
                    navigator=None, start_position=None, rooms=None) -> Optional[str]:
    """
    解析目标输入:
      - 坐标 "1.5,0,3.2" → 返回 None (直通)
      - 精确物体名 "chair_9" → 返回 None (直通)
      - 精确房间名 "会议室" → 返回 "room:会议室" (特殊标记)
      - 模糊意图 "帮我找个能坐的地方" → 调用 IntentMatcher 返回物体名

    Returns:
        具体的物体名 (如 "chair_9") 或 "room:房间名" 或 None (表示直通原有逻辑)
    """
    # 检查 scene_graph.json 是否存在
    scene_graph_path = scene_graph_arg
    if scene_graph_path is None:
        scene_graph_path = str(base_dir / 'unified_output' / 'scene_graph.json')

    if not Path(scene_graph_path).exists():
        print(f"  [IntentMatcher] scene_graph.json 不存在: {scene_graph_path}")
        print(f"  [IntentMatcher] 跳过意图识别，使用原始输入")
        return None

    # 快速判断: 如果是坐标或精确名称，直接返回 None
    _COORD_RE = re.compile(r"^\s*-?\d+\.?\d*\s*,\s*-?\d+\.?\d*\s*,\s*-?\d+\.?\d*\s*$")

    if _COORD_RE.match(target_input):
        return None  # 坐标，直通

    # 尝试从 scene_graph.json 快速检查是否是精确名称
    try:
        with open(scene_graph_path, 'r') as f:
            sg = json.load(f)
        all_names = {obj.get('name', '') for obj in sg.get('objects', [])}
        if target_input in all_names:
            return None  # 精确名称，直通
    except Exception:
        pass  # 如果读取失败，继续走 IntentMatcher

    # 模糊意图 — 调用 IntentMatcher
    print(f"\n{'=' * 60}")
    print(f"[IntentMatcher] 检测到模糊意图: '{target_input}'")
    print(f"[IntentMatcher] 启动 VLM 意图识别...")

    from navigation.intent_matcher import IntentMatcher

    matcher = IntentMatcher(scene_graph_path)
    result = matcher.match(target_input,
                          start_position=start_position,
                          navigator=navigator,
                          rooms=rooms)

    print(f"[IntentMatcher] 输入类型: {result.input_type}")
    print(f"[IntentMatcher] 匹配方法: {result.method}")
    print(f"[IntentMatcher] 类别: {result.category}")
    print(f"[IntentMatcher] 目标物体: {result.object_name}")
    print(f"[IntentMatcher] 置信度: {result.confidence:.2f}")
    print(f"[IntentMatcher] 选择理由: {result.reasoning}")
    print(f"{'=' * 60}\n")

    if not result.object_name:
        print(f"[IntentMatcher] ✗ 意图识别失败，无法导航")
        return None

    return result.object_name


# ============================================================
# 辅助函数
# ============================================================

def _pose_to_world_position(tx, ty, tz, qx, qy, qz, qw):
    """
    将 poses.txt 中的一行位姿转换为世界坐标系中的相机位置。

    逻辑与 build_pointcloud.py 和 export_camera_trajectory.py 完全一致:
      1. 构建 T_w2c (世界到相机)
      2. 取逆得到 T_c2w (相机到世界)
      3. 应用 T_SWITCH_AXIS 坐标轴变换
    """
    import numpy as np
    from scipy.spatial.transform import Rotation as R

    # 四元数 → 旋转矩阵 (与 export_camera_trajectory.py 一致)
    quat = [qx, qy, qz, qw]
    rot_matrix = R.from_quat(quat).as_matrix()

    # 构建世界到相机变换
    T_w2c = np.eye(4)
    T_w2c[:3, :3] = rot_matrix
    T_w2c[:3, 3] = [tx, ty, tz]

    # 取逆得到相机到世界变换
    T_c2w = np.linalg.inv(T_w2c)

    # 应用坐标轴变换 (与 build_pointcloud.py 一致)
    T_SWITCH_AXIS = np.array([
        [1, 0, 0, 0],
        [0, 0, 1, 0],
        [0, -1, 0, 0],
        [0, 0, 0, 1]
    ], dtype=np.float64)
    T_c2w = T_SWITCH_AXIS @ T_c2w

    return T_c2w[:3, 3]


def get_start_from_timestamp(poses_file, timestamp: str):
    """
    从 poses.txt 按时间戳提取相机位姿作为导航起点

    参数:
        poses_file: poses.txt 路径 (TUM 格式: timestamp tx ty tz qx qy qz qw)
        timestamp: 时间戳字符串，如 "1757050999184.8821" (对应图片文件名)

    返回:
        start_position: [x, y, z] 世界坐标系中的相机位置
    """
    poses_file = Path(poses_file)
    if not poses_file.exists():
        print(f"  警告: poses 文件不存在: {poses_file}")
        return None

    with open(poses_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if parts[0] == timestamp and len(parts) >= 8:
                tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
                qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

                pos = _pose_to_world_position(tx, ty, tz, qx, qy, qz, qw)
                print(f"  时间戳 {timestamp} 相机位置 (世界坐标): ({pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f})")
                return pos.tolist()

    print(f"  警告: 未找到时间戳 {timestamp} 对应的位姿")
    return None


def get_start_from_frame(poses_file, frame_number=1):
    """
    从 poses.txt 提取指定帧的相机位姿作为导航起点

    参数:
        poses_file: poses.txt 路径 (TUM 格式: timestamp tx ty tz qx qy qz qw)
        frame_number: 帧号 (1-索引, 即 frame_number=1 是第一帧, 350 是第 350 帧)

    返回:
        start_position: [x, y, z] 世界坐标系中的相机位置
    """
    poses_file = Path(poses_file)
    if not poses_file.exists():
        print(f"  警告: poses 文件不存在: {poses_file}")
        return None

    with open(poses_file, 'r') as f:
        lines = [l.strip() for l in f if l.strip() and not l.startswith('#')]

    if frame_number < 1 or frame_number > len(lines):
        print(f"  警告: 帧号 {frame_number} 超出范围 (共 {len(lines)} 帧)")
        return None

    parts = lines[frame_number - 1].split()
    if len(parts) >= 8:
        tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
        qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

        pos = _pose_to_world_position(tx, ty, tz, qx, qy, qz, qw)
        print(f"  第 {frame_number} 帧相机位置 (世界坐标): ({pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f})")
        return pos.tolist()

    print("  警告: 未找到有效的位姿数据")
    return None


def get_start_from_first_frame(poses_file):
    """兼容旧接口: 提取第一帧位姿"""
    return get_start_from_frame(poses_file, frame_number=1)


# ============================================================
# 辅助函数
# ============================================================

def print_scene_summary(navigator):
    """打印场景摘要"""
    print("\n" + "=" * 60)
    print("场景摘要")
    print("=" * 60)

    gm = navigator.grid_map
    print(f"\n栅格地图:")
    print(f"  分辨率: {gm.resolution}m")
    print(f"  范围: X[{gm.x_min:.1f}, {gm.x_max:.1f}], Z[{gm.z_min:.1f}, {gm.z_max:.1f}]")
    print(f"  尺寸: {gm.width} x {gm.height}")

    grid = gm.get_grid()
    print(f"  可行走: {np.sum(grid == 1):,}")
    print(f"  障碍: {np.sum(grid == 100):,}")
    print(f"  未知: {np.sum(grid == 0):,}")

    if navigator.cost_map:
        print(f"\nCost Map:")
        print(f"  Sigma: {navigator.cost_map.sigma}m")
        print(f"  Weight: {navigator.cost_map.distance_weight}")
        valid = navigator.cost_map.cost_map[navigator.cost_map.grid == 1]
        print(f"  平均代价: {valid.mean():.2f}, 最大: {valid.max():.2f}")

    if navigator.gateways:
        print(f"\nGateway ({len(navigator.gateways)} 个):")
        for gw in navigator.gateways:
            print(f"  GW{gw.id}: Room {gw.room_a} ↔ Room {gw.room_b} "
                  f"@ ({gw.position[0]:.1f}, {gw.position[1]:.1f}), 宽={gw.width:.2f}m")
    else:
        print(f"\nGateway: 未检测到 (重建流程中应已生成)")

    if navigator.objects:
        summary = navigator.scene_graph.get('objects_summary', {})
        print(f"\n物体 (共 {len(navigator.objects)} 个):")
        for cat, cnt in sorted(summary.items()):
            print(f"  {cat}: {cnt}")


def run_viz(path_json, compare_paths=None, cost_sigma=0.5, cost_weight=5.0,
            complete_wall=True, output_dir='navigation/viz_all', global_pcd=None,
            grid_map=None, gateways=None):
    """调用 visualize_all.py 生成 2D+3D 图片"""
    viz_script = Path(__file__).parent / 'visualize_all.py'
    if not viz_script.exists():
        print("  [viz] visualize_all.py 不存在, 跳过可视化")
        return

    cmd = [
        sys.executable, str(viz_script),
        '--path', str(path_json),
        '--output', str(output_dir),
        '--cost-sigma', str(cost_sigma),
        '--cost-weight', str(cost_weight),
    ]

    if global_pcd:
        cmd += ['--global-pcd', str(global_pcd)]
    if grid_map:
        cmd += ['--grid-map', str(grid_map)]
    if gateways:
        cmd += ['--gateways', str(gateways)]
    if not complete_wall:
        cmd.append('--no-boundary-wall')

    # 对比路径
    if compare_paths:
        parts = []
        for label, p in compare_paths:
            parts.append(f'{label}:{p}')
        cmd += ['--compare'] + parts

    print(f"\n  [viz] 生成 2D+3D 图片...")
    print(f"  [viz] 输出: {output_dir}/")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        # 统计输出
        out = Path(output_dir)
        pngs = sorted(out.glob('*.png'))
        plys = sorted(out.glob('*.ply'))
        print(f"  [viz] ✓ {len(pngs)} PNG, {len(plys)} PLY 已生成")
        for p in pngs:
            print(f"       {p.name}")
    else:
        print(f"  [viz] ✗ 可视化失败:")
        print(result.stderr[-500:] if result.stderr else "未知错误")


def interactive_mode(navigator, use_first_frame=False, poses_file=None):
    """交互式导航"""
    
    # 如果使用指定位姿
    start = None
    if start_frame is not None:
        if poses_file is None:
            poses_file = _project_root / 'poses.txt'
        if isinstance(start_frame, tuple) and start_frame[0] == 'timestamp':
            # 直接传入了已解析的坐标
            start = start_frame[1]
            print(f"\n使用时间戳位姿作为起点: {start}")
        elif isinstance(start_frame, int):
            start = get_start_from_frame(poses_file, frame_number=start_frame)
            print(f"\n使用第 {start_frame} 帧位姿作为起点: {start}")
        else:
            start = get_start_from_first_frame(poses_file)
            print(f"\n使用第一帧位姿作为起点: {start}")
        if start is None:
            start = [0.0, 0.0, 0.0]
    
    print("\n" + "=" * 60)
    print("交互式导航 (输入 'list' 查看物体, 'q' 退出)")
    print("=" * 60)

    while True:
        print("\n" + "-" * 40)
        
        # 如果已有起点（从第一帧读取），询问是否使用
        if start is not None:
            start_use = input(f"起点 [{start[0]:.2f},{start[1]:.2f},{start[2]:.2f}], 使用? (y/n 或新坐标 x,y,z): ").strip().lower()
            if start_use in ['n', 'no']:
                start = None
            elif start_use not in ['y', 'yes', '']:
                try:
                    start = [float(x) for x in start_use.split(',')]
                    assert len(start) == 3
                except:
                    print("  错误: 格式应为 'x,y,z'")
                    continue
        
        # 如果没有起点，提示输入
        if start is None:
            start_input = input("起点 (x,y,z) [默认: 0,0,0]: ").strip()
            if start_input.lower() in ['q', 'quit', 'exit']:
                break
            if not start_input:
                start_input = '0,0,0'

            try:
                start = [float(x) for x in start_input.split(',')]
                assert len(start) == 3
            except:
                print("  错误: 格式应为 'x,y,z'")
                continue

        target_input = input("目标: ").strip()
        if target_input.lower() in ['q', 'quit', 'exit']:
            break
        if target_input.lower() == 'list':
            print("\n可用物体:")
            for obj in navigator.objects:
                c = obj.get('center', [0, 0, 0])
                print(f"  {obj['name']:25s} [{obj['category']:15s}] ({c[0]:.1f}, {c[1]:.1f}, {c[2]:.1f})")
            continue

        result = navigator.plan(start, target_input)
        if result['success']:
            print(f"  ✓ 路径长度: {result['path_length']:.1f}m, "
                  f"点数: {len(result['path'])}")
            save = input("保存? (文件名 或 n): ").strip()
            if save and save.lower() != 'n':
                out = Path(__file__).parent / 'paths' / save
                out.parent.mkdir(parents=True, exist_ok=True)
                with open(out, 'w') as f:
                    json.dump(result, f, indent=2, default=str)
                print(f"  已保存: {out}")
        else:
            print(f"  ✗ 规划失败: {result.get('error')}")


# ============================================================
# 主函数
# ============================================================

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description='全局场景导航 + 自动可视化',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 规划到 refrigerator_1, 自动出图
  python -m navigation.navigate --target "refrigerator_1"

  # 使用第一帧相机位姿作为起点
  python -m navigation.navigate --target "refrigerator_1" --start-from-first-frame

  # 自定义起点 + 参数
  python -m navigation.navigate --target "chair_0" --start "0,-0.5,-5" \\
    --re-detect-gateways --cost-weight 10.0 --cost-sigma 1.0

  # 多路径对比 (Safe vs NoCost)
  python -m navigation.navigate --target "plant_10" --compare

  # 交互模式
  python -m navigation.navigate --interactive
        """
    )

    # 导航参数
    parser.add_argument('--start', type=str, default=None,
                        help='起点 (x,y,z), 默认: 0,0,0')
    parser.add_argument('--start-from-first-frame', action='store_true',
                        help='使用第一帧相机位姿作为起点 (从 poses.txt 读取)')
    parser.add_argument('--start-frame', type=int, default=None,
                        help='使用指定帧号的相机位姿作为起点 (1-索引, 如 --start-frame 350 即第350帧)')
    parser.add_argument('--start-timestamp', type=str, default=None,
                        help='使用指定时间戳的相机位姿作为起点 (对应图片文件名, 如 1757050999184.8821)')
    parser.add_argument('--poses-file', type=str, default=None,
                        help='poses.txt 路径 (用于 --start-from-first-frame), 默认自动查找')
    parser.add_argument('--target', type=str, default=None,
                        help='目标物体名称 或 坐标(x,y,z)')
    parser.add_argument('--name', type=str, default=None,
                        help='输出文件名 (默认: 自动生成)')

    # 算法参数
    parser.add_argument('--re-detect-gateways', action='store_true',
                        help='重新检测 gateway (默认: 自动加载已有结果)')
    parser.add_argument('--no-gateways', action='store_true',
                        help='禁用 gateway 导航 (使用直接路径)')
    parser.add_argument('--cost-sigma', type=float, default=0.5,
                        help='Cost Map sigma (m), 默认: 0.5')
    parser.add_argument('--cost-weight', type=float, default=5.0,
                        help='Cost Map 障碍物权重, 默认: 5.0')
    parser.add_argument('--no-cost-map', action='store_true',
                        help='禁用 Cost Map')
    parser.add_argument('--no-boundary-wall', action='store_true',
                        help='不补全外围 wall')

    # 可视化
    parser.add_argument('--viz', action='store_true', default=True,
                        help='自动生成可视化 (默认: 开启)')
    parser.add_argument('--no-viz', action='store_true',
                        help='不生成可视化')
    parser.add_argument('--compare', action='store_true',
                        help='多路径对比 (Safe vs NoCost vs NoGateway)')

    # 路径输出
    parser.add_argument('--output', type=str, default=None,
                        help='路径 JSON 输出路径 (默认: navigation/paths/{name}.json)')
    parser.add_argument('--export-ply', action='store_true',
                        help='额外导出路径 PLY (MeshLab)')
    parser.add_argument('--ply-dir', type=str, default=None,
                        help='PLY 输出目录 (默认: navigation/paths/)')

    # 数据源
    parser.add_argument('--global-pcd', type=str, default=None,
                        help='全局点云 (默认: unified_output/global/global_pointcloud.ply)')
    parser.add_argument('--resolution', type=float, default=0.05)
    parser.add_argument('--cached-grid', type=str, default=None,
                        help='已有栅格地图 (pkl)')
    parser.add_argument('--rooms', type=str, default=None,
                        help='房间分割数据 (pkl)')
    parser.add_argument('--scene-graph', type=str, default=None,
                        help='scene_graph.json 路径 (用于模糊意图识别), 默认自动查找')

    # 模式
    parser.add_argument('--interactive', action='store_true',
                        help='交互模式')

    args = parser.parse_args()

    import time
    t_start = time.time()

    # 推导路径
    base_dir = _project_root
    global_pcd = args.global_pcd or str(base_dir / 'unified_output/global/global_pointcloud.ply')
    rooms_path = args.rooms or str(base_dir / 'unified_output/rooms/floor_0_rooms.pkl')
    grid_map_path = args.cached_grid or str(base_dir / 'unified_output/navigation/grid_map_floor.pkl')

    if not Path(global_pcd).exists():
        print(f"错误: 点云不存在: {global_pcd}")
        return

    # 输出目录
    paths_dir = base_dir / 'navigation' / 'paths'
    paths_dir.mkdir(parents=True, exist_ok=True)
    viz_dir = base_dir / 'navigation' / 'viz_all'

    # 默认文件名
    target_safe = args.target or 'unknown'
    file_name = args.name or f"{target_safe}"

    # 初始化导航器
    print(f"\n初始化导航器...")
    navigator = FloorNavigator(
        global_pcd_path=str(global_pcd),
        resolution=args.resolution,
        grid_map_path=grid_map_path if Path(grid_map_path).exists() else None,
        use_cost_map=not args.no_cost_map,
        cost_sigma=args.cost_sigma,
        cost_weight=args.cost_weight,
        complete_boundary_wall=not args.no_boundary_wall,
    )

    # 加载房间
    rooms = None
    if Path(rooms_path).exists():
        with open(rooms_path, 'rb') as f:
            rooms = pickle.load(f)
        print(f"房间: {len(rooms)} 个 (来自 pickle)")
    else:
        # 尝试从 scene_graph.json 加载房间
        scene_graph_path = base_dir / 'unified_output' / 'scene_graph.json'
        if scene_graph_path.exists():
            with open(scene_graph_path, 'r') as f:
                scene_data = json.load(f)
            rooms = scene_data.get('rooms', [])
            print(f"房间: {len(rooms)} 个 (来自 scene_graph.json)")
        else:
            print("警告: 未找到房间数据")

    # Gateway 已在 FloorNavigator 初始化时自动加载 (来自 unified_output/navigation/gateways/gateways.json)
    # 如果需要重新检测:
    if args.re_detect_gateways and rooms:
        print("\n重新检测 Gateway...")
        traj_path = base_dir / 'unified_output' / 'trajectory_resampled.ply'
        if traj_path.exists():
            import open3d as o3d
            pcd = o3d.io.read_point_cloud(str(traj_path))
            trajectory = np.asarray(pcd.points)
            navigator.detect_gateways_from_trajectory(trajectory, rooms)
        else:
            navigator.detect_gateways(rooms)
    elif navigator.gateways:
        print(f"Gateway: {len(navigator.gateways)} 个 (已自动加载)")
    else:
        print("Gateway: 未检测到")

    print_scene_summary(navigator)

    # 交互模式
    if args.interactive:
        start_frame_arg = None
        if args.start_timestamp:
            # 交互模式用 timestamp 时,先解析出来
            poses_file = args.poses_file
            if poses_file is None:
                for p in [base_dir / 'poses.txt', base_dir.parent / 'poses.txt',
                          Path('/workspace/wxd/VLN/datasets/icra_ic7f/poses.txt'),
                          Path('/workspace/wxd/VLN/datasets/icra_ic4f/poses.txt')]:
                    if Path(p).exists():
                        poses_file = p
                        break
            if poses_file:
                ts_start = get_start_from_timestamp(poses_file, args.start_timestamp)
                if ts_start:
                    start_frame_arg = ('timestamp', ts_start)
        elif args.start_frame is not None:
            start_frame_arg = args.start_frame
        elif args.start_from_first_frame:
            start_frame_arg = True

        interactive_mode(navigator,
                        start_frame=start_frame_arg,
                        poses_file=args.poses_file)
        return

    # 单路径规划
    if not args.target and not args.compare:
        print("\n需要 --target, 或用 --interactive, 或用 --compare")
        parser.print_help()
        return

    if args.target:
        # 解析起点
        start = None

        # 优先级 1: --start "x,y,z" (手动指定坐标，最高优先级)
        if args.start:
            try:
                start = [float(x) for x in args.start.split(',')]
                assert len(start) == 3
            except:
                print(f"错误: 起点格式应为 'x,y,z', 当前: {args.start}")
                return

        # 优先级 2: --start-timestamp (按时间戳精确匹配，对应图片文件名)
        elif args.start_timestamp:
            poses_file = args.poses_file
            if poses_file is None:
                candidate_paths = [
                    base_dir / 'poses.txt',
                    base_dir.parent / 'poses.txt',
                    Path('/workspace/wxd/VLN/datasets/icra_ic7f/poses.txt'),
                    Path('/workspace/wxd/VLN/datasets/icra_ic4f/poses.txt'),
                ]
                for p in candidate_paths:
                    if Path(p).exists():
                        poses_file = p
                        print(f"  找到 poses 文件: {poses_file}")
                        break
                if poses_file is None or not Path(poses_file).exists():
                    poses_file = base_dir / 'poses.txt'
            else:
                poses_file = Path(poses_file)

            start = get_start_from_timestamp(poses_file, args.start_timestamp)
            if start is None:
                print("  警告: 无法找到时间戳对应的位姿, 回退到 (0,0,0)")
                start = [0.0, 0.0, 0.0]

        # 优先级 3: --start-frame N (指定帧号, 1-索引)
        elif args.start_frame is not None:
            poses_file = args.poses_file
            if poses_file is None:
                candidate_paths = [
                    base_dir / 'poses.txt',
                    base_dir.parent / 'poses.txt',
                    Path('/workspace/wxd/VLN/datasets/icra_ic7f/poses.txt'),
                    Path('/workspace/wxd/VLN/datasets/icra_ic4f/poses.txt'),
                ]
                for p in candidate_paths:
                    if Path(p).exists():
                        poses_file = p
                        print(f"  找到 poses 文件: {poses_file}")
                        break
                if poses_file is None or not Path(poses_file).exists():
                    poses_file = base_dir / 'poses.txt'
            else:
                poses_file = Path(poses_file)

            start = get_start_from_frame(poses_file, frame_number=args.start_frame)
            if start is None:
                print("  警告: 无法读取指定位姿, 回退到 (0,0,0)")
                start = [0.0, 0.0, 0.0]

        # 优先级 3: 第一帧位姿 (默认行为)
        else:
            poses_file = args.poses_file
            if poses_file is None:
                # 自动查找 poses.txt (按优先级搜索)
                candidate_paths = [
                    base_dir / 'poses.txt',                                    # 项目根目录
                    base_dir.parent / 'poses.txt',                             # 父目录
                    Path('/workspace/wxd/VLN/datasets/icra_ic7f/poses.txt'),   # 数据集路径
                    Path('/workspace/wxd/VLN/datasets/icra_ic4f/poses.txt'),   # 数据集路径
                ]

                for p in candidate_paths:
                    if Path(p).exists():
                        poses_file = p
                        print(f"  找到 poses 文件: {poses_file}")
                        break

                if poses_file is None or not Path(poses_file).exists():
                    poses_file = base_dir / 'poses.txt'  # 默认回退
            else:
                poses_file = Path(poses_file)

            start = get_start_from_first_frame(poses_file)
            if start is None:
                print("  警告: 无法读取第一帧位姿, 回退到 (0,0,0)")
                start = [0.0, 0.0, 0.0]

        # ── 意图识别: 如果 target 是模糊意图，走 IntentMatcher ──
        actual_target = args.target
        target_resolved = _resolve_target(
            args.target, args.scene_graph, base_dir,
            navigator=navigator,
            start_position=start,
            rooms=rooms,
        )
        if target_resolved is not None:
            actual_target = target_resolved

        print(f"\n规划: {start} → {actual_target}")
        import time
        t0 = time.time()
        result = navigator.plan(start, actual_target, rooms=rooms)
        elapsed = time.time() - t0
        print(f"\n[⏱️ 导航推理耗时] {elapsed:.3f}s ({elapsed*1000:.1f}ms)")

        if not result['success']:
            print(f"规划失败: {result.get('error', '未知错误')}")
            return

        # 保存路径 JSON
        out_json = args.output or str(paths_dir / f'path_{file_name}.json')
        out_path = Path(out_json)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, 'w') as f:
            json.dump(result, f, indent=2, default=str)
        elapsed_total = time.time() - t_start
        print(f"\n路径已保存: {out_path}")
        print(f"\n[⏱️ 总耗时] {elapsed_total:.3f}s ({elapsed_total*1000:.1f}ms) — 从启动到路径JSON保存")
        print(f"  ├─ 初始化 (加载栅格/CostMap/Gateway): {elapsed_total - elapsed:.3f}s")
        print(f"  └─ 导航推理 (IntentMatcher + A*规划): {elapsed:.3f}s")

        # 额外 PLY 导出
        if args.export_ply:
            ply_dir = args.ply_dir or str(paths_dir / f'ply_{file_name}')
            export_navigation_results(
                str(out_path), ply_dir,
                include_global_pcd=True, global_pcd_path=global_pcd
            )

        # 自动可视化
        if args.viz and not args.no_viz:
            gateway_path = None
            if navigator.gateways:
                gw_file = viz_dir / 'gateways.pkl'
                gw_file.parent.mkdir(parents=True, exist_ok=True)
                with open(gw_file, 'wb') as f:
                    pickle.dump({'gateways': navigator.gateways}, f)
                gateway_path = str(gw_file)

            run_viz(
                path_json=str(out_path),
                cost_sigma=args.cost_sigma,
                cost_weight=args.cost_weight,
                complete_wall=not args.no_boundary_wall,
                output_dir=str(viz_dir),
                global_pcd=global_pcd,
                grid_map=grid_map_path if Path(grid_map_path).exists() else None,
                gateways=gateway_path,
            )

    # 多路径对比
    if args.compare:
        start = [float(x) for x in (args.start or '0,0,0').split(',')]
        assert len(start) == 3

        print(f"\n对比规划 (起点: {start}, 目标: {args.target})...")

        # 1. 安全路径 (cost map + gateway)
        print("\n[1/3] 安全路径 (Cost Map + Gateway)...")
        r1 = navigator.plan(start, args.target, rooms=rooms)
        if r1['success']:
            p1 = str(paths_dir / f'path_safe_{file_name}.json')
            with open(p1, 'w') as f:
                json.dump(r1, f, indent=2, default=str)
            print(f"  保存: {p1}")

        # 2. 无 cost map 路径
        print("\n[2/3] 无 Cost Map 路径...")
        navigator_no_cost = FloorNavigator(
            global_pcd_path=global_pcd,
            resolution=args.resolution,
            grid_map_path=grid_map_path if Path(grid_map_path).exists() else None,
            use_cost_map=False,
            complete_boundary_wall=not args.no_boundary_wall,
        )
        if use_gateways and rooms:
            navigator_no_cost.detect_gateways(rooms)
        r2 = navigator_no_cost.plan(start, args.target, rooms=rooms)
        if r2['success']:
            p2 = str(paths_dir / f'path_nocost_{file_name}.json')
            with open(p2, 'w') as f:
                json.dump(r2, f, indent=2, default=str)
            print(f"  保存: {p2}")

        # 3. 无 gateway 路径
        print("\n[3/3] 无 Gateway 路径...")
        navigator_no_gw = FloorNavigator(
            global_pcd_path=global_pcd,
            resolution=args.resolution,
            grid_map_path=grid_map_path if Path(grid_map_path).exists() else None,
            use_cost_map=not args.no_cost_map,
            cost_sigma=args.cost_sigma,
            cost_weight=args.cost_weight,
            complete_boundary_wall=not args.no_boundary_wall,
        )
        r3 = navigator_no_gw.plan(start, args.target, rooms=None)
        if r3['success']:
            p3 = str(paths_dir / f'path_nogw_{file_name}.json')
            with open(p3, 'w') as f:
                json.dump(r3, f, indent=2, default=str)
            print(f"  保存: {p3}")

        # 统一可视化对比
        if args.viz and not args.no_viz:
            # 保存 gateway
            gateway_path = None
            if navigator.gateways:
                gw_file = viz_dir / 'gateways.pkl'
                with open(gw_file, 'wb') as f:
                    pickle.dump({'gateways': navigator.gateways}, f)
                gateway_path = str(gw_file)

            compare_paths = []
            if r1.get('success'):
                compare_paths.append(('Safe', str(paths_dir / f'path_safe_{file_name}.json')))
            if r2.get('success'):
                compare_paths.append(('NoCost', str(paths_dir / f'path_nocost_{file_name}.json')))
            if r3.get('success'):
                compare_paths.append(('NoGW', str(paths_dir / f'path_nogw_{file_name}.json')))

            # 用第一个成功的路径作为主路径
            main_path = None
            if r1.get('success'):
                main_path = str(paths_dir / f'path_safe_{file_name}.json')
            elif r2.get('success'):
                main_path = str(paths_dir / f'path_nocost_{file_name}.json')
            elif r3.get('success'):
                main_path = str(paths_dir / f'path_nogw_{file_name}.json')

            if main_path:
                run_viz(
                    path_json=main_path,
                    compare_paths=compare_paths,
                    cost_sigma=args.cost_sigma,
                    cost_weight=args.cost_weight,
                    complete_wall=not args.no_boundary_wall,
                    output_dir=str(viz_dir),
                    global_pcd=global_pcd,
                    grid_map=grid_map_path if Path(grid_map_path).exists() else None,
                    gateways=gateway_path,
                )


if __name__ == '__main__':
    main()
