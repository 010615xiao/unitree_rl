#!/usr/bin/env python3
"""
独立运行：为 scene_graph.json 中的物体生成 VLM 环境描述

用法:
    python generate_env_descriptions.py                    # 使用默认输出目录
    python generate_env_descriptions.py --cache-file xxx   # 指定缓存文件
"""

import json
import argparse
from pathlib import Path
import sys

# 复用主脚本中的函数
from reconstruct_and_segment import (
    annotate_scene_graph_with_environment_descriptions,
    build_object_environment_cache_key,
    describe_object_environment,
    VLM_API_URL,
    OUTPUT_DIR,
    CLEANING_INSPECTION_FILE,
    BEHAVIORAL_ANALYSIS_FILE,
    OBJECT_ENVIRONMENT_DESCRIPTION_ENABLED,
    OBJECT_ENVIRONMENT_MAX_IMAGES,
    OBJECT_SOURCE_VIEW_LIMIT,
)


def main():
    parser = argparse.ArgumentParser(description='为场景图中的物体生成 VLM 环境描述')
    parser.add_argument('--scene-graph', type=str,
                        default=str(OUTPUT_DIR / 'scene_graph.json'),
                        help='scene_graph.json 路径')
    parser.add_argument('--cache-file', type=str, default=None,
                        help='VLM 缓存文件路径（跳过已生成的描述）')
    parser.add_argument('--max-images', type=int,
                        default=OBJECT_ENVIRONMENT_MAX_IMAGES,
                        help='每个物体的上下文图片数量')
    args = parser.parse_args()

    scene_graph_path = Path(args.scene_graph)
    if not scene_graph_path.exists():
        print(f"错误: scene_graph.json 不存在: {scene_graph_path}")
        return

    print(f"加载场景图: {scene_graph_path}")
    with open(scene_graph_path, 'r', encoding='utf-8') as f:
        scene_graph = json.load(f)

    objects = scene_graph.get('objects', [])
    if not objects:
        print("场景图中没有物体，跳过")
        return

    # 统计已有描述
    with_desc = sum(1 for obj in objects if obj.get('environment_description') or obj.get('behavior_description'))
    print(f"共 {len(objects)} 个物体，其中 {with_desc} 个已有环境描述")

    cache_file = args.cache_file
    if cache_file is None:
        cache_file = OUTPUT_DIR / "object_environment_descriptions.json"

    print(f"缓存文件: {cache_file}")
    print(f"VLM 服务: {VLM_API_URL}")
    print()

    # 重新调用 annotate 函数（内部有缓存机制，已生成的不会重复）
    updated_scene_graph, floor_results, person_results = annotate_scene_graph_with_environment_descriptions(
        scene_graph=scene_graph,
        cache_file=cache_file,
        max_images=args.max_images,
    )

    # 保存更新后的场景图
    with open(scene_graph_path, 'w', encoding='utf-8') as f:
        json.dump(updated_scene_graph, f, indent=2, ensure_ascii=False)
    print(f"\n✓ 已更新: {scene_graph_path}")

    # 保存 cleaning_inspection.json
    with open(CLEANING_INSPECTION_FILE, 'w') as f:
        json.dump(floor_results, f, indent=2, default=str, ensure_ascii=False)
    print(f"  ✓ 已保存地板清洁检测：{CLEANING_INSPECTION_FILE} ({len(floor_results)} 个 floor)")

    # 保存 behavioral_analysis.json
    with open(BEHAVIORAL_ANALYSIS_FILE, 'w') as f:
        json.dump(person_results, f, indent=2, default=str, ensure_ascii=False)
    print(f"  ✓ 已保存人员行为分析：{BEHAVIORAL_ANALYSIS_FILE} ({len(person_results)} 个 person)")

    # 统计结果
    updated = sum(1 for obj in updated_scene_graph['objects'] if obj.get('environment_description') or obj.get('behavior_description'))
    print(f"共 {updated}/{len(updated_scene_graph['objects'])} 个物体已生成环境描述")


if __name__ == '__main__':
    main()
