#!/usr/bin/env python3
"""
场景驱动的用户行为分析 - 单帧 VLM 分析

根据数据集中的 RGB 图像,让 VLM 分析场景类型(客厅/厨房/办公室等),
并生成符合该场景的用户行为描述。

采样间隔: 每 18 帧采样一次
输出: behavior_analysis.json (含 3D 位姿信息)

用法:
  # 分析整个数据集(默认采样间隔 18 帧)
  python generate_behavior_analysis.py

  # 指定采样间隔
  python generate_behavior_analysis.py --skip 9

  # 限制最大处理帧数
  python generate_behavior_analysis.py --max-frames 100
"""

import argparse
import base64
import json
import sys
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import requests

# 添加当前目录到路径,以便导入数据适配器
sys.path.insert(0, str(Path(__file__).parent))
from data_adapter import DatasetAdapter

# ================= 配置 =================
DATA_DIR = Path("/workspace/wxd/VLN/datasets/icra_ic7f")

VLM_API_URL = "http://localhost:8008/v1/chat/completions"
VLM_MODEL_NAME = "RoboBrain2.5-8B"

# 采样参数
SKIP_FRAMES = 18  # 每 18 帧采样一次

# VLM 请求参数
VLM_TIMEOUT = 120
MAX_TOKENS = 512
TEMPERATURE = 0.5

# 输出
OUTPUT_DIR = Path(__file__).parent / "behavior_analysis"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
# ===========================================


def image_to_base64(image_path):
    """将图片转换为 base64"""
    with open(image_path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')


def get_sorted_image_files(images_dir):
    """获取排序后的图像文件列表"""
    image_files = sorted(images_dir.glob("*.png"))
    if not image_files:
        image_files = sorted(images_dir.glob("*.jpg"))
    if not image_files:
        image_files = sorted(images_dir.glob("*.jpeg"))
    return image_files


def load_poses(poses_file):
    """加载相机位姿文件
    
    支持格式: timestamp tx ty tz qx qy qz qw (或 4x4 矩阵行)
    返回: dict of {timestamp_str: {position: [x,y,z], rotation: [qx,qy,qz,qw]}}
    """
    poses = {}
    if not Path(poses_file).exists():
        print(f"  警告: 位姿文件不存在: {poses_file}")
        return poses

    with open(poses_file, 'r') as f:
        lines = [l.strip() for l in f if l.strip() and not l.startswith('#')]

    if not lines:
        return poses

    # 检测格式: 第一行如果是 16 个数字则是 4x4 矩阵格式
    first_parts = lines[0].split()
    is_matrix_format = len(first_parts) == 16

    if is_matrix_format:
        # 4x4 矩阵格式: timestamp + 16 个矩阵元素 (行优先)
        for line in lines:
            parts = line.split()
            if len(parts) < 17:
                continue
            timestamp = parts[0]
            vals = [float(x) for x in parts[1:17]]
            T = np.array(vals).reshape(4, 4)
            poses[timestamp] = {
                'position': T[:3, 3].tolist(),
                'rotation_matrix': T[:3, :3].tolist(),
            }
    else:
        # timestamp tx ty tz qx qy qz qw 格式
        for line in lines:
            parts = line.split()
            if len(parts) < 8:
                continue
            timestamp = parts[0]
            poses[timestamp] = {
                'position': [float(parts[1]), float(parts[2]), float(parts[3])],
                'rotation': [float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])],
            }

    print(f"  ✓ 加载 {len(poses)} 个相机位姿")
    return poses


def build_pose_timestamp_map(poses, image_files):
    """建立图像文件到位姿的映射
    
    处理两种情况:
    1. 图像文件名 = 时间戳: 直接匹配
    2. 图像文件名 = 序号: 按列表顺序一一对应
    """
    file_to_pose = {}

    # 检测文件名是否是时间戳
    first_name = image_files[0].stem if image_files else ""
    is_timestamp = '.' in first_name and len(first_name) > 10

    pose_timestamps = sorted(poses.keys())

    if is_timestamp:
        # 文件名就是时间戳，直接匹配
        for img_file in image_files:
            # 尝试精确匹配
            if img_file.stem in poses:
                file_to_pose[img_file.name] = poses[img_file.stem]
            else:
                # 尝试模糊匹配 (时间戳可能有精度差异)
                for pts in pose_timestamps:
                    if abs(float(img_file.stem) - float(pts)) < 0.01:
                        file_to_pose[img_file.name] = poses[pts]
                        break
    else:
        # 文件名是序号，按列表顺序一一对应
        for i, img_file in enumerate(image_files):
            if i < len(pose_timestamps):
                ts = pose_timestamps[i]
                file_to_pose[img_file.name] = poses[ts]

    matched = len(file_to_pose)
    print(f"  ✓ 建立图像-位姿映射: {matched}/{len(image_files)} 帧匹配到位姿")
    return file_to_pose


def build_scene_behavior_prompt():
    """构建场景分析与行为生成提示词"""
    prompt = """You are an expert in indoor scene understanding and human behavior simulation.

## Task
Analyze the provided indoor scene image. First, decide if this frame is suitable for generating a human behavior description.

### When to say "NOT suitable"
Say not suitable if ANY of these apply:
- The image is too dark, blurry, or severely occluded to understand the scene
- The camera is in motion and the scene is unreadable (heavy motion blur, only floor/wall visible)
- The frame shows only a blank wall, ceiling, or floor with no meaningful objects or space context
- The view is blocked (e.g., by a door closing, someone's back filling the entire frame)

### When it IS suitable
- You can identify the scene type (office, kitchen, hallway, living room, etc.)
- You can see furniture, objects, or environmental context
- Even if no person is visible, you can infer what activity could happen here

## Output Format (MANDATORY)

If NOT suitable, output ONLY this JSON:
{"suitable": false, "reason": "short reason"}

If suitable, output ONLY this JSON:
{
  "suitable": true,
  "timestamp": "YYYY-MM-DD HH:MM:SS (fabricate a plausible time)",
  "location": "Scene type in Chinese, e.g., 茶水间/办公室/客厅/厨房/走廊/会议室/卧室/卫生间/餐厅/书房/阳台/储物间",
  "person": "person",
  "description": "One sentence describing what the person is doing. The behavior MUST match the scene type. Example: using the water dispenser to make coffee, then throwing trash into the bin",
  "detected_objects": ["List of 2-5 key objects visible in the scene"],
  "scene_tag": "Short behavior tag, e.g., getting_water/making_coffee/cleaning_desk"
}

## Behavior Guidelines by Scene

- Office: working at desk, typing, reading documents, online meeting, organizing desk, coffee break
- Living room: watching TV, resting on sofa, chatting with family, playing games, reading, light stretching
- Kitchen: cooking, preparing ingredients, washing dishes, making coffee, organizing cabinets, wiping counter
- Bedroom: sleeping, getting dressed, reading in bed, organizing wardrobe, morning routine
- Hallway: walking through, carrying items, heading to another room, greeting someone
- Bathroom: washing hands, grooming, showering, cleaning
- Conference room: attending meeting, presenting, discussing with colleagues, taking notes
- Study: reading, studying, writing, researching, organizing books
- Dining room: eating a meal, setting table, clearing dishes, dinner conversation
- Pantry / tea room: getting water, making tea/coffee, resting, chatting, throwing trash
- Balcony: relaxing, enjoying view, watering plants, fresh air
- Storage room: organizing items, searching for something, cleaning, moving boxes

## Rules

1. Dare to say "not suitable" — if the frame is unclear or lacks information, output suitable=false
2. Behavior MUST be consistent with the scene type — do not generate "cooking" in an office
3. person must always be "person"
4. Fabricate a plausible timestamp (office work during work hours, meals at mealtime)
5. description must be concise and specific
6. detected_objects should list 2-5 visible key objects
7. Output ONLY the JSON object, no markdown, no explanation

Analyze the provided image NOW:"""

    return prompt


def clean_json_output(content):
    """清理 VLM 输出，提取有效 JSON"""
    if content.startswith('```json'):
        content = content[7:]
    if content.startswith('```'):
        content = content[3:]
    if content.endswith('```'):
        content = content[:-3]

    content = content.strip()

    start = content.find('{')
    end = content.rfind('}') + 1

    if start >= 0 and end > start:
        return content[start:end]

    return content


def call_vlm_single_image(image_path, prompt, max_tokens=MAX_TOKENS, temperature=TEMPERATURE, timeout=VLM_TIMEOUT):
    """调用 VLM 分析单张图像"""
    if not Path(image_path).exists():
        print(f"  错误: 图像不存在: {image_path}")
        return None

    image_base64 = image_to_base64(image_path)
    image_suffix = Path(image_path).suffix.lower()
    image_mime = "jpeg" if image_suffix in {".jpg", ".jpeg"} else "png"

    content = [
        {
            "type": "image_url",
            "image_url": {"url": f"data:image/{image_mime};base64,{image_base64}"},
        },
        {"type": "text", "text": prompt}
    ]

    payload = {
        "model": VLM_MODEL_NAME,
        "messages": [{
            "role": "user",
            "content": content,
        }],
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stream": False,
    }

    try:
        response = requests.post(VLM_API_URL, json=payload, timeout=timeout)
        response.raise_for_status()

        result = response.json()
        response_text = result['choices'][0]['message']['content'].strip()

        response_text = clean_json_output(response_text)
        return json.loads(response_text)

    except requests.exceptions.ConnectionError:
        print(f"  错误: 无法连接到 VLM 服务 ({VLM_API_URL})")
        return None
    except requests.exceptions.Timeout:
        print(f"  错误: VLM 请求超时 ({timeout}秒)")
        return None
    except json.JSONDecodeError as e:
        print(f"  错误: VLM 返回 JSON 解析失败: {e}")
        print(f"  原始输出: {response_text[:300]}")
        return None
    except Exception as e:
        print(f"  错误: VLM 调用失败: {e}")
        return None


def check_vlm_service():
    """检查 VLM 服务是否可用"""
    try:
        payload = {
            "model": VLM_MODEL_NAME,
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 10,
            "stream": False,
        }
        response = requests.post(VLM_API_URL, json=payload, timeout=5)
        if response.status_code == 200:
            print(f"✓ VLM 服务可用 ({VLM_API_URL})")
            return True
        else:
            print(f"✗ VLM 服务返回状态码: {response.status_code}")
            return False
    except Exception as e:
        print(f"✗ 无法连接 VLM 服务: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="场景驱动的用户行为分析 - 单帧 VLM 分析")
    parser.add_argument("--data-dir", type=str, default=str(DATA_DIR), help="数据集目录")
    parser.add_argument("--skip", type=int, default=SKIP_FRAMES, help=f"采样间隔帧数 (默认: {SKIP_FRAMES})")
    parser.add_argument("--max-frames", type=int, default=None, help="最大处理帧数 (默认: 全部)")
    parser.add_argument("--output", type=str, default=None, help="输出 JSON 文件路径 (默认: behavior_analysis.json)")
    parser.add_argument("--start", type=int, default=0, help="起始帧索引 (默认: 0)")
    args = parser.parse_args()

    print("\n" + "=" * 70)
    print("场景驱动的用户行为分析 - 单帧 VLM 分析")
    print("=" * 70)

    # 检查 VLM 服务
    if not check_vlm_service():
        print("\n请先启动 VLM 服务:")
        print('  ./llama-server -m /workspace/wxd/models/RoboBrain2.5-8B-GGUF/RoboBrain2.5-8B_q8_0.gguf \\')
        print('    --mmproj /workspace/wxd/models/RoboBrain2.5-8B-GGUF/mmproj-RoboBrain2.5-8b-F16.gguf \\')
        print('    --port 8008 --host 0.0.0.0 --media-path /workspace/wxd/Agent/images --ctx-size 12000')
        return

    # 初始化数据适配器
    print(f"\n加载数据集: {args.data_dir}")
    try:
        adapter = DatasetAdapter(args.data_dir)
    except Exception as e:
        print(f"  ✗ 数据集加载失败: {e}")
        return

    # 获取图像文件列表
    image_files = get_sorted_image_files(adapter.images_dir)
    if not image_files:
        print(f"  ✗ 未找到图像文件: {adapter.images_dir}")
        return

    total_images = len(image_files)
    print(f"  ✓ 找到 {total_images} 帧图像")

    # 加载位姿
    poses = load_poses(adapter.poses_file)
    file_to_pose = {}
    if poses:
        file_to_pose = build_pose_timestamp_map(poses, image_files)

    # 计算采样帧
    sampled_indices = list(range(args.start, total_images, args.skip))
    if args.max_frames:
        sampled_indices = sampled_indices[:args.max_frames]

    print(f"\n采样配置:")
    print(f"  采样间隔: 每 {args.skip} 帧")
    print(f"  起始帧: {args.start}")
    print(f"  采样帧数: {len(sampled_indices)}")
    if args.max_frames:
        print(f"  最大处理: {args.max_frames} 帧")

    # 构建提示词
    prompt = build_scene_behavior_prompt()

    # 逐帧分析
    all_results = []
    success_count = 0
    fail_count = 0
    skipped_count = 0

    print(f"\n开始分析...")
    start_time = time.time()

    for i, frame_idx in enumerate(sampled_indices):
        image_path = image_files[frame_idx]
        image_name = image_path.name
        print(f"\n[{i+1}/{len(sampled_indices)}] 帧 {frame_idx}: {image_name}")

        result = call_vlm_single_image(image_path, prompt)

        if result:
            # 检查 VLM 是否认为当前帧不适合生成描述
            if not result.get("suitable", True):
                reason = result.get("reason", "未知原因")
                print(f"  ⊘ VLM 判定为不适合: {reason}")
                skipped_count += 1
                continue

            # 添加 3D 位姿信息
            if image_name in file_to_pose:
                pose_data = file_to_pose[image_name]
                position = pose_data.get('position', [0.0, 0.0, 0.0])
                result["position_3d"] = {
                    "x": round(position[0], 4),
                    "y": round(position[1], 4),
                    "z": round(position[2], 4),
                }
                pos_str = f"({position[0]:.2f}, {position[1]:.2f}, {position[2]:.2f})"
            else:
                result["position_3d"] = None
                pos_str = "N/A"

            # 添加帧索引
            result["frame_index"] = frame_idx
            result["image_file"] = image_name

            all_results.append(result)

            # 打印简短摘要
            location = result.get("location", "?")
            desc = result.get("description", "")[:50]
            scene_tag = result.get("scene_tag", "")
            print(f"  ✓ [{location}] {pos_str}: {desc}... ({scene_tag})")
            success_count += 1
        else:
            print(f"  ✗ VLM 分析失败")
            fail_count += 1

        # 简短延迟避免请求过快
        if i < len(sampled_indices) - 1:
            time.sleep(0.5)

    elapsed = time.time() - start_time
    print(f"\n{'=' * 70}")
    print(f"分析完成:")
    print(f"  总采样帧: {len(sampled_indices)}")
    print(f"  成功: {success_count}")
    print(f"  跳过 (不适合): {skipped_count}")
    print(f"  失败: {fail_count}")
    print(f"  耗时: {elapsed:.1f} 秒")

    if not all_results:
        print("\n无有效结果,退出")
        return

    # 构建输出 JSON
    output_data = {
        "metadata": {
            "dataset": str(args.data_dir),
            "total_frames_in_dataset": total_images,
            "skip_interval": args.skip,
            "sampled_frames": len(sampled_indices),
            "successful_analyses": success_count,
            "skipped_unsuitable": skipped_count,
            "failed_analyses": fail_count,
            "processing_time_seconds": round(elapsed, 1),
            "generated_at": datetime.now().isoformat(),
        },
        "behaviors": all_results,
    }

    # 保存结果
    if args.output:
        output_file = Path(args.output)
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = OUTPUT_DIR / f"behavior_analysis_{timestamp}.json"

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)

    print(f"\n✓ 结果已保存: {output_file}")

    # 打印统计
    location_counts = {}
    scene_tag_counts = {}
    for r in all_results:
        loc = r.get("location", "unknown")
        tag = r.get("scene_tag", "unknown")
        location_counts[loc] = location_counts.get(loc, 0) + 1
        scene_tag_counts[tag] = scene_tag_counts.get(tag, 0) + 1

    print(f"\n场景位置分布:")
    for loc, count in sorted(location_counts.items(), key=lambda x: -x[1]):
        print(f"  {loc}: {count}")

    print(f"\n行为标签分布:")
    for tag, count in sorted(scene_tag_counts.items(), key=lambda x: -x[1]):
        print(f"  {tag}: {count}")


if __name__ == "__main__":
    main()
