"""
Trajectory 2D - 点云分割模块

根据检测目标，分别提取和保存场景点云、目标点云和地板点云。
"""

from .sam2_client import SAM2Client
from .pointcloud_saver import PointCloudSaver, PointCloudVisualizer
from .main import PointCloudSegmentationPipeline, VLMIntentClient, GroundingDINODetector

__all__ = [
    "SAM2Client",
    "PointCloudSaver",
    "PointCloudVisualizer",
    "VLMIntentClient",
    "GroundingDINODetector",
    "PointCloudSegmentationPipeline",
]

__version__ = "1.0.0"
