#!/usr/bin/env python3
"""
Deterministic 2D trajectory planning utilities.

This module keeps planning grounded in explicit geometric constraints:
- the path must stay on floor pixels
- the goal is projected to a reachable floor point near the target object
- the path is searched on a traversable mask and then smoothed/resampled
"""

from __future__ import annotations

import heapq
import math
import os
from collections import deque
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np


Point = Tuple[int, int]


def _load_image(image_path: str) -> np.ndarray:
    image = cv2.imread(image_path)
    if image is None:
        raise FileNotFoundError(f"Unable to read image: {image_path}")
    return image


def _normalize_mask(mask: np.ndarray) -> np.ndarray:
    if mask.dtype == np.bool_:
        return mask.copy()
    if mask.ndim == 3:
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
    return mask > 0


def load_mask(mask_path: Optional[str]) -> Optional[np.ndarray]:
    if not mask_path:
        return None
    if not os.path.exists(mask_path):
        return None

    suffix = os.path.splitext(mask_path)[1].lower()
    if suffix == ".npy":
        mask = np.load(mask_path)
    else:
        mask = cv2.imread(mask_path, cv2.IMREAD_UNCHANGED)
        if mask is None:
            raise FileNotFoundError(f"Unable to read mask: {mask_path}")
    return _normalize_mask(mask)


def extract_floor_mask_from_depth_masks(depth_masks_path: str) -> np.ndarray:
    image = _load_image(depth_masks_path)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    lower_green = np.array([35, 40, 50], dtype=np.uint8)
    upper_green = np.array([85, 255, 255], dtype=np.uint8)
    return cv2.inRange(hsv, lower_green, upper_green) > 0


def extract_target_mask_from_depth_masks(
    depth_masks_path: str,
    fallback_point: Optional[Point] = None,
    fallback_radius: int = 18,
) -> np.ndarray:
    image = _load_image(depth_masks_path)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    lower_red_1 = np.array([0, 80, 40], dtype=np.uint8)
    upper_red_1 = np.array([10, 255, 255], dtype=np.uint8)
    lower_red_2 = np.array([170, 80, 40], dtype=np.uint8)
    upper_red_2 = np.array([180, 255, 255], dtype=np.uint8)

    red_mask = cv2.inRange(hsv, lower_red_1, upper_red_1) | cv2.inRange(hsv, lower_red_2, upper_red_2)
    mask = red_mask > 0

    if mask.any() or fallback_point is None:
        return mask

    h, w = mask.shape
    cx = int(np.clip(fallback_point[0], 0, w - 1))
    cy = int(np.clip(fallback_point[1], 0, h - 1))
    yy, xx = np.ogrid[:h, :w]
    return (xx - cx) ** 2 + (yy - cy) ** 2 <= fallback_radius ** 2


def inflate_mask(mask: np.ndarray, radius: int) -> np.ndarray:
    if radius <= 0:
        return mask.copy()
    kernel_size = radius * 2 + 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    return cv2.dilate(mask.astype(np.uint8), kernel) > 0


def resolve_floor_mask(depth_masks_path: str, floor_mask_path: Optional[str] = None) -> Tuple[np.ndarray, str]:
    floor_mask = load_mask(floor_mask_path)
    if floor_mask is not None:
        return floor_mask, "floor_mask_file"
    return extract_floor_mask_from_depth_masks(depth_masks_path), "depth_masks_green_channel"


def resolve_target_mask(
    depth_masks_path: str,
    fallback_point: Optional[Point] = None,
    fallback_radius: int = 18,
    target_mask_path: Optional[str] = None,
) -> Tuple[np.ndarray, str]:
    target_mask = load_mask(target_mask_path)
    if target_mask is not None and target_mask.any():
        return target_mask, "target_mask_file"
    return (
        extract_target_mask_from_depth_masks(
            depth_masks_path,
            fallback_point=fallback_point,
            fallback_radius=fallback_radius,
        ),
        "depth_masks_red_channel_or_fallback",
    )


def point_within_mask(point: Sequence[float], mask: np.ndarray) -> bool:
    x = int(round(point[0]))
    y = int(round(point[1]))
    h, w = mask.shape
    return 0 <= x < w and 0 <= y < h and bool(mask[y, x])


def derive_target_anchor(target_mask: Optional[np.ndarray], fallback_point: Optional[Point]) -> Optional[Point]:
    if target_mask is not None and target_mask.any():
        ys, xs = np.where(target_mask)
        y_max = ys.max()
        bottom_band = ys >= max(0, y_max - max(3, int((y_max - ys.min() + 1) * 0.15)))
        xs_band = xs[bottom_band]
        ys_band = ys[bottom_band]
        return int(np.median(xs_band)), int(np.median(ys_band))
    return fallback_point


def project_point_to_mask(
    point: Sequence[float],
    mask: np.ndarray,
    max_distance: Optional[float] = None,
) -> Optional[Point]:
    if point is None:
        return None

    x = int(round(point[0]))
    y = int(round(point[1]))
    h, w = mask.shape

    x = int(np.clip(x, 0, w - 1))
    y = int(np.clip(y, 0, h - 1))

    if mask[y, x]:
        return x, y

    ys, xs = np.where(mask)
    if len(xs) == 0:
        return None

    dx = xs - x
    dy = ys - y
    distances_sq = dx * dx + dy * dy
    best_idx = int(np.argmin(distances_sq))
    best_distance = math.sqrt(float(distances_sq[best_idx]))

    if max_distance is not None and best_distance > max_distance:
        return None

    return int(xs[best_idx]), int(ys[best_idx])


def connected_component_from_point(mask: np.ndarray, seed: Point) -> np.ndarray:
    component = np.zeros_like(mask, dtype=bool)
    sx, sy = seed
    if not point_within_mask(seed, mask):
        return component

    queue: deque[Point] = deque([(sx, sy)])
    component[sy, sx] = True
    # 8-连通（允许对角线移动，跨越单像素断裂）
    neighbors = [
        (-1, 0), (1, 0), (0, -1), (0, 1),
        (-1, -1), (-1, 1), (1, -1), (1, 1),
    ]

    while queue:
        x, y = queue.popleft()
        for dx, dy in neighbors:
            nx = x + dx
            ny = y + dy
            if 0 <= nx < mask.shape[1] and 0 <= ny < mask.shape[0] and mask[ny, nx] and not component[ny, nx]:
                component[ny, nx] = True
                queue.append((nx, ny))

    return component


def choose_navigation_goal(
    reachable_mask: np.ndarray,
    target_anchor: Point,
) -> Optional[Point]:
    ys, xs = np.where(reachable_mask)
    if len(xs) == 0:
        return None

    dx = xs - target_anchor[0]
    dy = ys - target_anchor[1]
    distances_sq = dx * dx + dy * dy
    best_idx = int(np.argmin(distances_sq))
    return int(xs[best_idx]), int(ys[best_idx])


def compute_navigation_goal_from_masks(
    floor_mask: np.ndarray,
    target_mask: np.ndarray,
    start_point: Point,
    target_point: Optional[Point],
    obstacle_margin_px: int,
) -> Dict[str, object]:
    if not floor_mask.any():
        return {"success": False, "error": "No floor pixels found in mask."}
    if target_mask.shape != floor_mask.shape:
        return {"success": False, "error": "Floor mask and target mask shapes do not match."}

    inflated_target_mask = inflate_mask(target_mask, obstacle_margin_px) if target_mask.any() else target_mask
    traversable_mask = floor_mask & ~inflated_target_mask
    if not traversable_mask.any():
        return {"success": False, "error": "No traversable floor remains after obstacle inflation."}

    projected_start = project_point_to_mask(start_point, traversable_mask)
    if projected_start is None:
        return {"success": False, "error": "Unable to project start point onto traversable floor."}

    target_anchor = derive_target_anchor(target_mask, target_point)
    if target_anchor is None:
        return {"success": False, "error": "Unable to determine target anchor point."}

    reachable_mask = connected_component_from_point(traversable_mask, projected_start)
    if not reachable_mask.any():
        return {"success": False, "error": "Start point is not connected to any traversable floor region."}

    navigation_goal = choose_navigation_goal(reachable_mask, target_anchor)
    if navigation_goal is None:
        return {"success": False, "error": "Unable to find a reachable goal point near the target."}

    return {
        "success": True,
        "projected_start": projected_start,
        "target_anchor": target_anchor,
        "navigation_goal": navigation_goal,
        "inflated_target_mask": inflated_target_mask,
        "traversable_mask": traversable_mask,
        "reachable_mask": reachable_mask,
    }


def bresenham_line(start: Point, end: Point) -> List[Point]:
    x0, y0 = start
    x1, y1 = end

    points: List[Point] = []
    dx = abs(x1 - x0)
    dy = -abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx + dy

    while True:
        points.append((x0, y0))
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            x0 += sx
        if e2 <= dx:
            err += dx
            y0 += sy

    return points


def line_is_traversable(traversable_mask: np.ndarray, start: Point, end: Point) -> bool:
    h, w = traversable_mask.shape
    for x, y in bresenham_line(start, end):
        if not (0 <= x < w and 0 <= y < h and traversable_mask[y, x]):
            return False
    return True


def build_clearance_cost_map(
    traversable_mask: np.ndarray,
    obstacle_margin_px: int,
    clearance_margin_px: int,
    clearance_weight: float,
) -> np.ndarray:
    penalty = np.zeros(traversable_mask.shape, dtype=np.float32)
    if clearance_weight <= 0.0 or clearance_margin_px <= 0:
        return penalty

    distances = cv2.distanceTransform(traversable_mask.astype(np.uint8), cv2.DIST_L2, 5).astype(np.float32)
    effective_margin = float(max(clearance_margin_px, obstacle_margin_px + 1, 1))
    normalized = np.clip((effective_margin - distances) / effective_margin, 0.0, 1.0)
    penalty = (normalized ** 2) * float(clearance_weight)
    penalty[~traversable_mask] = 0.0
    return penalty


def astar_search(
    traversable_mask: np.ndarray,
    start: Point,
    goal: Point,
    step_penalty_map: Optional[np.ndarray] = None,
) -> Optional[List[Point]]:
    if not point_within_mask(start, traversable_mask) or not point_within_mask(goal, traversable_mask):
        return None

    h, w = traversable_mask.shape
    g_score = np.full((h, w), np.inf, dtype=np.float32)
    parent_x = np.full((h, w), -1, dtype=np.int32)
    parent_y = np.full((h, w), -1, dtype=np.int32)
    closed = np.zeros((h, w), dtype=bool)

    neighbors = [
        (-1, 0, 1.0),
        (1, 0, 1.0),
        (0, -1, 1.0),
        (0, 1, 1.0),
        (-1, -1, math.sqrt(2.0)),
        (-1, 1, math.sqrt(2.0)),
        (1, -1, math.sqrt(2.0)),
        (1, 1, math.sqrt(2.0)),
    ]

    sx, sy = start
    gx, gy = goal

    def heuristic(x: int, y: int) -> float:
        return math.hypot(gx - x, gy - y)

    heap: List[Tuple[float, float, int, int]] = []
    g_score[sy, sx] = 0.0
    heapq.heappush(heap, (heuristic(sx, sy), 0.0, sx, sy))

    while heap:
        _, current_g, x, y = heapq.heappop(heap)
        if closed[y, x]:
            continue
        closed[y, x] = True

        if (x, y) == goal:
            path: List[Point] = []
            cx, cy = x, y
            while cx != -1 and cy != -1:
                path.append((cx, cy))
                px = parent_x[cy, cx]
                py = parent_y[cy, cx]
                cx, cy = int(px), int(py)
            path.reverse()
            return path

        for dx, dy, cost in neighbors:
            nx = x + dx
            ny = y + dy
            if not (0 <= nx < w and 0 <= ny < h and traversable_mask[ny, nx]):
                continue
            if closed[ny, nx]:
                continue
            if dx != 0 and dy != 0:
                if not (traversable_mask[y, nx] and traversable_mask[ny, x]):
                    continue

            extra_cost = 0.0 if step_penalty_map is None else float(step_penalty_map[ny, nx])
            tentative_g = current_g + cost + extra_cost
            if tentative_g < g_score[ny, nx]:
                g_score[ny, nx] = tentative_g
                parent_x[ny, nx] = x
                parent_y[ny, nx] = y
                heapq.heappush(heap, (tentative_g + heuristic(nx, ny), tentative_g, nx, ny))

    return None


def smooth_path(path: Sequence[Point], traversable_mask: np.ndarray) -> List[Point]:
    if len(path) <= 2:
        return list(path)

    smoothed: List[Point] = [path[0]]
    idx = 0

    while idx < len(path) - 1:
        next_idx = len(path) - 1
        while next_idx > idx + 1:
            if line_is_traversable(traversable_mask, path[idx], path[next_idx]):
                break
            next_idx -= 1
        smoothed.append(path[next_idx])
        idx = next_idx

    return smoothed


def polyline_length(path: Sequence[Point]) -> float:
    if len(path) < 2:
        return 0.0
    total = 0.0
    for p0, p1 in zip(path[:-1], path[1:]):
        total += math.hypot(p1[0] - p0[0], p1[1] - p0[1])
    return total


def resample_path(
    path: Sequence[Point],
    traversable_mask: np.ndarray,
    min_points: int,
    max_points: int,
    base_step_px: float,
) -> List[Point]:
    if len(path) <= 2:
        return list(path)

    total_length = polyline_length(path)
    if total_length <= 1e-6:
        return [path[0], path[-1]]

    approx_points = int(round(total_length / max(base_step_px, 1.0))) + 1
    target_count = int(np.clip(approx_points, max(2, min_points), max(max_points, 2)))

    cumulative = [0.0]
    for p0, p1 in zip(path[:-1], path[1:]):
        cumulative.append(cumulative[-1] + math.hypot(p1[0] - p0[0], p1[1] - p0[1]))

    distances = np.linspace(0.0, cumulative[-1], target_count)
    result: List[Point] = []
    seg_idx = 0

    for dist in distances:
        while seg_idx < len(cumulative) - 2 and cumulative[seg_idx + 1] < dist:
            seg_idx += 1

        p0 = path[seg_idx]
        p1 = path[seg_idx + 1]
        seg_start = cumulative[seg_idx]
        seg_end = cumulative[seg_idx + 1]
        if seg_end <= seg_start:
            interp = p0
        else:
            t = (dist - seg_start) / (seg_end - seg_start)
            interp = (
                int(round(p0[0] + t * (p1[0] - p0[0]))),
                int(round(p0[1] + t * (p1[1] - p0[1]))),
            )

        snapped = project_point_to_mask(interp, traversable_mask, max_distance=3.0) or interp
        if not result or snapped != result[-1]:
            result.append(snapped)

    if result[-1] != path[-1]:
        result.append(path[-1])

    return result


def validate_trajectory_against_mask(trajectory: Sequence[Point], traversable_mask: np.ndarray) -> Dict[str, object]:
    point_failures: List[Dict[str, object]] = []
    segment_failures: List[Dict[str, object]] = []

    for idx, point in enumerate(trajectory):
        if not point_within_mask(point, traversable_mask):
            point_failures.append({"index": idx, "point": [int(point[0]), int(point[1])]})

    for idx, (p0, p1) in enumerate(zip(trajectory[:-1], trajectory[1:])):
        if not line_is_traversable(traversable_mask, p0, p1):
            segment_failures.append(
                {
                    "segment_index": idx,
                    "start": [int(p0[0]), int(p0[1])],
                    "end": [int(p1[0]), int(p1[1])],
                }
            )

    total_points = len(trajectory)
    floor_coverage = 1.0 if total_points == 0 else 1.0 - (len(point_failures) / total_points)

    return {
        "success": not point_failures and not segment_failures,
        "all_points_on_floor": not point_failures,
        "all_segments_on_floor": not segment_failures,
        "point_failures": point_failures,
        "segment_failures": segment_failures,
        "floor_coverage": floor_coverage,
    }


def plan_classic_trajectory(
    depth_masks_path: str,
    start_point: Point,
    target_point: Optional[Point],
    min_points: int = 8,
    max_points: int = 15,
    base_step_px: float = 24.0,
    obstacle_margin_px: int = 8,
    target_fallback_radius: int = 18,
    floor_mask_path: Optional[str] = None,
    target_mask_path: Optional[str] = None,
    clearance_margin_px: int = 20,
    clearance_weight: float = 1.5,
) -> Dict[str, object]:
    floor_mask, floor_mask_source = resolve_floor_mask(depth_masks_path, floor_mask_path=floor_mask_path)
    target_mask, target_mask_source = resolve_target_mask(
        depth_masks_path,
        fallback_point=target_point,
        fallback_radius=target_fallback_radius,
        target_mask_path=target_mask_path,
    )

    goal_info = compute_navigation_goal_from_masks(
        floor_mask=floor_mask,
        target_mask=target_mask,
        start_point=start_point,
        target_point=target_point,
        obstacle_margin_px=obstacle_margin_px,
    )
    if not goal_info["success"]:
        return {"success": False, "error": str(goal_info["error"])}

    projected_start = goal_info["projected_start"]
    target_anchor = goal_info["target_anchor"]
    navigation_goal = goal_info["navigation_goal"]
    reachable_mask = goal_info["reachable_mask"]
    traversable_mask = goal_info["traversable_mask"]

    clearance_cost_map = build_clearance_cost_map(
        traversable_mask,
        obstacle_margin_px=obstacle_margin_px,
        clearance_margin_px=clearance_margin_px,
        clearance_weight=clearance_weight,
    )

    reachable_cost_map = np.where(reachable_mask, clearance_cost_map, 0.0)
    raw_path = astar_search(reachable_mask, projected_start, navigation_goal, step_penalty_map=reachable_cost_map)
    if not raw_path:
        return {"success": False, "error": "A* could not find a path to the reachable goal."}

    smoothed_path = smooth_path(raw_path, reachable_mask)
    resampled_path = resample_path(
        smoothed_path,
        reachable_mask,
        min_points=min_points,
        max_points=max_points,
        base_step_px=base_step_px,
    )

    if resampled_path[0] != projected_start:
        resampled_path.insert(0, projected_start)
    if resampled_path[-1] != navigation_goal:
        resampled_path.append(navigation_goal)

    validation = validate_trajectory_against_mask(resampled_path, reachable_mask)
    if not validation["success"]:
        return {
            "success": False,
            "error": "Generated path failed traversability validation.",
            "validation": validation,
        }

    return {
        "success": True,
        "planner": "classic",
        "start_point": [int(start_point[0]), int(start_point[1])],
        "projected_start_point": [int(projected_start[0]), int(projected_start[1])],
        "target_object_point": [int(target_anchor[0]), int(target_anchor[1])],
        "navigation_goal_point": [int(navigation_goal[0]), int(navigation_goal[1])],
        "trajectory": [[int(x), int(y)] for x, y in resampled_path],
        "raw_path_num_points": len(raw_path),
        "smoothed_path_num_points": len(smoothed_path),
        "num_points": len(resampled_path),
        "mask_sources": {
            "floor": floor_mask_source,
            "target": target_mask_source,
        },
        "planner_settings": {
            "min_points": int(min_points),
            "max_points": int(max_points),
            "base_step_px": float(base_step_px),
            "obstacle_margin_px": int(obstacle_margin_px),
            "target_fallback_radius": int(target_fallback_radius),
            "clearance_margin_px": int(clearance_margin_px),
            "clearance_weight": float(clearance_weight),
        },
        "validation": validation,
    }
