#!/usr/bin/env python3
"""
2D 轨迹规划点云分割主流程 (改进版)
根据用户指令检测目标物体，分割并保存场景点云、目标点云和地板点云

核心改进:
1. VLM 意图理解 - 详细识别深度/位置/序数词/关系型查询
2. 多目标检测 - GroundingDINO 检测所有候选目标
3. 目标选择决策 - 根据深度/位置/序数词选择最终目标
4. 地板检测 - 始终额外执行 floor 的检测和分割

流程:
1. VLM 意图理解 - 解析用户指令，提取目标物体、深度/位置属性、序数词
2. GroundingDINO 检测 - 检测所有候选目标
3. 目标选择决策 - 根据意图选择最终目标 (最近/最远/第 N 个)
4. SAM2 分割 - 使用边界框获取目标的精确掩码
5. Floor 检测 - 额外检测 floor 并分割
6. Depth-Anything-v3 点云生成 - 生成场景 3D 点云
7. 点云分割 - 分离场景、目标、地板点云
8. 保存输出 - PLY 格式点云 + 可视化图像

使用示例:
    python main.py --image test.png --instruction "远处的垃圾桶"
    python main.py --image test.png --instruction "最近的椅子"
    python main.py --image test.png --instruction "左边的桌子"
"""

import sys
import os
import json
import re
import cv2
import numpy as np
import torch
from typing import Dict, Any, Optional, List, Tuple
from openai import OpenAI

# 添加路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # 父目录 checkpoints

# 导入自定义模块
from sam2_client import SAM2Client
from pointcloud_segmentation_http import PointCloudSegmentator, DepthAnythingV3Client, GroundingDINOClient
from pointcloud_saver import PointCloudSaver, PointCloudVisualizer
from classic_trajectory_planner import compute_navigation_goal_from_masks

# 导入耗时追踪模块
from timing_tracker import track_time, tracker

# ============== 配置常量 ==============
BOX_THRESHOLD = 0.30
TEXT_THRESHOLD = 0.20

# 服务配置
SAM2_HOST = "localhost"
SAM2_PORT = 20020
GROUNDING_DINO_HOST = "localhost"
GROUNDING_DINO_PORT = 20021
DEPTH_ANYTHING_HOST = "localhost"
DEPTH_ANYTHING_PORT = 20022

# 默认输出目录
DEFAULT_OUTPUT_DIR = None  # 将在运行时根据图像路径自动推导

# 起点配置 (2D 坐标，参考 visualize_traj_3d.py)
# 默认使用图像底部中心位置，可根据具体图像调整
# 注意：当启用自动起点计算时（--auto_start_point），此起点将被覆盖
START_POINT_2D = (310, 450)  # (x, y)


def compute_start_point_from_floor_mask(
    floor_mask: np.ndarray,
    image_height: int,
    image_width: int,
    bottom_ratio: float = 0.3,
    bottom_margin_ratio: float = 0.05
) -> tuple:
    """
    从地板掩码自动计算起点（位于地板靠下区域中心，但不在最底部）

    算法：
    1. 提取地板掩码中所有像素的 Y 坐标范围
    2. 取地板区域底部 bottom_ratio 比例的像素
    3. 计算这些像素的中心点 (median X, median Y)
    4. 确保 Y 坐标距离图像底部至少 bottom_margin_ratio 的边距

    Args:
        floor_mask: 地板掩码 [H, W] bool 数组
        image_height: 图像高度（像素）
        image_width: 图像宽度（像素）
        bottom_ratio: 使用地板区域底部多少比例来计算中心（默认 0.3 = 底部 30%）
        bottom_margin_ratio: 距离图像底部的边距比例（默认 0.05 = 5%）

    Returns:
        (x, y) 起点坐标
    """
    # 提取地板像素坐标
    ys, xs = np.where(floor_mask)
    if len(ys) == 0:
        # 没有地板像素，返回默认起点
        print("   ⚠️ 地板掩码为空，使用默认起点")
        return START_POINT_2D

    y_min, y_max = ys.min(), ys.max()
    floor_height = y_max - y_min

    # 取地板区域底部 bottom_ratio 比例的像素
    bottom_threshold = y_max - floor_height * bottom_ratio
    bottom_mask = ys >= bottom_threshold
    bottom_xs = xs[bottom_mask]
    bottom_ys = ys[bottom_mask]

    if len(bottom_xs) == 0:
        print("   ⚠️ 地板底部区域为空，使用默认起点")
        return START_POINT_2D

    # 计算中心点
    center_x = int(np.median(bottom_xs))
    center_y = int(np.median(bottom_ys))

    # 确保 Y 坐标距离图像底部有一定边距
    margin_y = int(image_height * bottom_margin_ratio)
    center_y = min(center_y, image_height - margin_y)

    # 确保 X 坐标在图像范围内
    center_x = max(0, min(center_x, image_width - 1))

    return (center_x, center_y)


# ============== 配置校验 ==============
VALID_DEPTH_ATTRS = ("nearest", "farthest")
VALID_POSITION_ATTRS = ("left", "right", "center", "center_left", "center_right")
VALID_TASK_TYPES = ("simple_selection", "relational_selection", "ordinal_selection", "combined_selection")
VALID_RELATION_TYPES = ("closest_to", "farthest_from", "next_to", "nearest_to", "left_of", "right_of")


def _validate_intent(result: Dict[str, Any], instruction: str) -> Dict[str, Any]:
    """校验并规范化 VLM/规则解析输出，确保字段合规"""
    # 规范化 depth_attribute
    depth = result.get("depth_attribute")
    if depth is not None and depth not in VALID_DEPTH_ATTRS:
        # 尝试映射
        mapping = {"near": "nearest", "close": "nearest", "close_to": "nearest",
                   "far": "farthest", "further": "farthest", "distant": "farthest"}
        result["depth_attribute"] = mapping.get(depth.lower(), None)
        if result["depth_attribute"] is None:
            print(f"   ⚠️ 无效的 depth_attribute '{depth}'，已设为 null")

    # 规范化 position_attribute
    pos = result.get("position_attribute")
    if pos is not None and pos not in VALID_POSITION_ATTRS:
        mapping = {"l": "left", "r": "right", "middle": "center", "central": "center",
                   "center_left": "center_left", "center_right": "center_right",
                   "mid_left": "center_left", "mid_right": "center_right"}
        result["position_attribute"] = mapping.get(pos.lower(), None)
        if result["position_attribute"] is None:
            print(f"   ⚠️ 无效的 position_attribute '{pos}'，已设为 null")

    # 规范化 task_type
    task = result.get("task_type", "simple_selection")
    if task not in VALID_TASK_TYPES:
        result["task_type"] = "simple_selection"

    # 规范化 relation_type
    rel = result.get("relation_type")
    if rel is not None and rel not in VALID_RELATION_TYPES:
        mapping = {"near": "closest_to", "close": "closest_to", "far": "farthest_from",
                   "left": "left_of", "right": "right_of",
                   "left_of": "left_of", "right_of": "right_of"}
        result["relation_type"] = mapping.get(rel.lower(), None)

    # 规范化 target_objects
    if "target_objects" not in result or not result.get("target_objects"):
        result["target_objects"] = ["object"]
    elif isinstance(result["target_objects"], str):
        result["target_objects"] = [result["target_objects"]]

    # 确保 ordinal 为正整数
    if not isinstance(result.get("ordinal"), int) or result["ordinal"] < 1:
        result["ordinal"] = 1

    # 确保 confidence 存在
    if "confidence" not in result:
        result["confidence"] = 1.0 if result.get("reasoning") != "规则解析" else 0.7

    return result


# ============== VLM 意图理解 ==============
class VLMIntentClient:
    """VLM 客户端，用于解析用户指令意图（使用 RoboBrain2.5-8B）

    改进:
    1. 添加 Pydantic 风格的校验和规范化（_validate_intent）
    2. 支持重试机制（最多 MAX_RETRIES 次）
    3. 异常时调用规则 fallback 而非硬编码默认值
    4. 添加置信度评估
    5. 支持组合条件识别（如"左边最远的桌子"）
    """

    MAX_RETRIES = 2

    def __init__(self,
                 base_url="http://localhost:8011/v1",
                 model="RoboBrain2.5-8B"):
        self.client = OpenAI(base_url=base_url, api_key="not-needed")
        self.model = model
        self._image_cache: Dict[str, str] = {}  # 缓存 base64 编码
        print(f"🤖 VLM 意图理解客户端已初始化")
        print(f"   VLM: {model} @ {base_url}")

    def health_check(self) -> Tuple[bool, str]:
        """检查 VLM 服务状态"""
        try:
            models = self.client.models.list()
            return True, f"服务正常，可用模型：{[m.id for m in models.data]}"
        except Exception as e:
            return False, f"{self.model} 服务不可用：{str(e)}"

    def _encode_image(self, image_path: str) -> str:
        """编码图像为 base64，带缓存"""
        if image_path in self._image_cache:
            return self._image_cache[image_path]
        import base64
        with open(image_path, "rb") as f:
            encoded = base64.b64encode(f.read()).decode('utf-8')
        self._image_cache[image_path] = encoded
        return encoded

    def _build_prompt(self, instruction: str) -> str:
        """构建 VLM prompt"""
        return f"""你是一个智能具身 Agent 的意图理解模块。请分析用户的指令，提取关键信息。

用户指令："{instruction}"

重要识别任务:
1. **目标物体**: 识别用户要找的物体类别（英文，如 "garbage can", "water dispenser", "chair"）
2. **关系型查询**:
   - 如果指令包含"closest to X"、"nearest to X"、"farthest from X"、"X 旁边的"、"X 附近的"等
   - 提取 reference_object (参考物体) 和 relation_type ("closest_to" / "farthest_from" / "next_to" 等)
   - **方向性关系**:
     - "X 左边的"、"X 的左边"、"X 左侧的"、"left of X" → reference_object = X, relation_type = "left_of"
     - "X 右边的"、"X 的右边"、"X 右侧的"、"right of X" → reference_object = X, relation_type = "right_of"
   - 示例："中间垃圾桶的左边的那个垃圾桶" → reference_object = "中间垃圾桶", relation_type = "left_of", target_objects = ["垃圾桶"]
3. **序数词**: 识别"first"、"second"、"third"、"第 1 个"、"第 2 个"、"第一个"、"第二个"等，提取序数 (1, 2, 3...)
4. **深度属性** (非常重要):
   - "farthest"、"furthest"、"最远"、"远处的"、"远端的" → depth_attribute = "farthest"
   - "nearest"、"closest"、"最近"、"近处的"、"近端的"、"旁边的"、"附近的" → depth_attribute = "nearest"
   - 注意："最近的 X" = "nearest X" = depth_attribute = "nearest"
   - 注意："最远的 X" = "farthest X" = depth_attribute = "farthest"
5. **位置属性**:
   - "left"、"左边"、"左侧的"、"最左" → position_attribute = "left"
   - "right"、"右边"、"右侧的"、"最右" → position_attribute = "right"
   - "center"、"中间"、"中央的" → position_attribute = "center"
   - "中间偏左"、"中间靠左"、"左中"、"中左" → position_attribute = "center_left"
   - "中间偏右"、"中间靠右"、"右中"、"中右" → position_attribute = "center_right"

组合条件:
- 如果指令同时包含多个条件（如"左边最远的桌子"），请将所有条件都提取到对应字段中
- task_type 应设为 "combined_selection"

请输出 JSON 格式，包含以下字段:
- task_type: 任务类型 ("simple_selection" / "relational_selection" / "ordinal_selection" / "combined_selection")
- target_objects: 目标物体列表 (英文，如 ["garbage can", "chair", "sofa"])
- reference_object: 参考物体 (英文，关系型查询需要，如 "tent"，否则为 null)
- relation_type: 关系类型 ("closest_to" / "farthest_from" / "next_to" / "left_of" / "right_of" 等，否则为 null)
- ordinal: 序数 (int, 如 1, 2, 3...，默认为 1)
- depth_attribute: 深度属性 ("nearest" / "farthest" / null)
- position_attribute: 位置属性 ("left" / "right" / "center" / null)
- confidence: 你对解析结果的置信度 (0.0-1.0，不确定时给低分)
- reasoning: 简要的推理说明（中文，解释为什么这样判断）

只输出 JSON，不要有其他内容。"""

    def parse_intent(self, instruction: str, image_path: str) -> Dict[str, Any]:
        """
        解析用户指令的意图（带重试和校验）

        识别:
        - 目标物体 (target_objects)
        - 关系型查询 (reference_object, relation_type)
        - 序数词 (ordinal)
        - 深度/位置属性 (depth_attribute, position_attribute)
        """
        image_base64 = self._encode_image(image_path)
        prompt = self._build_prompt(instruction)

        # 打印 VLM Prompt（如果启用）
        from vlm_logger import log_vlm_call
        log_vlm_call("意图解析", prompt, image_path)

        last_error = None
        for attempt in range(1, self.MAX_RETRIES + 1):
            try:
                if attempt > 1:
                    print(f"   🔄 第 {attempt} 次重试 VLM 意图解析...")

                tracker.start("VLM", "意图解析")
                try:
                    response = self.client.chat.completions.create(
                        model=self.model,
                        messages=[{"role": "user", "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}}
                        ]}],
                        max_tokens=600,
                        temperature=0.1,
                        timeout=120
                    )
                finally:
                    tracker.end("VLM", "意图解析")

                # 打印 VLM 原始输出（如果启用）
                from vlm_logger import log_vlm_output
                result_text = response.choices[0].message.content.strip()
                log_vlm_output("意图解析", result_text)
                if not result_text:
                    print(f"   ❌ VLM 返回空响应")
                    raise ValueError("VLM 返回空响应")

                # 提取 JSON（支持多种格式）
                if "```json" in result_text:
                    result_text = result_text.split("```json")[1].split("```")[0].strip()
                elif "```" in result_text:
                    result_text = result_text.split("```")[1].split("```")[0].strip()
                else:
                    # 尝试从纯文本中提取第一个 {...} 块
                    match = re.search(r'\{.*\}', result_text, re.DOTALL)
                    if match:
                        result_text = match.group(0)

                result = json.loads(result_text)
                result["original_instruction"] = instruction
                result["vlm_model"] = self.model

                # 兼容处理
                if "target_object" in result and "target_objects" not in result:
                    result["target_objects"] = [result["target_object"]]

                # 校验和规范化
                result = _validate_intent(result, instruction)

                # 后处理：规则修正（即使 VLM 返回 null，也根据指令关键词修正）
                if result.get("depth_attribute") is None:
                    instruction_lower = instruction.lower()
                    if any(w in instruction_lower for w in
                           ["nearest", "closest", "最近", "近处的", "近端的", "旁边的", "附近的"]):
                        result["depth_attribute"] = "nearest"
                        print(f"   🔄 修正 depth_attribute: null → 'nearest' (指令包含关键词)")
                    elif any(w in instruction_lower for w in
                             ["farthest", "furthest", "最远", "远处的", "远端的"]):
                        result["depth_attribute"] = "farthest"
                        print(f"   🔄 修正 depth_attribute: null → 'farthest' (指令包含关键词)")

                if result.get("position_attribute") is None:
                    instruction_lower = instruction.lower()
                    if any(w in instruction_lower for w in
                           ["中间偏左", "中间靠左", "左中", "中左"]):
                        result["position_attribute"] = "center_left"
                        print(f"   🔄 修正 position_attribute: null → 'center_left' (指令包含关键词)")
                    elif any(w in instruction_lower for w in
                             ["中间偏右", "中间靠右", "右中", "中右"]):
                        result["position_attribute"] = "center_right"
                        print(f"   🔄 修正 position_attribute: null → 'center_right' (指令包含关键词)")
                    elif any(w in instruction_lower for w in
                             ["left", "左边", "左侧", "最左"]):
                        result["position_attribute"] = "left"
                        print(f"   🔄 修正 position_attribute: null → 'left' (指令包含关键词)")
                    elif any(w in instruction_lower for w in
                             ["right", "右边", "右侧", "最右"]):
                        result["position_attribute"] = "right"
                        print(f"   🔄 修正 position_attribute: null → 'right' (指令包含关键词)")
                    elif any(w in instruction_lower for w in
                             ["center", "中间", "中央"]):
                        result["position_attribute"] = "center"
                        print(f"   🔄 修正 position_attribute: null → 'center' (指令包含关键词)")

                # 检测组合条件并更新 task_type
                has_depth = result.get("depth_attribute") is not None
                has_position = result.get("position_attribute") is not None
                has_ordinal = result.get("ordinal", 1) > 1
                has_relation = result.get("relation_type") is not None

                attr_count = sum([has_depth, has_position, has_ordinal, has_relation])
                if attr_count >= 2 and result.get("task_type") != "relational_selection":
                    result["task_type"] = "combined_selection"
                    print(f"   📋 检测到组合条件 ({attr_count} 个属性)，task_type → 'combined_selection'")

                print(f"   ✅ VLM 意图解析成功 (attempt {attempt})，置信度: {result.get('confidence', 'N/A')}")
                return result

            except json.JSONDecodeError as e:
                print(f"   ⚠️ VLM 返回非 JSON 格式 (attempt {attempt}): {e}")
                last_error = e
            except Exception as e:
                print(f"   ⚠️ VLM 意图解析异常 (attempt {attempt}): {e}")
                last_error = e

        # 所有重试失败，降级到规则解析
        print(f"   ⚠️ VLM 意图解析 {self.MAX_RETRIES} 次后失败，降级到规则解析")
        return self._rule_based_parse(instruction)

    def _rule_based_parse(self, instruction: str) -> Dict[str, Any]:
        """规则解析（降级方案）——支持组合条件"""
        instruction_lower = instruction.lower()

        # 深度属性判断
        depth_attr = None
        if any(w in instruction_lower for w in
               ["farthest", "furthest", "最远", "远处的", "远端的"]):
            depth_attr = "farthest"
        elif any(w in instruction_lower for w in
                 ["nearest", "closest", "最近", "近处的", "近端的", "旁边的", "附近的"]):
            depth_attr = "nearest"

        # 位置属性判断（支持 5 区域：left / center_left / center / center_right / right）
        position_attr = None
        # 先检测组合词（优先级更高）
        if any(w in instruction_lower for w in ["中间偏左", "中间靠左", "左中", "中左"]):
            position_attr = "center_left"
        elif any(w in instruction_lower for w in ["中间偏右", "中间靠右", "右中", "中右"]):
            position_attr = "center_right"
        elif any(w in instruction_lower for w in ["left", "左边", "左侧", "左边的"]):
            position_attr = "left"
        elif any(w in instruction_lower for w in ["right", "右边", "右侧", "右边的"]):
            position_attr = "right"
        elif any(w in instruction_lower for w in ["center", "中间", "中央", "中间的"]):
            position_attr = "center"

        # 序数词判断
        ordinal = 1
        ordinals = {
            "first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5,
            "第 1 个": 1, "第 2 个": 2, "第 3 个": 3, "第 4 个": 4, "第 5 个": 5,
            "第一个": 1, "第二个": 2, "第三个": 3, "第四个": 4, "第五个": 5,
        }
        for key, val in ordinals.items():
            if key in instruction_lower:
                ordinal = val
                break

        # 关系型查询检测（支持方向性关系）
        relation_type = None
        reference_object = None
        # 简单启发式："X 旁边的 Y" → reference_object=X, relation_type=next_to
        rel_patterns = [
            # 方向性关系（优先级最高）
            (r"(.+?)\s*(的\s*)?(左边|左侧|左面|left\s*of)\s*(的)?\s*", "left_of"),
            (r"(.+?)\s*(的\s*)?(右边|右侧|右面|right\s*of)\s*(的)?\s*", "right_of"),
            # 距离关系
            (r"(离|距离)\s*(.+?)\s*(最近|closest|nearest)", "closest_to"),
            (r"(离|距离)\s*(.+?)\s*(最远|farthest|furthest)", "farthest_from"),
            (r"(.+?)\s*(旁边的|附近的|旁边|附近)\s*", "next_to"),
            (r"closest\s*to\s*(\w+)", "closest_to"),
            (r"farthest\s*from\s*(\w+)", "farthest_from"),
            (r"nearest\s*to\s*(\w+)", "nearest_to"),
            (r"left\s*of\s*(\w+)", "left_of"),
            (r"right\s*of\s*(\w+)", "right_of"),
        ]
        for pattern, rel in rel_patterns:
            match = re.search(pattern, instruction_lower)
            if match:
                relation_type = rel
                # 提取参考物体（简化处理，取匹配到的词）
                groups = match.groups()
                for g in groups:
                    if g not in ("最近", "最远", "closest", "nearest", "farthest", "furthest",
                                 "离", "距离", "旁边的", "附近的", "旁边", "附近",
                                 "左边", "右侧", "右边", "左侧", "左面", "右面",
                                 "left of", "right of",
                                 "的", "的 ", None):
                        reference_object = g
                        break
                break

        # 目标物体提取
        target = self._extract_target(instruction)

        # 确定 task_type
        has_depth = depth_attr is not None
        has_position = position_attr is not None
        has_ordinal = ordinal > 1
        has_relation = relation_type is not None
        attr_count = sum([has_depth, has_position, has_ordinal, has_relation])

        if has_relation:
            task_type = "relational_selection"
        elif attr_count >= 2:
            task_type = "combined_selection"
        elif has_ordinal:
            task_type = "ordinal_selection"
        else:
            task_type = "simple_selection"

        return {
            "task_type": task_type,
            "target_objects": [target],
            "reference_object": reference_object,
            "relation_type": relation_type,
            "ordinal": ordinal,
            "depth_attribute": depth_attr,
            "position_attribute": position_attr,
            "confidence": 0.7,
            "reasoning": f"规则解析 (task_type={task_type})"
        }

    def _extract_target(self, instruction: str) -> str:
        """从指令中提取目标物体（改进版：支持更多模式）"""
        target = instruction.strip()

        # 1. 移除 "离参考物体最近/最远的" 模式（关系型查询）
        rel_patterns = [
            r"离\s*.+?\s*(最近|最远|closest|farthest|nearest|furthest)\s*(的)?\s*",
            r"距离\s*.+?\s*(最近|最远|closest|farthest|nearest|furthest)\s*(的)?\s*",
            r"closest\s*to\s*.+?\s*",
            r"farthest\s*from\s*.+?\s*",
            r"nearest\s*to\s*.+?\s*",
        ]
        for pattern in rel_patterns:
            target = re.sub(pattern, "", target, flags=re.IGNORECASE)

        # 2. 常见修饰语前缀
        modifiers = [
            "最近的", "最远的", "近处的", "远处的", "近端的", "远端的", "旁边的", "附近的",
            "farthest ", "furthest ", "nearest ", "closest ",
            "左边的", "右边的", "中间的", "左侧的", "右侧的", "中央的",
            "left ", "right ", "center ", "middle ",
            "第一个", "第二个", "第三个", "第四个", "第五个",
            "第 1 个", "第 2 个", "第 3 个", "第 4 个", "第 5 个",
            "first ", "second ", "third ", "fourth ", "fifth ",
            "那个", "这个", "这些", "那些",
            "the ", "a ", "an ", "that ", "this "
        ]

        for mod in modifiers:
            if target.startswith(mod):
                target = target[len(mod):]
                break

        # 3. 中文"X 的 Y"模式 → 取 Y
        if "的" in target:
            target = target.split("的")[-1]

        # 4. 英文多词处理（取最后两个词）
        if " " in target:
            words = target.split()
            if len(words) >= 2:
                target = " ".join(words[-2:])
            else:
                target = words[-1]

        target = target.strip()
        if not target:
            target = "object"

        return target


# ============== GroundingDINO 检测 ==============
class GroundingDINODetector:
    """GroundingDINO 目标检测器（HTTP 版本）"""

    def __init__(self, host=GROUNDING_DINO_HOST, port=GROUNDING_DINO_PORT):
        self.client = GroundingDINOClient(host=host, port=port)
        print(f"🔍 GroundingDINO 检测器已初始化（HTTP 版本）")

    def detect(
        self,
        image_path: str,
        target_object: str,
        box_threshold: float = BOX_THRESHOLD,
        text_threshold: float = TEXT_THRESHOLD
    ) -> List[Dict]:
        """
        检测目标物体

        Returns:
            检测结果列表，每个包含：box, confidence, phrase, center_x, center_y
        """
        # 使用 HTTP 客户端检测
        result = self.client.detect(
            image_path=image_path,
            text_prompt=target_object,
            box_threshold=box_threshold,
            text_threshold=text_threshold
        )

        # 转换为原有格式
        detections = []
        for i, box in enumerate(result.get("boxes", [])):
            x1, y1, x2, y2 = box
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            detections.append({
                "box": box,
                "confidence": result["scores"][i] if i < len(result["scores"]) else 0.0,
                "phrase": result["labels"][i] if i < len(result["labels"]) else target_object,
                "center_x": center_x,
                "center_y": center_y
            })

        return detections


# ============== 目标选择决策 ==============
class TrajectoryDecisionMaker:
    """轨迹规划决策层：根据意图选择目标

    改进:
    1. 多属性联合打分（深度 + 位置 + 序数 + 关系）而非固定优先级
    2. 序数词改为按深度排序（从近到远）而非检测列表顺序
    3. 位置属性使用 x 坐标归一化打分，支持"center"的中间偏好
    4. 关系型查询支持多参考物体加权
    5. 组合条件支持（如"左边最远的桌子"）
    6. 每个维度输出子分数，便于调试
    """

    # 各维度权重（总和不需要为 1，分数按比例决定）
    WEIGHTS = {
        "depth": 1.0,
        "position": 0.8,
        "ordinal": 0.6,
        "relation": 1.2,
        "confidence": 0.3,  # GroundingDINO 检测置信度
    }

    def __init__(self, intent: Dict[str, Any]):
        self.intent = intent
        self._image_w: Optional[int] = None
        self._image_h: Optional[int] = None
        print(f"🧠 决策器已初始化，意图：{intent.get('task_type', 'unknown')}")

    def set_image_size(self, w: int, h: int):
        """设置图像尺寸，用于位置属性归一化"""
        self._image_w = w
        self._image_h = h

    def select_target(
        self,
        candidates: List[Dict],
        reference_candidates: Optional[List[Dict]] = None
    ) -> Tuple[Optional[Dict], str]:
        """
        根据意图选择目标（多属性联合打分）

        Returns:
            selected_target: 选中的目标
            reasoning: 决策理由
        """
        if not candidates:
            return None, "无候选目标"

        if len(candidates) == 1:
            return candidates[0], "仅有一个候选目标"

        depth_attr = self.intent.get("depth_attribute")
        position_attr = self.intent.get("position_attribute")
        ordinal = self.intent.get("ordinal", 1)
        relation_type = self.intent.get("relation_type")

        print(f"\n🤔 开始决策...")
        print(f"   任务类型：{self.intent.get('task_type', 'unknown')}")
        print(f"   深度属性：{depth_attr}")
        print(f"   位置属性：{position_attr}")
        print(f"   序数：{ordinal}")
        print(f"   关系类型：{relation_type}")
        print(f"   候选数量：{len(candidates)}")

        # 如果只有单一属性且没有组合条件，仍然用打分制但只考虑该属性
        scores = np.zeros(len(candidates))
        score_details = []

        for i, cand in enumerate(candidates):
            breakdown = {}

            # 1. 深度打分
            if depth_attr:
                breakdown["depth"] = self._compute_depth_score(candidates, i, depth_attr)
                scores[i] += breakdown["depth"] * self.WEIGHTS["depth"]

            # 2. 位置打分
            if position_attr:
                breakdown["position"] = self._compute_position_score(candidates, i, position_attr)
                scores[i] += breakdown["position"] * self.WEIGHTS["position"]

            # 3. 序数打分
            if ordinal > 1:
                breakdown["ordinal"] = self._compute_ordinal_score(candidates, i, ordinal)
                scores[i] += breakdown["ordinal"] * self.WEIGHTS["ordinal"]

            # 4. 关系型打分
            if relation_type and reference_candidates:
                if relation_type in ["left_of", "right_of"]:
                    # 方向性关系
                    breakdown["relation"] = self._compute_directional_score(
                        candidates, i, reference_candidates, relation_type)
                else:
                    # 距离型关系
                    breakdown["relation"] = self._compute_relational_score(
                        candidates, i, reference_candidates, relation_type)
                scores[i] += breakdown["relation"] * self.WEIGHTS["relation"]

            # 5. 检测置信度（始终加入，但权重较低）
            breakdown["confidence"] = cand.get("confidence", 0.0)
            scores[i] += breakdown["confidence"] * self.WEIGHTS["confidence"]

            score_details.append(breakdown)

        # 选最高分
        best_idx = int(np.argmax(scores))
        best_score = scores[best_idx]
        selected = candidates[best_idx]

        # 打印各候选分数
        print(f"\n📊 各候选分数:")
        for i, cand in enumerate(candidates):
            detail_str = ", ".join(f"{k}={v:.2f}" for k, v in score_details[i].items())
            marker = " ✅" if i == best_idx else ""
            print(f"   [{i}] {cand['phrase']} (depth={cand.get('depth', 0):.3f}m, "
                  f"x={cand['center_x']:.1f}, y={cand['center_y']:.1f}, "
                  f"conf={cand.get('confidence', 0):.2f}) "
                  f"→ score={scores[i]:.3f} [{detail_str}]{marker}")

        # 生成理由
        reasoning_parts = []
        if depth_attr:
            reasoning_parts.append(f"深度={score_details[best_idx].get('depth', 0):.2f}")
        if position_attr:
            reasoning_parts.append(f"位置={score_details[best_idx].get('position', 0):.2f}")
        if ordinal > 1:
            reasoning_parts.append(f"序数={score_details[best_idx].get('ordinal', 0):.2f}")
        if relation_type and reference_candidates:
            rel_score = score_details[best_idx].get('relation', 0)
            if relation_type in ["left_of", "right_of"]:
                direction_desc = "参考物体左边" if relation_type == "left_of" else "参考物体右边"
                reasoning_parts.append(f"方向({direction_desc})={rel_score:.2f}")
            else:
                reasoning_parts.append(f"关系={rel_score:.2f}")

        reasoning = f"综合评分最高 (score={best_score:.3f}, {'; '.join(reasoning_parts)})"

        return selected, reasoning

    def _compute_depth_score(self, candidates: List[Dict], idx: int, depth_attr: str) -> float:
        """深度打分（0~1 归一化）"""
        depths = [c.get("depth", 0) for c in candidates]
        min_d, max_d = min(depths), max(depths)

        if max_d == min_d:
            return 0.5  # 所有深度相同

        # 归一化到 0~1
        norm = (depths[idx] - min_d) / (max_d - min_d)

        if depth_attr == "farthest":
            return norm  # 越深分数越高
        elif depth_attr == "nearest":
            return 1.0 - norm  # 越浅分数越高
        return 0.5

    def _compute_position_score(self, candidates: List[Dict], idx: int, position_attr: str) -> float:
        """位置打分（0~1 归一化，支持 5 区域）

        位置模型:
            left          center_left    center    center_right    right
              |                |            |            |            |
            最左           左 1/4        正中         右 3/4        最右
        """
        xs = [c["center_x"] for c in candidates]
        min_x, max_x = min(xs), max(xs)
        width = max_x - min_x if max_x != min_x else 1.0
        mid_x = (min_x + max_x) / 2

        if position_attr == "left":
            norm = (xs[idx] - min_x) / width
            return 1.0 - norm
        elif position_attr == "right":
            norm = (xs[idx] - min_x) / width
            return norm
        elif position_attr == "center":
            max_dist = width / 2
            dist = abs(xs[idx] - mid_x)
            return 1.0 - (dist / max_dist)
        elif position_attr == "center_left":
            # 目标点：1/4 处（从左边数）
            target_x = min_x + width * 0.25
            max_dist = width / 2
            dist = abs(xs[idx] - target_x)
            return max(0.0, 1.0 - dist / max_dist)
        elif position_attr == "center_right":
            # 目标点：3/4 处（从左边数）
            target_x = min_x + width * 0.75
            max_dist = width / 2
            dist = abs(xs[idx] - target_x)
            return max(0.0, 1.0 - dist / max_dist)
        return 0.5

    def _compute_ordinal_score(self, candidates: List[Dict], idx: int, ordinal: int) -> float:
        """序数打分（按深度排序，从近到远）"""
        # 按深度排序，从近到远
        sorted_indices = sorted(range(len(candidates)), key=lambda i: candidates[i].get("depth", 0))

        # ordinal=1 表示第一个（最近的），ordinal=2 表示第二个，依此类推
        target_rank = min(ordinal - 1, len(sorted_indices) - 1)
        target_rank = max(target_rank, 0)

        target_idx = sorted_indices[target_rank]

        # 只有匹配到对应排名的候选才得满分
        if idx == target_idx:
            return 1.0
        else:
            # 其他候选根据与目标排名的深度差距给部分分数
            actual_rank = sorted_indices.index(idx)
            rank_diff = abs(actual_rank - target_rank)
            return max(0.0, 1.0 - rank_diff * 0.3)

    def _compute_relational_score(
        self,
        candidates: List[Dict],
        idx: int,
        reference_candidates: List[Dict],
        relation_type: str
    ) -> float:
        """关系型打分（支持多参考物体加权）"""
        if not reference_candidates:
            return 0.5

        # 计算与每个参考物体的距离
        total_combined_dist = 0.0
        ref_count = 0

        for ref in reference_candidates[:3]:  # 最多取 3 个参考物体
            dx = candidates[idx]["center_x"] - ref["center_x"]
            dy = candidates[idx]["center_y"] - ref["center_y"]
            ddepth = candidates[idx].get("depth", 0) - ref.get("depth", 0)

            dist_2d = (dx ** 2 + dy ** 2) ** 0.5
            combined_dist = dist_2d + abs(ddepth) * 100
            total_combined_dist += combined_dist
            ref_count += 1

        if ref_count == 0:
            return 0.5

        avg_combined_dist = total_combined_dist / ref_count

        # 计算所有候选的平均距离用于归一化
        all_avg_dists = []
        for c in candidates:
            d = 0.0
            n = 0
            for ref in reference_candidates[:3]:
                dx = c["center_x"] - ref["center_x"]
                dy = c["center_y"] - ref["center_y"]
                ddepth = c.get("depth", 0) - ref.get("depth", 0)
                d += (dx ** 2 + dy ** 2) ** 0.5 + abs(ddepth) * 100
                n += 1
            all_avg_dists.append(d / n if n > 0 else 0)

        min_d, max_d = min(all_avg_dists), max(all_avg_dists)
        if max_d == min_d:
            return 0.5

        norm = (avg_combined_dist - min_d) / (max_d - min_d)

        if relation_type in ["closest_to", "nearest_to", "next_to"]:
            return 1.0 - norm
        elif relation_type == "farthest_from":
            return norm

        return 1.0 - norm  # 默认按最近

    def _compute_directional_score(
        self,
        candidates: List[Dict],
        idx: int,
        reference_candidates: List[Dict],
        direction: str
    ) -> float:
        """方向性关系打分（left_of / right_of）

        逻辑:
        1. 找到参考物体的中心位置
        2. 计算候选物体相对于参考物体的 x 方向
        3. left_of: 候选在参考左边，且离参考越近分数越高
        4. right_of: 候选在参考右边，且离参考越近分数越高
        5. 不在正确方向的候选得分很低
        """
        if not reference_candidates:
            return 0.5

        # 使用第一个参考物体（可扩展为多参考加权）
        ref = reference_candidates[0]
        ref_x = ref["center_x"]

        xs = [c["center_x"] for c in candidates]
        min_x, max_x = min(xs), max(xs)
        width = max_x - min_x if max_x != min_x else 1.0

        cand_x = candidates[idx]["center_x"]
        dist_from_ref = abs(cand_x - ref_x)
        max_dist = width  # 最大可能距离

        if direction == "left_of":
            if cand_x >= ref_x:
                return 0.1  # 不在左边，低分
            # 在左边：距离参考越近分数越高
            rel_dist = dist_from_ref / max_dist
            return 1.0 - rel_dist
        elif direction == "right_of":
            if cand_x <= ref_x:
                return 0.1  # 不在右边，低分
            # 在右边：距离参考越近分数越高
            rel_dist = dist_from_ref / max_dist
            return 1.0 - rel_dist

        return 0.5

    # ===== 以下保留兼容旧接口的方法（内部使用打分制，对外 API 不变）=====

    def _depth_select(self, candidates: List[Dict], depth_attr: str) -> Tuple[Dict, str]:
        """根据深度属性选择（内部使用打分制）"""
        return self.select_target(candidates)

    def _position_select(self, candidates: List[Dict], position_attr: str) -> Tuple[Dict, str]:
        """根据位置属性选择（内部使用打分制）"""
        return self.select_target(candidates)

    def _ordinal_select(self, candidates: List[Dict], ordinal: int) -> Tuple[Dict, str]:
        """序数词选择（内部使用打分制）"""
        return self.select_target(candidates)

    def _relational_select(
        self,
        candidates: List[Dict],
        reference_candidates: List[Dict],
        relation_type: str,
        ordinal: int
    ) -> Tuple[Dict, str]:
        """关系型查询（内部使用打分制）"""
        return self.select_target(candidates, reference_candidates)


# ============== 点云分割主流程 ==============
class PointCloudSegmentationPipeline:
    """点云分割主流程"""

    def __init__(
        self,
        output_dir: str = DEFAULT_OUTPUT_DIR,
        sam2_host: str = SAM2_HOST,
        sam2_port: int = SAM2_PORT,
        grounding_dino_host: str = GROUNDING_DINO_HOST,
        grounding_dino_port: int = GROUNDING_DINO_PORT,
        depth_anything_host: str = DEPTH_ANYTHING_HOST,
        depth_anything_port: int = DEPTH_ANYTHING_PORT,
        skip_ply_save: bool = False,
        use_vision_intent: bool = False
    ):
        self.output_dir = output_dir
        self.sam2_host = sam2_host
        self.sam2_port = sam2_port
        self.skip_ply_save = skip_ply_save
        self.use_vision_intent = use_vision_intent

        # 初始化组件（全部使用 HTTP 客户端）
        self.vlm = VLMIntentClient()
        self.detector = GroundingDINODetector(host=grounding_dino_host, port=grounding_dino_port)
        self.sam2_client = SAM2Client(host=sam2_host, port=sam2_port)
        self.segmentator = PointCloudSegmentator(
            sam2_host=sam2_host, sam2_port=sam2_port,
            grounding_dino_host=grounding_dino_host, grounding_dino_port=grounding_dino_port,
            depth_anything_host=depth_anything_host, depth_anything_port=depth_anything_port
        )
        self.saver = PointCloudSaver()
        self.visualizer = PointCloudVisualizer()

        # 如果使用新的 VLM 意图识别，初始化 VisionIntentPipeline
        if use_vision_intent:
            from vlm_vision_reasoning import VisionIntentPipeline
            self.vision_pipeline = VisionIntentPipeline(
                grounding_dino_host=grounding_dino_host,
                grounding_dino_port=grounding_dino_port
            )
        else:
            self.vision_pipeline = None

        ply_status = "❌ 跳过（节省 I/O）" if skip_ply_save else "✅ 开启"
        intent_mode = "🧠 两阶段 VLM 意图识别" if use_vision_intent else "📋 传统 VLM 意图解析"
        print(f"📦 点云分割主流程已初始化（HTTP 版本）")
        print(f"   输出目录：{output_dir}")
        print(f"   SAM2 服务器：{sam2_host}:{sam2_port}")
        print(f"   GroundingDINO 服务器：{grounding_dino_host}:{grounding_dino_port}")
        print(f"   Depth-Anything-v3 服务器：{depth_anything_host}:{depth_anything_port}")
        print(f"   PLY 点云保存：{ply_status}")
        print(f"   意图识别模式：{intent_mode}")

    def run(
        self,
        image_path: str,
        instruction: str,
        save_result: bool = True
    ) -> Dict[str, Any]:
        """
        运行完整的点云分割流程

        Args:
            image_path: 输入图像路径
            instruction: 用户指令
            save_result: 是否保存结果

        Returns:
            包含结果和统计信息的字典
        """
        results = {
            "success": False,
            "image_path": image_path,
            "instruction": instruction
        }

        try:
            # ========== 步骤 1: 意图理解（传统或新流程） ==========
            print("\n" + "="*70)
            if self.use_vision_intent:
                print("🧠 步骤 1: 两阶段 VLM 意图识别")
            else:
                print("📋 步骤 1: VLM 意图理解")
            print("="*70)

            if self.use_vision_intent:
                # 使用新的两阶段 VLM 意图识别
                vision_result = self.vision_pipeline.run(image_path, instruction)
                if not vision_result["success"]:
                    print(f"❌ 意图识别失败: {vision_result.get('error', 'unknown')}")
                    return results

                # 转换为兼容格式
                intent = vision_result["intent"]
                selected_det = vision_result["selected_detection"]
                candidates = vision_result["all_detections"]
                
                # 将所有检测结果展平为 candidates（兼容旧格式）
                all_candidates = []
                for obj_class, dets in candidates.items():
                    all_candidates.extend(dets)
                candidates = all_candidates
                
                # selected_target 已经是检测框格式
                selected_target = selected_det
                
                # 没有 reference_candidates（新流程在 VLM 消歧时已处理关系）
                reference_candidates = []
                
                print(f"✅ 识别目标：{selected_target['phrase']}")
                if intent.get('depth_attribute'):
                    print(f"   深度属性：{intent.get('depth_attribute')}")
                if intent.get('position_attribute'):
                    print(f"   位置属性：{intent.get('position_attribute')}")
                if intent.get('ordinal', 1) > 1:
                    print(f"   序数：{intent.get('ordinal')}")
                if intent.get('relation_type'):
                    print(f"   关系型查询：{intent.get('relation_type')} → {intent.get('reference_object', '?')}")
                print(f"   置信度：{selected_target.get('confidence', 'N/A')}")
                print(f"   处理步骤: {vision_result.get('processing_steps', [])}")
            else:
                # 使用传统 VLM 意图解析
                intent = self.vlm.parse_intent(instruction, image_path)
                print(f"✅ 识别目标：{intent['target_objects'][0]}")
                if intent.get('depth_attribute'):
                    print(f"   深度属性：{intent['depth_attribute']}")
                if intent.get('position_attribute'):
                    print(f"   位置属性：{intent['position_attribute']}")
                if intent.get('ordinal', 1) > 1:
                    print(f"   序数：{intent['ordinal']}")
                if intent.get('relation_type'):
                    print(f"   关系型查询：{intent['relation_type']} → {intent.get('reference_object', '?')}")
                if intent.get('task_type') == 'combined_selection':
                    print(f"   组合条件：深度={intent.get('depth_attribute')} 位置={intent.get('position_attribute')}")
                print(f"   置信度：{intent.get('confidence', 'N/A')}")

            # ========== 步骤 2: GroundingDINO 目标检测（仅传统流程） ==========
            if not self.use_vision_intent:
                print("\n" + "="*70)
                print("🔍 步骤 2: GroundingDINO 目标检测")
                print("="*70)

                target_object = intent["target_objects"][0]
                candidates = self.detector.detect(image_path, target_object)

                if not candidates:
                    print("❌ 未检测到目标物体")
                    return results

                # 如果意图包含参考物体，也进行检测
                reference_candidates = []
                ref_object = intent.get("reference_object")
                if ref_object and intent.get("relation_type"):
                    print(f"   📌 检测到关系型查询，参考物体: {ref_object}")
                    reference_candidates = self.detector.detect(image_path, ref_object)
                    if reference_candidates:
                        print(f"   ✅ 检测到 {len(reference_candidates)} 个参考物体")
                    else:
                        print(f"   ⚠️ 未检测到参考物体 '{ref_object}'，将使用单属性决策")
            else:
                # 新流程已经在步骤 1 完成检测和选择
                pass

            # ========== 步骤 3: Depth-Anything-v3 深度估计 ==========
            print("\n" + "="*70)
            print("📊 步骤 3: Depth-Anything-v3 深度估计")
            print("="*70)

            point_cloud, depth_map, image_rgb = self.segmentator.generate_point_cloud(image_path)
            h, w = depth_map.shape

            # ========== 步骤 4: 为候选目标添加深度信息（仅传统流程） ==========
            if not self.use_vision_intent:
                print("\n" + "="*70)
                print("🎯 步骤 4: 计算候选目标深度")
                print("="*70)

                for cand in candidates:
                    box = cand["box"]
                    x1, y1, x2, y2 = [int(v) for v in box]
                    x1, y1 = max(0, x1), max(0, y1)
                    x2, y2 = min(w, x2), min(h, y2)

                    region_depth = depth_map[y1:y2, x1:x2]
                    if region_depth.size > 0:
                        cand["depth"] = float(np.median(region_depth))
                        cand["point_3d"] = point_cloud[int(cand["center_y"]), int(cand["center_x"])].tolist()
                        print(f"   {cand['phrase']}: 深度={cand['depth']:.3f}米")

                # 为参考物体也计算深度
                for cand in reference_candidates:
                    box = cand["box"]
                    x1, y1, x2, y2 = [int(v) for v in box]
                    x1, y1 = max(0, x1), max(0, y1)
                    x2, y2 = min(w, x2), min(h, y2)

                    region_depth = depth_map[y1:y2, x1:x2]
                    if region_depth.size > 0:
                        cand["depth"] = float(np.median(region_depth))
                        print(f"   [ref] {cand['phrase']}: 深度={cand['depth']:.3f}米")

                # ========== 步骤 5: 目标选择决策（仅传统流程） ==========
                print("\n" + "="*70)
                print("🧠 步骤 5: 目标选择决策")
                print("="*70)

                decision_maker = TrajectoryDecisionMaker(intent)
                decision_maker.set_image_size(w, h)
                selected_target, reasoning = decision_maker.select_target(
                    candidates,
                    reference_candidates=reference_candidates if reference_candidates else None
                )

                if selected_target is None:
                    print("❌ 无法选择目标")
                    return results

                print(f"✅ 选择目标：{selected_target['phrase']}")
                print(f"   理由：{reasoning}")
                print(f"   边界框：{selected_target['box']}")
                print(f"   深度：{selected_target['depth']:.3f}米")
            else:
                # 新流程：为选中的目标添加深度信息
                print("\n" + "="*70)
                print("🎯 步骤 4-5: 为新流程选中目标添加深度信息")
                print("="*70)

                # 新流程已经选中了目标，现在计算深度
                box = selected_target["box"]
                x1, y1, x2, y2 = [int(v) for v in box]
                x1, y1 = max(0, x1), max(0, y1)
                x2, y2 = min(w, x2), min(h, y2)

                region_depth = depth_map[y1:y2, x1:x2]
                if region_depth.size > 0:
                    selected_target["depth"] = float(np.median(region_depth))
                    selected_target["point_3d"] = point_cloud[int(selected_target["center_y"]), int(selected_target["center_x"])].tolist()
                    print(f"   {selected_target['phrase']}: 深度={selected_target['depth']:.3f}米")
                else:
                    print(f"   ⚠️ 目标区域深度无效")

                reasoning = f"两阶段 VLM 意图识别 (处理步骤: {vision_result.get('processing_steps', [])})"

            # ========== 步骤 6: SAM2 分割目标 ==========
            print("\n" + "="*70)
            print("✂️  步骤 6: SAM2 目标分割")
            print("="*70)

            target_box = selected_target["box"]
            target_mask = self.sam2_client.predict_with_box(image_path, target_box)

            if target_mask is None:
                print("❌ SAM2 分割失败")
                return results

            print(f"✅ 目标掩码已生成，像素数：{target_mask.sum()}")

            # ========== 步骤 7: Floor 检测和分割（始终执行） ==========
            print("\n" + "="*70)
            print("🏠 步骤 7: Floor 检测和分割")
            print("="*70)

            floor_candidates = self.detector.detect(image_path, "floor")
            floor_mask = None

            if floor_candidates:
                # 选择所有置信度 > 0.3 的 floor 候选
                valid_candidates = [c for c in floor_candidates if c["confidence"] > 0.3]
                
                if len(valid_candidates) > 1:
                    print(f"✅ 检测到 {len(valid_candidates)} 个 floor 候选，将合并掩码")
                elif len(valid_candidates) == 1:
                    print(f"✅ 检测到 floor (置信度：{valid_candidates[0]['confidence']:.3f})")
                
                # 对每个候选调用 SAM2，然后合并掩码
                floor_mask = np.zeros((h, w), dtype=bool)
                for i, cand in enumerate(valid_candidates):
                    print(f"   [{i+1}/{len(valid_candidates)}] floor (置信度：{cand['confidence']:.3f})")
                    cand_mask = self.sam2_client.predict_with_box(image_path, cand["box"])
                    if cand_mask is not None:
                        floor_mask |= cand_mask  # 合并掩码
                
                if floor_mask.sum() > 0:
                    print(f"✅ Floor 掩码已生成，总像素数：{floor_mask.sum()}")
                else:
                    print("⚠️ SAM2 分割失败，使用启发式方法")
                    floor_mask = np.zeros_like(target_mask)
                    floor_y_start = int(h * 0.8)
                    floor_mask[floor_y_start:, :] = True
                    print(f"✅ 使用启发式 floor 掩码，像素数：{floor_mask.sum()}")
            else:
                print("⚠️ 未检测到 floor，使用启发式方法估计")
                # 启发式：取图像底部 20% 区域
                floor_mask = np.zeros_like(target_mask)
                floor_y_start = int(h * 0.8)
                floor_mask[floor_y_start:, :] = True
                print(f"✅ 使用启发式 floor 掩码，像素数：{floor_mask.sum()}")

            # ========== 步骤 7.5: 从地板点反推相机离地高度 ==========
            print("\n" + "-"*70)
            print("📏 步骤 7.5: 从地板点 3D 坐标反推相机离地高度")
            print("-"*70)

            if floor_mask is not None and floor_mask.sum() > 0 and point_cloud is not None:
                floor_points_y = point_cloud[floor_mask][:, 1]  # Y 轴向下为正（相机坐标系）
                if len(floor_points_y) > 0:
                    camera_height_estimate = -np.median(floor_points_y)
                    camera_height_mean = -np.mean(floor_points_y)
                    camera_height_std = np.std(floor_points_y)
                    print(f"   地板点数：{len(floor_points_y)}")
                    print(f"   相机离地高度（中位数）：{camera_height_estimate:.3f} 米")
                    print(f"   相机离地高度（平均值）：{camera_height_mean:.3f} 米")
                    print(f"   标准差：{camera_height_std:.3f} 米")
                    print(f"   💡 中位数更稳定，建议参考此值")
                else:
                    print("   ⚠️ 地板点云 Y 坐标为空")
            else:
                print("   ⚠️ 地板掩码或点云无效，跳过相机高度估计")

            # ========== 步骤 8: 点云分割 ==========
            print("\n" + "="*70)
            print("☁️  步骤 8: 点云分割")
            print("="*70)

            clouds = self.segmentator.segment(
                depth_map=depth_map,
                point_cloud=point_cloud,
                target_mask=target_mask,
                floor_mask=floor_mask,
                image_rgb=image_rgb
            )

            print(f"✅ 点云分割完成")
            print(f"   完整点云：{len(clouds['full'].points)} 个点")
            print(f"   目标点云：{len(clouds['target'].points)} 个点")
            print(f"   地板点云：{len(clouds['floor'].points)} 个点")
            print(f"   场景点云：{len(clouds['scene'].points)} 个点")

            # ========== 步骤 9: 保存结果 ==========
            if save_result:
                print("\n" + "="*70)
                print("💾 步骤 9: 保存结果")
                print("="*70)

                base_name = os.path.splitext(os.path.basename(image_path))[0]
                output_subdir = os.path.join(self.output_dir, base_name)
                os.makedirs(output_subdir, exist_ok=True)

                # 保存 PLY 点云（可选跳过）
                prefix = f"{base_name}_"
                if self.skip_ply_save:
                    print("⏭️  跳过 PLY 点云保存（--skip_ply_save）")
                    saved_plys = {}
                else:
                    saved_plys = self.saver.save_all_clouds(clouds, output_subdir, prefix)

                # 计算起点坐标
                h, w = image_rgb.shape[:2]
                # 优先从地板掩码自动计算起点（位于地板靠下区域中心）
                if floor_mask is not None and floor_mask.sum() > 0:
                    start_point = compute_start_point_from_floor_mask(floor_mask, h, w)
                    print(f"\n   📍 起点自动计算: {start_point}")
                else:
                    start_point = START_POINT_2D
                    print(f"\n   📍 使用默认起点: {start_point}（地板掩码不可用）")

                # 提取目标物体的 2D 目标点（底部中心点，用于轨迹终点）
                target_point_2d = None
                navigation_goal_point_2d = None
                navigation_goal_info = None
                if target_mask is not None and target_mask.sum() > 0:
                    # 获取目标物体掩码的底部中心点
                    ys, xs = np.where(target_mask)
                    if len(ys) > 0:
                        # 找到底部区域（y 坐标最大的 20% 像素）
                        y_max = ys.max()
                        bottom_region_mask = (ys >= y_max * 0.8)
                        bottom_xs = xs[bottom_region_mask]
                        bottom_ys = ys[bottom_region_mask]
                        
                        # 取底部区域的中心点
                        target_x = int(np.median(bottom_xs))
                        target_y = int(np.median(bottom_ys))
                        target_point_2d = [target_x, target_y]
                        print(f"   目标物体点 2D (T): {target_point_2d}")

                # 计算可达终点（机器人可以站立的位置）
                if floor_mask is not None and target_mask is not None:
                    navigation_goal_info = compute_navigation_goal_from_masks(
                        floor_mask=floor_mask,
                        target_mask=target_mask,
                        start_point=start_point,
                        target_point=None if target_point_2d is None else (target_point_2d[0], target_point_2d[1]),
                        obstacle_margin_px=8,
                    )
                    if navigation_goal_info.get("success"):
                        nav_goal = navigation_goal_info["navigation_goal"]
                        navigation_goal_point_2d = [int(nav_goal[0]), int(nav_goal[1])]

                        # 清晰打印目标点(T)和可达点(G)的对比
                        print(f"\n   ========== 轨迹终点对比 ========== ")
                        print(f"   目标物体点 2D (T): {target_point_2d}")
                        print(f"   可达终点 2D (G): {navigation_goal_point_2d}")
                        print(f"   距离差异: {np.sqrt((target_point_2d[0]-navigation_goal_point_2d[0])**2 + (target_point_2d[1]-navigation_goal_point_2d[1])**2):.1f} 像素")
                        print(f"   >>> VLM轨迹预测将使用可达终点 2D (G): {navigation_goal_point_2d}")
                        print(f"   =================================== \n")

                        # 只保留可 JSON 序列化的字段，移除 numpy 数组
                        navigation_goal_info = {
                            "success": True,
                            "projected_start": [int(p) for p in navigation_goal_info["projected_start"]],
                            "target_anchor": [int(p) for p in navigation_goal_info["target_anchor"]],
                            "navigation_goal": [int(p) for p in navigation_goal_info["navigation_goal"]],
                        }
                    else:
                        # 降级：使用目标物体点作为可达终点
                        print(f"   ⚠️ 可达终点计算失败: {navigation_goal_info.get('error', 'unknown')}")
                        navigation_goal_point_2d = target_point_2d.copy() if target_point_2d else None
                        print(f"   >>> 降级：VLM轨迹预测将使用目标物体点 (T) 作为终点: {navigation_goal_point_2d}")

                saved_vis = self.visualizer.visualize_all(
                    clouds, image_path, depth_map, output_subdir, prefix,
                    start_point=start_point
                )

                # 保存掩码文件（供后续轨迹规划使用）
                floor_mask_path = os.path.join(output_subdir, f"{base_name}_floor_mask.npy")
                target_mask_path = os.path.join(output_subdir, f"{base_name}_target_mask.npy")
                np.save(floor_mask_path, floor_mask.astype(np.uint8))
                np.save(target_mask_path, target_mask.astype(np.uint8))

                metadata = {
                    "image_path": image_path,
                    "instruction": instruction,
                    "intent": intent,
                    "detection": {
                        "all_candidates": candidates,
                        "selected": selected_target,
                        "reasoning": reasoning
                    },
                    "floor_detection": {
                        "candidates": floor_candidates,
                        "mask_pixels": int(floor_mask.sum()) if floor_mask is not None else 0,
                        "mask_path": floor_mask_path
                    },
                    "segmentation": {
                        "target_mask_pixels": int(target_mask.sum()) if target_mask is not None else 0,
                        "target_mask_path": target_mask_path,
                        "floor_mask_path": floor_mask_path
                    },
                    "pointcloud_stats": {
                        "full": len(clouds["full"].points),
                        "target": len(clouds["target"].points),
                        "floor": len(clouds["floor"].points),
                        "scene": len(clouds["scene"].points)
                    },
                    "trajectory_config": {
                        "start_point_2d": start_point,  # (x, y) 像素坐标
                        "target_point_2d": target_point_2d,  # 目标物体底部中心点 (T)
                        "target_object_point_2d": target_point_2d,  # 别名
                        "navigation_goal_point_2d": navigation_goal_point_2d  # 可达终点 (G)
                    },
                    "navigation": {
                        "goal_from_masks": navigation_goal_info if navigation_goal_info is not None else {
                            "success": False,
                            "error": "Navigation goal was not computed."
                        }
                    },
                    "saved_files": {
                        "ply": saved_plys,
                        "visualization": saved_vis,
                        "masks": {
                            "floor": floor_mask_path,
                            "target": target_mask_path
                        }
                    }
                }

                metadata_path = os.path.join(output_subdir, f"{prefix}metadata.json")
                with open(metadata_path, "w") as f:
                    json.dump(metadata, f, indent=2)

                print(f"✅ 所有结果已保存：{output_subdir}")

                results["output_dir"] = output_subdir
                results["saved_files"] = {
                    "ply": saved_plys,
                    "visualization": saved_vis,
                    "metadata": metadata_path
                }

            results["success"] = True
            results["intent"] = intent
            results["detection"] = {
                "all_candidates": candidates,
                "selected": selected_target
            }
            results["pointcloud_stats"] = {
                "full": len(clouds["full"].points),
                "target": len(clouds["target"].points),
                "floor": len(clouds["floor"].points),
                "scene": len(clouds["scene"].points)
            }

        except Exception as e:
            print(f"\n❌ 流程执行异常：{e}")
            import traceback
            traceback.print_exc()
            results["error"] = str(e)

        print("\n" + "="*70)
        if results["success"]:
            print("✅ 点云分割流程完成!")
        else:
            print("❌ 点云分割流程失败")
        print("="*70)

        return results


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(
        description="2D 轨迹规划点云分割",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 完整参数（传统流程）
  python main.py --image test.png --instruction "远处的垃圾桶"

  # 使用两阶段 VLM 意图识别（新流程，支持模糊指令）
  python main.py --image test.png --instruction "找点喝的" --use_vision_intent

  # 交互式输入（不传参数）
  python main.py

  # 只指定图像，指令交互输入
  python main.py --image test.png

  # 只指定指令，使用默认图像
  python main.py --instruction "近处的椅子"
        """
    )
    parser.add_argument("--image", type=str, default=None, help="输入图像路径（可选，不传则交互输入）")
    parser.add_argument("--instruction", type=str, default=None, help="自然语言指令（可选，不传则交互输入）")
    parser.add_argument("--output-dir", type=str, default=None, help="输出目录（默认自动推导为图像所在目录下的 trajectory_2D_results）")
    parser.add_argument("--sam2-host", type=str, default=SAM2_HOST, help="SAM2 服务器主机")
    parser.add_argument("--sam2-port", type=int, default=SAM2_PORT, help="SAM2 服务器端口")
    parser.add_argument("--skip_ply_save", action="store_true", default=False,
                        help="跳过 PLY 点云文件保存（节省 I/O 时间）")
    parser.add_argument("--use_vision_intent", action="store_true", default=False,
                        help="使用两阶段 VLM 意图识别（视觉推理 + 自适应检测 + 多目标消歧）")
    parser.add_argument("--verbose_vlm", action="store_true", default=False,
                        help="打印所有 VLM 的 prompt 和原始输出（用于调试）")

    args = parser.parse_args()

    # 设置 VLM 日志打印开关
    if args.verbose_vlm:
        from vlm_logger import set_verbose
        set_verbose(True)
        print("\n" + "=" * 80)
        print("📝 已启用 VLM 详细日志：将打印所有 VLM prompt 和原始输出")
        print("=" * 80 + "\n")

    # 交互式输入
    print("\n" + "="*70)
    print("📋 Trajectory 2D - 点云分割")
    print("="*70)

    image_path = args.image
    if image_path is None:
        default_images = [
            "/workspace/wxd/Agent/images/test_6.png",
            "/workspace/wxd/Agent/images/test_navigation_2.png",
            "/workspace/wxd/Agent/images/test_2.png",
        ]
        print("\n🖼️  请选择或输入图像路径:")
        for i, img in enumerate(default_images, 1):
            if os.path.exists(img):
                print(f"   [{i}] {img}")
        print(f"   [0] 输入其他路径")
        
        choice = input("\n   请选择 (0-3): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(default_images):
            image_path = default_images[int(choice) - 1]
        else:
            image_path = input("   请输入图像路径：").strip()
    
    if not os.path.exists(image_path):
        print(f"❌ 图像不存在：{image_path}")
        return

    instruction = args.instruction
    if instruction is None:
        print(f"\n📷 当前图像：{image_path}")
        print("\n💬 请输入指令（示例）:")
        print("   - 远处的垃圾桶（明确型）")
        print("   - 找点喝的（需求型，需要新流程）")
        print("   - 最近的椅子（带空间属性）")
        print("   - 左边的桌子（带位置属性）")
        print("   - 中间垃圾桶的左边（关系型）")
        instruction = input("\n   请输入指令：").strip()
        if not instruction:
            instruction = "远处的垃圾桶"

    print("\n" + "="*70)
    print(f"✅ 配置确认")
    print(f"   图像：{image_path}")
    print(f"   指令：{instruction}")
    print("="*70)

    # 如果未指定输出目录，自动推导为图像所在目录下的 trajectory_2D_results
    if args.output_dir is None:
        image_abs_path = os.path.abspath(image_path)
        image_dir = os.path.dirname(image_abs_path)
        args.output_dir = os.path.join(image_dir, "trajectory_2D_results")
        print(f"   输出目录：{args.output_dir}（自动推导）")

    pipeline = PointCloudSegmentationPipeline(
        output_dir=args.output_dir,
        sam2_host=args.sam2_host,
        sam2_port=args.sam2_port,
        skip_ply_save=args.skip_ply_save,
        use_vision_intent=args.use_vision_intent
    )

    result = pipeline.run(
        image_path=image_path,
        instruction=instruction,
        save_result=True
    )

    if result["success"]:
        print("\n📊 结果摘要:")
        print(f"   目标：{result['intent']['target_objects'][0]}")
        print(f"   检测置信度：{result['detection']['selected']['confidence']:.3f}")
        print(f"   完整点云：{result['pointcloud_stats']['full']} 个点")
        print(f"   目标点云：{result['pointcloud_stats']['target']} 个点")
        print(f"   地板点云：{result['pointcloud_stats']['floor']} 个点")
        print(f"   场景点云：{result['pointcloud_stats']['scene']} 个点")
        print(f"   输出目录：{result['output_dir']}")
    else:
        print(f"\n❌ 失败：{result.get('error', '未知错误')}")

    # ========== 打印所有 VLM 日志（如果启用） ==========
    from vlm_logger import print_all_vlm_logs
    print_all_vlm_logs()


if __name__ == "__main__":
    main()
