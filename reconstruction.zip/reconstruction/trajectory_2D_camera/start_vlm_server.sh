#!/bin/bash
# =============================================================================
# VLM Server Startup Script for Trajectory 2D Project
# Model: RoboBrain2.5-8B
# =============================================================================
#
# Usage:
#   ./start_vlm_server.sh              # Start server in foreground
#   ./start_vlm_server.sh --background # Start server in background
#   ./start_vlm_server.sh --stop       # Stop background server
#   ./start_vlm_server.sh --status     # Check server status
#
# Requirements:
#   - CUDA-2
#   - Model path: /workspace/wxd/models/RoboBrain2.5-8B
# =============================================================================

# Configuration
CUDA_DEVICES="5,6"
MODEL_PATH="/workspace/wxd/models/RoboBrain2.5-8B"
MODEL_NAME="RoboBrain2.5-8B"
HOST="0.0.0.0"
PORT="8008"
MAX_MODEL_LEN="32768"
TENSOR_PARALLEL_SIZE="2"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored message
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if server is running
check_server_status() {
    if curl -s "http://localhost:${PORT}/v1/models" > /dev/null 2>&1; then
        print_success "VLM Server is running at http://localhost:${PORT}"
        print_info "Model: ${MODEL_NAME}"
        return 0
    else
        print_warning "VLM Server is not running"
        return 1
    fi
}

# Function to stop background server
stop_server() {
    print_info "Stopping VLM Server..."
    
    # Find and kill the vllm process
    pids=$(ps aux | grep "vllm.entrypoints.openai.api_server" | grep "port ${PORT}" | grep -v grep | awk '{print $2}')
    
    if [ -z "$pids" ]; then
        print_warning "No running VLM Server found on port ${PORT}"
        return 1
    fi
    
    for pid in $pids; do
        print_info "Killing process ${pid}"
        kill -9 $pid 2>/dev/null
    done
    
    sleep 2
    print_success "VLM Server stopped"
}

# Function to start server
start_server() {
    print_info "Starting VLM Server..."
    print_info "CUDA Devices: ${CUDA_DEVICES}"
    print_info "Model Path: ${MODEL_PATH}"
    print_info "Model Name: ${MODEL_NAME}"
    print_info "Host: ${HOST}"
    print_info "Port: ${PORT}"
    print_info "Max Model Length: ${MAX_MODEL_LEN}"
    print_info "Tensor Parallel Size: ${TENSOR_PARALLEL_SIZE}"
    
    # Check if model exists
    if [ ! -d "${MODEL_PATH}" ]; then
        print_error "Model path not found: ${MODEL_PATH}"
        exit 1
    fi
    
    # Check if port is already in use
    if lsof -i :${PORT} > /dev/null 2>&1; then
        print_error "Port ${PORT} is already in use"
        print_info "Use './start_vlm_server.sh --stop' to stop existing server"
        exit 1
    fi
    
    echo ""
    echo "=========================================="
    echo "  Starting VLM Server (RoboBrain2.5-8B)"
    echo "=========================================="
    echo ""
    
    # Start server
    CUDA_VISIBLE_DEVICES=${CUDA_DEVICES} python -m vllm.entrypoints.openai.api_server \
        --model ${MODEL_PATH} \
        --served-model-name ${MODEL_NAME} \
        --host ${HOST} \
        --port ${PORT} \
        --max_model_len ${MAX_MODEL_LEN} \
        --tensor-parallel-size ${TENSOR_PARALLEL_SIZE}
}

# Function to start server in background
start_server_background() {
    print_info "Starting VLM Server in background..."
    print_info "CUDA Devices: ${CUDA_DEVICES}"
    print_info "Model Path: ${MODEL_PATH}"
    print_info "Model Name: ${MODEL_NAME}"
    print_info "Port: ${PORT}"
    
    # Check if model exists
    if [ ! -d "${MODEL_PATH}" ]; then
        print_error "Model path not found: ${MODEL_PATH}"
        exit 1
    fi
    
    # Check if port is already in use
    if lsof -i :${PORT} > /dev/null 2>&1; then
        print_error "Port ${PORT} is already in use"
        print_info "Use './start_vlm_server.sh --stop' to stop existing server"
        exit 1
    fi
    
    # Log file
    LOG_FILE="/tmp/vlm_server_${PORT}.log"
    
    print_info "Log file: ${LOG_FILE}"
    
    # Start server in background
    nohup CUDA_VISIBLE_DEVICES=${CUDA_DEVICES} python -m vllm.entrypoints.openai.api_server \
        --model ${MODEL_PATH} \
        --served-model-name ${MODEL_NAME} \
        --host ${HOST} \
        --port ${PORT} \
        --max_model_len ${MAX_MODEL_LEN} \
        --tensor-parallel-size ${TENSOR_PARALLEL_SIZE} \
        > ${LOG_FILE} 2>&1 &
    
    SERVER_PID=$!
    
    echo ""
    print_success "VLM Server started in background (PID: ${SERVER_PID})"
    print_info "Waiting for server to be ready..."
    
    # Wait for server to be ready (max 120 seconds)
    MAX_WAIT=120
    WAIT_COUNT=0
    
    while [ $WAIT_COUNT -lt $MAX_WAIT ]; do
        if curl -s "http://localhost:${PORT}/v1/models" > /dev/null 2>&1; then
            print_success "VLM Server is ready!"
            print_info "API endpoint: http://localhost:${PORT}/v1"
            print_info "To stop: ./start_vlm_server.sh --stop"
            print_info "To view logs: tail -f ${LOG_FILE}"
            exit 0
        fi
        
        sleep 5
        WAIT_COUNT=$((WAIT_COUNT + 5))
        print_info "Waiting... (${WAIT_COUNT}/${MAX_WAIT}s)"
    done
    
    print_warning "Server may still be initializing. Check logs: ${LOG_FILE}"
}

# Main script
case "$1" in
    --background|-b)
        start_server_background
        ;;
    --stop|-s)
        stop_server
        ;;
    --status|-st)
        check_server_status
        ;;
    --help|-h)
        echo "Usage: $0 [OPTION]"
        echo ""
        echo "Options:"
        echo "  --background, -b    Start server in background"
        echo "  --stop, -s          Stop background server"
        echo "  --status, -st       Check server status"
        echo "  --help, -h          Show this help message"
        echo ""
        echo "Default: Start server in foreground"
        ;;
    *)
        start_server
        ;;
esac
