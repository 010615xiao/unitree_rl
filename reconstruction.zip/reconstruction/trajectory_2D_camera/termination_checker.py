#!/usr/bin/env python3
"""
导航终止判别模块

判断机器人是否已到达目标点。采用多重条件验证策略：
  1. VLM 趋势判断：对比起始帧和当前帧，判断是否在朝目标靠近
  2. 几何终止条件（满足任一即终止）：
     A. 起始点不再在地板上 → 机器人已非常接近目标
     B. 起始点→目标点连线上的地板像素占比 < 阈值 → 中间可走空间耗尽
     C. 目标区域中位深度 < 阈值 → 物理距离够近

使用场景：
  世界模型 rollout 最后一帧 → 跑深度/分割 → 终止判断 → 继续 or 停止

输入：
  - start_rgb_path: 起始视角的原始 RGB 图像路径
  - current_rgb_path: 当前视角的原始 RGB 图像路径
  - start_target_mask: 起始视角的目标 mask [H, W]
  - current_target_mask: 当前视角的目标 mask [H, W]
  - current_depth_map: 当前视角的深度图 [H, W]
  - current_floor_mask: 当前视角的地板 mask [H, W]
  - target_description: 目标语义描述，如 "黑色的垃圾桶"
  - start_point: 起始点像素坐标 (x, y)，默认 (310, 450)

输出：
  - {"reached": bool, "vlm_reached": bool, "geo_reached": bool,
     "reasons": list, "target_median_depth": float,
     "start_on_floor": bool, "floor_path_ratio": float}
"""

import base64
import cv2
import numpy as np
import os
from typing import Dict, Optional, Tuple
from openai import OpenAI

# 配置
VLM_BASE_URL = "http://localhost:8011/v1"
VLM_MODEL = "RoboBrain2.5-8B"

# 终止阈值
DEPTH_THRESHOLD = 0.8            # 目标中位深度阈值（米）
FLOOR_PATH_RATIO_THRESHOLD = 0.3 # 起始点→目标连线上地板像素占比阈值
DEFAULT_START_POINT = (310, 450) # 起始点像素坐标 (x, y)
VLM_TEMPERATURE = 0.1


def encode_image_to_base64(image_path: str) -> str:
    """将图像编码为 base64"""
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def extract_target_mask_from_depth_masks(depth_masks_path: str) -> Tuple[np.ndarray, float]:
    """
    从 depth_masks 图像中提取目标 mask（红色区域）和面积占比

    Returns:
        target_mask: [H, W] 布尔数组
        area_ratio: 目标 mask 占整图的比例
    """
    img = cv2.imread(depth_masks_path)
    if img is None:
        return np.zeros((1, 1), dtype=bool), 0.0

    h, w = img.shape[:2]
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # 红色区域（HSV 色相环绕，需要两个范围）
    lower_red_1 = np.array([0, 80, 40])
    upper_red_1 = np.array([10, 255, 255])
    lower_red_2 = np.array([170, 80, 40])
    upper_red_2 = np.array([180, 255, 255])
    mask1 = cv2.inRange(hsv, lower_red_1, upper_red_1)
    mask2 = cv2.inRange(hsv, lower_red_2, upper_red_2)
    target_mask = (mask1 | mask2) > 0

    area_ratio = target_mask.sum() / (h * w)
    return target_mask, area_ratio


def extract_floor_mask_from_depth_masks(depth_masks_path: str) -> np.ndarray:
    """
    从 depth_masks 图像中提取地板 mask（绿色区域）

    Returns:
        floor_mask: [H, W] 布尔数组
    """
    img = cv2.imread(depth_masks_path)
    if img is None:
        return np.zeros((1, 1), dtype=bool)

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    lower_green = np.array([35, 40, 50])
    upper_green = np.array([85, 255, 255])
    return cv2.inRange(hsv, lower_green, upper_green) > 0


def compute_target_median_depth(depth_map: np.ndarray, target_mask: np.ndarray) -> Optional[float]:
    """
    计算目标区域的中位深度（毫秒级，无需点云）

    Args:
        depth_map: [H, W] 深度图（米）
        target_mask: [H, W] 布尔数组

    Returns:
        目标区域中位深度（米）
    """
    if depth_map is None or target_mask is None:
        return None

    target_mask = target_mask.astype(bool)
    if target_mask.sum() == 0:
        return None

    target_depths = depth_map[target_mask]
    # 过滤无效深度
    valid = np.isfinite(target_depths) & (target_depths > 0.01)
    if valid.sum() == 0:
        return None

    return float(np.median(target_depths[valid]))


def check_start_on_floor(floor_mask: np.ndarray, start_point: Tuple[int, int]) -> bool:
    """
    检查起始点是否还在地板上

    Args:
        floor_mask: [H, W] 布尔数组
        start_point: (x, y) 像素坐标

    Returns:
        True = 起始点在地板上
    """
    if floor_mask is None or start_point is None:
        return True  # 没有信息时假设在地板上

    x, y = start_point
    h, w = floor_mask.shape
    if 0 <= x < w and 0 <= y < h:
        return bool(floor_mask[y, x])
    return False  # 越界认为不在地板上


def compute_floor_path_ratio(floor_mask: np.ndarray,
                              start_point: Tuple[int, int],
                              target_mask: np.ndarray) -> float:
    """
    计算起始点→目标中心连线上地板像素的占比

    Args:
        floor_mask: [H, W] 布尔数组
        start_point: (x, y) 起始点像素坐标
        target_mask: [H, W] 目标 mask

    Returns:
        线上地板像素占比 (0~1)
    """
    if floor_mask is None or start_point is None or target_mask is None:
        return 1.0  # 没有信息时假设全是地板

    # 目标中心
    ys, xs = np.where(target_mask.astype(bool))
    if len(xs) == 0 or len(ys) == 0:
        return 1.0

    target_cx = int(np.median(xs))
    target_cy = int(np.median(ys))

    # Bresenham 画线获取线上所有像素
    x0, y0 = start_point
    x1, y1 = target_cx, target_cy

    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx - dy

    floor_count = 0
    total_count = 0

    h, w = floor_mask.shape
    while True:
        if 0 <= x0 < w and 0 <= y0 < h:
            total_count += 1
            if floor_mask[y0, x0]:
                floor_count += 1

        if x0 == x1 and y0 == y1:
            break

        e2 = 2 * err
        if e2 > -dy:
            err -= dy
            x0 += sx
        if e2 < dx:
            err += dx
            y0 += sy

    return floor_count / total_count if total_count > 0 else 1.0


def geometric_check(
    depth_map: np.ndarray,
    floor_mask: np.ndarray,
    target_mask: np.ndarray,
    start_point: Tuple[int, int] = DEFAULT_START_POINT,
    depth_threshold: float = DEPTH_THRESHOLD,
    floor_path_ratio_threshold: float = FLOOR_PATH_RATIO_THRESHOLD
) -> Dict:
    """
    几何终止条件检查（OR 门：满足任一即终止）

    条件A: 起始点不在地板上 → 立即终止
    条件B: 起始点→目标连线上地板占比 < 阈值 → 终止
    条件C: 目标中位深度 < 阈值 → 终止

    Returns:
        {
            "reached": bool,
            "reasons": list,
            "start_on_floor": bool,
            "floor_path_ratio": float,
            "target_median_depth": float
        }
    """
    reasons = []
    reached = False

    # 条件A: 起始点是否还在地板上
    start_on_floor = check_start_on_floor(floor_mask, start_point)
    if not start_on_floor:
        reached = True
        reasons.append("A: 起始点已不在地板上，机器人非常接近目标")

    # 条件B: 起始点→目标连线上地板占比
    floor_path_ratio = compute_floor_path_ratio(floor_mask, start_point, target_mask)
    if floor_path_ratio < floor_path_ratio_threshold:
        reached = True
        reasons.append(f"B: 起始点→目标连线上地板占比 {floor_path_ratio:.1%} < {floor_path_ratio_threshold:.0%}，可走空间耗尽")

    # 条件C: 目标中位深度
    target_median_depth = compute_target_median_depth(depth_map, target_mask)
    if target_median_depth is not None and target_median_depth < depth_threshold:
        reached = True
        reasons.append(f"C: 目标中位深度 {target_median_depth:.2f}m < {depth_threshold:.1f}m，物理距离够近")

    if not reached:
        parts = []
        if start_on_floor:
            parts.append("A: 起始点仍在地板上")
        parts.append(f"B: 连线地板占比 {floor_path_ratio:.1%} >= {floor_path_ratio_threshold:.0%}")
        if target_median_depth is not None:
            parts.append(f"C: 目标中位深度 {target_median_depth:.2f}m >= {depth_threshold:.1f}m")
        reasons.append("未满足终止条件: " + "; ".join(parts))

    return {
        "reached": reached,
        "reasons": reasons,
        "start_on_floor": start_on_floor,
        "floor_path_ratio": floor_path_ratio,
        "target_median_depth": target_median_depth
    }


def overlay_target_mask_on_rgb(rgb_path: str, target_mask: np.ndarray,
                                color: tuple = (0, 0, 255)) -> np.ndarray:
    """
    在 RGB 图像上叠加目标 mask 的轮廓和半透明填充

    Args:
        rgb_path: RGB 图像路径
        target_mask: [H, W] 布尔数组
        color: mask 轮廓颜色 BGR

    Returns:
        叠加后的 BGR 图像
    """
    img = cv2.imread(rgb_path)
    if img is None:
        return None

    if target_mask is None or target_mask.sum() == 0:
        return img

    # 确保布尔数组
    target_mask = target_mask.astype(bool)

    # 绘制 mask 轮廓
    mask_uint8 = (target_mask * 255).astype(np.uint8)
    contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(img, contours, -1, color, 3)

    # 半透明填充
    overlay = img.copy()
    overlay[target_mask] = (overlay[target_mask] * 0.6 + np.array(color) * 0.4).astype(np.uint8)
    img = cv2.addWeighted(overlay, 0.7, img, 0.3, 0)

    return img


def create_comparison_image(
    start_rgb_path: str,
    current_rgb_path: str,
    start_target_mask: Optional[np.ndarray] = None,
    current_target_mask: Optional[np.ndarray] = None
) -> Optional[str]:
    """
    创建起始帧和当前帧的并排对比图（RGB + 目标 mask 叠加）

    Returns:
        对比图保存路径
    """
    start_img = overlay_target_mask_on_rgb(start_rgb_path, start_target_mask)
    current_img = overlay_target_mask_on_rgb(current_rgb_path, current_target_mask)

    if start_img is None or current_img is None:
        return None

    # 统一高度
    h1, w1 = start_img.shape[:2]
    h2, w2 = current_img.shape[:2]
    target_h = max(h1, h2)

    if h1 != target_h:
        scale = target_h / h1
        start_img = cv2.resize(start_img, (int(w1 * scale), target_h))
    if h2 != target_h:
        scale = target_h / h2
        current_img = cv2.resize(current_img, (int(w2 * scale), target_h))

    # 并排拼接
    comparison = np.hstack([start_img, current_img])

    # 保存临时文件
    output_path = "./termination_comparison.png"
    cv2.imwrite(output_path, comparison)
    return output_path


def vlm_check_arrival(
    start_rgb_path: str,
    current_rgb_path: str,
    target_description: str,
    start_target_mask: Optional[np.ndarray] = None,
    current_target_mask: Optional[np.ndarray] = None,
    client: Optional[OpenAI] = None,
    model: str = VLM_MODEL
) -> Dict:
    """
    让 VLM 对比起始帧和当前帧（RGB + 目标 mask 叠加），判断是否靠近目标

    Args:
        start_rgb_path: 起始视角的原始 RGB 图像
        current_rgb_path: 当前视角的原始 RGB 图像
        target_description: 目标语义描述，如 "黑色的垃圾桶"
        start_target_mask: 起始视角的目标 mask
        current_target_mask: 当前视角的目标 mask
        client: OpenAI 客户端
        model: 模型名

    Returns:
        {"reached": bool, "confidence": float, "reason": str}
    """
    if client is None:
        client = OpenAI(base_url=VLM_BASE_URL, api_key="not-needed")

    # 创建对比图（RGB + mask 叠加）
    comparison_path = create_comparison_image(
        start_rgb_path, current_rgb_path,
        start_target_mask, current_target_mask
    )
    if comparison_path is None:
        return {"reached": False, "confidence": 0.0, "reason": "无法创建对比图"}

    img_b64 = encode_image_to_base64(comparison_path)

    prompt = f"""You are a robot navigation system. Compare the two images side by side.

**Left image:** The view when the robot STARTED navigating
**Right image:** The robot's CURRENT view

**Target object:** {target_description}
The red contour and overlay marks the target object in each image.

**Question:** Is the robot moving CLOSER toward the target?

**Criteria for YES (moving closer):**
1. The target appears LARGER or CLOSER in the right image compared to the left
2. The robot is facing the target (not looking away)
3. The target is more prominent or less occluded in the current view

**Criteria for NO (not moving closer):**
1. The target appears smaller or further away
2. The robot is looking in a different direction
3. No meaningful progress toward the target

**Answer Format:**
<analysis>
Brief comparison: how has the target's apparent distance changed between the two views?
</analysis>

<decision>
YES or NO
</decision>

<confidence>
High / Medium / Low
</confidence>
"""

    try:
        from timing_tracker import tracker
        
        # 打印 VLM Prompt（如果启用）
        from vlm_logger import log_vlm_call, log_vlm_output
        log_vlm_call("导航终止判断", prompt)
        
        tracker.start("VLM", "导航终止判断")
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}},
                        ],
                    }
                ],
                max_tokens=2048,
                temperature=VLM_TEMPERATURE,
            )
        finally:
            tracker.end("VLM", "导航终止判断")

        result_text = response.choices[0].message.content.strip()
        
        # 打印 VLM 原始输出（如果启用）
        log_vlm_output("导航终止判断", result_text)

        # 解析决策
        reached = False
        confidence = 0.5
        reason = result_text

        if "<decision>" in result_text and "</decision>" in result_text:
            decision = result_text.split("<decision>")[1].split("</decision>")[0].strip().upper()
            reached = "YES" in decision

        if "<confidence>" in result_text and "</confidence>" in result_text:
            conf_str = result_text.split("<confidence>")[1].split("</confidence>")[0].strip().lower()
            if "high" in conf_str:
                confidence = 0.9
            elif "medium" in conf_str:
                confidence = 0.6
            elif "low" in conf_str:
                confidence = 0.3

        return {"reached": reached, "confidence": confidence, "reason": reason}

    except Exception as e:
        return {"reached": False, "confidence": 0.0, "reason": f"VLM 调用失败: {str(e)}"}


def check_termination(
    start_rgb_path: str,
    current_rgb_path: str,
    current_depth_map: np.ndarray,
    current_floor_mask: np.ndarray,
    current_target_mask: np.ndarray,
    start_target_mask: Optional[np.ndarray] = None,
    start_point: Tuple[int, int] = DEFAULT_START_POINT,
    target_description: str = "target object",
    depth_threshold: float = DEPTH_THRESHOLD,
    floor_path_ratio_threshold: float = FLOOR_PATH_RATIO_THRESHOLD,
    client: Optional[OpenAI] = None,
    model: str = VLM_MODEL
) -> Dict:
    """
    终止判别主函数

    VLM 判断是否在靠近 + 几何条件（OR 门：满足任一即终止）

    Args:
        start_rgb_path: 起始视角的原始 RGB 图像
        current_rgb_path: 当前视角的原始 RGB 图像
        current_depth_map: 当前视角的深度图 [H, W]
        current_floor_mask: 当前视角的地板 mask [H, W]
        current_target_mask: 当前视角的目标 mask [H, W]
        start_target_mask: 起始视角的目标 mask [H, W]
        start_point: 起始点像素坐标 (x, y)
        target_description: 目标语义描述
        depth_threshold: 目标中位深度阈值（米）
        floor_path_ratio_threshold: 起始点→目标连线上地板占比阈值
        client: OpenAI 客户端
        model: 模型名

    Returns:
        {
            "reached": bool,              # 最终终止信号
            "vlm_reached": bool,          # VLM 判断（是否在靠近）
            "geo_reached": bool,          # 几何判断（OR 门）
            "vlm_confidence": float,      # VLM 置信度
            "start_on_floor": bool,       # 起始点是否在地板上
            "floor_path_ratio": float,    # 起始点→目标连线地板占比
            "target_median_depth": float, # 目标中位深度
            "vlm_reason": str,            # VLM 理由
            "geo_reasons": list           # 几何判断理由
        }
    """
    # VLM 判断（趋势：是否在靠近）
    vlm_result = vlm_check_arrival(
        start_rgb_path,
        current_rgb_path,
        target_description,
        start_target_mask,
        current_target_mask,
        client,
        model
    )

    # 几何判断（OR 门：满足任一即终止）
    geo_result = geometric_check(
        current_depth_map,
        current_floor_mask,
        current_target_mask,
        start_point,
        depth_threshold,
        floor_path_ratio_threshold
    )

    # 终止条件：VLM 说在靠近 AND 几何条件满足
    reached = vlm_result["reached"] and geo_result["reached"]

    return {
        "reached": reached,
        "vlm_reached": vlm_result["reached"],
        "geo_reached": geo_result["reached"],
        "vlm_confidence": vlm_result["confidence"],
        "start_on_floor": geo_result["start_on_floor"],
        "floor_path_ratio": geo_result["floor_path_ratio"],
        "target_median_depth": geo_result["target_median_depth"],
        "vlm_reason": vlm_result["reason"],
        "geo_reasons": geo_result["reasons"]
    }


def main():
    """测试终止判别模块"""
    import argparse

    parser = argparse.ArgumentParser(description="导航终止判别模块")
    parser.add_argument("--start-rgb", type=str, required=True,
                        help="起始视角的原始 RGB 图像路径")
    parser.add_argument("--current-rgb", type=str, required=True,
                        help="当前视角的原始 RGB 图像路径")
    parser.add_argument("--start-mask", type=str, default=None,
                        help="起始视角的目标 mask .npy 路径 [H,W] 布尔数组")
    parser.add_argument("--current-mask", type=str, required=True,
                        help="当前视角的目标 mask .npy 路径 [H,W] 布尔数组")
    parser.add_argument("--depth-map", type=str, required=True,
                        help="当前视角的深度图 .npy 路径 [H,W]")
    parser.add_argument("--floor-mask", type=str, required=True,
                        help="当前视角的地板 mask .npy 路径 [H,W] 布尔数组")
    parser.add_argument("--target-desc", type=str, default="target object",
                        help="目标语义描述")
    parser.add_argument("--depth-threshold", type=float, default=DEPTH_THRESHOLD,
                        help=f"目标中位深度阈值（米），默认 {DEPTH_THRESHOLD}")
    parser.add_argument("--floor-ratio-threshold", type=float, default=FLOOR_PATH_RATIO_THRESHOLD,
                        help=f"起始点→目标连线地板占比阈值，默认 {FLOOR_PATH_RATIO_THRESHOLD}")
    parser.add_argument("--start-point", type=str, default=None,
                        help="起始点像素坐标 x,y（默认 310,450）")
    args = parser.parse_args()

    print("=" * 70)
    print("🛑 导航终止判别")
    print("=" * 70)
    print(f"起始 RGB：{args.start_rgb}")
    print(f"当前 RGB：{args.current_rgb}")
    print(f"目标描述：{args.target_desc}")
    print(f"深度阈值：{args.depth_threshold}m")
    print(f"地板占比阈值：{args.floor_ratio_threshold:.0%}")
    print("=" * 70)

    # 加载目标 mask
    start_target_mask = None
    if args.start_mask and os.path.exists(args.start_mask):
        start_target_mask = np.load(args.start_mask)
        print(f"✅ 起始目标 mask：{start_target_mask.shape}, 面积占比 {start_target_mask.sum()/(start_target_mask.shape[0]*start_target_mask.shape[1]):.1%}")

    current_target_mask = np.load(args.current_mask)
    area = current_target_mask.sum() / (current_target_mask.shape[0] * current_target_mask.shape[1])
    print(f"✅ 当前目标 mask：{current_target_mask.shape}, 面积占比 {area:.1%}")

    # 加载深度图
    depth_map = np.load(args.depth_map)
    print(f"✅ 深度图：{depth_map.shape}")

    # 加载地板 mask
    floor_mask = np.load(args.floor_mask)
    print(f"✅ 地板 mask：{floor_mask.shape}, 面积占比 {floor_mask.sum()/(floor_mask.shape[0]*floor_mask.shape[1]):.1%}")

    # 起始点
    start_point = DEFAULT_START_POINT
    if args.start_point:
        x, y = map(int, args.start_point.split(","))
        start_point = (x, y)
        print(f"✅ 起始点：{start_point}")

    # 终止判断
    result = check_termination(
        start_rgb_path=args.start_rgb,
        current_rgb_path=args.current_rgb,
        current_depth_map=depth_map,
        current_floor_mask=floor_mask,
        current_target_mask=current_target_mask,
        start_target_mask=start_target_mask,
        start_point=start_point,
        target_description=args.target_desc,
        depth_threshold=args.depth_threshold,
        floor_path_ratio_threshold=args.floor_ratio_threshold
    )

    # 输出结果
    print("\n" + "=" * 70)
    print("📋 终止判别结果")
    print("=" * 70)
    print(f"  最终决策：{'🛑 到达，终止' if result['reached'] else '🚶 未到达，继续'}")
    print(f"  VLM 判断：{'✅ 在靠近' if result['vlm_reached'] else '❌ 未靠近'} (置信度: {result['vlm_confidence']:.1%})")
    print(f"  几何判断：{'✅ 满足' if result['geo_reached'] else '❌ 未满足'}")
    print(f"  起始点在地板上：{'是' if result['start_on_floor'] else '否'}")
    print(f"  连线地板占比：{result['floor_path_ratio']:.1%}")
    if result['target_median_depth'] is not None:
        print(f"  目标中位深度：{result['target_median_depth']:.2f}m")
    print(f"\n  VLM 理由：{result['vlm_reason']}")
    print(f"  几何理由：")
    for r in result['geo_reasons']:
        print(f"    - {r}")
    print("=" * 70)


if __name__ == "__main__":
    main()
