#!/usr/bin/env python3
"""
API 客户端示例 - 展示如何使用点云分割结果（Base64 编码）

用法:
    python example_client_segmentation.py --image /path/to/image.png --instruction "左边的椅子" --api-url http://localhost:9000
"""

import argparse
import json
import base64
import os
import requests
from pathlib import Path


def call_trajectory_api(image_path: str, instruction: str, api_url: str = "http://localhost:9000", output_dir: str = "api_output"):
    """
    调用轨迹规划 API 并保存点云分割结果到本地

    Args:
        image_path: 输入图像路径
        instruction: 自然语言指令
        api_url: API 服务器 URL
        output_dir: 输出目录
    """
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    # 准备请求
    url = f"{api_url}/api/trajectory"
    files = {
        'image': (os.path.basename(image_path), open(image_path, 'rb'), 'image/png')
    }
    data = {
        'instruction': instruction,
        'return_metadata': True,
        'skip_ply_save': True
    }

    print(f"🚀 正在调用 API: {url}")
    print(f"   图像: {image_path}")
    print(f"   指令: {instruction}")

    try:
        response = requests.post(url, files=files, data=data)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"❌ API 调用失败: {e}")
        return None
    finally:
        files['image'][1].close()

    # 解析响应
    result = response.json()

    if not result.get('success'):
        print(f"❌ API 返回失败: {result.get('error', 'unknown')}")
        return None

    print(f"✅ API 调用成功")
    print(f"   轨迹点数: {result.get('num_points', 0)}")

    # 保存完整响应
    response_path = os.path.join(output_dir, "response.json")
    with open(response_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"✅ 响应已保存: {response_path}")

    # 提取点云分割结果
    segmentation_results = result.get('segmentation_results')
    if segmentation_results:
        seg_dir = os.path.join(output_dir, "segmentation")
        os.makedirs(seg_dir, exist_ok=True)

        print(f"\n📦 正在提取点云分割结果...")
        for filename, base64_data in segmentation_results.items():
            file_bytes = base64.b64decode(base64_data)
            file_path = os.path.join(seg_dir, filename)
            with open(file_path, 'wb') as f:
                f.write(file_bytes)
            print(f"   ✅ {filename} ({len(file_bytes)} bytes)")

        print(f"\n✅ 点云分割结果已保存到: {seg_dir}/")
        print(f"   包含文件:")
        for filename in segmentation_results.keys():
            print(f"     - {filename}")
    else:
        print(f"\n⚠️ 响应中未找到点云分割结果数据")

    # 提取轨迹动画（如果存在）
    trajectory_video = result.get('trajectory_video_base64')
    if trajectory_video:
        video_path = os.path.join(output_dir, "trajectory.mp4")
        video_bytes = base64.b64decode(trajectory_video)
        with open(video_path, 'wb') as f:
            f.write(video_bytes)
        print(f"\n🎬 轨迹动画已保存: {video_path} ({len(video_bytes)} bytes)")

    # 提取渲染图像（如果存在）
    rendered_views = result.get('rendered_views', [])
    if rendered_views:
        views_dir = os.path.join(output_dir, "rendered_views")
        os.makedirs(views_dir, exist_ok=True)

        print(f"\n🖼️  正在提取渲染图像...")
        for idx, view in enumerate(rendered_views):
            if view.get('image_base64'):
                img_bytes = base64.b64decode(view['image_base64'])
                img_path = os.path.join(views_dir, f"view_{idx:03d}.png")
                with open(img_path, 'wb') as f:
                    f.write(img_bytes)
                print(f"   ✅ view_{idx:03d}.png ({len(img_bytes)} bytes)")

        print(f"\n✅ 渲染图像已保存到: {views_dir}/")

    return result


def main():
    parser = argparse.ArgumentParser(description="API 客户端示例 - 点云分割结果")
    parser.add_argument("--image", type=str, required=True, help="输入图像路径")
    parser.add_argument("--instruction", type=str, required=True, help="自然语言指令")
    parser.add_argument("--api-url", type=str, default="http://localhost:9000", help="API 服务器 URL")
    parser.add_argument("--output-dir", type=str, default="api_output", help="输出目录")
    args = parser.parse_args()

    if not os.path.exists(args.image):
        print(f"❌ 图像文件不存在: {args.image}")
        return

    result = call_trajectory_api(
        image_path=args.image,
        instruction=args.instruction,
        api_url=args.api_url,
        output_dir=args.output_dir
    )

    if result:
        print(f"\n{'='*60}")
        print("✅ 完成！")
        print(f"{'='*60}")
        print(f"输出目录: {args.output_dir}/")
        print(f"  - response.json              (完整 API 响应)")
        print(f"  - segmentation/              (点云分割结果)")
        if result.get('trajectory_video_base64'):
            print(f"  - trajectory.mp4            (轨迹动画)")
        if result.get('rendered_views'):
            print(f"  - rendered_views/            (渲染图像)")


if __name__ == "__main__":
    main()
