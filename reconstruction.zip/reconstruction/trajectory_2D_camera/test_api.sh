#!/bin/bash

# API 轨迹规划请求脚本 - 接收并保存渲染视角图像

API_URL="http://localhost:9001/api/trajectory"
IMAGE_PATH="/workspace/wxd/Agent/images/frames/frame_0110.png"
INSTRUCTION="左边的椅子"
OUTPUT_DIR="./api_result"

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

echo "=========================================="
echo "🚀 发送轨迹规划请求"
echo "=========================================="
echo "API 地址: $API_URL"
echo "图像路径: $IMAGE_PATH"
echo "指令: $INSTRUCTION"
echo "输出目录: $OUTPUT_DIR"
echo "=========================================="

# 发送请求，将响应保存到临时文件
RESPONSE_FILE="$OUTPUT_DIR/response.json"

echo "⏳ 正在请求 API..."
curl -s -X POST "$API_URL" \
    -F "image=@$IMAGE_PATH" \
    -F "instruction=$INSTRUCTION" \
    -o "$RESPONSE_FILE"

# 检查请求是否成功
if [ $? -ne 0 ]; then
    echo "❌ 请求失败！"
    exit 1
fi

echo "✅ 请求完成，响应已保存到: $RESPONSE_FILE"

# 解析响应
echo ""
echo "=========================================="
echo "📊 解析响应"
echo "=========================================="

# 使用 Python 解析 JSON 并提取渲染图像
python3 << 'PYTHON_SCRIPT'
import json
import os
import base64
from pathlib import Path

output_dir = Path("./api_result")
response_file = output_dir / "response.json"

# 读取响应
with open(response_file, 'r', encoding='utf-8') as f:
    response = json.load(f)

# 打印基本信息
print(f"✅ 成功: {response.get('success')}")
print(f"📝 消息: {response.get('message')}")
print(f"📍 轨迹点数量: {response.get('num_points')}")
print(f"⏱️  处理耗时: {response.get('processing_time_seconds', 0):.2f} 秒")

# 提取轨迹点
trajectory = response.get('trajectory', [])
if trajectory:
    print(f"\n🛤️  轨迹点（前 5 个）:")
    for point in trajectory[:5]:
        print(f"   索引 {point.get('index')}: ({point.get('x')}, {point.get('y')})")
    if len(trajectory) > 5:
        print(f"   ... 共 {len(trajectory)} 个点")

# 提取渲染视角图像
rendered_views = response.get('rendered_views', [])
if rendered_views:
    print(f"\n📸 渲染视角图像: {len(rendered_views)} 张")
    
    images_dir = output_dir / "rendered_views"
    images_dir.mkdir(exist_ok=True)
    
    for view in rendered_views:
        view_index = view.get('view_index', 0)
        image_base64 = view.get('image_base64', '')
        
        if image_base64:
            # 解码 Base64 并保存
            image_bytes = base64.b64decode(image_base64)
            image_path = images_dir / f"view_{view_index:03d}.png"
            
            with open(image_path, 'wb') as img_f:
                img_f.write(image_bytes)
            
            print(f"   ✅ 视图 {view_index}: 已保存到 {image_path}")
        else:
            print(f"   ⚠️  视图 {view_index}: 无图像数据")
    
    print(f"\n📁 所有渲染图像已保存到: {images_dir}")
else:
    print("\n⚠️  无渲染视角图像（return_rendered_views=false 或渲染失败）")

# 提取验证信息
validation = response.get('validation')
if validation:
    print(f"\n🔍 验证信息:")
    print(f"   地板覆盖率: {validation.get('floor_coverage', 0):.2%}")
    print(f"   在地板上的点: {validation.get('on_floor_count', 0)}")
    print(f"   不在地板上的点: {validation.get('off_floor_count', 0)}")

# 保存关键点信息
start_point = response.get('start_point')
target_point = response.get('target_point')
navigation_goal_point = response.get('navigation_goal_point')

print(f"\n🎯 关键点:")
print(f"   起点: {start_point}")
print(f"   目标点: {target_point}")
print(f"   导航终点: {navigation_goal_point}")

print("\n✅ 解析完成！")
PYTHON_SCRIPT

echo ""
echo "=========================================="
echo "📁 输出文件"
echo "=========================================="
echo "完整响应: $OUTPUT_DIR/response.json"
echo "渲染图像: $OUTPUT_DIR/rendered_views/view_*.png"
echo "=========================================="
