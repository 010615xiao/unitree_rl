#!/usr/bin/env python3
"""
测试 run_pipeline.py 的 API 模式

用法:
    python test_api_mode.py --api-url http://localhost:9000 --image /path/to/image.png
"""

import argparse
import sys
import os

def test_api_mode(api_url, image_path):
    """测试 API 模式"""
    print("=" * 80)
    print("🧪 测试 run_pipeline.py 的 API 模式")
    print("=" * 80)
    print(f"API URL: {api_url}")
    print(f"图像路径: {image_path}")
    print()
    
    # 检查图像是否存在
    if not os.path.exists(image_path):
        print(f"❌ 图像文件不存在: {image_path}")
        return False
    
    # 构建命令
    cmd = [
        sys.executable, "run_pipeline.py",
        "--image", image_path,
        "--instruction", "测试目标",
        "--api-url", api_url,
        "--output-dir", "./test_api_output"
    ]
    
    print(f"🚀 执行命令:")
    print(f"   {' '.join(cmd)}")
    print()
    
    # 执行命令
    import subprocess
    result = subprocess.run(cmd, capture_output=False, text=True)
    
    print()
    if result.returncode == 0:
        print("✅ API 模式测试成功！")
        return True
    else:
        print(f"❌ API 模式测试失败，退出码: {result.returncode}")
        return False


def main():
    parser = argparse.ArgumentParser(description="测试 run_pipeline.py 的 API 模式")
    parser.add_argument("--api-url", type=str, required=True, help="API 服务器 URL")
    parser.add_argument("--image", type=str, required=True, help="测试图像路径")
    args = parser.parse_args()
    
    success = test_api_mode(args.api_url, args.image)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
