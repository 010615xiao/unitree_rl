#!/bin/bash
# 统一启动脚本：同时启动 SAM2、GroundingDINO 和 Depth-Anything-v3 服务
# 所有服务将在后台运行，日志输出到各自的文件
#
# 使用示例:
#   ./start_services.sh              # 启动所有服务
#   ./start_services.sh --status     # 查看服务状态
#
# 注意：模型文件位于 ../checkpoints/ 目录下

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHECKPOINT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"  # 模型目录在父目录

# 设置使用的 GPU
export CUDA_VISIBLE_DEVICES=7

echo "=========================================="
echo "🚀 启动多服务（SAM2 + GroundingDINO + Depth-Anything-v3）"
echo "=========================================="
echo ""
echo "工作目录：$CHECKPOINT_DIR"
echo "使用 GPU: $CUDA_VISIBLE_DEVICES"
echo ""

# 创建日志目录
LOG_DIR="$CHECKPOINT_DIR/service_logs"
mkdir -p "$LOG_DIR"

# 检查端口是否已被占用
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
        return 0  # 端口被占用
    else
        return 1  # 端口空闲
    fi
}

# 启动 SAM2 服务 (端口 20020)
echo "📦 启动 SAM2 服务 (端口 20020)..."
if check_port 20020; then
    echo "⚠️  端口 20020 已被占用，跳过 SAM2 启动"
else
    nohup python "$SCRIPT_DIR/sam2_server.py" \
        --checkpoint_path "$CHECKPOINT_DIR/sam2/sam2.1_l.pt" \
        --port 20020 \
        > "$LOG_DIR/sam2.log" 2>&1 &
    SAM2_PID=$!
    echo "✅ SAM2 服务已启动 (PID: $SAM2_PID)"
    sleep 2  # 等待 SAM2 启动
fi

# 启动 GroundingDINO 服务 (端口 20021)
echo "🔍 启动 GroundingDINO 服务 (端口 20021)..."
if check_port 20021; then
    echo "⚠️  端口 20021 已被占用，跳过 GroundingDINO 启动"
else
    nohup python "$SCRIPT_DIR/grounding_dino_server.py" \
        --checkpoint_path "$CHECKPOINT_DIR/grounding_dino/groundingdino_swinb_cogcoor.pth" \
        --port 20021 \
        > "$LOG_DIR/grounding_dino.log" 2>&1 &
    GDINO_PID=$!
    echo "✅ GroundingDINO 服务已启动 (PID: $GDINO_PID)"
    sleep 3  # 等待 GroundingDINO 启动
fi

# 启动 Depth-Anything-v3 服务 (端口 20022)
echo "📊 启动 Depth-Anything-v3 服务 (端口 20022)..."
if check_port 20022; then
    echo "⚠️  端口 20022 已被占用，跳过 Depth-Anything-v3 启动"
else
    nohup python "$CHECKPOINT_DIR/depth_anything/depth_anything_v3_server.py" \
        --checkpoint_path "$CHECKPOINT_DIR/depth_anything" \
        --port 20022 \
        > "$LOG_DIR/depth_anything_v3.log" 2>&1 &
    DA3_PID=$!
    echo "✅ Depth-Anything-v3 服务已启动 (PID: $DA3_PID)"
    sleep 5  # 等待 Depth-Anything-v3 启动
fi

echo ""
echo "=========================================="
echo "✅ 所有服务启动完成!"
echo "=========================================="
echo ""
echo "服务状态:"
echo "  - SAM2:              http://localhost:20020"
echo "  - GroundingDINO:     http://localhost:20021"
echo "  - Depth-Anything-v3: http://localhost:20022"
echo ""
echo "日志文件:"
echo "  - $LOG_DIR/sam2.log"
echo "  - $LOG_DIR/grounding_dino.log"
echo "  - $LOG_DIR/depth_anything_v3.log"
echo ""
echo "查看日志：tail -f $LOG_DIR/*.log"
echo "停止服务：bash $SCRIPT_DIR/stop_services.sh"
echo ""

# 等待服务启动（GroundingDINO 需要较长时间加载模型）
echo "⏳ 等待服务启动..."
sleep 12

# 检查服务状态（使用 curl 检查 HTTP 健康端点）
echo ""
echo "📋 服务健康检查:"

# 检查 SAM2
if curl -s --max-time 5 http://localhost:20020/health >/dev/null 2>&1; then
    echo "  ✅ SAM2:              运行中"
else
    echo "  ❌ SAM2:              未启动"
fi

# 检查 GroundingDINO
if curl -s --max-time 5 http://localhost:20021/health >/dev/null 2>&1; then
    echo "  ✅ GroundingDINO:     运行中"
else
    echo "  ❌ GroundingDINO:     未启动"
fi

# 检查 Depth-Anything-v3
if curl -s --max-time 5 http://localhost:20022/health >/dev/null 2>&1; then
    echo "  ✅ Depth-Anything-v3: 运行中"
else
    echo "  ❌ Depth-Anything-v3: 未启动"
fi

echo ""
echo "=========================================="
