#!/bin/bash
# 完整使用示例：先运行run_pipeline.py，再运行3D相机延伸

set -e

echo "========================================"
echo "3D相机位置延伸 - 完整流程示例"
echo "========================================"

# ========== 配置 ==========
IMAGE="current.jpg"                    # 当前帧图像
INSTRUCTION="找出可导航区域"            # 分割指令
OUTPUT_DIR="output"                    # 输出目录
NUM_TRANSITION_POINTS=10              # 过渡点数

# ========== 步骤1: 运行主流程 ==========
echo ""
echo "步骤 1/2: 运行 run_pipeline.py..."
echo ""

python run_pipeline.py \
    --image "$IMAGE" \
    --instruction "$INSTRUCTION" \
    --output_dir "$OUTPUT_DIR"

# 查找生成的轨迹文件
TRAJECTORY_JSON=$(find "$OUTPUT_DIR" -name "*_trajectory_data.json" -type f | head -1)

if [ -z "$TRAJECTORY_JSON" ]; then
    echo "❌ 未找到轨迹JSON文件"
    exit 1
fi

echo ""
echo "✅ 找到轨迹文件: $TRAJECTORY_JSON"

# 查找深度图文件
DEPTH_MAP=$(find "$OUTPUT_DIR" -name "depth_map.npy" -o -name "*_depth*.npy" | head -1)

if [ -z "$DEPTH_MAP" ]; then
    echo "❌ 未找到深度图文件"
    exit 1
fi

echo "✅ 找到深度图: $DEPTH_MAP"

# ========== 步骤2: 运行3D相机延伸 ==========
echo ""
echo "========================================"
echo "步骤 2/2: 运行 extend_camera_in_3d.py..."
echo "========================================"
echo ""

python extend_camera_in_3d.py \
    --trajectory_json "$TRAJECTORY_JSON" \
    --depth_map "$DEPTH_MAP" \
    --output_dir "$OUTPUT_DIR" \
    --num_transition_points "$NUM_TRANSITION_POINTS"

echo ""
echo "========================================"
echo "✅ 完整流程完成！"
echo "========================================"
echo ""
echo "输出文件:"
find "$OUTPUT_DIR" -name "*extended_3d*" -o -name "*transition_points_3d*" | while read file; do
    echo "  - $file"
done
