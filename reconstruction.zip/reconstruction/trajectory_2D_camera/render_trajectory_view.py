#!/usr/bin/env python3
"""
简化的新视角渲染模块 - 用于 trajectory_2D run_pipeline.py

与 render_3d_view.py 的区别：
1. 轨迹点都在地板上 → 直接从深度图查询深度值
2. 朝向计算简化 → 主要考虑水平方向的旋转（yaw）
3. 不需要复杂的 pitch 计算 → 地板上的点朝向基本水平

坐标系统：
- 世界坐标系：以原始相机为原点，X 向右，Y 向下，Z 向前
- 轨迹点：2D 像素坐标 (pixel_x, pixel_y) + 深度值 depth_m

运行示例：
    python render_trajectory_view.py \
        --depth_masks /workspace/wxd/Agent/images/trajectory_2D_results/frame_0017/frame_0017_depth_masks.png \
        --trajectory_data /workspace/wxd/Agent/images/trajectory_2D_results/frame_0017/frame_0017_depth_masks_trajectory_data_filtered.json \
        --original_image /workspace/wxd/Agent/images/frames/frame_0017.png \
        --view_index -1
"""

import argparse
import json
import os
import sys
import numpy as np
import cv2
from typing import Dict, List, Optional, Tuple
from datetime import datetime


def ransac_fit_floor_plane(floor_points_3d: np.ndarray, rng: np.random.Generator, 
                           n_iterations: int = 100, inlier_threshold: float = 0.05,
                           min_inliers: int = 10) -> Optional[Tuple[float, float, float, float, np.ndarray, int, float]]:
    """
    使用RANSAC拟合地板平面，返回确定性结果（使用传入的rng）
    
    Args:
        floor_points_3d: 地板点云 (N, 3)
        rng: numpy random generator（用于确定性采样）
        n_iterations: RANSAC迭代次数
        inlier_threshold: 内点距离阈值（米）
        min_inliers: 最小内点数量
    
    Returns:
        (a, b, c, d, floor_normal, n_inliers, residual) 或 None（拟合失败）
        其中 floor_normal 确保 b < 0（指向上方）
    """
    # 过滤无效点
    valid_mask = np.all(np.isfinite(floor_points_3d), axis=1)
    floor_points_3d_valid = floor_points_3d[valid_mask]
    
    if len(floor_points_3d_valid) < min_inliers:
        return None
    
    try:
        best_inliers = []
        best_plane = None
        best_residual = float('inf')
        
        n_points = len(floor_points_3d_valid)
        
        for _ in range(n_iterations):
            if n_points < 3:
                break
            
            # 使用传入的rng进行确定性采样
            idx = rng.choice(n_points, 3, replace=False)
            p1, p2, p3 = floor_points_3d_valid[idx]
            
            # 计算平面法向量
            v1 = p2 - p1
            v2 = p3 - p1
            normal = np.cross(v1, v2)
            norm = np.linalg.norm(normal)
            
            if norm < 1e-6:  # 三点共线
                continue
            
            normal = normal / norm
            a, b, c = normal
            d = -np.dot(normal, p1)
            
            # 计算内点
            distances = np.abs(a * floor_points_3d_valid[:, 0] +
                             b * floor_points_3d_valid[:, 1] +
                             c * floor_points_3d_valid[:, 2] + d)
            inlier_mask = distances < inlier_threshold
            
            n_inliers = np.sum(inlier_mask)
            
            if n_inliers > len(best_inliers):
                best_inliers = inlier_mask
                best_plane = (a, b, c, d)
                best_residual = np.mean(distances[inlier_mask])
        
        if best_plane is not None and len(best_inliers) >= min_inliers:
            a, b, c, d = best_plane
            n_inliers = np.sum(best_inliers)
            
            # 确保法向量指向上方（b < 0，因为相机坐标系Y向下为正）
            if b > 0:
                a, b, c, d = -a, -b, -c, -d
            
            floor_normal = np.array([a, b, c], dtype=np.float32)
            return (a, b, c, d, floor_normal, int(n_inliers), float(best_residual))
        else:
            return None
    except Exception as e:
        print(f"   ⚠️ RANSAC平面拟合异常：{e}")
        return None


def save_trajectory_pointcloud(
    trajectory_3d_points: np.ndarray,
    trajectory_colors: np.ndarray,
    output_path: str,
    point_type: str = "elevated"
) -> str:
    """
    保存轨迹点为 PLY 点云文件

    Args:
        trajectory_3d_points: [N, 3] 3D 坐标数组
        trajectory_colors: [N, 3] RGB 颜色数组 (0-255)
        output_path: 输出 PLY 文件路径
        point_type: 点类型标签（用于日志输出）

    Returns:
        保存的文件路径
    """
    if len(trajectory_3d_points) == 0:
        print(f"   ⚠️ {point_type} 轨迹点为空，跳过保存")
        return None

    # 确保颜色在 0-255 范围
    if trajectory_colors.max() <= 1.0:
        trajectory_colors = (trajectory_colors * 255).astype(np.uint8)
    else:
        trajectory_colors = trajectory_colors.astype(np.uint8)

    # 写入 PLY 文件（ASCII 格式）
    with open(output_path, 'w') as f:
        # PLY 头
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {len(trajectory_3d_points)}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        f.write("property uchar red\n")
        f.write("property uchar green\n")
        f.write("property uchar blue\n")
        f.write("end_header\n")

        # 写入点数据
        for pt, col in zip(trajectory_3d_points, trajectory_colors):
            f.write(f"{pt[0]:.6f} {pt[1]:.6f} {pt[2]:.6f} {int(col[0])} {int(col[1])} {int(col[2])}\n")

    print(f"   ✅ {point_type} 轨迹点云已保存：{output_path} ({len(trajectory_3d_points)} 个点)")
    print(f"      X 范围：[{trajectory_3d_points[:, 0].min():.3f}, {trajectory_3d_points[:, 0].max():.3f}] m")
    print(f"      Y 范围：[{trajectory_3d_points[:, 1].min():.3f}, {trajectory_3d_points[:, 1].max():.3f}] m")
    print(f"      Z 范围：[{trajectory_3d_points[:, 2].min():.3f}, {trajectory_3d_points[:, 2].max():.3f}] m")

    return output_path


class TrajectoryViewRenderer:
    """简化的轨迹点新视角渲染器"""

    def __init__(self, output_dir: Optional[str] = None):
        self.output_dir = output_dir
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

    def get_depth_from_depth_map(
        self,
        depth_map: np.ndarray,
        pixel_x: float,
        pixel_y: float,
        use_bilinear: bool = True
    ) -> Optional[float]:
        """
        从深度图查询指定像素位置的深度值

        Args:
            depth_map: 深度图 [H, W]
            pixel_x: 像素 x 坐标
            pixel_y: 像素 y 坐标
            use_bilinear: 是否使用双线性插值

        Returns:
            深度值（米），如果无效返回 None
        """
        h, w = depth_map.shape

        # 边界检查
        if pixel_x < 0 or pixel_x >= w or pixel_y < 0 or pixel_y >= h:
            print(f"   ⚠️ 像素坐标 ({pixel_x:.1f}, {pixel_y:.1f}) 超出深度图范围 ({w}x{h})")
            return None

        if use_bilinear:
            # 双线性插值
            x0, y0 = int(np.floor(pixel_x)), int(np.floor(pixel_y))
            x1, y1 = x0 + 1, y0 + 1

            # 边界检查
            x0 = max(0, min(x0, w - 1))
            x1 = max(0, min(x1, w - 1))
            y0 = max(0, min(y0, h - 1))
            y1 = max(0, min(y1, h - 1))

            # 插值权重
            wx = pixel_x - x0
            wy = pixel_y - y0

            # 双线性插值
            depth = (
                depth_map[y0, x0] * (1 - wx) * (1 - wy) +
                depth_map[y0, x1] * wx * (1 - wy) +
                depth_map[y1, x0] * (1 - wx) * wy +
                depth_map[y1, x1] * wx * wy
            )
        else:
            # 最近邻
            x, y = int(round(pixel_x)), int(round(pixel_y))
            x = max(0, min(x, w - 1))
            y = max(0, min(y, h - 1))
            depth = depth_map[y, x]

        # 验证深度值有效性
        if not np.isfinite(depth) or depth <= 0 or depth > 20:  # 合理深度范围 0-20 米
            print(f"   ⚠️ 深度值无效: {depth:.3f} 米 (超出合理范围)")
            return None

        return float(depth)

    def compute_camera_orientation(
        self,
        current_point: np.ndarray,
        next_point: Optional[np.ndarray],
        prev_point: Optional[np.ndarray],
        pitch_down_degrees: float = 15.0  # 默认向下俯仰 15 度
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        计算相机坐标系基向量（简化的朝向计算）

        相机被抬高到轨迹点上方后，为了让渲染画面与原始视角一致，
        给朝向添加一个向下的俯仰角（pitch down）。

        Args:
            current_point: 当前点 3D 坐标 [x, y, z]
            next_point: 下一个点 3D 坐标（可选）
            prev_point: 前一个点 3D 坐标（可选）
            pitch_down_degrees: 向下俯仰角度（度），默认 15 度

        Returns:
            (x_axis, y_axis, z_axis) 相机坐标系基向量
        """
        # 确定水平朝向方向（XZ 平面）
        if next_point is not None:
            direction = next_point - current_point
        elif prev_point is not None:
            direction = prev_point - current_point
        else:
            direction = np.array([0, 0, 1])

        # 水平方向（忽略 Y）
        direction[1] = 0.0
        h_norm = np.linalg.norm(direction)
        if h_norm > 1e-6:
            direction = direction / h_norm
        else:
            direction = np.array([0, 0, 1])

        # 添加向下俯仰角
        pitch_rad = np.deg2rad(pitch_down_degrees)
        # 原始方向是水平的 [dx, 0, dz]
        # 向下俯仰后：[dx*cos(pitch), sin(pitch), dz*cos(pitch)]
        cos_p = np.cos(pitch_rad)
        sin_p = np.sin(pitch_rad)
        direction[1] = sin_p  # Y 向下为正，所以是正值
        direction[0] *= cos_p
        direction[2] *= cos_p

        # 归一化
        norm = np.linalg.norm(direction)
        if norm > 1e-6:
            direction = direction / norm

        # Z 轴 = 朝向方向（向下俯仰）
        z_axis = direction

        # X 轴 = 水平向右（与世界Y轴垂直）
        x_axis = np.cross([0, 1, 0], z_axis)
        x_norm = np.linalg.norm(x_axis)
        if x_norm > 1e-6:
            x_axis = x_axis / x_norm
        else:
            x_axis = np.array([1, 0, 0])

        # Y 轴 = Z × X（右手定则）
        y_axis = np.cross(z_axis, x_axis)
        y_axis = y_axis / np.linalg.norm(y_axis)

        return x_axis, y_axis, z_axis

    def render_view(
        self,
        point_cloud: np.ndarray,
        original_image: np.ndarray,
        depth_map: np.ndarray,
        trajectory: List[List[float]],
        view_index: int = -1,
        yaw_offset: float = 0.0,
        intrinsics: Optional[np.ndarray] = None,
        image_path: Optional[str] = None,
        camera_height_offset: float = 0.5,  # 默认抬高 0.5 米
        render_origin_view: bool = False,   # 渲染初始相机原点视角
        save_elevated_trajectory: bool = False,  # 是否保存抬高后的轨迹点
        output_dir: Optional[str] = None    # 输出目录
    ) -> Optional[Dict[str, str]]:
        """
        从轨迹点渲染新视角

        Args:
            point_cloud: 点云 [H, W, 3]
            original_image: 原始 RGB 图像 [H, W, 3]
            depth_map: 深度图 [H, W]
            trajectory: 轨迹点列表 [[pixel_x, pixel_y], ...]
            view_index: 要渲染的轨迹点索引（-1 表示最后一个点）
            yaw_offset: 额外的 yaw 偏移（度）
            intrinsics: 相机内参 [3, 3]（可选）
            image_path: 原始图像路径（用于生成输出文件名，可选）
            camera_height_offset: 相机高度偏移（米），默认 0.5 米模拟人眼高度
            render_origin_view: 是否渲染初始相机原点视角（忽略 view_index）
            save_elevated_trajectory: 是否保存抬高后的轨迹点为点云文件
            output_dir: 输出目录（用于保存轨迹点云文件）

        Returns:
            输出文件路径字典
        """
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        print("\n" + "=" * 70)
        if render_origin_view:
            print("🎨 初始相机原点视角渲染")
        else:
            print("🎨 轨迹点新视角渲染")
        print("=" * 70)

        # 获取图像尺寸
        h_orig, w_orig = original_image.shape[:2]
        h_pc, w_pc = point_cloud.shape[:2]

        print(f"   原始图像：{w_orig}x{h_orig}")
        print(f"   点云尺寸：{w_pc}x{h_pc}")

        # 相机内参
        if intrinsics is not None:
            fx = intrinsics[0, 0] * w_orig
            fy = intrinsics[1, 1] * h_orig
            cx = intrinsics[0, 2] * w_orig
            cy = intrinsics[1, 2] * h_orig
            fov_x = 2 * np.arctan(w_orig / (2 * fx)) * 180 / np.pi
            print(f"   相机内参：fx={fx:.1f}, fy={fy:.1f}, cx={cx:.1f}, cy={cy:.1f}")
            print(f"   FOV: {fov_x:.1f}°")
        else:
            # 默认 FOV=60°
            focal_length = w_orig / (2 * np.tan(np.deg2rad(60) / 2))
            fx = fy = focal_length
            cx, cy = w_orig / 2, h_orig / 2
            print(f"   相机内参（默认 FOV=60°）：fx=fy={focal_length:.1f}, cx={cx:.1f}, cy={cy:.1f}")

        if render_origin_view:
            # 初始相机原点视角：相机位于 (0,0,0)，朝向轨迹起点
            cam_x, cam_y, cam_z = 0.0, 0.0, 0.0
            target_idx = -1
            depth = 0.0
            pixel_x, pixel_y = 0.0, 0.0
            print(f"   渲染位置：初始相机原点")
            print(f"   3D 坐标：(0.0, 0.0, 0.0) 米 (相机原始位置)")

            # 朝向：默认朝前（Z 轴正方向）
            z_axis = np.array([0.0, 0.0, 1.0])
            x_axis = np.array([1.0, 0.0, 0.0])
            y_axis = np.array([0.0, 1.0, 0.0])

            # 如果有轨迹，朝向第一个轨迹点
            if trajectory:
                first_pixel = trajectory[0]
                pixel_x, pixel_y = first_pixel
                # 从深度图获取起点深度
                start_depth = self.get_depth_from_depth_map(depth_map, first_pixel[0], first_pixel[1])
                if start_depth is not None:
                    depth = start_depth
                    start_3d_x = (first_pixel[0] - cx) * start_depth / fx
                    start_3d_y = (first_pixel[1] - cy) * start_depth / fy
                    start_3d_z = start_depth
                    direction = np.array([start_3d_x, start_3d_y, start_3d_z])
                    direction[1] = 0  # 忽略 Y 分量，保持水平
                    norm = np.linalg.norm(direction)
                    if norm > 1e-6:
                        direction = direction / norm
                        z_axis = direction
                        # 重新计算 X 轴（水平向右）
                        x_axis = np.cross([0, 1, 0], z_axis)
                        x_norm = np.linalg.norm(x_axis)
                        if x_norm > 1e-6:
                            x_axis = x_axis / x_norm
                        else:
                            x_axis = np.array([1, 0, 0])
                        # Y 轴 = Z × X
                        y_axis = np.cross(z_axis, x_axis)
                        y_axis = y_axis / np.linalg.norm(y_axis)
                        print(f"   朝向起点：({first_pixel[0]:.0f}, {first_pixel[1]:.0f}) @ {start_depth:.2f}m")
                        print(f"   水平朝向：({z_axis[0]:.3f}, {z_axis[1]:.3f}, {z_axis[2]:.3f})")
                    else:
                        direction = np.array([0.0, 0.0, 1.0])
                else:
                    print(f"   ⚠️ 起点深度无效，默认朝前")
                    direction = np.array([0.0, 0.0, 1.0])
            else:
                direction = np.array([0.0, 0.0, 1.0])
        else:
            # 获取目标轨迹点
            target_idx = view_index if view_index >= 0 else len(trajectory) + view_index
            target_idx = max(0, min(target_idx, len(trajectory) - 1))

            if target_idx < 0 or target_idx >= len(trajectory):
                print(f"⚠️ 轨迹点索引 {view_index} 超出范围，跳过渲染")
                return None

            target_pixel = trajectory[target_idx]
            pixel_x, pixel_y = target_pixel

            # 从深度图查询深度值（带有效性检查）
            depth = self.get_depth_from_depth_map(depth_map, pixel_x, pixel_y)
            if depth is None:
                print(f"❌ 无法获取轨迹点 #{target_idx} 的有效深度值，跳过渲染")
                return None

            print(f"   渲染位置：轨迹点 #{target_idx}")
            print(f"   像素坐标：({pixel_x:.1f}, {pixel_y:.1f})")
            print(f"   深度值：{depth:.3f} 米")

            # ============================================================
            # 计算轨迹点 3D 坐标
            # ============================================================
            cam_x = (pixel_x - cx) * depth / fx
            cam_y = (pixel_y - cy) * depth / fy
            cam_z = depth

            # 抬高相机位置（模拟人眼/机器人摄像头高度）
            cam_y -= camera_height_offset  # Y 轴向下为正，减去高度即向上移动

            current_point_3d = np.array([cam_x, cam_y, cam_z])
            print(f"   3D 坐标：({cam_x:.3f}, {cam_y:.3f}, {cam_z:.3f}) 米 (相机抬高 {camera_height_offset} 米)")

            # ============================================================
            # 计算前后点 3D 坐标（用于朝向计算）
            # ============================================================
            next_point_3d = None
            prev_point_3d = None

            if target_idx < len(trajectory) - 1:
                next_pixel = trajectory[target_idx + 1]
                next_depth = self.get_depth_from_depth_map(depth_map, next_pixel[0], next_pixel[1])
                if next_depth is not None:
                    next_x = (next_pixel[0] - cx) * next_depth / fx
                    next_y = (next_pixel[1] - cy) * next_depth / fy
                    next_z = next_depth
                    next_point_3d = np.array([next_x, next_y, next_z])
                else:
                    print(f"   ⚠️ 下一个点 #{target_idx+1} 深度无效，将使用孤立点朝向")

            if target_idx > 0:
                prev_pixel = trajectory[target_idx - 1]
                prev_depth = self.get_depth_from_depth_map(depth_map, prev_pixel[0], prev_pixel[1])
                if prev_depth is not None:
                    prev_x = (prev_pixel[0] - cx) * prev_depth / fx
                    prev_y = (prev_pixel[1] - cy) * prev_depth / fy
                    prev_z = prev_depth
                    prev_point_3d = np.array([prev_x, prev_y, prev_z])
                else:
                    print(f"   ⚠️ 上一个点 #{target_idx-1} 深度无效")

            # ============================================================
            # 计算朝向（简化的水平朝向）
            # ============================================================
            # 由于轨迹点在地板上，我们让相机保持水平朝向（不看地面）

            # 计算水平朝向方向（忽略 Y 分量，保持水平）
            if next_point_3d is not None:
                # 前进方向（忽略垂直分量）
                direction = next_point_3d - current_point_3d
                direction[1] = 0  # 忽略 Y 分量，保持水平
            elif prev_point_3d is not None:
                # 后视方向（忽略垂直分量）
                direction = prev_point_3d - current_point_3d
                direction[1] = 0  # 忽略 Y 分量，保持水平
            else:
                # 孤立点，默认朝前
                direction = np.array([0, 0, 1])

            # 归一化
            norm = np.linalg.norm(direction)
            if norm > 1e-6:
                direction = direction / norm

        # Z 轴 = 水平朝向方向
        z_axis = direction

        # X 轴 = 水平向右（与世界 Y 轴垂直）
        x_axis = np.cross([0, 1, 0], z_axis)
        x_norm = np.linalg.norm(x_axis)
        if x_norm > 1e-6:
            x_axis = x_axis / x_norm
        else:
            # Z 轴接近垂直方向，使用默认 X 轴
            x_axis = np.array([1, 0, 0])

        # Y 轴 = Z × X（右手定则）
        y_axis = np.cross(z_axis, x_axis)
        y_axis = y_axis / np.linalg.norm(y_axis)

        print(f"   水平朝向：({z_axis[0]:.3f}, {z_axis[1]:.3f}, {z_axis[2]:.3f})")

        # 应用 yaw 偏移
        if yaw_offset != 0:
            print(f"   应用 yaw 偏移：{yaw_offset}°")
            # 在水平面内旋转 Z 轴
            yaw_rad = np.radians(yaw_offset)
            cos_y, sin_y = np.cos(yaw_rad), np.sin(yaw_rad)

            # 旋转矩阵（绕 Y 轴旋转）
            # 注意：世界坐标系 Y 轴向下，旋转方向需要调整
            z_axis_rotated = np.array([
                z_axis[0] * cos_y + z_axis[2] * sin_y,
                z_axis[1],  # Y 分量不变
                -z_axis[0] * sin_y + z_axis[2] * cos_y
            ])
            z_axis = z_axis_rotated / np.linalg.norm(z_axis_rotated)

            # 重新计算 X 和 Y 轴
            x_axis = np.cross([0, 1, 0], z_axis)
            if np.linalg.norm(x_axis) > 1e-6:
                x_axis = x_axis / np.linalg.norm(x_axis)
            else:
                x_axis = np.array([1, 0, 0])
            y_axis = np.cross(z_axis, x_axis)
            y_axis = y_axis / np.linalg.norm(y_axis)

        print(f"\n   相机基向量:")
        print(f"      X: ({x_axis[0]:.3f}, {x_axis[1]:.3f}, {x_axis[2]:.3f})")
        print(f"      Y: ({y_axis[0]:.3f}, {y_axis[1]:.3f}, {y_axis[2]:.3f})")
        print(f"      Z: ({z_axis[0]:.3f}, {z_axis[1]:.3f}, {z_axis[2]:.3f})")

        # 构造旋转矩阵
        R = np.array([x_axis, y_axis, z_axis])

        # ============================================================
        # 渲染：点云变换 + 投影
        # ============================================================
        print(f"\n   开始渲染...")

        # 1. 重塑点云
        points = point_cloud.reshape(-1, 3).copy()

        # 2. 平移
        points[:, 0] -= cam_x
        points[:, 1] -= cam_y
        points[:, 2] -= cam_z

        # 3. 旋转
        points_camera = points @ R.T

        # 4. 投影
        valid_mask = points_camera[:, 2] > 0.01
        points_valid = points_camera[valid_mask]

        u = (points_valid[:, 0] * fx / points_valid[:, 2] + cx).astype(int)
        v = (points_valid[:, 1] * fy / points_valid[:, 2] + cy).astype(int)

        # 过滤在图像外的点
        in_image = (u >= 0) & (u < w_orig) & (v >= 0) & (v < h_orig)
        u = u[in_image]
        v = v[in_image]
        points_valid = points_valid[in_image]

        print(f"   有效点数：{np.sum(valid_mask)} / {len(points)} ({100*np.sum(valid_mask)/len(points):.1f}%)")
        print(f"   图像内点数：{len(u)} / {np.sum(valid_mask)} ({100*len(u)/np.sum(valid_mask):.1f}%)")

        # 5. 获取颜色
        original_indices = np.where(valid_mask)[0]
        original_indices = original_indices[in_image]

        u_orig = original_indices % w_pc
        v_orig = original_indices // w_pc

        image_rgb = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        point_colors = image_rgb[v_orig, u_orig]

        # 6. 渲染（Z-buffer）
        rendered_image = np.zeros((h_orig, w_orig, 3), dtype=np.float32)
        depth_rendered = np.zeros((h_orig, w_orig), dtype=np.float32)

        depths = points_valid[:, 2]
        sort_indices = np.argsort(depths)[::-1]

        draw_count = 0
        for idx in sort_indices:
            ui, vi = u[idx], v[idx]
            depth_val = depths[idx]
            color = point_colors[idx]

            if depth_rendered[vi, ui] == 0 or depth_val < depth_rendered[vi, ui]:
                rendered_image[vi, ui] = color
                depth_rendered[vi, ui] = depth_val
                draw_count += 1

        print(f"   绘制像素数：{draw_count} / {w_orig * h_orig} ({100*draw_count/(w_orig*h_orig):.2f}%)")
        print(f"   空洞率：{100*(1 - draw_count/(w_orig*h_orig)):.1f}%")

        # 7. 颜色增强
        gamma = 0.55
        rendered_image = np.power(rendered_image, 1/gamma)
        rendered_image = rendered_image * 1.2
        rendered_image = np.clip(rendered_image, 0, 1)

        print(f"   颜色增强：gamma={gamma}, 对比度=1.2x")

        # 8. 保存结果
        if image_path:
            base_name = os.path.splitext(os.path.basename(image_path))[0]
        else:
            base_name = "rendered_view"
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        offset_str = f"_yaw{int(yaw_offset)}" if yaw_offset != 0 else ""

        view_label = "origin" if render_origin_view else f"view{target_idx}"

        output_rendered = os.path.join(
            self.output_dir or os.path.dirname(original_image),
            f"{base_name}_{view_label}_rendered_{timestamp}.png"
        )

        # 保存渲染图像
        rendered_bgr = (rendered_image * 255).astype(np.uint8)
        rendered_bgr = cv2.cvtColor(rendered_bgr, cv2.COLOR_RGB2BGR)
        cv2.imwrite(output_rendered, rendered_bgr)
        print(f"   ✅ 渲染图像：{output_rendered}")

        return {
            "rendered_image": output_rendered,
            "view_index": target_idx if not render_origin_view else -1,
            "is_origin_view": render_origin_view,
            "pixel_coords": [pixel_x, pixel_y] if not render_origin_view else [0, 0],
            "depth": depth if not render_origin_view else 0.0
        }

    def _render_single_view(
        self,
        point_cloud: np.ndarray,
        original_image: np.ndarray,
        cam_x: float,
        cam_y: float,
        cam_z: float,
        x_axis: np.ndarray,
        y_axis: np.ndarray,
        z_axis: np.ndarray,
        fx: float,
        fy: float,
        cx: float,
        cy: float,
        output_path: str,
        image_path: Optional[str] = None,
        fov_x: float = 60.0
    ) -> Optional[str]:
        """
        从指定的 3D 相机位置和朝向渲染视角

        Args:
            point_cloud: 点云 [H, W, 3]
            original_image: 原始 RGB 图像 [H, W, 3]
            cam_x, cam_y, cam_z: 相机 3D 位置
            x_axis, y_axis, z_axis: 相机基向量
            fx, fy, cx, cy: 相机内参
            output_path: 输出图像路径
            image_path: 原始图像路径（用于生成文件名）
            fov_x: 水平视场角（度）

        Returns:
            输出图像路径，失败返回 None
        """
        # 获取图像尺寸
        h_orig, w_orig = original_image.shape[:2]
        h_pc, w_pc = point_cloud.shape[:2]

        # 构造旋转矩阵
        R = np.array([x_axis, y_axis, z_axis])

        # 1. 重塑点云
        points = point_cloud.reshape(-1, 3).copy()

        # 2. 平移
        points[:, 0] -= cam_x
        points[:, 1] -= cam_y
        points[:, 2] -= cam_z

        # 3. 旋转
        points_camera = points @ R.T

        # 4. 投影
        valid_mask = points_camera[:, 2] > 0.01
        points_valid = points_camera[valid_mask]

        u = (points_valid[:, 0] * fx / points_valid[:, 2] + cx).astype(int)
        v = (points_valid[:, 1] * fy / points_valid[:, 2] + cy).astype(int)

        # 过滤在图像外的点
        in_image = (u >= 0) & (u < w_orig) & (v >= 0) & (v < h_orig)
        u = u[in_image]
        v = v[in_image]
        points_valid = points_valid[in_image]

        # 5. 获取颜色
        original_indices = np.where(valid_mask)[0]
        original_indices = original_indices[in_image]

        u_orig = original_indices % w_pc
        v_orig = original_indices // w_pc

        image_rgb = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        point_colors = image_rgb[v_orig, u_orig]

        # 6. 渲染（Z-buffer）
        rendered_image = np.zeros((h_orig, w_orig, 3), dtype=np.float32)
        depth_rendered = np.zeros((h_orig, w_orig), dtype=np.float32)

        depths = points_valid[:, 2]
        sort_indices = np.argsort(depths)[::-1]

        draw_count = 0
        for idx in sort_indices:
            ui, vi = u[idx], v[idx]
            depth_val = depths[idx]
            color = point_colors[idx]

            if depth_rendered[vi, ui] == 0 or depth_val < depth_rendered[vi, ui]:
                rendered_image[vi, ui] = color
                depth_rendered[vi, ui] = depth_val
                draw_count += 1

        # 7. 颜色增强
        gamma = 0.55
        rendered_image = np.power(rendered_image, 1/gamma)
        rendered_image = rendered_image * 1.2
        rendered_image = np.clip(rendered_image, 0, 1)

        # 8. 保存结果
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.', exist_ok=True)

        rendered_bgr = (rendered_image * 255).astype(np.uint8)
        rendered_bgr = cv2.cvtColor(rendered_bgr, cv2.COLOR_RGB2BGR)
        cv2.imwrite(output_path, rendered_bgr)

        return output_path

    def render_all_elevated_trajectory_points(
        self,
        point_cloud: np.ndarray,
        original_image: np.ndarray,
        depth_map: np.ndarray,
        trajectory: List[List[float]],
        intrinsics: Optional[np.ndarray] = None,
        image_path: Optional[str] = None,
        camera_height_offset: Optional[float] = None,  # None=自动从地板平面计算
        save_pointcloud: bool = True,
        save_camera_origin: bool = True,
        floor_mask: Optional[np.ndarray] = None,  # 地板掩码
        camera_approach_spacing: float = 0.017,  # 相机到轨迹起点的插值间距（米）
        smooth_window: int = 10,  # 轨迹交接处平滑窗口大小
        random_seed: int = 42,  # 随机种子，确保确定性渲染
        pitch_down_degrees: float = 0.0  # 相机向下俯仰角度（度），默认 0 度（水平朝向）
    ) -> Dict[str, any]:
        """
        渲染并保存所有抬高后的轨迹点为点云文件

        遍历所有轨迹点，计算抬高后的 3D 坐标，并保存为 PLY 文件。
        颜色编码：起点绿色，终点红色，中间点使用图像颜色或黄色。

        Args:
            point_cloud: 点云 [H, W, 3]
            original_image: 原始 RGB 图像 [H, W, 3]
            depth_map: 深度图 [H, W]
            trajectory: 轨迹点列表 [[pixel_x, pixel_y], ...]
            intrinsics: 相机内参 [3, 3]（可选）
            image_path: 原始图像路径（用于生成输出文件名，可选）
            camera_height_offset: 相机高度偏移（米），None=自动从地板平面计算相机实际离地高度
            save_pointcloud: 是否保存为 PLY 文件
            save_camera_origin: 是否保存相机初始位置点云（地面高度 + 抬高高度）
            floor_mask: 地板掩码 [H, W]（布尔数组，用于计算地面高度）
            camera_approach_spacing: 相机地面投影到轨迹起点的插值间距（米），默认 0.017 米
            smooth_window: 轨迹交接处平滑窗口大小（只使用前方 N 个点计算平均方向），默认 10
            random_seed: 随机种子，确保RANSAC平面拟合的确定性，默认 42

        Returns:
            包含轨迹点云数据和保存路径的字典
        """
        import matplotlib
        matplotlib.use('Agg')

        # 初始化确定性随机数生成器
        rng = np.random.default_rng(random_seed)

        print("\n" + "=" * 70)
        print("📍 保存抬高后的轨迹点点云")
        print("=" * 70)
        
        if camera_height_offset is None:
            print(f"   📏 相机高度未指定，将在地板平面拟合后自动计算实际离地高度")
        else:
            print(f"   📏 使用手动指定的相机高度：{camera_height_offset:.3f} 米")

        # 获取图像尺寸
        h_orig, w_orig = original_image.shape[:2]
        h_pc, w_pc = point_cloud.shape[:2]

        print(f"   原始图像：{w_orig}x{h_orig}")
        print(f"   轨迹点数：{len(trajectory)}")
        print(f"   相机抬高高度：{camera_height_offset} 米")

        # 相机内参
        if intrinsics is not None:
            fx = intrinsics[0, 0] * w_orig
            fy = intrinsics[1, 1] * h_orig
            cx = intrinsics[0, 2] * w_orig
            cy = intrinsics[1, 2] * h_orig
            print(f"   相机内参：fx={fx:.1f}, fy={fy:.1f}, cx={cx:.1f}, cy={cy:.1f}")
        else:
            # 默认 FOV=60°
            focal_length = w_orig / (2 * np.tan(np.deg2rad(60) / 2))
            fx = fy = focal_length
            cx, cy = w_orig / 2, h_orig / 2
            print(f"   相机内参（默认 FOV=60°）：fx=fy={focal_length:.1f}, cx={cx:.1f}, cy={cy:.1f}")

        # ========== 先计算地板法向量（用于后续的轨迹点抬高和相机位置计算）==========
        # 只运行一次RANSAC，确保结果一致性
        floor_plane_params = None
        floor_normal = np.array([0.0, 1.0, 0.0], dtype=np.float32)  # 默认法向量朝下

        if floor_mask is not None and point_cloud is not None:
            if floor_mask.sum() > 100:  # 至少需要 100 个点才能拟合平面
                # 从 floor_mask 中提取地板点云的 3D 坐标
                floor_points_3d = point_cloud[floor_mask]

                # 采样以提高性能（最多 5000 个点）
                max_samples = min(5000, len(floor_points_3d))
                if len(floor_points_3d) > max_samples:
                    sample_indices = rng.choice(len(floor_points_3d), max_samples, replace=False)
                    floor_points_3d_sampled = floor_points_3d[sample_indices]
                else:
                    floor_points_3d_sampled = floor_points_3d

                # 使用RANSAC拟合地板平面（确定性，使用rng）
                ransac_result = ransac_fit_floor_plane(floor_points_3d_sampled, rng)
                
                if ransac_result is not None:
                    a, b, c, d, floor_normal, n_inliers, residual = ransac_result
                    floor_plane_params = (a, b, c, d)
                    
                    print(f"   📐 地板法向量（RANSAC 拟合）：n = ({a:.4f}, {b:.4f}, {c:.4f})")
                    print(f"      使用 {n_inliers} 个内点拟合平面（残差：{residual:.4f}m）")
                else:
                    print(f"   ⚠️ RANSAC 平面拟合失败，使用默认法向量 [0, 1, 0]")
            else:
                print(f"   ⚠️ floor_mask 点数不足，使用默认法向量 [0, 1, 0]")
        else:
            print(f"   ⚠️ 未提供 floor_mask，使用默认法向量 [0, 1, 0]")

        print(f"   🎯 轨迹点抬高方向：沿法向量 n = ({floor_normal[0]:.4f}, {floor_normal[1]:.4f}, {floor_normal[2]:.4f})")

        # ========== 自动计算相机实际离地高度（如果未指定）==========
        if camera_height_offset is None and floor_plane_params is not None:
            a, b, c, d = floor_plane_params
            # 相机原点 (0,0,0) 到平面 ax+by+cz+d=0 的垂直距离
            camera_height_offset = abs(d) / np.sqrt(a*a + b*b + c*c)
            print(f"   📏 自动计算的相机离地高度：{camera_height_offset:.3f} 米")
        elif camera_height_offset is None:
            # 退化：如果没有地板平面，使用默认值
            camera_height_offset = 0.06
            print(f"   ⚠️ 无法自动计算高度，使用默认值：{camera_height_offset:.3f} 米")
        else:
            print(f"   📏 使用手动指定的抬高高度：{camera_height_offset:.3f} 米")

        # ========== 步骤 1: 收集所有"原始轨迹点" 3D 坐标（从深度图反投影，暂不抬高）==========
        # 注："原始轨迹点" = 经过 VLM 自反思 + 后处理 + 地板过滤 + 3D 重采样后的轨迹点
        # 这些点已按物理间距重采样，但高度来自深度图反投影，不一定精确在地板平面上
        original_trajectory_3d = []
        trajectory_colors = []

        for i, target_pixel in enumerate(trajectory):
            pixel_x, pixel_y = target_pixel

            depth = self.get_depth_from_depth_map(depth_map, pixel_x, pixel_y)
            if depth is None:
                print(f"   ⚠️ 轨迹点 #{i} [{pixel_x:.1f}, {pixel_y:.1f}] 深度无效，跳过")
                continue

            cam_x = (pixel_x - cx) * depth / fx
            cam_y = (pixel_y - cy) * depth / fy
            cam_z = depth

            point_3d = np.array([cam_x, cam_y, cam_z], dtype=np.float32)
            original_trajectory_3d.append(point_3d)

            if i == 0:
                trajectory_colors.append([0, 255, 0])  # 绿色
                print(f"   🟢 起点 #{i}: ({cam_x:.3f}, {cam_y:.3f}, {cam_z:.3f}) @ {depth:.3f}m")
            elif i == len(trajectory) - 1:
                trajectory_colors.append([255, 0, 0])  # 红色
                print(f"   🔴 终点 #{i}: ({cam_x:.3f}, {cam_y:.3f}, {cam_z:.3f}) @ {depth:.3f}m")
            else:
                px_int = int(round(pixel_x))
                py_int = int(round(pixel_y))
                px_int = max(0, min(px_int, w_orig - 1))
                py_int = max(0, min(py_int, h_orig - 1))
                color_bgr = original_image[py_int, px_int]
                trajectory_colors.append([color_bgr[2], color_bgr[1], color_bgr[0]])

        if len(original_trajectory_3d) == 0:
            print("   ❌ 没有有效的轨迹点，跳过保存")
            return {"success": False, "error": "没有有效的轨迹点"}

        print(f"\n   ✅ 有效原始轨迹点数：{len(original_trajectory_3d)} / {len(trajectory)}")

        # ========== 步骤 2: 生成相机到轨迹起点的插值点（在地板平面上）==========
        camera_real_3d = np.array([0.0, 0.0, 0.0], dtype=np.float32)
        a_fp, b_fp, c_fp, d_fp = floor_plane_params if floor_plane_params is not None else (0.0, 1.0, 0.0, 0.0)
        denom_fp = a_fp*a_fp + b_fp*b_fp + c_fp*c_fp

        t_camera = -d_fp / denom_fp
        camera_on_ground = camera_real_3d + t_camera * floor_normal

        start_3d = original_trajectory_3d[0]
        t_start = -(a_fp * start_3d[0] + b_fp * start_3d[1] + c_fp * start_3d[2] + d_fp) / denom_fp
        start_on_ground = start_3d + t_start * floor_normal

        print(f"\n   📍 相机真实位置：({camera_real_3d[0]:.3f}, {camera_real_3d[1]:.3f}, {camera_real_3d[2]:.3f})")
        print(f"   🌍 相机地面投影：({camera_on_ground[0]:.3f}, {camera_on_ground[1]:.3f}, {camera_on_ground[2]:.3f})")
        print(f"   📍 轨迹起点 3D：({start_3d[0]:.3f}, {start_3d[1]:.3f}, {start_3d[2]:.3f})")
        print(f"   🌍 轨迹起点地面投影：({start_on_ground[0]:.3f}, {start_on_ground[1]:.3f}, {start_on_ground[2]:.3f})")

        approach_points_3d = []
        distance = np.linalg.norm(start_on_ground - camera_on_ground)
        if distance > camera_approach_spacing:
            n_points = int(distance / camera_approach_spacing) + 1
            print(f"   📐 插值间距：{camera_approach_spacing:.3f}m, 生成 {n_points} 个插值点")
            for i in range(n_points):
                t = i / (n_points - 1) if n_points > 1 else 0
                approach_points_3d.append(camera_on_ground + t * (start_on_ground - camera_on_ground))
        else:
            print(f"   ℹ️  距离过近（{distance:.3f}m），跳过插值")

        # ========== 步骤 3: 合并所有点（相机位置 + 插值点 + 原始轨迹点）==========
        all_points_3d = []
        all_point_labels = []
        all_point_colors = []

        all_points_3d.append(camera_real_3d.copy())
        all_point_labels.append("相机真实位置")
        all_point_colors.append([255, 255, 0])  # 黄色

        for i, pt in enumerate(approach_points_3d):
            all_points_3d.append(pt.copy())
            all_point_labels.append(f"插值点 {i+1}")
            all_point_colors.append([255, 128, 0])  # 橙色

        if len(original_trajectory_3d) > 1:
            for i, pt in enumerate(original_trajectory_3d[1:], start=1):
                    all_points_3d.append(pt.copy())
                    all_point_labels.append(f"轨迹点 {i+1}")
                    all_point_colors.append(trajectory_colors[i])
        else:
            all_points_3d.append(original_trajectory_3d[0].copy())
            all_point_labels.append("轨迹点 1")
            all_point_colors.append(trajectory_colors[0])

        print(f"\n   📋 合并后总计：{len(all_points_3d)} 个点（投影前）")

        # ========== 步骤 4: 统一将所有点投影到地板平面 ==========
        print(f"\n   📐 步骤 4: 统一将所有点投影到地板平面")

        projected_points_3d = []
        for i, pt in enumerate(all_points_3d):
            t = -(a_fp * pt[0] + b_fp * pt[1] + c_fp * pt[2] + d_fp) / denom_fp
            projected = pt + t * floor_normal
            projected_points_3d.append(projected)
            if i < 3 or i >= len(all_points_3d) - 2:
                dist = abs(a_fp*pt[0] + b_fp*pt[1] + c_fp*pt[2] + d_fp) / np.sqrt(denom_fp)
                print(f"      {all_point_labels[i]}: 距平面 {dist:.4f}m → 投影")
            elif i == 3:
                print(f"      ... ({len(all_points_3d) - 6} 个中间点省略)")

        projected_points_3d = np.array(projected_points_3d, dtype=np.float32)

        # ========== 步骤 5: 统一沿地板法向量抬高所有点 ==========
        print(f"\n   📐 步骤 5: 统一沿地板法向量抬高所有点 ({camera_height_offset}m)")

        elevated_points_3d = projected_points_3d + floor_normal * camera_height_offset
        elevated_colors = np.array(all_point_colors, dtype=np.uint8)

        print(f"   ✅ 抬高完成：{len(elevated_points_3d)} 个点")
        print(f"      X 范围：[{elevated_points_3d[:, 0].min():.3f}, {elevated_points_3d[:, 0].max():.3f}] m")
        print(f"      Y 范围：[{elevated_points_3d[:, 1].min():.3f}, {elevated_points_3d[:, 1].max():.3f}] m")
        print(f"      Z 范围：[{elevated_points_3d[:, 2].min():.3f}, {elevated_points_3d[:, 2].max():.3f}] m")

        # ========== 为下游代码提取组件 ==========
        # elevated_points_3d 结构：[相机(1个), 插值点(n个), 原始轨迹点(已跳过第一个)(m个)]
        camera_elevated = elevated_points_3d[0:1]  # 相机抬高位置

        n_approach_computed = len(approach_points_3d)
        if n_approach_computed > 0:
            elevation_points = elevated_points_3d[1:1+n_approach_computed]
        else:
            elevation_points = None

        # 原始轨迹抬高（已跳过第一个点）
        original_trajectory_elevated = elevated_points_3d[1 + n_approach_computed:]

        # 标记：已完成统一投影和抬高，跳过旧的重插值逻辑
        _unified_elevation_done = True

        # 保存为 PLY 文件
        result = {"success": True, "num_points": len(elevated_points_3d), "camera_height_offset": camera_height_offset}

        if save_pointcloud:
            if image_path:
                    base_name = os.path.splitext(os.path.basename(image_path))[0]
            else:
                base_name = "trajectory"

            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_dir_to_use = self.output_dir or "."
            os.makedirs(output_dir_to_use, exist_ok=True)

            output_ply_path = os.path.join(
                output_dir_to_use,
                f"{base_name}_elevated_trajectory_h{camera_height_offset:.2f}m_{timestamp}.ply"
            )

            saved_path = save_trajectory_pointcloud(
                elevated_points_3d,
                elevated_colors,
                output_ply_path,
                point_type=f"抬高轨迹 (h={camera_height_offset:.2f}m)"
            )

            result["ply_path"] = os.path.basename(saved_path) if saved_path else None
            result["saved"] = True

        # ========== 保存相机初始位置点云 ==========
        if save_camera_origin and len(trajectory) > 0:
            print("\n" + "-" * 70)
            print("📷 保存相机初始位置点云")
            print("-" * 70)

            # 相机真实位置（场景点云中的位置）：(0, 0, 0)
            camera_real_x, camera_real_y, camera_real_z = 0.0, 0.0, 0.0

            # 计算地面投影：复用前面计算的地板平面参数（不再运行第二次RANSAC）
            floor_y_avg = None
            # floor_plane_params 已经在前面计算过，直接复用

            if floor_plane_params is not None:
                # 使用已计算的地板平面参数
                a, b, c, d = floor_plane_params
                
                # 计算相机位置 (0, 0, 0) 到平面的垂足
                denom = a*a + b*b + c*c
                t = -d / denom

                floor_proj_x = t * a
                floor_proj_y = t * b
                floor_proj_z = t * c

                floor_y_avg = floor_proj_y
                camera_real_x, camera_real_y, camera_real_z = 0.0, 0.0, 0.0

                print(f"   📍 相机真实位置：({camera_real_x:.3f}, {camera_real_y:.3f}, {camera_real_z:.3f})")
                print(f"   🌍 地板平面（复用前面拟合）：{a:.4f}x + {b:.4f}y + {c:.4f}z + {d:.4f} = 0")
                print(f"   📐 地板法向量：n = ({a:.4f}, {b:.4f}, {c:.4f})")
                print(f"   🎯 相机投影到地面：({floor_proj_x:.3f}, {floor_proj_y:.3f}, {floor_proj_z:.3f})")
            else:
                # 退化：如果没有地板平面参数，使用默认值
                if floor_mask is None:
                    print(f"   ⚠️ 未提供 floor_mask，使用相机 Y 坐标")
                if depth_map is None:
                    print(f"   ⚠️ 深度图不可用，使用相机 Y 坐标")
                if point_cloud is None:
                    print(f"   ⚠️ 点云不可用，使用相机 Y 坐标")
                floor_y_avg = camera_real_y
                floor_plane_params = (0, 1, 0, -camera_real_y)

            # 相机初始位置（相机真实位置）
            camera_real = np.array([[camera_real_x, camera_real_y, camera_real_z]], dtype=np.float32)
            camera_real_color = np.array([[255, 255, 0]], dtype=np.uint8)  # 黄色

            # 相机初始位置（投影到地面）
            # 使用平面拟合计算的投影点（如果可用），否则使用简化方法
            if floor_plane_params is not None and floor_y_avg is not None:
                # 重新计算投影点（使用上面的结果）
                a, b, c, d = floor_plane_params
                denom = a*a + b*b + c*c
                t = -d / denom
                camera_on_ground = np.array([[t * a, t * b, t * c]], dtype=np.float32)
            else:
                # 退化情况：使用简化方法 (0, floor_y_avg, 0)
                camera_on_ground = np.array([[camera_real_x, floor_y_avg if floor_y_avg is not None else camera_real_y, camera_real_z]], dtype=np.float32)

            camera_on_ground_color = np.array([[0, 255, 255]], dtype=np.uint8)  # 青色

            # 相机初始位置（抬高高度）- 从地面投影点向上抬高
            # 注意：沿 Y 轴负方向抬高（相机坐标系 Y 向下为正）
            camera_elevated = np.array([[camera_on_ground[0, 0], camera_on_ground[0, 1] - camera_height_offset, camera_on_ground[0, 2]]], dtype=np.float32)
            camera_elevated_color = np.array([[255, 128, 0]], dtype=np.uint8)  # 橙色

            # 相机地面投影：从原点沿法向量投影到平面（用于插值计算）
            a_interp, b_interp, c_interp, d_interp = floor_plane_params if floor_plane_params is not None else (0.0, 1.0, 0.0, 0.0)
            t_interp = -d_interp / (a_interp*a_interp + b_interp*b_interp + c_interp*c_interp)
            camera_on_ground_interp = np.array([[t_interp * a_interp, t_interp * b_interp, t_interp * c_interp]], dtype=np.float32)

            # 相机抬高位置：从地面投影点沿法向量抬高
            camera_elevated_interp = camera_on_ground_interp + floor_normal * camera_height_offset

            if image_path:
                base_name = os.path.splitext(os.path.basename(image_path))[0]
            else:
                base_name = "trajectory"

            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_dir_to_use = self.output_dir or "."
            os.makedirs(output_dir_to_use, exist_ok=True)

        # ========== 计算相机初始位置（用于插值，无论 save_camera_origin 是否启用）==========
        # 如果已完成统一投影和抬高，则跳过旧的重插值逻辑
        if not locals().get('_unified_elevation_done', False) and len(trajectory) > 0 and floor_plane_params is not None:
            # 确保 output_dir_to_use 已定义（如果 save_camera_origin=False，前面的块不会定义它）
            if 'output_dir_to_use' not in locals():
                output_dir_to_use = self.output_dir or "."
                os.makedirs(output_dir_to_use, exist_ok=True)
                if image_path:
                    base_name = os.path.splitext(os.path.basename(image_path))[0]
                else:
                    base_name = "trajectory"
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

            # 相机真实位置：(0, 0, 0)
            camera_real_x, camera_real_y, camera_real_z = 0.0, 0.0, 0.0

            # 相机地面投影：从原点沿法向量投影到平面
            a, b, c, d = floor_plane_params if floor_plane_params is not None else (0.0, 1.0, 0.0, 0.0)
            t = -d / (a*a + b*b + c*c)
            camera_on_ground = np.array([[t * a, t * b, t * c]], dtype=np.float32)

            # 相机抬高位置：从地面投影点沿法向量抬高
            camera_elevated = camera_on_ground + floor_normal * camera_height_offset

            # ========== 相机地面投影到轨迹起点的地面投影的插值 ==========
            print(f"\n🔍 插值调试信息:")
            print(f"   len(trajectory): {len(trajectory)}")
            print(f"   camera_on_ground is not None: {camera_on_ground is not None}")
            print(f"   floor_plane_params is not None: {floor_plane_params is not None}")

            if len(trajectory) >= 1 and camera_on_ground is not None and floor_plane_params is not None:
                # 获取轨迹起点的 3D 坐标
                start_pixel = trajectory[0]
                start_px, start_py = start_pixel[0], start_pixel[1]

                # 从 point_cloud 中获取起点的 3D 坐标
                h_pc, w_pc = point_cloud.shape[:2]
                start_px_int = int(round(start_px * w_pc / w_orig))
                start_py_int = int(round(start_py * h_pc / h_orig))

                if 0 <= start_px_int < w_pc and 0 <= start_py_int < h_pc:
                    start_3d = point_cloud[start_py_int, start_px_int]

                    if np.all(np.isfinite(start_3d)):
                        # 计算轨迹起点的地面投影（使用地板平面方程）
                        a, b, c, d = floor_plane_params
                        # 从轨迹起点沿法向量方向投影到平面
                        # 公式：P_projected = P_start - (a*x + b*y + c*z + d) / (a²+b²+c²) * (a, b, c)
                        denom = a*a + b*b + c*c
                        t_start = -(a * start_3d[0] + b * start_3d[1] + c * start_3d[2] + d) / denom
                        start_on_ground = np.array([
                            start_3d[0] + t_start * a,
                            start_3d[1] + t_start * b,
                            start_3d[2] + t_start * c
                        ], dtype=np.float32)

                        # 相机地面投影点
                        cam_ground = camera_on_ground[0]  # (Xₚ, Yₚ, Zₚ)

                        # 计算距离（从相机地面投影到轨迹起点的地面投影）
                        distance = np.linalg.norm(start_on_ground - cam_ground)
                        print(f"\n   📏 相机地面投影到轨迹起点的地面投影距离：{distance:.3f}m")
                        print(f"      相机地面投影：({cam_ground[0]:.3f}, {cam_ground[1]:.3f}, {cam_ground[2]:.3f})")
                        print(f"      轨迹起点 3D：({start_3d[0]:.3f}, {start_3d[1]:.3f}, {start_3d[2]:.3f})")
                        print(f"      轨迹起点地面投影：({start_on_ground[0]:.3f}, {start_on_ground[1]:.3f}, {start_on_ground[2]:.3f})")

                        if distance > camera_approach_spacing:
                            # 计算插值点数
                            n_points = int(distance / camera_approach_spacing) + 1
                            print(f"   📐 插值间距：{camera_approach_spacing:.3f}m")
                            print(f"   📍 生成 {n_points} 个插值点")

                            # 线性插值（从相机地面投影到轨迹起点的地面投影）
                            interpolation_points = []
                            for i in range(n_points):
                                t = i / (n_points - 1) if n_points > 1 else 0
                                point = cam_ground + t * (start_on_ground - cam_ground)
                                interpolation_points.append(point)

                            interpolation_points = np.array(interpolation_points, dtype=np.float32)

                            # ========== 抬高插值点（与抬高轨迹点保持一致）==========
                            elevation_points = []

                            for point in interpolation_points:
                                # ✅ 沿地板法向量方向抬高（垂直于地面向上）
                                point_3d_elevated = point + floor_normal * camera_height_offset
                                elevation_points.append(point_3d_elevated)

                            elevation_points = np.array(elevation_points, dtype=np.float32)

                            print(f"   📍 生成 {n_points} 个插值点（仅用于构建统一轨迹，不单独保存）")
                        else:
                            print(f"   ℹ️  距离过近（{distance:.3f}m < {camera_approach_spacing:.3f}m），跳过插值")
                    else:
                        print(f"   ⚠️ 轨迹起点 3D 坐标无效，跳过插值")
                else:
                    print(f"   ⚠️ 轨迹起点像素坐标越界，跳过插值")

            print(f"\n   ✅ 原始轨迹抬高计算完成：{len(elevated_points_3d)} 个点")

        # ========== 统一轨迹重新编号和渲染 ==========
        # 无论使用统一投影抬高还是旧插值逻辑，都会执行此渲染
        if len(trajectory) > 0 and floor_plane_params is not None:
            print("\n" + "=" * 70)
            print("🔢 统一轨迹重新编号和渲染")
            print("=" * 70)

            # 构建完整的统一轨迹：
            # 1. 相机抬高位置（起点）
            # 2. 抬高插值点
            # 3. 原始抬高轨迹点（跳过第一个点，避免重复）

            # 相机抬高位置（3D 坐标）
            camera_elevated_3d = camera_elevated[0]  # (Xₚ, Yₚ-h, Zₚ)

            # 抬高插值点（3D 坐标）
            elevated_approach_points = None
            # 使用之前计算的 elevation_points（在插值逻辑中计算）
            if 'elevation_points' in locals() and elevation_points is not None:
                elevated_approach_points = elevation_points
                print(f"\n   📍 使用抬高插值点：{len(elevated_approach_points)} 个")
            else:
                print(f"\n   ℹ️  无插值点，仅渲染相机位置和原始轨迹")

            # 原始轨迹点的抬高版本
            if locals().get('_unified_elevation_done', False):
                # 使用统一投影和抬高时已计算好的值
                print(f"\n   ✅ 使用统一投影和抬高的轨迹点（{len(original_trajectory_elevated)} 个，已跳过第一个点）")
            elif len(elevated_points_3d) > 1:
                # 旧逻辑：从 elevated_points_3d 跳过第一个点
                original_trajectory_elevated = elevated_points_3d[1:]
            else:
                original_trajectory_elevated = elevated_points_3d

            # 构建完整的统一轨迹
            unified_trajectory = []
            trajectory_labels = []

            # 1. 相机抬高位置（起点）
            unified_trajectory.append(camera_elevated_3d)
            trajectory_labels.append("相机抬高位置")

            # 2. 抬高插值点
            if elevated_approach_points is not None and len(elevated_approach_points) > 0:
                for i, pt in enumerate(elevated_approach_points):
                    unified_trajectory.append(pt)
                    trajectory_labels.append(f"插值点 {i+1}")

            # 3. 原始抬高轨迹点（从索引 2 开始标记，因为跳过了第一个点）
            for i, pt in enumerate(original_trajectory_elevated):
                unified_trajectory.append(pt)
                trajectory_labels.append(f"轨迹点 {i+2}")  # +2 因为跳过了点 1

            unified_trajectory = np.array(unified_trajectory, dtype=np.float32)

            print(f"\n   📋 统一轨迹构成：")
            print(f"      1. 相机抬高位置（起点）")
            if elevated_approach_points is not None:
                print(f"      2. 抬高插值点：{len(elevated_approach_points)} 个")
            print(f"      3. 原始抬高轨迹点（跳过第一个）：{len(original_trajectory_elevated)} 个")
            print(f"      总计：{len(unified_trajectory)} 个轨迹点")
            print(f"")
            print(f"   💡 跳过了原始轨迹的第一个点，插值点直接连接到第二个点")
            print(f"      这样渲染出的轨迹画面变化更平滑")
            print(f"")
            print(f"   ✅ 复用了前面计算的 elevated_points_3d（已抬高），避免重复计算")

            # 保存统一轨迹点云
            if save_pointcloud and len(unified_trajectory) > 0:
                # 生成颜色：起点橙色 → 中间橙色 → 终点红橙渐变
                unified_colors = []

                n_camera = 1
                n_approach = len(elevated_approach_points) if elevated_approach_points is not None else 0
                n_original = len(original_trajectory_elevated)

                # 相机位置：橙色
                unified_colors.append([255, 128, 0])

                # 插值点：橙色
                if n_approach > 0:
                    for _ in range(n_approach):
                        unified_colors.append([255, 128, 0])

                # 原始轨迹：从橙色渐变到红色
                if n_original > 0:
                    orange = np.array([255, 128, 0], dtype=np.uint8)
                    red = np.array([255, 0, 0], dtype=np.uint8)
                    for i in range(n_original):
                        t = i / (n_original - 1) if n_original > 1 else 0
                        color = (orange * (1 - t) + red * t).astype(np.uint8)
                        unified_colors.append(color.tolist())

                unified_colors = np.array(unified_colors, dtype=np.uint8)

            unified_path = os.path.join(
                output_dir_to_use,
                f"{base_name}_unified_elevated_trajectory_h{camera_height_offset:.2f}m_{timestamp}.ply"
            )
            saved_unified_path = save_trajectory_pointcloud(
                unified_trajectory,
                unified_colors,
                unified_path,
                point_type=f"统一抬高轨迹 (n={len(unified_trajectory)})"
            )
            result["unified_elevated_trajectory_ply"] = os.path.basename(saved_unified_path) if saved_unified_path else None

            print(f"\n   ✅ 统一抬高轨迹点云已保存：{os.path.basename(saved_unified_path)}")

            # 渲染每个轨迹点的视角（使用 3D 坐标）
            # 跳过索引 0（相机抬高位置），只渲染插值点和原始轨迹点
            print(f"\n   📸 渲染轨迹点视角（跳过相机抬高位置，从索引 1 开始）...")
            print(f"   ℹ️  使用每个轨迹点的 3D 坐标（包括插值点和原始轨迹）")

            # 计算 FOV（用于 _render_single_view）
            fov_x = 2 * np.arctan(w_orig / (2 * fx)) * 180 / np.pi

            rendered_files = []
            # 从索引 1 开始渲染（跳过相机抬高位置）

            # 计算插值点数量（用于判断交接处位置）
            n_approach_points = len(elevated_approach_points) if elevated_approach_points is not None else 0
            junction_idx = 1 + n_approach_points  # 交接处的索引（插值点最后一个点的下一个点）

            print(f"   🔧 交接处索引：{junction_idx}，平滑窗口：{smooth_window}（只使用前方 {smooth_window} 个点）")

            for idx in range(1, len(unified_trajectory)):
                point_3d = unified_trajectory[idx]
                cam_x, cam_y, cam_z = point_3d[0], point_3d[1], point_3d[2]

                # ========== 计算朝向（使用平滑平均方向 + 向下俯仰）==========
                # 判断是否在交接处附近（使用 smooth_window 参数）
                dist_to_junction = abs(idx - junction_idx)
                use_smooth = dist_to_junction <= smooth_window

                # 先计算水平方向（XZ 平面）
                if use_smooth and idx < len(unified_trajectory) - 1:
                    # 交接处附近：只使用前方多个点计算平均方向
                    end_idx = min(len(unified_trajectory) - 1, idx + smooth_window)

                    directions = []
                    for j in range(idx + 1, end_idx + 1):
                        other_point = unified_trajectory[j]
                        direction = np.array([
                            other_point[0] - cam_x,
                            0.0,  # 忽略 Y 差异，只保留水平方向
                            other_point[2] - cam_z
                        ])
                        norm = np.linalg.norm(direction)
                        if norm > 1e-6:
                            directions.append(direction / norm)

                    if len(directions) > 0:
                        direction = np.mean(directions, axis=0)
                    else:
                        next_point = unified_trajectory[idx + 1]
                        direction = np.array([
                            next_point[0] - cam_x,
                            0.0,
                            next_point[2] - cam_z
                        ])
                elif idx < len(unified_trajectory) - 1:
                    next_point = unified_trajectory[idx + 1]
                    direction = np.array([
                        next_point[0] - cam_x,
                        0.0,  # 忽略 Y 差异
                        next_point[2] - cam_z
                    ])
                else:
                    if idx > 0:
                        prev_point = unified_trajectory[idx - 1]
                        direction = np.array([
                            cam_x - prev_point[0],
                            0.0,
                            cam_z - prev_point[2]
                        ])
                    else:
                        direction = np.array([0.0, 0.0, 1.0])

                # 归一化水平方向
                h_norm = np.linalg.norm(direction)
                if h_norm > 1e-6:
                    direction = direction / h_norm
                else:
                    direction = np.array([0.0, 0.0, 1.0])

                # 添加向下俯仰角
                pitch_rad = np.deg2rad(pitch_down_degrees)
                cos_p = np.cos(pitch_rad)
                sin_p = np.sin(pitch_rad)
                z_axis = np.array([
                    direction[0] * cos_p,
                    sin_p,  # Y 向下为正
                    direction[2] * cos_p
                ])

                # 计算相机坐标系
                x_axis = np.cross([0, 1, 0], z_axis)
                x_norm = np.linalg.norm(x_axis)
                if x_norm > 1e-6:
                    x_axis = x_axis / x_norm
                else:
                    x_axis = np.array([1, 0, 0])

                y_axis = np.cross(z_axis, x_axis)
                y_axis = y_axis / np.linalg.norm(y_axis)

                # 渲染视角
                output_path = os.path.join(
                    output_dir_to_use,
                    f"{base_name}_render_view_{idx:03d}_{trajectory_labels[idx]}_h{camera_height_offset:.2f}m_{timestamp}.png"
                )

                self._render_single_view(
                    point_cloud, original_image,
                    cam_x, cam_y, cam_z,
                    x_axis, y_axis, z_axis,
                    fx, fy, cx, cy,
                    output_path,
                    image_path,
                    fov_x
                )

                rendered_files.append(output_path)
                if (idx + 1) % 10 == 0 or idx + 1 == len(unified_trajectory):
                    print(f"   进度：{idx}/{len(unified_trajectory)-1}（跳过索引 0）")

            if rendered_files:
                print(f"\n   ✅ 视角渲染完成：共 {len(rendered_files)} 个视角（跳过相机抬高位置）")
            result["unified_rendered_views"] = [os.path.basename(f) for f in rendered_files]

            # ========== 将渲染结果保存为 MP4 视频 ==========
            print(f"\n   🎬 将渲染结果保存为 MP4 视频...")
            try:
                import cv2
                # 读取第一张图像获取尺寸
                first_img = cv2.imread(rendered_files[0])
                if first_img is not None:
                    h_frame, w_frame = first_img.shape[:2]

                    # 输出视频路径
                    video_path = os.path.join(
                        output_dir_to_use,
                        f"{base_name}_trajectory_video_h{camera_height_offset:.2f}m_{timestamp}.mp4"
                    )

                    # 创建视频写入器
                    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
                    fps = 10  # 每秒 10 帧
                    video_writer = cv2.VideoWriter(video_path, fourcc, fps, (w_frame, h_frame))

                    # 逐帧写入
                    for img_path in rendered_files:
                        frame = cv2.imread(img_path)
                        if frame is not None:
                            video_writer.write(frame)

                    video_writer.release()
                    print(f"   ✅ 视频已保存：{os.path.basename(video_path)}")
                    print(f"      帧数：{len(rendered_files)}")
                    print(f"      帧率：{fps} fps")
                    print(f"      时长：{len(rendered_files)/fps:.1f} 秒")
                    result["trajectory_video_mp4"] = os.path.basename(video_path)
                else:
                    print(f"   ⚠️ 无法读取第一帧，跳过视频生成")
            except Exception as e:
                print(f"   ⚠️ 视频生成失败：{e}")

        return result


def load_depth_map_from_npy(depth_npy_path: str) -> Optional[np.ndarray]:
    """
    从 numpy 格式加载真实深度图

    Args:
        depth_npy_path: .npy 文件路径

    Returns:
        深度图数组，失败返回 None
    """
    if not os.path.exists(depth_npy_path):
        return None

    try:
        depth_map = np.load(depth_npy_path)
        print(f"✅ 从 .npy 加载深度图：{depth_npy_path}")
        print(f"   深度范围：{depth_map.min():.3f} - {depth_map.max():.3f} 米")
        return depth_map
    except Exception as e:
        print(f"❌ 加载深度图失败：{e}")
        return None


def load_depth_map_from_image(depth_masks_path: str) -> Optional[np.ndarray]:
    """
    从 depth_masks 图像加载深度图（备用方案）

    Args:
        depth_masks_path: depth_masks 图像路径

    Returns:
        深度图数组，失败返回 None
    """
    if not os.path.exists(depth_masks_path):
        print(f"❌ 文件不存在：{depth_masks_path}")
        return None

    # 读取图像
    img = cv2.imread(depth_masks_path)
    if img is None:
        print(f"❌ 无法读取图像：{depth_masks_path}")
        return None

    # 转换为灰度图作为深度图（或者从 JSON 加载真实深度）
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 注意：这里使用的是简化的深度图
    # 实际应该从 main.py 生成的深度数据中加载真实深度值
    print(f"⚠️ 从 depth_masks 加载深度图（灰度近似）")
    print(f"   深度范围：{gray.min()} - {gray.max()}")

    return gray.astype(np.float32) / 255.0 * 5.0  # 假设深度范围 0-5 米


def main():
    parser = argparse.ArgumentParser(description="从轨迹点渲染新视角图像")
    parser.add_argument("--depth_masks", type=str, required=True,
                        help="depth_masks 图像路径")
    parser.add_argument("--trajectory_data", type=str, required=True,
                        help="轨迹数据 JSON 文件路径")
    parser.add_argument("--original_image", type=str, required=True,
                        help="原始 RGB 图像路径")
    parser.add_argument("--point_cloud_path", type=str, default=None,
                        help="点云 PLY 文件路径（可选，如果不提供则从深度图生成）")
    parser.add_argument("--view_index", type=int, default=-1,
                        help="要渲染的轨迹点索引（-1=最后一个点，-2=倒数第二个点）")
    parser.add_argument("--yaw_offset", type=float, default=0.0,
                        help="额外的 yaw 偏移（度）")
    parser.add_argument("--output_dir", type=str, default=None,
                        help="输出目录")

    args = parser.parse_args()

    # 加载轨迹数据
    print("=" * 70)
    print("📊 加载轨迹数据")
    print("=" * 70)

    with open(args.trajectory_data, 'r') as f:
        trajectory_data = json.load(f)

    trajectory = trajectory_data.get('trajectory', [])
    print(f"   轨迹点数：{len(trajectory)}")

    if len(trajectory) < 2:
        print("❌ 轨迹点数量不足")
        return

    # 加载原始图像
    original_image = cv2.imread(args.original_image)
    if original_image is None:
        print(f"❌ 无法读取原始图像：{args.original_image}")
        return
    print(f"✅ 原始图像：{args.original_image}")

    # 加载深度图
    depth_map = load_depth_map_from_image(args.depth_masks)
    if depth_map is None:
        print("❌ 无法加载深度图")
        return

    # 生成/加载点云
    if args.point_cloud_path and os.path.exists(args.point_cloud_path):
        # 从 PLY 加载点云
        print(f"✅ 从 PLY 加载点云：{args.point_cloud_path}")
        # TODO: 实现 PLY 加载
        point_cloud = None
    else:
        # 从深度图生成简化的点云
        print("🔧 从深度图生成点云...")
        h, w = depth_map.shape

        # 假设 FOV=60°
        focal_length = w / (2 * np.tan(np.deg2rad(60) / 2))
        cx, cy = w / 2, h / 2

        # 反投影
        y, x = np.meshgrid(np.arange(h), np.arange(w), indexing='ij')
        cam_x = (x - cx) * depth_map / focal_length
        cam_y = (y - cy) * depth_map / focal_length
        cam_z = depth_map

        point_cloud = np.stack([cam_x, cam_y, cam_z], axis=-1)
        print(f"✅ 点云已生成：{w}x{h}")

    if point_cloud is None:
        print("❌ 点云加载失败")
        return

    # 渲染
    renderer = TrajectoryViewRenderer(output_dir=args.output_dir)

    result = renderer.render_view(
        point_cloud=point_cloud,
        original_image=original_image,
        depth_map=depth_map,
        trajectory=trajectory,
        view_index=args.view_index,
        yaw_offset=args.yaw_offset
    )

    if result:
        print("\n" + "=" * 70)
        print("✅ 渲染完成!")
        print("=" * 70)
        print(f"渲染图像：{result['rendered_image']}")


if __name__ == "__main__":
        main()
