#!/usr/bin/env python3
"""
Trajectory 2D API Server
将完整的轨迹规划 pipeline 封装为 HTTP API

输入: RGB 图像 + 自然语言指令
输出: 轨迹点序列 + 新视角渲染图像 + 3D 点云

使用示例:
    # 启动服务
    python api_server.py --host 0.0.0.0 --port 9000

    # 调用 API（基本用法）
    curl -X POST http://localhost:9000/api/trajectory \
        -F "image=@/path/to/image.png" \
        -F "instruction=左边的椅子"

    # 带轨迹动画（显式开启）
    curl -X POST http://localhost:9000/api/trajectory \
        -F "image=@/path/to/image.png" \
        -F "instruction=左边的椅子" \
        -F "return_trajectory_video=true"

    # 完整参数示例
    curl -X POST http://localhost:9000/api/trajectory \
        -F "image=@/path/to/image.png" \
        -F "instruction=左边的椅子" \
        -F "filter_floor=true" \
        -F "trajectory_spacing=0.017" \
        -F "trajectory_smooth_window=5" \
        -F "camera_height=0.06" \
        -F "self_reflection=true" \
        -F "return_trajectory_video=true" \
        -F "return_metadata=true"
"""

import sys
import os
import io
import json
import zipfile
import base64
import tempfile
import shutil
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
from contextlib import asynccontextmanager

import numpy as np
import cv2
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, Field
import uvicorn

# 添加当前目录到 Python 路径
sys.path.insert(0, os.path.dirname(__file__))


# ========== 配置模型 ==========

class TrajectoryRequest(BaseModel):
    """轨迹规划请求参数"""
    instruction: str = Field(..., description="自然语言指令，如'左边的椅子'")
    initial_image: Optional[str] = Field(
        None,
        description="初始图像路径（用于 VLM 终止判断，与当前图像组合判断趋势）"
    )
    target_desc: Optional[str] = Field(
        None,
        description="目标描述（用于终止判断的 VLM 分析，默认使用 instruction）"
    )
    depth_threshold: float = Field(
        0.8,
        description="门判断阈值：目标中位深度 < 此值认为是门（米）"
    )
    floor_ratio_threshold: float = Field(
        0.3,
        description="门判断阈值：起点到目标连线地板占比 < 此值认为是门"
    )
    skip_ply_save: bool = Field(
        True,
        description="跳过 PLY 点云文件保存（默认跳过，提升 I/O 效率）"
    )

    # 轨迹规划参数
    start_x: int = Field(310, description="起点 x 坐标（像素）", ge=0)
    start_y: int = Field(450, description="起点 y 坐标（像素）", ge=0)
    distance_threshold: float = Field(5.0, description="去重距离阈值（像素）", gt=0)
    skip_postprocess: bool = Field(False, description="跳过轨迹点后处理")
    filter_floor: bool = Field(True, description="启用地板约束过滤（默认开启）")
    trajectory_spacing: float = Field(
        0.010,
        description="轨迹点目标物理间距（米），默认 0.010m。越小越密集，越大越稀疏"
    )
    save_comparison: bool = Field(False, description="保存过滤前后对比图")
    
    # 渲染控制
    render_view: bool = Field(
        False,
        description="渲染单个轨迹点新视角（配合 view_index 使用）"
    )
    render_all_views: bool = Field(
        True,
        description="渲染所有轨迹点新视角（默认开启）"
    )
    view_index: int = Field(-1, description="要渲染的轨迹点索引（-1=最后一个）")
    yaw_offset: float = Field(0.0, description="额外的 yaw 偏移（度）")
    camera_height: Optional[float] = Field(
        None,
        description="相机高度偏移（米），默认None=自动从地板平面计算相机实际离地高度"
    )
    pitch_down_degrees: float = Field(
        0.0,
        description="相机向下俯仰角度（度），默认 0 度（水平朝向）"
    )
    return_only_selected_views: bool = Field(
        False, 
        description="只返回指定索引的渲染视图（配合 view_index 使用）"
    )
    
    # 响应内容控制
    return_trajectory_points: bool = Field(
        True,
        description="返回所有轨迹点的 2D 像素坐标（默认返回）"
    )
    return_rendered_views: bool = Field(
        True,
        description="返回渲染的视角图像（默认返回）"
    )
    return_trajectory_video: bool = Field(
        False,
        description="返回轨迹动画 MP4（默认不返回，需显式开启）"
    )
    return_metadata: bool = Field(
        False,
        description="返回完整元数据 JSON"
    )
    save_trajectory_3d: bool = Field(False, description="保存轨迹 3D 点云 PLY")
    save_zip: bool = Field(True, description="打包输出为 zip（默认开启）")
    use_vision_intent: bool = Field(
        True,
        description="使用两阶段 VLM 意图识别（新流程），支持模糊指令/多目标/关系型指令"
    )

    # 服务配置
    output_dir: Optional[str] = Field(
        None,
        description="输出目录（默认使用临时目录）"
    )


class TrajectoryPoint(BaseModel):
    """轨迹点"""
    x: float
    y: float
    index: int


class ValidationResult(BaseModel):
    """验证结果"""
    success: bool
    floor_coverage: float
    on_floor_count: int
    off_floor_count: int


class TerminationResult(BaseModel):
    """VLM 终止判断结果"""
    reached: bool = Field(False, description="是否已到达目标")
    reason: Optional[str] = Field(None, description="终止原因")
    target_depth: Optional[float] = Field(None, description="目标中位深度（米）")
    floor_ratio: Optional[float] = Field(None, description="起点到目标连线地板占比")
    initial_depth: Optional[float] = Field(None, description="初始图像目标中位深度（米）")
    current_depth: Optional[float] = Field(None, description="当前图像目标中位深度（米）")
    is_door: Optional[bool] = Field(None, description="是否判定为门")
    is_door_reason: Optional[str] = Field(None, description="门判断原因")
    depth_trend: Optional[str] = Field(None, description="深度变化趋势 (decreasing/increasing/stable)")


class RenderedView(BaseModel):
    """渲染的新视角"""
    view_index: int
    image_base64: str
    pixel_coords: List[float]
    depth: float


class TrajectoryResponse(BaseModel):
    """轨迹规划响应"""
    success: bool
    message: str

    # 轨迹数据
    trajectory: List[TrajectoryPoint]
    num_points: int

    # 关键点
    start_point: List[int]
    target_point: Optional[List[int]] = None
    navigation_goal_point: Optional[List[int]] = None

    # 验证
    validation: Optional[ValidationResult] = None

    # VLM 终止判断
    termination: Optional[TerminationResult] = None

    # 渲染图像
    rendered_views: List[RenderedView] = []

    # 轨迹动画
    trajectory_video_base64: Optional[str] = None

    # 渲染使用的相机高度（米）
    camera_height_offset: Optional[float] = None

    # 点云分割结果（Base64 编码，客户端可自行保存到本地）
    segmentation_results: Optional[Dict[str, str]] = Field(
        None,
        description="点云分割结果（Base64 编码），包含 depth_masks.png、depth_map.npy、floor_mask.npy、target_mask.npy 等"
    )

    # 原始输出文件（可选）
    output_files: Optional[Dict[str, str]] = None

    # 处理时间
    processing_time_seconds: float

    # 详细数据（完整 JSON）
    raw_trajectory_data: Optional[Dict[str, Any]] = None

    error: Optional[str] = None


# ========== 全局变量 ==========

# 服务状态
service_status = {
    "running": False,
    "start_time": None,
    "total_requests": 0,
    "successful_requests": 0,
    "failed_requests": 0
}


# ========== API 实现 ==========

@asynccontextmanager
async def lifespan(app: FastAPI):
    """服务生命周期管理"""
    # 启动时
    service_status["running"] = True
    service_status["start_time"] = datetime.now().isoformat()
    print("✅ Trajectory 2D API Server 已启动")
    print(f"   时间: {service_status['start_time']}")
    yield
    # 关闭时
    service_status["running"] = False
    print("👋 Trajectory 2D API Server 已关闭")


app = FastAPI(
    title="Trajectory 2D API",
    description="机器人导航轨迹规划 API - 输入 RGB 图像 + 自然语言指令，输出轨迹点 + 新视角渲染图像",
    version="1.0.0",
    lifespan=lifespan
)


@app.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "ok",
        "service": "Trajectory 2D API",
        "running": service_status["running"],
        "start_time": service_status["start_time"],
        "total_requests": service_status["total_requests"],
        "successful_requests": service_status["successful_requests"],
        "failed_requests": service_status["failed_requests"]
    }


@app.post("/api/trajectory", response_model=TrajectoryResponse)
async def plan_trajectory(
    image: UploadFile = File(..., description="RGB 图像（PNG/JPG）"),
    instruction: str = Form(..., description="自然语言指令"),
    initial_image: Optional[str] = Form(None, description="初始图像路径（用于 VLM 终止判断）"),
    target_desc: Optional[str] = Form(None, description="目标描述（用于终止判断，默认使用 instruction）"),
    depth_threshold: float = Form(0.8, description="门判断深度阈值（米）"),
    floor_ratio_threshold: float = Form(0.3, description="门判断地板占比阈值"),
    skip_ply_save: bool = Form(True, description="跳过 PLY 点云文件保存"),
    use_vision_intent: bool = Form(True, description="使用两阶段 VLM 意图识别（新流程）"),

    # 轨迹规划参数
    start_x: int = Form(310),
    start_y: int = Form(450),
    distance_threshold: float = Form(5.0),
    skip_postprocess: bool = Form(False),
    filter_floor: bool = Form(True),
    trajectory_spacing: float = Form(0.010, description="轨迹点目标物理间距（米）"),
    trajectory_smooth_window: int = Form(10, description="轨迹交接处平滑窗口大小"),

    # 渲染参数
    render_view: bool = Form(False),
    render_all_views: bool = Form(True),
    camera_height: float = Form(
        None,
        description="相机高度偏移（米），默认None=自动从地板平面计算相机实际离地高度"
    ),
    pitch_down_degrees: float = Form(
        0.0,
        description="相机向下俯仰角度（度），默认 0 度（水平朝向）"
    ),
    random_seed: int = Form(42, description="随机种子，确保渲染确定性"),

    # 输出选项
    self_reflection: bool = Form(True),
    save_trajectory_3d: bool = Form(False),
    save_zip: bool = Form(True),

    # 响应内容控制
    return_trajectory_points: bool = Form(True),
    return_rendered_views: bool = Form(True),
    return_trajectory_video: bool = Form(False),
    return_metadata: bool = Form(False),
):
    """
    轨迹规划主接口

    **输入**:
    - `image`: 当前 RGB 图像文件
    - `instruction`: 自然语言指令（如"左边的椅子"）
    - `initial_image`: 初始图像路径（可选，用于 VLM 终止判断）

    **输出**:
    - 轨迹点序列（2D 像素坐标）
    - 渲染的视角图像（Base64 编码，默认返回所有视角）
    - 轨迹动画 MP4（可选，默认不返回）
    - 完整元数据（可选）
    - VLM 终止判断结果（当提供 initial_image 时）

    **示例请求**:
    ```bash
    # 基本用法（默认参数：地板过滤+全视角渲染+self_reflection）
    curl -X POST http://localhost:9000/api/trajectory \
        -F "image=@image.png" \
        -F "instruction=左边的椅子"

    # 带轨迹动画（显式开启）
    curl -X POST http://localhost:9000/api/trajectory \
        -F "image=@image.png" \
        -F "instruction=左边的椅子" \
        -F "return_trajectory_video=true"

    # 带终止判断（初始图像 + 当前图像）
    curl -X POST http://localhost:9000/api/trajectory \
        -F "image=@frame_0110.png" \
        -F "initial_image=@frame_0000.png" \
        -F "instruction=左边的椅子"
    ```
    """
    
    start_time = datetime.now()
    service_status["total_requests"] += 1
    
    # 创建临时目录
    temp_dir = tempfile.mkdtemp(prefix="trajectory_api_")
    output_dir = os.path.join(temp_dir, "output")
    os.makedirs(output_dir, exist_ok=True)
    
    image_path = None
    
    try:
        # 1. 保存上传的图像
        image_filename = image.filename or "input_image.png"
        image_path = os.path.join(temp_dir, image_filename)
        
        with open(image_path, "wb") as f:
            content = await image.read()
            f.write(content)
        
        # 验证图像
        if not os.path.exists(image_path):
            raise HTTPException(status_code=400, detail="图像上传失败")
        
        test_img = cv2.imread(image_path)
        if test_img is None:
            raise HTTPException(status_code=400, detail="无法读取图像，请检查格式")

        image_height, image_width = test_img.shape[:2]

        print(f"\n{'='*80}")
        print(f"🚀 开始处理轨迹规划请求")
        print(f"   图像: {image_filename} ({image_width}x{image_height})")
        print(f"   指令: {instruction}")
        if initial_image:
            print(f"   初始图像: {initial_image} (终止判断)")
        print(f"   参数: filter_floor={filter_floor}, render_all_views={render_all_views}, self_reflection={self_reflection}")
        print(f"   参数: camera_height={camera_height}, skip_ply_save={skip_ply_save}")
        print(f"   意图识别: {'🧠 两阶段 VLM（新流程）' if use_vision_intent else '📋 传统 VLM'}")
        print(f"{'='*80}\n")

        # 2. 调用完整 pipeline
        # 导入 run_pipeline 的核心函数
        from run_pipeline import (
            run_main_pipeline,
            run_vlm_trajectory,
            postprocess_trajectory,
            filter_trajectory_on_floor,
            interpolate_trajectory,
            save_trajectory_as_pointcloud,
            visualize_trajectory_on_image
        )
        from render_trajectory_view import TrajectoryViewRenderer, load_depth_map_from_npy, load_depth_map_from_image
        from datetime import datetime as dt
        import termination_checker as tc
        import tempfile as _tf
        from timing_tracker import load_timing_from_file, print_detailed_timing

        # 创建计时文件路径（用于聚合子进程的计时数据）
        _timing_dir = _tf.mkdtemp(prefix="api_timing_")
        _main_timing = os.path.join(_timing_dir, "main.json")
        _vlm_timing = os.path.join(_timing_dir, "vlm.json")

        # 步骤 1: 运行主 pipeline（分割）
        # 注意：点云分割结果保存在服务器端（temp_dir/output/）
        # 客户端需要通过 API 返回的 Base64 数据自行保存
        depth_masks_path, depth_map_npy_path, output_subdir, target_point_2d, navigation_goal_point_2d, computed_start_point = run_main_pipeline(
            image_path, instruction, output_dir, save_ply=not skip_ply_save, use_vision_intent=use_vision_intent, timing_file=_main_timing
        )

        if depth_masks_path is None:
            service_status["failed_requests"] += 1
            raise HTTPException(status_code=500, detail="点云分割失败")

        # 使用 main.py 自动计算的起点（如果可用），否则使用 API 参数
        if computed_start_point is not None:
            actual_start_x, actual_start_y = computed_start_point
            print(f"\n✅ 使用 main.py 自动计算的起点: ({actual_start_x}, {actual_start_y})")
        else:
            actual_start_x, actual_start_y = start_x, start_y
            print(f"\n⚠️ 未获取到自动计算的起点，使用 API 参数: ({actual_start_x}, {actual_start_y})")

        # 步骤 1.5: VLM 终止判断（当提供了 initial_image 时）
        termination_result = None
        if initial_image and os.path.exists(initial_image):
            print(f"\n{'='*80}")
            print("🛑 步骤 1.5: VLM 终止判断")
            print("=" * 80)

            actual_target_desc = target_desc if target_desc else instruction

            # 从 depth_masks 提取当前图像的 target mask
            current_mask_img = cv2.imread(depth_masks_path, cv2.IMREAD_GRAYSCALE)
            if current_mask_img is not None:
                # target mask 区域是白色（255）
                current_target_mask = (current_mask_img >= 128)
            else:
                current_target_mask = None

            initial_target_mask = None

            # 对初始图像运行 main.py 获取 target mask（用于 VLM 趋势对比）
            try:
                initial_output_dir = os.path.join(temp_dir, "initial_output")
                os.makedirs(initial_output_dir, exist_ok=True)

                init_depth_masks, init_depth_npy, _, _, _, _ = run_main_pipeline(
                    initial_image, instruction, initial_output_dir, save_ply=True, use_vision_intent=use_vision_intent
                )

                if init_depth_masks and os.path.exists(init_depth_masks):
                    init_mask_img = cv2.imread(init_depth_masks, cv2.IMREAD_GRAYSCALE)
                    if init_mask_img is not None:
                        # target mask 区域是白色（255）
                        initial_target_mask = (init_mask_img >= 128)
                        print(f"  ✅ 初始图像 target mask 面积: {initial_target_mask.sum()} 像素")
                    else:
                        print(f"  ⚠️ 无法读取初始图像 depth_masks")
                else:
                    print(f"  ⚠️ 初始图像分割未返回 depth_masks")

            except Exception as e:
                print(f"  ⚠️ 初始图像分割失败: {e}")
                import traceback
                traceback.print_exc()

            current_depth_map = np.load(depth_map_npy_path) if os.path.exists(depth_map_npy_path) else None

            try:
                # 加载 floor mask
                base_name_current = os.path.splitext(os.path.basename(image_path))[0]
                floor_mask_path = os.path.join(output_subdir, f"{base_name_current}_floor_mask.npy")
                if os.path.exists(floor_mask_path):
                    current_floor_mask = np.load(floor_mask_path)
                elif current_target_mask is not None:
                    current_floor_mask = np.zeros_like(current_target_mask, dtype=np.uint8)
                else:
                    current_floor_mask = np.zeros((image_height, image_width), dtype=np.uint8)

                # 确保 target mask 有效
                if current_target_mask is None:
                    current_target_mask = np.zeros((image_height, image_width), dtype=np.uint8)

                termination_result = tc.check_termination(
                    start_rgb_path=initial_image,
                    current_rgb_path=image_path,
                    current_depth_map=current_depth_map,
                    current_floor_mask=current_floor_mask,
                    current_target_mask=current_target_mask,
                    start_target_mask=initial_target_mask if initial_target_mask is not None else None,
                    start_point=(actual_start_x, actual_start_y),
                    target_description=actual_target_desc,
                    depth_threshold=depth_threshold,
                    floor_path_ratio_threshold=floor_ratio_threshold
                )

                print(f"  终止判断结果: reached={termination_result.get('reached', False)}")
                if termination_result.get('reason'):
                    print(f"  原因: {termination_result['reason']}")

                # 如果已到达目标，直接返回，跳过后续轨迹规划
                if termination_result.get('reached', False):
                    print("🛑 终止条件满足，跳过轨迹规划")

                    end_time = datetime.now()
                    processing_time = (end_time - start_time).total_seconds()
                    service_status["successful_requests"] += 1

                    return TrajectoryResponse(
                        success=True,
                        message=f"已到达目标: {termination_result.get('reason', 'unknown')}",
                        trajectory=[],
                        num_points=0,
                        start_point=[actual_start_x, actual_start_y],
                        target_point=target_point_2d,
                        navigation_goal_point=navigation_goal_point_2d,
                        termination=TerminationResult(
                            reached=termination_result.get('reached', False),
                            reason=termination_result.get('reason'),
                            target_depth=termination_result.get('target_depth'),
                            floor_ratio=termination_result.get('floor_ratio'),
                            initial_depth=termination_result.get('initial_depth'),
                            current_depth=termination_result.get('current_depth'),
                            is_door=termination_result.get('is_door'),
                            is_door_reason=termination_result.get('is_door_reason'),
                            depth_trend=termination_result.get('depth_trend')
                        ),
                        rendered_views=[],
                        trajectory_video_base64=None,
                        processing_time_seconds=processing_time
                    )

            except Exception as e:
                print(f"⚠️ 终止判断失败: {e}")
                import traceback
                traceback.print_exc()
                # 不影响后续流程

        # 步骤 2: 运行 VLM 轨迹预测
        trajectory_data_path = run_vlm_trajectory(
            depth_masks_path,
            depth_map_npy_path,
            (actual_start_x, actual_start_y),
            target_point_2d,
            navigation_goal_point_2d,
            use_self_reflection=self_reflection,
            timing_file=_vlm_timing
        )
        
        if trajectory_data_path is None:
            service_status["failed_requests"] += 1
            raise HTTPException(status_code=500, detail="轨迹预测失败")

        # 加载轨迹数据
        with open(trajectory_data_path, 'r', encoding='utf-8') as f:
            trajectory_data = json.load(f)
        
        current_trajectory = trajectory_data.get('trajectory', [])
        goal_point = navigation_goal_point_2d if navigation_goal_point_2d else target_point_2d

        # 步骤 3: 后处理
        from timing_tracker import tracker as _tt
        if not skip_postprocess:
            _tt.start("Postprocess", "去重+融合+顺序验证")
            postprocess_result = postprocess_trajectory(
                trajectory=current_trajectory,
                start_point=(actual_start_x, actual_start_y),
                target_point=goal_point,
                distance_threshold=distance_threshold
            )
            _tt.end("Postprocess", "去重+融合+顺序验证")

            if postprocess_result['success']:
                trajectory_data['trajectory'] = postprocess_result['trajectory']
                trajectory_data['postprocess'] = postprocess_result
                current_trajectory = postprocess_result['trajectory']

        # 步骤 4: 地板约束过滤
        if filter_floor:
            # 加载地板掩码
            base_name = os.path.splitext(os.path.basename(image_path))[0]
            floor_mask_path = os.path.join(output_dir, base_name, f"{base_name}_floor_mask.npy")

            if os.path.exists(floor_mask_path):
                floor_mask = np.load(floor_mask_path)

                _tt.start("Postprocess", "地板约束过滤")
                filter_result = filter_trajectory_on_floor(
                    trajectory=current_trajectory,
                    floor_mask=floor_mask,
                    start_point=(actual_start_x, actual_start_y),
                    target_point=goal_point
                )
                _tt.end("Postprocess", "地板约束过滤")

                if filter_result['success']:
                    trajectory_data['trajectory'] = filter_result['trajectory']
                    trajectory_data['floor_filter'] = filter_result
                    current_trajectory = filter_result['trajectory']

                    # 插值（基于物理间距，优先使用3D空间距离）
                    depth_map_for_interp = None
                    if os.path.exists(depth_map_npy_path):
                        try:
                            depth_map_for_interp = np.load(depth_map_npy_path)
                        except Exception as e:
                            print(f"⚠️ 加载深度图用于插值失败: {e}")

                    _tt.start("Postprocess", "3D空间插值")
                    interp_result = interpolate_trajectory(
                        trajectory=current_trajectory,
                        floor_mask=floor_mask,
                        target_spacing=trajectory_spacing,
                        min_points=5,
                        max_density=15.0,
                        depth_map=depth_map_for_interp,
                        camera_intrinsics=None,
                        image_width=floor_mask.shape[1],
                        image_height=floor_mask.shape[0],
                        force_resample=True
                    )
                    _tt.end("Postprocess", "3D空间插值")

                    if interp_result['success']:
                        trajectory_data['trajectory'] = interp_result['trajectory']
                        trajectory_data['interpolation'] = interp_result
                        current_trajectory = interp_result['trajectory']

        # 保存更新后的轨迹数据
        with open(trajectory_data_path, 'w', encoding='utf-8') as f:
            json.dump(trajectory_data, f, ensure_ascii=False, indent=2)

        # 步骤 5: 新视角渲染
        rendered_views_data = []
        trajectory_video_base64 = None

        # 判断是否需要渲染
        need_render = return_rendered_views or return_trajectory_video
        print(f"\n🔍 渲染调试信息:")
        print(f"   return_rendered_views: {return_rendered_views}")
        print(f"   return_trajectory_video: {return_trajectory_video}")
        print(f"   need_render: {need_render}")
        print(f"   current_trajectory 长度: {len(current_trajectory)}")

        if need_render and len(current_trajectory) >= 2:
            print(f"   ✅ 进入渲染流程")
            original_image = cv2.imread(image_path)
            if original_image is None:
                print(f"   ⚠️ 无法读取原始图像: {image_path}")
            depth_npy_path = os.path.join(output_dir, base_name, f"{base_name}_depth_map.npy")
            depth_map = load_depth_map_from_npy(depth_npy_path)

            if depth_map is None:
                depth_map = load_depth_map_from_image(depth_masks_path)

            if depth_map is not None and len(current_trajectory) >= 2:
                # 生成点云
                h, w = depth_map.shape
                focal_length = w / (2 * np.tan(np.deg2rad(60) / 2))
                cx, cy = w / 2, h / 2

                y, x = np.meshgrid(np.arange(h), np.arange(w), indexing='ij')
                cam_x = (x - cx) * depth_map / focal_length
                cam_y = (y - cy) * depth_map / focal_length
                cam_z = depth_map

                point_cloud = np.stack([cam_x, cam_y, cam_z], axis=-1)

                # 渲染
                renderer = TrajectoryViewRenderer(output_dir=output_dir)

                # 初始化 elevated_result（用于后续响应）
                elevated_result = None

                # 提取地板掩码
                floor_mask_for_camera = None
                try:
                    from run_pipeline import extract_floor_mask
                    floor_mask_for_camera = extract_floor_mask(depth_masks_path)
                    if floor_mask_for_camera is not None:
                        print(f"   ✅ 已加载 floor_mask 用于相机抬高计算")
                    else:
                        print(f"   ⚠️ 无法提取 floor_mask，将使用默认地面高度")
                except Exception as e:
                    print(f"   ⚠️ 提取 floor_mask 失败：{e}，将使用默认地面高度")

                # 使用 render_all_elevated_trajectory_points 统一渲染
                _tt.start("Rendering", "点云生成+相机抬高+视角渲染+视频编码")
                elevated_result = renderer.render_all_elevated_trajectory_points(
                    point_cloud=point_cloud,
                    original_image=original_image,
                    depth_map=depth_map,
                    trajectory=current_trajectory,
                    image_path=image_path,
                    camera_height_offset=camera_height,
                    save_pointcloud=True,
                    save_camera_origin=False,  # API 模式下不保存相机初始位置点云
                    floor_mask=floor_mask_for_camera,
                    camera_approach_spacing=trajectory_spacing,
                    smooth_window=trajectory_smooth_window,
                    random_seed=random_seed,
                    pitch_down_degrees=pitch_down_degrees
                )
                _tt.end("Rendering", "点云生成+相机抬高+视角渲染+视频编码")

                if elevated_result.get('success'):
                    print(f"   ✅ elevated_result['success'] = True")
                    print(f"   elevated_result keys: {list(elevated_result.keys())}")
                    if 'unified_rendered_views' in elevated_result:
                        print(f"   unified_rendered_views 数量: {len(elevated_result['unified_rendered_views'])}")
                    else:
                        print(f"   ⚠️ elevated_result 中没有 'unified_rendered_views' 键")
                    
                    # 保存抬高轨迹信息到 JSON
                    trajectory_data['elevated_trajectory_ply'] = elevated_result.get('ply_path')
                    # 保存实际使用的相机高度（可能是自动计算的）
                    trajectory_data['camera_height_offset'] = elevated_result.get('camera_height_offset', camera_height)
                    if 'unified_elevated_trajectory_ply' in elevated_result and elevated_result['unified_elevated_trajectory_ply']:
                        trajectory_data['unified_elevated_trajectory_ply'] = elevated_result['unified_elevated_trajectory_ply']
                    if 'unified_rendered_views' in elevated_result:
                        trajectory_data['unified_rendered_views'] = elevated_result['unified_rendered_views']
                    if 'trajectory_video_mp4' in elevated_result:
                        trajectory_data['trajectory_video_mp4'] = elevated_result['trajectory_video_mp4']

                    with open(trajectory_data_path, 'w', encoding='utf-8') as f:
                        json.dump(trajectory_data, f, ensure_ascii=False, indent=2)

                    # 收集渲染的图像
                    if return_rendered_views and 'unified_rendered_views' in elevated_result:
                        rendered_files = elevated_result['unified_rendered_views']
                        for idx, img_filename in enumerate(rendered_files):
                            img_path = os.path.join(output_subdir, img_filename)
                            if os.path.exists(img_path):
                                with open(img_path, 'rb') as img_f:
                                    img_bytes = img_f.read()
                                    img_base64 = base64.b64encode(img_bytes).decode('utf-8')

                                rendered_views_data.append({
                                    'view_index': idx,
                                    'image_base64': img_base64,
                                    'pixel_coords': [],
                                    'depth': 0.0
                                })

                    # 读取轨迹动画（如果请求）
                    if return_trajectory_video and 'trajectory_video_mp4' in elevated_result:
                        video_filename = elevated_result['trajectory_video_mp4']
                        video_path = os.path.join(output_subdir, video_filename)
                        if os.path.exists(video_path):
                            try:
                                with open(video_path, 'rb') as vid_f:
                                    trajectory_video_base64 = base64.b64encode(vid_f.read()).decode('utf-8')
                                print(f"   ✅ 轨迹动画已编码为 Base64")
                            except Exception as e:
                                print(f"   ⚠️ 编码轨迹动画失败: {e}")
                else:
                    print(f"   ⚠️ 统一渲染失败：{elevated_result.get('error', '未知错误')}")

        # 收集输出文件
        output_files = {}
        rendered_view_responses = []

        # 将渲染数据转换为 RenderedView 对象
        if return_rendered_views:
            for view_data in rendered_views_data:
                try:
                    rendered_view_responses.append(RenderedView(
                        view_index=view_data['view_index'],
                        image_base64=view_data['image_base64'],
                        pixel_coords=view_data['pixel_coords'],
                        depth=view_data['depth']
                    ))
                except Exception as e:
                    print(f"⚠️ 转换渲染视图失败: {e}")

        # 收集输出文件路径（不读取内容）
        for root, dirs, files in os.walk(output_dir):
            for file in files:
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, output_dir)

                if file.endswith('_trajectory_data.json'):
                    output_files['trajectory_data'] = rel_path
                elif file.endswith('.png') and 'trajectory' in file.lower():
                    output_files[file] = rel_path
                elif file.endswith('.mp4'):
                    output_files[file] = rel_path
        
        # 提取轨迹点
        trajectory_points = trajectory_data.get('trajectory', [])
        trajectory_list = []
        
        if return_trajectory_points:
            trajectory_list = [
                TrajectoryPoint(x=p[0], y=p[1], index=i)
                for i, p in enumerate(trajectory_points)
            ]
        
        # 提取验证信息
        validation_data = trajectory_data.get('validation', {})
        validation = None
        if validation_data:
            validation = ValidationResult(
                success=validation_data.get('success', False),
                floor_coverage=validation_data.get('floor_coverage', 0.0),
                on_floor_count=len(validation_data.get('on_floor', [])),
                off_floor_count=len(validation_data.get('off_floor', []))
            )

        # 计算处理时间
        end_time = datetime.now()
        processing_time = (end_time - start_time).total_seconds()

        service_status["successful_requests"] += 1

        # 加载子进程的计时数据并打印
        load_timing_from_file(_main_timing)
        load_timing_from_file(_vlm_timing)
        print_detailed_timing()
        print(f"\n💡 总API耗时: {processing_time:.3f}s")

        # 构造响应
        termination_resp = None
        if termination_result:
            termination_resp = TerminationResult(
                reached=termination_result.get('reached', False),
                reason=termination_result.get('reason'),
                target_depth=termination_result.get('target_depth'),
                floor_ratio=termination_result.get('floor_ratio'),
                initial_depth=termination_result.get('initial_depth'),
                current_depth=termination_result.get('current_depth'),
                is_door=termination_result.get('is_door'),
                is_door_reason=termination_result.get('is_door_reason'),
                depth_trend=termination_result.get('depth_trend')
            )

        # ========== 收集点云分割结果（Base64 编码） ==========
        segmentation_results = {}
        try:
            base_name_seg = os.path.splitext(os.path.basename(image_path))[0]
            seg_files = [
                f"{base_name_seg}_depth_masks.png",
                f"{base_name_seg}_depth_map.npy",
                f"{base_name_seg}_floor_mask.npy",
                f"{base_name_seg}_target_mask.npy"
            ]
            for seg_file in seg_files:
                seg_path = os.path.join(output_subdir, seg_file)
                if os.path.exists(seg_path):
                    with open(seg_path, 'rb') as f:
                        file_bytes = f.read()
                        file_base64 = base64.b64encode(file_bytes).decode('utf-8')
                        segmentation_results[seg_file] = file_base64
            print(f"✅ 已收集 {len(segmentation_results)} 个点云分割结果文件（Base64 编码）")
        except Exception as e:
            print(f"⚠️ 收集点云分割结果失败: {e}")
            segmentation_results = None

        response = TrajectoryResponse(
            success=True,
            message=f"轨迹规划完成，生成 {len(trajectory_points)} 个轨迹点",
            trajectory=trajectory_list,
            num_points=len(trajectory_points) if return_trajectory_points else 0,
            start_point=trajectory_data.get('start_point', [actual_start_x, actual_start_y]),
            target_point=trajectory_data.get('target_point'),
            navigation_goal_point=trajectory_data.get('navigation_goal_point'),
            validation=validation,
            termination=termination_resp,
            rendered_views=rendered_view_responses if return_rendered_views else [],
            trajectory_video_base64=trajectory_video_base64 if return_trajectory_video else None,
            camera_height_offset=elevated_result.get('camera_height_offset') if elevated_result else camera_height,
            segmentation_results=segmentation_results,
            output_files=output_files if return_metadata else None,
            processing_time_seconds=processing_time,
            raw_trajectory_data=trajectory_data if return_metadata else None
        )
        
        print(f"\n✅ 请求处理完成 ({processing_time:.2f}s)")
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ 处理请求失败: {e}")
        import traceback
        traceback.print_exc()
        
        service_status["failed_requests"] += 1
        
        end_time = datetime.now()
        processing_time = (end_time - start_time).total_seconds()
        
        return TrajectoryResponse(
            success=False,
            message="处理失败",
            trajectory=[],
            num_points=0,
            start_point=[actual_start_x, actual_start_y],
            processing_time_seconds=processing_time,
            error=str(e)
        )
        
    finally:
        # 清理临时目录
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
            print(f"🧹 临时目录已清理: {temp_dir}")
        except Exception as e:
            print(f"⚠️ 清理临时目录失败: {e}")


@app.post("/api/trajectory/file")
async def plan_trajectory_from_file(
    image_path: str = Form(..., description="服务器上的图像文件路径"),
    instruction: str = Form(..., description="自然语言指令"),
    
    # 其他参数与 /api/trajectory 相同
    start_x: int = Form(310),
    start_y: int = Form(450),
    distance_threshold: float = Form(5.0),
    skip_postprocess: bool = Form(False),
    filter_floor: bool = Form(False),
    render_all_views: bool = Form(False),
    view_index: int = Form(-1),
    yaw_offset: float = Form(0.0),
    camera_height: float = Form(
        None,
        description="相机高度偏移（米），默认None=自动从地板平面计算"
    ),
    pitch_down_degrees: float = Form(
        0.0,
        description="相机向下俯仰角度（度），默认 0 度（水平朝向）"
    ),
    self_reflection: bool = Form(False),
    save_trajectory_3d: bool = Form(False),
):
    """
    从服务器文件路径调用轨迹规划（不上传图像）
    
    适用于图像已经在服务器上的场景
    """
    
    if not os.path.exists(image_path):
        raise HTTPException(status_code=400, detail=f"图像文件不存在: {image_path}")
    
    # 构造伪 UploadFile 对象
    from fastapi import UploadFile
    from starlette.datastructures import UploadFile as StarletteUploadFile
    
    filename = os.path.basename(image_path)
    
    # 这里需要重新实现逻辑，或者重构上面的代码为可复用函数
    # 为简化，直接返回提示信息
    return {
        "message": "此接口需要实现代码重构，建议使用 /api/trajectory 上传图像",
        "image_path": image_path,
        "instruction": instruction
    }


@app.get("/api/status")
async def get_status():
    """获取服务状态"""
    return {
        **service_status,
        "uptime_seconds": (
            datetime.now() - datetime.fromisoformat(service_status["start_time"])
        ).total_seconds() if service_status["start_time"] else 0
    }


# ========== 启动入口 ==========

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Trajectory 2D API Server")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="监听地址")
    parser.add_argument("--port", type=int, default=9000, help="监听端口")
    parser.add_argument("--workers", type=int, default=1, help="工作进程数")
    parser.add_argument("--reload", action="store_true", help="启用热重载（开发模式）")
    
    args = parser.parse_args()
    
    print(f"\n{'='*80}")
    print(f"🚀 Trajectory 2D API Server")
    print(f"{'='*80}")
    print(f"   地址: http://{args.host}:{args.port}")
    print(f"   文档: http://{args.host}:{args.port}/docs")
    print(f"   健康检查: http://{args.host}:{args.port}/health")
    print(f"   轨迹规划: POST http://{args.host}:{args.port}/api/trajectory")
    print(f"{'='*80}\n")
    
    uvicorn.run(
        "api_server:app",
        host=args.host,
        port=args.port,
        workers=args.workers,
        reload=args.reload,
        log_level="info"
    )


if __name__ == "__main__":
    main()
