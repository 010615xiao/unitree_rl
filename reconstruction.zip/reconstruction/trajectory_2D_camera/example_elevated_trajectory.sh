#!/bin/bash
# ============================================
# 抬高轨迹点云功能 - 使用示例
# ============================================

echo "============================================================"
echo "抬高轨迹点云功能 - 使用示例"
echo "============================================================"
echo ""

# 示例 1: 使用默认相机高度（0.06m）
echo "示例 1: 使用默认相机高度（0.06m，机器人摄像头高度）"
echo "------------------------------------------------------------"
echo "命令："
echo "  python run_pipeline.py \\"
echo "      --image /path/to/image.png \\"
echo "      --instruction \"远处的垃圾桶\" \\"
echo "      --render_all_views"
echo ""
echo "输出文件："
echo "  - *_elevated_trajectory_h0.06m_*.ply"
echo ""

# 示例 2: 使用人眼高度（0.5m）
echo "示例 2: 使用人眼高度（0.5m，推荐用于可视化）"
echo "------------------------------------------------------------"
echo "命令："
echo "  python run_pipeline.py \\"
echo "      --image /path/to/image.png \\"
echo "      --instruction \"远处的垃圾桶\" \\"
echo "      --camera_height 0.5 \\"
echo "      --render_all_views \\"
echo "      --filter_floor"
echo ""
echo "输出文件："
echo "  - *_elevated_trajectory_h0.50m_*.ply"
echo ""

# 示例 3: 完整流程（多种高度对比）
echo "示例 3: 生成多种高度的轨迹点云（用于对比分析）"
echo "------------------------------------------------------------"
echo "命令："
echo "  # 0.3m - 低矮摄像头"
echo "  python run_pipeline.py --image img.png --instruction \"目标\" \\"
echo "      --camera_height 0.3 --render_all_views --filter_floor"
echo ""
echo "  # 0.5m - 人眼高度"
echo "  python run_pipeline.py --image img.png --instruction \"目标\" \\"
echo "      --camera_height 0.5 --render_all_views --filter_floor"
echo ""
echo "  # 1.0m - 较高的摄像头"
echo "  python run_pipeline.py --image img.png --instruction \"目标\" \\"
echo "      --camera_height 1.0 --render_all_views --filter_floor"
echo ""

# 查看点云的示例
echo "============================================================"
echo "查看生成的点云文件"
echo "============================================================"
echo ""
echo "方法 1: 使用 MeshLab"
echo "  meshlab *_elevated_trajectory_h0.50m_*.ply"
echo ""
echo "方法 2: 使用 CloudCompare"
echo "  CloudCompare *_elevated_trajectory_h0.50m_*.ply"
echo ""
echo "方法 3: 使用 Python (Open3D)"
cat << 'EOF'
  python << 'PYEOF'
import open3d as o3d

# 读取抬高轨迹点云
elevated_pcd = o3d.io.read_point_cloud("*_elevated_trajectory_h0.50m_*.ply")

# 读取场景点云
scene_pcd = o3d.io.read_point_cloud("*_full_pointcloud.ply")

# 可视化（叠加查看）
o3d.visualization.draw_geometries([scene_pcd, elevated_pcd])
PYEOF
EOF

echo ""
echo "============================================================"
echo "颜色说明"
echo "============================================================"
echo "  🟢 绿色点 = 起点（机器人起始位置）"
echo "  🔴 红色点 = 终点（机器人最终位置）"
echo "  ⚪ 彩色点 = 中间点（从原始图像获取真实颜色）"
echo ""
echo "============================================================"
echo "坐标系统（相机坐标系）"
echo "============================================================"
echo "  X 轴：向右为正"
echo "  Y 轴：向下为正（抬高 = Y 值减小）"
echo "  Z 轴：向前为正（深度方向）"
echo ""
echo "============================================================"
