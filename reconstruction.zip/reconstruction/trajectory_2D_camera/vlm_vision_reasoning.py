#!/usr/bin/env python3
"""
两阶段 VLM 意图识别模块

架构:
    阶段 1: VLMVisionReasoner - 视觉意图推理（图像 + 指令 → 结构化意图）
    阶段 2: AdaptiveDetector - 自适应 GroundingDINO 检测（按优先级检测，找到即停）
    阶段 3: VLMDisambiguator - 多目标消歧选择（VLM 基于视觉上下文选最优）

与现有流程的兼容:
    - 输出格式与现有 VLMIntentClient 完全兼容
    - 可通过 --use_vision_intent 参数开关切换
    - 降级策略：VLM 失败时自动 fallback 到改进的规则解析

使用示例:
    from vlm_vision_reasoning import VisionIntentPipeline

    pipeline = VisionIntentPipeline()
    result = pipeline.run(image_path="test.png", instruction="找点喝的")

    if result["success"]:
        print(f"选中物体: {result['selected_detection']['phrase']}")
        print(f"检测框: {result['selected_box']}")
"""

import os
import re
import json
import cv2
import numpy as np
from typing import Dict, Any, Optional, List, Tuple
from openai import OpenAI

# 导入现有模块
from pointcloud_segmentation_http import GroundingDINOClient

# ============== 配置常量 ==============
BOX_THRESHOLD = 0.30
TEXT_THRESHOLD = 0.20
GROUNDING_DINO_HOST = "localhost"
GROUNDING_DINO_PORT = 20021

# VLM 配置
VLM_BASE_URL = "http://localhost:8011/v1"
VLM_MODEL = "RoboBrain2.5-8B"
VLM_MAX_RETRIES = 2
VLM_TEMPERATURE = 0.1
VLM_TIMEOUT = 120

# 有效属性值（与现有 _validate_intent 保持一致）
VALID_DEPTH_ATTRS = ("nearest", "farthest")
VALID_POSITION_ATTRS = ("left", "right", "center", "center_left", "center_right")
VALID_TASK_TYPES = ("simple_selection", "relational_selection", "ordinal_selection", "combined_selection")
VALID_RELATION_TYPES = ("closest_to", "farthest_from", "next_to", "nearest_to", "left_of", "right_of")


# ============== 工具函数 ==============

def _validate_spatial_attributes(attrs: Dict[str, Any]) -> Dict[str, Any]:
    """校验并规范化空间属性"""
    # 规范化 depth_attribute
    depth = attrs.get("depth_attribute")
    if depth is not None and depth not in VALID_DEPTH_ATTRS:
        mapping = {
            "near": "nearest", "close": "nearest", "close_to": "nearest", "nearby": "nearest",
            "far": "farthest", "further": "farthest", "distant": "farthest", "away": "farthest"
        }
        attrs["depth_attribute"] = mapping.get(depth.lower(), None)

    # 规范化 position_attribute
    pos = attrs.get("position_attribute")
    if pos is not None and pos not in VALID_POSITION_ATTRS:
        mapping = {
            "l": "left", "r": "right", "middle": "center", "central": "center",
            "center_left": "center_left", "center_right": "center_right",
            "mid_left": "center_left", "mid_right": "center_right",
            "left_side": "left", "right_side": "right"
        }
        attrs["position_attribute"] = mapping.get(pos.lower(), None)

    # 规范化 relation_type
    rel = attrs.get("relation_type")
    if rel is not None and rel not in VALID_RELATION_TYPES:
        mapping = {
            "near": "closest_to", "close": "closest_to", "far": "farthest_from",
            "left": "left_of", "right": "right_of",
            "left_of": "left_of", "right_of": "right_of",
            "beside": "next_to", "next": "next_to"
        }
        attrs["relation_type"] = mapping.get(rel.lower(), None)

    # 确保 ordinal 为正整数
    if not isinstance(attrs.get("ordinal"), int) or attrs.get("ordinal", 1) < 1:
        attrs["ordinal"] = 1

    return attrs


def _extract_json_from_text(text: str) -> Optional[Dict[str, Any]]:
    """从 VLM 输出文本中提取 JSON"""
    if not text:
        return None

    # 尝试提取 ```json ... ``` 块
    if "```json" in text:
        try:
            json_str = text.split("```json")[1].split("```")[0].strip()
            return json.loads(json_str)
        except (json.JSONDecodeError, IndexError):
            pass

    # 尝试提取 ``` ... ``` 块
    if "```" in text:
        try:
            json_str = text.split("```")[1].split("```")[0].strip()
            return json.loads(json_str)
        except (json.JSONDecodeError, IndexError):
            pass

    # 尝试从纯文本中提取第一个 {...} 块
    match = re.search(r'\{.*\}', text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass

    return None


def _rule_based_parse_v2(instruction: str) -> Dict[str, Any]:
    """
    改进的规则解析（V2 版本）

    与现有 _rule_based_parse 相比:
    - 统一输出英文物体名（通过简单映射表）
    - 支持更多关键词模式（包括需求型指令）
    - 输出格式与 VLM 一致
    """
    instruction_lower = instruction.lower()

    # ========== 需求型指令识别（新增） ==========
    # 当检测到需求型指令时，直接推断目标物体
    need_based_mappings = {
        # 休息相关
        "我想休息": ("bed", "需求型指令：休息 → bed"),
        "休息": ("bed", "需求型指令：休息 → bed"),
        "我想睡觉": ("bed", "需求型指令：睡觉 → bed"),
        "睡觉": ("bed", "需求型指令：睡觉 → bed"),
        "躺下": ("bed", "需求型指令：躺下 → bed"),
        "想坐": ("sofa", "需求型指令：坐 → sofa"),
        "坐下": ("sofa", "需求型指令：坐下 → sofa"),
        "沙发": ("sofa", "需求型指令：沙发 → sofa"),
        # 饮食相关
        "我饿了": ("food", "需求型指令：饿 → food"),
        "饿了": ("food", "需求型指令：饿 → food"),
        "找点喝的": ("drink", "需求型指令：喝 → drink"),
        "口渴": ("drink", "需求型指令：渴 → drink"),
        "喝水": ("water bottle", "需求型指令：喝水 → water bottle"),
        "吃饭": ("food", "需求型指令：吃饭 → food"),
        "食物": ("food", "需求型指令：食物 → food"),
        "冰箱": ("refrigerator", "需求型指令：冰箱 → refrigerator"),
        # 工作相关
        "我想工作": ("laptop", "需求型指令：工作 → laptop"),
        "工作": ("laptop", "需求型指令：工作 → laptop"),
        "电脑": ("laptop", "需求型指令：电脑 → laptop"),
        "写字": ("desk", "需求型指令：写字 → desk"),
        "办公桌": ("desk", "需求型指令：办公桌 → desk"),
        # 娱乐相关
        "看电视": ("tv", "需求型指令：看电视 → tv"),
        "玩游戏": ("game console", "需求型指令：玩游戏 → game console"),
        "娱乐": ("tv", "需求型指令：娱乐 → tv"),
    }

    inferred_target = None
    inferred_reason = None
    for keyword, (target, reason) in need_based_mappings.items():
        if keyword in instruction_lower:
            inferred_target = target
            inferred_reason = reason
            break

    # 深度属性
    depth_attr = None
    if any(w in instruction_lower for w in ["farthest", "furthest", "最远", "远处的", "远端的", "靠后的"]):
        depth_attr = "farthest"
    elif any(w in instruction_lower for w in ["nearest", "closest", "最近", "近处的", "近端的", "旁边的", "附近的", "靠前的", "面前的"]):
        depth_attr = "nearest"

    # 位置属性（5 区域）
    position_attr = None
    if any(w in instruction_lower for w in ["中间偏左", "中间靠左", "左中", "中左"]):
        position_attr = "center_left"
    elif any(w in instruction_lower for w in ["中间偏右", "中间靠右", "右中", "中右"]):
        position_attr = "center_right"
    elif any(w in instruction_lower for w in ["left", "左边", "左侧", "左边的", "左面"]):
        position_attr = "left"
    elif any(w in instruction_lower for w in ["right", "右边", "右侧", "右边的", "右面"]):
        position_attr = "right"
    elif any(w in instruction_lower for w in ["center", "中间", "中央", "中间的", "中部"]):
        position_attr = "center"

    # 序数词
    ordinal = 1
    ordinals = {
        "first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5, "sixth": 6, "seventh": 7, "eighth": 8, "ninth": 9, "tenth": 10,
        "第 1 个": 1, "第 2 个": 2, "第 3 个": 3, "第 4 个": 4, "第 5 个": 5,
        "第一个": 1, "第二个": 2, "第三个": 3, "第四个": 4, "第五个": 5,
        "第1个": 1, "第2个": 2, "第3个": 3, "第4个": 4, "第5个": 5,
        "倒数第一": -1, "倒数第二": -2, "倒数第三": -3, "最后一个": -1,
    }
    for key, val in ordinals.items():
        if key in instruction_lower:
            ordinal = val
            break

    # 关系型查询
    relation_type = None
    reference_object = None
    rel_patterns = [
        (r"(.+?)\s*(的\s*)?(左边|左侧|左面|left\s*of)\s*(的)?\s*", "left_of"),
        (r"(.+?)\s*(的\s*)?(右边|右侧|右面|right\s*of)\s*(的)?\s*", "right_of"),
        (r"(离|距离)\s*(.+?)\s*(最近|closest|nearest)", "closest_to"),
        (r"(离|距离)\s*(.+?)\s*(最远|farthest|furthest)", "farthest_from"),
        (r"(.+?)\s*(旁边的|附近的|旁边|附近)\s*", "next_to"),
    ]
    for pattern, rel in rel_patterns:
        match = re.search(pattern, instruction_lower)
        if match:
            relation_type = rel
            groups = match.groups()
            for g in groups:
                if g and g not in ("最近", "最远", "closest", "nearest", "farthest", "furthest",
                                   "离", "距离", "旁边的", "附近的", "旁边", "附近",
                                   "左边", "右侧", "右边", "左侧", "左面", "右面",
                                   "left of", "right of", "的", "的 ", None):
                    reference_object = g.strip().rstrip("的")
                    break

    # 目标物体提取（改进：保留关键修饰词）
    # 优先使用需求型指令推断的目标
    if inferred_target:
        target = inferred_target
        reasoning_text = inferred_reason
    else:
        target = _extract_target_v2(instruction)
        reasoning_text = "规则解析 (V2)"

    # 确定 task_type
    has_depth = depth_attr is not None
    has_position = position_attr is not None
    has_ordinal = ordinal > 1
    has_relation = relation_type is not None
    attr_count = sum([has_depth, has_position, has_ordinal, has_relation])

    if has_relation:
        task_type = "relational_selection"
    elif attr_count >= 2:
        task_type = "combined_selection"
    elif has_ordinal:
        task_type = "ordinal_selection"
    elif inferred_target:
        task_type = "need_based_selection"
    else:
        task_type = "simple_selection"

    return {
        "task_type": task_type,
        "target_objects": [target],
        "reference_object": reference_object,
        "relation_type": relation_type,
        "ordinal": ordinal,
        "depth_attribute": depth_attr,
        "position_attribute": position_attr,
        "confidence": 0.7,
        "reasoning": reasoning_text,
        # 新字段（与 VLM 输出一致）
        "task_goal": f"找到指令中描述的物体: {target}",
        "instruction_type": "need_based" if inferred_target else "explicit",
        "expected_count": None,
    }


def _extract_target_v2(instruction: str) -> str:
    """
    改进的目标物体提取（V2 版本）
    
    与现有 _extract_target 相比:
    - 保留关键修饰词（颜色、材质等）
    - 输出英文（通过简单映射表）
    """
    target = instruction.strip()

    # 常见中英文物体映射表
    object_mapping = {
        "垃圾桶": "trash can", "垃圾": "trash can", "垃圾桶的": "trash can",
        "椅子": "chair", "椅": "chair", "椅子的": "chair",
        "桌子": "table", "桌": "table", "桌子的": "table",
        "饮水机": "water dispenser", "饮水机": "water dispenser",
        "水瓶": "water bottle", "矿泉水": "water bottle",
        "杯子": "cup", "水杯": "cup",
        "沙发": "sofa", "沙发": "sofa",
        "床": "bed",
        "电脑": "computer", "电脑": "computer",
        "显示器": "monitor",
        "键盘": "keyboard",
        "花盆": "flower pot", "花": "flower pot",
        "柜子": "cabinet", "抽屉": "cabinet",
        "灯": "lamp", "台灯": "lamp",
        "门": "door",
        "窗户": "window",
        "箱子": "box", "盒子": "box",
        "tent": "tent", "帐篷": "tent",
        "floor": "floor", "地板": "floor", "地面": "floor",
    }

    # 尝试直接匹配映射表
    for cn, en in object_mapping.items():
        if cn in target:
            return en

    # 如果未匹配到映射，尝试提取核心名词
    # 移除关系模式
    rel_patterns = [
        r"离\s*.+?\s*(最近|最远|closest|farthest|nearest|furthest)\s*(的)?\s*",
        r"距离\s*.+?\s*(最近|最远|closest|farthest|nearest|furthest)\s*(的)?\s*",
        r"closest\s*to\s*.+?\s*",
        r"farthest\s*from\s*.+?\s*",
        r"nearest\s*to\s*.+?\s*",
    ]
    for pattern in rel_patterns:
        target = re.sub(pattern, "", target, flags=re.IGNORECASE)

    # 移除常见修饰语前缀
    modifiers = [
        "最近的", "最远的", "近处的", "远处的", "近端的", "远端的", "旁边的", "附近的",
        "farthest ", "furthest ", "nearest ", "closest ",
        "左边的", "右边的", "中间的", "左侧的", "右侧的", "中央的",
        "left ", "right ", "center ", "middle ",
        "第一个", "第二个", "第三个", "第四个", "第五个",
        "第 1 个", "第 2 个", "第 3 个", "第 4 个", "第 5 个",
        "first ", "second ", "third ", "fourth ", "fifth ",
        "那个", "这个", "这些", "那些",
        "the ", "a ", "an ", "that ", "this "
    ]
    for mod in modifiers:
        if target.startswith(mod):
            target = target[len(mod):]
            break

    # 中文"X 的 Y"模式 → 取 Y（但保留颜色等关键修饰词）
    if "的" in target:
        parts = target.split("的")
        # 如果第一部分包含颜色/材质等，保留
        color_modifiers = ["黑色", "白色", "红色", "蓝色", "绿色", "灰色", "棕色", "黄色", "紫色"]
        material_modifiers = ["木质", "金属", "塑料", "玻璃", "陶瓷"]
        
        kept_mods = []
        for mod in color_modifiers + material_modifiers:
            if mod in parts[0]:
                kept_mods.append(mod)
        
        # 取最后部分
        target = parts[-1]
        
        # 如果有保留的修饰词，拼接到前面
        if kept_mods:
            target = " ".join(kept_mods) + " " + target

    # 英文多词处理（取最后两个词）
    if " " in target:
        words = target.split()
        if len(words) >= 2:
            target = " ".join(words[-2:])
        else:
            target = words[-1]

    target = target.strip()
    if not target:
        target = "object"

    return target


# ============== 阶段 1: VLMVisionReasoner ==============

class VLMVisionReasoner:
    """
    阶段 1：VLM 视觉意图推理
    
    利用 VLM 的多模态能力，结合图像和指令，输出结构化的意图分析
    
    与现有 VLMIntentClient 的区别:
    - 真正利用图像进行视觉推理（而非仅作文本转换）
    - 支持模糊指令（如"找点喝的"）
    - 输出英文物体名，与 GroundingDINO 一致
    """

    def __init__(
        self,
        base_url: str = VLM_BASE_URL,
        model: str = VLM_MODEL,
        max_retries: int = VLM_MAX_RETRIES,
        temperature: float = VLM_TEMPERATURE,
        timeout: int = VLM_TIMEOUT
    ):
        self.client = OpenAI(base_url=base_url, api_key="not-needed")
        self.model = model
        self.max_retries = max_retries
        self.temperature = temperature
        self.timeout = timeout
        self._image_cache: Dict[str, str] = {}

        print(f"🧠 VLMVisionReasoner 已初始化")
        print(f"   模型: {model} @ {base_url}")

    def health_check(self) -> Tuple[bool, str]:
        """检查 VLM 服务状态"""
        try:
            models = self.client.models.list()
            return True, f"服务正常，可用模型: {[m.id for m in models.data]}"
        except Exception as e:
            return False, f"VLM 服务不可用: {str(e)}"

    def _encode_image(self, image_path: str) -> str:
        """编码图像为 base64，带缓存"""
        if image_path in self._image_cache:
            return self._image_cache[image_path]
        import base64
        with open(image_path, "rb") as f:
            encoded = base64.b64encode(f.read()).decode('utf-8')
        self._image_cache[image_path] = encoded
        return encoded

    def _build_prompt(self, instruction: str) -> str:
        """构建视觉推理 Prompt"""
        return f"""你是一个智能具身 Agent 的意图理解模块。你将看到一张场景图像和一条用户指令。

你的任务:
1. **理解任务目标**: 分析用户指令，理解用户真正想做什么
2. **识别相关物体**: 在图像中找出能完成该任务的物体（必须用英文命名）
3. **提取空间属性**: 如果指令中包含位置/深度/序数/关系信息，提取出来

指令类型识别:
- "explicit"（明确型）: "最近的椅子"、"左边的桌子"、"第二个垃圾桶" → 有明确目标物+空间属性
- "need_based"（需求型）: "找点喝的"、"我想休息" → 需要推理出相关物体
- "action_based"（动作型）: "去那边"、"往前走" → 需要理解方向/位置
- "exploration"（探索型）: "看看有什么" → 需要列举场景中的物体

空间属性提取:
- 深度: "最近/nearest" → depth_attribute="nearest"; "最远/farthest" → "farthest"
- 位置: "左边" → "left"; "右边" → "right"; "中间" → "center"; "中间偏左" → "center_left"; "中间偏右" → "center_right"
- 序数: "第一个" → ordinal=1; "第二个" → ordinal=2
- 关系: "X 旁边" → reference_object=X, relation_type="next_to"; "X 左边" → reference_object=X, relation_type="left_of"

输出要求:
请输出 JSON 格式，包含以下字段:
- task_goal: 任务目标（自然语言描述，中文）
- instruction_type: 指令类型 ("explicit" / "need_based" / "action_based" / "exploration")
- target_objects: 相关物体列表，每个包含 {{
    "name": 英文名（如 "water dispenser", "chair", "trash can"）,
    "priority": 优先级（1=最高，数字越小越优先检测）,
    "reason": 为什么这个物体相关（中文）
  }}
- spatial_attributes: 空间属性 {{
    "depth_attribute": "nearest" | "farthest" | null,
    "position_attribute": "left" | "right" | "center" | "center_left" | "center_right" | null,
    "ordinal": int（默认 1）,
    "relation_type": "closest_to" | "farthest_from" | "next_to" | "left_of" | "right_of" | null,
    "reference_object": str | null（英文）
  }}
- expected_count: 你在图像中看到的相关物体数量（如果没有或不确定，给 null）
- confidence: 你对推理结果的置信度（0.0-1.0）
- reasoning: 详细的推理过程（中文）

只输出 JSON，不要有其他内容。

用户指令: "{instruction}"
"""

    def reason(
        self,
        image_path: str,
        instruction: str
    ) -> Dict[str, Any]:
        """
        视觉意图推理（带重试和校验）
        
        输入:
            - image_path: 场景图像路径
            - instruction: 用户指令（可以是模糊的）
        
        输出:
            结构化意图字典，包含:
            - task_goal, instruction_type, target_objects, spatial_attributes,
              expected_count, confidence, reasoning
            以及兼容现有流程的字段:
            - task_type, target_objects (扁平化), depth_attribute, position_attribute,
              ordinal, relation_type, reference_object
        """
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"图像不存在: {image_path}")

        image_base64 = self._encode_image(image_path)
        prompt = self._build_prompt(instruction)

        # 打印 VLM Prompt（如果启用）
        from vlm_logger import log_vlm_call
        log_vlm_call("视觉意图推理", prompt, image_path)

        last_error = None
        for attempt in range(1, self.max_retries + 1):
            try:
                if attempt > 1:
                    print(f"   🔄 第 {attempt} 次重试 VLM 视觉意图推理...")
                    # 重试时略微提高 temperature 增加多样性
                    temp = min(self.temperature + 0.1 * (attempt - 1), 0.5)
                else:
                    temp = self.temperature

                from timing_tracker import tracker
                tracker.start("VLM", "视觉意图推理")
                try:
                    response = self.client.chat.completions.create(
                        model=self.model,
                        messages=[{"role": "user", "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}}
                        ]}],
                        max_tokens=800,
                        temperature=temp,
                        timeout=self.timeout
                    )
                finally:
                    tracker.end("VLM", "视觉意图推理")

                # 打印 VLM 原始输出（如果启用）
                from vlm_logger import log_vlm_output
                result_text = response.choices[0].message.content.strip()
                log_vlm_output("视觉意图推理", result_text)
                if not result_text:
                    raise ValueError("VLM 返回空响应")

                # 提取 JSON
                result = _extract_json_from_text(result_text)
                if result is None:
                    raise ValueError(f"无法从 VLM 输出中提取 JSON: {result_text[:200]}")

                # 校验并规范化
                result = self._validate_and_normalize(result, instruction)

                print(f"   ✅ VLM 视觉意图推理成功 (attempt {attempt})")
                print(f"   任务目标: {result.get('task_goal', 'N/A')}")
                print(f"   指令类型: {result.get('instruction_type', 'N/A')}")
                print(f"   相关物体: {[obj['name'] for obj in result.get('target_objects_dict', [])]}")
                print(f"   置信度: {result.get('confidence', 'N/A')}")

                return result

            except json.JSONDecodeError as e:
                print(f"   ⚠️ VLM 返回非 JSON 格式 (attempt {attempt}): {e}")
                last_error = e
            except Exception as e:
                print(f"   ⚠️ VLM 视觉意图推理异常 (attempt {attempt}): {e}")
                last_error = e

        # 所有重试失败，降级到规则解析
        print(f"   ⚠️ VLM 视觉意图推理 {self.max_retries} 次后失败，降级到规则解析 (V2)")
        return self.reason_with_fallback(image_path, instruction)

    def reason_with_fallback(
        self,
        image_path: str,
        instruction: str
    ) -> Dict[str, Any]:
        """
        带降级策略的视觉意图推理

        VLM 失败时自动 fallback 到改进的规则解析 (V2)
        """
        print(f"   🔄 降级到规则解析 (V2)...")
        result = _rule_based_parse_v2(instruction)
        
        # 转换为字典格式
        target = result["target_objects"][0] if isinstance(result["target_objects"], list) else result["target_objects"]
        result["target_objects"] = [{"name": target, "priority": 1, "reason": "规则解析 (V2)"}]
        
        # 添加兼容字段
        result["target_objects_dict"] = result["target_objects"]
        result["target_objects"] = [target]  # 扁平化版本
        result["original_instruction"] = instruction
        result["fallback_used"] = True
        result["vlm_model"] = self.model
        result["task_type"] = result.get("task_type", "simple_selection")
        
        return result

    def _validate_and_normalize(
        self,
        result: Dict[str, Any],
        instruction: str
    ) -> Dict[str, Any]:
        """校验并规范化 VLM 输出"""
        # 确保必需字段存在
        if "target_objects" not in result or not result.get("target_objects"):
            result["target_objects"] = [{"name": "object", "priority": 1, "reason": "默认目标"}]

        # 确保 target_objects 格式正确
        for i, obj in enumerate(result["target_objects"]):
            if isinstance(obj, str):
                result["target_objects"][i] = {"name": obj, "priority": 1, "reason": ""}
            elif "name" not in obj:
                result["target_objects"][i]["name"] = "object"
            if "priority" not in obj:
                result["target_objects"][i]["priority"] = 1
            if "reason" not in obj:
                result["target_objects"][i]["reason"] = ""

        # 校验 spatial_attributes
        spatial = result.get("spatial_attributes", {})
        spatial = _validate_spatial_attributes(spatial)
        result["spatial_attributes"] = spatial

        # 扁平化输出（兼容现有流程）
        result["task_type"] = self._infer_task_type(result)
        result["depth_attribute"] = spatial.get("depth_attribute")
        result["position_attribute"] = spatial.get("position_attribute")
        result["ordinal"] = spatial.get("ordinal", 1)
        result["relation_type"] = spatial.get("relation_type")
        result["reference_object"] = spatial.get("reference_object")

        # 保留 target_objects 的字典格式（内部使用），同时提供扁平化版本（兼容旧流程）
        target_objects_dicts = result["target_objects"]  # 先保存字典版本 [{"name", "priority", "reason"}, ...]
        result["target_objects_dict"] = target_objects_dicts
        result["target_objects"] = [obj["name"] for obj in target_objects_dicts]  # 扁平化版本

        result["original_instruction"] = instruction
        result["vlm_model"] = self.model
        result["fallback_used"] = False

        # 后处理：规则修正（即使 VLM 返回 null，也根据指令关键词修正）
        result = self._post_process_keywords(result, instruction)

        return result

    def _infer_task_type(self, result: Dict[str, Any]) -> str:
        """从 VLM 输出推断 task_type"""
        instruction_type = result.get("instruction_type", "explicit")
        spatial = result.get("spatial_attributes", {})

        has_depth = spatial.get("depth_attribute") is not None
        has_position = spatial.get("position_attribute") is not None
        has_ordinal = spatial.get("ordinal", 1) > 1
        has_relation = spatial.get("relation_type") is not None
        attr_count = sum([has_depth, has_position, has_ordinal, has_relation])

        if instruction_type == "need_based" or instruction_type == "exploration":
            return "simple_selection"  # 需求型/探索型默认为简单选择
        elif has_relation:
            return "relational_selection"
        elif attr_count >= 2:
            return "combined_selection"
        elif has_ordinal:
            return "ordinal_selection"
        else:
            return "simple_selection"

    def _post_process_keywords(
        self,
        result: Dict[str, Any],
        instruction: str
    ) -> Dict[str, Any]:
        """后处理：根据指令关键词修正属性"""
        instruction_lower = instruction.lower()

        if result.get("depth_attribute") is None:
            if any(w in instruction_lower for w in ["nearest", "closest", "最近", "近处的", "近端的", "旁边的", "附近的"]):
                result["depth_attribute"] = "nearest"
                print(f"   🔄 修正 depth_attribute: null → 'nearest' (指令包含关键词)")
            elif any(w in instruction_lower for w in ["farthest", "furthest", "最远", "远处的", "远端的"]):
                result["depth_attribute"] = "farthest"
                print(f"   🔄 修正 depth_attribute: null → 'farthest' (指令包含关键词)")

        if result.get("position_attribute") is None:
            if any(w in instruction_lower for w in ["中间偏左", "中间靠左", "左中", "中左"]):
                result["position_attribute"] = "center_left"
                print(f"   🔄 修正 position_attribute: null → 'center_left' (指令包含关键词)")
            elif any(w in instruction_lower for w in ["中间偏右", "中间靠右", "右中", "中右"]):
                result["position_attribute"] = "center_right"
                print(f"   🔄 修正 position_attribute: null → 'center_right' (指令包含关键词)")
            elif any(w in instruction_lower for w in ["left", "左边", "左侧", "最左"]):
                result["position_attribute"] = "left"
                print(f"   🔄 修正 position_attribute: null → 'left' (指令包含关键词)")
            elif any(w in instruction_lower for w in ["right", "右边", "右侧", "最右"]):
                result["position_attribute"] = "right"
                print(f"   🔄 修正 position_attribute: null → 'right' (指令包含关键词)")
            elif any(w in instruction_lower for w in ["center", "中间", "中央"]):
                result["position_attribute"] = "center"
                print(f"   🔄 修正 position_attribute: null → 'center' (指令包含关键词)")

        return result


# ============== 阶段 2: AdaptiveDetector ==============

class AdaptiveDetector:
    """
    阶段 2：自适应 GroundingDINO 检测
    
    按优先级依次检测，找到即停（可选）
    """

    def __init__(
        self,
        host: str = GROUNDING_DINO_HOST,
        port: int = GROUNDING_DINO_PORT,
        stop_on_first_match: bool = True
    ):
        self.client = GroundingDINOClient(host=host, port=port)
        self.stop_on_first_match = stop_on_first_match

        print(f"🔍 AdaptiveDetector 已初始化（HTTP 版本）")
        print(f"   服务器: {host}:{port}")
        print(f"   找到即停: {stop_on_first_match}")

    def detect(
        self,
        image_path: str,
        target_objects: List[Dict[str, Any]],
        box_threshold: float = BOX_THRESHOLD,
        text_threshold: float = TEXT_THRESHOLD
    ) -> Dict[str, List[Dict]]:
        """
        按优先级依次检测目标物体
        
        输入:
            - image_path: 图像路径
            - target_objects: VLM 输出的相关物体列表
              [{"name": "water dispenser", "priority": 1, "reason": "..."}, ...]
            - box_threshold, text_threshold: GroundingDINO 阈值
        
        输出:
            {
                "water dispenser": [det1, det2, ...],
                "water bottle": [det3, det4, ...]
            }
        """
        if not target_objects:
            print("   ⚠️ target_objects 为空，跳过检测")
            return {}

        # 按优先级排序
        sorted_objects = sorted(target_objects, key=lambda x: x.get("priority", 999))

        all_detections = {}
        detected_any = False

        print(f"\n🔍 开始自适应检测 ({len(sorted_objects)} 个目标类)...")
        for obj_info in sorted_objects:
            obj_name = obj_info.get("name", "object")
            priority = obj_info.get("priority", 999)
            reason = obj_info.get("reason", "")

            print(f"   [{priority}] 检测 '{obj_name}' (原因: {reason})...")

            try:
                detections = self._detect_single(
                    image_path, obj_name, box_threshold, text_threshold
                )

                if detections:
                    all_detections[obj_name] = detections
                    detected_any = True
                    print(f"   ✅ 检测到 {len(detections)} 个 '{obj_name}'")

                    # 策略：如果已找到最高优先级物体，可选择停止
                    if self.stop_on_first_match and priority == 1:
                        print(f"   🛑 找到最高优先级物体，停止后续检测")
                        break
                else:
                    print(f"   ⚠️ 未检测到 '{obj_name}'")

            except Exception as e:
                print(f"   ❌ 检测 '{obj_name}' 异常: {e}")

        if not detected_any:
            print(f"   ⚠️ 所有目标类均未检测到")
        else:
            total = sum(len(dets) for dets in all_detections.values())
            print(f"   📊 共检测到 {total} 个检测框 ({len(all_detections)} 个类别)")

        return all_detections

    def _detect_single(
        self,
        image_path: str,
        target_object: str,
        box_threshold: float,
        text_threshold: float
    ) -> List[Dict]:
        """检测单个目标物体，转换为现有格式"""
        result = self.client.detect(
            image_path=image_path,
            text_prompt=target_object,
            box_threshold=box_threshold,
            text_threshold=text_threshold
        )

        detections = []
        for i, box in enumerate(result.get("boxes", [])):
            x1, y1, x2, y2 = box
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            detections.append({
                "box": box,
                "confidence": result["scores"][i] if i < len(result["scores"]) else 0.0,
                "phrase": result["labels"][i] if i < len(result["labels"]) else target_object,
                "center_x": center_x,
                "center_y": center_y,
                "object_class": target_object  # 添加物体类标记
            })

        return detections


# ============== 阶段 3: VLMDisambiguator ==============

class VLMDisambiguator:
    """
    阶段 3：VLM 多目标消歧选择
    
    当有多个候选目标时，让 VLM 基于视觉上下文选择最优
    """

    def __init__(
        self,
        base_url: str = VLM_BASE_URL,
        model: str = VLM_MODEL,
        max_retries: int = VLM_MAX_RETRIES,
        temperature: float = VLM_TEMPERATURE,
        timeout: int = VLM_TIMEOUT,
        output_dir: Optional[str] = None
    ):
        self.client = OpenAI(base_url=base_url, api_key="not-needed")
        self.model = model
        self.max_retries = max_retries
        self.temperature = temperature
        self.timeout = timeout
        self.output_dir = output_dir or "/workspace/wxd/Agent/images/trajectory_2D_results/disambiguation"
        os.makedirs(self.output_dir, exist_ok=True)

        print(f"🎯 VLMDisambiguator 已初始化")
        print(f"   模型: {model} @ {base_url}")

    def should_disambiguate(
        self,
        all_detections: Dict[str, List[Dict]],
        intent: Dict[str, Any]
    ) -> bool:
        """
        判断是否需要 VLM 消歧
        
        需要消歧的情况:
        1. 同一类物体有多个检测结果
        2. 多类物体都被检测到
        3. 指令包含空间属性需要进一步筛选
        """
        total_detections = sum(len(dets) for dets in all_detections.values())
        num_classes = len(all_detections)

        if total_detections == 0:
            return False  # 无检测，无需消歧
        if total_detections == 1:
            return False  # 单目标，直接用

        # 多目标，需要消歧
        return True

    def select_best(
        self,
        image_path: str,
        all_detections: Dict[str, List[Dict]],
        instruction: str,
        intent: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        VLM 多目标消歧选择
        
        输入:
            - image_path: 原始图像路径
            - all_detections: 所有检测结果
            - instruction: 原始指令
            - intent: VLM 阶段 1 的意图输出
        
        输出:
            {
                "selected_detection": {...},
                "selected_object_class": "water dispenser",
                "selected_global_id": 2,
                "reasoning": "选择理由"
            }
        """
        # 分配全局 ID
        all_detections_with_ids = self._assign_global_ids(all_detections)

        # 创建带编号的可视化图像
        annotated_image_path = self._create_annotated_image(image_path, all_detections_with_ids)

        # 构建 Prompt
        prompt = self._build_disambiguation_prompt(
            instruction, intent, all_detections_with_ids
        )

        # 调用 VLM 选择
        selected = self._vlm_select(
            annotated_image_path, prompt
        )

        if selected is None:
            # VLM 选择失败，使用启发式选择
            print(f"   ⚠️ VLM 消歧选择失败，使用启发式选择")
            selected = self._heuristic_select(all_detections_with_ids, intent)

        # 找到对应的检测结果
        global_id = selected.get("selected_global_id")
        selected_det = None
        for obj_class, detections in all_detections_with_ids.items():
            for det in detections:
                if det.get("global_id") == global_id:
                    selected_det = det
                    break
            if selected_det:
                break

        if selected_det is None:
            # 回退到第一个检测
            first_class = list(all_detections_with_ids.keys())[0]
            selected_det = all_detections_with_ids[first_class][0]
            selected["selected_global_id"] = selected_det.get("global_id", 1)
            selected["selected_object_class"] = first_class

        return {
            "selected_detection": selected_det,
            "selected_object_class": selected.get("selected_object_class", selected_det.get("object_class")),
            "selected_global_id": selected.get("selected_global_id"),
            "reasoning": selected.get("reasoning", "启发式选择（VLM 失败）"),
            "annotated_image_path": annotated_image_path
        }

    def _assign_global_ids(
        self,
        all_detections: Dict[str, List[Dict]]
    ) -> Dict[str, List[Dict]]:
        """为所有检测框分配全局 ID"""
        result = {}
        global_id = 1

        for obj_class, detections in all_detections.items():
            result[obj_class] = []
            for det in detections:
                det_copy = det.copy()
                det_copy["global_id"] = global_id
                result[obj_class].append(det_copy)
                global_id += 1

        return result

    def _create_annotated_image(
        self,
        image_path: str,
        all_detections: Dict[str, List[Dict]]
    ) -> str:
        """
        创建带编号检测框的可视化图像
        
        每个检测框用不同颜色 + 编号标注
        """
        image = cv2.imread(image_path)
        if image is None:
            return image_path

        # 颜色池
        colors = [
            (0, 255, 0),    # 绿色
            (255, 0, 0),    # 蓝色
            (0, 0, 255),    # 红色
            (255, 255, 0),  # 青色
            (255, 0, 255),  # 品红
            (0, 255, 255),  # 黄色
            (128, 0, 128),  # 紫色
            (255, 165, 0),  # 橙色
        ]

        global_id = 1
        for obj_class, detections in all_detections.items():
            color = colors[(global_id - 1) % len(colors)]
            for det in detections:
                x1, y1, x2, y2 = [int(v) for v in det["box"]]
                cv2.rectangle(image, (x1, y1), (x2, y2), color, 3)
                label = f"[{global_id}] {obj_class}"
                cv2.putText(image, label, (x1, y1 - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
                global_id += 1

        # 保存
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_path = os.path.join(self.output_dir, f"{base_name}_annotated.png")
        cv2.imwrite(output_path, image)
        print(f"   🖼️  标注图像已保存: {output_path}")

        return output_path

    def _build_disambiguation_prompt(
        self,
        instruction: str,
        intent: Dict[str, Any],
        all_detections: Dict[str, List[Dict]]
    ) -> str:
        """构建消歧 Prompt"""
        # 格式化检测结果
        detections_str = ""
        for obj_class, det_list in all_detections.items():
            for det in det_list:
                gid = det.get("global_id", "?")
                conf = det.get("confidence", 0.0)
                cx, cy = det.get("center_x", 0), det.get("center_y", 0)
                depth = det.get("depth", "N/A")
                detections_str += f"  [{gid}] {obj_class} (conf={conf:.2f}, center=({cx:.0f},{cy:.0f}), depth={depth})\n"

        spatial = intent.get("spatial_attributes", {})

        return f"""你是一个智能具身 Agent 的决策模块。

用户指令: "{instruction}"

你已经在图像中检测到以下物体（见标注图像，每个检测框有编号 [ID]）:
{detections_str}

空间属性要求:
- depth_attribute: {spatial.get('depth_attribute', 'N/A')}
- position_attribute: {spatial.get('position_attribute', 'N/A')}
- relation_type: {spatial.get('relation_type', 'N/A')}
- reference_object: {spatial.get('reference_object', 'N/A')}

任务:
从所有检测框中选择最符合用户指令的一个。

考虑因素:
1. 任务目标匹配度：哪个物体最能完成用户的任务？
2. 空间属性：如果指令要求"最近的"，选择深度最近的；如果要求"左边的"，选择位置最左的
3. 检测置信度：GroundingDINO 的 confidence 分数

请输出 JSON:
- selected_global_id: 选中的检测框编号（int）
- selected_object_class: 选中的物体类名（英文）
- confidence: 选择置信度（0.0-1.0）
- reasoning: 选择理由（中文）

只输出 JSON。"""

    def _vlm_select(
        self,
        annotated_image_path: str,
        prompt: str
    ) -> Optional[Dict[str, Any]]:
        """调用 VLM 进行消歧选择"""
        image_base64 = self._encode_image(annotated_image_path)

        from timing_tracker import tracker

        for attempt in range(1, self.max_retries + 1):
            try:
                # 打印 VLM Prompt（如果启用）
                from vlm_logger import log_vlm_call
                log_vlm_call("多目标消歧", prompt)

                tracker.start("VLM", "多目标消歧")
                try:
                    response = self.client.chat.completions.create(
                        model=self.model,
                        messages=[{"role": "user", "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}}
                        ]}],
                        max_tokens=400,
                        temperature=self.temperature,
                        timeout=self.timeout
                    )
                finally:
                    tracker.end("VLM", "多目标消歧")

                # 打印 VLM 原始输出（如果启用）
                from vlm_logger import log_vlm_output
                result_text = response.choices[0].message.content.strip()
                log_vlm_output("多目标消歧", result_text)
                if not result_text:
                    raise ValueError("VLM 返回空响应")

                result = _extract_json_from_text(result_text)
                if result is None:
                    raise ValueError(f"无法提取 JSON: {result_text[:200]}")

                # 校验必需字段
                if "selected_global_id" not in result:
                    raise ValueError(f"缺少 selected_global_id: {result}")

                return result

            except Exception as e:
                print(f"   ⚠️ VLM 消歧选择异常 (attempt {attempt}): {e}")

        return None

    def _heuristic_select(
        self,
        all_detections: Dict[str, List[Dict]],
        intent: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        启发式选择（VLM 失败时的降级方案）
        
        策略:
        1. 如果有 depth_attribute，按深度排序选择
        2. 如果有 position_attribute，按位置排序选择
        3. 否则选择检测置信度最高的
        """
        # 收集所有检测结果
        all_dets = []
        for obj_class, det_list in all_detections.items():
            for det in det_list:
                det_copy = det.copy()
                det_copy["object_class"] = obj_class
                all_dets.append(det_copy)

        if not all_dets:
            return {"selected_global_id": 1, "reasoning": "无检测结果"}

        spatial = intent.get("spatial_attributes", {})

        # 按深度属性选择
        if spatial.get("depth_attribute") == "nearest":
            # 选深度最近的
            all_dets.sort(key=lambda d: d.get("depth", float("inf")))
        elif spatial.get("depth_attribute") == "farthest":
            # 选深度最远的
            all_dets.sort(key=lambda d: -d.get("depth", 0))
        elif spatial.get("position_attribute") == "left":
            # 选最左的
            all_dets.sort(key=lambda d: d.get("center_x", 0))
        elif spatial.get("position_attribute") == "right":
            # 选最右的
            all_dets.sort(key=lambda d: -d.get("center_x", 0))
        else:
            # 选检测置信度最高的
            all_dets.sort(key=lambda d: -d.get("confidence", 0))

        selected = all_dets[0]
        return {
            "selected_global_id": selected.get("global_id", 1),
            "selected_object_class": selected.get("object_class"),
            "confidence": 0.5,
            "reasoning": f"启发式选择（VLM 失败）: 按 {'depth' if spatial.get('depth_attribute') else 'position' if spatial.get('position_attribute') else 'confidence'} 排序"
        }

    def _encode_image(self, image_path: str) -> str:
        """编码图像为 base64"""
        import base64
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode('utf-8')


# ============== 统一流水线: VisionIntentPipeline ==============

class VisionIntentPipeline:
    """
    统一流水线，协调三个阶段
    
    与现有 PointCloudSegmentationPipeline 兼容:
    - 输出结构包含现有代码期望的所有字段
    - 可通过参数开关切换新旧流程
    """

    def __init__(
        self,
        vlm_base_url: str = VLM_BASE_URL,
        vlm_model: str = VLM_MODEL,
        grounding_dino_host: str = GROUNDING_DINO_HOST,
        grounding_dino_port: int = GROUNDING_DINO_PORT,
        stop_on_first_match: bool = True,
        disambiguation_output_dir: Optional[str] = None
    ):
        self.vision_reasoner = VLMVisionReasoner(base_url=vlm_base_url, model=vlm_model)
        self.detector = AdaptiveDetector(
            host=grounding_dino_host,
            port=grounding_dino_port,
            stop_on_first_match=stop_on_first_match
        )
        self.disambiguator = VLMDisambiguator(
            base_url=vlm_base_url,
            model=vlm_model,
            output_dir=disambiguation_output_dir
        )

        print(f"\n📦 VisionIntentPipeline 已初始化")
        print(f"   VLM: {vlm_model} @ {vlm_base_url}")
        print(f"   GroundingDINO: {grounding_dino_host}:{grounding_dino_port}")
        print(f"   找到即停: {stop_on_first_match}")

    def run(
        self,
        image_path: str,
        instruction: str
    ) -> Dict[str, Any]:
        """
        运行完整的意图识别流程
        
        输出:
            {
                "success": bool,
                "intent": {...},                  # 阶段 1 输出
                "all_detections": {...},          # 阶段 2 输出
                "selected_detection": {...},      # 阶段 3 输出（如有）
                "selected_box": [...],            # 最终检测框 [x1, y1, x2, y2]
                "processing_steps": [...]         # 处理步骤记录
            }
        """
        result = {
            "success": False,
            "image_path": image_path,
            "instruction": instruction,
            "processing_steps": []
        }

        try:
            # ========== 阶段 1: VLM 视觉意图推理 ==========
            print("\n" + "="*70)
            print("🧠 阶段 1: VLM 视觉意图推理")
            print("="*70)

            # 调用 reason() 方法（它会先尝试 VLM，失败后自动降级）
            intent = self.vision_reasoner.reason(image_path, instruction)
            result["intent"] = intent
            result["processing_steps"].append("vision_reasoning")

            if intent.get("fallback_used"):
                print(f"   ⚠️ 使用降级策略 (规则解析 V2)")
            else:
                print(f"   ✅ VLM 视觉意图推理成功")
                print(f"   任务目标: {intent.get('task_goal', 'N/A')}")
                print(f"   指令类型: {intent.get('instruction_type', 'N/A')}")

            # ========== 阶段 2: 自适应检测 ==========
            print("\n" + "="*70)
            print("🔍 阶段 2: 自适应 GroundingDINO 检测")
            print("="*70)

            # 构建 target_objects 列表（优先使用字典版本）
            target_objects = []
            if "target_objects_dict" in intent and isinstance(intent["target_objects_dict"], list):
                # VLM 输出格式: [{"name": ..., "priority": ..., "reason": ...}, ...]
                target_objects = intent["target_objects_dict"]
            elif isinstance(intent.get("target_objects"), list):
                # 规则解析输出或其他来源
                if len(intent["target_objects"]) > 0 and isinstance(intent["target_objects"][0], dict):
                    target_objects = intent["target_objects"]
                else:
                    # 字符串列表，转换为字典
                    target_objects = [{"name": name, "priority": 1, "reason": ""} for name in intent["target_objects"]]

            all_detections = self.detector.detect(image_path, target_objects)
            result["all_detections"] = all_detections
            result["processing_steps"].append("adaptive_detection")

            if not all_detections:
                result["error"] = "No objects detected"
                print(f"   ❌ 未检测到任何目标物体")
                return result

            # ========== 阶段 3: 多目标消歧（需要时） ==========
            total_detections = sum(len(dets) for dets in all_detections.values())
            if self.disambiguator.should_disambiguate(all_detections, intent):
                print("\n" + "="*70)
                print(f"🎯 阶段 3: VLM 多目标消歧选择 ({total_detections} 个候选)")
                print("="*70)

                selected = self.disambiguator.select_best(
                    image_path, all_detections, instruction, intent
                )
                result["selected_detection"] = selected["selected_detection"]
                result["selected_box"] = selected["selected_detection"]["box"]
                result["selected_object_class"] = selected["selected_object_class"]
                result["processing_steps"].append("vlm_disambiguation")

                print(f"   ✅ 选择结果: [{selected['selected_global_id']}] {selected['selected_object_class']}")
                print(f"   理由: {selected['reasoning']}")
            else:
                # 单目标，直接用第一个检测结果
                first_class = list(all_detections.keys())[0]
                first_det = all_detections[first_class][0]
                result["selected_detection"] = first_det
                result["selected_box"] = first_det["box"]
                result["selected_object_class"] = first_class
                result["processing_steps"].append("single_target_direct")

                print(f"\n📦 单目标直接采用: {first_class}")
                print(f"   检测框: {first_det['box']}")
                print(f"   置信度: {first_det['confidence']:.3f}")

            result["success"] = True

        except Exception as e:
            print(f"\n❌ 流程执行异常: {e}")
            import traceback
            traceback.print_exc()
            result["error"] = str(e)

        print("\n" + "="*70)
        if result["success"]:
            print("✅ 意图识别流程完成!")
        else:
            print("❌ 意图识别流程失败")
        print("="*70)

        return result


# ============== 便捷函数 ==============

def run_vision_intent(
    image_path: str,
    instruction: str,
    vlm_base_url: str = VLM_BASE_URL,
    vlm_model: str = VLM_MODEL,
    grounding_dino_host: str = GROUNDING_DINO_HOST,
    grounding_dino_port: int = GROUNDING_DINO_PORT
) -> Dict[str, Any]:
    """
    便捷函数：一行调用意图识别流程
    
    使用示例:
        result = run_vision_intent("test.png", "找点喝的")
        if result["success"]:
            print(f"选中物体: {result['selected_detection']['phrase']}")
    """
    pipeline = VisionIntentPipeline(
        vlm_base_url=vlm_base_url,
        vlm_model=vlm_model,
        grounding_dino_host=grounding_dino_host,
        grounding_dino_port=grounding_dino_port
    )
    return pipeline.run(image_path, instruction)


# ============== 主函数（测试用） ==============

def main():
    """主函数（测试用）"""
    import argparse

    parser = argparse.ArgumentParser(description="两阶段 VLM 意图识别测试")
    parser.add_argument("--image", type=str, default=None, help="输入图像路径")
    parser.add_argument("--instruction", type=str, default=None, help="用户指令")
    parser.add_argument("--vlm-base-url", type=str, default=VLM_BASE_URL, help="VLM 服务地址")
    parser.add_argument("--vlm-model", type=str, default=VLM_MODEL, help="VLM 模型名称")
    parser.add_argument("--dino-host", type=str, default=GROUNDING_DINO_HOST, help="GroundingDINO 服务器主机")
    parser.add_argument("--dino-port", type=int, default=GROUNDING_DINO_PORT, help="GroundingDINO 服务器端口")

    args = parser.parse_args()

    # 交互式输入
    if args.image is None:
        default_images = [
            "/workspace/wxd/Agent/images/test_6.png",
            "/workspace/wxd/Agent/images/test_navigation_2.png",
            "/workspace/wxd/Agent/images/test_2.png",
        ]
        print("\n🖼️  请选择或输入图像路径:")
        for i, img in enumerate(default_images, 1):
            if os.path.exists(img):
                print(f"   [{i}] {img}")
        print(f"   [0] 输入其他路径")

        choice = input("\n   请选择 (0-3): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(default_images):
            image_path = default_images[int(choice) - 1]
        else:
            image_path = input("   请输入图像路径：").strip()
    else:
        image_path = args.image

    if not os.path.exists(image_path):
        print(f"❌ 图像不存在: {image_path}")
        return

    instruction = args.instruction
    if instruction is None:
        print(f"\n📷 当前图像: {image_path}")
        print("\n💬 请输入指令（示例）:")
        print("   - 找点喝的")
        print("   - 最近的椅子")
        print("   - 左边的桌子")
        print("   - 中间垃圾桶的左边的那个")
        instruction = input("\n   请输入指令：").strip()
        if not instruction:
            instruction = "找点喝的"

    print("\n" + "="*70)
    print(f"✅ 配置确认")
    print(f"   图像: {image_path}")
    print(f"   指令: {instruction}")
    print("="*70)

    # 运行流程
    result = run_vision_intent(
        image_path=image_path,
        instruction=instruction,
        vlm_base_url=args.vlm_base_url,
        vlm_model=args.vlm_model,
        grounding_dino_host=args.dino_host,
        grounding_dino_port=args.dino_port
    )

    if result["success"]:
        print("\n📊 结果摘要:")
        print(f"   选中物体: {result['selected_detection']['phrase']}")
        print(f"   检测框: {result['selected_box']}")
        print(f"   检测置信度: {result['selected_detection']['confidence']:.3f}")
        print(f"   处理步骤: {result['processing_steps']}")
        print(f"\n✅ 流程成功!")
    else:
        print(f"\n❌ 失败: {result.get('error', '未知错误')}")


if __name__ == "__main__":
    main()
