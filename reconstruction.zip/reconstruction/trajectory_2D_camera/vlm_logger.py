"""
VLM Prompt 和输出打印工具

提供统一的装饰器函数，用于收集所有 VLM 的 prompt 和原始输出。
在 run_pipeline.py 中通过 --verbose_vlm 参数启用。

使用方式:
    from vlm_logger import log_vlm_call, log_vlm_output, print_all_vlm_logs
    
    # 在 VLM 调用前记录 prompt
    log_vlm_call("意图解析", prompt, image_path)
    
    # 在 VLM 返回后记录输出
    log_vlm_output("意图解析", response_text)
    
    # 在运行结束后统一打印所有日志
    print_all_vlm_logs()
"""

import os
from typing import Optional, Dict, List
from datetime import datetime

# 全局开关：通过 set_verbose(True/False) 控制
_verbose = False

# 存储所有 VLM 调用记录
_vlm_calls: List[Dict] = []

# 当前正在记录的调用索引
_current_call_index: Optional[int] = None


def set_verbose(enabled: bool):
    """设置 VLM 日志打印开关"""
    global _verbose
    _verbose = enabled


def is_verbose() -> bool:
    """检查是否启用了详细日志"""
    return _verbose


def clear_logs():
    """清空所有日志记录"""
    global _vlm_calls, _current_call_index
    _vlm_calls = []
    _current_call_index = None


def log_vlm_call(stage_name: str, prompt: str, image_path: Optional[str] = None):
    """
    记录 VLM 调用前的 prompt 信息
    
    Args:
        stage_name: VLM 调用阶段名称（如"意图解析"、"轨迹生成"等）
        prompt: 发送给 VLM 的完整 prompt
        image_path: 输入图像路径（可选）
    """
    if not _verbose:
        return
    
    global _current_call_index
    
    # 创建新的调用记录
    call_record = {
        "stage_name": stage_name,
        "prompt": prompt,
        "image_path": image_path,
        "response_text": None,
        "success": None,
        "error": None,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    _vlm_calls.append(call_record)
    _current_call_index = len(_vlm_calls) - 1


def log_vlm_output(stage_name: str, response_text: str, success: bool = True, error: Optional[str] = None):
    """
    记录 VLM 返回的原始输出
    
    Args:
        stage_name: VLM 调用阶段名称
        response_text: VLM 返回的完整文本
        success: 是否调用成功
        error: 错误信息（如果有）
    """
    if not _verbose:
        return
    
    global _current_call_index
    
    # 更新当前调用记录
    if _current_call_index is not None and _current_call_index < len(_vlm_calls):
        _vlm_calls[_current_call_index]["response_text"] = response_text
        _vlm_calls[_current_call_index]["success"] = success
        _vlm_calls[_current_call_index]["error"] = error
    else:
        # 如果没有对应的调用记录，创建一个新的
        call_record = {
            "stage_name": stage_name,
            "prompt": None,
            "image_path": None,
            "response_text": response_text,
            "success": success,
            "error": error,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        _vlm_calls.append(call_record)


def log_vlm_full(stage_name: str, prompt: str, response_text: str, 
                 image_path: Optional[str] = None, success: bool = True, 
                 error: Optional[str] = None):
    """
    一次性记录 VLM 的完整调用信息（prompt + 输出）
    
    Args:
        stage_name: VLM 调用阶段名称
        prompt: 发送的 prompt
        response_text: VLM 返回的响应文本
        image_path: 输入图像路径（可选）
        success: 是否调用成功
        error: 错误信息（如果有）
    """
    if not _verbose:
        return
    
    call_record = {
        "stage_name": stage_name,
        "prompt": prompt,
        "response_text": response_text,
        "image_path": image_path,
        "success": success,
        "error": error,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    _vlm_calls.append(call_record)


def print_all_vlm_logs():
    """
    统一打印所有 VLM 调用日志（在运行结束后调用）
    """
    if not _verbose or not _vlm_calls:
        return
    
    print("\n\n")
    print("=" * 100)
    print("📋 VLM 调用日志汇总（共 {} 次调用）".format(len(_vlm_calls)))
    print("=" * 100)
    print("\n")
    
    for idx, record in enumerate(_vlm_calls, 1):
        stage_name = record.get("stage_name", "未知阶段")
        timestamp = record.get("timestamp", "N/A")
        image_path = record.get("image_path")
        prompt = record.get("prompt")
        response_text = record.get("response_text")
        success = record.get("success")
        error = record.get("error")
        
        # 打印调用头部
        print("=" * 100)
        print("🔹 调用 #{}: {} [{}]".format(idx, stage_name, timestamp))
        print("=" * 100)
        
        if image_path:
            print("\n📷 图像路径: {}".format(image_path))
        
        # 打印 Prompt
        if prompt:
            print("\n📤 发送的 Prompt:")
            print("-" * 100)
            print(prompt)
            print("-" * 100)
        
        # 打印输出
        if response_text is not None:
            if success:
                print("\n📥 VLM 原始输出:")
                print("-" * 100)
                print(response_text)
                print("-" * 100)
            else:
                print("\n❌ 调用失败: {}".format(error))
                if response_text:
                    print("\n📥 部分输出:")
                    print("-" * 100)
                    print(response_text)
                    print("-" * 100)
        
        # 打印分隔
        print("\n\n")
    
    # 打印总结
    print("=" * 100)
    print("📊 VLM 调用统计")
    print("=" * 100)
    
    success_count = sum(1 for r in _vlm_calls if r.get("success", False))
    fail_count = len(_vlm_calls) - success_count
    
    print("总调用次数: {}".format(len(_vlm_calls)))
    print("成功次数: {}".format(success_count))
    print("失败次数: {}".format(fail_count))
    
    # 按阶段统计
    stage_stats = {}
    for record in _vlm_calls:
        stage = record.get("stage_name", "未知")
        if stage not in stage_stats:
            stage_stats[stage] = {"total": 0, "success": 0}
        stage_stats[stage]["total"] += 1
        if record.get("success", False):
            stage_stats[stage]["success"] += 1
    
    print("\n按阶段统计:")
    for stage, stats in stage_stats.items():
        print("  - {}: {}/{} 成功".format(stage, stats["success"], stats["total"]))
    
    print("=" * 100)
    print("\n")
