#!/bin/bash
# API 调用示例脚本
# 展示如何使用更新后的 Trajectory 2D API

# 配置
API_URL="http://localhost:9000/api/trajectory"
IMAGE_PATH="${1:-/workspace/wxd/Agent/Spagent/spagent/checkpoints/trajectory_2D_camera/examples/frame_0000.png}"
INSTRUCTION="${2:-左边的椅子}"

# 检查图像文件是否存在
if [ ! -f "$IMAGE_PATH" ]; then
    echo "❌ 图像文件不存在: $IMAGE_PATH"
    echo "用法: $0 [图像路径] [指令]"
    exit 1
fi

echo "============================================================"
echo "🚀 Trajectory 2D API 调用示例"
echo "============================================================"
echo "API URL: $API_URL"
echo "图像: $IMAGE_PATH"
echo "指令: $INSTRUCTION"
echo "============================================================"

# 示例 1: 基本调用（默认参数）
echo ""
echo "📋 示例 1: 基本调用（默认参数）"
echo "   - 返回轨迹点坐标"
echo "   - 返回渲染的视角图像"
echo "   - 不返回轨迹动画"
echo ""

curl -X POST "$API_URL" \
    -F "image=@$IMAGE_PATH" \
    -F "instruction=$INSTRUCTION" \
    -o response_basic.json

echo "✅ 响应已保存到 response_basic.json"

# 提取点云分割结果（如果存在）
python3 -c "
import json
import base64
import os

with open('response_basic.json', 'r') as f:
    data = json.load(f)

if data.get('segmentation_results'):
    seg_dir = 'segmentation_results'
    os.makedirs(seg_dir, exist_ok=True)
    for filename, base64_data in data['segmentation_results'].items():
        file_bytes = base64.b64decode(base64_data)
        file_path = os.path.join(seg_dir, filename)
        with open(file_path, 'wb') as f:
            f.write(file_bytes)
        print(f'✅ 已保存: {file_path}')
    print(f'✅ 点云分割结果已保存到 {seg_dir}/ 目录')
else:
    print('⚠️ 响应中未找到点云分割结果数据')
"

# 示例 2: 带轨迹动画
echo ""
echo "🎬 示例 2: 带轨迹动画"
echo "   - 返回轨迹点坐标"
echo "   - 返回渲染的视角图像"
echo "   - 返回轨迹动画 MP4（Base64 编码）"
echo ""

curl -X POST "$API_URL" \
    -F "image=@$IMAGE_PATH" \
    -F "instruction=$INSTRUCTION" \
    -F "return_trajectory_video=true" \
    -o response_with_video.json

echo "✅ 响应已保存到 response_with_video.json"

# 提取轨迹动画（如果存在）
if python3 -c "import json; data=json.load(open('response_with_video.json')); print('视频数据存在' if data.get('trajectory_video_base64') else '视频数据不存在')" 2>/dev/null | grep -q "存在"; then
    echo "📥 正在提取轨迹动画..."
    python3 -c "
import json
import base64

with open('response_with_video.json', 'r') as f:
    data = json.load(f)

if data.get('trajectory_video_base64'):
    video_bytes = base64.b64decode(data['trajectory_video_base64'])
    with open('trajectory_animation.mp4', 'wb') as vf:
        vf.write(video_bytes)
    print('✅ 轨迹动画已提取到 trajectory_animation.mp4')
else:
    print('⚠️ 响应中未找到轨迹动画数据')
"
fi

# 示例 3: 完整参数
echo ""
echo "⚙️  示例 3: 完整参数"
echo "   - 自定义轨迹间距和平滑窗口"
echo "   - 自定义相机高度"
echo "   - 返回元数据"
echo ""

curl -X POST "$API_URL" \
    -F "image=@$IMAGE_PATH" \
    -F "instruction=$INSTRUCTION" \
    -F "filter_floor=true" \
    -F "trajectory_spacing=0.017" \
    -F "trajectory_smooth_window=5" \
    -F "camera_height=0.06" \
    -F "self_reflection=true" \
    -F "return_trajectory_video=true" \
    -F "return_metadata=true" \
    -o response_full.json

echo "✅ 响应已保存到 response_full.json"

echo ""
echo "============================================================"
echo "✅ 所有示例执行完成"
echo "============================================================"
echo "生成的文件:"
echo "  - response_basic.json     (基本响应)"
echo "  - response_with_video.json (带轨迹动画的响应)"
echo "  - response_full.json      (完整参数响应)"
echo "  - trajectory_animation.mp4 (轨迹动画，如果成功提取)"
echo "============================================================"
