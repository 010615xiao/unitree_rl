# Trajectory 2D - 点云分割与轨迹规划模块

根据检测目标，分别提取和保存场景点云、目标点云和地板点云，并规划从起点到目标的 2D 行走轨迹。

**集成导航终止判断**：在每次循环中先判断是否已到达目标，再决定是否继续轨迹规划。

## 📁 项目结构

```
trajectory_2D/
├── run_pipeline.py              # ⭐ 主运行脚本（统一流程，集成终止判断）
├── termination_checker.py       # ⭐ 导航终止判断模块
├── main.py                      # 点云分割主流程
├── sam2_client.py               # SAM2 服务器客户端
├── sam2_server.py               # SAM2 分割服务器
├── grounding_dino_server.py     # GroundingDINO 检测服务器
├── pointcloud_segmentation.py   # 点云分割模块（本地版）
├── pointcloud_segmentation_http.py  # 点云分割模块（HTTP版）
├── pointcloud_saver.py          # 点云保存和可视化
├── render_trajectory_view.py    # 新视角渲染模块
├── vlm_trajectory.py            # VLM 轨迹预测测试
├── vlm_depth_masks.py           # 深度掩码测试
├── batch_test.py                # 批量测试脚本
├── start_services.sh            # 启动所有服务
├── stop_services.sh             # 停止所有服务
├── start_vlm_server.sh          # 启动 VLM 服务
└── README.md                    # 本文档
```

## 🚀 快速开始

### 前置条件

1. **启动所有服务** (推荐):
```bash
cd trajectory_2D
./start_services.sh
```

或单独启动各服务：

```bash
# SAM2 服务器 (端口 20020)
python sam2_server.py --checkpoint_path ../sam2/sam2.1_l.pt --port 20020

# GroundingDINO 服务器 (端口 20021)
python grounding_dino_server.py --checkpoint_path ../grounding_dino/groundingdino_swinb_cogcoor.pth --port 20021

# VLM 服务器 (端口 8000)
./start_vlm_server.sh
```

2. **确保其他服务可用**:
   - VLM 服务 (RoboBrain2.5-8B) @ `http://localhost:8008/v1`
   - Depth-Anything-v3 服务 @ `http://localhost:20022`
   - GroundingDINO 模型 @ `../grounding_dino/`
   - MoGe2 模型 @ `../moge2/moge-2-vitl-normal/model.pt`

### 基本使用

```bash
cd /workspace/wxd/Agent/Spagent/spagent/checkpoints/trajectory_2D

# 方式 1: 交互式运行（推荐）
python main.py

# 方式 2: 命令行指定所有参数
python main.py --image /path/to/image.png --instruction "远处的垃圾桶"

# 方式 3: 只指定图像，指令交互输入
python main.py --image /path/to/image.png

# 方式 4: 只指定指令，使用默认图像
python main.py --instruction "近处的椅子"

# 方式 5: 使用 run_pipeline.py 运行完整流程（推荐）
python run_pipeline.py --image /path/to/image.png --instruction "远处的垃圾桶"

# 方式 6: 保存轨迹 3D 点云（⭐ 新功能）
python run_pipeline.py --image /path/to/image.png --instruction "远处的垃圾桶" --save_trajectory_3d

# 方式 7: ⭐ 带导航终止判断的完整流程（需要起始帧 + 当前帧）
python run_pipeline.py \
  --initial-image /path/to/frame_0000.png \
  --image /path/to/frame_0110.png \
  --instruction "左边椅子" \
  --filter_floor --render_all_views --save_zip --self_reflection --save_trajectory_3d

# 方式 8: ⭐ 跨环境调用（通过远程 API 获取点云分割结果）
python run_pipeline.py \
  --image /path/to/image.png \
  --instruction "左边椅子" \
  --api-url http://your-server:9000 \
  --output-dir ./my_results
```

### 测试示例

```bash
# 使用测试图像运行
python main.py --image /workspace/wxd/Agent/images/test_6.png --instruction "远处的垃圾桶"

# 使用 run_pipeline 并保存轨迹 3D 点云
python run_pipeline.py --image /workspace/wxd/Agent/images/test_6.png --instruction "远处的垃圾桶" --save_trajectory_3d
```

### 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--image` | 输入图像路径（当前帧） | (必需) |
| `--instruction` | 自然语言指令 | "远处的垃圾桶" |
| `--api-url` | 远程 API 服务器 URL（跨环境调用点云分割） | None（本地调用） |
| `--initial_image` | 起始帧图像路径（用于终止判断） | None（不启用终止判断） |
| `--target_desc` | 目标语义描述（用于 VLM 终止判断） | 从 instruction 推断 |
| `--depth_threshold` | 目标中位深度阈值（米） | 0.8 |
| `--floor_ratio_threshold` | 起始点→目标连线地板占比阈值 | 0.3 |
| `--output-dir` | 输出目录 | `/workspace/wxd/Agent/images/trajectory_2D_results` |
| `--sam2-host` | SAM2 服务器主机 | `localhost` |
| `--sam2-port` | SAM2 服务器端口 | `20020` |
| `--save_trajectory_3d` | 保存轨迹 3D 点云为 PLY | 关闭 |
| `--filter_floor` | 启用地板约束过滤 | 关闭 |
| `--render_all_views` | 渲染所有轨迹点新视角 | 关闭 |
| `--self_reflection` | 启用 VLM 自选最优轨迹 | 关闭 |
| `--save_zip` | 打包输出文件夹为 zip | 关闭 |
| `--verbose_vlm` | 运行结束后统一打印所有 VLM 的 prompt 和原始输出 | 关闭（调试用） |

## 🛑 导航终止判断

`run_pipeline.py` 集成了导航终止判断功能，用于判断机器人是否已到达目标位置。

**工作原理：**
1. 对当前帧运行 `main.py` 生成分割掩码和深度图
2. **终止判断**（如果指定了 `--initial_image`）：
   - VLM 对比起始帧和当前帧，判断是否在朝目标靠近
   - 几何条件检查（满足任一即终止）：
     - A. 起始点不在地板上 → 机器人接近目标
     - B. 起点→目标连线地板占比 < 阈值 → 可走空间耗尽
     - C. 目标中位深度 < 阈值 → 物理距离够近
3. 如果判断为**已到达**，输出结果并停止
4. 如果判断为**未到达**，继续运行 VLM 轨迹预测

**输出文件：**
- `termination_result.json`：终止判断结果（包含 VLM 判断、几何判断、置信度等）
- `termination_comparison.png`：起始帧 vs 当前帧对比图（叠加目标 mask）

## 📊 输出文件

运行成功后，输出目录将包含以下文件：

```
trajectory_2D_results/
└── {image_name}/
    ├── {image_name}_full_pointcloud.ply      # 完整场景点云
    ├── {image_name}_target_pointcloud.ply    # 目标物体点云
    ├── {image_name}_floor_pointcloud.ply     # 地板点云
    ├── {image_name}_scene_pointcloud.ply     # 场景点云 (背景)
    ├── {image_name}_trajectory_3d_*.ply      # ⭐ 轨迹 3D 点云（新增）
    ├── {image_name}_3d_pointcloud.png        # 3D 点云可视化
    ├── {image_name}_2d_projection.png        # 2D 投影可视化
    ├── {image_name}_depth_masks.png          # 深度图 + 掩码
    ├── {image_name}_depth_map.npy            # 真实深度图（NumPy 格式）
    ├── {image_name}_trajectory_data.json     # 轨迹数据
    ├── termination_result.json               # ⭐ 终止判断结果（如果启用）
    ├── termination_comparison.png            # ⭐ 起始帧 vs 当前帧对比图（如果启用）
    └── {image_name}_metadata.json            # 元数据
```

### PLY 文件格式

每个 PLY 文件包含:
- `x, y, z`: 3D 坐标 (相机坐标系，单位：米)
- `red, green, blue`: RGB 颜色 (0-255)

### 轨迹 3D 点云 PLY（新增）

轨迹 3D 点云文件（`*_trajectory_3d_*.ply`）包含:
- **坐标系统**：与场景点云相同的相机坐标系
- **颜色编码**：
  - 🟢 起点（绿色）：机器人起始位置
  - 🟡 中间点（黄色/图像颜色）：轨迹路径点
  - 🔴 终点（红色）：机器人最终到达位置
- **用途**：在 3D 查看器中与场景点云叠加，直观检查轨迹规划效果

### 抬高轨迹点云 PLY（⭐ 新功能）

抬高轨迹点云文件（`*_elevated_trajectory_h*.ply`）包含:
- **坐标系统**：与场景点云相同的相机坐标系
- **抬高高度**：通过 `--camera_height` 参数指定（默认 0.06 米）
- **颜色编码**：
  - 🟢 起点（绿色）：机器人起始位置（已抬高）
  - 🟡 中间点（图像颜色）：轨迹路径点（已抬高）
  - 🔴 终点（红色）：机器人最终到达位置（已抬高）
- **用途**：查看机器人摄像头在抬高到指定高度后，轨迹点的实际 3D 空间分布

### 相机初始位置点云 PLY（⭐ 新增）

相机初始位置点云文件包含三个版本：
1. **相机真实位置**（`*_camera_origin_real_*.ply`）
   - 位置：`(0, 0, 0)` - 相机在场景点云中的真实位置（光心）
   - 颜色：🟡 黄色
   - 用途：标记相机拍摄图像时的真实空间位置

2. **投影到地面**（`*_camera_origin_ground_*.ply`）
   - 位置：`(0, Y_floor, 0)` - 相机 X、Z 坐标不变，Y 坐标等于地面高度
   - 颜色：🔵 青色
   - 用途：与地面上的轨迹点对齐查看（地面高度通过深度图中位数估计）

3. **抬高高度相机**（`*_camera_origin_elevated_h*.ply`）
   - 位置：`(0, -camera_height, 0)` - 从相机真实位置抬高指定高度
   - 颜色：🟠 橙色
   - 用途：与抬高后的轨迹点对齐查看

**查看提示**：
- 🟡 黄色点 = 相机真实位置（光心）
- 🔵 青色点 = 相机投影到地面
- 🟠 橙色点 = 相机抬高后位置
- 🟢 绿色点 = 轨迹起点
- 🔴 红色点 = 轨迹终点

### 元数据 JSON

```json
{
  "image_path": "/path/to/image.png",
  "instruction": "远处的垃圾桶",
  "intent": {
    "target_objects": ["garbage can"],
    "depth_attribute": "farthest"
  },
  "detection": {
    "box": [x1, y1, x2, y2],
    "confidence": 0.85,
    "phrase": "garbage can"
  },
  "pointcloud_stats": {
    "full": 1228800,
    "target": 15420,
    "floor": 89350,
    "scene": 1124030
  },
  "saved_files": { ... }
}
```

## 🔧 模块说明

### 1. VLM 意图理解 (`main.py: VLMIntentClient`)

解析用户指令，提取:
- 目标物体 (英文)
- 深度属性 (nearest/farthest)
- 位置属性 (left/right/center)
- 序数词 (1st, 2nd, 3rd...)

### 2. GroundingDINO 检测 (`main.py: GroundingDINODetector`)

检测目标物体的 2D 边界框，输出:
- 边界框坐标 (xyxy)
- 置信度
- 检测短语

### 3. SAM2 分割 (`sam2_client.py`)

通过 HTTP API 连接 SAM2 服务器，获取目标的精确掩码:
- 设置图像
- 使用边界框预测掩码
- 返回 2D 掩码

### 4. MoGe2 点云生成 (`pointcloud_segmentation.py`)

从单目图像生成 3D 点云:
- 深度图估计
- 3D 点云重建
- 相机内参估算

### 5. 点云分割 (`pointcloud_segmentation.py: PointCloudSegmentator`)

分离不同部分的点云:
- **目标点云**: SAM2 掩码区域内的点
- **地板点云**: 目标下方区域，Y 坐标较大的点
- **场景点云**: 去除目标和地板后的剩余点

### 6. 点云保存和可视化 (`pointcloud_saver.py`)

保存和可视化:
- PLY 格式 (ASCII)
- 3D matplotlib 可视化
- 2D 投影叠加
- 深度图 + 掩码可视化

## 🎯 技术路线

```
用户指令
    ↓
[VLM 意图理解] → 目标物体名称
    ↓
[GroundingDINO] → 2D 边界框
    ↓
[SAM2 分割] → 目标掩码
    ↓
[MoGe2] → 完整场景点云
    ↓
[点云分割] → 场景/目标/地板点云
    ↓
[保存输出] → PLY + 可视化
```

## 🛠️ 使用 Python API

```python
from trajectory_2D.main import PointCloudSegmentationPipeline

# 创建流程
pipeline = PointCloudSegmentationPipeline(
    output_dir="/path/to/output",
    sam2_host="localhost",
    sam2_port=20020
)

# 运行
result = pipeline.run(
    image_path="test.png",
    instruction="远处的垃圾桶"
)

if result["success"]:
    print(f"目标点云：{result['pointcloud_stats']['target']} 个点")
    print(f"输出目录：{result['output_dir']}")
```

## 🌐 使用 HTTP API

### 启动 API 服务

```bash
# 启动 API 服务
python api_server.py --host 0.0.0.0 --port 9000

# 查看 API 文档
# 浏览器访问: http://localhost:9000/docs
```

### 基本调用

```bash
# 基本调用（返回轨迹点 + 渲染图像）
curl -X POST http://localhost:9000/api/trajectory \
    -F "image=@image.png" \
    -F "instruction=左边的椅子"

# 带轨迹动画（显式开启）
curl -X POST http://localhost:9000/api/trajectory \
    -F "image=@image.png" \
    -F "instruction=左边的椅子" \
    -F "return_trajectory_video=true"

# 完整参数
curl -X POST http://localhost:9000/api/trajectory \
    -F "image=@image.png" \
    -F "instruction=左边的椅子" \
    -F "filter_floor=true" \
    -F "trajectory_spacing=0.017" \
    -F "trajectory_smooth_window=5" \
    -F "camera_height=0.06" \
    -F "self_reflection=true" \
    -F "return_trajectory_video=true" \
    -F "return_metadata=true"
```

### Python 调用示例

#### 基本调用（含点云分割结果）

```python
import requests
import base64
import json
import os

# 准备请求
url = "http://localhost:9000/api/trajectory"
files = {"image": open("image.png", "rb")}
data = {
    "instruction": "左边的椅子",
    "skip_ply_save": "true"  # 跳过 PLY 保存（加速）
}

# 发送请求
response = requests.post(url, files=files, data=data)
result = response.json()

# 处理响应
print(f"轨迹点数: {result['num_points']}")

# ========== 保存点云分割结果 ==========
if result.get('segmentation_results'):
    seg_dir = "segmentation_results"
    os.makedirs(seg_dir, exist_ok=True)
    
    for filename, base64_data in result['segmentation_results'].items():
        file_bytes = base64.b64decode(base64_data)
        file_path = os.path.join(seg_dir, filename)
        with open(file_path, 'wb') as f:
            f.write(file_bytes)
        print(f"✅ 已保存: {file_path}")
    
    print(f"\n✅ 点云分割结果已保存到: {seg_dir}/")
    print(f"   包含文件:")
    for filename in result['segmentation_results'].keys():
        print(f"     - {filename}")
else:
    print("⚠️ 未找到点云分割结果")
```

#### 带轨迹动画和渲染图像

```python
import requests
import base64
import os

url = "http://localhost:9000/api/trajectory"
files = {"image": open("image.png", "rb")}
data = {
    "instruction": "左边的椅子",
    "return_trajectory_video": "true",
    "return_metadata": "true"
}

response = requests.post(url, files=files, data=data)
result = response.json()

print(f"轨迹点数: {result['num_points']}")
print(f"渲染视图数: {len(result['rendered_views'])}")

# 保存轨迹动画
if result.get('trajectory_video_base64'):
    video_bytes = base64.b64decode(result['trajectory_video_base64'])
    with open('trajectory.mp4', 'wb') as f:
        f.write(video_bytes)
    print("✅ 轨迹动画已保存")

# 保存渲染图像
for i, view in enumerate(result['rendered_views']):
    img_bytes = base64.b64decode(view['image_base64'])
    with open(f'view_{i:03d}.png', 'wb') as f:
        f.write(img_bytes)
print(f"✅ 已保存 {len(result['rendered_views'])} 张渲染图像")
```

### 响应字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `success` | bool | 请求是否成功 |
| `message` | str | 响应消息 |
| `trajectory` | list | 轨迹点列表（2D 像素坐标） |
| `num_points` | int | 轨迹点数量 |
| `start_point` | list | 起点坐标 [x, y] |
| `target_point` | list | 目标点坐标 [x, y] |
| `navigation_goal_point` | list | 可达终点坐标 [x, y] |
| `rendered_views` | list | 渲染的视角图像列表 |
| `trajectory_video_base64` | str | 轨迹动画 MP4（Base64 编码，需显式请求） |
| `segmentation_results` | dict | 点云分割结果（Base64 编码），客户端可自行保存到本地 |
| `termination` | object | VLM 终止判断结果 |
| `processing_time_seconds` | float | 处理耗时（秒） |

### 请求参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `image` | file | 必需 | 输入图像文件 |
| `instruction` | str | 必需 | 自然语言指令 |
| `initial_image` | str | None | 初始图像路径（终止判断） |
| `skip_ply_save` | bool | true | 跳过 PLY 点云文件保存（提升 I/O 效率） |
| `filter_floor` | bool | true | 地板约束过滤 |
| `trajectory_spacing` | float | 0.017 | 轨迹点物理间距（米） |
| `trajectory_smooth_window` | int | 5 | 平滑窗口大小 |
| `camera_height` | float | 0.06 | 相机抬高距离（米） |
| `self_reflection` | bool | true | VLM 自我反思 |
| `return_trajectory_points` | bool | true | 返回轨迹点坐标 |
| `return_rendered_views` | bool | true | 返回渲染图像 |
| `return_trajectory_video` | bool | false | 返回轨迹动画（默认关闭） |
| `return_metadata` | bool | false | 返回完整元数据 |

## ⚠️ 注意事项

1. **SAM2 服务器必须先启动**，否则流程会失败
2. **GPU 内存需求**: 建议至少 8GB GPU 内存
3. **深度精度**: MoGe2 估计的深度是相对深度，可能存在尺度误差
4. **地板检测**: 使用几何方法，在目标下方区域寻找 Y 坐标最大的点

## 🌍 跨环境使用（客户端/服务器分离）

当点云分割服务运行在远程服务器上时，客户端无法直接访问服务器的本地文件路径。API 返回 **Base64 编码的点云分割结果**，客户端可自行保存到本地。

### 服务器端（你的机器）

```bash
# 启动 API 服务
python api_server.py --host 0.0.0.0 --port 9000
```

### 客户端（其他用户的机器）

```python
import requests
import base64
import os

# 调用远程 API
url = "http://your-server:9000/api/trajectory"
files = {"image": open("image.png", "rb")}
data = {
    "instruction": "左边的椅子",
    "skip_ply_save": "true"
}

response = requests.post(url, files=files, data=data)
result = response.json()

# 保存点云分割结果到本地
if result.get('segmentation_results'):
    seg_dir = "segmentation_results"
    os.makedirs(seg_dir, exist_ok=True)
    
    for filename, base64_data in result['segmentation_results'].items():
        file_bytes = base64.b64decode(base64_data)
        file_path = os.path.join(seg_dir, filename)
        with open(file_path, 'wb') as f:
            f.write(file_bytes)
        print(f"✅ 已保存: {file_path}")
    
    print(f"\n✅ 点云分割结果已保存到本地: {seg_dir}/")
```

### 包含的文件

| 文件名 | 说明 |
|--------|------|
| `{image_name}_depth_masks.png` | 深度掩码图像（含地板/目标掩码） |
| `{image_name}_depth_map.npy` | 深度图（numpy 格式） |
| `{image_name}_floor_mask.npy` | 地板掩码 |
| `{image_name}_target_mask.npy` | 目标物体掩码 |

## 🔍 查看点云

使用以下工具查看 PLY 文件:
- [MeshLab](https://www.meshlab.net/)
- [CloudCompare](https://www.danielgm.net/cc/)
- Open3D (Python)

```python
import open3d as o3d

# 读取点云
pcd = o3d.io.read_point_cloud("target_pointcloud.ply")
o3d.visualization.draw_geometries([pcd])
```

## 📝 示例输出

```
======================================================================
🚀 开始点云分割流程
======================================================================
   图像：/workspace/wxd/Agent/images/test.png
   指令：远处的垃圾桶
======================================================================

======================================================================
📋 步骤 1: VLM 意图理解
======================================================================
✅ 识别目标：garbage can
   深度属性：farthest
   位置属性：None

======================================================================
🔍 步骤 2: GroundingDINO 目标检测
======================================================================
   检测到：garbage can (置信度：0.852)
   边界框：x1=320.5, y1=180.2, x2=450.8, y2=380.6
✅ 选择检测框：置信度 0.852

======================================================================
✂️  步骤 3: SAM2 分割
======================================================================
✅ SAM2 掩码已生成，像素数：12580

======================================================================
☁️  步骤 4: MoGe2 点云生成与分割
======================================================================
✅ 点云分割完成
   完整点云：1228800 个点
   目标点云：15420 个点
   地板点云：89350 个点
   场景点云：1124030 个点

======================================================================
💾 步骤 5: 保存结果
======================================================================
✅ 点云已保存：.../target_pointcloud.ply (15420 个点)
✅ 点云已保存：.../floor_pointcloud.ply (89350 个点)
✅ 点云已保存：.../scene_pointcloud.ply (1124030 个点)
✅ 3D 可视化已保存：.../3d_pointcloud.png
✅ 2D 投影可视化已保存：.../2d_projection.png
✅ 深度图可视化已保存：.../depth_masks.png
✅ 所有结果已保存：/workspace/wxd/Agent/images/trajectory_2D_results/test

======================================================================
✅ 点云分割流程完成!
======================================================================
```

## 📞 故障排除

### SAM2 服务器不可用
```
❌ SAM2 服务器不可用，请确保已启动：python sam2_server.py ...
```
**解决**: 确保 SAM2 服务器在指定端口运行

### 未检测到目标物体
```
❌ 未检测到目标物体：garbage can
```
**解决**: 
- 检查 GroundingDINO 模型路径是否正确
- 尝试调整 `BOX_THRESHOLD` 和 `TEXT_THRESHOLD`
- 确认目标物体在图像中可见

### 点云为空
```
⚠️ 点云为空，跳过保存
```
**解决**:
- 检查 MoGe2 模型是否正确加载
- 确认图像路径有效
