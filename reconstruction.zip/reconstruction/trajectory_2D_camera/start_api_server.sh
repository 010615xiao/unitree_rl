#!/bin/bash
# 启动 Trajectory 2D API Server

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 默认参数
HOST=${1:-"0.0.0.0"}
PORT=${2:-9000}
WORKERS=${3:-1}

echo ""
echo "========================================================================"
echo "🚀 启动 Trajectory 2D API Server"
echo "========================================================================"
echo "   地址: http://$HOST:$PORT"
echo "   API 文档: http://$HOST:$PORT/docs"
echo "   健康检查: http://$HOST:$PORT/health"
echo "   工作进程: $WORKERS"
echo "========================================================================"
echo ""

# 检查依赖
echo "📦 检查依赖..."
python3 -c "import fastapi" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "⚠️  缺少 FastAPI 依赖，正在安装..."
    pip3 install -q -r requirements_api.txt
fi

# 启动服务
echo "✅ 依赖检查完成，启动服务..."
echo ""

python3 api_server.py --host $HOST --port $PORT --workers $WORKERS
