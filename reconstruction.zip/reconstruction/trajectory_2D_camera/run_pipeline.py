#!/usr/bin/env python3
"""
统一运行脚本：先运行 main.py 生成分割掩码，然后运行 VLM 轨迹预测

集成导航终止判断：在每次循环中先判断是否已到达目标，再决定是否继续轨迹规划

使用示例:
    # 单次轨迹规划（无终止判断）
    python run_pipeline.py --image /workspace/wxd/Agent/images/test_6.png --instruction "远处的垃圾桶"

    # 带终止判断的完整导航流程（需要起始帧 + 当前帧）
    python run_pipeline.py --initial-image frame_0000.png --image frame_0110.png --instruction "左边椅子" --filter_floor --render_all_views
"""

import sys
import os
import argparse
import subprocess
import json
import zipfile
import numpy as np
import cv2
from pathlib import Path
from typing import List, Tuple, Optional, Dict
from datetime import datetime

# 导入渲染模块中的工具函数
from render_trajectory_view import load_depth_map_from_npy, load_depth_map_from_image

# 导入终止判断模块
import termination_checker


def visualize_trajectory_on_image(
    image_path: str,
    trajectory: List[List[float]],
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    title: str = "Trajectory Visualization",
    output_dir: Optional[str] = None,  # 修改为输出目录
    point_colors: Optional[Dict[str, Tuple[int, int, int]]] = None
) -> str:
    """
    在图像上可视化轨迹

    Args:
        image_path: 图像路径
        trajectory: 轨迹点列表
        start_point: 起点坐标
        target_point: 目标点坐标
        title: 标题
        output_dir: 输出目录（如果不指定，使用图像所在目录）
        point_colors: 点颜色配置

    Returns:
        输出图像路径
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]

    # 创建叠加层
    overlay = image_rgb.copy()

    # 默认颜色配置
    if point_colors is None:
        point_colors = {
            "start": (0, 255, 0),      # 绿色
            "end": (0, 0, 255),        # 红色
            "interpolated": (255, 255, 0),  # 黄色（插值点）
            "original": (255, 255, 255)     # 白色（原始点）
        }

    # 绘制轨迹线（渐变色）
    if len(trajectory) >= 2:
        points = [(int(p[0]), int(p[1])) for p in trajectory]
        for i in range(len(points) - 1):
            t = i / (len(points) - 1)
            color = (int(0 * (1 - t) + 255 * t), int(255 * (1 - t) + 0 * t), 0)
            cv2.line(overlay, points[i], points[i+1], color, 3)

    # 绘制轨迹点
    for i, pt in enumerate(trajectory):
        x, y = int(pt[0]), int(pt[1])
        
        if i == 0:
            # 起点：绿色大圆圈
            cv2.circle(overlay, (x, y), 12, point_colors["start"], -1)
            cv2.putText(overlay, "S", (x - 8, y + 8),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
        elif i == len(trajectory) - 1:
            # 终点：红色大圆圈（可达终点 G）
            cv2.circle(overlay, (x, y), 12, point_colors["end"], -1)
            cv2.putText(overlay, "G", (x - 8, y + 8),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        else:
            # 中间点：白色或黄色小圆圈
            color = point_colors.get("interpolated", (255, 255, 0))
            cv2.circle(overlay, (x, y), 8, color, -1)

    # 添加标题和统计信息
    stats_y = 25
    font_scale = 0.5

    cv2.putText(overlay, title, (10, stats_y),
               cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 2)
    cv2.putText(overlay, f"Points: {len(trajectory)}", (10, stats_y + 25),
               cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 2)

    # 保存
    if output_dir is None:
        output_dir = os.path.dirname(image_path)
    
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_path = os.path.join(output_dir, f"{base_name}_trajectory_{timestamp}.png")

    output_bgr = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 轨迹可视化已保存：{output_path}")

    return output_path


def pixels_to_3d(
    trajectory_2d: List[List[float]],
    depth_map: np.ndarray,
    fx: float,
    fy: float,
    cx: float,
    cy: float
) -> List[np.ndarray]:
    """
    将2D像素点反投影到3D相机坐标系

    Args:
        trajectory_2d: 2D轨迹点列表 [[x1, y1], [x2, y2], ...]
        depth_map: 深度图 [H, W]（单位：米）
        fx, fy, cx, cy: 相机内参

    Returns:
        3D点列表，每个元素为 np.array([X, Y, Z])，无效点返回 None
    """
    h, w = depth_map.shape
    trajectory_3d = []

    for i, point_2d in enumerate(trajectory_2d):
        px, py = point_2d[0], point_2d[1]

        # 边界检查
        if px < 0 or px >= w or py < 0 or py >= h:
            trajectory_3d.append(None)
            continue

        # 从深度图查询深度值（双线性插值）
        x0, y0 = int(np.floor(px)), int(np.floor(py))
        x1, y1 = min(x0 + 1, w - 1), min(y0 + 1, h - 1)
        x0 = max(0, x0)
        y0 = max(0, y0)

        wx = px - x0
        wy = py - y0

        depth = (
            depth_map[y0, x0] * (1 - wx) * (1 - wy) +
            depth_map[y0, x1] * wx * (1 - wy) +
            depth_map[y1, x0] * (1 - wx) * wy +
            depth_map[y1, x1] * wx * wy
        )

        # 验证深度值
        if not np.isfinite(depth) or depth <= 0 or depth > 20:
            trajectory_3d.append(None)
            continue

        # 反投影到3D相机坐标系
        cam_x = (px - cx) * depth / fx
        cam_y = (py - cy) * depth / fy
        cam_z = depth

        trajectory_3d.append(np.array([cam_x, cam_y, cam_z]))

    return trajectory_3d


def interpolate_trajectory(
    trajectory: List[List[float]],
    floor_mask: np.ndarray,
    target_spacing: float = 0.017,  # 目标物理间距（米）
    min_points: int = 5,             # 最少点数保底
    max_density: float = 15.0,       # 最大插值密度（像素间隔，仅2D模式）
    depth_map: Optional[np.ndarray] = None,
    camera_intrinsics: Optional[np.ndarray] = None,
    image_width: Optional[int] = None,
    image_height: Optional[int] = None,
    force_resample: bool = True
) -> dict:
    """
    对轨迹点进行插值/重采样，基于物理间距自动计算目标点数

    优先使用3D空间距离插值（如果提供了深度图和相机内参），
    否则回退到2D像素距离插值。

    Args:
        trajectory: 原始轨迹点列表
        floor_mask: 地板掩码（用于验证插值点是否在地板上）
        target_spacing: 目标物理间距（米），默认 0.017m
        min_points: 最少点数保底
        max_density: 最大插值密度（点之间的最小像素距离，仅用于2D模式）
        depth_map: 深度图 [H, W]（单位：米），如果提供则使用3D插值
        camera_intrinsics: 相机内参矩阵 [3, 3]（归一化坐标）
        image_width: 图像宽度（用于计算实际内参）
        image_height: 图像高度（用于计算实际内参）
        force_resample: 是否强制重采样（即使点数已 >= min_points）

    Returns:
        插值结果字典
    """
    # 检查是否满足3D插值条件
    use_3d = depth_map is not None and (camera_intrinsics is not None or (image_width is not None and image_height is not None))

    if use_3d and len(trajectory) >= 2:
        return _interpolate_trajectory_3d(
            trajectory, depth_map, camera_intrinsics,
            image_width, image_height, floor_mask, target_spacing, min_points, force_resample
        )
    else:
        return _interpolate_trajectory_2d(trajectory, floor_mask, min_points, max_density, force_resample)


def _interpolate_trajectory_3d(
    trajectory_2d: List[List[float]],
    depth_map: np.ndarray,
    camera_intrinsics: Optional[np.ndarray],
    image_width: Optional[int],
    image_height: Optional[int],
    floor_mask: np.ndarray,
    target_spacing: float = 0.017,
    min_points: int = 5,
    force_resample: bool = True
) -> dict:
    """
    基于3D空间距离的轨迹插值

    按目标物理间距自动计算点数：target_count = total_length_3d / target_spacing + 1
    同时受 min_points 保底限制。

    Args:
        trajectory_2d: 2D轨迹点列表
        depth_map: 深度图
        camera_intrinsics: 相机内参 [3, 3]（归一化）
        image_width: 图像宽度
        image_height: 图像高度
        floor_mask: 地板掩码（用于验证）
        target_spacing: 目标物理间距（米），默认 0.017m
        min_points: 最少点数保底
        force_resample: 是否强制重采样

    Returns:
        插值结果字典
    """
    if len(trajectory_2d) < 2:
        return {
            "success": False,
            "error": "轨迹点数量不足，无法插值",
            "original_points": len(trajectory_2d)
        }

    h, w = depth_map.shape

    # 计算相机内参
    if camera_intrinsics is not None:
        fx = camera_intrinsics[0, 0] * w
        fy = camera_intrinsics[1, 1] * h
        cx = camera_intrinsics[0, 2] * w
        cy = camera_intrinsics[1, 2] * h
    else:
        # 默认 FOV=60°
        focal_length = w / (2 * np.tan(np.deg2rad(60) / 2))
        fx = fy = focal_length
        cx, cy = w / 2, h / 2

    original_count = len(trajectory_2d)

    print("\n" + "=" * 80)
    print("📐 轨迹点插值（3D空间距离）")
    print("=" * 80)
    print(f"   原始点数：{original_count}")
    print(f"   目标物理间距：{target_spacing:.4f} 米")
    print(f"   最少点数保底：{min_points}")
    print(f"   相机内参：fx={fx:.1f}, fy={fy:.1f}, cx={cx:.1f}, cy={cy:.1f}")

    # ========== 步骤 1: 2D → 3D 反投影 ==========
    print("\n📌 步骤 1: 2D轨迹点反投影到3D空间")

    trajectory_3d = pixels_to_3d(trajectory_2d, depth_map, fx, fy, cx, cy)

    valid_count = sum(1 for p in trajectory_3d if p is not None)
    invalid_count = original_count - valid_count

    print(f"   有效3D点数：{valid_count} / {original_count}")
    if invalid_count > 0:
        print(f"   ⚠️ 无效点数：{invalid_count}（深度无效或超出边界）")

    if valid_count < 2:
        return {
            "success": False,
            "error": "有效3D点数量不足，无法插值",
            "original_points": original_count,
            "valid_3d_points": valid_count
        }

    # ========== 步骤 2: 计算3D空间中的真实距离 ==========
    print("\n📌 步骤 2: 计算3D空间线段长度")

    segments_3d = []
    total_length_3d = 0.0

    for i in range(len(trajectory_3d) - 1):
        if trajectory_3d[i] is None or trajectory_3d[i + 1] is None:
            continue

        dist_3d = np.linalg.norm(trajectory_3d[i + 1] - trajectory_3d[i])
        segments_3d.append({
            "start_idx": i,
            "p1": trajectory_3d[i],
            "p2": trajectory_3d[i + 1],
            "p1_2d": trajectory_2d[i],
            "p2_2d": trajectory_2d[i + 1],
            "distance_3d": dist_3d
        })
        total_length_3d += dist_3d
        print(f"   段 {i}: {dist_3d:.3f}m (2D: [{trajectory_2d[i][0]:.0f},{trajectory_2d[i][1]:.0f}] → [{trajectory_2d[i+1][0]:.0f},{trajectory_2d[i+1][1]:.0f}])")

    print(f"\n   3D轨迹总长度：{total_length_3d:.3f}m")

    # ========== 步骤 3: 按3D距离比例插值 ==========
    print(f"\n📌 步骤 3: 按物理间距计算目标点数")

    # 根据物理间距计算目标点数
    if total_length_3d > 0 and target_spacing > 0:
        target_count = max(int(round(total_length_3d / target_spacing)) + 1, min_points)
    else:
        target_count = max(valid_count, min_points)

    print(f"   3D总长度：{total_length_3d:.3f}m")
    print(f"   目标间距：{target_spacing:.4f}m")
    print(f"   计算目标点数：{target_count} = round({total_length_3d:.3f} / {target_spacing:.4f}) + 1")

    if not force_resample and valid_count >= target_count:
        print(f"   点数已足够 ({valid_count} >= {target_count})，跳过插值")
        return {
            "success": True,
            "interpolated": False,
            "original_points": original_count,
            "valid_3d_points": valid_count,
            "interpolated_points": valid_count,
            "trajectory": [p for p in trajectory_2d if p is not None],
            "trajectory_3d": [p.tolist() for p in trajectory_3d if p is not None],
            "added_points": 0,
            "target_points": target_count,
            "target_spacing_m": target_spacing,
            "total_length_3d_m": total_length_3d,
            "method": "3d_space"
        }

    # 在3D空间中均匀采样 target_count 个点
    interpolated_trajectory_2d = []
    interpolated_trajectory_3d = []

    # 构建累积距离数组
    cumulative_dist = [0.0]
    for seg in segments_3d:
        cumulative_dist.append(cumulative_dist[-1] + seg["distance_3d"])

    # 在总长度上均匀采样 target_count 个点
    if target_count <= 1:
        target_count = 2
    sample_distances = np.linspace(0, total_length_3d, target_count)

    for target_dist in sample_distances:
        # 找到对应的线段
        seg_idx = 0
        while seg_idx < len(segments_3d) - 1 and cumulative_dist[seg_idx + 1] < target_dist:
            seg_idx += 1

        if seg_idx >= len(segments_3d):
            seg_idx = len(segments_3d) - 1

        seg = segments_3d[seg_idx]
        seg_start = cumulative_dist[seg_idx]
        seg_end = cumulative_dist[seg_idx + 1]
        seg_len = seg_end - seg_start

        if seg_len > 1e-6:
            t = (target_dist - seg_start) / seg_len
        else:
            t = 1.0

        # 3D空间线性插值
        interp_point_3d = seg["p1"] + t * (seg["p2"] - seg["p1"])

        # 投影回2D
        z = interp_point_3d[2]
        if z > 0:
            interp_px = fx * interp_point_3d[0] / z + cx
            interp_py = fy * interp_point_3d[1] / z + cy

            px_int, py_int = int(round(interp_px)), int(round(interp_py))
            if 0 <= px_int < w and 0 <= py_int < h:
                is_on_floor = bool(floor_mask[py_int, px_int])
                if is_on_floor:
                    interpolated_trajectory_2d.append([float(interp_px), float(interp_py)])
                    interpolated_trajectory_3d.append(interp_point_3d)

    # 确保起点和终点在列表中
    if len(interpolated_trajectory_2d) == 0 or interpolated_trajectory_2d[0] != trajectory_2d[0]:
        interpolated_trajectory_2d.insert(0, trajectory_2d[0])
    if len(interpolated_trajectory_3d) == 0 or not np.array_equal(interpolated_trajectory_3d[0], trajectory_3d[0]):
        interpolated_trajectory_3d.insert(0, trajectory_3d[0])

    if len(interpolated_trajectory_2d) == 0 or interpolated_trajectory_2d[-1] != trajectory_2d[-1]:
        if trajectory_3d[-1] is not None:
            interpolated_trajectory_2d.append(trajectory_2d[-1])
            interpolated_trajectory_3d.append(trajectory_3d[-1])

    added_count = len(interpolated_trajectory_2d) - valid_count
    print(f"   重采样后点数：{len(interpolated_trajectory_2d)}")

    # ========== 步骤 4: 输出统计 ==========
    print(f"\n📌 步骤 4: 插值结果")
    print(f"   插值后点数：{len(interpolated_trajectory_2d)}")
    print(f"   新增点数：{added_count}")
    print(f"   3D总长度：{total_length_3d:.3f}m")
    if len(interpolated_trajectory_2d) >= 2:
        avg_3d_dist = total_length_3d / (len(interpolated_trajectory_2d) - 1)
        print(f"   平均3D间距：{avg_3d_dist:.4f}m (目标: {target_spacing:.4f}m)")

    return {
        "success": True,
        "interpolated": True,
        "original_points": original_count,
        "valid_3d_points": valid_count,
        "interpolated_points": len(interpolated_trajectory_2d),
        "trajectory": interpolated_trajectory_2d,
        "trajectory_3d": [p.tolist() for p in interpolated_trajectory_3d],
        "added_points": added_count,
        "target_points": target_count,
        "target_spacing_m": target_spacing,
        "total_length_3d_m": total_length_3d,
        "method": "3d_space",
        "force_resample": force_resample,
        "avg_3d_spacing_m": total_length_3d / (len(interpolated_trajectory_2d) - 1) if len(interpolated_trajectory_2d) >= 2 else 0
    }


def _interpolate_trajectory_2d(
    trajectory: List[List[float]],
    floor_mask: np.ndarray,
    min_points: int = 10,
    max_density: float = 15.0,
    force_resample: bool = True
) -> dict:
    """
    基于2D像素距离的轨迹插值（回退方案）

    Args:
        trajectory: 原始轨迹点列表
        floor_mask: 地板掩码
        min_points: 最少点数
        max_density: 最大插值密度

    Returns:
        插值结果字典
    """
    if len(trajectory) < 2:
        return {
            "success": False,
            "error": "轨迹点数量不足，无法插值",
            "original_points": len(trajectory)
        }

    original_count = len(trajectory)

    # 如果点数已经足够，不需要插值
    if original_count >= min_points:
        return {
            "success": True,
            "interpolated": False,
            "original_points": original_count,
            "interpolated_points": original_count,
            "trajectory": trajectory,
            "added_points": 0
        }

    print("\n" + "=" * 80)
    print("📐 轨迹点插值（2D像素距离，回退方案）")
    print("=" * 80)
    print(f"   原始点数：{original_count}")
    print(f"   目标点数：至少 {min_points} 个")

    # ========== 步骤 1: 计算相邻点之间的距离 ==========
    print("\n📌 步骤 1: 分析点间距")

    segments = []
    total_length = 0

    for i in range(len(trajectory) - 1):
        p1 = np.array(trajectory[i])
        p2 = np.array(trajectory[i + 1])
        dist = np.linalg.norm(p2 - p1)
        segments.append({
            "start_idx": i,
            "p1": p1,
            "p2": p2,
            "distance": dist
        })
        total_length += dist
        print(f"   段 {i}: [{p1[0]:.1f}, {p1[1]:.1f}] → [{p2[0]:.1f}, {p2[1]:.1f}], 距离={dist:.1f} 像素")

    # ========== 步骤 2: 计算需要的插值点数 ==========
    points_needed = min_points - original_count
    print(f"\n📌 步骤 2: 计算插值方案")
    print(f"   需要添加：{points_needed} 个点")
    print(f"   轨迹总长度：{total_length:.1f} 像素")

    # 按距离比例分配插值点到各个段
    interpolated_trajectory = [trajectory[0].copy()]
    added_count = 0

    for seg in segments:
        # 计算这个段应该分配的插值点数（按距离比例）
        segment_ratio = seg["distance"] / total_length
        points_for_segment = int(round(points_needed * segment_ratio))

        # 确保每个段至少有一个点（如果原距离较大）
        if seg["distance"] > max_density and points_for_segment == 0:
            points_for_segment = 1

        # 计算插值点
        num_intervals = points_for_segment + 1
        for j in range(1, num_intervals + 1):
            t = j / num_intervals
            interp_point = seg["p1"] + t * (seg["p2"] - seg["p1"])

            # 验证插值点是否在地板上
            x, y = int(round(interp_point[0])), int(round(interp_point[1]))
            h, w = floor_mask.shape

            if 0 <= x < w and 0 <= y < h:
                is_on_floor = bool(floor_mask[y, x])

                if is_on_floor:
                    # 检查与上一个点的距离（避免太密集）
                    if len(interpolated_trajectory) > 0:
                        last_point = np.array(interpolated_trajectory[-1])
                        dist_to_last = np.linalg.norm(interp_point - last_point)

                        if dist_to_last >= max_density * 0.5:  # 至少达到最小密度的一半
                            interpolated_trajectory.append(interp_point.tolist())
                            added_count += 1
                    else:
                        interpolated_trajectory.append(interp_point.tolist())
                        added_count += 1

    # 添加最后一个点（验证地板约束）
    last_point = trajectory[-1]
    x, y = int(round(last_point[0])), int(round(last_point[1]))
    h, w = floor_mask.shape
    if 0 <= x < w and 0 <= y < h and bool(floor_mask[y, x]):
        interpolated_trajectory.append(last_point.copy())
    else:
        # 如果最后一个点不在地板上，找到最后一个在地板上的插值点
        print(f"   ⚠️ 终点 [{x}, {y}] 不在地板上，使用最后一个有效插值点")
        # 终点已经在前面被添加到 interpolated_trajectory 中，无需额外操作

    # ========== 步骤 3: 输出统计 ==========
    print(f"\n📌 步骤 3: 插值结果")
    print(f"   插值后点数：{len(interpolated_trajectory)}")
    print(f"   新增点数：{added_count}")

    # 检查是否达到目标
    if len(interpolated_trajectory) < min_points:
        print(f"   ⚠️ 由于地板约束，无法达到 {min_points} 个点")

    return {
        "success": True,
        "interpolated": True,
        "original_points": original_count,
        "interpolated_points": len(interpolated_trajectory),
        "trajectory": interpolated_trajectory,
        "added_points": added_count,
        "target_points": min_points,
        "method": "2d_pixel"
    }


def postprocess_trajectory(
    trajectory: List[List[float]],
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    distance_threshold: float = 5.0
) -> dict:
    """
    对轨迹点进行后处理：去重 + 排序

    Args:
        trajectory: 原始轨迹点列表 [[x1, y1], [x2, y2], ...]
        start_point: 起点坐标 (x, y)
        target_point: 目标点坐标 [x, y]（可选，用于确保终点正确）
        distance_threshold: 融合相近点的距离阈值（像素），默认 5.0

    Returns:
        后处理结果字典，包含：
        - success: 是否成功
        - original_points: 原始点数
        - deduped_points: 去重后的点数
        - sorted_points: 排序后的点数
        - trajectory: 最终轨迹
        - removed_duplicates: 移除的重复点数
    """
    if not trajectory or len(trajectory) < 2:
        return {
            "success": False,
            "error": "轨迹点数量不足",
            "original_points": len(trajectory) if trajectory else 0
        }

    print("\n" + "=" * 80)
    print("🔧 轨迹点后处理")
    print("=" * 80)

    original_count = len(trajectory)
    print(f"原始轨迹点数：{original_count}")

    # ========== 步骤 1: 去重和融合相近点 ==========
    print("\n📌 步骤 1: 去重和融合相近点")
    print(f"   距离阈值：{distance_threshold} 像素")

    deduped = []
    i = 0
    while i < len(trajectory):
        current_point = trajectory[i]

        # 查找与当前点距离小于阈值的所有连续点
        cluster = [current_point]
        j = i + 1
        while j < len(trajectory):
            next_point = trajectory[j]
            dist = np.sqrt((current_point[0] - next_point[0]) ** 2 + (current_point[1] - next_point[1]) ** 2)
            if dist < distance_threshold:
                cluster.append(next_point)
                j += 1
            else:
                break

        # 融合 cluster 中的点（取平均）
        if len(cluster) > 1:
            avg_point = [
                np.mean([p[0] for p in cluster]),
                np.mean([p[1] for p in cluster])
            ]
            deduped.append(avg_point)
            print(f"   融合 {len(cluster)} 个相近点 → [{avg_point[0]:.1f}, {avg_point[1]:.1f}]")
        else:
            deduped.append(current_point)

        i = j

    # ========== 步骤 1.5: 全局去重（移除完全相同的点）==========
    # 在融合相近点后，再检查并移除全局重复的点
    global_deduped = []
    seen_points = set()
    for point in deduped:
        # 转换为元组以便放入集合
        point_tuple = (round(point[0], 1), round(point[1], 1))
        if point_tuple not in seen_points:
            seen_points.add(point_tuple)
            global_deduped.append(point)
    
    if len(global_deduped) < len(deduped):
        print(f"   全局去重：移除 {len(deduped) - len(global_deduped)} 个完全重复的点")
    deduped = global_deduped

    deduped_count = len(deduped)
    removed_count = original_count - deduped_count
    print(f"✅ 去重后点数：{deduped_count} (移除了 {removed_count} 个重复点)")

    # ========== 步骤 2: 验证轨迹顺序（而非重新排序）==========
    print("\n📌 步骤 2: 验证轨迹顺序")
    print(f"   起点：{start_point}")

    # VLM 输出的轨迹已经是按路径顺序排列的
    # 我们只需要确保起点是第一个点，终点是最后一个点
    sorted_trajectory = deduped.copy()

    # 确保起点是第一个点（如果起点不在列表中，添加到开头）
    start_dist = np.sqrt((sorted_trajectory[0][0] - start_point[0]) ** 2 + (sorted_trajectory[0][1] - start_point[1]) ** 2)
    if start_dist > distance_threshold:
        # 找到离起点最近的点
        min_start_dist = float('inf')
        nearest_to_start_idx = 0
        for i, point in enumerate(sorted_trajectory):
            dist = np.sqrt((point[0] - start_point[0]) ** 2 + (point[1] - start_point[1]) ** 2)
            if dist < min_start_dist:
                min_start_dist = dist
                nearest_to_start_idx = i

        # 如果离起点最近的点不在开头，将其移到开头
        if nearest_to_start_idx != 0:
            start_item = sorted_trajectory.pop(nearest_to_start_idx)
            sorted_trajectory.insert(0, start_item)
            print(f"   将离起点最近的点 (索引{nearest_to_start_idx}, 距离{min_start_dist:.1f}) 移到开头")

    # 如果有目标点，确保终点是最后一个点
    if target_point is not None:
        # 找到离目标点最近的点
        min_dist_to_target = float('inf')
        target_idx = -1
        for i, item in enumerate(sorted_trajectory):
            dist_to_target = np.sqrt((item[0] - target_point[0]) ** 2 + (item[1] - target_point[1]) ** 2)
            if dist_to_target < min_dist_to_target:
                min_dist_to_target = dist_to_target
                target_idx = i

        # 将离目标最近的点移到列表末尾（如果不在末尾）
        if target_idx != -1 and target_idx != len(sorted_trajectory) - 1:
            target_item = sorted_trajectory.pop(target_idx)
            sorted_trajectory.append(target_item)
            print(f"   将离目标点最近的点 (索引{target_idx}, 距离{min_dist_to_target:.1f}) 设为终点")

    # 验证排序结果
    first_point = sorted_trajectory[0]
    last_point = sorted_trajectory[-1]
    first_dist = np.sqrt((first_point[0] - start_point[0]) ** 2 + (first_point[1] - start_point[1]) ** 2)
    print(f"✅ 顺序验证后点数：{len(sorted_trajectory)}")
    print(f"   起点最近点：{first_point} (距离起点 {first_dist:.1f})")
    if target_point is not None:
        last_dist = np.sqrt((last_point[0] - target_point[0]) ** 2 + (last_point[1] - target_point[1]) ** 2)
        print(f"   终点最近点：{last_point} (距离目标 {last_dist:.1f})")

    # ========== 步骤 3: 输出统计信息 ==========
    print("\n📊 后处理统计:")
    print(f"   原始点数：{original_count}")
    print(f"   去重后点数：{deduped_count}")
    print(f"   排序后点数：{len(sorted_trajectory)}")
    print(f"   移除重复点：{removed_count}")
    print(f"   压缩率：{(1 - len(sorted_trajectory) / original_count) * 100:.1f}%")

    return {
        "success": True,
        "original_points": original_count,
        "deduped_points": deduped_count,
        "sorted_points": len(sorted_trajectory),
        "trajectory": sorted_trajectory,
        "removed_duplicates": removed_count
    }


def extract_floor_mask(depth_masks_path: str) -> Optional[np.ndarray]:
    """
    从 depth_masks 图像中提取地板掩码（绿色区域）
    
    Args:
        depth_masks_path: depth_masks 图像路径
        
    Returns:
        地板掩码（布尔数组），如果失败返回 None
    """
    if not os.path.exists(depth_masks_path):
        print(f"❌ depth_masks 文件不存在：{depth_masks_path}")
        return None
    
    # 读取图像
    mask_img = cv2.imread(depth_masks_path)
    if mask_img is None:
        print(f"❌ 无法读取 depth_masks 图像：{depth_masks_path}")
        return None
    
    # 转换到 HSV 颜色空间
    hsv = cv2.cvtColor(mask_img, cv2.COLOR_BGR2HSV)
    
    # 绿色的 HSV 范围
    lower_green = np.array([35, 40, 50])
    upper_green = np.array([85, 255, 255])
    
    # 创建掩码
    mask = cv2.inRange(hsv, lower_green, upper_green)
    floor_mask = mask > 0
    
    print(f"✅ 提取地板掩码：{floor_mask.sum()} 个像素 ({100*floor_mask.sum()/(mask_img.shape[0]*mask_img.shape[1]):.1f}%)")
    
    return floor_mask


def filter_trajectory_on_floor(
    trajectory: List[List[float]],
    floor_mask: np.ndarray,
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    skip_first_point: bool = True
) -> dict:
    """
    过滤轨迹点，只保留在地板上的点
    
    Args:
        trajectory: 原始轨迹点列表
        floor_mask: 地板掩码
        start_point: 起点坐标（始终保留）
        target_point: 目标点坐标（始终保留）
        skip_first_point: 是否跳过起点验证（起点始终保留）
        
    Returns:
        过滤结果字典
    """
    if not trajectory or len(trajectory) < 2:
        return {
            "success": False,
            "error": "轨迹点数量不足",
            "original_points": len(trajectory) if trajectory else 0
        }
    
    if floor_mask is None:
        return {
            "success": False,
            "error": "地板掩码为空",
            "original_points": len(trajectory)
        }
    
    print("\n" + "=" * 80)
    print("🔧 地板约束过滤")
    print("=" * 80)
    
    original_count = len(trajectory)
    print(f"原始轨迹点数：{original_count}")
    
    # ========== 步骤 1: 检查每个点是否在地板上 ==========
    print("\n📌 步骤 1: 检查每个点是否在地板上")
    
    filtered_points = []
    on_floor_points = []
    off_floor_points = []
    
    h, w = floor_mask.shape
    
    for i, point in enumerate(trajectory):
        x, y = int(round(point[0])), int(round(point[1]))
        
        # 检查边界
        if x < 0 or x >= w or y < 0 or y >= h:
            off_floor_points.append({"index": i, "point": [x, y], "reason": "out_of_bounds"})
            continue
        
        # 检查是否在地板上
        is_on_floor = bool(floor_mask[y, x])
        
        # 起点始终保留
        is_start = (i == 0)
        # 终点始终保留（轨迹的最后一个点）
        is_end = (i == len(trajectory) - 1)

        if is_on_floor or is_start or is_end:
            filtered_points.append(point)
            if is_on_floor:
                on_floor_points.append({"index": i, "point": [x, y]})
            else:
                status = "start_point" if is_start else "end_point"
                print(f"   点 {i} [{x}, {y}]: 保留 ({status})")
        else:
            off_floor_points.append({"index": i, "point": [x, y], "reason": "not_on_floor"})
            print(f"   点 {i} [{x}, {y}]: ❌ 不在地板上，移除")
    
    filtered_count = len(filtered_points)
    removed_count = original_count - filtered_count
    
    print(f"\n✅ 过滤后点数：{filtered_count}")
    print(f"   在地板上：{len(on_floor_points)} 个点")
    print(f"   不在地板上：{len(off_floor_points)} 个点 (已移除)")
    
    # ========== 步骤 2: 确保最后一个点是终点 ==========
    print("\n📌 步骤 2: 确保最后一个点是终点")
    
    if target_point is not None and len(filtered_points) > 1:
        # 找到离目标点最近的点
        min_dist = float('inf')
        target_idx = -1
        for i, point in enumerate(filtered_points):
            dist = np.sqrt((point[0] - target_point[0]) ** 2 + (point[1] - target_point[1]) ** 2)
            if dist < min_dist:
                min_dist = dist
                target_idx = i
        
        # 将离目标最近的点移到最后
        if target_idx != -1 and target_idx != len(filtered_points) - 1:
            target_item = filtered_points.pop(target_idx)
            filtered_points.append(target_item)
            print(f"   将离目标点最近的点 (索引{target_idx}, 距离{min_dist:.1f}) 移到末尾")
    
    # ========== 步骤 3: 输出统计 ==========
    print("\n📊 过滤统计:")
    print(f"   原始点数：{original_count}")
    print(f"   过滤后点数：{len(filtered_points)}")
    print(f"   移除点数：{removed_count}")
    print(f"   保留率：{len(filtered_points) / original_count * 100:.1f}%")
    
    return {
        "success": True,
        "original_points": original_count,
        "filtered_points": len(filtered_points),
        "on_floor_count": len(on_floor_points),
        "off_floor_count": len(off_floor_points),
        "removed_count": removed_count,
        "trajectory": filtered_points,
        "on_floor_details": on_floor_points,
        "off_floor_details": off_floor_points
    }


def visualize_trajectory_comparison(
    image_path: str,
    original_trajectory: List[List[float]],
    filtered_trajectory: List[List[float]],
    floor_mask: np.ndarray,
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    output_path: Optional[str] = None
) -> str:
    """
    可视化轨迹过滤前后的对比
    
    Args:
        image_path: depth_masks 图像路径
        original_trajectory: 原始轨迹
        filtered_trajectory: 过滤后的轨迹
        floor_mask: 地板掩码
        start_point: 起点坐标
        target_point: 目标点坐标
        output_path: 输出图像路径
        
    Returns:
        输出图像路径
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    
    # 创建左右并排的对比图
    combined_image = np.zeros((h, w * 2, 3), dtype=np.uint8)
    combined_image[:h, :w] = image_rgb
    combined_image[:h, w:] = image_rgb
    
    # 添加标题
    cv2.putText(combined_image, "Before Filtering", (w // 2 - 100, 30),
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    cv2.putText(combined_image, "After Filtering", (w + w // 2 - 80, 30),
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    def draw_trajectory(img, trajectory, offset_x=0):
        """在图像上绘制轨迹"""
        if len(trajectory) < 2:
            return
        
        points = [(int(p[0]) + offset_x, int(p[1])) for p in trajectory]
        
        # 绘制轨迹线
        for i in range(len(points) - 1):
            t = i / (len(points) - 1)
            color = (int(0 * (1 - t) + 255 * t), int(255 * (1 - t) + 0 * t), 0)
            cv2.line(img, points[i], points[i+1], color, 2)
        
        # 绘制轨迹点
        for i, pt in enumerate(points):
            if i == 0:
                # 起点：绿色
                cv2.circle(img, pt, 8, (0, 255, 0), -1)
            elif i == len(points) - 1:
                # 终点：红色
                cv2.circle(img, pt, 8, (0, 0, 255), -1)
            else:
                # 中间点：蓝色
                cv2.circle(img, pt, 6, (255, 0, 0), -1)
    
    # 绘制原始轨迹（左侧）
    draw_trajectory(combined_image, original_trajectory, offset_x=0)
    
    # 绘制过滤后的轨迹（右侧）
    draw_trajectory(combined_image, filtered_trajectory, offset_x=w)
    
    # 保存
    if output_path is None:
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.dirname(image_path)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(output_dir, f"{base_name}_trajectory_comparison_{timestamp}.png")
    
    output_bgr = cv2.cvtColor(combined_image, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 轨迹对比图已保存：{output_path}")
    
    return output_path


def visualize_filtered_trajectory(
    image_path: str,
    trajectory: List[List[float]],
    floor_mask: np.ndarray,
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    filter_result: Optional[dict] = None,
    output_path: Optional[str] = None
) -> str:
    """
    可视化过滤后的轨迹
    
    Args:
        image_path: depth_masks 图像路径
        trajectory: 过滤后的轨迹
        floor_mask: 地板掩码
        start_point: 起点坐标
        target_point: 目标点坐标
        filter_result: 过滤结果字典
        output_path: 输出图像路径
        
    Returns:
        输出图像路径
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    
    # 创建叠加层
    overlay = image_rgb.copy()
    
    # 绘制地板掩码（半透明绿色）
    floor_overlay = overlay.copy()
    floor_overlay[floor_mask] = [0, 255, 0]
    cv2.addWeighted(floor_overlay, 0.3, overlay, 0.7, 0, overlay)
    
    # 绘制轨迹
    if len(trajectory) >= 2:
        points = [(int(p[0]), int(p[1])) for p in trajectory]
        
        # 绘制轨迹线（渐变色）
        for i in range(len(points) - 1):
            t = i / (len(points) - 1)
            color = (int(0 * (1 - t) + 255 * t), int(255 * (1 - t) + 0 * t), 0)
            cv2.line(overlay, points[i], points[i+1], color, 3)
        
        # 绘制轨迹点
        for i, pt in enumerate(points):
            if i == 0:
                # 起点：绿色大圆圈
                cv2.circle(overlay, pt, 12, (0, 255, 0), -1)
                cv2.putText(overlay, "S", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            elif i == len(points) - 1:
                # 终点：红色大圆圈（可达终点 G）
                cv2.circle(overlay, pt, 12, (0, 0, 255), -1)
                cv2.putText(overlay, "G", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            else:
                # 中间点：白色小圆圈
                cv2.circle(overlay, pt, 6, (255, 255, 255), -1)
    
    # 添加统计信息
    stats_y = 25
    stats_x = 10
    font_scale = 0.5
    
    cv2.putText(overlay, f"Points: {len(trajectory)}", (stats_x, stats_y),
               cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 1)
    
    if filter_result:
        cv2.putText(overlay, f"Removed: {filter_result.get('removed_count', 0)}", 
                   (stats_x, stats_y + 20),
                   cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 1)
        cv2.putText(overlay, f"On Floor: {filter_result.get('on_floor_count', 0)}", 
                   (stats_x, stats_y + 40),
                   cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 1)
    
    # 保存
    if output_path is None:
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.dirname(image_path)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(output_dir, f"{base_name}_trajectory_filtered_{timestamp}.png")
    
    output_bgr = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 过滤后轨迹可视化已保存：{output_path}")
    
    return output_path


def run_main_pipeline_via_api(image_path: str, instruction: str, output_dir: str, api_url: str, save_ply: bool = False):
    """
    通过远程 API 调用点云分割服务，获取结果并保存到本地

    Args:
        image_path: 图像路径
        instruction: 指令
        output_dir: 本地输出目录
        api_url: 远程 API 服务器 URL（如 http://your-server:9000）
        save_ply: 是否请求保存 PLY 点云文件

    Returns:
        (depth_masks_path, depth_map_npy_path, output_subdir, target_point_2d, navigation_goal_point_2d, start_point_2d)
        如果失败返回 (None, None, None, None, None, None)
    """
    import requests
    import base64

    print("\n" + "=" * 80)
    print("📦 步骤 1: 通过远程 API 调用点云分割服务")
    print("=" * 80)
    print(f"图像：{image_path}")
    print(f"指令：{instruction}")
    print(f"API URL：{api_url}")
    print(f"本地输出目录：{output_dir}")
    print(f"PLY 点云保存：{'✅ 开启' if save_ply else '❌ 跳过'}")

    # 检查图像文件是否存在
    if not os.path.exists(image_path):
        print(f"❌ 图像文件不存在：{image_path}")
        return None, None, None, None, None, None

    try:
        # 调用 API
        url = f"{api_url}/api/trajectory"
        with open(image_path, 'rb') as f:
            files = {'image': (os.path.basename(image_path), f, 'image/png')}
            data = {
                'instruction': instruction,
                'skip_ply_save': str(not save_ply).lower(),
                'return_trajectory_points': 'true',
                'return_metadata': 'false',
                'return_rendered_views': 'false',
                'return_trajectory_video': 'false'
            }

            print(f"\n🚀 正在调用 API: {url}")
            response = requests.post(url, files=files, data=data, timeout=300)
            response.raise_for_status()

        result = response.json()

        if not result.get('success'):
            print(f"❌ API 返回失败: {result.get('error', 'unknown')}")
            return None, None, None, None, None, None

        print(f"✅ API 调用成功")
        print(f"   轨迹点数: {result.get('num_points', 0)}")

        # 提取点云分割结果
        segmentation_results = result.get('segmentation_results')
        if not segmentation_results:
            print(f"❌ API 响应中未找到点云分割结果")
            return None, None, None, None, None, None

        # 保存到本地
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_subdir = os.path.join(output_dir, base_name)
        os.makedirs(output_subdir, exist_ok=True)

        print(f"\n💾 正在保存点云分割结果到本地: {output_subdir}")
        for filename, base64_data in segmentation_results.items():
            file_bytes = base64.b64decode(base64_data)
            file_path = os.path.join(output_subdir, filename)
            with open(file_path, 'wb') as f:
                f.write(file_bytes)
            print(f"   ✅ {filename} ({len(file_bytes)} bytes)")

        # 确定文件路径
        depth_masks_path = os.path.join(output_subdir, f"{base_name}_depth_masks.png")
        depth_map_npy_path = os.path.join(output_subdir, f"{base_name}_depth_map.npy")

        # 提取起点、目标点 2D 坐标（从 API 响应中）
        start_point_2d = result.get('start_point')
        target_point_2d = result.get('target_point')
        navigation_goal_point_2d = result.get('navigation_goal_point')

        if start_point_2d:
            print(f"\n✅ 起点 2D: {start_point_2d}")
        if target_point_2d:
            print(f"✅ 目标物体点 2D (T): {target_point_2d}")
        if navigation_goal_point_2d:
            print(f"✅ 可达终点 2D (G): {navigation_goal_point_2d}")

        print(f"\n✅ 点云分割结果已保存到本地: {output_subdir}")
        return depth_masks_path, depth_map_npy_path, output_subdir, target_point_2d, navigation_goal_point_2d, start_point_2d

    except requests.exceptions.RequestException as e:
        print(f"❌ API 调用失败: {e}")
        return None, None, None, None, None, None
    except Exception as e:
        print(f"❌ 处理 API 响应失败: {e}")
        import traceback
        traceback.print_exc()
        return None, None, None, None, None, None


def run_main_pipeline(image_path: str, instruction: str, output_dir: str, save_ply: bool = False, use_vision_intent: bool = False, verbose_vlm: bool = False, timing_file: str = None):
    """运行 main.py 生成分割掩码

    Args:
        image_path: 图像路径
        instruction: 指令
        output_dir: 输出目录
        save_ply: 是否保存 PLY 点云文件（默认跳过以节省 I/O）
        use_vision_intent: 是否使用两阶段 VLM 意图识别（新流程）
        verbose_vlm: 是否启用 VLM 详细日志
        timing_file: 子进程计时数据输出文件路径

    Returns:
        (depth_masks_path, depth_map_npy_path, output_subdir, target_point_2d, navigation_goal_point_2d, start_point_2d)
        如果失败返回 (None, None, None, None, None, None)
    """
    print("\n" + "=" * 80)
    print("📦 步骤 1: 运行 main.py 生成分割掩码")
    print("=" * 80)
    print(f"图像：{image_path}")
    print(f"指令：{instruction}")
    print(f"输出目录：{output_dir}")
    print(f"PLY 点云保存：{'✅ 开启' if save_ply else '❌ 跳过'}")
    print(f"意图识别模式：{'🧠 两阶段 VLM（新流程）' if use_vision_intent else '📋 传统 VLM'}")

    script_dir = os.path.dirname(os.path.abspath(__file__))
    cmd = [
        sys.executable,
        "main.py",
        "--image", image_path,
        "--instruction", instruction,
        "--output-dir", output_dir,
    ]
    if not save_ply:
        cmd.append("--skip_ply_save")
    if use_vision_intent:
        cmd.append("--use_vision_intent")
    if verbose_vlm:
        cmd.append("--verbose_vlm")

    # 传递计时文件路径给子进程
    env = os.environ.copy()
    if timing_file:
        env["TIMING_FILE_PATH"] = timing_file

    # 捕获输出以提取目标点坐标
    result = subprocess.run(cmd, cwd=script_dir, capture_output=True, text=True, env=env)

    # 打印输出
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)

    if result.returncode != 0:
        print(f"❌ main.py 运行失败，退出码：{result.returncode}")
        return None, None, None, None, None, None

    # 从输出中提取起点、目标点 2D 坐标
    start_point_2d = None
    target_point_2d = None
    navigation_goal_point_2d = None
    for line in result.stdout.split('\n'):
        if '📍 起点自动计算:' in line or '📍 使用默认起点:' in line:
            try:
                # 解析 "📍 起点自动计算: (x, y)" 或 "📍 使用默认起点: (x, y)（...）" 格式
                coord_part = line.split('📍')[1].strip()
                # 提取括号中的坐标
                import re
                match = re.search(r'\((\d+),\s*(\d+)\)', coord_part)
                if match:
                    start_point_2d = [int(match.group(1)), int(match.group(2))]
                    print(f"\n✅ 提取起点 2D: {start_point_2d}")
            except Exception as e:
                print(f"⚠️ 解析起点失败：{e}")
        elif '目标物体点 2D (T):' in line:
            try:
                # 解析 "目标物体点 2D (T): [x, y]" 格式
                target_point_2d = json.loads(line.split('目标物体点 2D (T):')[1].strip())
                print(f"\n✅ 提取目标物体点 2D (T): {target_point_2d}")
            except Exception as e:
                print(f"⚠️ 解析目标物体点失败：{e}")
        elif '可达终点 2D (G):' in line:
            try:
                # 解析 "可达终点 2D (G): [x, y]" 格式
                navigation_goal_point_2d = json.loads(line.split('可达终点 2D (G):')[1].strip())
                print(f"\n✅ 提取可达终点 2D (G): {navigation_goal_point_2d}")
            except Exception as e:
                print(f"⚠️ 解析可达终点失败：{e}")

    # 查找生成的 depth_masks 图像和 depth_map.npy
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    output_subdir = os.path.join(output_dir, base_name)
    depth_masks_path = os.path.join(output_subdir, f"{base_name}_depth_masks.png")
    depth_map_npy_path = os.path.join(output_subdir, f"{base_name}_depth_map.npy")

    if not os.path.exists(depth_masks_path):
        # 尝试不带子目录的路径
        output_subdir = output_dir
        depth_masks_path = os.path.join(output_dir, f"{base_name}_depth_masks.png")
        depth_map_npy_path = os.path.join(output_dir, f"{base_name}_depth_map.npy")

    if os.path.exists(depth_masks_path):
        print(f"✅ 找到 depth_masks: {depth_masks_path}")
    else:
        print(f"❌ 未找到 depth_masks 文件")
        print(f"   预期路径：{depth_masks_path}")
        return None, None, None, None, None

    if os.path.exists(depth_map_npy_path):
        print(f"✅ 找到 depth_map.npy: {depth_map_npy_path}")
    else:
        print(f"⚠️ 未找到 depth_map.npy（终止判断将使用 depth_masks 估算深度）")
        depth_map_npy_path = None

    return depth_masks_path, depth_map_npy_path, output_subdir, target_point_2d, navigation_goal_point_2d, start_point_2d


def run_vlm_trajectory(depth_masks_path: str, depth_map_path: str, start_point: tuple = (310, 450), target_point_2d: list = None, navigation_goal_point_2d: list = None, use_self_reflection: bool = False, verbose_vlm: bool = False, timing_file: str = None):
    """运行 vlm_trajectory.py 预测轨迹

    Args:
        depth_masks_path: depth_masks 图像路径
        depth_map_path: 深度图 .npy 路径
        start_point: 起点坐标
        target_point_2d: 目标物体点 T
        navigation_goal_point_2d: 可达终点 G
        use_self_reflection: 是否启用 self-reflection 模式
        verbose_vlm: 是否启用 VLM 详细日志
        timing_file: 子进程计时数据输出文件路径
    """
    print("\n" + "=" * 80)
    mode_str = "🤖 步骤 2: 运行 VLM 轨迹预测 (Self-Reflection)" if use_self_reflection else "🤖 步骤 2: 运行 VLM 轨迹预测"
    print(mode_str)
    print("=" * 80)
    print(f"depth_masks: {depth_masks_path}")
    if use_self_reflection:
        print(f"🔄 Self-Reflection 模式：生成多条候选，VLM 选择最优")

    # 清晰打印目标点(T)和可达点(G)的对比
    print("\n" + "=" * 80)
    print("📍 VLM轨迹预测 - 终点信息确认")
    print("=" * 80)
    print(f"   起点 (S): {start_point}")
    print(f"   目标物体点 (T): {target_point_2d} - 目标物体底部中心")
    print(f"   可达终点 (G): {navigation_goal_point_2d} - 机器人站立位置（VLM轨迹终点）")
    if target_point_2d and navigation_goal_point_2d:
        import numpy as np
        dist = np.sqrt((target_point_2d[0]-navigation_goal_point_2d[0])**2 + (target_point_2d[1]-navigation_goal_point_2d[1])**2)
        print(f"   T与G距离差异: {dist:.1f} 像素")
    print(f"\n   >>> VLM将预测从 S 到 G 的轨迹")
    print("=" * 80 + "\n")

    script_dir = os.path.dirname(os.path.abspath(__file__))

    # 通过命令行参数传递，不再修改源文件
    cmd = [
        sys.executable,
        "vlm_trajectory.py",
        "--image", depth_masks_path,
        "--start-point", f"{start_point[0]},{start_point[1]}",
    ]
    if use_self_reflection:
        cmd.append("--self-reflection")
        if depth_map_path:
            cmd.extend(["--depth-map", depth_map_path])
    if target_point_2d:
        cmd.extend(["--target-point", f"{target_point_2d[0]},{target_point_2d[1]}"])
    if navigation_goal_point_2d:
        cmd.extend(["--goal-point", f"{navigation_goal_point_2d[0]},{navigation_goal_point_2d[1]}"])
    if verbose_vlm:
        cmd.append("--verbose_vlm")

    print(f"✅ 起点 (S): {start_point}")
    if target_point_2d:
        print(f"✅ 目标物体点 (T): {target_point_2d}")
    if navigation_goal_point_2d:
        print(f"✅ 可达终点 (G): {navigation_goal_point_2d}")

    # 传递计时文件路径给子进程
    env = os.environ.copy()
    if timing_file:
        env["TIMING_FILE_PATH"] = timing_file

    # 运行 vlm_trajectory.py
    result = subprocess.run(cmd, cwd=script_dir, env=env)

    if result.returncode != 0:
        print(f"❌ VLM 轨迹预测失败，退出码：{result.returncode}")
        return None

    # 返回轨迹数据路径
    base_name = os.path.splitext(os.path.basename(depth_masks_path))[0]
    output_dir = os.path.dirname(depth_masks_path)
    trajectory_data_path = os.path.join(output_dir, f"{base_name}_trajectory_data.json")

    if os.path.exists(trajectory_data_path):
        print(f"✅ 轨迹数据已保存：{trajectory_data_path}")
        return trajectory_data_path

    return None


def save_trajectory_as_pointcloud(
    trajectory: List[List[float]],
    depth_map: np.ndarray,
    image_rgb: Optional[np.ndarray] = None,
    output_path: Optional[str] = None,
    camera_intrinsics: Optional[np.ndarray] = None,
    image_width: Optional[int] = None,
    image_height: Optional[int] = None
) -> Optional[str]:
    """
    将 2D 轨迹点序列转换为 3D 点云并保存为 PLY 文件

    Args:
        trajectory: 2D 轨迹点列表 [[x1, y1], [x2, y2], ...]
        depth_map: 深度图 [H, W]（单位：米）
        image_rgb: RGB 图像 [H, W, 3]（用于给轨迹点着色）
        output_path: 输出 PLY 文件路径（如果不指定，自动生成）
        camera_intrinsics: 相机内参矩阵 [3, 3]（可选）
        image_width: 图像宽度（当没有 image_rgb 时需要）
        image_height: 图像高度（当没有 image_rgb 时需要）

    Returns:
        保存的 PLY 文件路径，失败返回 None
    """
    if not trajectory or len(trajectory) < 2:
        print("⚠️ 轨迹点数量不足，跳过 3D 点云保存")
        return None

    h, w = depth_map.shape

    # 计算相机内参
    if camera_intrinsics is not None:
        fx = camera_intrinsics[0, 0] * w
        fy = camera_intrinsics[1, 1] * h
        cx = camera_intrinsics[0, 2] * w
        cy = camera_intrinsics[1, 2] * h
    else:
        # 默认 FOV=60°
        focal_length = w / (2 * np.tan(np.deg2rad(60) / 2))
        fx = fy = focal_length
        cx, cy = w / 2, h / 2

    print("\n" + "=" * 80)
    print("🔧 轨迹点 3D 反投影")
    print("=" * 80)
    print(f"   轨迹点数：{len(trajectory)}")
    print(f"   相机内参：fx={fx:.1f}, fy={fy:.1f}, cx={cx:.1f}, cy={cy:.1f}")

    # 反投影 2D → 3D
    points_3d = []
    colors = []

    for i, point_2d in enumerate(trajectory):
        px, py = point_2d[0], point_2d[1]

        # 边界检查
        if px < 0 or px >= w or py < 0 or py >= h:
            print(f"   ⚠️ 点 {i} [{px:.1f}, {py:.1f}] 超出图像边界，跳过")
            continue

        # 从深度图查询深度值（双线性插值）
        x0, y0 = int(np.floor(px)), int(np.floor(py))
        x1, y1 = min(x0 + 1, w - 1), min(y0 + 1, h - 1)
        x0 = max(0, x0)
        y0 = max(0, y0)

        wx = px - x0
        wy = py - y0

        depth = (
            depth_map[y0, x0] * (1 - wx) * (1 - wy) +
            depth_map[y0, x1] * wx * (1 - wy) +
            depth_map[y1, x0] * (1 - wx) * wy +
            depth_map[y1, x1] * wx * wy
        )

        # 验证深度值
        if not np.isfinite(depth) or depth <= 0 or depth > 20:
            print(f"   ⚠️ 点 {i} [{px:.1f}, {py:.1f}] 深度无效 ({depth:.3f}m)，跳过")
            continue

        # 反投影到 3D 相机坐标系
        cam_x = (px - cx) * depth / fx
        cam_y = (py - cy) * depth / fy
        cam_z = depth

        points_3d.append([cam_x, cam_y, cam_z])

        # 获取颜色
        if image_rgb is not None:
            px_int, py_int = int(round(px)), int(round(py))
            px_int = max(0, min(px_int, w - 1))
            py_int = max(0, min(py_int, h - 1))
            color = image_rgb[py_int, px_int]
            colors.append(color)
        else:
            # 默认颜色：起点绿色，终点红色，中间黄色
            if i == 0:
                colors.append([0, 255, 0])  # 绿色
            elif i == len(trajectory) - 1:
                colors.append([255, 0, 0])  # 红色
            else:
                colors.append([255, 255, 0])  # 黄色

    if len(points_3d) < 2:
        print("❌ 有效 3D 点数量不足，无法保存轨迹点云")
        return None

    points_3d = np.array(points_3d, dtype=np.float32)
    colors = np.array(colors, dtype=np.uint8)

    print(f"   ✅ 有效 3D 点数：{len(points_3d)} / {len(trajectory)}")
    print(f"   X 范围：[{points_3d[:, 0].min():.3f}, {points_3d[:, 0].max():.3f}] m")
    print(f"   Y 范围：[{points_3d[:, 1].min():.3f}, {points_3d[:, 1].max():.3f}] m")
    print(f"   Z 范围（深度）：[{points_3d[:, 2].min():.3f}, {points_3d[:, 2].max():.3f}] m")

    # 生成输出路径
    if output_path is None:
        # 从 trajectory 推断输出目录
        base_dir = os.path.dirname(depth_map.ctypes.data) if hasattr(depth_map, 'ctypes') else "."
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(base_dir, f"trajectory_3d_{timestamp}.ply")

    # 保存为 PLY 文件
    with open(output_path, 'w') as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {len(points_3d)}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        f.write("property uchar red\n")
        f.write("property uchar green\n")
        f.write("property uchar blue\n")
        f.write("end_header\n")

        for pt, col in zip(points_3d, colors):
            f.write(f"{pt[0]:.6f} {pt[1]:.6f} {pt[2]:.6f} {int(col[0])} {int(col[1])} {int(col[2])}\n")

    print(f"✅ 轨迹 3D 点云已保存：{output_path} ({len(points_3d)} 个点)")
    print(f"   💡 提示：使用 MeshLab 或 CloudCompare 打开，与场景点云叠加查看")

    return output_path


def zip_output_folder(folder_path: str) -> str:
    """
    将输出文件夹打包为 zip 压缩包

    Args:
        folder_path: 要打包的文件夹路径

    Returns:
        zip 文件路径
    """
    if not os.path.isdir(folder_path):
        print(f"⚠️ 文件夹不存在，跳过打包：{folder_path}")
        return None

    # zip 文件与父目录同级
    parent_dir = os.path.dirname(folder_path)
    folder_name = os.path.basename(folder_path)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    zip_path = os.path.join(parent_dir, f"{folder_name}_{timestamp}.zip")

    print(f"\n📦 正在打包输出文件夹...")
    file_count = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, folder_path)
                zipf.write(file_path, arcname)
                file_count += 1

    zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"✅ 已打包 {file_count} 个文件 → {zip_path} ({zip_size_mb:.1f} MB)")
    return zip_path


def main():
    parser = argparse.ArgumentParser(description="统一运行 2D 轨迹规划 pipeline（集成导航终止判断）")
    parser.add_argument("--image", type=str, required=True, help="输入 RGB 图像路径（当前帧）")
    parser.add_argument("--instruction", type=str, required=True, help="用户指令，如'远处的垃圾桶'")
    parser.add_argument("--initial_image", type=str, default=None,
                        help="起始帧 RGB 图像路径（导航开始时的第一张图，用于终止判断）")
    parser.add_argument("--target_desc", type=str, default=None,
                        help="目标语义描述（用于 VLM 终止判断，默认从 instruction 推断）")
    parser.add_argument("--depth_threshold", type=float, default=termination_checker.DEPTH_THRESHOLD,
                        help=f"目标中位深度阈值（米），默认 {termination_checker.DEPTH_THRESHOLD}")
    parser.add_argument("--floor_ratio_threshold", type=float, default=termination_checker.FLOOR_PATH_RATIO_THRESHOLD,
                        help=f"起始点→目标连线地板占比阈值，默认 {termination_checker.FLOOR_PATH_RATIO_THRESHOLD}")
    parser.add_argument("--output_dir", type=str,
                        default=None,
                        help="输出目录（默认自动推导为当前目录下的 trajectory_2D_results）")
    parser.add_argument("--start_x", type=int, default=310, help="起点 x 坐标")
    parser.add_argument("--start_y", type=int, default=450, help="起点 y 坐标")
    parser.add_argument("--distance_threshold", type=float, default=5.0,
                        help="去重距离阈值（像素），默认 5.0")
    parser.add_argument("--skip_postprocess", action="store_true",
                        help="跳过轨迹点后处理")
    parser.add_argument("--filter_floor", action="store_true", default=True,
                        help="启用地板约束过滤（移除不在地板上的点），默认开启")
    parser.add_argument("--save_comparison", action="store_true",
                        help="保存过滤前后的可视化对比图")
    parser.add_argument("--render_view", action="store_true",
                        help="渲染轨迹点新视角图像")
    parser.add_argument("--render_all_views", action="store_true", default=True,
                        help="渲染所有轨迹点的新视角图像（从起点到倒数第二个点），默认开启")
    parser.add_argument("--self_reflection", action="store_true", default=True,
                        help="启用 self-reflection 模式（生成多条候选轨迹，VLM 选择最优），默认开启")
    parser.add_argument("--view_index", type=int, default=-1,
                        help="要渲染的轨迹点索引（-1=最后一个点，-2=倒数第二个点）")
    parser.add_argument("--yaw_offset", type=float, default=0.0,
                        help="额外的 yaw 偏移（度）")
    parser.add_argument("--camera_height", type=float, default=None,
                        help="相机高度偏移（米），默认None=自动从地板平面计算相机实际离地高度")
    parser.add_argument("--pitch_down", type=float, default=0.0,
                        help="相机向下俯仰角度（度），默认 0 度（水平朝向）")
    parser.add_argument("--random_seed", type=int, default=42,
                        help="随机种子，确保RANSAC平面拟合和渲染的确定性，默认 42")
    parser.add_argument("--trajectory_smooth_window", type=int, default=10,
                        help="轨迹交接处平滑窗口大小（只使用前方 N 个点计算平均方向），默认 5")
    parser.add_argument("--save_trajectory_3d", action="store_true",
                        help="将轨迹点转换为 3D 点云并保存为 PLY 文件")
    parser.add_argument("--trajectory_spacing", type=float, default=0.010,
                        help="轨迹点之间的目标物理间距（米），默认 0.010 米。插值按此间距自动计算点数，近目标点稀疏、远目标点密集")
    parser.add_argument("--resample_points", type=int, default=45,
                        help="[已弃用] 重采样的目标点数；若 --trajectory_spacing 未设置则回退使用此参数")
    parser.add_argument("--save_zip", action="store_true", default=True,
                        help="将输出文件夹打包为 zip 压缩包，默认开启")
    parser.add_argument("--save_ply", action="store_true", default=False,
                        help="保存场景 PLY 点云文件（默认跳过，开启后额外耗时数秒）")
    parser.add_argument("--resize_target", type=str, default="640x480",
                        help="统一 resize 目标尺寸，格式 '宽x高'，默认 '640x480'；设为 'none' 则不 resize")
    parser.add_argument("--api_url", type=str, default=None,
                        help="远程 API 服务器 URL（跨环境调用点云分割）")
    parser.add_argument("--use_vision_intent", action="store_true", default=False,
                        help="使用两阶段 VLM 意图识别（新流程），支持模糊指令/多目标/关系型指令")
    parser.add_argument("--verbose_vlm", action="store_true", default=False,
                        help="打印所有 VLM 的 prompt 和原始输出（用于调试）")

    args = parser.parse_args()

    # 设置 VLM 日志打印开关
    if args.verbose_vlm:
        from vlm_logger import set_verbose
        set_verbose(True)
        print("\n" + "=" * 80)
        print("📝 已启用 VLM 详细日志：将打印所有 VLM prompt 和原始输出")
        print("=" * 80 + "\n")

    # 解析目标尺寸
    if args.resize_target.lower() != "none":
        try:
            w_str, h_str = args.resize_target.split("x")
            resize_w, resize_h = int(w_str), int(h_str)
            assert resize_w > 0 and resize_h > 0
            args.resize_target_size = (resize_w, resize_h)
        except (ValueError, AssertionError):
            print(f"⚠️ 无效的目标尺寸：{args.resize_target}，使用默认 640x480")
            args.resize_target_size = (640, 480)
    else:
        args.resize_target_size = None

    # 检查输入图像
    if not os.path.exists(args.image):
        print(f"❌ 输入图像不存在：{args.image}")
        sys.exit(1)

    # 如果指定了 initial_image，检查是否存在
    if args.initial_image and not os.path.exists(args.initial_image):
        print(f"❌ 起始帧图像不存在：{args.initial_image}")
        sys.exit(1)

    # ========== 图像尺寸统一 resize ==========
    def resize_image_if_needed(image_path, label="图像"):
        """读取图像并 resize 到目标尺寸（如果需要）"""
        img = cv2.imread(image_path)
        if img is None:
            print(f"❌ 无法读取{label}：{image_path}")
            sys.exit(1)
        orig_h, orig_w = img.shape[:2]
        if args.resize_target_size is not None:
            target_w, target_h = args.resize_target_size
            if orig_w != target_w or orig_h != target_h:
                print(f"\n📐 {label}尺寸调整：{orig_w}x{orig_h} → {target_w}x{target_h}")
                img_resized = cv2.resize(img, (target_w, target_h), interpolation=cv2.INTER_AREA)
                # 保存 resize 后的图像到输出目录
                base_name = os.path.splitext(os.path.basename(image_path))[0]
                ext = os.path.splitext(image_path)[1]
                resized_path = os.path.join(args.output_dir, base_name, f"{base_name}_resized{ext}")
                os.makedirs(os.path.dirname(resized_path), exist_ok=True)
                cv2.imwrite(resized_path, img_resized)
                print(f"   已保存：{resized_path}")
                return img_resized, resized_path
            else:
                print(f"\n📐 {label}尺寸：{orig_w}x{orig_h}（已为目标尺寸，无需 resize）")
                return img, image_path
        else:
            print(f"\n📐 {label}尺寸：{orig_w}x{orig_h}")
            return img, image_path

    # Resize 当前帧图像
    current_image, resized_current_path = resize_image_if_needed(args.image, "当前帧图像")

    # Resize 初始帧图像（如果指定）
    resized_initial_path = None
    if args.initial_image:
        initial_image, resized_initial_path = resize_image_if_needed(args.initial_image, "初始帧图像")

    # 如果未指定输出目录，自动推导为当前目录下的 trajectory_2D_results
    if args.output_dir is None:
        args.output_dir = os.path.join(os.getcwd(), "trajectory_2D_results")

    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)

    # 步骤 1: 运行 main.py 生成分割掩码和深度图
    # 更新 args 中的图像路径为 resize 后的路径
    args.image = resized_current_path
    if args.initial_image and resized_initial_path:
        args.initial_image = resized_initial_path

    # 步骤 1: 运行 main.py 生成分割掩码和深度图（新流程使用两阶段 VLM 意图识别）
    # 创建计时数据文件路径
    import tempfile
    timing_dir = tempfile.mkdtemp(prefix="spagent_timing_")
    main_timing_file = os.path.join(timing_dir, "main_timing.json")
    vlm_timing_file = os.path.join(timing_dir, "vlm_timing.json")

    # 根据是否指定 API URL 选择调用方式
    if args.api_url and args.api_url.lower() != 'none':
        # 通过远程 API 调用点云分割服务
        depth_masks_path, depth_map_npy_path, output_subdir, target_point_2d, navigation_goal_point_2d, computed_start_point = run_main_pipeline_via_api(
            args.image, args.instruction, args.output_dir, api_url=args.api_url, save_ply=args.save_ply
        )
    else:
        # 本地调用 main.py
        depth_masks_path, depth_map_npy_path, output_subdir, target_point_2d, navigation_goal_point_2d, computed_start_point = run_main_pipeline(
            args.image, args.instruction, args.output_dir, save_ply=args.save_ply, use_vision_intent=args.use_vision_intent, verbose_vlm=args.verbose_vlm, timing_file=main_timing_file
        )

    if depth_masks_path is None:
        print("❌ 步骤 1 失败，无法继续")
        sys.exit(1)

    # 使用 main.py 自动计算的起点（如果可用），否则使用命令行参数
    if computed_start_point is not None:
        start_point = tuple(computed_start_point)
        print(f"\n✅ 使用 main.py 自动计算的起点: {start_point}")
    else:
        start_point = (args.start_x, args.start_y)
        print(f"\n⚠️ 未获取到自动计算的起点，使用命令行参数: {start_point}")

    # ========== 步骤 1.5: 导航终止判断（如果指定了 initial_image）==========
    if args.initial_image:
        print("\n" + "=" * 80)
        print("🛑 步骤 1.5: 导航终止判断")
        print("=" * 80)
        print(f"起始帧：{args.initial_image}")
        print(f"当前帧：{args.image}")

        # 加载深度图（优先使用真实深度图，否则用 depth_masks 估算）
        if depth_map_npy_path and os.path.exists(depth_map_npy_path):
            current_depth_map = np.load(depth_map_npy_path)
            print(f"✅ 加载真实深度图：{depth_map_npy_path}")
        else:
            current_depth_map = load_depth_map_from_image(depth_masks_path)
            print("⚠️ 使用 depth_masks 估算深度图")

        if current_depth_map is None:
            print("❌ 无法加载深度图，跳过终止判断")
        else:
            # 提取目标 mask 和地板 mask
            current_target_mask, target_area_ratio = termination_checker.extract_target_mask_from_depth_masks(depth_masks_path)
            current_floor_mask = termination_checker.extract_floor_mask_from_depth_masks(depth_masks_path)

            if current_target_mask.sum() == 0:
                print("⚠️ 目标 mask 为空，跳过终止判断")
            else:
                print(f"✅ 目标 mask 面积占比：{target_area_ratio:.1%}")
                print(f"✅ 地板 mask 面积占比：{current_floor_mask.sum()/(current_floor_mask.shape[0]*current_floor_mask.shape[1]):.1%}")

                # 目标描述（默认使用 instruction）
                target_description = args.target_desc if args.target_desc else args.instruction

                # 终止判断
                termination_result = termination_checker.check_termination(
                    start_rgb_path=args.initial_image,
                    current_rgb_path=args.image,
                    current_depth_map=current_depth_map,
                    current_floor_mask=current_floor_mask,
                    current_target_mask=current_target_mask,
                    start_target_mask=None,  # 第一帧没有起始 mask
                    start_point=start_point,
                    target_description=target_description,
                    depth_threshold=args.depth_threshold,
                    floor_path_ratio_threshold=args.floor_ratio_threshold
                )

                # 输出终止判断结果
                print("\n" + "=" * 80)
                print("📋 终止判断结果")
                print("=" * 80)
                print(f"  最终决策：{'🛑 到达，终止导航' if termination_result['reached'] else '🚶 未到达，继续轨迹规划'}")
                print(f"  VLM 判断：{'✅ 在靠近' if termination_result['vlm_reached'] else '❌ 未靠近'} (置信度: {termination_result['vlm_confidence']:.1%})")
                print(f"  几何判断：{'✅ 满足终止条件' if termination_result['geo_reached'] else '❌ 未满足'}")
                print(f"  起始点在地板上：{'是' if termination_result['start_on_floor'] else '否'}")
                print(f"  连线地板占比：{termination_result['floor_path_ratio']:.1%}")
                if termination_result['target_median_depth'] is not None:
                    print(f"  目标中位深度：{termination_result['target_median_depth']:.2f}m")

                # 保存终止判断结果到 JSON
                termination_output_path = os.path.join(output_subdir, "termination_result.json")
                termination_output = {
                    "reached": termination_result['reached'],
                    "vlm_reached": termination_result['vlm_reached'],
                    "geo_reached": termination_result['geo_reached'],
                    "vlm_confidence": termination_result['vlm_confidence'],
                    "start_on_floor": termination_result['start_on_floor'],
                    "floor_path_ratio": termination_result['floor_path_ratio'],
                    "target_median_depth": termination_result['target_median_depth'],
                    "vlm_reason": termination_result['vlm_reason'],
                    "geo_reasons": termination_result['geo_reasons']
                }
                with open(termination_output_path, 'w', encoding='utf-8') as f:
                    json.dump(termination_output, f, ensure_ascii=False, indent=2)
                print(f"\n✅ 终止判断结果已保存：{termination_output_path}")

                # 保存对比图
                comparison_path = termination_checker.create_comparison_image(
                    args.initial_image, args.image,
                    start_target_mask=None,
                    current_target_mask=current_target_mask
                )
                if comparison_path:
                    print(f"✅ 终止对比图已保存：{comparison_path}")

                # 如果判断为已到达，跳过后续轨迹规划
                if termination_result['reached']:
                    print("\n" + "=" * 80)
                    print("🛑 已到达目标，停止导航")
                    print("=" * 80)
                    return

                print("\n🚶 未到达目标，继续轨迹规划...")

    # 确定可达终点 G（用于后处理、过滤、插值等所有后续步骤）
    goal_point = navigation_goal_point_2d if navigation_goal_point_2d else target_point_2d

    # 步骤 2: 运行 VLM 轨迹预测（使用可达终点 G 作为轨迹终点）
    trajectory_data_path = run_vlm_trajectory(depth_masks_path, depth_map_npy_path, start_point, target_point_2d, navigation_goal_point_2d, use_self_reflection=args.self_reflection, verbose_vlm=args.verbose_vlm, timing_file=vlm_timing_file)

    if trajectory_data_path is None:
        print("❌ 步骤 2 失败")
        sys.exit(1)

    # 完成
    print("\n" + "=" * 80)
    print("✅ Pipeline 完成!")
    print("=" * 80)
    print(f"depth_masks: {depth_masks_path}")
    print(f"轨迹数据：{trajectory_data_path}")

    # 加载并显示轨迹数据
    with open(trajectory_data_path, 'r') as f:
        trajectory_data = json.load(f)

    print(f"\n📍 原始轨迹点序列 ({len(trajectory_data.get('trajectory', []))} 个点):")
    for i, point in enumerate(trajectory_data.get('trajectory', [])):
        marker = "🟢" if i == 0 else ("🎯" if i == len(trajectory_data['trajectory']) - 1 else "⚪")
        print(f"  {marker} 点 {i}: {point}")

    if trajectory_data.get('validation'):
        coverage = trajectory_data['validation'].get('floor_coverage', 0)
        print(f"\n📊 地板覆盖率：{coverage * 100:.1f}%")

    # ========== 步骤 3: 轨迹点后处理（去重 + 排序）==========
    if not args.skip_postprocess:
        postprocess_result = postprocess_trajectory(
            trajectory=trajectory_data.get('trajectory', []),
            start_point=start_point,
            target_point=goal_point,
            distance_threshold=args.distance_threshold
        )

        if postprocess_result['success']:
            # 更新轨迹数据
            trajectory_data['trajectory'] = postprocess_result['trajectory']
            trajectory_data['postprocess'] = postprocess_result

            # 保存后处理后的轨迹数据
            base_name = os.path.splitext(os.path.basename(trajectory_data_path))[0]
            output_dir = os.path.dirname(trajectory_data_path)
            postprocessed_path = os.path.join(output_dir, f"{base_name}_trajectory_data_postprocessed.json")

            with open(postprocessed_path, 'w', encoding='utf-8') as f:
                json.dump(trajectory_data, f, ensure_ascii=False, indent=2)

            print(f"\n✅ 后处理轨迹数据已保存：{postprocessed_path}")

            # 显示后处理后的轨迹
            print(f"\n📍 后处理轨迹点序列 ({postprocess_result['sorted_points']} 个点):")
            for i, point in enumerate(postprocess_result['trajectory']):
                marker = "🟢" if i == 0 else ("🎯" if i == len(postprocess_result['trajectory']) - 1 else "⚪")
                print(f"  {marker} 点 {i}: [{point[0]:.1f}, {point[1]:.1f}]")
        else:
            print(f"\n⚠️ 后处理失败：{postprocess_result.get('error', '未知错误')}")

    # ========== 步骤 4: 地板约束过滤（可选）==========
    if args.filter_floor:
        print("\n" + "=" * 80)
        print("🌍 步骤 4: 地板约束过滤")
        print("=" * 80)
        
        # 提取地板掩码
        floor_mask = extract_floor_mask(depth_masks_path)
        
        if floor_mask is not None:
            # 获取当前轨迹（后处理后的或原始的）
            current_trajectory = trajectory_data.get('trajectory', [])
            
            # 地板约束过滤（使用可达终点 G）
            filter_result = filter_trajectory_on_floor(
                trajectory=current_trajectory,
                floor_mask=floor_mask,
                start_point=start_point,
                target_point=goal_point
            )
            
            if filter_result['success']:
                # 更新轨迹数据
                trajectory_data['trajectory'] = filter_result['trajectory']
                trajectory_data['floor_filter'] = filter_result
                
                # 保存过滤后的轨迹数据
                base_name = os.path.splitext(os.path.basename(trajectory_data_path))[0]
                output_dir = os.path.dirname(trajectory_data_path)
                filtered_path = os.path.join(output_dir, f"{base_name}_trajectory_data_filtered.json")
                
                with open(filtered_path, 'w', encoding='utf-8') as f:
                    json.dump(trajectory_data, f, ensure_ascii=False, indent=2)
                
                print(f"\n✅ 过滤后轨迹数据已保存：{filtered_path}")
                
                # 显示过滤后的轨迹
                print(f"\n📍 过滤后轨迹点序列 ({len(filter_result['trajectory'])} 个点):")
                for i, point in enumerate(filter_result['trajectory']):
                    marker = "🟢" if i == 0 else ("🎯" if i == len(filter_result['trajectory']) - 1 else "⚪")
                    print(f"  {marker} 点 {i}: [{point[0]:.1f}, {point[1]:.1f}]")
                
                # 生成可视化（使用可达终点 G）
                if args.save_comparison:
                    # 保存过滤前后对比图
                    visualize_trajectory_comparison(
                        image_path=depth_masks_path,
                        original_trajectory=current_trajectory,
                        filtered_trajectory=filter_result['trajectory'],
                        floor_mask=floor_mask,
                        start_point=start_point,
                        target_point=goal_point
                    )
                
                # 保存过滤后轨迹可视化
                visualize_filtered_trajectory(
                    image_path=depth_masks_path,
                    trajectory=filter_result['trajectory'],
                    floor_mask=floor_mask,
                    start_point=start_point,
                    target_point=goal_point,
                    filter_result=filter_result
                )
                
                # ========== 步骤 4.5: 轨迹点3D重采样（基于真实距离）==========
                print("\n" + "=" * 80)
                print("📐 步骤 4.5: 轨迹点3D重采样（基于真实物理距离）")
                print("=" * 80)
                print(f"   目标间距：{args.trajectory_spacing} 米")

                # 加载深度图用于3D重采样
                depth_map = None
                if depth_map_npy_path and os.path.exists(depth_map_npy_path):
                    try:
                        depth_map = np.load(depth_map_npy_path)
                        print(f"✅ 加载深度图用于3D重采样：{depth_map_npy_path}")
                    except Exception as e:
                        print(f"⚠️ 加载深度图失败：{e}，将使用2D重采样")

                # 对过滤后的轨迹进行重采样（优先使用3D空间距离）
                interp_result = interpolate_trajectory(
                    trajectory=filter_result['trajectory'],
                    floor_mask=floor_mask,
                    target_spacing=args.trajectory_spacing,
                    min_points=5,
                    max_density=15.0,
                    depth_map=depth_map,
                    camera_intrinsics=None,  # 使用默认FOV=60°
                    image_width=floor_mask.shape[1],
                    image_height=floor_mask.shape[0],
                    force_resample=True  # 强制重采样
                )

                if interp_result['success'] and interp_result.get('interpolated'):
                    # 更新轨迹数据
                    trajectory_data['trajectory'] = interp_result['trajectory']
                    trajectory_data['interpolation'] = interp_result

                    # 保存重采样后的轨迹数据
                    base_name = os.path.splitext(os.path.basename(trajectory_data_path))[0]
                    output_dir = os.path.dirname(trajectory_data_path)
                    resampled_path = os.path.join(output_dir, f"{base_name}_trajectory_data_resampled.json")

                    with open(resampled_path, 'w', encoding='utf-8') as f:
                        json.dump(trajectory_data, f, ensure_ascii=False, indent=2)

                    print(f"\n✅ 重采样后轨迹数据已保存：{resampled_path}")

                    # 显示最终轨迹（融合后或重采样后）
                    final_trajectory = trajectory_data['trajectory']
                    print(f"\n📍 最终轨迹点序列 ({len(final_trajectory)} 个点):")
                    for i, point in enumerate(final_trajectory):
                        marker = "🟢" if i == 0 else ("🎯" if i == len(final_trajectory) - 1 else "⚪")
                        print(f"  {marker} 点 {i}: [{point[0]:.1f}, {point[1]:.1f}]")

                    if interp_result.get('method') == '3d_space':
                        print(f"\n📊 3D重采样统计:")
                        print(f"   3D总长度：{interp_result.get('total_length_3d_m', 0):.3f}m")
                        print(f"   平均3D间距：{interp_result.get('avg_3d_spacing_m', 0):.4f}m (目标: {interp_result.get('target_spacing_m', 0):.4f}m)")
                        print(f"   方法：3D空间距离（物理真实）")

                    # ========== 步骤 4.5.2: 可视化最终轨迹 ==========
                    # 获取输出目录（与 depth_masks 同一目录）
                    output_subdir = os.path.dirname(depth_masks_path)

                    # 在 depth_masks 上可视化（使用可达终点 G）
                    visualize_trajectory_on_image(
                        image_path=depth_masks_path,
                        trajectory=final_trajectory,
                        start_point=start_point,
                        target_point=goal_point,
                        title=f"Final Trajectory ({len(final_trajectory)} points)",
                        output_dir=output_subdir
                    )

                    # 在原图上可视化（使用可达终点 G）
                    visualize_trajectory_on_image(
                        image_path=args.image,
                        trajectory=final_trajectory,
                        start_point=start_point,
                        target_point=goal_point,
                        title=f"Final Trajectory on Original Image",
                        output_dir=output_subdir
                    )

                elif interp_result['success']:
                    print(f"\nℹ️  重采样成功但未生成新点 ({len(filter_result['trajectory'])} 个原始点)")
            else:
                print(f"\n⚠️ 地板约束过滤失败：{filter_result.get('error', '未知错误')}")
        else:
            print("\n⚠️ 无法提取地板掩码，跳过地板约束过滤")

    # ========== 步骤 5: 新视角渲染（可选，由 render_all_elevated_trajectory_points 统一处理）==========
    if args.render_view or args.render_all_views:
        print("\n" + "=" * 80)
        print("🎨 步骤 5: 新视角渲染（统一处理）")
        print("=" * 80)
        print("   ℹ️  将使用 render_all_elevated_trajectory_points 统一渲染所有轨迹点")
        print("   ℹ️  统一渲染包括：相机抬高位置 + 插值点 + 原始轨迹点（跳过第一个点）")
        print("")

        from render_trajectory_view import TrajectoryViewRenderer, load_depth_map_from_npy, load_depth_map_from_image

        # 加载原始图像
        original_image = cv2.imread(args.image)
        if original_image is None:
            print(f"❌ 无法读取原始图像：{args.image}")
        else:
            base_name = os.path.splitext(os.path.basename(args.image))[0]

            # 优先从 .npy 加载真实深度图（使用 run_main_pipeline 返回的实际路径）
            depth_map = load_depth_map_from_npy(depth_map_npy_path) if depth_map_npy_path else None

            # 如果 .npy 不存在，使用 depth_masks 作为备用
            if depth_map is None:
                print("⚠️ 真实深度图不可用，尝试使用 depth_masks 估算")
                depth_map = load_depth_map_from_image(depth_masks_path)

            if depth_map is not None:
                # 生成点云（从深度图）
                print("🔧 从深度图生成点云...")
                h, w = depth_map.shape
                focal_length = w / (2 * np.tan(np.deg2rad(60) / 2))
                cx, cy = w / 2, h / 2

                y, x = np.meshgrid(np.arange(h), np.arange(w), indexing='ij')
                cam_x = (x - cx) * depth_map / focal_length
                cam_y = (y - cy) * depth_map / focal_length
                cam_z = depth_map

                point_cloud = np.stack([cam_x, cam_y, cam_z], axis=-1)
                print(f"✅ 点云已生成：{w}x{h}")

                # 获取当前轨迹（优先使用插值后的，其次是过滤后的，最后是后处理后的）
                current_trajectory = trajectory_data.get('trajectory', [])

                if len(current_trajectory) >= 2:
                    # 渲染新视角
                    renderer = TrajectoryViewRenderer(output_dir=os.path.dirname(depth_masks_path))

                    # ========== 保存抬高后的轨迹点云 ==========
                    print("\n" + "=" * 80)
                    print("📍 保存抬高后的轨迹点点云")
                    print("=" * 80)

                    # 提取地板掩码（用于计算地面高度）
                    floor_mask_for_camera = None
                    try:
                        floor_mask_for_camera = extract_floor_mask(depth_masks_path)
                        if floor_mask_for_camera is not None:
                            print(f"   ✅ 已加载 floor_mask 用于计算地面高度")
                        else:
                            print(f"   ⚠️ 无法提取 floor_mask，将使用默认地面高度")
                    except Exception as e:
                        print(f"   ⚠️ 提取 floor_mask 失败：{e}，将使用默认地面高度")

                    elevated_result = renderer.render_all_elevated_trajectory_points(
                        point_cloud=point_cloud,
                        original_image=original_image,
                        depth_map=depth_map,
                        trajectory=current_trajectory,
                        image_path=args.image,
                        camera_height_offset=args.camera_height,
                        save_pointcloud=True,
                        save_camera_origin=True,  # 保存相机初始位置点云
                        floor_mask=floor_mask_for_camera,  # 传入地板掩码
                        camera_approach_spacing=args.trajectory_spacing,  # 相机到轨迹起点插值间距
                        smooth_window=args.trajectory_smooth_window,  # 平滑窗口大小
                        random_seed=args.random_seed,  # 随机种子
                        pitch_down_degrees=args.pitch_down  # 向下俯仰角度
                    )

                    if elevated_result.get('success'):
                        trajectory_data['elevated_trajectory_ply'] = elevated_result.get('ply_path')
                        # 保存实际使用的相机高度（可能是自动计算的）
                        trajectory_data['camera_height_offset'] = elevated_result.get('camera_height_offset', args.camera_height)
                        # 保存统一抬高轨迹点云路径
                        if 'unified_elevated_trajectory_ply' in elevated_result and elevated_result['unified_elevated_trajectory_ply']:
                            trajectory_data['unified_elevated_trajectory_ply'] = elevated_result['unified_elevated_trajectory_ply']
                        # 保存渲染视图和MP4（已在render_trajectory_view.py中转换为文件名）
                        if 'unified_rendered_views' in elevated_result:
                            trajectory_data['unified_rendered_views'] = elevated_result['unified_rendered_views']
                        if 'trajectory_video_mp4' in elevated_result:
                            trajectory_data['trajectory_video_mp4'] = elevated_result['trajectory_video_mp4']
                        # 更新 JSON 文件
                        with open(trajectory_data_path, 'w', encoding='utf-8') as f:
                            json.dump(trajectory_data, f, ensure_ascii=False, indent=2)
                        print(f"\n✅ 抬高轨迹、相机初始位置、插值和统一轨迹点云信息已保存到 JSON")
                    else:
                        print(f"\n⚠️ 保存抬高轨迹点云失败：{elevated_result.get('error', '未知错误')}")
                else:
                    print("⚠️ 轨迹点数量不足，跳过渲染")
            else:
                print("❌ 深度图加载失败，跳过渲染")
                print(f"   depth_map_npy_path: {depth_map_npy_path if depth_map_npy_path else 'None'}")
                print(f"   depth_masks_path: {depth_masks_path}")

    # ========== 保存轨迹为 3D 点云 ==========
    if args.save_trajectory_3d:
        print("\n" + "=" * 80)
        print("🌐 额外步骤: 保存轨迹 3D 点云")
        print("=" * 80)

        # 获取当前轨迹
        current_trajectory = trajectory_data.get('trajectory', [])

        if len(current_trajectory) >= 2:
            # 加载深度图（使用 run_main_pipeline 返回的实际路径）
            depth_map = load_depth_map_from_npy(depth_map_npy_path) if depth_map_npy_path else None

            if depth_map is None:
                # 备用方案：从 depth_masks 估算
                print("⚠️ 真实深度图不存在，使用 depth_masks 估算深度")
                depth_map = load_depth_map_from_image(depth_masks_path)

            if depth_map is not None:
                # 加载原始图像用于着色
                image_rgb = cv2.imread(args.image)
                if image_rgb is not None:
                    image_rgb = cv2.cvtColor(image_rgb, cv2.COLOR_BGR2RGB)

                # 生成输出路径
                output_subdir = os.path.dirname(depth_masks_path)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                output_ply_path = os.path.join(output_subdir, f"{base_name}_trajectory_3d_{timestamp}.ply")

                # 保存轨迹 3D 点云
                saved_path = save_trajectory_as_pointcloud(
                    trajectory=current_trajectory,
                    depth_map=depth_map,
                    image_rgb=image_rgb,
                    output_path=output_ply_path
                )

                if saved_path:
                    trajectory_data['trajectory_3d_ply'] = os.path.basename(saved_path)
                    # 更新 JSON 文件
                    with open(trajectory_data_path, 'w', encoding='utf-8') as f:
                        json.dump(trajectory_data, f, ensure_ascii=False, indent=2)
            else:
                print("❌ 无法加载深度图，跳过轨迹 3D 点云保存")
        else:
            print("⚠️ 轨迹点数量不足，跳过 3D 点云保存")

    # ========== 打包输出 ==========
    if args.save_zip:
        # depth_masks_path 是文件路径，取其父目录（如 test_navigation_2 文件夹）
        output_subfolder = os.path.dirname(depth_masks_path)
        zip_output_folder(output_subfolder)

    # ========== 输出模型推理耗时统计 ==========
    from timing_tracker import aggregate_and_print

    timing_files = []
    if main_timing_file and os.path.exists(main_timing_file):
        timing_files.append(main_timing_file)
    if vlm_timing_file and os.path.exists(vlm_timing_file):
        timing_files.append(vlm_timing_file)

    if timing_files:
        aggregate_and_print(timing_files)
    else:
        print("⏱️  没有记录到任何模型推理耗时")

    # ========== 打印所有 VLM 日志（如果启用） ==========
    from vlm_logger import print_all_vlm_logs
    print_all_vlm_logs()


if __name__ == "__main__":
    main()
