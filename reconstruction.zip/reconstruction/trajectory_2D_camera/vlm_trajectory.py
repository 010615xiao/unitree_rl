#!/usr/bin/env python3
"""
导航轨迹点序列

1. 轨迹点必须严格限制在地板上
2. 输出格式：[[x1, y1], [x2, y2], ...]
3. 可视化

- 区分 T (语义目标) 和 G (可达终点)
- T: 目标物体的位置（语义上的终点）
- G: 机器人可以站立的位置（物理上的终点，在地板上且靠近目标）
"""

import base64
import json
import os
import re
import cv2
import numpy as np
from openai import OpenAI
from datetime import datetime
from classic_trajectory_planner import compute_navigation_goal_from_masks
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor, as_completed

# 配置
DEFAULT_IMAGE_PATH = "/workspace/wxd/Agent/images/trajectory_2D_results/frame_0110/frame_0110_depth_masks.png"
VLM_BASE_URL = "http://localhost:8011/v1"
VLM_MODEL = "RoboBrain2.5-8B"

# 默认起点/目标/可达终点（可通过命令行参数覆盖）
DEFAULT_START_POINT = (310, 450)
DEFAULT_TARGET_POINT = [802, 291]
DEFAULT_NAVIGATION_GOAL_POINT = [804, 331]

# Self-reflection 配置
NUM_CANDIDATES = 6          # 候选轨迹数量（单图叠加展示）
MAX_SELECTION_ROUNDS = 2    # 最大选择轮次（若都不行则重试）


def encode_image_to_base64(image_path: str) -> str:
    """将图像编码为 base64"""
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")


def compute_trajectory_metrics(
    trajectory: list,
    floor_mask: np.ndarray,
    target_point: list,
    navigation_goal_point: list,
    depth_map: np.ndarray = None,
    skip_first_point: bool = True,
    obstacle_margin_px: float = 10.0
) -> dict:
    """

    Args:
        trajectory: 轨迹点列表 [[x1,y1], ...]
        floor_mask: 地板掩码 [H, W] bool
        target_point: 目标点 T [x, y]
        navigation_goal_point: 可达终点 G [x, y]
        depth_map: 深度图 [H, W] (米)，用于计算 3D 距离
        skip_first_point: 是否跳过起点（用户指定的固定位置）
        obstacle_margin_px: 安全边距阈值（像素）

    Returns:
        {
            "total_points": int,
            "on_floor_count": int,
            "on_floor_rate": float,       # 在地板上的百分比
            "dist_3d_to_G": float,        # 3D 欧氏距离到 G（米），无深度图则为 None
            "dist_2d_to_G": float,        # 2D 像素距离到 G
            "endpoint_angle_to_T": float, # 倒数第二点→G 方向 vs G→T 方向的夹角（度）
            "min_obstacle_dist": float,   # 第2点~倒数第2点中到障碍物的最近距离（像素）
            "avg_obstacle_dist": float,   # 第2点~倒数第2点中到障碍物的平均距离（像素）
            "has_collision": bool,        # 是否有碰撞（点在非绿色区域）
            "path_smoothness": float,     # 平均转弯角度（度），越小越平滑
            "total_path_len_2d": float,   # 2D 总路径长度（像素）
            "fail_reasons": list[str]     # 失败原因列表
        }
    """
    h, w = floor_mask.shape
    if len(trajectory) < 2:
        return {"fail_reasons": ["轨迹点不足"]}

    traj_pts = np.array(trajectory, dtype=np.float32)
    points_to_check = traj_pts[1:] if skip_first_point else traj_pts
    # 避障计算范围：第2个点 至 倒数第2个点（包含两端）
    obstacle_check_pts = traj_pts[1:-1] if len(traj_pts) >= 3 else traj_pts[1:]

    # ========== 1. 地板覆盖率 ==========
    on_floor = []
    for pt in points_to_check:
        px, py = int(pt[0]), int(pt[1])
        if 0 <= px < w and 0 <= py < h:
            on_floor.append(bool(floor_mask[py, px]))
        else:
            on_floor.append(False)  # 超出图像范围 = 不在地板上

    on_floor_count = sum(on_floor)
    on_floor_rate = on_floor_count / len(points_to_check) if len(points_to_check) > 0 else 0

    # ========== 2. 终点距离（2D + 3D）==========
    endpoint = traj_pts[-1]
    end_x, end_y = int(endpoint[0]), int(endpoint[1])
    goal_x, goal_y = navigation_goal_point[0], navigation_goal_point[1]

    dist_2d_to_G = np.sqrt((end_x - goal_x)**2 + (end_y - goal_y)**2)

    dist_3d_to_G = None
    if depth_map is not None and 0 <= end_x < w and 0 <= end_y < h and 0 <= goal_x < w and 0 <= goal_y < h:
        end_depth = depth_map[end_y, end_x]
        goal_depth = depth_map[goal_y, goal_x]
        if np.isfinite(end_depth) and np.isfinite(goal_depth) and end_depth > 0 and goal_depth > 0:
            # 3D 坐标（使用默认内参 FOV=60°）
            focal = w / (2 * np.tan(np.deg2rad(30)))
            cx, cy = w / 2, h / 2
            end_3d = np.array([
                (end_x - cx) * end_depth / focal,
                (end_y - cy) * end_depth / focal,
                end_depth
            ])
            goal_3d = np.array([
                (goal_x - cx) * goal_depth / focal,
                (goal_y - cy) * goal_depth / focal,
                goal_depth
            ])
            dist_3d_to_G = float(np.linalg.norm(end_3d - goal_3d))

    # ========== 3. 终点朝向角度 ==========
    # 倒数第二个点 → 可达终点 G 的方向 与 G → T 的方向夹角
    if len(traj_pts) >= 2:
        penultimate = traj_pts[-2]
        pen_x, pen_y = int(penultimate[0]), int(penultimate[1])

        # 倒数第二个点 到 G 的方向
        to_G_vec = np.array([goal_x - pen_x, goal_y - pen_y], dtype=np.float32)
        to_G_norm = np.linalg.norm(to_G_vec)
        if to_G_norm > 1e-6:
            to_G_dir = to_G_vec / to_G_norm
        else:
            to_G_dir = np.array([0, 1])

        # G 到 T 的方向（期望的机器人面向方向）
        to_T_vec = np.array([target_point[0] - goal_x, target_point[1] - goal_y], dtype=np.float32)
        to_T_norm = np.linalg.norm(to_T_vec)
        if to_T_norm > 1e-6:
            to_T_dir = to_T_vec / to_T_norm
        else:
            to_T_dir = np.array([0, 1])

        cos_angle = np.clip(np.dot(to_G_dir, to_T_dir), -1, 1)
        endpoint_angle_to_T = float(np.arccos(cos_angle) * 180 / np.pi)
    else:
        endpoint_angle_to_T = 90.0

    # ========== 4. 障碍物距离（第2点 至 倒数第2点）==========
    # 使用距离变换高效计算到最近障碍物的距离
    obstacle_map = ~floor_mask  # True = 障碍物
    has_collision = False

    # 检查是否有碰撞
    for pt in points_to_check:
        px, py = int(pt[0]), int(pt[1])
        if 0 <= px < w and 0 <= py < h:
            if not floor_mask[py, px]:
                has_collision = True

    # 用距离变换计算障碍物距离场
    obs_dists = []
    if np.any(obstacle_map) and len(obstacle_check_pts) > 0:
        obstacle_uint8 = obstacle_map.astype(np.uint8) * 255
        dist_transform = cv2.distanceTransform(obstacle_uint8, cv2.DIST_L2, 3)
        for pt in obstacle_check_pts:
            px, py = int(pt[0]), int(pt[1])
            if 0 <= px < w and 0 <= py < h:
                obs_dists.append(dist_transform[py, px])

    min_obstacle_dist = float(min(obs_dists)) if obs_dists else 999.0
    avg_obstacle_dist = float(np.mean(obs_dists)) if obs_dists else 999.0

    # ========== 5. 路径平滑度（平均转弯角度）==========
    turning_angles = []
    for i in range(1, len(traj_pts) - 1):
        seg1 = traj_pts[i] - traj_pts[i-1]
        seg2 = traj_pts[i+1] - traj_pts[i]
        n1 = np.linalg.norm(seg1)
        n2 = np.linalg.norm(seg2)
        if n1 > 1e-6 and n2 > 1e-6:
            cos_a = np.clip(np.dot(seg1, seg2) / (n1 * n2), -1, 1)
            angle = np.arccos(cos_a) * 180 / np.pi  # 转弯角度 = 180 - 前进角
            turning_angles.append(angle)
    path_smoothness = float(np.mean(turning_angles)) if turning_angles else 0.0

    # ========== 6. 2D 总路径长度 ==========
    total_path_len_2d = 0.0
    for i in range(len(traj_pts) - 1):
        total_path_len_2d += np.linalg.norm(traj_pts[i+1] - traj_pts[i])

    # ========== 7. 判断失败原因 ==========
    # 注意：不再做硬过滤，而是标记"严重问题"供 VLM 参考
    fail_reasons = []

    # 地板覆盖率 < 50% → 严重问题（阈值从 80% 降到 50%）
    if on_floor_rate < 0.5:
        fail_reasons.append(f"地板覆盖率极低 ({on_floor_rate:.0%} < 50%)")

    # 终点距 G 的 3D 距离 > 1.0m（或 2D > 80px 无深度图时）
    if dist_3d_to_G is not None and dist_3d_to_G > 1.0:
        fail_reasons.append(f"终点距 G 过远 (3D: {dist_3d_to_G:.2f}m > 1.0m)")
    elif dist_3d_to_G is None and dist_2d_to_G > 80:
        fail_reasons.append(f"终点距 G 过远 (2D: {dist_2d_to_G:.0f}px > 80px)")

    # 终点朝向角度 > 90°（从 60° 放宽到 90°）
    if endpoint_angle_to_T > 90:
        fail_reasons.append(f"终点背离目标 (角度 {endpoint_angle_to_T:.0f}° > 90°)")

    # 碰撞不标记为 FAIL，因为 VLM 轨迹精度有限，只需提醒

    # 避障距离：平均 < 8px 或最近 < 3px 才标记警告
    if avg_obstacle_dist < 8.0:
        fail_reasons.append(f"平均避障距离偏小 (Avg: {avg_obstacle_dist:.0f}px < 8px)")
    if min_obstacle_dist < 3.0:
        fail_reasons.append(f"最近避障距离极近 (Min: {min_obstacle_dist:.0f}px < 3px)")

    return {
        "total_points": len(trajectory),
        "on_floor_count": on_floor_count,
        "on_floor_rate": on_floor_rate,
        "dist_3d_to_G": dist_3d_to_G,
        "dist_2d_to_G": dist_2d_to_G,
        "endpoint_angle_to_T": endpoint_angle_to_T,
        "min_obstacle_dist": min_obstacle_dist,
        "avg_obstacle_dist": avg_obstacle_dist,
        "has_collision": has_collision,
        "path_smoothness": path_smoothness,
        "total_path_len_2d": total_path_len_2d,
        "fail_reasons": fail_reasons
    }


def parse_trajectory(response_text: str) -> list:
    """从 VLM 响应中解析轨迹点"""
    # [[x1, y1], [x2, y2], ...] — 支持负数坐标
    pattern = r'\[\s*\[\s*-?\d+\.?\d*\s*,\s*-?\d+\.?\d*\s*\][\s*,\s*\[\s*-?\d+\.?\d*\s*,\s*-?\d+\.?\d*\s*\]]*\s*\]'
    matches = re.findall(pattern, response_text)

    if matches:
        # 取最后一个匹配（通常是主要答案）
        traj_str = matches[-1]
        try:
            trajectory = json.loads(traj_str)
            # 验证格式
            if isinstance(trajectory, list) and all(
                isinstance(pt, list) and len(pt) == 2 and
                all(isinstance(c, (int, float)) for c in pt)
                for pt in trajectory
            ):
                # 去重：移除连续重复的点
                deduped = [trajectory[0]]
                for pt in trajectory[1:]:
                    if pt != deduped[-1]:
                        deduped.append(pt)
                return deduped
        except json.JSONDecodeError:
            pass

    # 尝试匹配 (x, y) 格式 — 支持负数
    # 优先从 <trajectory> 标签内提取，避免 analysis 等段落中的坐标干扰
    traj_block = response_text
    if "<trajectory>" in response_text and "</trajectory>" in response_text:
        traj_block = response_text.split("<trajectory>")[1].split("</trajectory>")[0]

    pattern2 = r'\(\s*(-?\d+\.?\d*)\s*,\s*(-?\d+\.?\d*)\s*\)'
    matches2 = re.findall(pattern2, traj_block)
    if matches2:
        trajectory = [[float(x), float(y)] for x, y in matches2]
        # 去重：移除连续重复的点
        deduped = [trajectory[0]]
        for pt in trajectory[1:]:
            if pt != deduped[-1]:
                deduped.append(pt)
        return deduped

    # 尝试匹配 x,y 格式（每行一个点）
    lines = response_text.strip().split('\n')
    trajectory = []
    for line in lines:
        line = line.strip()
        if ',' in line:
            parts = line.replace('[', '').replace(']', '').replace('(', '').replace(')', '').split(',')
            if len(parts) == 2:
                try:
                    x, y = float(parts[0].strip()), float(parts[1].strip())
                    trajectory.append([x, y])
                except ValueError:
                    pass

    if len(trajectory) >= 2:
        # 去重：移除连续重复的点
        deduped = [trajectory[0]]
        for pt in trajectory[1:]:
            if pt != deduped[-1]:
                deduped.append(pt)
        return deduped

    return None


def draw_multiple_trajectories_grid(
    image_path: str,
    trajectories: list,
    floor_mask_path: str = None,
    start_point: tuple = None,
    target_point: list = None,
    output_path: str = None
) -> str:
    """
    Args:
        image_path: 原始图像路径
        trajectories: 轨迹列表，每个是 [[x1,y1], ...] 格式
        floor_mask_path: floor 掩码路径
        start_point: 起点 (x, y)
        target_point: 目标点 [x, y]
        output_path: 输出路径

    Returns:
        输出图像路径
    """
    import math

    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]

    num_trajectories = len(trajectories)
    if num_trajectories == 0:
        return None

    # 计算网格布局：2列，自适应行数
    cols = 2
    rows = math.ceil(num_trajectories / cols)

    # 子图尺寸（缩放原图）
    subplot_scale = 0.45
    sw, sh = int(w * subplot_scale), int(h * subplot_scale)

    # 标题栏高度
    title_h = 30
    # 子图间距
    gap = 8

    # 总画布尺寸（顶部留一行总标题）
    total_title_h = title_h
    canvas_w = cols * sw + (cols + 1) * gap
    canvas_h = total_title_h + gap + rows * (sh + title_h + gap)

    canvas = np.ones((canvas_h, canvas_w, 3), dtype=np.uint8) * 255  # 白色背景

    # 绘制总标题
    total_title_bg = np.ones((total_title_h, canvas_w, 3), dtype=np.uint8) * 240
    cv2.putText(total_title_bg, "VLM Candidate Trajectories — Select the BEST one (reply 1-N or NONE)",
               (15, total_title_h - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    canvas[:total_title_h, :] = total_title_bg

    # 内容区域起始y
    y_base = total_title_h + gap

    # 加载 floor 掩码
    floor_mask = None
    if floor_mask_path and os.path.exists(floor_mask_path):
        mask_img = cv2.imread(floor_mask_path)
        if mask_img is not None:
            hsv = cv2.cvtColor(mask_img, cv2.COLOR_BGR2HSV)
            lower_green = np.array([35, 40, 50])
            upper_green = np.array([85, 255, 255])
            floor_mask = cv2.inRange(hsv, lower_green, upper_green) > 0

    # 统一使用红色绘制轨迹，避免颜色混淆
    traj_color = (255, 50, 50)  # 鲜艳红色

    for idx in range(num_trajectories):
        traj = trajectories[idx]
        if len(traj) < 2:
            continue

        # 计算子图位置
        row = idx // cols
        col = idx % cols
        x_offset = gap + col * (sw + gap)
        y_offset = y_base + row * (sh + title_h + gap)

        # 缩放原图到子图
        subplot = cv2.resize(image_rgb, (sw, sh))
        overlay = subplot.copy()

        # 缩放轨迹坐标
        sx, sy = sw / w, sh / h
        traj_points = [(int(pt[0] * sx), int(pt[1] * sy)) for pt in traj]

        # 绘制轨迹线段
        for i in range(len(traj_points) - 1):
            t = i / max(len(traj_points) - 1, 1)
            alpha = 0.5 + 0.5 * t  # 渐变透明度（起点淡→终点浓）
            segment_color = tuple(int(c * alpha) for c in traj_color)
            cv2.line(overlay, traj_points[i], traj_points[i+1], segment_color, 2)

            # 绘制箭头
            arrow_length = 8
            arrow_angle = 25
            angle = np.arctan2(traj_points[i+1][1] - traj_points[i][1],
                              traj_points[i+1][0] - traj_points[i][0])
            arrow_pt1 = (
                int(traj_points[i+1][0] - arrow_length * np.cos(angle - np.deg2rad(arrow_angle))),
                int(traj_points[i+1][1] - arrow_length * np.sin(angle - np.deg2rad(arrow_angle)))
            )
            arrow_pt2 = (
                int(traj_points[i+1][0] - arrow_length * np.cos(angle + np.deg2rad(arrow_angle))),
                int(traj_points[i+1][1] - arrow_length * np.sin(angle + np.deg2rad(arrow_angle)))
            )
            cv2.line(overlay, traj_points[i+1], arrow_pt1, segment_color, 2)
            cv2.line(overlay, traj_points[i+1], arrow_pt2, segment_color, 2)

        # 绘制轨迹点
        for i, pt in enumerate(traj_points):
            if i == 0:
                # 起点：绿色大圆圈 + "S"
                cv2.circle(overlay, pt, 8, (0, 200, 0), -1)
                cv2.circle(overlay, pt, 10, (255, 255, 255), 2)
                cv2.putText(overlay, "S", (pt[0] - 5, pt[1] + 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            elif i == len(traj_points) - 1:
                # 终点：红色大圆圈 + "G"
                cv2.circle(overlay, pt, 8, (0, 0, 255), -1)
                cv2.circle(overlay, pt, 10, (255, 255, 255), 2)
                cv2.putText(overlay, "G", (pt[0] - 5, pt[1] + 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            else:
                # 中间点：白色小圆圈
                cv2.circle(overlay, pt, 4, (255, 255, 255), -1)
                cv2.circle(overlay, pt, 4, traj_color, 1)

        # 绘制目标点 T
        if target_point:
            tx, ty = int(target_point[0] * sx), int(target_point[1] * sy)
            cv2.circle(overlay, (tx, ty), 7, (0, 0, 255), -1)
            cv2.circle(overlay, (tx, ty), 9, (255, 255, 255), 2)
            cv2.putText(overlay, "T", (tx - 5, ty + 5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

        # 将子图画到画布上
        canvas[y_offset:y_offset+sh, x_offset:x_offset+sw] = overlay

        # 绘制标题栏（在子图上方）
        title_bg = np.ones((title_h, sw, 3), dtype=np.uint8) * 220  # 浅灰背景
        cv2.putText(title_bg, f"Trajectory #{idx+1}  ({len(traj)} points)",
                   (10, title_h - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        canvas[y_offset-title_h:y_offset, x_offset:x_offset+sw] = title_bg

    # 保存
    if output_path is None:
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.dirname(image_path)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(output_dir, f"{base_name}_multi_trajectory_grid_{timestamp}.png")

    output_bgr = cv2.cvtColor(canvas, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 多轨迹网格对比图已保存：{output_path}")

    return output_path


def draw_multiple_trajectories(
    image_path: str,
    trajectories: list,
    floor_mask_path: str = None,
    start_point: tuple = None,
    target_point: list = None,
    output_path: str = None
) -> str:
    """
    将多条轨迹绘制在同一张图上，编号区分
    用于 VLM self-reflection 选择

    Args:
        image_path: 原始图像路径
        trajectories: 轨迹列表，每个是 [[x1,y1], ...] 格式
        floor_mask_path: floor 掩码路径
        start_point: 起点 (x, y)
        target_point: 目标点 [x, y]
        output_path: 输出路径

    Returns:
        输出图像路径
    """
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    overlay = image_rgb.copy()

    # 加载 floor 掩码
    floor_mask = None
    if floor_mask_path and os.path.exists(floor_mask_path):
        mask_img = cv2.imread(floor_mask_path)
        if mask_img is not None:
            hsv = cv2.cvtColor(mask_img, cv2.COLOR_BGR2HSV)
            lower_green = np.array([35, 40, 50])
            upper_green = np.array([85, 255, 255])
            floor_mask = cv2.inRange(hsv, lower_green, upper_green) > 0

    # 为每条轨迹分配不同颜色
    colors = [
        (255, 0, 0),    # 蓝色
        (0, 255, 0),    # 绿色
        (255, 165, 0),  # 橙色
        (255, 0, 255),  # 品红
        (0, 255, 255),  # 青色
        (255, 255, 0),  # 黄色
        (128, 0, 128),  # 紫色
        (0, 128, 255),  # 橙红
    ]

    # 绘制每条轨迹
    for idx, traj in enumerate(trajectories):
        if len(traj) < 2:
            continue

        color = colors[idx % len(colors)]
        traj_points = [(int(pt[0]), int(pt[1])) for pt in traj]

        # 绘制轨迹线段
        for i in range(len(traj_points) - 1):
            t = i / max(len(traj_points) - 1, 1)
            alpha = 0.3 + 0.7 * t  # 渐变透明度
            segment_color = tuple(int(c * alpha) for c in color)
            cv2.line(overlay, traj_points[i], traj_points[i+1], segment_color, 3)

        # 绘制轨迹点
        for i, pt in enumerate(traj_points):
            if i == 0:
                # 起点：白色大圆圈 + "S"
                cv2.circle(overlay, pt, 10, (255, 255, 255), -1)
                cv2.circle(overlay, pt, 12, (200, 200, 200), 2)
                cv2.putText(overlay, "S", (pt[0] - 6, pt[1] + 6),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
            elif i == len(traj_points) - 1:
                # 终点：带编号的彩色圆圈
                cv2.circle(overlay, pt, 12, color, -1)
                cv2.circle(overlay, pt, 14, (255, 255, 255), 2)
                cv2.putText(overlay, f"G{idx+1}", (pt[0] - 10, pt[1] + 6),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
            else:
                # 中间点：小圆圈
                cv2.circle(overlay, pt, 5, color, -1)

        # 在起点附近标注轨迹编号
        if len(traj_points) > 0:
            label_pt = (traj_points[0][0] + 15, traj_points[0][1] - 15 * (idx + 1))
            # 确保标签在图像内
            label_pt = (max(10, min(label_pt[0], w - 30)),
                       max(20, min(label_pt[1], h - 10)))
            cv2.putText(overlay, f"#{idx+1}", label_pt,
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

    # 绘制目标点标记（如果有）
    if target_point:
        tx, ty = int(target_point[0]), int(target_point[1])
        cv2.circle(overlay, (tx, ty), 10, (0, 0, 255), -1)
        cv2.circle(overlay, (tx, ty), 13, (255, 255, 255), 2)
        cv2.putText(overlay, "T", (tx - 7, ty + 7),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

    # 添加图例
    legend_y = 30
    for idx in range(len(trajectories)):
        color = colors[idx % len(colors)]
        legend_x = 10
        cv2.circle(overlay, (legend_x + 10, legend_y + idx * 25), 6, color, -1)
        cv2.putText(overlay, f"Trajectory #{idx+1}", (legend_x + 22, legend_y + idx * 25 + 5),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    # 保存
    if output_path is None:
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.dirname(image_path)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(output_dir, f"{base_name}_multi_trajectory_{timestamp}.png")

    output_bgr = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 多轨迹对比图已保存：{output_path}")

    return output_path


def select_best_trajectory_vlm(
    image_path: str,
    trajectories: list,
    client: OpenAI,
    model: str,
    start_point: tuple,
    target_point: list,
    navigation_goal_point: list,
    floor_mask_path: str = None,
    depth_map_path: str = None
) -> dict:
    """
    混合模式：Python 计算硬性指标 + VLM 定性选择

    流程：
    1. 对每条轨迹计算硬性指标（地板覆盖率、3D 距离、朝向角度、障碍物碰撞）
    2. 过滤掉 FAIL 的轨迹
    3. 将剩余候选 + 指标表格 + 网格图发送给 VLM
    4. VLM 做定性判断：哪条路径最合理

    Returns:
        {"index": 选中的轨迹索引 (0-based), "reason": "选择理由", "metrics_table": str, "filtered_count": int}
        或 {"index": -1, "reason": "都不行", "metrics_table": str, "filtered_count": 0}
    """
    # 加载地板掩码
    floor_mask = None
    if floor_mask_path and os.path.exists(floor_mask_path):
        mask_img = cv2.imread(floor_mask_path)
        if mask_img is not None:
            hsv = cv2.cvtColor(mask_img, cv2.COLOR_BGR2HSV)
            lower_green = np.array([35, 40, 50])
            upper_green = np.array([85, 255, 255])
            floor_mask = cv2.inRange(hsv, lower_green, upper_green) > 0

    # 加载深度图
    depth_map = None
    if depth_map_path and os.path.exists(depth_map_path):
        try:
            depth_map = np.load(depth_map_path)
        except Exception as e:
            print(f"   ⚠️ 加载深度图失败: {e}")

    # ========== Step 1: 计算每条轨迹的指标 ==========
    print(f"\n📊 Step 1: 计算 {len(trajectories)} 条轨迹的指标...")
    all_metrics = []
    for idx, traj in enumerate(trajectories):
        if len(traj) < 2:
            all_metrics.append({"fail_reasons": ["轨迹点不足"]})
            continue
        m = compute_trajectory_metrics(
            trajectory=traj,
            floor_mask=floor_mask,
            target_point=target_point,
            navigation_goal_point=navigation_goal_point,
            depth_map=depth_map,
            skip_first_point=True,
            obstacle_margin_px=10.0
        )
        all_metrics.append(m)

    # 打印指标表
    print(f"   {'#':>2}  {'地板率':>6}  {'3D到G':>7}  {'朝向角':>5}  {'避障Avg':>7}  {'避障Min':>7}  {'平滑度':>5}  {'警告':>4}")
    for idx, m in enumerate(all_metrics):
        sev = len(m.get("fail_reasons", []))
        sev_str = f"⚠️×{sev}" if sev > 0 else "✅ 无"
        avg_obs = m.get('avg_obstacle_dist', 999)
        min_obs = m.get('min_obstacle_dist', 999)
        print(f"   {idx+1:>2}  {m.get('on_floor_rate',0):>5.0%}  {m.get('dist_3d_to_G',0) or 0:>6.2f}m  {m.get('endpoint_angle_to_T',0):>4.0f}°  {avg_obs:>6.1f}px  {min_obs:>6.1f}px  {m.get('path_smoothness',0):>4.1f}°  {sev_str}")
        for reason in m.get("fail_reasons", []):
            print(f"       → {reason}")

    # ========== Step 2: 绘制网格图（全部候选） ==========
    multi_img_path = draw_multiple_trajectories_grid(
        image_path, trajectories, floor_mask_path, start_point, target_point
    )
    if multi_img_path is None:
        return {"index": -1, "reason": "无法绘制轨迹图"}

    multi_img_b64 = encode_image_to_base64(multi_img_path)

    # 构建指标表格文本（含警告标记）
    metrics_table = _format_metrics_table_all(trajectories, all_metrics)

    # ========== Step 3: VLM 综合判断 ==========
    prompt = f"""You are a robot navigation system. Compare the candidate trajectories and select the BEST one.

**Image Layout:** Each trajectory is shown in a SEPARATE subplot. Read the title above each subplot for the trajectory number.

**Metrics Table (computed by program, for REFERENCE only):**
{metrics_table}

**Legend:**
- S = Start, G = Endpoint of each trajectory, T = Target object
- Green region = walkable floor

**Selection Criteria (in PRIORITY order):**

**Priority 1 — Navigable Passage (MOST IMPORTANT):** The trajectory should follow the most natural walking corridor. Prefer paths that go through open gaps between obstacles, avoiding narrow squeezes even if they are technically on floor. This is the PRIMARY factor — the best trajectory is the one a person would naturally walk through.

**Priority 2 — Obstacle Clearance (40% weight reference):** The AvgObsDist and MinObsDist values in the metrics table tell you how safely the trajectory avoids obstacles. Higher is better. A trajectory with AvgObsDist < 8px is dangerously tight. A trajectory with MinObsDist < 3px is essentially scraping an obstacle. Obstacle safety is MORE important than endpoint precision or facing direction.

**Priority 3 — Target Facing (30% weight reference):** The Angle_to_T measures the direction from the second-to-last point toward Goal G, compared with the ideal G→T direction. Smaller angle = the robot approaches the goal while facing the target. Angles > 90° mean the robot ends up approaching from the wrong side. But navigable passage still beats perfect facing.

**Priority 4 — 3D Endpoint Accuracy (30% weight reference):** Dist3D_to_G measures how close the endpoint is to Goal G in 3D space. Smaller is better, but this is a soft preference — a trajectory with good obstacle clearance but slightly off endpoint is better than a precise endpoint through a narrow squeeze.

**Directness (Tie-breaker only):** Given similar quality on all above, prefer shorter paths (lower PathLen2D). But never sacrifice navigable passage or obstacle safety for directness.

**Answer Format:**
Reply in this exact format:
<number>: <one-sentence reason>

Examples:
"3: Most natural walking corridor — AvgObsDist=22px, good clearance, faces target at 15°"
"2: Cleanest path with best obstacle safety (MinObs=18px), slightly longer but worth it"
"NONE" if all are clearly unusable.
"""

    try:
        from timing_tracker import tracker
        
        # 打印 VLM Prompt（如果启用）
        from vlm_logger import log_vlm_call, log_vlm_output
        log_vlm_call("轨迹选择(Self-Reflection)", prompt)
        
        tracker.start("VLM", "轨迹选择(Self-Reflection)")
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{multi_img_b64}"}},
                        ],
                    }
                ],
                max_tokens=200,
                temperature=0.1,
            )
        finally:
            tracker.end("VLM", "轨迹选择(Self-Reflection)")

        result_text = response.choices[0].message.content.strip()
        
        # 打印 VLM 原始输出（如果启用）
        log_vlm_output("轨迹选择(Self-Reflection)", result_text)
        print(f"\n🤖 VLM 选择: {result_text}")

        # 解析结果：格式为 "4: Best path — smooth..."
        if "NONE" in result_text.upper():
            return {"index": -1, "reason": result_text, "metrics_table": metrics_table}

        match = re.search(r'(\d+)\s*:\s*(.+)', result_text)
        if match:
            num = int(match.group(1))
            reason = match.group(2).strip()
            if 1 <= num <= len(trajectories):
                return {"index": num - 1, "reason": reason, "metrics_table": metrics_table}

        # 降级：尝试只提取数字
        match = re.search(r'(\d+)', result_text)
        if match:
            num = int(match.group(1))
            if 1 <= num <= len(trajectories):
                return {"index": num - 1, "reason": result_text, "metrics_table": metrics_table}

        return {"index": -1, "reason": f"无法解析结果: {result_text}", "metrics_table": metrics_table}

    except Exception as e:
        return {"index": -1, "reason": f"VLM 选择失败: {str(e)}"}


def _format_metrics_table_all(trajectories, all_metrics):
    """格式化全部候选指标表格（含警告标记 + 参考权重）"""
    lines = []
    lines.append("=== Metrics Table (Program-Computed, For Reference Only) ===")
    lines.append("Reference Weights: Obstacle Clearance 40% | Target Facing 30% | 3D Dist to G 30%")
    lines.append("")
    for idx, m in enumerate(all_metrics):
        warnings = m.get("fail_reasons", [])
        warn_str = " | ".join(warnings) if warnings else "No critical issues"
        dist_str = f"{m['dist_3d_to_G']:.2f}m" if m.get('dist_3d_to_G') is not None else "N/A"
        lines.append(
            f"Trajectory #{idx+1}: Points={m['total_points']}, "
            f"Floor={m['on_floor_rate']:.0%}, "
            f"Dist3D_to_G={dist_str}, "
            f"Angle_to_T={m['endpoint_angle_to_T']:.0f}°, "
            f"AvgObsDist={m.get('avg_obstacle_dist',0):.0f}px, "
            f"MinObsDist={m['min_obstacle_dist']:.0f}px, "
            f"Smoothness={m['path_smoothness']:.1f}°, "
            f"PathLen2D={m['total_path_len_2d']:.0f}px"
            + (f" ⚠️ {warn_str}" if warnings else "")
        )
    return "\n".join(lines)


def _format_passing_metrics_table(trajectories, all_metrics, original_indices):
    """格式化通过的候选指标表格"""
    lines = []
    for local_idx, orig_idx in enumerate(original_indices):
        m = all_metrics[orig_idx]
        dist_str = f"{m['dist_3d_to_G']:.2f}m" if m.get('dist_3d_to_G') is not None else "N/A (2D)"
        lines.append(
            f"Trajectory #{local_idx+1}: Points={m['total_points']}, "
            f"Floor={m['on_floor_rate']:.0%}, "
            f"Dist3D_to_G={dist_str}, "
            f"Angle_to_T={m['endpoint_angle_to_T']:.0f}°, "
            f"MinObsDist={m['min_obstacle_dist']:.0f}px, "
            f"Smoothness={m['path_smoothness']:.1f}°, "
            f"PathLen2D={m['total_path_len_2d']:.0f}px"
        )
    return "\n".join(lines)


def _format_metrics_table(trajectories, all_metrics):
    """格式化完整指标表格（用于返回失败时的信息）"""
    lines = []
    for idx, m in enumerate(all_metrics):
        if m.get("fail_reasons"):
            reasons = "; ".join(m["fail_reasons"])
            lines.append(f"Trajectory #{idx+1}: FAIL — {reasons}")
        else:
            lines.append(f"Trajectory #{idx+1}: PASS (Floor={m['on_floor_rate']:.0%}, Dist3D={m.get('dist_3d_to_G')}, Angle={m['endpoint_angle_to_T']:.0f}°)")
    return "\n".join(lines)


def visualize_trajectory_on_image(
    image_path: str,
    trajectory: list,
    floor_mask_path: str = None,
    output_path: str = None,
    start_point: tuple = None,
    validation_result: dict = None
) -> str:
    """
    在图像上绘制轨迹
    - 起点：绿色大圆圈 + "S" 标签
    - 终点：红色大圆圈 + "G" 标签（可达终点）
    - 中间点：带编号的小圆圈
    - 轨迹线：带箭头的渐变颜色

    Args:
        image_path: 原始图像路径
        trajectory: 轨迹点列表 [[x1, y1], [x2, y2], ...]
        floor_mask_path: floor 掩码图像路径（用于验证轨迹点在地板上）
        output_path: 输出图像路径
        start_point: 起点坐标 (x, y)
        validation_result: 验证结果字典

    Returns:
        输出图像路径
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]

    # 创建叠加层
    overlay = image_rgb.copy()

    # 加载 floor 掩码（如果有）
    floor_mask = None
    if floor_mask_path and os.path.exists(floor_mask_path):
        # 尝试从 floor 点云可视化图中提取 mask
        mask_img = cv2.imread(floor_mask_path)
        if mask_img is not None:
            # 绿色区域是 floor
            lower_green = np.array([0, 100, 0])
            upper_green = np.array([100, 255, 100])
            mask = cv2.inRange(mask_img, lower_green, upper_green)
            floor_mask = mask > 0
            print(f"✅ 加载 floor 掩码：{floor_mask.sum()} 个像素")

    # 绘制轨迹线和点
    if len(trajectory) >= 2:
        traj_points = [(int(pt[0]), int(pt[1])) for pt in trajectory]

        # 创建验证查找表（如果有验证结果）
        on_floor_set = None
        if validation_result and validation_result.get("success"):
            on_floor_set = set(item["index"] for item in validation_result["on_floor"])
            off_floor_set = set(item["index"] for item in validation_result["off_floor"])

        # 绘制轨迹线段（带箭头和渐变颜色）
        for i in range(len(traj_points) - 1):
            t = i / (len(traj_points) - 1)
            # 渐变颜色：从绿色到红色
            segment_color = (
                int(0 * (1 - t) + 255 * t),      # R
                int(255 * (1 - t) + 0 * t),      # G
                int(0 * (1 - t) + 0 * t)         # B
            )
            # 绘制线段
            cv2.line(overlay, traj_points[i], traj_points[i+1], segment_color, 3)
            # 绘制箭头
            arrow_length = 12
            arrow_angle = 25
            angle = np.arctan2(traj_points[i+1][1] - traj_points[i][1], 
                              traj_points[i+1][0] - traj_points[i][0])
            arrow_pt1 = (
                int(traj_points[i+1][0] - arrow_length * np.cos(angle - np.deg2rad(arrow_angle))),
                int(traj_points[i+1][1] - arrow_length * np.sin(angle - np.deg2rad(arrow_angle)))
            )
            arrow_pt2 = (
                int(traj_points[i+1][0] - arrow_length * np.cos(angle + np.deg2rad(arrow_angle))),
                int(traj_points[i+1][1] - arrow_length * np.sin(angle + np.deg2rad(arrow_angle)))
            )
            cv2.line(overlay, traj_points[i+1], arrow_pt1, segment_color, 3)
            cv2.line(overlay, traj_points[i+1], arrow_pt2, segment_color, 3)

        # 绘制轨迹点
        for i, pt in enumerate(traj_points):
            if i == 0:
                # 起点：绿色大圆圈 + "S" 标签
                cv2.circle(overlay, pt, 12, (0, 255, 0), -1)
                cv2.circle(overlay, pt, 15, (0, 200, 0), 2)
                cv2.putText(overlay, "S", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            elif i == len(traj_points) - 1:
                # 终点：红色大圆圈 + "G" 标签（可达终点）
                cv2.circle(overlay, pt, 12, (0, 0, 255), -1)
                cv2.circle(overlay, pt, 15, (0, 0, 200), 2)
                cv2.putText(overlay, "G", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            else:
                # 中间点：带编号的小圆圈
                # 根据验证结果着色
                if on_floor_set is not None:
                    if i in on_floor_set:
                        circle_color = (0, 255, 0)  # 绿色：在地板上
                    elif i in off_floor_set:
                        circle_color = (0, 0, 255)  # 红色：不在地板上
                    else:
                        circle_color = (200, 200, 200)  # 灰色：未知
                else:
                    circle_color = (200, 200, 200)  # 灰色
                
                cv2.circle(overlay, pt, 8, circle_color, -1)
                cv2.circle(overlay, pt, 10, (150, 150, 150), 1)
                cv2.putText(overlay, str(i), (pt[0] - 5, pt[1] + 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

    # 保存
    if output_path is None:
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.dirname(image_path)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(output_dir, f"{base_name}_trajectory_{timestamp}.png")
    
    output_bgr = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 轨迹可视化已保存：{output_path}")
    
    return output_path


def query_vlm_trajectory(image_base64: str, client: OpenAI, model: str, prompt: str) -> dict:
    """查询 VLM 获取轨迹"""
    from timing_tracker import tracker
    
    # 打印 VLM Prompt（如果启用）
    from vlm_logger import log_vlm_call, log_vlm_output
    log_vlm_call("轨迹生成", prompt)
    
    try:
        tracker.start("VLM", "轨迹生成")
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}},
                        ],
                    }
                ],
                max_tokens=1000,
                temperature=0.1,
            )
            token_count = response.usage.completion_tokens if hasattr(response, 'usage') and response.usage else 0
            duration = tracker.get_last_duration("VLM", "轨迹生成")
            if token_count > 0:
                print(f"      📊 VLM响应: {token_count} tokens, {duration:.2f}s, {token_count/duration:.1f} tok/s")
        finally:
            tracker.end("VLM", "轨迹生成")

        # 打印 VLM 原始输出（如果启用）
        response_text = response.choices[0].message.content
        log_vlm_output("轨迹生成", response_text)

        return {
            "success": True,
            "response": response_text,
            "error": None
        }
        
    except Exception as e:
        return {
            "success": False,
            "response": None,
            "error": str(e)
        }


def validate_trajectory_on_floor(trajectory: list, floor_mask: np.ndarray, image_path: str, skip_first_point: bool = True) -> dict:
    """
    验证轨迹点是否在地板区域上

    Args:
        trajectory: 轨迹点列表 [[x1, y1], [x2, y2], ...]
        floor_mask: 地板掩码 (H, W) 布尔数组
        image_path: 原始图像路径（用于获取尺寸）
        skip_first_point: 是否跳过起点验证（起点是用户指定的固定位置，不是 VLM 规划的）

    Returns:
        验证结果字典
    """
    image = cv2.imread(image_path)
    if image is None:
        return {"success": False, "error": "无法读取图像"}

    h, w = image.shape[:2]

    results = {
        "success": True,
        "total_points": len(trajectory),
        "on_floor": [],
        "off_floor": [],
        "out_of_bounds": [],
        "floor_coverage": 0.0,
        "details": []
    }

    for i, pt in enumerate(trajectory):
        x, y = int(pt[0]), int(pt[1])

        # 检查是否超出图像边界
        if x < 0 or x >= w or y < 0 or y >= h:
            results["out_of_bounds"].append({"index": i, "point": [x, y]})
            results["details"].append({
                "index": i,
                "point": [x, y],
                "status": "out_of_bounds",
                "on_floor": False
            })
            continue

        # 跳过起点验证（起点是用户指定的固定位置）
        if skip_first_point and i == 0:
            results["on_floor"].append({"index": i, "point": [x, y], "note": "start_point"})
            results["details"].append({
                "index": i,
                "point": [x, y],
                "status": "start_point_skipped",
                "on_floor": True
            })
            continue

        # 检查是否在地板掩码上
        if floor_mask is not None:
            is_on_floor = bool(floor_mask[y, x])
        else:
            is_on_floor = False

        if is_on_floor:
            results["on_floor"].append({"index": i, "point": [x, y]})
        else:
            results["off_floor"].append({"index": i, "point": [x, y]})

        results["details"].append({
            "index": i,
            "point": [x, y],
            "status": "on_floor" if is_on_floor else "off_floor",
            "on_floor": is_on_floor
        })

    # 计算地板覆盖率（排除起点）
    valid_points = len(trajectory) - len(results["out_of_bounds"])
    
    # 检测是否有起点标记
    has_start_point = any(item.get("note") == "start_point" for item in results["on_floor"])
    
    if skip_first_point and has_start_point:
        valid_points -= 1  # 排除起点
    
    # 计算在地板上的点数（排除起点）
    on_floor_count = len(results["on_floor"])
    if skip_first_point and has_start_point:
        on_floor_count -= 1  # 排除起点
    
    if valid_points > 0:
        results["floor_coverage"] = on_floor_count / valid_points
    else:
        results["floor_coverage"] = 0.0

    return results


def _generate_single_candidate(args):
    """辅助函数：单次 VLM 调用生成一条候选轨迹（用于线程池）"""
    image_base64, client, model, prompt, idx = args
    result = query_vlm_trajectory(image_base64, client, model, prompt)
    if not result["success"]:
        return idx, None, result["error"]
    traj = parse_trajectory(result["response"])
    if traj is None or len(traj) < 2:
        return idx, None, "无法解析有效轨迹"
    return idx, {"trajectory": traj, "response": result["response"]}, None


def generate_candidate_trajectories(
    image_base64: str,
    client: OpenAI,
    model: str,
    prompt: str,
    count: int = NUM_CANDIDATES
) -> list:
    """
    并行调用 VLM 生成候选轨迹（利用线程池同时发起请求）

    Args:
        image_base64: 图像 base64
        client: OpenAI 客户端
        model: 模型名
        prompt: prompt
        count: 生成数量

    Returns:
        轨迹列表 [{"trajectory": [[x,y],...], "response": "..."}, ...]
    """
    candidates = [None] * count
    tasks = [(image_base64, client, model, prompt, i) for i in range(count)]

    print(f"\n  🚀 并行生成 {count} 条候选轨迹...")
    with ThreadPoolExecutor(max_workers=count) as executor:
        futures = {executor.submit(_generate_single_candidate, t): t[4] for t in tasks}
        for future in as_completed(futures):
            idx, candidate, error = future.result()
            if candidate:
                candidates[idx] = candidate
                print(f"  ✅ 候选 #{idx+1} 解析成功：{len(candidate['trajectory'])} 个点")
            else:
                print(f"  ❌ 候选 #{idx+1} 失败：{error}")

    # 过滤掉失败的，保持顺序
    return [c for c in candidates if c is not None]


def test_trajectory_prediction_with_self_reflection(
    image_path: str,
    floor_mask_path: str = None,
    start_point: tuple = None,
    target_point: list = None,
    navigation_goal_point: list = None,
    num_candidates: int = NUM_CANDIDATES,
    max_rounds: int = MAX_SELECTION_ROUNDS,
    depth_map_path: str = None
):
    """
    使用 self-reflection 机制测试 VLM 轨迹预测

    流程：
    1. 生成 N 条候选轨迹（原始 VLM 预测，未经后处理）
    2. 绘制在同一张图上编号
    3. VLM 选择最优轨迹
    4. 若 VLM 说 NONE，重新生成（最多 M 轮）
    5. 对选中的轨迹进行后处理和验证

    Args:
        image_path: 图像路径
        floor_mask_path: floor 掩码路径
        start_point: 起点坐标 (x, y)
        target_point: 目标物体点 T [x, y]
        navigation_goal_point: 可达终点 G [x, y]
        num_candidates: 候选轨迹数量
        max_rounds: 最大选择轮次
    """
    # 使用默认值（如果未提供）
    if start_point is None:
        start_point = DEFAULT_START_POINT
    if target_point is None:
        target_point = DEFAULT_TARGET_POINT
    if navigation_goal_point is None:
        navigation_goal_point = DEFAULT_NAVIGATION_GOAL_POINT

    print("="*70)
    print("🤖 VLM 导航轨迹预测测试 (Self-Reflection)")
    print("="*70)
    print(f"图像路径：{image_path}")
    print(f"VLM 模型：{VLM_MODEL}")
    print(f"候选数量：{num_candidates}")
    print(f"最大选择轮次：{max_rounds}")
    print("="*70)

    # 检查文件
    if not os.path.exists(image_path):
        print(f"❌ 图像文件不存在：{image_path}")
        return None

    # 编码图像
    print("\n🔄 编码图像...")
    image_base64 = encode_image_to_base64(image_path)
    print(f"✅ 图像编码完成")

    # 获取图像尺寸
    image = cv2.imread(image_path)
    h, w = image.shape[:2]
    print(f"📐 图像尺寸：{w}x{h}")

    # 加载 floor 掩码（如果有）
    floor_mask = None
    if floor_mask_path and os.path.exists(floor_mask_path):
        print(f"\n📍 加载 floor 掩码：{floor_mask_path}")
        mask_img = cv2.imread(floor_mask_path)
        if mask_img is not None:
            hsv = cv2.cvtColor(mask_img, cv2.COLOR_BGR2HSV)
            lower_green = np.array([35, 40, 50])
            upper_green = np.array([85, 255, 255])
            mask = cv2.inRange(hsv, lower_green, upper_green)
            floor_mask = mask > 0
            print(f"✅ Floor 掩码像素数：{floor_mask.sum()} ({100*floor_mask.sum()/(h*w):.1f}%)")
        else:
            print("⚠️ 无法加载 floor 掩码")

    # 创建客户端
    client = OpenAI(base_url=VLM_BASE_URL, api_key="not-needed")

    goal_info = ""
    goal_point_str = ""
    if navigation_goal_point:
        goal_point_str = f"{navigation_goal_point[0]}, {navigation_goal_point[1]}"
        goal_info = f"""
**Goal Position**
The robot's destination is at pixel coordinate: **({navigation_goal_point[0]}, {navigation_goal_point[1]})**
- x = {navigation_goal_point[0]} (horizontal, from left edge)
- y = {navigation_goal_point[1]} (vertical, from top edge)
"""

    # 清晰打印目标点(T)和可达点(G)的对比
    print("\n" + "=" * 70)
    print("📍 VLM轨迹预测 - 终点信息确认")
    print("=" * 70)
    print(f"   起点 (S): {start_point}")
    print(f"   目标物体点 (T): {target_point} - 目标物体底部中心（不用于轨迹预测）")
    print(f"   可达终点 (G): {navigation_goal_point} - 机器人站立位置（VLM轨迹终点）")
    if target_point and navigation_goal_point:
        dist = np.sqrt((target_point[0]-navigation_goal_point[0])**2 + (target_point[1]-navigation_goal_point[1])**2)
        print(f"   T与G距离差异: {dist:.1f} 像素")
    print(f"\n   >>> VLM将预测从 S 到 G 的轨迹")
    print("=" * 70 + "\n")

    # 构建 VLM prompt（用于生成候选轨迹）
    prompt = f"""You are a robot navigation system. Analyze this depth segmentation image and plan a feasible walking path for a mobile robot.

**Color Semantics:**
- 🟢 **Green region**: Floor / walkable area (ONLY valid region)
- 🔴 **Other colors (purple, blue, etc.)**: Obstacles & background (AVOID)

**Robot Info:**
- Start position: pixel ({start_point[0]}, {start_point[1]})
- Goal position: pixel ({goal_point_str}) — pre-verified to be on green floor
- Robot width: ~30cm (keep a safe margin from obstacle edges)

**Task:**
Plan a collision-free trajectory from Start to Goal.

**Step-by-step reasoning:**
1. Locate the Start and Goal points on the image
2. Identify the green walkable corridor connecting them
3. Plan intermediate waypoints along the corridor, keeping at least 10 pixels away from any non-green boundary
4. Ensure consecutive waypoints are no more than 80 pixels apart (Euclidean distance)
5. **The trajectory endpoint MUST point TOWARD the target T** — the last segment direction should face the target object

**Requirements:**
1. First point MUST be exactly: [{start_point[0]}, {start_point[1]}]
2. Last point MUST be exactly: [{goal_point_str}]
3. ALL points must fall on green pixels with ≥10px safety margin from non-green edges
4. Consecutive points must be ≤80 pixels apart (Euclidean distance)
5. Total points: 8-15
6. No backtracking — each point should make progress toward the Goal
7. **The endpoint direction must point toward target T ({target_point[0]}, {target_point[1]})**

**Output Format:**
[[x1, y1], [x2, y2], ...]

**Constraints:**
- x coordinate range: [0, {w}]
- y coordinate range: [0, {h}]
- Number of points: 8-15
- ALL points must fall on green pixels with ≥10px margin

<trajectory>
[[x1, y1], [x2, y2], ..., [xn, yn]]
</trajectory>
"""

    # ========== Self-Reflection 主循环 ==========
    best_trajectory = None
    best_response = None
    selection_round = 0

    for round_idx in range(max_rounds):
        selection_round = round_idx + 1
        print("\n" + "="*70)
        print(f"🔄 Self-Reflection 第 {selection_round}/{max_rounds} 轮")
        print("="*70)

        # Step 1: 生成候选轨迹
        print(f"\n📊 Step 1: 生成 {num_candidates} 条候选轨迹...")
        candidates = generate_candidate_trajectories(
            image_base64, client, VLM_MODEL, prompt, num_candidates
        )

        if len(candidates) == 0:
            print("❌ 未能生成任何候选轨迹")
            continue

        print(f"\n✅ 成功生成 {len(candidates)} 条候选轨迹")

        # Step 2: VLM 选择最优轨迹
        print(f"\n📊 Step 2: VLM 选择最优轨迹...")
        trajectories_for_selection = [c["trajectory"] for c in candidates]

        selection_result = select_best_trajectory_vlm(
            image_path,
            trajectories_for_selection,
            client,
            VLM_MODEL,
            start_point,
            target_point,
            navigation_goal_point,
            floor_mask_path,
            depth_map_path
        )

        if selection_result["index"] >= 0:
            best_idx = selection_result["index"]
            best_trajectory = candidates[best_idx]["trajectory"]
            best_response = candidates[best_idx]["response"]
            print(f"\n✅ 选择完成！选中轨迹 #{best_idx+1}（{len(best_trajectory)} 个点）")
            print(f"   理由：{selection_result['reason']}")
            break
        else:
            print(f"\n⚠️ VLM 认为所有候选轨迹都不合格")
            print(f"   原因：{selection_result['reason']}")
            if selection_round < max_rounds:
                print(f"   🔄 将重新生成候选轨迹...")

    # 检查是否成功选中轨迹
    if best_trajectory is None:
        print("\n" + "="*70)
        print("❌ Self-Reflection 失败：所有轮次都未能选出合格轨迹")
        print("="*70)
        return None

    # ========== 对选中的轨迹进行后处理和验证 ==========
    print("\n" + "="*70)
    print("🔍 对选中轨迹进行后处理和验证")
    print("="*70)

    trajectory = best_trajectory
    result = {"success": True, "response": best_response}

    print(f"\n✅ VLM 原始回答:")
    print("-"*70)
    print(best_response)
    print("-"*70)

    print(f"\n✅ 选中轨迹点数：{len(trajectory)}")
    print(f"轨迹点列表：{trajectory}")

    # 验证轨迹点是否在图像范围内
    valid_points = []
    invalid_points = []
    for pt in trajectory:
        x, y = pt
        if 0 <= x < w and 0 <= y < h:
            valid_points.append(pt)
        else:
            invalid_points.append(pt)
            print(f"⚠️ 点 ({x}, {y}) 超出图像范围")

    if invalid_points:
        print(f"⚠️ {len(invalid_points)} 个点超出范围，已过滤")
        trajectory = valid_points

    if len(trajectory) < 2:
        print("❌ 有效轨迹点不足 2 个")
        return None

    # ========== 地板约束验证 ==========
    print("\n" + "="*70)
    print("🔍 地板约束验证")
    print("="*70)

    validation_result = validate_trajectory_on_floor(trajectory, floor_mask, image_path, skip_first_point=True)

    if validation_result["success"]:
        on_floor_count = len(validation_result["on_floor"])
        off_floor_count = len(validation_result["off_floor"])
        out_of_bounds_count = len(validation_result["out_of_bounds"])
        coverage = validation_result["floor_coverage"]

        start_point_item = next((item for item in validation_result["on_floor"] if item.get("note") == "start_point"), None)
        has_start_point = start_point_item is not None

        validated_points = validation_result["total_points"] - (1 if has_start_point else 0) - out_of_bounds_count

        print(f"\n总轨迹点数：{validation_result['total_points']}")
        if has_start_point:
            print(f"📍 起点 (跳过验证): ({start_point_item['point'][0]}, {start_point_item['point'][1]})")
        print(f"✅ 在地板上：{on_floor_count - (1 if has_start_point else 0)} 个点 ({100*coverage:.1f}%)")

        if off_floor_count > 0:
            print(f"❌ 不在地板上：{off_floor_count} 个点")
            for item in validation_result["off_floor"]:
                print(f"   - 点 {item['index']}: ({item['point'][0]}, {item['point'][1]})")

        if out_of_bounds_count > 0:
            print(f"⚠️ 超出边界：{out_of_bounds_count} 个点")
            for item in validation_result["out_of_bounds"]:
                print(f"   - 点 {item['index']}: ({item['point'][0]}, {item['point'][1]})")

        print("\n" + "-"*70)
        if coverage >= 0.8:
            print("✅ 验证通过：轨迹点大部分在地板上")
        elif coverage >= 0.5:
            print("⚠️ 验证警告：部分轨迹点不在地板上")
        else:
            print("❌ 验证失败：大部分轨迹点不在地板上")
    else:
        print(f"❌ 验证失败：{validation_result.get('error', '未知错误')}")
        coverage = 0

    # 可视化
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    output_dir = os.path.dirname(image_path)
    output_path = os.path.join(output_dir, f"{base_name}_vlm_trajectory.png")

    print("\n🎨 绘制轨迹...")
    vis_path = visualize_trajectory_on_image(
        image_path,
        trajectory,
        floor_mask_path,
        output_path,
        start_point,
        validation_result if validation_result else None
    )

    # 保存轨迹数据
    traj_data = {
        "image_path": image_path,
        "image_size": {"width": w, "height": h},
        "start_point": list(start_point),
        "target_point": target_point,
        "navigation_goal_point": navigation_goal_point,
        "trajectory": trajectory,
        "num_points": len(trajectory),
        "timestamp": datetime.now().isoformat(),
        "model": VLM_MODEL,
        "self_reflection": {
            "enabled": True,
            "num_candidates": num_candidates,
            "max_rounds": max_rounds,
            "selection_round": selection_round,
        },
        "vlm_response": best_response,
        "validation": validation_result if validation_result else None
    }

    traj_json_path = os.path.join(output_dir, f"{base_name}_trajectory_data.json")
    with open(traj_json_path, "w", encoding="utf-8") as f:
        json.dump(traj_data, f, ensure_ascii=False, indent=2)
    print(f"📄 轨迹数据已保存：{traj_json_path}")

    print("\n" + "="*70)
    print("✅ 测试完成!")
    print("="*70)
    print(f"起点：{start_point}")
    print(f"轨迹点数：{len(trajectory)}")
    print(f"Self-Reflection 轮次：{selection_round}")
    print(f"轨迹可视化：{vis_path}")
    print(f"轨迹数据：{traj_json_path}")

    return traj_data


def test_trajectory_prediction(
    image_path: str,
    floor_mask_path: str = None,
    start_point: tuple = None,
    target_point: list = None,
    navigation_goal_point: list = None
):
    """测试 VLM 轨迹预测

    Args:
        image_path: 图像路径
        floor_mask_path: floor 掩码路径
        start_point: 起点坐标 (x, y)
        target_point: 目标物体点 T [x, y]
        navigation_goal_point: 可达终点 G [x, y]
    """
    # 使用默认值（如果未提供）
    if start_point is None:
        start_point = DEFAULT_START_POINT
    if target_point is None:
        target_point = DEFAULT_TARGET_POINT
    if navigation_goal_point is None:
        navigation_goal_point = DEFAULT_NAVIGATION_GOAL_POINT

    print("="*70)
    print("🤖 VLM 导航轨迹预测测试")
    print("="*70)
    print(f"图像路径：{image_path}")
    print(f"VLM 模型：{VLM_MODEL}")
    print("="*70)

    # 检查文件
    if not os.path.exists(image_path):
        print(f"❌ 图像文件不存在：{image_path}")
        return None

    # 编码图像
    print("\n🔄 编码图像...")
    image_base64 = encode_image_to_base64(image_path)
    print(f"✅ 图像编码完成")

    # 获取图像尺寸
    image = cv2.imread(image_path)
    h, w = image.shape[:2]
    print(f"📐 图像尺寸：{w}x{h}")

    # 加载 floor 掩码（如果有）
    floor_mask = None
    if floor_mask_path and os.path.exists(floor_mask_path):
        print(f"\n📍 加载 floor 掩码：{floor_mask_path}")
        # 从 depth_masks 图像中提取绿色区域作为 floor 掩码
        mask_img = cv2.imread(floor_mask_path)
        if mask_img is not None:
            # 使用 HSV 颜色空间提取绿色
            hsv = cv2.cvtColor(mask_img, cv2.COLOR_BGR2HSV)

            # 绿色的 HSV 范围（更宽松）
            # H: 35-85 (绿色色相), S: 40-255 (饱和度), V: 50-255 (亮度)
            lower_green = np.array([35, 40, 50])
            upper_green = np.array([85, 255, 255])
            mask = cv2.inRange(hsv, lower_green, upper_green)
            floor_mask = mask > 0
            print(f"✅ Floor 掩码像素数：{floor_mask.sum()} ({100*floor_mask.sum()/(h*w):.1f}%)")

            # 调试：显示 Top 颜色
            unique_colors = np.unique(mask_img.reshape(-1, 3), axis=0)
            if len(unique_colors) > 0:
                print(f"   图像中唯一颜色数量：{len(unique_colors)}")
                # 检查是否有绿色系颜色
                green_pixels = ((mask_img[:, :, 1] > 100) &
                               (mask_img[:, :, 0] < 150) &
                               (mask_img[:, :, 2] < 150))
                print(f"   绿色系像素数：{green_pixels.sum()}")
        else:
            print("⚠️ 无法加载 floor 掩码")

    # 创建客户端
    client = OpenAI(base_url=VLM_BASE_URL, api_key="not-needed")

    goal_info = ""
    goal_point_str = ""
    if navigation_goal_point:
        goal_point_str = f"{navigation_goal_point[0]}, {navigation_goal_point[1]}"
        goal_info = f"""
**Goal Position**
The robot's destination is at pixel coordinate: **({navigation_goal_point[0]}, {navigation_goal_point[1]})**
- x = {navigation_goal_point[0]} (horizontal, from left edge)
- y = {navigation_goal_point[1]} (vertical, from top edge)
"""

    # 清晰打印目标点(T)和可达点(G)的对比
    print("\n" + "=" * 70)
    print("📍 VLM轨迹预测 - 终点信息确认")
    print("=" * 70)
    print(f"   起点 (S): {start_point}")
    print(f"   目标物体点 (T): {target_point} - 目标物体底部中心（不用于轨迹预测）")
    print(f"   可达终点 (G): {navigation_goal_point} - 机器人站立位置（VLM轨迹终点）")
    if target_point and navigation_goal_point:
        dist = np.sqrt((target_point[0]-navigation_goal_point[0])**2 + (target_point[1]-navigation_goal_point[1])**2)
        print(f"   T与G距离差异: {dist:.1f} 像素")
    print(f"\n   >>> VLM将预测从 S 到 G 的轨迹")
    print("=" * 70 + "\n")

    prompt = f"""You are a robot navigation system. Analyze this depth segmentation image and plan a feasible walking path for a mobile robot.

**Color Semantics:**
- 🟢 **Green region**: Floor / walkable area (ONLY valid region)
- 🔴 **Other colors (purple, blue, etc.)**: Obstacles & background (AVOID)

**Robot Info:**
- Start position: pixel ({start_point[0]}, {start_point[1]})
- Goal position: pixel ({goal_point_str}) — pre-verified to be on green floor
- Robot width: ~30cm (keep a safe margin from obstacle edges)

**Task:**
Plan a collision-free trajectory from Start to Goal.

**Step-by-step reasoning:**
1. Locate the Start and Goal points on the image
2. Identify the green walkable corridor connecting them
3. Plan intermediate waypoints along the corridor, keeping at least 10 pixels away from any non-green boundary
4. Ensure consecutive waypoints are no more than 80 pixels apart (Euclidean distance)
5. **The trajectory endpoint MUST point TOWARD the target T** — the last segment direction should face the target object

**Requirements:**
1. First point MUST be exactly: [{start_point[0]}, {start_point[1]}]
2. Last point MUST be exactly: [{goal_point_str}]
3. ALL points must fall on green pixels with ≥10px safety margin from non-green edges
4. Consecutive points must be ≤80 pixels apart (Euclidean distance)
5. Total points: 8-15
6. No backtracking — each point should make progress toward the Goal
7. **The endpoint direction must point toward target T ({target_point[0]}, {target_point[1]})**

**Output Format:**
[[x1, y1], [x2, y2], ...]

**Constraints:**
- x coordinate range: [0, {w}]
- y coordinate range: [0, {h}]
- Number of points: 8-15
- ALL points must fall on green pixels with ≥10px margin

<trajectory>
[[x1, y1], [x2, y2], ..., [xn, yn]]
</trajectory>
"""

    print("\n" + "="*70)
    print("📝 VLM Prompt:")
    print("="*70)
    print(prompt)
    print("="*70)

    print("\n🔄 查询 VLM...")
    result = query_vlm_trajectory(image_base64, client, VLM_MODEL, prompt)
    
    if not result["success"]:
        print(f"❌ VLM 查询失败：{result['error']}")
        return None
    
    print("\n✅ VLM 原始回答:")
    print("-"*70)
    print(result["response"])
    print("-"*70)
    
    # 解析轨迹
    trajectory = parse_trajectory(result["response"])
    
    if trajectory is None:
        print("\n❌ 无法从响应中解析轨迹点")
        print("尝试手动提取...")
        # 显示可能的轨迹部分
        if "<trajectory>" in result["response"]:
            traj_part = result["response"].split("<trajectory>")[1].split("</trajectory>")[0] if "</trajectory>" in result["response"] else result["response"].split("<trajectory>")[1]
            print(f"轨迹部分：{traj_part}")
        return None
    
    print(f"\n✅ 解析成功！轨迹点数：{len(trajectory)}")
    print(f"轨迹点列表：{trajectory}")
    
    # 验证轨迹点是否在图像范围内
    valid_points = []
    invalid_points = []
    for pt in trajectory:
        x, y = pt
        if 0 <= x < w and 0 <= y < h:
            valid_points.append(pt)
        else:
            invalid_points.append(pt)
            print(f"⚠️ 点 ({x}, {y}) 超出图像范围")
    
    if invalid_points:
        print(f"⚠️ {len(invalid_points)} 个点超出范围，已过滤")
        trajectory = valid_points
    
    if len(trajectory) < 2:
        print("❌ 有效轨迹点不足 2 个")
        return None
    
    # ========== 地板约束验证 ==========
    print("\n" + "="*70)
    print("🔍 地板约束验证")
    print("="*70)

    validation_result = validate_trajectory_on_floor(trajectory, floor_mask, image_path, skip_first_point=True)

    if validation_result["success"]:
        on_floor_count = len(validation_result["on_floor"])
        off_floor_count = len(validation_result["off_floor"])
        out_of_bounds_count = len(validation_result["out_of_bounds"])
        coverage = validation_result["floor_coverage"]

        # 计算起点标记
        start_point_item = next((item for item in validation_result["on_floor"] if item.get("note") == "start_point"), None)
        has_start_point = start_point_item is not None
        
        # 实际验证的点数（排除起点）
        validated_points = validation_result["total_points"] - (1 if has_start_point else 0) - out_of_bounds_count

        print(f"\n总轨迹点数：{validation_result['total_points']}")
        if has_start_point:
            print(f"📍 起点 (跳过验证): ({start_point_item['point'][0]}, {start_point_item['point'][1]})")
        print(f"✅ 在地板上：{on_floor_count - (1 if has_start_point else 0)} 个点 ({100*coverage:.1f}%)")

        if off_floor_count > 0:
            print(f"❌ 不在地板上：{off_floor_count} 个点")
            for item in validation_result["off_floor"]:
                print(f"   - 点 {item['index']}: ({item['point'][0]}, {item['point'][1]})")

        if out_of_bounds_count > 0:
            print(f"⚠️ 超出边界：{out_of_bounds_count} 个点")
            for item in validation_result["out_of_bounds"]:
                print(f"   - 点 {item['index']}: ({item['point'][0]}, {item['point'][1]})")

        # 评估结果
        print("\n" + "-"*70)
        if coverage >= 0.8:
            print("✅ 验证通过：轨迹点大部分在地板上")
        elif coverage >= 0.5:
            print("⚠️ 验证警告：部分轨迹点不在地板上")
        else:
            print("❌ 验证失败：大部分轨迹点不在地板上")
    else:
        print(f"❌ 验证失败：{validation_result.get('error', '未知错误')}")
        coverage = 0
    
    # 可视化
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    output_dir = os.path.dirname(image_path)
    output_path = os.path.join(output_dir, f"{base_name}_vlm_trajectory.png")

    print("\n🎨 绘制轨迹...")
    vis_path = visualize_trajectory_on_image(
        image_path,
        trajectory,
        floor_mask_path,
        output_path,
        start_point,
        validation_result if validation_result else None
    )

    # 保存轨迹数据
    traj_data = {
        "image_path": image_path,
        "image_size": {"width": w, "height": h},
        "start_point": list(start_point),
        "target_point": target_point,
        "navigation_goal_point": navigation_goal_point,
        "trajectory": trajectory,
        "num_points": len(trajectory),
        "timestamp": datetime.now().isoformat(),
        "model": VLM_MODEL,
        "vlm_response": result["response"],
        "validation": validation_result if validation_result else None
    }
    
    traj_json_path = os.path.join(output_dir, f"{base_name}_trajectory_data.json")
    with open(traj_json_path, "w", encoding="utf-8") as f:
        json.dump(traj_data, f, ensure_ascii=False, indent=2)
    print(f"📄 轨迹数据已保存：{traj_json_path}")
    
    print("\n" + "="*70)
    print("✅ 测试完成!")
    print("="*70)
    print(f"起点：{start_point}")
    print(f"轨迹点数：{len(trajectory)}")
    print(f"轨迹可视化：{vis_path}")
    print(f"轨迹数据：{traj_json_path}")
    
    return traj_data


def main():
    import argparse

    parser = argparse.ArgumentParser(description="VLM 导航轨迹预测")
    parser.add_argument("--image", type=str, default=DEFAULT_IMAGE_PATH, help="图像路径")
    parser.add_argument("--floor-mask", type=str, default=None, help="Floor 掩码路径（默认与 image 相同）")
    parser.add_argument("--start-point", type=str, default=None, help="起点坐标，格式: x,y")
    parser.add_argument("--target-point", type=str, default=None, help="目标物体点 T，格式: x,y")
    parser.add_argument("--goal-point", type=str, default=None, help="可达终点 G，格式: x,y")
    parser.add_argument("--self-reflection", action="store_true", help="启用 self-reflection 模式（生成多条候选，VLM 选择）")
    parser.add_argument("--num-candidates", type=int, default=NUM_CANDIDATES, help=f"候选轨迹数量（默认 {NUM_CANDIDATES}）")
    parser.add_argument("--max-rounds", type=int, default=MAX_SELECTION_ROUNDS, help=f"最大选择轮次（默认 {MAX_SELECTION_ROUNDS}）")
    parser.add_argument("--depth-map", type=str, default=None, dest="depth_map_path", help="深度图 .npy 路径（用于计算 3D 距离）")
    parser.add_argument("--verbose_vlm", action="store_true", default=False, help="打印所有 VLM 的 prompt 和原始输出")
    args = parser.parse_args()

    # 设置 VLM 日志打印
    if args.verbose_vlm:
        from vlm_logger import set_verbose
        set_verbose(True)

    image_path = args.image
    floor_mask_path = args.floor_mask if args.floor_mask else image_path

    # 解析命令行参数
    start_point = DEFAULT_START_POINT
    if args.start_point:
        x, y = args.start_point.split(",")
        start_point = (int(x.strip()), int(y.strip()))

    target_point = DEFAULT_TARGET_POINT
    if args.target_point:
        x, y = args.target_point.split(",")
        target_point = [int(x.strip()), int(y.strip())]

    navigation_goal_point = DEFAULT_NAVIGATION_GOAL_POINT
    if args.goal_point:
        x, y = args.goal_point.split(",")
        navigation_goal_point = [int(x.strip()), int(y.strip())]

    print(f"起点坐标：{start_point}")
    print(f"目标物体点 (T)：{target_point}")
    print(f"可达终点 (G)：{navigation_goal_point}")
    print(f"Self-Reflection：{'启用' if args.self_reflection else '禁用'}")

    if args.self_reflection:
        num_candidates = args.num_candidates
        max_rounds = args.max_rounds
        test_trajectory_prediction_with_self_reflection(
            image_path,
            floor_mask_path,
            start_point=start_point,
            target_point=target_point,
            navigation_goal_point=navigation_goal_point,
            num_candidates=num_candidates,
            max_rounds=max_rounds,
            depth_map_path=args.depth_map_path
        )
    else:
        test_trajectory_prediction(
            image_path,
            floor_mask_path,
            start_point=start_point,
            target_point=target_point,
            navigation_goal_point=navigation_goal_point
        )

    # 打印所有 VLM 日志（如果启用）
    from vlm_logger import print_all_vlm_logs
    print_all_vlm_logs()


if __name__ == "__main__":
    main()
