#!/usr/bin/env python3
"""
点云保存和可视化模块
支持 PLY 格式保存和多种可视化方式
"""

import numpy as np
import os
import cv2
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


class PointCloudSaver:
    """点云保存器"""

    @staticmethod
    def save_ply(
        points: np.ndarray,
        colors: Optional[np.ndarray] = None,
        output_path: str = "output.ply"
    ) -> str:
        """
        保存点云为 PLY 格式（ASCII）

        Args:
            points: [N, 3] XYZ 坐标
            colors: [N, 3] RGB 颜色 (0-255)
            output_path: 输出路径

        Returns:
            保存的路径
        """
        if len(points) == 0:
            print("⚠️ 点云为空，跳过保存")
            return None

        # 确保颜色存在
        if colors is None:
            colors = np.ones_like(points) * 128  # 默认灰色

        # 确保颜色在 0-255 范围
        if colors.max() <= 1.0:
            colors = (colors * 255).astype(np.uint8)
        else:
            colors = colors.astype(np.uint8)

        # 写入 PLY 文件
        with open(output_path, 'w') as f:
            # PLY 头
            f.write("ply\n")
            f.write("format ascii 1.0\n")
            f.write(f"element vertex {len(points)}\n")
            f.write("property float x\n")
            f.write("property float y\n")
            f.write("property float z\n")
            f.write("property uchar red\n")
            f.write("property uchar green\n")
            f.write("property uchar blue\n")
            f.write("end_header\n")

            # 写入点数据
            for pt, col in zip(points, colors):
                f.write(f"{pt[0]:.6f} {pt[1]:.6f} {pt[2]:.6f} {int(col[0])} {int(col[1])} {int(col[2])}\n")

        print(f"✅ 点云已保存：{output_path} ({len(points)} 个点)")
        return output_path

    @staticmethod
    def save_ply_binary(
        points: np.ndarray,
        colors: Optional[np.ndarray] = None,
        output_path: str = "output.ply"
    ) -> str:
        """
        保存点云为 PLY 格式（二进制）

        Args:
            points: [N, 3] XYZ 坐标
            colors: [N, 3] RGB 颜色 (0-255)
            output_path: 输出路径

        Returns:
            保存的路径
        """
        import struct

        if len(points) == 0:
            print("⚠️ 点云为空，跳过保存")
            return None

        if colors is None:
            colors = np.ones_like(points) * 128

        if colors.max() <= 1.0:
            colors = (colors * 255).astype(np.uint8)
        else:
            colors = colors.astype(np.uint8)

        with open(output_path, 'wb') as f:
            # PLY 头
            header = (
                "ply\n"
                "format binary_little_endian 1.0\n"
                f"element vertex {len(points)}\n"
                "property float x\n"
                "property float y\n"
                "property float z\n"
                "property uchar red\n"
                "property uchar green\n"
                "property uchar blue\n"
                "end_header\n"
            ).encode('utf-8')
            f.write(header)

            # 写入点数据（二进制）
            for pt, col in zip(points, colors):
                f.write(struct.pack('fffBBB', pt[0], pt[1], pt[2], col[0], col[1], col[2]))

        print(f"✅ 点云已保存（二进制）：{output_path} ({len(points)} 个点)")
        return output_path

    @staticmethod
    def save_all_clouds(
        clouds: Dict[str, any],
        output_dir: str,
        prefix: str = ""
    ) -> Dict[str, str]:
        """
        保存所有点云

        Args:
            clouds: 字典包含各类点云
                - scene: 场景点云
                - target: 目标点云
                - floor: 地板点云
                - full: 完整点云
            output_dir: 输出目录
            prefix: 文件名前缀

        Returns:
            保存路径字典
        """
        os.makedirs(output_dir, exist_ok=True)

        saved_paths = {}

        for name, cloud in clouds.items():
            if cloud.points is None or len(cloud.points) == 0:
                print(f"⚠️ {name} 点云为空，跳过保存")
                continue

            filename = f"{prefix}{name}_pointcloud.ply" if prefix else f"{name}_pointcloud.ply"
            output_path = os.path.join(output_dir, filename)

            PointCloudSaver.save_ply(
                cloud.points,
                cloud.colors,
                output_path
            )

            saved_paths[name] = output_path

        return saved_paths


class PointCloudVisualizer:
    """点云可视化器"""

    @staticmethod
    def visualize_3d_matplotlib(
        clouds: Dict[str, any],
        output_path: str,
        title: str = "3D Point Cloud",
        start_point: Optional[Tuple[int, int]] = None
    ) -> str:
        """
        使用 matplotlib 可视化 3D 点云

        Args:
            clouds: 字典包含各类点云
            output_path: 输出图像路径
            title: 图像标题
            start_point: 起点 2D 坐标 (x, y)
        """
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D

        fig = plt.figure(figsize=(16, 12))
        ax = fig.add_subplot(111, projection='3d')

        for name, cloud in clouds.items():
            if cloud.points is None or len(cloud.points) == 0:
                continue

            # 降采样以加快显示
            points = cloud.points
            colors = cloud.colors

            if len(points) > 50000:
                indices = np.random.choice(len(points), 50000, replace=False)
                points = points[indices]
                if colors is not None:
                    colors = colors[indices]

            # 使用真实颜色或指定颜色
            if colors is not None and colors.max() <= 1.0:
                point_colors = colors
            elif colors is not None:
                point_colors = colors / 255.0
            else:
                point_colors = None

            ax.scatter(
                points[:, 0], points[:, 1], points[:, 2],
                c=point_colors if point_colors is not None else 'gray',
                s=1,
                alpha=0.6,
                marker='.'
            )

        ax.set_xlabel('X (m)')
        ax.set_ylabel('Y (m)')
        ax.set_zlabel('Z (m)')
        ax.view_init(elev=20, azim=-60)

        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        print(f"✅ 3D 可视化已保存：{output_path}")
        return output_path

    @staticmethod
    def visualize_2d_projection(
        clouds: Dict[str, any],
        image_path: str,
        output_path: str,
        title: str = "2D Projection",
        start_point: Optional[Tuple[int, int]] = None
    ):
        """
        在原始图像上可视化点云 2D 投影（无图例、无文字）

        Args:
            clouds: 字典包含各类点云
            image_path: 原始图像路径
            output_path: 输出图像路径
            title: 图像标题
            start_point: 起点 2D 坐标 (x, y)
        """
        # 读取原始图像
        image = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        h, w = image_rgb.shape[:2]

        # 创建叠加层
        overlay = image_rgb.copy()

        # 绘制点云投影（使用掩码）
        alpha = 0.5
        colors_bgr = {
            'scene': (255, 0, 0),      # 蓝色
            'target': (0, 0, 255),     # 红色
            'floor': (0, 255, 0)       # 绿色
        }

        for name, cloud in clouds.items():
            if cloud.mask is None or name == 'full':
                continue

            color = colors_bgr.get(name, (255, 255, 255))

            # 创建彩色掩码
            color_overlay = np.zeros_like(overlay)
            color_overlay[cloud.mask] = color

            # 混合
            overlay = cv2.addWeighted(overlay, 1, color_overlay, alpha, 0)

        # 保存
        overlay_bgr = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
        cv2.imwrite(output_path, overlay_bgr)

        print(f"✅ 2D 投影可视化已保存：{output_path}")
        return output_path

    @staticmethod
    def visualize_depth_with_mask(
        depth_map: np.ndarray,
        masks: Dict[str, np.ndarray],
        output_path: str,
        title: str = "Depth with Masks",
        start_point: Optional[Tuple[int, int]] = None
    ) -> str:
        """
        可视化深度图并叠加掩码（无图例、无文字）

        Args:
            depth_map: [H, W] 深度图
            masks: 掩码字典
            output_path: 输出路径
            title: 标题
            start_point: 起点 2D 坐标 (x, y)
        """
        # 深度图可视化
        depth_vis = cv2.normalize(depth_map, None, 0, 255, cv2.NORM_MINMAX)
        depth_vis = depth_vis.astype(np.uint8)
        depth_color = cv2.applyColorMap(depth_vis, cv2.COLORMAP_INFERNO)

        # 叠加掩码
        overlay = depth_color.copy()
        colors = {
            'target': (0, 0, 255),    # 红色
            'floor': (0, 255, 0),     # 绿色
            'scene': (255, 0, 0)      # 蓝色
        }

        for name, mask in masks.items():
            if mask is None:
                continue
            color = colors.get(name, (255, 255, 255))
            overlay[mask] = (overlay[mask] * 0.5 + np.array(color) * 0.5).astype(np.uint8)

        cv2.imwrite(output_path, overlay)
        print(f"✅ 深度图可视化已保存：{output_path}")
        return output_path

    @staticmethod
    def visualize_all(
        clouds: Dict[str, any],
        image_path: str,
        depth_map: np.ndarray,
        output_dir: str,
        prefix: str = "",
        start_point: Optional[Tuple[int, int]] = None
    ) -> Dict[str, str]:
        """
        生成所有可视化

        Args:
            clouds: 点云字典
            image_path: 原始图像路径
            depth_map: 深度图
            output_dir: 输出目录
            prefix: 文件名前缀
            start_point: 起点 2D 坐标 (x, y)

        Returns:
            保存路径字典
        """
        os.makedirs(output_dir, exist_ok=True)

        saved_paths = {}

        # 3D 可视化
        output_3d = os.path.join(output_dir, f"{prefix}3d_pointcloud.png")
        PointCloudVisualizer.visualize_3d_matplotlib(
            clouds,
            output_3d,
            title="3D Point Cloud Visualization",
            start_point=start_point
        )
        saved_paths['3d'] = output_3d

        # 2D 投影
        output_2d = os.path.join(output_dir, f"{prefix}2d_projection.png")
        PointCloudVisualizer.visualize_2d_projection(
            clouds,
            image_path,
            output_2d,
            title="Point Cloud 2D Projection",
            start_point=start_point
        )
        saved_paths['2d'] = output_2d

        # 深度图 + 掩码
        masks = {name: cloud.mask for name, cloud in clouds.items() if cloud.mask is not None}
        output_depth = os.path.join(output_dir, f"{prefix}depth_masks.png")
        PointCloudVisualizer.visualize_depth_with_mask(
            depth_map,
            masks,
            output_depth,
            title="Depth with Segmentation Masks",
            start_point=start_point
        )
        saved_paths['depth'] = output_depth

        # 保存原始深度图为 .npy 格式
        output_depth_npy = os.path.join(output_dir, f"{prefix}depth_map.npy")
        np.save(output_depth_npy, depth_map)
        print(f"✅ 深度图已保存：{output_depth_npy} ({depth_map.shape})")
        saved_paths['depth_npy'] = output_depth_npy

        return saved_paths
