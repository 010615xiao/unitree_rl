"""
模型推理耗时追踪模块

提供统一的计时器，追踪所有模型（VLM、SAM2、GroundingDINO、Depth-Anything-v3）的推理耗时。
在程序结束时输出详细的耗时统计表格。

使用方式:
    from timing_tracker import track_time, print_timing_summary

    # 方式 1: 上下文管理器（推荐）
    with track_time("VLM", "意图解析"):
        result = client.chat.completions.create(...)

    # 方式 2: 装饰器
    @track_time("SAM2", "目标分割")
    def predict_mask(...):
        ...

    # 方式 3: 手动记录
    tracker.start("VLM", "轨迹预测")
    result = ...
    tracker.end("VLM", "轨迹预测")

    # 程序结束时输出汇总
    print_timing_summary()
"""

import time
import os
import json
import atexit
import threading
from contextlib import contextmanager
from functools import wraps
from typing import Dict, List, Optional
from datetime import datetime


class TimingEntry:
    """单次计时记录"""
    def __init__(self, model: str, operation: str, start_time: float, end_time: float = None):
        self.model = model
        self.operation = operation
        self.start_time = start_time
        self.end_time = end_time
        self.duration = (end_time - start_time) if end_time else None

    @property
    def duration_ms(self) -> Optional[float]:
        return self.duration * 1000 if self.duration else None


class TimingTracker:
    """全局耗时追踪器"""

    def __init__(self):
        self._records: List[TimingEntry] = []
        self._active_timers: Dict[str, List[TimingEntry]] = {}  # key -> list of active entries
        self._lock = threading.Lock()
        self._save_path: Optional[str] = None

        # 如果设置了环境变量 TIMING_FILE_PATH，在进程退出时自动保存
        env_path = os.environ.get("TIMING_FILE_PATH")
        if env_path:
            self._save_path = env_path
            atexit.register(self._auto_save)

    def _auto_save(self):
        """atexit 回调：保存计时数据到文件"""
        if self._save_path and self._records:
            try:
                os.makedirs(os.path.dirname(self._save_path), exist_ok=True)
                with open(self._save_path, "w") as f:
                    json.dump(self._export_records(), f)
            except Exception as e:
                print(f"⚠️  保存计时数据失败: {e}")

    def _export_records(self) -> list:
        """导出记录为可序列化的列表"""
        return [
            {
                "model": e.model,
                "operation": e.operation,
                "duration": e.duration,
                "start_time": e.start_time,
                "end_time": e.end_time,
            }
            for e in self._records
        ]

    def _import_records(self, data: list):
        """从导出的数据导入记录"""
        for item in data:
            entry = TimingEntry(item["model"], item["operation"], item["start_time"], item["end_time"])
            entry.duration = item["duration"]
            self._records.append(entry)

    def start(self, model: str, operation: str) -> None:
        """开始计时（支持多线程并发同一个 operation）"""
        key = f"{model}:{operation}"
        with self._lock:
            if key not in self._active_timers:
                self._active_timers[key] = []
            self._active_timers[key].append(TimingEntry(model, operation, time.time()))

    def end(self, model: str, operation: str) -> float:
        """结束计时，返回耗时（秒）"""
        key = f"{model}:{operation}"
        with self._lock:
            if key not in self._active_timers or not self._active_timers[key]:
                print(f"⚠️  计时器警告：未找到 '{key}' 的开始记录")
                return 0.0
            # 弹出最后一个（LIFO 顺序）
            entry = self._active_timers[key].pop()
            if not self._active_timers[key]:
                del self._active_timers[key]
            entry.end_time = time.time()
            entry.duration = entry.end_time - entry.start_time
            self._records.append(entry)
            return entry.duration

    def record(self, model: str, operation: str, duration: float) -> None:
        """直接记录一次耗时（不通过 start/end）"""
        entry = TimingEntry(model, operation, time.time() - duration, time.time())
        entry.duration = duration
        self._records.append(entry)

    def get_last_duration(self, model: str, operation: str) -> float:
        """获取最近一次计时的持续时间（不结束计时）"""
        key = f"{model}:{operation}"
        with self._lock:
            if key not in self._active_timers or not self._active_timers[key]:
                return 0.0
            entry = self._active_timers[key][-1]
            return time.time() - entry.start_time

    def get_summary(self) -> Dict[str, Dict]:
        """获取按模型+操作分组的统计摘要"""
        with self._lock:
            summary: Dict[str, Dict] = {}
            for entry in self._records:
                key = f"{entry.model}:{entry.operation}"
                if key not in summary:
                    summary[key] = {
                        "model": entry.model,
                        "operation": entry.operation,
                        "count": 0,
                        "total": 0.0,
                        "min": float('inf'),
                        "max": 0.0,
                        "durations": []
                    }
                summary[key]["count"] += 1
                summary[key]["total"] += entry.duration
                summary[key]["min"] = min(summary[key]["min"], entry.duration)
                summary[key]["max"] = max(summary[key]["max"], entry.duration)
                summary[key]["durations"].append(entry.duration)

            # 计算平均值
            for s in summary.values():
                s["avg"] = s["total"] / s["count"]

            return summary

    def print_summary(self) -> None:
        """打印详细的耗时统计表格"""
        summary = self.get_summary()
        if not summary:
            print("\n⏱️  没有记录到任何模型推理耗时")
            return

        # 按模型分组显示
        models = {}
        for key, s in summary.items():
            if s["model"] not in models:
                models[s["model"]] = []
            models[s["model"]].append(s)

        print("\n" + "=" * 90)
        print("⏱️  模型推理耗时统计")
        print("=" * 90)

        grand_total = 0.0
        grand_count = 0

        # 模型显示顺序
        model_order = ["VLM", "SAM2", "GroundingDINO", "Depth-Anything-v3", "Other"]
        model_icons = {
            "VLM": "🤖",
            "SAM2": "🎯",
            "GroundingDINO": "🔍",
            "Depth-Anything-v3": "📏",
            "Other": "📦"
        }

        for model_name in model_order:
            if model_name not in models:
                continue

            items = sorted(models[model_name], key=lambda x: x["total"], reverse=True)
            icon = model_icons.get(model_name, "📦")

            print(f"\n{icon} {model_name}")
            print("-" * 86)
            print(f"  {'操作':<30} {'次数':>4} {'总耗时(s)':>10} {'平均(s)':>9} {'最小(s)':>9} {'最大(s)':>9}")
            print(f"  {'-'*30} {'-'*4} {'-'*10} {'-'*9} {'-'*9} {'-'*9}")

            model_total = 0.0
            model_count = 0

            for s in items:
                print(f"  {s['operation']:<30} {s['count']:>4} {s['total']:>10.3f} {s['avg']:>9.3f} {s['min']:>9.3f} {s['max']:>9.3f}")
                model_total += s["total"]
                model_count += s["count"]

            print(f"  {'小计':<30} {model_count:>4} {model_total:>10.3f}")
            grand_total += model_total
            grand_count += model_count

        # 总计
        print("\n" + "-" * 86)
        print(f"  {'总计':<30} {grand_count:>4} {grand_total:>10.3f}")
        print("=" * 90)

        # 按调用次数列出详细记录
        if self._records:
            print(f"\n📋 详细调用记录（按时间顺序，共 {len(self._records)} 次调用）")
            print("-" * 86)
            print(f"  {'#':>3} {'模型':<18} {'操作':<25} {'耗时(s)':>8} {'耗时(ms)':>9}")
            print(f"  {'-'*3} {'-'*18} {'-'*25} {'-'*8} {'-'*9}")

            for i, entry in enumerate(self._records, 1):
                print(f"  {i:>3} {entry.model:<18} {entry.operation:<25} {entry.duration:>8.3f} {entry.duration_ms:>9.1f}")

            print("-" * 86)


# 全局单例
tracker = TimingTracker()


@contextmanager
def track_time(model: str, operation: str):
    """
    上下文管理器：追踪代码块耗时

    用法:
        with track_time("VLM", "意图解析"):
            result = client.chat.completions.create(...)
    """
    tracker.start(model, operation)
    try:
        yield
    finally:
        tracker.end(model, operation)


def timed(model: str, operation: str):
    """
    装饰器：追踪函数耗时

    用法:
        @timed("VLM", "意图解析")
        def parse_intent(...):
            ...
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            tracker.start(model, operation)
            try:
                result = func(*args, **kwargs)
                return result
            finally:
                tracker.end(model, operation)
        return wrapper
    return decorator


def print_timing_summary():
    """打印耗时汇总（供外部调用）"""
    tracker.print_summary()


def get_timing_summary_json() -> dict:
    """获取 JSON 格式的耗时统计（供程序化使用）"""
    summary = tracker.get_summary()
    result = {}
    for key, s in summary.items():
        result[key] = {
            "model": s["model"],
            "operation": s["operation"],
            "count": s["count"],
            "total_sec": round(s["total"], 3),
            "avg_sec": round(s["avg"], 3),
            "min_sec": round(s["min"], 3) if s["min"] != float('inf') else None,
            "max_sec": round(s["max"], 3),
        }
    return result


def load_timing_from_file(file_path: str):
    """从 JSON 文件加载计时数据并合并到全局追踪器"""
    if not os.path.exists(file_path):
        return
    try:
        with open(file_path, "r") as f:
            data = json.load(f)
        tracker._import_records(data)
    except Exception as e:
        print(f"⚠️  加载计时数据失败 ({file_path}): {e}")


def aggregate_and_print(timing_files: List[str]):
    """从多个 JSON 文件加载并聚合计时数据，打印汇总"""
    for f in timing_files:
        load_timing_from_file(f)
    print_timing_summary()


def print_detailed_timing():
    """打印每次模型推理的详细耗时（不聚合）"""
    with tracker._lock:
        records = list(tracker._records)

    if not records:
        print("\n⏱️  没有记录到任何模型推理耗时")
        return

    print("\n" + "=" * 100)
    print("⏱️  模型推理详细耗时（每次调用）")
    print("=" * 100)
    print(f"  {'序号':<6} {'模型':<20} {'操作':<35} {'耗时(s)':>8} {'耗时(ms)':>10}")
    print("-" * 100)

    total = 0.0
    for i, entry in enumerate(records, 1):
        ms = entry.duration * 1000
        total += entry.duration
        print(f"  {i:<6} {entry.model:<20} {entry.operation:<35} {entry.duration:>8.3f} {ms:>10.1f}")

    print("-" * 100)
    print(f"  {'合计':<62} {total:>8.3f} {total * 1000:>10.1f}")
    print("=" * 100)
