---
name: depth-pose-reconstruction
description: Reconstruct global colored point cloud from depth images + camera poses + intrinsics, with pose convention debugging (world2cam vs cam2world)
source: auto-skill
extracted_at: '2026-06-05T06:20:42.800Z'
---

# Depth + Pose Global Point Cloud Reconstruction

## Pipeline

1. **Load intrinsics**: fx, fy, cx, cy, image size (W, H)
2. **Load camera poses**: one 4x4 matrix per frame (16 floats per line, row-major)
3. **Match depth and RGB files**: sort by filename, pair by index
4. **For each frame**:
   - Load depth map (.npy, float32, values in mm)
   - Filter invalid: depth <= 0, depth == invalid_value (e.g. 5000), depth > max_range
   - Unproject valid pixels to camera coordinates: `x = (u - cx) * z / fx`, `y = (v - cy) * z / fy`
   - Transform to world coordinates using pose
   - Sample RGB color from corresponding image
5. **Concatenate** all frames and write to binary PLY

## Critical: Pose Convention (world2cam vs cam2world)

**Problem**: Poses may be world-to-camera (world2cam) transforms, NOT camera-to-world (cam2world). Using them directly causes all frames to collapse into a single blob near the translation vector.

**How to detect world2cam poses**:
- A specific row of the rotation matrix and the corresponding tz value are **identical across all frames** (e.g., row 3 = [0.999, -0.013, -0.024] and tz = -0.109 for every frame)
- The translation vector norm is large (~20m) but the camera barely moves in a meaningful direction
- Camera centers computed as `-R^T @ t` show a smooth trajectory, while raw translations do not

**Fix**: Invert the pose matrix before using it for backprojection:
```python
P_cam2world = np.linalg.inv(P_world2cam)
pts_world = (P_cam2world @ pts_cam_homogeneous.T).T[:, :3]
```

## Performance Tips

- Use **binary PLY** format with numpy structured arrays (not ASCII, not per-point loops):
  ```python
  vertex_dtype = np.dtype([("x","f4"),("y","f4"),("z","f4"),("red","u1"),("green","u1"),("blue","u1")])
  vertices = np.empty(n, dtype=vertex_dtype)
  # fill fields, then f.write(vertices.tobytes())
  ```
- Use stride sampling (e.g., every 2 pixels) to reduce point count while preserving structure
- Precompute pixel grid once, reuse across frames

## Depth Value Conventions

- Depth maps stored as `.npy` float32 arrays, shape (H, W)
- Values typically in **millimeters** — divide by 1000 to get meters
- Common invalid markers: 0, 5000, negative values — always check the actual data distribution first
- Filter: `valid = (depth > 0) & (depth != INVALID) & (depth <= MAX_DEPTH_M)`
