#!/usr/bin/env python3
"""
将里程计数据 (小车坐标系) 通过 Tfc/Toc 标定转换为相机坐标系下的 (x', y', yaw')，
输出替换后的 odom 文件，可直接喂给 build_pointcloud_raw.py。

流程:
  1. T_odom @ Tfo → 提取相机坐标系下的 x', y', yaw'
  2. 替换 odom_matched.txt 中的 x, y, yaw → odom_matched_camera.txt
  3. build_pointcloud_raw.py 读取替换后的文件构建位姿

用法:
    python odom_to_camera_pose.py --odom data/odom_matched.txt
    python build_pointcloud_raw.py --data_dir data --camera_height 0.0625
"""

import argparse
import os

import numpy as np

# ============================================================
# 标定矩阵 (平移单位 mm, 使用时转为 m)
# ============================================================
Tfc_raw = np.array([
    [-0.000629663, 0.999983, 0.00576696, 26.8988],
    [0.0269993, 0.00578213, -0.999618, -26.1825],
    [-0.999635, -0.000474031, -0.0270022, -77.1289],
    [0, 0, 0, 1]
])

Toc_raw = np.array([
    [-1, -1.47774e-11, 0.000169652, 96.131],
    [8.24737e-05, -0.873884, 0.486135, -3.87401],
    [0.000148256, 0.486135, 0.873884, 79.83],
    [0, 0, 0, 1]
])

Tfc = Tfc_raw.copy()
Tfc[:3, 3] /= 1000.0

Toc = Toc_raw.copy()
Toc[:3, 3] /= 1000.0


def parse_args():
    p = argparse.ArgumentParser(description="里程计 → 相机坐标系 (x', y', yaw') 替换")
    p.add_argument("--odom", type=str, required=True, help="odom_matched.txt 路径")
    p.add_argument("--output", type=str, default=None,
                   help="输出路径 (默认同目录 odom_matched_camera.txt)")
    return p.parse_args()


def main():
    args = parse_args()

    # Tfo = Tfc @ inv(Toc)
    Tfo = Tfc @ np.linalg.inv(Toc)
    print("Tfo = Tfc @ inv(Toc):")
    for row in Tfo:
        print("  " + " ".join(f"{v:12.6f}" for v in row))
    print()

    odom_path = args.odom
    output_path = args.output or os.path.join(os.path.dirname(odom_path), "odom_matched_camera.txt")

    with open(odom_path) as f:
        raw_lines = [l.rstrip('\n') for l in f]

    lines_out = []
    converted = []

    for line in raw_lines:
        stripped = line.strip()
        if not stripped:
            lines_out.append(line)
            continue

        parts = stripped.split('\t')
        if len(parts) < 6:
            lines_out.append(line)
            continue

        x_m = float(parts[1]) / 1000.0
        y_m = float(parts[2]) / 1000.0
        yaw = float(parts[3])

        c, s = np.cos(yaw), np.sin(yaw)
        T_odom = np.array([
            [c, -s, 0, x_m],
            [s,  c, 0, y_m],
            [0,  0, 1, 0],
            [0,  0, 0, 1]
        ])

        T_cam = T_odom @ Tfo
        x_new = T_cam[0, 3]
        y_new = T_cam[1, 3]
        yaw_new = np.arctan2(T_cam[1, 0], T_cam[0, 0])

        # 替换 x, y, yaw (x,y 保持 mm 格式)
        parts[1] = str(int(round(x_new * 1000)))
        parts[2] = str(int(round(y_new * 1000)))
        parts[3] = str(yaw_new)

        lines_out.append('\t'.join(parts))
        converted.append({'x': x_new, 'y': y_new, 'yaw': yaw_new,
                          'x_orig': x_m, 'y_orig': y_m, 'yaw_orig': yaw})

    with open(output_path, 'w') as f:
        f.write('\n'.join(lines_out) + '\n')

    # 打印对比
    print(f"前5帧对比 (原始 → 转换后):")
    print(f"{'Frame':>5} | {'x_orig':>8} {'y_orig':>8} {'yaw_orig':>8} | {'x_new':>8} {'y_new':>8} {'yaw_new':>8}")
    for i in range(min(5, len(converted))):
        d = converted[i]
        print(f"{i:5d} | {d['x_orig']:8.3f} {d['y_orig']:8.3f} {d['yaw_orig']:8.4f} | {d['x']:8.3f} {d['y']:8.3f} {d['yaw']:8.4f}")

    # 找 yaw 变化大的帧
    print(f"\nyaw 变化较大的帧:")
    for i in range(1, len(converted)):
        dyaw = abs(converted[i]['yaw_orig'] - converted[i-1]['yaw_orig'])
        if dyaw > 0.5:
            d = converted[i]
            print(f"  Frame {i}: yaw {d['yaw_orig']:.4f} → {d['yaw']:.4f} (delta_orig={dyaw:.4f})")
            if i < len(converted) - 1:
                break

    print(f"\n已保存 -> {output_path}")
    print(f"下一步: 将 {output_path} 重命名为 odom_matched.txt, 然后运行 build_pointcloud_raw.py")


if __name__ == "__main__":
    main()
