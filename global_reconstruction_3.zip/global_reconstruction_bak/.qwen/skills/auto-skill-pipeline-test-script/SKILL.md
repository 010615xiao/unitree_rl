---
name: pipeline-test-script
description: Create isolated test scripts that mirror the main reconstruction pipeline for debugging specific issues
source: auto-skill
extracted_at: '2026-07-01T15:20:00.000Z'
---

# Pipeline Test Script Creation

When debugging issues in the global reconstruction pipeline (e.g., missing objects in visualization, incorrect detection behavior), create an isolated test script that reproduces the exact behavior of the main pipeline with controlled inputs.

## Key Principle

**Mirror the main pipeline exactly** — use the same function signatures, parameter values, and data loading logic. Any deviation makes the test unreliable for debugging.

## Common Pitfalls and Corrections

### 1. Configuration Loading

**Wrong:**
```python
from global_reconstruction.core.config_loader import load_config
config = load_config(Path(__file__).parent / "config.yaml")
```

**Correct:**
```python
from global_reconstruction.core.config_loader import get_config
config = get_config()  # Auto-discovers config.yaml from project root
```

### 2. Intrinsics Loading

**Wrong:**
```python
from global_reconstruction.reconstruction.reconstruct_and_segment import load_intrinsics
K = load_intrinsics(intrinsic_file)  # Only works for YAML format
```

**Correct:**
```python
from global_reconstruction.core.data_adapter import DatasetAdapter
adapter = DatasetAdapter(dataset_dir)
K = adapter.K  # Handles all dataset formats (da3_ezviz, standard)
```

**Why**: `DatasetAdapter` auto-detects dataset type and loads intrinsics from the correct file format (intrinsic.txt, camera.yaml, etc.). It also computes adapted intrinsics for the working resolution.

### 3. Pose Loading

The `load_poses()` function auto-detects format:
- **TUM format** (8 values): `timestamp tx ty tz qx qy qz qw`
- **4x4 matrix format** (16 values): row-major camera-to-world matrix

For 4x4 matrix format (camera_poses.txt), frame IDs are auto-generated as sequential 5-digit strings: `"00000"`, `"00001"`, etc.

```python
from global_reconstruction.reconstruction.reconstruct_and_segment import load_poses
poses = load_poses(poses_file)  # Returns dict mapping frame_id → 4x4 T_c2w matrix
```

### 4. Depth File Format

Different datasets use different depth formats:
- **da3_ezviz**: `.npy` files (already in meters, float32)
- **standard**: `.png` files (need division by 1000.0 to convert to meters)

**Handle both:**
```python
depth_file_npy = depth_dir / f"{frame_id}.npy"
depth_file_png = depth_dir / f"{frame_id}.png"

if depth_file_npy.exists():
    depth = np.load(str(depth_file_npy))
    if depth.dtype != np.float32:
        depth = depth.astype(np.float32)
elif depth_file_png.exists():
    depth = cv2.imread(str(depth_file_png), cv2.IMREAD_UNCHANGED)
    depth = depth.astype(np.float32) / 1000.0
else:
    print(f"  Depth file not found: {depth_file_npy} or {depth_file_png}")
    continue
```

### 5. VLM Detection Function Signature

**Correct signature:**
```python
from global_reconstruction.reconstruction.reconstruct_and_segment import vlm_detect_objects

detected_objects = vlm_detect_objects(
    image_path=rgb_file,              # Path to RGB image
    discovered_categories={'plant': 1},  # Force specific categories
    history_images=None,              # Optional: list of recent images
)
```

**Returns:** List of dicts: `[{"category": "plant", "sam3_prompt": "plant"}, ...]`

### 6. SAM3 Segmentation Function Signatures

**Single category:**
```python
from global_reconstruction.reconstruction.reconstruct_and_segment import sam3_segment

detections = sam3_segment(
    image_path=rgb_file,
    category="plant",  # or sam3_prompt text
)
```

**Batch mode (preferred for multiple categories):**
```python
from global_reconstruction.reconstruction.reconstruct_and_segment import sam3_segment_batch

batch_results = sam3_segment_batch(
    image_path=rgb_file,
    category_prompts=[('plant', 'plant'), ('chair', 'office chair')],
)
# Returns: dict mapping prompt text → list of detections
```

### 7. Point Cloud Generation

```python
from global_reconstruction.reconstruction.reconstruct_and_segment import mask_to_3d_points

points_3d = mask_to_3d_points(
    mask,           # 2D boolean mask from SAM3
    depth,          # Depth image in meters (H, W)
    K,              # 3x3 intrinsics matrix
    T_c2w,          # 4x4 camera-to-world transform
    confidence=None,
    conf_threshold=0.0,
)
# Returns: Nx3 array of world coordinates
```

### 8. Visibility Visualization

```python
from global_reconstruction.reconstruction.reconstruct_and_segment import visualize_visibility

viz_path, num_visible = visualize_visibility(
    color_bgr=color_bgr,          # Current frame in BGR format
    K=K,                          # 3x3 intrinsics
    T_c2w=T_c2w,                  # 4x4 camera-to-world transform
    depth=depth,                  # Depth image in meters
    all_objects=all_objects,      # Historical objects list
    current_detections=current_detections,  # Current frame detections
    frame_id=frame_id,            # Frame identifier for filename
    output_dir=output_dir,        # Output directory
    point_size=3,                 # Projected point size (pixels)
    mask_alpha=0.45,              # Mask transparency
    max_points_per_obj=8000,      # Max points per object (random sampling)
    visibility_config=None,       # Optional: object_visibility config dict
)
```

## Complete Test Script Template

```python
#!/usr/bin/env python3
"""Test script: isolate and debug specific pipeline behavior"""

import sys
import cv2
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from global_reconstruction.core.config_loader import get_config
from global_reconstruction.core.data_adapter import DatasetAdapter
from global_reconstruction.reconstruction.reconstruct_and_segment import (
    load_poses,
    mask_to_3d_points,
    visualize_visibility,
    vlm_detect_objects,
    sam3_segment,
)


def main():
    config = get_config()
    
    # Test frames (use 5-digit format for da3_ezviz datasets)
    test_frames = ["00342", "00344", "00346", "00348", "00350", "00352", "00354"]
    
    # Dataset path
    dataset_dir = Path(__file__).parent / "datasets" / "itof_0622"
    rgb_dir = dataset_dir / "rgb"
    depth_dir = dataset_dir / "depth"
    poses_file = dataset_dir / "camera_poses.txt"
    
    # Output directory
    output_dir = Path(__file__).parent / "test_output"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Load intrinsics via DatasetAdapter
    adapter = DatasetAdapter(dataset_dir)
    K = adapter.K
    print(f"Intrinsics:\n{K}")
    
    # Load poses
    poses = load_poses(poses_file)
    print(f"Loaded {len(poses)} poses")
    
    # Accumulated objects (simulates main pipeline's all_objects)
    all_objects = []
    
    for frame_id in test_frames:
        print(f"\n{'='*60}")
        print(f"Processing frame: {frame_id}")
        print(f"{'='*60}")
        
        # Load RGB
        rgb_file = rgb_dir / f"{frame_id}.jpg"
        if not rgb_file.exists():
            print(f"  RGB not found: {rgb_file}")
            continue
        
        color = cv2.imread(str(rgb_file))
        if color is None:
            print(f"  Failed to read RGB: {rgb_file}")
            continue
        h, w = color.shape[:2]
        print(f"  Image size: {w}x{h}")
        
        # Load depth (handle both .npy and .png)
        depth_file_npy = depth_dir / f"{frame_id}.npy"
        depth_file_png = depth_dir / f"{frame_id}.png"
        
        if depth_file_npy.exists():
            depth = np.load(str(depth_file_npy))
            if depth.dtype != np.float32:
                depth = depth.astype(np.float32)
        elif depth_file_png.exists():
            depth = cv2.imread(str(depth_file_png), cv2.IMREAD_UNCHANGED)
            if depth is None:
                print(f"  Failed to read depth: {depth_file_png}")
                continue
            depth = depth.astype(np.float32) / 1000.0
        else:
            print(f"  Depth not found: {depth_file_npy} or {depth_file_png}")
            continue
        
        print(f"  Depth size: {depth.shape[1]}x{depth.shape[0]}, range: [{depth.min():.2f}, {depth.max():.2f}]m")
        
        # Load pose
        if frame_id not in poses:
            print(f"  Pose not found: {frame_id}")
            continue
        
        T_c2w = poses[frame_id]
        print(f"  Pose: T_c2w = {T_c2w[:3, 3]}")
        
        # VLM detection
        print(f"\n  [1] VLM detection...")
        detected_objects = vlm_detect_objects(
            image_path=rgb_file,
            discovered_categories={'plant': 1},  # Force specific category
            history_images=None,
        )
        
        # Filter to target category
        detected_objects = [obj for obj in detected_objects if obj.get('category') == 'plant']
        print(f"  VLM detected {len(detected_objects)} plant objects")
        
        # SAM3 segmentation
        print(f"\n  [2] SAM3 segmentation...")
        current_frame_detections = []
        for obj_info in detected_objects:
            category = obj_info['category']
            sam3_text = obj_info.get('sam3_prompt', category)
            
            print(f"    Segmenting: {category} ({sam3_text})")
            detections = sam3_segment(
                image_path=rgb_file,
                category=sam3_text,
            )
            
            print(f"      Got {len(detections)} detections")
            for det in detections:
                mask = det.get('mask')
                if mask is not None:
                    # Generate 3D point cloud
                    points_3d = mask_to_3d_points(
                        mask, depth, K, T_c2w,
                        confidence=None,
                        conf_threshold=0.0,
                    )
                    print(f"      Point cloud size: {len(points_3d)}")
                    
                    # Filter by minimum points threshold
                    if len(points_3d) > config.object_segmentation.min_points:
                        current_frame_detections.append({
                            'mask': mask,
                            'category': category,
                            'score': det.get('score', 0),
                            'points_3d': points_3d,
                        })
        
        # Generate visibility visualization
        print(f"\n  [3] Generating visibility_viz...")
        viz_dir = output_dir / "visibility_viz"
        viz_dir.mkdir(parents=True, exist_ok=True)
        
        viz_path, num_visible = visualize_visibility(
            color_bgr=color,  # Already in BGR format
            K=K,
            T_c2w=T_c2w,
            depth=depth,
            all_objects=all_objects,
            current_detections=current_frame_detections,
            frame_id=frame_id,
            output_dir=viz_dir,
            point_size=config.object_segmentation.visibility_viz.projected_point_size,
            mask_alpha=config.object_segmentation.visibility_viz.mask_alpha,
            max_points_per_obj=config.object_segmentation.visibility_viz.max_points_per_object,
            visibility_config=None,
        )
        
        print(f"  Visualization saved: {viz_path}")
        print(f"  Visible historical objects: {num_visible}/{len(all_objects)}")
        print(f"  Current detections: {len(current_frame_detections)}")
        
        # Add current frame detections to all_objects (simulate main pipeline)
        for det in current_frame_detections:
            all_objects.append({
                'category': det['category'],
                'points': det['points_3d'],
                'frame': frame_id,
                'image_path': str(rgb_file),
                'center': det['points_3d'].mean(axis=0),
                'T_c2w': T_c2w.copy(),
                'source_views': [],
            })
        
        print(f"\n  Total accumulated objects: {len(all_objects)}")
    
    print(f"\n{'='*60}")
    print(f"Test complete! Output directory: {output_dir}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
```

## Debugging Checklist

When the test script works but the main pipeline doesn't:

1. **Check frame ID format**: Main pipeline may use different frame ID format (timestamp vs sequential)
2. **Check detection_interval**: Main pipeline skips frames based on `detection_interval` config
3. **Check object accumulation**: Verify objects are being added to `all_objects` correctly
4. **Check visibility filtering**: Verify `visible_ratio >= 0.20` threshold isn't filtering out objects
5. **Check point cloud threshold**: Verify `min_points: 30` threshold isn't filtering out small detections
6. **Check structural category exclusion**: `floor`, `wall`, `ceiling` are excluded from visualization

## Critical First Step: Verify Scene Content

**Before assuming a pipeline bug, verify the object is actually visible in the frame's image.**

Common scenario: User reports "object X missing in frame N", but the camera position at frame N simply doesn't show object X.

**How to verify:**
```python
# Load and inspect the actual image
import cv2
img = cv2.imread(str(rgb_file))
# Display or save for visual inspection
cv2.imwrite("debug_frame.jpg", img)
```

**Example from debugging session:**
- User asked: "Why no plant in frames 00034/00036?"
- Investigation: Frame 00034 shows a different room area with chairs/desks only — **no plant exists in that view**
- Frame 00344 shows the plant clearly (different camera position)
- **Conclusion**: Not a bug — plant is only visible from certain camera positions

**Rule**: Always check the actual image content before debugging detection/visualization logic.

## Dataset Format Detection

`DatasetAdapter` auto-detects dataset type:
- **da3_ezviz**: Has `rgb/` directory and `camera_poses.txt` → uses `.npy` depth, intrinsic.txt
- **standard**: Has `images/` directory and `poses.txt` → uses `.png` depth, camera.yaml

Frame ID format:
- **da3_ezviz**: Sequential 5-digit strings (`"00000"`, `"00001"`, ...)
- **standard**: Timestamps from poses.txt (`"1757050926519.6672"`, ...)
