---
name: depth-confidence-visualization
description: Visualize Depth Anything V3 depth and confidence maps with color-coded low-confidence regions to diagnose point cloud filtering issues
source: auto-skill
extracted_at: '2026-07-01T13:42:08.247Z'
---

# Depth and Confidence Visualization

Visualize depth and confidence maps from Depth Anything V3 to diagnose why objects (e.g., plants) are being filtered out during point cloud generation.

## Purpose

When objects disappear from point clouds despite being visible in RGB images, the issue is often **confidence threshold filtering** in `mask_to_3d_points()`. This visualization helps identify:
- Which regions have confidence < threshold (marked in red)
- Whether object regions (plants, furniture) fall in low-confidence areas
- Appropriate threshold adjustments

## Script: `visualize_depth_conf.py`

```python
#!/usr/bin/env python3
"""可视化 depth 和 confidence 图，高亮 confidence < 1 的区域"""

import numpy as np
import cv2
from pathlib import Path
from tqdm import tqdm


def visualize_confidence(conf, output_path, threshold=1.0):
    """可视化 confidence 图，红色标记 < threshold 的区域"""
    # 归一化到 0-255
    conf_norm = (conf * 255).astype(np.uint8)
    conf_color = cv2.applyColorMap(conf_norm, cv2.COLORMAP_JET)
    
    # 标记 < threshold 的区域（红色）
    low_conf_mask = conf < threshold
    if low_conf_mask.sum() > 0:
        conf_color[low_conf_mask] = [0, 0, 255]  # BGR 红色
    
    cv2.imwrite(str(output_path), conf_color)
    return low_conf_mask.sum()


def visualize_depth(depth, output_path, max_depth=15.0):
    """可视化 depth 图"""
    # 裁剪到 [0, max_depth]
    depth_clipped = np.clip(depth, 0, max_depth)
    depth_norm = (depth_clipped / max_depth * 255).astype(np.uint8)
    depth_color = cv2.applyColorMap(depth_norm, cv2.COLORMAP_TURBO)
    
    # 标记无效深度（黑色）
    invalid_mask = (depth <= 0) | (depth >= max_depth) | ~np.isfinite(depth)
    if invalid_mask.sum() > 0:
        depth_color[invalid_mask] = [0, 0, 0]
    
    cv2.imwrite(str(output_path), depth_color)


def main():
    dataset_dir = Path('/workspace/wxd/Agent-Skill/agent/my_file/global_reconstruction_bak/datasets/itof_0622')
    depth_dir = dataset_dir / 'depth'
    conf_dir = dataset_dir / 'conf'
    
    output_dir = Path('/workspace/wxd/Agent-Skill/agent/my_file/global_reconstruction_bak/test_output/depth_conf_viz')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 获取所有帧
    depth_files = sorted(depth_dir.glob('*.npy'))
    print(f"找到 {len(depth_files)} 个深度帧")
    
    for depth_file in tqdm(depth_files, desc="生成可视化"):
        frame_id = depth_file.stem
        
        # 加载 depth 和 conf
        depth = np.load(str(depth_file))
        conf_file = conf_dir / f"{frame_id}_conf.npy"
        
        if not conf_file.exists():
            print(f"  警告：{conf_file} 不存在，跳过")
            continue
        
        conf = np.load(str(conf_file))
        
        # 生成可视化
        conf_viz_path = output_dir / f"{frame_id}_conf.png"
        depth_viz_path = output_dir / f"{frame_id}_depth.png"
        
        low_conf_count = visualize_confidence(conf, conf_viz_path, threshold=1.0)
        visualize_depth(depth, depth_viz_path, max_depth=15.0)
        
        total_pixels = conf.size
        low_conf_ratio = low_conf_count / total_pixels * 100
        
        if low_conf_ratio > 1:  # 只打印低置信度比例 > 1% 的帧
            print(f"  {frame_id}: 低置信度像素 {low_conf_count}/{total_pixels} ({low_conf_ratio:.2f}%)")
    
    print(f"\n可视化已保存到：{output_dir}")
    print("红色 = confidence < 1.0")


if __name__ == "__main__":
    main()
```

## Color Mapping

| Color | Meaning |
|-------|---------|
| **Red** (BGR: [0,0,255]) | confidence < threshold (low confidence) |
| **Dark red/brown** | confidence >= threshold (high confidence) |
| **Blue→Green→Yellow→Red** (JET colormap) | Depth: near (blue) → far (red) |
| **Black** | Invalid depth (<=0 or >= max_depth) |

## Key Findings from itof_0622 Dataset

After visualizing all 992 frames:

1. **Most pixels have confidence < 1.0**: Typical frames show 20-50% of pixels in red (low confidence)
2. **Plant regions are almost entirely red**: Plants have confidence < 1.0, explaining why they're filtered out
3. **Only close-range surfaces have high confidence**: Floor, walls, and nearby objects show dark red/brown (confidence >= 1.0)

### Example Statistics

```
00034: 低置信度像素 70188/225280 (31.16%)
00344: 低置信度像素 94846/225280 (42.10%)
00734: 低置信度像素 196928/225280 (87.41%)  # Extreme case
```

## Root Cause Analysis

In `mask_to_3d_points()`:

```python
# Current filtering (too strict)
mask = (depth > 0) & (depth < 15.0) & (conf >= 1.0)
points_3d = backproject(depth[mask], K, T_c2w)
```

**Problem**: `conf >= 1.0` filters out most pixels including plant regions.

**Solution options**:

1. **Lower the threshold**:
   ```python
   mask = (depth > 0) & (depth < 15.0) & (conf >= 0.3)
   ```

2. **Use relative threshold** (per-frame median):
   ```python
   conf_threshold = np.median(conf[conf > 0])
   mask = (depth > 0) & (depth < 15.0) & (conf >= conf_threshold * 0.5)
   ```

3. **Remove confidence filtering entirely** (test first):
   ```python
   mask = (depth > 0) & (depth < 15.0)
   ```

## Usage

```bash
# Generate visualizations for all frames
python visualize_depth_conf.py

# Output: test_output/depth_conf_viz/
#   - {frame_id}_conf.png  (confidence map, red = low confidence)
#   - {frame_id}_depth.png (depth map, blue=near, red=far)
```

## File Locations

- **Script**: `visualize_depth_conf.py`
- **Input**: `datasets/itof_0622/depth/*.npy`, `datasets/itof_0622/conf/*_conf.npy`
- **Output**: `test_output/depth_conf_viz/`

## Related: Confidence Threshold in Point Cloud Generation

The confidence threshold is applied in `global_reconstruction/reconstruction/reconstruct_and_segment.py`:

```python
def mask_to_3d_points(depth, conf, K, T_c2w, conf_threshold=1.0):
    """Convert depth mask to 3D points with confidence filtering"""
    mask = (depth > 0) & (depth < 15.0) & (conf >= conf_threshold)
    # ... backproject ...
```

After visualization confirms the issue, adjust `conf_threshold` parameter or modify the filtering logic.
