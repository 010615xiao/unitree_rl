---
name: cross-frame-object-matching
description: Maintain consistent object IDs across frames by matching new detections to existing alive objects via category and 3D centroid distance before creating new entries
source: auto-skill
extracted_at: '2026-07-03T06:33:18.422Z'
---

# Cross-Frame Object Matching

## Problem

During frame-by-frame detection, the same physical object detected in different frames receives different sequential IDs. For example, a person detected in frame 00048 as `#76` and in frame 00050 as `#78` are the same physical object but have different IDs. This breaks object lifecycle tracking and makes it impossible to maintain a coherent history of object observations across frames.

## Root Cause

The object creation logic in `reconstruct_and_segment.py` always appends new objects to `all_objects` with sequential IDs:

```python
all_objects.append({...})
_new_obj_idx = len(all_objects) - 1
lifecycle_tracker.register_object(obj_id=_new_obj_idx, ...)
```

There is no mechanism to check if a new detection corresponds to an existing alive object before creating a new entry.

## Solution

Add cross-frame matching that checks new detections against existing alive objects in the lifecycle tracker before creating new entries.

### Helper Function: `_find_matching_object()`

```python
def _find_matching_object(
    category: str,
    centroid: np.ndarray,
    lifecycle_tracker: LifecycleTracker,
    all_objects: list[dict],
    distance_threshold: float = 1.0,
) -> int | None:
    """Find an existing alive object that matches the given category and centroid.
    
    Returns:
        obj_id of the best match, or None if no match found.
    """
    alive_instances = lifecycle_tracker.get_alive_instances()
    if not alive_instances:
        return None

    best_match_id = None
    best_distance = float('inf')

    for obj_id, instance in alive_instances.items():
        if instance.category != category:
            continue
        if not instance.centroid_trajectory:
            continue
        
        # Get last known centroid from trajectory
        last_trajectory = instance.centroid_trajectory[-1]
        existing_centroid = np.array([last_trajectory[1], last_trajectory[2], last_trajectory[3]])
        
        distance = float(np.linalg.norm(centroid - existing_centroid))
        if distance < distance_threshold and distance < best_distance:
            best_distance = distance
            best_match_id = obj_id

    return best_match_id
```

### Modified Object Creation Logic

Replace the unconditional append with a match-or-create pattern:

```python
# Check for existing match before creating new object
matched_id = _find_matching_object(
    category=category,
    centroid=object_center,
    lifecycle_tracker=lifecycle_tracker,
    all_objects=all_objects,
    distance_threshold=1.0,
)

if matched_id is not None:
    # Update existing object's points and centroid
    existing_obj = all_objects[matched_id]
    existing_obj['points'] = np.vstack([existing_obj['points'], points_3d])
    update_centroid_incremental(existing_obj, points_3d)
    
    # Update lifecycle tracker observation
    lifecycle_tracker.update_observation(
        obj_id=matched_id,
        frame_id=timestamp_str,
        centroid=object_center.tolist(),
        point_count=len(points_3d),
    )
else:
    # Create new object as before
    all_objects.append({
        'category': category,
        'points': points_3d,
        'frame': timestamp_str,
        'image_path': str(color_file),
        'center': object_center,
        'T_c2w': T_c2w.copy(),
        'source_views': [grounded_view] if grounded_view else [],
        '_centroid': object_center.copy(),
        '_point_count': len(points_3d),
    })
    _new_obj_idx = len(all_objects) - 1
    lifecycle_tracker.register_object(
        obj_id=_new_obj_idx,
        category=category,
        frame_id=timestamp_str,
        centroid=object_center.tolist(),
        point_count=len(points_3d),
    )
```

## Key Design Decisions

1. **Match against alive instances only** - Dead objects (exceeded miss threshold) are not candidates for matching. Future detections at the same location create new instances (irreversible death).

2. **Category + centroid distance** - Two criteria must match:
   - Same category (e.g., both "person")
   - Centroid distance < threshold (default 1.0m)
   
3. **Greedy best match** - If multiple alive objects match, pick the closest by centroid distance.

4. **Incremental centroid update** - When updating an existing object, use `update_centroid_incremental()` to maintain the cached `_centroid` and `_point_count` fields without recomputing from all points.

5. **Distance threshold tuning** - The `distance_threshold` parameter (default 1.0m) controls how strict the matching is:
   - Too small: same object detected at slightly different positions creates duplicate entries
   - Too large: distinct objects at similar locations get incorrectly merged
   
   The threshold should be tuned based on object size and detection noise. For typical indoor scenes with objects like chairs, tables, and people, 1.0m is a reasonable starting point.

## Relationship to Other Skills

- **lightweight-object-merge**: This skill handles within-frame deduplication (multiple detections of the same object in a single frame). Cross-frame matching handles across-frame identity maintenance. They are complementary - lightweight merge runs before visualization, cross-frame matching runs during object creation.

- **lifecycle-tracker**: Cross-frame matching relies on the lifecycle tracker's `get_alive_instances()` method to find candidate objects. The matched objects' observations are updated via `update_observation()`, which maintains the centroid trajectory and resets miss counts.

## Configuration

```yaml
# config.yaml → object_segmentation.visibility_viz
cross_frame_match_distance: 1.0  # metres; max centroid distance for cross-frame match
```

## Implementation Location

- Helper function: `global_reconstruction/reconstruction/reconstruct_and_segment.py` (around line 221-268)
- Object creation logic: `global_reconstruction/reconstruction/reconstruct_and_segment.py` (around line 3630, in the VLM detection loop)

## Verification

To verify cross-frame matching is working:
1. Run the pipeline on a multi-frame sequence
2. Check that the same physical object maintains the same ID across frames
3. Verify that `lifecycle_tracker.get_alive_instances()` returns objects with multiple entries in `observed_frames` and `centroid_trajectory`
4. Confirm that object count growth is slower (duplicates are merged instead of creating new entries)
