---
name: lifecycle-tracker
description: Object lifecycle tracking with depth-ray state detection (persisting/occluded/disappeared/unknown), ratio-based UNKNOWN threshold, miss-count death threshold, merged-state propagation to constituents, and irreversible object death
source: auto-skill
extracted_at: '2026-07-03T03:23:57.360Z'
---

# Object Lifecycle Tracker

## Problem

During incremental reconstruction, objects are detected frame-by-frame. Need to track:
- Birth frame, observed frames, centroid trajectory per object instance
- Object state each frame: persisting, occluded, disappeared, or unknown (via depth ray comparison)
- Miss count with death threshold — only mark permanently dead after consecutive misses
- State propagation from merged objects back to all constituent originals via `_merged_from`
- Irreversible death — once dead, future detections at same location create new instances

## Architecture

### State Detection (`object_state_detector.py`)

Depth ray comparison determines object state per frame:

1. **Project** each merged object's 3D points to image plane → get pixel coords + expected depth
2. **Sample** actual depth from depth map at those pixels (mask-based, not bbox, with edge erosion)
3. **Filter** invalid depths: `depth_min < actual < depth_max` (default 0.01-15m)
4. **Classify** by valid depth ratio and match ratio:
   - `valid_ratio < valid_ratio_threshold` (default 0.5) → **UNKNOWN** (insufficient depth evidence)
   - `valid_ratio >= valid_ratio_threshold` but `n_pixels < min_valid_samples` → **UNKNOWN** (too few pixels for confident classification, insufficient evidence)
   - `n_pixels >= min_valid_samples` and `match_ratio >= persist_ratio` → **PERSISTING**
   - `n_pixels >= min_valid_samples` but low match ratio → **OCCLUDED** or **DISAPPEARED**

**UNKNOWN state purpose**: Used in two cases:
1. When confidence filtering removes most depth pixels (`valid_ratio < valid_ratio_threshold`), the object state is uncertain regardless of absolute pixel count.
2. When there are enough valid pixels ratio-wise but too few absolute samples (`n_valid < min_valid_samples`), there is insufficient evidence for confident classification.

UNKNOWN prevents false miss_count increments that would prematurely kill objects due to temporary poor depth data quality or limited projection area.

Key: occlusion detection is depth-primary — if something closer blocks the ray, it's occluded regardless of what name the closer surface has.

### Lifecycle Tracker (`lifecycle_tracker.py`)

```python
@dataclass
class ObjectInstance:
    obj_id: int
    category: str
    birth_frame: str
    observed_frames: list[str]
    centroid_trajectory: list[tuple]  # (frame_id, cx, cy, cz, point_count)
    is_alive: bool = True
    miss_count: int = 0
    current_state: str = "unknown"
```

Key API methods:
- `register_object()` — new instance at birth frame
- `update_observation(state="persisting")` — records observation, resets miss_count when persisting
- `increment_miss_count(death_threshold=5)` — increments miss; marks `is_alive=False` when threshold exceeded
- `get_alive_instances()` — returns only alive instances
- `record_merge_groups()` — per-frame lightweight merge groups

### Config (`config.yaml`)

```yaml
visibility_viz:
  state_detection_enabled: true
  depth_tolerance: 0.25          # meters, sensor noise + surface thickness
  min_valid_samples: 20          # minimum pixels for reliable classification
  persist_ratio_threshold: 0.3   # fraction of matching pixels for PERSISTING
  valid_ratio_threshold: 0.5     # fraction of valid/total projected pixels; below = UNKNOWN
  miss_death_threshold: 5        # consecutive misses before permanent death
```

## Integration in Main Loop

After `visualize_visibility()` returns `_vis_records`:

```python
if state_detection_enabled:
    state_results = detect_object_states(
        merged_objects=_merged_objects, K=K, T_w2c=T_w2c,
        depth_map=depth, max_distance=..., depth_tolerance=...,
        min_valid_samples=..., persist_ratio=...,
        valid_ratio_threshold=0.5,  # valid/total projected pixels below this = UNKNOWN
    )
    for mi, mobj in enumerate(_merged_objects):
        constituents = mobj.get('_merged_from', [mi])
        state = state_by_idx[mi].state
        if state == PERSISTING:
            for orig_idx in constituents:
                tracker.update_observation(orig_idx, frame_id, ..., state='persisting')
        elif state in ('UNKNOWN', 'OCCLUDED'):
            # Insufficient evidence or occluded - don't increment miss_count
            # Object is still present (uncertain or blocked), no penalty applied
            for orig_idx in constituents:
                tracker.update_observation(orig_idx, frame_id, state=state)
        else:  # DISAPPEARED only
            for orig_idx in constituents:
                tracker.increment_miss_count(orig_idx, frame_id, state=..., death_threshold=...)
```

**Key difference for UNKNOWN and OCCLUDED**: Both call `update_observation()` instead of `increment_miss_count()`. This updates `current_state` but leaves `miss_count` unchanged (neither incremented nor reset).

**Critical fix**: OCCLUDED objects must NOT increment miss_count. An occluded object is still present in the scene, just blocked from view by something closer. Only DISAPPEARED (object not detected at all) should increment miss_count. Previously, the `else` branch incorrectly treated both OCCLUDED and DISAPPEARED the same way, causing occluded objects to accumulate misses and die prematurely.

## Final Output Filtering: Remove Dead Objects

The lifecycle tracker correctly marks objects as dead (`is_alive=False` when `miss_count >= death_threshold`), but **dead objects must be explicitly filtered from `all_objects` before saving to final output**.

### Filtering Code (after main frame processing loop)

```python
# ================= 过滤死亡物体 =================
# 获取存活的物体 ID 集合
alive_instances = lifecycle_tracker.get_alive_instances()
alive_obj_ids = set(alive_instances.keys())

# 过滤 all_objects，只保留存活的物体
original_obj_count = len(all_objects)
all_objects = [obj for idx, obj in enumerate(all_objects) if idx in alive_obj_ids]
removed_count = original_obj_count - len(all_objects)

if removed_count > 0:
    print(f"\n  已过滤 {removed_count} 个死亡物体 (miss_count >= 阈值)")
    print(f"  过滤前物体数：{original_obj_count}，过滤后：{len(all_objects)}")
    
    # 重新编号物体（因为过滤后索引会变化）
    for new_idx, obj in enumerate(all_objects):
        if '_merged_from' in obj:
            obj['_merged_from'] = [new_idx]
```

### Why This Step is Critical

- The lifecycle tracker maintains internal state but doesn't modify `all_objects`
- Without filtering, dead objects remain in the final output (objects.json, visualization, etc.)
- The filtering happens **after** all frame processing but **before** saving lifecycle data and final output
- `obj_id` corresponds to the index in `all_objects` (assigned when objects are registered), so filtering by index works correctly

### Verification: Check Output Timestamps

When debugging lifecycle issues, verify that output files reflect the current code:

```bash
# Check when output files were created
ls -lh unified_output/objects.json

# Check when script was last modified
ls -lh global_reconstruction/reconstruction/reconstruct_and_segment.py
```

If output files are older than the script modification time, the output is from a previous run and doesn't include recent fixes. The pipeline must be re-run to apply code changes.

### Expected Results

After filtering:
- Dead objects (miss_count >= 5) are removed from `all_objects`
- Only alive objects are saved to `unified_output/objects.json`
- Lifecycle data (`lifecycle/object_instances.json`) still contains ALL objects (including dead ones) for analysis
- The `is_alive` field in lifecycle data allows post-hoc analysis of object death patterns

## Bug Diagnosis: OCCLUDED State Miss Count Issue

### Symptom
Objects with `current_state='occluded'` had `miss_count=5` and `is_alive=False`, meaning they died after being occluded for several frames.

### Root Cause
In `reconstruct_and_segment.py`, the state handling logic used an `else` branch that caught both OCCLUDED and DISAPPEARED:

```python
# BUGGY CODE
if state == 'persisting':
    update_observation(state='persisting')  # resets miss_count ✓
elif state == 'unknown':
    update_observation(state='unknown')  # no penalty ✓
else:  # OCCLUDED and DISAPPEARED both hit this ✗
    increment_miss_count(...)  # both increment miss_count
```

### Fix
Split the logic to handle OCCLUDED separately:

```python
# FIXED CODE
if state == 'persisting':
    update_observation(state='persisting')  # resets miss_count ✓
elif state in ('unknown', 'occluded'):
    update_observation(state=state)  # no penalty ✓
else:  # DISAPPEARED only
    increment_miss_count(...)  # increment miss_count ✓
```

### Verification
Test script `test_lifecycle_fix.py` validates:
- OCCLUDED does not increment miss_count
- UNKNOWN does not increment miss_count
- DISAPPEARED increments miss_count
- PERSISTING resets miss_count
- Object dies after `miss_death_threshold` consecutive DISAPPEARED states

## Key Design Decisions

1. **Depth-primary, name-secondary** — Occlusion is detected by depth mismatch regardless of object name. A wall in front of a chair correctly causes occlusion.
2. **Mask-based sampling** — Uses projected pixel region (with edge erosion), not bbox, to avoid noise/outlier interference from bbox boundaries.
3. **Merged state propagation** — State detected on a merged object propagates to ALL constituent original objects via `_merged_from`.
4. **Miss count threshold** — Prevents premature death from transient occlusions. Only consecutive misses exceeding threshold cause permanent death.
5. **UNKNOWN state for ambiguous cases** — Object is marked UNKNOWN instead of DISAPPEARED in two scenarios:
   - When confidence filtering removes most depth pixels (`valid_ratio < valid_ratio_threshold`), using ratio-based threshold (`valid_ratio = n_valid / n_total`) rather than absolute pixel count
   - When there are too few valid samples (`n_valid < min_valid_samples`) for confident classification, even if the ratio is acceptable
   
   Both cases represent insufficient evidence for classification, not evidence of disappearance.
6. **Irreversible death** — Dead objects cannot be resurrected. Future detections at same location create new instances.
7. **Fallback mode** — When `state_detection_enabled=false`, reverts to simple observation updates for all visible objects.
