---
name: numpy-structured-dtype-view-fix
description: Fix NumPy structured dtype view errors with boolean-indexed arrays using np.void view for row-level set operations
source: auto-skill
extracted_at: '2026-07-01T05:34:02.685Z'
---

# NumPy Structured Dtype View Fix

When converting `(N, K)` arrays to sets for efficient intersection operations, use `np.void` view for fast C-level row-wise set operations.

## Problem

```python
# This fails with boolean-indexed slices:
_dt = np.dtype((all_keys.dtype, (3,)))
stable_keys_set = set(np.ascontiguousarray(all_keys[stable_mask]).view(_dt).ravel())
# ValueError: Changing the dtype to a subarray type is only supported if the total itemsize is unchanged
```

**Root cause**: Structured subarray dtype `(int64, (3,))` has strict compatibility requirements. Even `np.ascontiguousarray()` doesn't always resolve the itemsize mismatch when the original array dtype doesn't match the view dtype expectations.

## Solution: np.void View (Recommended)

Use `np.void` view — treats each row as a single opaque bytes object. This is NumPy's standard trick for row-level set operations:

```python
def _keys_to_set(keys):
    if len(keys) == 0:
        return set()
    contiguous = np.ascontiguousarray(keys)
    void_dt = np.dtype((np.void, contiguous.strides[0]))  # each row = one void object
    return set(contiguous.view(void_dt).ravel())

# Usage
stable_keys_set = _keys_to_set(all_keys[stable_mask])
all_keys_set = _keys_to_set(all_keys)

for obj in objects:
    keys = np.floor(pts / vs).astype(np.int64)
    unique_keys = np.unique(keys, axis=0)
    unique_set = _keys_to_set(unique_keys)

    stable_count = len(unique_set & stable_keys_set)
    observed_count = len(unique_set & all_keys_set)
```

**Why it works**: `np.void` view treats each row's raw bytes as a single hashable object. No dtype compatibility issues — works with any array dtype and shape.

## Alternative: np.in1d with Structured View (May Fail)

The structured subarray approach (`np.dtype((int64, (3,)))`) can still fail even with `np.ascontiguousarray()`. Avoid unless you've verified it works with your specific NumPy version.

## Alternative: Tuple Conversion (Fallback)

If `np.void` view fails for some reason, use tuple conversion (slower but always works):

```python
stable_keys_set = {tuple(k) for k in all_keys[stable_mask]}
all_keys_set = {tuple(k) for k in all_keys}
unique_set = {tuple(k) for k in unique_keys}

stable_count = len(unique_set & stable_keys_set)
```

**Performance**: ~10-50x slower than `np.void` view for large arrays (100K+ rows).

## Performance Comparison

| Approach | Speed (100K rows) | Reliability |
|----------|-------------------|-------------|
| `np.void` view | ~10ms | **Most robust** — works with any dtype |
| Tuple comprehension | ~500ms | Robust — works with any array |
| Structured `(int64,(3,))` view + `np.in1d` | ~10ms | **Fragile** — fails on boolean-indexed slices |

## When to Apply

- Converting `(N, K)` coordinate arrays to sets for intersection/union operations
- Working with boolean-indexed or fancy-indexed array slices
- When `.view()` throws "total itemsize is unchanged" errors
- Performance-critical loops with large arrays (N > 10K)

## Example Context

```python
# Voxel stability filtering — 9.5M voxels
all_keys = soa.keys[:n_voxels]  # (N, 3) int64
stable_mask = soa.is_stable[:n_voxels]  # boolean array

# ✅ Fast and robust — np.void view
def _keys_to_set(keys):
    if len(keys) == 0:
        return set()
    contiguous = np.ascontiguousarray(keys)
    void_dt = np.dtype((np.void, contiguous.strides[0]))
    return set(contiguous.view(void_dt).ravel())

stable_keys_set = _keys_to_set(all_keys[stable_mask])
all_keys_set = _keys_to_set(all_keys)

for obj in objects:
    keys = np.floor(pts / vs).astype(np.int64)
    unique_keys = np.unique(keys, axis=0)
    unique_set = _keys_to_set(unique_keys)

    stable_count = len(unique_set & stable_keys_set)
    observed_count = len(unique_set & all_keys_set)
```
