---
name: sam3-batch-segmentation
description: Convert sequential SAM3 segmentation calls to batch mode using /predict_batch endpoint
source: auto-skill
extracted_at: '2026-06-30T11:42:50.072Z'
---

# SAM3 Batch Segmentation

When processing multiple object categories per frame, avoid N sequential HTTP calls to SAM3. Instead, use the `/predict_batch` endpoint to encode the image once and reuse backbone features across all prompts.

## Pattern

### 1. Define batch URL constant

```python
# Derive from existing SAM3 URL
SAM3_BATCH_URL = SAM3_URL.rsplit('/', 1)[0] + '/predict_batch'
```

### 2. Create batch segmentation function

```python
def sam3_segment_batch(image_path, category_prompts, sam3_batch_url=..., timeout=60):
    """批量文本分割 — 图像编码一次，多个 prompt 复用"""
    # Extract unique texts from prompts
    texts = list(dict.fromkeys(text for _, text in category_prompts))
    
    payload = {
        "image_path": str(Path(image_path).resolve()),
        "texts": texts
    }
    
    response = requests.post(sam3_batch_url, json=payload, timeout=timeout)
    response.raise_for_status()
    results = response.json()
    
    # Parse results_map: {text: [detections]}
    results_map = {}
    for item in results.get('results', []):
        text = item.get('text', '')
        detections = item.get('detections', [])
        results_map[text] = detections
    
    return results_map
```

### 3. Modify main loop to batch mode

**Before (sequential):**
```python
for obj_info in detected_objects:
    category = obj_info['category']
    sam3_text = obj_info.get('sam3_prompt', category)
    detections = sam3_segment_single(image_path, sam3_text)
    # process detections...
```

**After (batch):**
```python
# Collect all prompts first
batch_prompts = [
    (obj_info['category'], obj_info.get('sam3_prompt', category))
    for obj_info in detected_objects
]

# Single batch call
batch_results = sam3_segment_batch(color_file, batch_prompts)

# Iterate results
for (category, sam3_text) in batch_prompts:
    detections = batch_results.get(sam3_text, [])
    # process detections...
```

### 4. Update incremental pipeline

For `incremental_update.py` and `streaming_runner.py`:
- Import `DEFAULT_SAM3_BATCH_URL`
- Add `sam3_batch_url` parameter to `auto_detect_current_frame()`
- Pass through from config loading

## Benefits

- **Speed**: Image backbone encoding runs once instead of N times
- **Efficiency**: Reduces HTTP overhead and GPU memory churn
- **Scalability**: Performance gain increases with number of categories per frame

## Server Requirements

The SAM3 server must expose `/predict_batch` endpoint that:
1. Accepts `{"image_path": str, "texts": List[str]}`
2. Calls `set_image()` once
3. Iterates over texts list, reusing encoded features
4. Returns grouped results: `{"results": [{"text": ..., "detections": [...]}]}`
