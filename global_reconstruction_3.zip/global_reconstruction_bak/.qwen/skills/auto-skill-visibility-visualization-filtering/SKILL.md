---
name: visibility-visualization-filtering
description: Filter objects for visibility visualization using geometric projection checks, structural category exclusion, point cloud ratio threshold, 2D bbox drawing, per-frame JSON record persistence, and live/occluded/miss state display in stats bar
source: auto-skill
extracted_at: '2026-07-03T02:51:04.182Z'
---

# Visibility Visualization Filtering

## Current Architecture (After Refactoring to incremental/)

As of 2026-07-02, all object lifecycle management code has been consolidated into `global_reconstruction/incremental/`:

- **`incremental/visibility_visualizer.py`** — Visibility detection, geometric projection filtering, distance-based culling, and side-by-side reprojection visualization (`visualize_visibility()`, `load_visibility_viz_config()`)
- **`incremental/object_merger.py`** — Lightweight pre-visualization merge: greedy clustering by category + 3D centroid distance with incremental centroid update (`merge_similar_objects()`, `update_centroid_incremental()`)
- **`incremental/incremental_update.py`** — Object state updates (add/match/delete), detection matching
- **`incremental/object_visibility.py`** — Utility functions only (IoU, intrinsics loading, pose loading)
- **`incremental/object_memory.py`** — Scene graph annotation with object updates

The `incremental/` package is the **single responsibility module** for object lifecycle management: state updates, visibility detection, and reprojection visualization.

The ray-AABB depth interval and depth evidence classification mechanism (`predict_object_visibility`, `predict_visible_objects`) has been **removed**. Simple geometric projection checks are used instead.

## Refactored Architecture: Extracted Helper + State Display (2026-07-03)

As of 2026-07-03, the visibility visualization was refactored to:
1. Extract filtering logic into a reusable `filter_visible_objects()` helper
2. Add `state_results` parameter to display live/occluded/miss objects in stats bar
3. Restructure caller to run state detection BEFORE visualization

### New Helper Function: `filter_visible_objects()`

```python
from global_reconstruction.incremental.visibility_visualizer import filter_visible_objects

# Call BEFORE visualize_visibility to get visible items
_visible_items, _vis_records = filter_visible_objects(
    all_objects=_merged_objects,
    K=K_frame,
    T_c2w=T_c2w,
    depth=depth,
    max_distance=_VIS_VIZ_CFG['max_distance'],
    min_visible_ratio=0.20,
)
```

**Returns:**
- `visible_items`: list of `(obj_idx, obj)` tuples for visible objects
- `visibility_records`: list of per-object visibility records (for JSON export)

**Why extract**: The caller needs access to visible items for state detection BEFORE visualization. Previously, filtering happened inside `visualize_visibility()` with no way to access intermediate results.

### Updated `visualize_visibility()` Signature

```python
visualize_visibility(
    color_bgr=...,
    K=...,
    T_c2w=...,
    depth=...,
    all_objects=...,
    current_detections=...,
    frame_id=...,
    output_dir=...,
    point_size=...,
    mask_alpha=...,
    max_points_per_obj=...,
    max_distance=...,
    state_results=None,  # NEW: optional list of {'obj_idx': int, 'state': str}
)
```

**`state_results` format:**
```python
[
    {'obj_idx': 0, 'state': 'persisting'},
    {'obj_idx': 1, 'state': 'occluded'},
    {'obj_idx': 2, 'state': 'disappeared'},
]
```

**Stats bar display:** When `state_results` is provided, the bottom stats bar shows:
```
Total objects: 5 | Visible: 2 (2 cats) | Detections: 6 | Live: [0] | Occluded: [1] | Miss: [2]
```

### Restructured Caller Pattern

**Critical**: State detection must run BEFORE visualization, and results must be mapped back to original object indices.

```python
# 1. Filter visible objects (extracted helper)
_visible_items, _vis_records = filter_visible_objects(
    all_objects=_merged_objects,
    K=K_frame,
    T_c2w=T_c2w,
    depth=depth,
    max_distance=_VIS_VIZ_CFG['max_distance'],
    min_visible_ratio=0.20,
)

# 2. Filter out structural categories for state detection
_STRUCTURAL_CATS = frozenset({'floor', 'wall', 'ceiling'})
_visible_non_structural = [
    obj for _, obj in _visible_items
    if obj.get('category', '') not in _STRUCTURAL_CATS
]

# 3. Run state detection on non-structural visible objects
_state_results_for_viz = None
if _VIS_VIZ_CFG.get('state_detection_enabled', False):
    _state_results = detect_object_states(
        merged_objects=_visible_non_structural,
        K=K_frame,
        T_w2c=np.linalg.inv(T_c2w),
        depth_map=depth,
        ...
    )
    
    # 4. Map state results back to original _merged_objects indices
    _visible_merged_indices = [
        idx for idx, _ in _visible_items
        if _merged_objects[idx].get('category', '') not in _STRUCTURAL_CATS
    ]
    _state_results_for_viz = []
    for _sf in _state_results:
        _vis_non_struct_idx = _sf['obj_idx']
        if _vis_non_struct_idx < len(_visible_merged_indices):
            _merged_obj_idx = _visible_merged_indices[_vis_non_struct_idx]
            _state_results_for_viz.append({
                'obj_idx': _merged_obj_idx,
                'state': _sf['state'].value,
            })

# 5. Call visualization with state results
_viz_path, _num_visible, _vis_records = visualize_visibility(
    ...,
    state_results=_state_results_for_viz,
)
```

### Index Mapping Challenge

**Problem**: `detect_object_states()` returns results indexed by position in `_visible_non_structural`, but `visualize_visibility()` expects `obj_idx` to match indices in `_merged_objects`.

**Solution**: Build a mapping array `_visible_merged_indices` that maps from non-structural position back to merged object index:

```python
# _visible_items = [(0, obj0), (3, obj3), (5, obj5), ...]  # indices in _merged_objects
# _visible_non_structural = [obj3, obj5, ...]  # filtered, re-indexed 0, 1, ...

# Mapping: position in _visible_non_structural → index in _merged_objects
_visible_merged_indices = [
    idx for idx, _ in _visible_items
    if _merged_objects[idx].get('category', '') not in _STRUCTURAL_CATS
]
# _visible_merged_indices = [3, 5, ...]

# When state_results has obj_idx=0 (first non-structural object),
# map to _merged_obj_idx = _visible_merged_indices[0] = 3
```

**Why this matters**: Without this mapping, state results would reference wrong objects in the visualization (off-by-one errors when structural objects are filtered).

### Utility Functions Retained in `object_visibility.py`

- `bbox_iou_2d()` — 2D bounding box IoU calculation
- `quaternion_to_rotation_matrix()` — Quaternion to rotation matrix conversion
- `load_intrinsics()` — Camera intrinsic matrix loading
- `load_pose_matrix()` — Camera pose matrix loading
- `load_depth_meters()` — Depth map loading with scale conversion

## Design Decision: Geometric Projection for Visualization

**Use simple geometric projection checks for visualization, not complex depth-based visibility reasoning.**

The previous `predict_object_visibility()` function performed depth-based evidence reasoning (checking if depth map "sees" the object). This was removed because:

1. **Dynamic objects move between frames** - A person detected in frame 00020 may have moved by frame 00022, so the depth map won't show them at the historical location
2. **Visualization goal is different** - We want to show "this object was visible here before" not "this object is confirmed present now"
3. **Complexity without benefit** - Depth evidence reasoning added computation but didn't improve visualization clarity

**Correct approach**: Use geometric projection checks (frustum culling + image bounds + visible ratio) to determine if a historical object *should be visible* in the current frame.

```python
# ✅ Correct: Simple geometric visibility check
_STRUCTURAL_CATS = {'floor', 'wall', 'ceiling'}
_MIN_VISIBLE_RATIO = 0.20

visible_items = []
for obj_idx, obj in enumerate(all_objects):
    pts = obj['points']
    if len(pts) == 0:
        continue
    cat = obj.get('category', '')
    if cat in _STRUCTURAL_CATS:
        continue
    
    # Project to camera space
    pts_hom = np.hstack([pts, np.ones((len(pts), 1))])
    pts_cam = (T_w2c @ pts_hom.T).T[:, :3]
    
    # Filter: in front of camera
    in_front = pts_cam[:, 2] > 0.1
    pts_in_front = pts_cam[in_front]
    if len(pts_in_front) == 0:
        continue
    
    # Project to image coordinates
    z = pts_in_front[:, 2]
    u = (pts_in_front[:, 0] * fx / z + cx).astype(np.int32)
    v = (pts_in_front[:, 1] * fy / z + cy).astype(np.int32)
    
    # Filter: within image bounds
    in_image = (u >= 0) & (u < w) & (v >= 0) & (v < h)
    visible_ratio = float(np.sum(in_image)) / len(pts)
    
    if visible_ratio < _MIN_VISIBLE_RATIO:
        continue
    
    visible_items.append((obj_idx, obj))

# Render loop (no vis variable needed)
for vis_idx, (obj_idx, obj) in enumerate(visible_items):
    # ... project and render points ...
    # Label: only object ID + category (no visibility state)
    label = f"#{obj_idx} {obj['category'][:8]}"
```

**Wrong approach**: Using `predict_object_visibility()` for visualization filtering:

```python
# ❌ Wrong: Depth-based visibility reasoning (for lifecycle management, not visualization)
vis = predict_object_visibility(obj, K, T_c2w, depth, image_shape)
if vis.get('visibility_state') != 'observed_by_depth':
    continue  # Dynamic objects will fail this check after moving
```

## Critical: Execution Order

**Merge → Visualize → Add current frame objects.**

```python
# ✅ Correct order
# 1. Collect current frame detections (for right panel)
current_frame_detections = [...]

# 2. Lightweight merge of historical objects (deduplicate same-object detections)
_merged_objects = merge_similar_objects(all_objects, centroid_distance=...)

# 3. Visualize (uses merged list; all_objects only contains historical objects)
visualize_visibility(all_objects=_merged_objects, ...)

# 4. Add current frame objects to history
all_objects.extend(new_objects)
```

**Wrong order** causes current frame objects to appear as "historical" in the left panel, making frame 0 show projections when it should be empty.

## Supplementing VLM Detections with Expected Visible Historical Objects

VLM may miss objects that are clearly visible. Use historical object point cloud reprojection to identify expected visible categories and add them to SAM3 segmentation prompts:

```python
# Before SAM3 batch segmentation, collect expected visible categories from history
expected_categories = set()
if len(all_objects) > 0:
    T_w2c = np.linalg.inv(T_c2w)
    fx, fy = K_frame[0, 0], K_frame[1, 1]
    cx, cy = K_frame[0, 2], K_frame[1, 2]
    h, w = depth.shape[:2]

    for hist_obj in all_objects:
        pts = hist_obj['points']
        if len(pts) == 0:
            continue
        cat = hist_obj.get('category', '')
        if cat in {'floor', 'wall', 'ceiling'}:
            continue

        # Fast reprojection to check visibility
        pts_hom = np.hstack([pts, np.ones((len(pts), 1))])
        pts_cam = (T_w2c @ pts_hom.T).T[:, :3]
        in_front = pts_cam[:, 2] > 0.1
        pts_in_front = pts_cam[in_front]
        if len(pts_in_front) == 0:
            continue
        z = pts_in_front[:, 2]
        u = (pts_in_front[:, 0] * fx / z + cx).astype(np.int32)
        v = (pts_in_front[:, 1] * fy / z + cy).astype(np.int32)
        in_image = (u >= 0) & (u < w) & (v >= 0) & (v < h)
        visible_ratio = float(np.sum(in_image)) / len(pts)

        if visible_ratio >= 0.20:  # At least 20% points visible
            expected_categories.add(cat)

# Add to SAM3 prompts (alongside VLM detections)
batch_prompts = [(cat, cat) for cat in vlm_categories]
for cat in expected_categories:
    if cat not in vlm_categories:
        batch_prompts.append((cat, cat))
        print(f"  + Supplementing historical category: {cat}")
```

**Why**: Prevents VLM false negatives from causing objects to disappear from tracking. If a chair was detected in previous frames and is clearly visible now (20%+ points in frame), it should be segmented even if VLM missed it.

## Filtering Layers

### 1. Exclude Structural Categories

```python
_STRUCTURAL_CATS = {'floor', 'wall', 'ceiling'}

for obj_idx, obj in enumerate(all_objects):
    cat = obj.get('category', '')
    if cat in _STRUCTURAL_CATS:
        continue  # Skip background structures
```

### 2. Geometric Visibility Check (No Depth Evidence)

```python
# Project points and check geometric visibility
pts_hom = np.hstack([pts, np.ones((len(pts), 1))])
pts_cam = (T_w2c @ pts_hom.T).T[:, :3]

# Filter: in front of camera (> 0.1m to avoid near-plane artifacts)
in_front = pts_cam[:, 2] > 0.1
pts_in_front = pts_cam[in_front]
if len(pts_in_front) == 0:
    continue

# Filter: distance culling (object center must be within max_distance)
obj_center_cam = pts_in_front.mean(axis=0)
obj_distance = np.linalg.norm(obj_center_cam)
if obj_distance > max_distance:  # default 6.0m, from config.yaml
    continue

# Project to image coordinates
z = pts_in_front[:, 2]
u = (pts_in_front[:, 0] * fx / z + cx).astype(np.int32)
v = (pts_in_front[:, 1] * fy / z + cy).astype(np.int32)

# Filter: within image bounds
in_image = (u >= 0) & (u < w) & (v >= 0) & (v < h)
visible_ratio = float(np.sum(in_image)) / len(pts)

if visible_ratio < _MIN_VISIBLE_RATIO:
    continue  # Skip objects with < 20% points in frame
```

**Why geometric only**: Dynamic objects (people, movable furniture) change position between frames. Depth-based checks would fail for these objects even when they should be visualized as "previously seen here."

### 3. Distance-Based Culling

Objects beyond `max_visible_distance` (default 6.0m, configurable in `config.yaml` under `visibility_viz.max_visible_distance`) are considered not visible in the current frame. This prevents distant objects from cluttering the visualization.

### 4. Point Cloud Visibility Ratio Threshold

```python
_MIN_VISIBLE_RATIO = 0.20  # At least 20% of points must be in image bounds
```

**Rationale**: Objects with very few points in the current frame are likely:
- Far away and not meaningfully visible
- Partially occluded by scene geometry
- Moving out of the field of view

20% threshold balances recall (showing relevant objects) vs precision (avoiding clutter).

## Performance Impact

The point cloud ratio check adds minimal overhead:
- Matrix multiplication: O(N) where N = points per object
- Projection and bounds check: O(N)
- Typical objects have 100-1000 points → microseconds per object

## Result

Before filtering: 301/419 objects visible (cluttered with floor/wall)
After filtering: ~50-100 objects (only meaningful foreground objects)

## Configuration

```python
# Tunable parameters
_STRUCTURAL_CATS = {'floor', 'wall', 'ceiling'}  # Categories to exclude
_MIN_VISIBLE_RATIO = 0.20  # Minimum fraction of points in image bounds (0.0-1.0)
```

## Rendering Loop Notes

After filtering, the rendering loop should:
- Use only `(obj_idx, obj)` tuples (no `vis` variable)
- Draw a **2D bounding box** around projected points for each object
- Place labels outside the bbox corner (not at centroid)
- Color points and bbox by object index for visual distinction

```python
for vis_idx, (obj_idx, obj) in enumerate(visible_items):
    pts_world = obj['points']
    # ... project to image, get u, v arrays ...

    bgr = obj_colors[vis_idx]
    r = point_size
    for ui, vi in zip(u, v):
        y0, y1 = max(0, vi - r), min(h, vi + r + 1)
        x0, x1 = max(0, ui - r), min(w, ui + r + 1)
        left[y0:y1, x0:x1] = bgr

    # 2D bounding box from projected points
    x_min, x_max = int(u.min()), int(u.max())
    y_min, y_max = int(v.min()), int(v.max())
    cv2.rectangle(left, (x_min, y_min), (x_max, y_max), bgr, 1)

    # Label outside bbox corner
    lx, ly = x_max + 4, y_min - 4
    label = f"#{obj_idx} {obj['category'][:8]}"
    cv2.putText(left, label, (lx, max(12, ly)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.35, bgr, 1, cv2.LINE_AA)
```

## Per-Frame Visibility Records (JSON)

The function saves structured visibility records alongside the PNG for lifecycle tracking. Return signature: `(out_path, visible_count, visibility_records)`.

### Record Format

```json
{
  "frame_id": "000123",
  "total_objects": 45,
  "visible_count": 12,
  "visible_objects": [
    {
      "obj_idx": 5,
      "category": "chair",
      "centroid_3d": [1.2, 0.5, 3.4],
      "distance": 3.62,
      "visible_ratio": 0.78,
      "point_count": 1250,
      "merged_from": [5, 12],
      "bbox_2d": [320, 180, 480, 360]
    }
  ]
}
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `obj_idx` | int | Index in the (merged) object list |
| `category` | str | Object category label |
| `centroid_3d` | [x,y,z] | 3D world centroid (from `_centroid` cache) |
| `distance` | float | Euclidean distance from camera to object center (metres) |
| `visible_ratio` | float | Fraction of total points that project into the image |
| `point_count` | int | Total number of 3D points |
| `merged_from` | [int] | Original object indices that were merged into this one |
| `bbox_2d` | [x1,y1,x2,y2] | 2D bounding box of projected points (pixels) |

### Output File

Saved as `visibility_records_{frame_id}.json` in the same output directory as the PNG.

### Caller Update

```python
_viz_path, _num_visible, _vis_records = visualize_visibility(...)
```

The `_vis_records` list can be aggregated across frames for lifecycle analysis (e.g. tracking when objects first appear, disappear, or are merged).
