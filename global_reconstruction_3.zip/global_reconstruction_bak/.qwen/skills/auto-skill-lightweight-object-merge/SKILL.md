---
name: lightweight-object-merge
description: Greedy merge of historical objects by category + 3D centroid distance with incremental centroid update and merge provenance tracking
source: auto-skill
extracted_at: '2026-07-02T10:37:29.893Z'
---

# Lightweight Object Merge for Reprojection Visualization

## Problem

During frame-by-frame detection, the same physical object can be detected in consecutive frames, creating multiple entries in `all_objects`. Before offline merging (which uses voxel fusion), these duplicates cause redundant overlapping projections in visibility visualization.

## Solution

A lightweight pre-merge step that runs **before** `visualize_visibility()`:
- Group objects by category
- Within each category, greedy cluster by **3D point cloud centroid distance**
- Merge clusters: concatenate point clouds, update centroid incrementally
- Structural categories (floor/wall/ceiling) pass through untouched

This is NOT the strict offline merge — it only deduplicates for cleaner visuals.

## Implementation

### Location

`global_reconstruction/incremental/object_merger.py`

### Key Functions

```python
def merge_similar_objects(
    objects: list[dict],
    centroid_distance: float = 0.5,  # metres
) -> list[dict]:
    """Greedy merge: same category + centroid within threshold → one cluster."""
    # 1. Group by category
    # 2. For each category (skip structural):
    #    - Iterate objects, find closest existing cluster
    #    - If distance < threshold: merge (vstack points, incremental centroid)
    #    - Else: start new cluster
    # 3. Return flat list of merged objects
```

### Incremental Centroid Update

Avoid recomputing centroid from all accumulated points each frame:

```python
def update_centroid_incremental(obj, new_points):
    """new_centroid = (old_centroid * N_old + new_centroid * N_new) / (N_old + N_new)"""
    old_centroid = obj['_centroid']
    old_n = obj['_point_count']
    new_centroid = new_points.mean(axis=0)
    total_n = old_n + len(new_points)
    obj['_centroid'] = (old_centroid * old_n + new_centroid * len(new_points)) / total_n
    obj['_point_count'] = total_n
```

### Centroid Cache Fields

Each object dict carries:
- `_centroid`: np.ndarray (3,) — cached 3D centroid
- `_point_count`: int — number of points used to compute the centroid

These are initialized when the object is first appended to `all_objects`:
```python
all_objects.append({
    ...
    '_centroid': object_center.copy(),  # = points_3d.mean(axis=0)
    '_point_count': len(points_3d),
})
```

## Why 3D Centroid (not bbox center)?

Bounding box center (`min + max / 2`) is highly sensitive to noise outliers — a single stray point can shift the bbox center far from the actual object. The 3D point cloud centroid (`mean(axis=0)`) is far more robust to outliers, making it a reliable distance metric for determining if two detections are the same physical object.

## Integration Point

In `reconstruct_and_segment.py`, before `visualize_visibility()`:

```python
_merged_objects = merge_similar_objects(
    all_objects,
    centroid_distance=_VIS_VIZ_CFG['merge_centroid_distance'],
)
visualize_visibility(all_objects=_merged_objects, ...)
```

The merge produces a **new list** — `all_objects` is not modified. The original list continues to accumulate detections normally.

## Configuration

```yaml
# config.yaml → object_segmentation.visibility_viz
merge_centroid_distance: 0.5  # metres; conservative to avoid merging distinct objects
```

## Key Design Decisions

1. **Greedy, not hierarchical** — O(n²) per category is fine for typical object counts (<100 per category)
2. **Point cloud concat, not voxel downsample** — keeps it lightweight; strict merge happens offline
3. **Cache on object dict** — `_centroid`/`_point_count` avoid recomputation; `_compute_centroid()` validates cache consistency
4. **Structural cats excluded** — floor/wall/ceiling are large and overlapping by nature; merging them would be incorrect

## Merge Provenance Tracking (`_merged_from`)

Every object returned by `merge_similar_objects()` carries a `_merged_from` field — a list of original indices that were merged into this object. This enables downstream code (e.g. visibility records, lifecycle tracking) to trace which original detections contributed to each merged result.

### Where it's set

| Case | `_merged_from` value |
|------|---------------------|
| Early return (≤1 object) | `[idx]` for each object |
| Structural category passthrough | `[idx]` per object |
| Single-member cluster | `[members[0]]` |
| Multi-member cluster | `list(members)` — all original indices |

```python
# Single member — identity
obj['_merged_from'] = [members[0]]

# Multi member — full provenance
cl['_merged_from'] = list(members)  # e.g. [5, 12, 23]
```

### Usage in visibility records

The visibility visualizer reads `_merged_from` to record which original objects contributed to each visible projection:

```python
merged_from = obj.get('_merged_from', [obj_idx])
visibility_records.append({
    'merged_from': [int(i) for i in merged_from],
    ...
})
```

This is essential for object lifecycle maintenance — knowing that merged object #5 came from detections at frames 12, 15, 18 allows reconstructing the full history.
