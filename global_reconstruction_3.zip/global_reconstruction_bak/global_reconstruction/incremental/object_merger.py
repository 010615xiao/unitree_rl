"""Lightweight object merging for visualization deduplication.

Greedy clustering by category + 3D centroid distance to reduce redundant
overlapping projections of the same physical object detected across
consecutive frames.  This is NOT the strict offline merge (which uses
voxel fusion); it only deduplicates for cleaner reprojection visuals.

Performance optimisations:
- Two-pass clustering: assignment (cheap centroid distance checks) is
  separated from data copying (single batched ``np.vstack`` per cluster).
- Cluster distance checks are vectorised with numpy broadcasting.
- Module-level result cache keyed by a lightweight fingerprint so
  unchanged object lists skip the merge entirely.
"""

from __future__ import annotations

from typing import Any

import numpy as np


# ================= Centroid Helpers =================

def _compute_centroid(obj: dict[str, Any]) -> tuple[np.ndarray, int]:
    """Return (centroid, point_count) for an object.

    Uses cached values if present and consistent, otherwise computes from
    the full point array and caches the result on the object dict.
    """
    cached = obj.get('_centroid')
    cached_n = obj.get('_point_count')
    pts = obj['points']
    n = len(pts)

    if cached is not None and cached_n == n:
        return cached, cached_n

    centroid = pts.mean(axis=0) if n > 0 else np.zeros(3)
    obj['_centroid'] = centroid
    obj['_point_count'] = n
    return centroid, n


def update_centroid_incremental(
    obj: dict[str, Any],
    new_points: np.ndarray,
) -> None:
    """Update an object's cached centroid after appending new points.

    Uses the incremental formula:
        new_centroid = (old_centroid * N_old + new_centroid * N_new) / (N_old + N_new)

    Call this right after ``obj['points'] = np.vstack([obj['points'], new_points])``.

    Args:
        obj: Object dict (must already contain updated 'points')
        new_points: The newly appended points (M, 3)
    """
    n_new = len(new_points)
    if n_new == 0:
        return

    old_centroid = obj.get('_centroid')
    old_n = obj.get('_point_count', 0)

    if old_centroid is None or old_n == 0:
        obj['_centroid'] = obj['points'].mean(axis=0)
        obj['_point_count'] = len(obj['points'])
        return

    new_centroid = new_points.mean(axis=0)
    total_n = old_n + n_new
    obj['_centroid'] = (old_centroid * old_n + new_centroid * n_new) / total_n
    obj['_point_count'] = total_n


# ================= Merge Result Cache =================

_merge_cache: dict[int, tuple[list[dict[str, Any]], int]] = {}


def _fingerprint(objects: list[dict[str, Any]]) -> int:
    """Cheap hash identifying the current object list state.

    Uses ``id()`` of each dict + its point count so that appending new
    points to an existing object invalidates the cache.
    """
    return hash((len(objects), tuple(
        (id(obj), len(obj.get('points', ()))) for obj in objects
    )))


def invalidate_merge_cache() -> None:
    """Clear the module-level merge result cache."""
    _merge_cache.clear()


# ================= Merge Logic =================

_STRUCTURAL_CATS = {'floor', 'wall', 'ceiling'}


def merge_similar_objects(
    objects: list[dict[str, Any]],
    centroid_distance: float = 0.5,
) -> list[dict[str, Any]]:
    """Greedy merge of objects with same category and close 3D centroids.

    Two-pass algorithm:
      1. **Assign** — for each category, greedily assign objects to
         clusters using vectorised centroid distance checks (no copies).
      2. **Build** — for each cluster, batch ``np.vstack`` all member
         point arrays in one shot and compute the merged centroid.

    Structural categories (floor/wall/ceiling) pass through unchanged.

    Results are cached by a lightweight fingerprint of the input list;
    if the list hasn't changed since the last call the cached result is
    returned immediately.

    Args:
        objects: List of object dicts (each has 'points', 'category')
        centroid_distance: Max Euclidean distance (metres) between 3D
            centroids for two objects to be considered the same

    Returns:
        New list with duplicates merged.  Original list is not modified.
    """
    if len(objects) <= 1:
        for idx, obj in enumerate(objects):
            obj['_merged_from'] = [idx]
        return list(objects)

    # ---- Cache check ----
    fp = _fingerprint(objects)
    cached = _merge_cache.get(fp)
    if cached is not None:
        return cached[0]

    # ---- Group indices by category ----
    by_cat: dict[str, list[int]] = {}
    for idx, obj in enumerate(objects):
        cat = obj.get('category', '')
        by_cat.setdefault(cat, []).append(idx)

    merged: list[dict[str, Any]] = []

    for cat, indices in by_cat.items():
        # Structural cats pass through untouched
        if cat in _STRUCTURAL_CATS:
            for idx in indices:
                objects[idx]['_merged_from'] = [idx]
                merged.append(objects[idx])
            continue

        # --- Pass 1: assign objects to clusters (no data copies) ---
        # cluster_members[i] = list of object indices in cluster i
        # cluster_centroids[i] = centroid of cluster i (updated lazily)
        cluster_members: list[list[int]] = []
        cluster_centroids: list[np.ndarray] = []
        dist_sq_thr = centroid_distance * centroid_distance

        for idx in indices:
            obj = objects[idx]
            centroid, _ = _compute_centroid(obj)

            best_ci = -1
            best_dist_sq = float('inf')

            if cluster_centroids:
                # Vectorised distance to all existing cluster centroids
                centroids_arr = np.array(cluster_centroids)  # (C, 3)
                diffs = centroids_arr - centroid             # (C, 3)
                dists_sq = np.einsum('ij,ij->i', diffs, diffs)  # (C,)
                best_ci = int(np.argmin(dists_sq))
                best_dist_sq = float(dists_sq[best_ci])

            if best_dist_sq < dist_sq_thr and best_ci >= 0:
                cluster_members[best_ci].append(idx)
                # Update cluster centroid incrementally (weighted avg)
                old_n = sum(len(objects[mi]['points'])
                            for mi in cluster_members[best_ci][:-1])
                new_n = len(obj['points'])
                total_n = old_n + new_n
                cluster_centroids[best_ci] = (
                    cluster_centroids[best_ci] * old_n
                    + centroid * new_n
                ) / total_n
            else:
                cluster_members.append([idx])
                cluster_centroids.append(centroid.copy())

        # --- Pass 2: build merged objects (single batched vstack each) ---
        for members in cluster_members:
            if len(members) == 1:
                obj = objects[members[0]]
                obj['_merged_from'] = [members[0]]
                merged.append(obj)
                continue

            # Batch vstack all member points
            all_pts = np.vstack([objects[mi]['points'] for mi in members])
            # Shallow-copy the first member as the cluster representative
            cl = dict(objects[members[0]])
            cl['points'] = all_pts
            cl['_centroid'] = all_pts.mean(axis=0)
            cl['_point_count'] = len(all_pts)
            cl['_merged_from'] = list(members)
            # Merge source_views if present
            for mi in members[1:]:
                sv = objects[mi].get('source_views')
                if sv:
                    cl.setdefault('source_views', []).extend(sv)
            merged.append(cl)

    # ---- Store in cache ----
    _merge_cache[fp] = (merged, fp)

    return merged
