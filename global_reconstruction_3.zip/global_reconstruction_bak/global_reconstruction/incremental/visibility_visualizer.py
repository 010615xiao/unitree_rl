"""Visibility detection and reprojection visualization for historical objects.

This module handles:
- Geometric projection-based visibility filtering
- Distance-based visibility culling
- Side-by-side visualization of historical objects vs current detections
- Per-frame structured visibility records (JSON) for lifecycle tracking
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np


# ================= Config Loading =================

def load_visibility_viz_config(cfg: dict[str, Any]) -> dict[str, Any]:
    """Load visibility visualization config from the main config dict.

    Args:
        cfg: Full config dict (from config.yaml)

    Returns:
        Dict with visibility viz parameters
    """
    viz_cfg = dict(cfg.get('object_segmentation', {}).get('visibility_viz', {}) or {})
    return {
        'enabled': bool(viz_cfg.get('enabled', False)),
        'point_size': int(viz_cfg.get('projected_point_size', 3)),
        'mask_alpha': float(viz_cfg.get('mask_alpha', 0.45)),
        'max_points_per_obj': int(viz_cfg.get('max_points_per_object', 8000)),
        'max_distance': float(viz_cfg.get('max_visible_distance', 6.0)),
        'merge_centroid_distance': float(viz_cfg.get('merge_centroid_distance', 0.5)),
        # State detection
        'state_detection_enabled': bool(viz_cfg.get('state_detection_enabled', False)),
        'depth_tolerance': float(viz_cfg.get('depth_tolerance', 0.15)),
        'min_valid_samples': int(viz_cfg.get('min_valid_samples', 20)),
        'persist_ratio_threshold': float(viz_cfg.get('persist_ratio_threshold', 0.5)),
        'valid_ratio_threshold': float(viz_cfg.get('valid_ratio_threshold', 0.5)),
        'miss_death_threshold': int(viz_cfg.get('miss_death_threshold', 5)),
    }


# ================= Helper Functions =================

def _generate_distinct_colors(n: int):
    """Generate n visually distinct BGR colors using golden-angle HSV spacing."""
    if n == 0:
        return []
    colors = []
    golden_angle = 137.508
    for i in range(n):
        hue = (i * golden_angle) % 360
        hsv = np.uint8([[[int(hue / 2), 200, 230]]])
        bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)[0, 0]
        colors.append((int(bgr[0]), int(bgr[1]), int(bgr[2])))
    return colors


# ================= Visibility Filtering =================

def filter_visible_objects(
    all_objects: list,
    K: np.ndarray,
    T_c2w: np.ndarray,
    depth: np.ndarray,
    max_distance: float = 6.0,
    min_visible_ratio: float = 0.20,
):
    """Filter objects by geometric projection visibility.

    Returns:
        visible_items: list of (obj_idx, obj) tuples for visible objects
        visibility_records: list of per-object visibility records
        
    Note:
        obj_idx 是 all_objects 列表的索引，用于数组访问。
        稳定 ID 存储在 visibility_records 的 'stable_id' 字段中。
    """
    h, w = depth.shape[:2]
    T_w2c = np.linalg.inv(T_c2w)
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    _STRUCTURAL_CATS = {'floor', 'wall', 'ceiling'}
    visible_items = []
    visibility_records = []

    for obj_idx, obj in enumerate(all_objects):
        pts = obj['points']
        if len(pts) == 0:
            continue

        cat = obj.get('category', '')
        if cat in _STRUCTURAL_CATS:
            continue

        pts_hom = np.hstack([pts, np.ones((len(pts), 1))])
        pts_cam = (T_w2c @ pts_hom.T).T[:, :3]
        in_front = pts_cam[:, 2] > 0.1
        pts_in_front = pts_cam[in_front]
        if len(pts_in_front) == 0:
            continue

        obj_center_cam = pts_in_front.mean(axis=0)
        obj_distance = float(np.linalg.norm(obj_center_cam))
        if obj_distance > max_distance:
            continue

        z = pts_in_front[:, 2]
        u = (pts_in_front[:, 0] * fx / z + cx).astype(np.int32)
        v = (pts_in_front[:, 1] * fy / z + cy).astype(np.int32)
        in_image = (u >= 0) & (u < w) & (v >= 0) & (v < h)
        visible_ratio = float(np.sum(in_image)) / len(pts)
        if visible_ratio < min_visible_ratio:
            continue

        visible_items.append((obj_idx, obj))

        # 计算稳定 ID：使用 _merged_from 中的最小索引
        # 这确保同一物体在不同帧的合并结果中编号一致
        merged_from = obj.get('_merged_from', [obj_idx])
        stable_id = min(merged_from) if merged_from else obj_idx
        
        centroid_world = obj.get('_centroid', pts.mean(axis=0))
        visibility_records.append({
            'obj_idx': int(obj_idx),      # 数组索引，用于访问
            'stable_id': int(stable_id),  # 稳定 ID，用于显示
            'category': cat,
            'centroid_3d': centroid_world.tolist(),
            'distance': obj_distance,
            'visible_ratio': round(visible_ratio, 4),
            'point_count': int(len(pts)),
            'merged_from': [int(i) for i in merged_from],
        })

    return visible_items, visibility_records


# ================= Main Visualization =================

def visualize_visibility(
    color_bgr: np.ndarray,
    K: np.ndarray,
    T_c2w: np.ndarray,
    depth: np.ndarray,
    all_objects: list,
    current_detections: list,
    frame_id: str,
    output_dir: Path,
    point_size: int = 3,
    mask_alpha: float = 0.45,
    max_points_per_obj: int = 8000,
    max_distance: float = 6.0,
    state_results: list | None = None,
):
    """左侧=当前帧应可见的历史物体反投影，右侧=当前帧检测掩码。

    左侧通过几何投影过滤物体（中心在相机前方、投影落在图像范围内、距离不超过阈值）。

    Args:
        color_bgr: 当前帧 BGR 图像 (H,W,3)
        K: 3x3 内参矩阵
        T_c2w: 4x4 相机到世界坐标变换
        depth: 当前帧深度图 (H,W) float32, 单位米
        all_objects: 已累积的所有物体列表 (含 'points', 'category')
        current_detections: 当前帧检测结果列表 (含 'mask', 'category', 'score')
        frame_id: 帧标识符
        output_dir: 输出目录
        point_size: 投影点正方形填充的半边长 (像素)
        mask_alpha: 掩码叠加透明度
        max_points_per_obj: 每个物体最大投影点数 (随机采样)
        max_distance: 物体距相机最大可见距离 (米)，超过视为不可见
        state_results: 可选，状态检测结果列表 (含 'obj_idx', 'state')，用于在统计栏显示 live/occluded/miss 物体
    """
    h, w = color_bgr.shape[:2]
    T_w2c = np.linalg.inv(T_c2w)
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    # ---- 可见性过滤：只保留当前帧应可见的物体 ----
    _MIN_VISIBLE_RATIO = 0.20  # 物体至少 20% 的点云在当前帧可见才投影
    visible_items, visibility_records = filter_visible_objects(
        all_objects=all_objects,
        K=K,
        T_c2w=T_c2w,
        depth=depth,
        max_distance=max_distance,
        min_visible_ratio=_MIN_VISIBLE_RATIO,
    )

    # ---- 左侧：可见历史物体反投影 ----
    left = color_bgr.copy()

    if len(visible_items) > 0:
        obj_colors = _generate_distinct_colors(len(visible_items))

        for vis_idx, (obj_idx, obj) in enumerate(visible_items):
            pts_world = obj['points']
            if len(pts_world) > max_points_per_obj:
                indices = np.random.choice(len(pts_world), max_points_per_obj, replace=False)
                pts_world = pts_world[indices]

            # 世界 → 相机
            pts_hom = np.hstack([pts_world, np.ones((len(pts_world), 1))])
            pts_cam = (T_w2c @ pts_hom.T).T[:, :3]

            # 过滤相机后方
            in_front = pts_cam[:, 2] > 0.1
            pts_cam = pts_cam[in_front]
            if len(pts_cam) == 0:
                continue

            # 投影到图像
            z_cam = pts_cam[:, 2]
            u = (pts_cam[:, 0] * fx / z_cam + cx).astype(np.int32)
            v = (pts_cam[:, 1] * fy / z_cam + cy).astype(np.int32)

            # 过滤图像范围外
            valid = (u >= 0) & (u < w) & (v >= 0) & (v < h)
            u, v = u[valid], v[valid]
            if len(u) == 0:
                continue

            bgr = obj_colors[vis_idx]
            r = point_size
            for ui, vi in zip(u, v):
                y0, y1 = max(0, vi - r), min(h, vi + r + 1)
                x0, x1 = max(0, ui - r), min(w, ui + r + 1)
                left[y0:y1, x0:x1] = bgr

            # 2D 边界框：从投影点计算
            x_min, x_max = int(u.min()), int(u.max())
            y_min, y_max = int(v.min()), int(v.max())
            cv2.rectangle(left, (x_min, y_min), (x_max, y_max), bgr, 1)

            # 将 bbox 写入可见性记录
            if vis_idx < len(visibility_records):
                visibility_records[vis_idx]['bbox_2d'] = [x_min, y_min, x_max, y_max]

            # 标签：物体稳定 ID + 类别
            # 使用 stable_id 确保同一物体在不同帧中编号一致
            stable_id = visibility_records[vis_idx].get('stable_id', obj_idx) if vis_idx < len(visibility_records) else obj_idx
            lx, ly = x_max + 4, y_min - 4
            label = f"#{stable_id} {obj['category'][:8]}"
            cv2.putText(left, label, (lx, max(12, ly)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, bgr, 1, cv2.LINE_AA)

    # ---- 右侧：当前帧检测掩码 ----
    right = color_bgr.copy()

    if len(current_detections) > 0:
        det_colors = _generate_distinct_colors(len(current_detections))

        for det_idx, det in enumerate(current_detections):
            mask = det['mask']
            if mask is None:
                continue

            if mask.shape[:2] != (h, w):
                mask = cv2.resize(mask.astype(np.float32), (w, h),
                                  interpolation=cv2.INTER_NEAREST)
            mask_bool = mask > 128

            bgr = det_colors[det_idx]
            color_layer = np.zeros_like(right)
            color_layer[mask_bool] = bgr
            right[mask_bool] = (
                right[mask_bool].astype(np.float32) * (1.0 - mask_alpha)
                + color_layer[mask_bool].astype(np.float32) * mask_alpha
            ).astype(np.uint8)

            mask_uint8 = mask_bool.astype(np.uint8) * 255
            contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(right, contours, -1, bgr, 2)

            ys, xs = np.where(mask_bool)
            if len(xs) > 0:
                cx_det, cy_det = int(xs.mean()), int(ys.mean())
                score = det.get('score', 0)
                label = f"#{det_idx} {det['category'][:8]} ({score:.2f})"
                cv2.putText(right, label, (cx_det + 4, cy_det - 4),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.35, bgr, 1, cv2.LINE_AA)

    # ---- 合并左右 + 标注 ----
    separator = np.ones((h, 2, 3), dtype=np.uint8) * 128
    combined = np.hstack([left, separator, right])

    # 顶部标题栏
    bar_h = 28
    bar = np.ones((bar_h, combined.shape[1], 3), dtype=np.uint8) * 40
    cv2.putText(bar, f"Frame: {frame_id}", (8, 19),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
    left_title_x = w // 2 - 140
    cv2.putText(bar, f"Visible History ({len(visible_items)}/{len(all_objects)})", (left_title_x, 19),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (100, 220, 255), 1, cv2.LINE_AA)
    right_title_x = w + 2 + w // 2 - 80
    cv2.putText(bar, f"Current Detections ({len(current_detections)})", (right_title_x, 19),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (100, 255, 150), 1, cv2.LINE_AA)

    combined = np.vstack([bar, combined])

    # 底部统计栏
    stats_h = 22
    stats_bar = np.ones((stats_h, combined.shape[1], 3), dtype=np.uint8) * 40
    visible_cats = set(obj['category'] for _, obj in visible_items)
    stats_text = (f"Total objects: {len(all_objects)} | "
                  f"Visible: {len(visible_items)} ({len(visible_cats)} cats) | "
                  f"Detections: {len(current_detections)}")
    
    # 添加状态信息 (live/occluded/miss)，包含物体 ID 和类别名
    if state_results is not None and len(state_results) > 0:
        persisting_items = []
        occluded_items = []
        disappeared_items = []
        for result in state_results:
            obj_idx = result.get('obj_idx')
            state = result.get('state', '')
            # 从 all_objects 获取类别名
            category = all_objects[obj_idx]['category'] if obj_idx < len(all_objects) else '?'
            # 查找对应的 stable_id（从 visibility_records 中）
            stable_id = obj_idx  # 默认使用 obj_idx
            for record in visibility_records:
                if record.get('obj_idx') == obj_idx:
                    stable_id = record.get('stable_id', obj_idx)
                    break
            item_str = f"#{stable_id} {category}"
            if state == 'persisting':
                persisting_items.append(item_str)
            elif state == 'occluded':
                occluded_items.append(item_str)
            elif state == 'disappeared':
                disappeared_items.append(item_str)

        state_parts = []
        if persisting_items:
            state_parts.append(f"Live: [{', '.join(persisting_items)}]")
        if occluded_items:
            state_parts.append(f"Occluded: [{', '.join(occluded_items)}]")
        if disappeared_items:
            state_parts.append(f"Miss: [{', '.join(disappeared_items)}]")

        if state_parts:
            stats_text += " | " + " | ".join(state_parts)
    
    cv2.putText(stats_bar, stats_text, (8, 16),
                cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1, cv2.LINE_AA)
    combined = np.vstack([combined, stats_bar])

    # 保存
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / f"visibility_viz_{frame_id}.png"
    cv2.imwrite(str(out_path), combined)

    # 保存可见性记录 JSON
    record_path = output_dir / f"visibility_records_{frame_id}.json"
    frame_record = {
        'frame_id': frame_id,
        'total_objects': len(all_objects),
        'visible_count': len(visible_items),
        'visible_objects': visibility_records,
    }
    with open(record_path, 'w', encoding='utf-8') as f:
        json.dump(frame_record, f, ensure_ascii=False, indent=2)

    return out_path, len(visible_items), visibility_records
