#!/usr/bin/env python3
"""
HTML可视化 - 分层场景图

用法:
    python visualize_graph_html.py [graph_path] [--negate-y]

输出:
    <graph_path>/visualization.html
"""

import os
import sys
import json
import glob
import base64
import io
import numpy as np
import open3d as o3d
from collections import defaultdict
from PIL import Image

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ================== 参数配置 ==================
MAX_ROOM_POINTS = 2000
MAX_OBJECT_POINTS = 1500
ROOM_VOXEL_SIZE = 0.2
OBJECT_VOXEL_SIZE = 0.03
COORD_DECIMALS = 3

EXCLUDE_KEYWORDS = {
    "wall", "floor", "ceiling", "paneling", "banner", "overhang",
    "divider", "ledge", "pillar", "tape", "stairs", "door", "doors",
    "stair", "window", "glass", "railing", "glass doors", "whiteboard",
    "sliding door", "carpet", "picture",
}
# ==============================================


HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>分层场景图 - 交互式3D可视化</title>
<style>
/* ===== 主题变量 ===== */
:root{
  --bg-body:#0f0f1a;--bg-panel:#141425;--bg-panel2:#1a1a3e;
  --bg-hover:#1e1e3e;--bg-active:#2a1a3e;
  --bg-overlay:rgba(20,20,37,.92);--bg-input:#1a1a3e;
  --border:#2a2a4a;--text:#e0e0e0;--text-dim:#888;--text-muted:#555;
  --accent:#ff6b9d;--accent-soft:rgba(255,107,157,.15);
  --accent-hover:#ff8ab5;--accent-glow:#ff6b9d;
  --scene-bg:#0f0f1a;--grid-main:#1a1a3e;--grid-sub:#111128;
  --shadow:rgba(0,0,0,.4);--label-obj-bg:rgba(80,80,100,.7);
  --label-obj-border:rgba(255,255,255,.15);
}
[data-theme="light"]{
  --bg-body:#d0d4da;--bg-panel:#e8eaee;--bg-panel2:#dde0e6;
  --bg-hover:#d0d4dc;--bg-active:#c8cce0;
  --bg-overlay:rgba(220,224,230,.94);--bg-input:#dde0e6;
  --border:#b8bcc8;--text:#1a1a2e;--text-dim:#556;--text-muted:#889;
  --accent:#c03860;--accent-soft:rgba(192,56,96,.12);
  --accent-hover:#d04870;--accent-glow:#c03860;
  --scene-bg:#c8ccd2;--grid-main:#b0b4c0;--grid-sub:#bcc0cc;
  --shadow:rgba(0,0,0,.08);--label-obj-bg:rgba(50,50,70,.85);
  --label-obj-border:rgba(255,255,255,.2);
}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg-body);color:var(--text);overflow:hidden;height:100vh;transition:background .4s,color .4s}
#sidebar{position:absolute;top:0;left:0;width:280px;bottom:0;background:var(--bg-panel);border-right:1px solid var(--border);overflow-y:auto;z-index:10;transition:transform .3s,background .4s}
#sidebar.collapsed{transform:translateX(-280px)}
#sidebar-hdr{padding:12px 14px;background:linear-gradient(135deg,var(--bg-panel2),var(--bg-panel));position:sticky;top:0;z-index:1;border-bottom:1px solid var(--border)}
#sidebar-hdr h2{font-size:15px;color:var(--accent);display:flex;align-items:center;gap:8px}
#sidebar-hdr .hdr-btns{display:flex;gap:6px;margin-top:8px}
#sidebar-hdr .hdr-btns button{flex:1;padding:4px 0;font-size:11px;background:var(--bg-input);border:1px solid var(--border);color:var(--text-dim);border-radius:4px;cursor:pointer;transition:all .2s}
#sidebar-hdr .hdr-btns button:hover{background:var(--bg-hover);color:var(--text)}
#search-box{padding:8px 12px;position:sticky;top:52px;z-index:1;background:var(--bg-panel);border-bottom:1px solid var(--border)}
#search-box input{width:100%;padding:6px 10px 6px 28px;background:var(--bg-input);border:1px solid var(--border);color:var(--text);border-radius:6px;font-size:12px;outline:none;transition:border-color .2s}
#search-box input:focus{border-color:var(--accent)}
#search-box input::placeholder{color:var(--text-muted)}
#search-icon{position:absolute;left:20px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:12px;pointer-events:none}
#tree{padding:4px 0}
.tree-item{padding:6px 12px;cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:6px;font-size:13px;border-left:3px solid transparent;color:var(--text)}
.tree-item:hover{background:var(--bg-hover);border-left-color:var(--accent)}
.tree-item.active{background:var(--bg-active);border-left-color:var(--accent)}
.tree-item .arrow{width:16px;text-align:center;flex-shrink:0;font-size:10px;transition:transform .2s;color:var(--text-muted);user-select:none}
.tree-item .arrow.expanded{transform:rotate(90deg)}
.tree-item .arrow.hidden-arrow{visibility:hidden}
.tree-item .icon{width:16px;text-align:center;flex-shrink:0}
.tree-item .name{flex:1;white-space:nowrap;overflow:hidden;overflow-ellipsis}
.tree-item .badge{font-size:10px;background:var(--bg-panel2);color:var(--text-dim);padding:1px 6px;border-radius:8px}
.tree-item.hidden{display:none}
.tree-children{padding-left:16px;overflow:hidden;transition:max-height .25s ease}
.tree-children.collapsed{max-height:0!important;overflow:hidden}
.floor-item .icon{color:#ffa500}
.room-item .icon{color:#4dabf7}
.object-item .icon{color:var(--accent)}
#toggle-sidebar{position:absolute;top:14px;left:280px;z-index:11;background:var(--bg-panel);border:1px solid var(--border);border-left:none;color:var(--text-dim);width:28px;height:28px;cursor:pointer;border-radius:0 6px 6px 0;display:flex;align-items:center;justify-content:center;font-size:14px;transition:left .3s,background .4s}
#toggle-sidebar.shifted{left:0}
#canvas-container{position:absolute;top:0;left:280px;right:0;bottom:0;transition:left .3s}
#canvas-container.expanded{left:0}
#controls{position:absolute;top:12px;right:12px;z-index:10;background:var(--bg-overlay);border-radius:10px;border:1px solid var(--border);backdrop-filter:blur(12px);transition:background .4s;overflow:hidden;width:160px}
#controls.collapsed{width:auto;border-radius:8px}
#ctrl-toggle{position:absolute;top:6px;right:6px;width:26px;height:26px;background:none;border:1px solid var(--border);color:var(--text-dim);border-radius:6px;cursor:pointer;font-size:13px;display:flex;align-items:center;justify-content:center;z-index:2;transition:all .2s}
#ctrl-toggle:hover{background:var(--bg-hover);color:var(--text)}
#ctrl-body{padding:14px 14px 10px;transition:opacity .25s,max-height .3s}
#controls.collapsed #ctrl-body{max-height:0;opacity:0;padding:0 14px;overflow:hidden;pointer-events:none}
#ctrl-mini{display:none;cursor:pointer;padding:8px 10px;font-size:16px;text-align:center;color:var(--text-dim)}
#ctrl-mini:hover{color:var(--accent)}
#controls.collapsed #ctrl-mini{display:block}
#controls h3{font-size:11px;color:var(--accent);margin-bottom:10px;text-transform:uppercase;letter-spacing:1.5px;font-weight:600}
.ctrl-row{display:flex;align-items:center;gap:6px;margin-bottom:5px;font-size:11px;color:var(--text)}
.ctrl-row label{flex:1;cursor:pointer;user-select:none}
.ctrl-row input[type=checkbox]{accent-color:var(--accent);width:13px;height:13px}
.ctrl-divider{height:1px;background:var(--border);margin:7px 0}
.ctrl-btn{width:100%;padding:5px 0;font-size:11px;background:var(--bg-input);border:1px solid var(--border);color:var(--text-dim);border-radius:5px;cursor:pointer;transition:all .2s;margin-bottom:3px}
.ctrl-btn:hover{background:var(--bg-hover);color:var(--text);border-color:var(--accent)}
.ctrl-btn.active{background:var(--accent-soft);color:var(--accent);border-color:var(--accent)}
#info-panel{position:absolute;top:12px;right:12px;z-index:15;width:250px;background:var(--bg-overlay);border-radius:12px;border:1px solid var(--border);backdrop-filter:blur(12px);transform:translateX(300px);transition:transform .35s cubic-bezier(.4,0,.2,1),background .4s;overflow:hidden}
#info-panel.show{transform:translateX(0)}
#info-panel .ip-hdr{padding:12px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px}
#info-panel .ip-hdr .color-dot{width:12px;height:12px;border-radius:50%;flex-shrink:0}
#info-panel .ip-hdr .ip-name{flex:1;font-weight:600;font-size:14px;color:var(--text)}
#info-panel .ip-hdr .ip-close{width:24px;height:24px;background:none;border:none;color:var(--text-dim);cursor:pointer;font-size:16px;border-radius:4px;display:flex;align-items:center;justify-content:center}
#info-panel .ip-hdr .ip-close:hover{background:var(--bg-hover);color:var(--text)}
#info-panel .ip-body{padding:12px 14px}
.ip-row{display:flex;justify-content:space-between;font-size:12px;margin-bottom:6px;color:var(--text-dim)}
.ip-row .ip-val{color:var(--text);font-weight:500}
.ip-row .ip-val.dim{font-size:11px;color:var(--text-muted)}
#info-panel .ip-focus{margin:8px 14px 12px;padding:7px 0;text-align:center;background:var(--accent);color:#fff;border:none;border-radius:6px;font-size:12px;cursor:pointer;font-weight:600;transition:opacity .2s}
#info-panel .ip-focus:hover{opacity:.85}
#help-hint{position:absolute;bottom:36px;left:50%;transform:translateX(-50%);z-index:10;background:var(--bg-overlay);border:1px solid var(--border);border-radius:8px;padding:8px 18px;font-size:11px;color:var(--text-dim);backdrop-filter:blur(8px);white-space:nowrap;transition:opacity 1s;pointer-events:none}
#help-hint kbd{background:var(--bg-panel2);padding:1px 5px;border-radius:3px;color:var(--text-dim);font-family:inherit;margin:0 2px}
#tooltip{position:absolute;pointer-events:none;z-index:100;background:var(--bg-overlay);border:1px solid var(--accent);border-radius:8px;padding:8px 14px;display:none;backdrop-filter:blur(8px);box-shadow:0 4px 20px var(--accent-soft)}
#tooltip .t-name{font-weight:600;color:var(--accent);font-size:14px;display:flex;align-items:center;gap:6px}
#tooltip .t-color{display:inline-block;width:10px;height:10px;border-radius:50%}
#tooltip .t-room{font-size:11px;color:var(--text-dim);margin-top:2px}
#statusbar{position:absolute;bottom:0;left:280px;right:0;height:26px;background:var(--bg-panel);display:flex;align-items:center;padding:0 14px;font-size:11px;color:var(--text-muted);gap:18px;z-index:10;transition:left .3s,background .4s;border-top:1px solid var(--border)}
#statusbar.expanded{left:0}
#loading{position:fixed;top:0;left:0;right:0;bottom:0;background:var(--bg-body);display:flex;align-items:center;justify-content:center;z-index:9999;flex-direction:column;gap:16px;transition:background .4s}
#loading .spinner{width:44px;height:44px;border:3px solid var(--border);border-top-color:var(--accent);border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
#loading .load-text{color:var(--text-muted);font-size:13px}
.label-2d{color:#fff;font-size:11px;padding:2px 8px;border-radius:4px;white-space:nowrap;pointer-events:none;font-family:'Segoe UI',sans-serif;text-shadow:0 1px 3px rgba(0,0,0,.5);transition:opacity .2s}
.label-2d.floor-label{background:rgba(255,165,0,.75);font-size:13px;font-weight:600}
.label-2d.room-label{background:rgba(77,171,247,.7);font-size:12px}
.label-2d.object-label{background:var(--label-obj-bg);font-size:10px;border:1px solid var(--label-obj-border)}
[data-theme="light"] .label-2d{color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.4)}
[data-theme="light"] .label-2d.floor-label{background:rgba(200,120,0,.85);color:#fff}
[data-theme="light"] .label-2d.room-label{background:rgba(40,120,200,.8);color:#fff}
[data-theme="light"] .label-2d.object-label{background:rgba(50,50,70,.85);color:#eee;border:1px solid rgba(255,255,255,.15)}
#views-panel{position:absolute;bottom:60px;right:20px;width:340px;
  background:var(--panel);border:1px solid var(--border);border-radius:8px;
  padding:12px;display:none;flex-direction:column;overflow:hidden;z-index:100}
#views-panel .vp-title{font-weight:600;font-size:14px;margin-bottom:8px;
  display:flex;justify-content:space-between;align-items:center;cursor:move;user-select:none}
#views-panel .vp-close{cursor:pointer;background:none;border:none;color:var(--text);
  font-size:18px;line-height:1;padding:0 4px}
#views-panel .vp-close:hover{color:#f44}
#views-panel .vp-img-wrap{height:360px;overflow-y:auto;display:flex;flex-direction:column;gap:8px}
#views-panel .vp-img-wrap img{width:100%;border-radius:4px;background:#1a1a2e;flex-shrink:0}
#views-panel .vp-counter{font-size:11px;color:var(--text-dim);font-weight:400}
</style>
</head>
<body>
<div id="loading"><div class="spinner"></div><div class="load-text">加载场景数据...</div></div>
<div id="sidebar">
  <div id="sidebar-hdr">
    <h2><span>🏗️</span> 场景图</h2>
    <div class="hdr-btns">
      <button id="btn-expand-all">📂 展开全部</button>
      <button id="btn-collapse-all">📁 折叠全部</button>
    </div>
  </div>
  <div id="search-box">
    <span id="search-icon">🔍</span>
    <input type="text" id="search-input" placeholder="搜索物体/房间...">
  </div>
  <div id="tree"></div>
</div>
<button id="toggle-sidebar">◀</button>
<div id="canvas-container"></div>
<div id="controls">
  <button id="ctrl-toggle" title="折叠面板">✕</button>
  <div id="ctrl-mini" title="展开控制面板">⚙️</div>
  <div id="ctrl-body">
    <h3>⚙️ 显示控制</h3>
    <div class="ctrl-row"><input type="checkbox" id="chk-labels" checked><label for="chk-labels">物体标签</label></div>
    <div class="ctrl-row"><input type="checkbox" id="chk-edges" checked><label for="chk-edges">层级连线</label></div>
    <div class="ctrl-row"><input type="checkbox" id="chk-rooms" checked><label for="chk-rooms">房间区域</label></div>
    <div class="ctrl-row"><input type="checkbox" id="chk-bboxes" checked><label for="chk-bboxes">包围盒</label></div>
    <div class="ctrl-row"><input type="checkbox" id="chk-nodes" checked><label for="chk-nodes">节点球</label></div>
    <div class="ctrl-row"><input type="checkbox" id="chk-roomlabels" checked><label for="chk-roomlabels">楼层/房间标签</label></div>
    <div class="ctrl-divider"></div>
    <button class="ctrl-btn" id="btn-theme">🌓 切换亮色</button>
    <button class="ctrl-btn" id="btn-axes">🧭 坐标轴</button>
    <button class="ctrl-btn" id="btn-screenshot">📸 截图</button>
    <button class="ctrl-btn" id="btn-reset">🎯 重置视角</button>
  </div>
</div>
<div id="info-panel">
  <div class="ip-hdr">
    <div class="color-dot"></div>
    <div class="ip-name"></div>
    <button class="ip-close">✕</button>
  </div>
  <div class="ip-body">
    <div class="ip-row"><span>房间</span><span class="ip-val ip-room">-</span></div>
    <div class="ip-row"><span>楼层</span><span class="ip-val ip-floor">-</span></div>
    <div class="ip-row"><span>尺寸</span><span class="ip-val ip-size">-</span></div>
    <div class="ip-row"><span>体积</span><span class="ip-val ip-volume">-</span></div>
    <div class="ip-row"><span>点数</span><span class="ip-val ip-pts">-</span></div>
    <div class="ip-row"><span>中心</span><span class="ip-val dim ip-centroid">-</span></div>
  </div>
  <button class="ip-focus">🎯 聚焦此物体</button>
</div>
<div id="views-panel">
  <div class="vp-title">
    <span>📷 <span class="vp-name"></span> <span class="vp-counter"></span></span>
    <button class="vp-close">✕</button>
  </div>
  <div class="vp-img-wrap"></div>
</div>
<div id="help-hint">
  <kbd>左键</kbd> 旋转 &nbsp; <kbd>右键</kbd>/<kbd>中键</kbd> 平移 &nbsp; <kbd>滚轮</kbd> 缩放 &nbsp; <kbd>R</kbd> 重置 &nbsp; <kbd>T</kbd> 切换主题
</div>
<div id="tooltip">
  <div class="t-name"></div>
  <div class="t-room"></div>
</div>
<div id="statusbar">
  <span id="stat-obj">物体: 0</span>
  <span id="stat-room">房间: 0</span>
  <span id="stat-floor">楼层: 0</span>
  <span id="stat-pts">点数: 0</span>
  <span id="stat-fps">FPS: --</span>
  <span style="flex:1"></span>
  <span id="stat-theme">🌙 暗色</span>
</div>
<script type="importmap">
{
  "imports":{
    "three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
    "three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"
  }
}
</script>
<script type="module">
import*as THREE from'three';
import{OrbitControls}from'three/addons/controls/OrbitControls.js';
import{CSS2DRenderer,CSS2DObject}from'three/addons/renderers/CSS2DRenderer.js';

const DATA=__SCENE_DATA__;

function rgbToHsl(r,g,b){const mx=Math.max(r,g,b),mn=Math.min(r,g,b);let h,s,l=(mx+mn)/2;if(mx===mn){h=s=0;}else{const d=mx-mn;s=l>0.5?d/(2-mx-mn):d/(mx+mn);switch(mx){case r:h=((g-b)/d+(g<b?6:0))/6;break;case g:h=((b-r)/d+2)/6;break;case b:h=((r-g)/d+4)/6;break;}}return[h,s,l];}
function hslToRgb(h,s,l){let r,g,b;if(s===0){r=g=b=l;}else{const hue2rgb=(p,q,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return p+(q-p)*6*t;if(t<1/2)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p;};const q=l<0.5?l*(1+s):l+s-l*s,p=2*l-q;r=hue2rgb(p,q,h+1/3);g=hue2rgb(p,q,h);b=hue2rgb(p,q,h-1/3);}return[r,g,b];}

let scene,camera,renderer,labelRenderer,controls;
let raycaster,mouse=new THREE.Vector2(-9,-9);
let objMeshes={},roomMeshes={},nodeGroups=[],edgeLines=[],bboxMeshes=[];
let objLabels=[],roomLabels=[];
let hovered=null,selected=null,animating=false;
let axesHelper=null,axesVisible=false;
let currentTheme='dark';
let pointerDownPos={x:0,y:0};
let pointerDownTime=0;
const CLICK_DIST_THRESHOLD=6;
const CLICK_TIME_THRESHOLD=400;
let hoverGroup,glowSphere,glowMat,groundRing,groundRingMat,vertLine;

const THEMES={
  dark:{bg:0x0f0f1a,fog:0x0f0f1a,gridMain:0x1a1a3e,gridSub:0x111128,glow:0xff6b9d,ambientI:0.5,objTint:0xffffff,objSize:0.10,objOpacity:0.92,roomTint:0xffffff,roomOpacity:0.18,bboxEdgeOpacity:0.35,bboxFillOpacity:0.06,edgeFloorOpacity:0.35,edgeObjOpacity:0.2,floorColor:0xffa500,floorEmissive:0x664400,roomColor:0x4dabf7,roomEmissive:0x003366},
  light:{bg:0xc0c0c8,fog:0xc0c0c8,gridMain:0xa0a0a8,gridSub:0xacacb4,glow:0xff6600,ambientI:0.85,objTint:0xffffff,objSize:0.10,objOpacity:1.0,roomTint:0x888898,roomOpacity:0.15,bboxEdgeOpacity:0.55,bboxFillOpacity:0.10,edgeFloorOpacity:0.55,edgeObjOpacity:0.38,floorColor:0xe09000,floorEmissive:0x885500,roomColor:0x3090e0,roomEmissive:0x004488}
};

function getGroundY(){return DATA.scene_min_y!=null?DATA.scene_min_y:(DATA.scene_center[1]-(DATA.scene_size||10)*0.5);}

function init(){
  const box=document.getElementById('canvas-container');
  scene=new THREE.Scene();scene.background=new THREE.Color(THEMES.dark.bg);scene.fog=new THREE.FogExp2(THEMES.dark.fog,0.008);
  const sc=DATA.scene_center||[0,0,0],ss=DATA.scene_size||10,center=new THREE.Vector3(sc[0],sc[1],sc[2]);
  camera=new THREE.PerspectiveCamera(55,box.clientWidth/box.clientHeight,0.1,500);
  camera.position.set(center.x+ss*0.6,center.y+ss*0.5,center.z-ss*0.6);
  renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance',preserveDrawingBuffer:true});
  renderer.setSize(box.clientWidth,box.clientHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,2));box.appendChild(renderer.domElement);
  labelRenderer=new CSS2DRenderer();labelRenderer.setSize(box.clientWidth,box.clientHeight);
  labelRenderer.domElement.style.position='absolute';labelRenderer.domElement.style.top='0';labelRenderer.domElement.style.left='0';labelRenderer.domElement.style.pointerEvents='none';
  box.appendChild(labelRenderer.domElement);
  controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=0.08;controls.target.copy(center);
  controls.enablePan=true;controls.panSpeed=1.0;controls.maxDistance=ss*3;controls.minDistance=0.5;
  controls.mouseButtons={LEFT:THREE.MOUSE.ROTATE,MIDDLE:THREE.MOUSE.PAN,RIGHT:THREE.MOUSE.PAN};controls.update();
  raycaster=new THREE.Raycaster();raycaster.params.Points.threshold=0.25;
  const ambient=new THREE.AmbientLight(0xffffff,0.5);scene.add(ambient);scene.userData.ambient=ambient;
  const dl=new THREE.DirectionalLight(0xffffff,0.3);dl.position.set(10,20,10);scene.add(dl);
  const groundY=getGroundY(),gridSize=Math.max(ss*2,30);
  const grid=new THREE.GridHelper(gridSize,Math.round(gridSize),0x1a1a3e,0x111128);grid.position.set(center.x,groundY-0.05,center.z);scene.add(grid);scene.userData.grid=grid;
  axesHelper=new THREE.AxesHelper(ss*0.5);axesHelper.position.set(center.x,groundY,center.z);axesHelper.visible=false;scene.add(axesHelper);
  initHoverGroup();renderData();buildTree();setupUI();
  document.getElementById('stat-obj').textContent='物体: '+Object.keys(DATA.objects).length;
  document.getElementById('stat-room').textContent='房间: '+Object.keys(DATA.rooms).length;
  document.getElementById('stat-floor').textContent='楼层: '+Object.keys(DATA.floors).length;
  window.addEventListener('resize',onResize);
  renderer.domElement.addEventListener('pointermove',onPointerMove);
  renderer.domElement.addEventListener('pointerdown',e=>{pointerDownPos={x:e.clientX,y:e.clientY};pointerDownTime=performance.now();});
  renderer.domElement.addEventListener('click',onPointerClick);
  window.addEventListener('keydown',onKeyDown);
  const saved=localStorage.getItem('sg-viz-theme');if(saved)applyTheme(saved);
  setTimeout(()=>{const h=document.getElementById('help-hint');if(h)h.style.opacity='0';setTimeout(()=>{if(h)h.style.display='none'},1200);},7000);
  document.getElementById('loading').style.display='none';animate();
}

function initHoverGroup(){
  hoverGroup=new THREE.Group();hoverGroup.visible=false;scene.add(hoverGroup);
  const glowVert=`varying vec3 vNormalView;varying vec3 vPositionView;void main(){vNormalView=normalize(normalMatrix*normal);vec4 mvPos=modelViewMatrix*vec4(position,1.0);vPositionView=mvPos.xyz;gl_Position=projectionMatrix*mvPos;}`;
  const glowFrag=`uniform vec3 uGlowColor;uniform float uTime;varying vec3 vNormalView;varying vec3 vPositionView;void main(){vec3 viewDir=normalize(-vPositionView);float fresnel=1.0-abs(dot(viewDir,vNormalView));fresnel=pow(fresnel,2.5);float pulse=0.85+0.15*sin(uTime*3.0);float alpha=fresnel*0.65*pulse;gl_FragColor=vec4(uGlowColor*fresnel*1.5+uGlowColor*0.3,alpha);}`;
  glowMat=new THREE.ShaderMaterial({uniforms:{uGlowColor:{value:new THREE.Color(0xff6b9d)},uTime:{value:0}},vertexShader:glowVert,fragmentShader:glowFrag,transparent:true,side:THREE.FrontSide,depthWrite:false,blending:THREE.AdditiveBlending});
  glowSphere=new THREE.Mesh(new THREE.SphereGeometry(1,32,32),glowMat);hoverGroup.add(glowSphere);
  const ringGeo=new THREE.RingGeometry(0.3,0.45,48);groundRingMat=new THREE.MeshBasicMaterial({color:0xff6b9d,transparent:true,opacity:0.5,side:THREE.DoubleSide,depthWrite:false});
  groundRing=new THREE.Mesh(ringGeo,groundRingMat);groundRing.rotation.x=-Math.PI/2;hoverGroup.add(groundRing);
  const lineGeo=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,0,0),new THREE.Vector3(0,1,0)]);
  const lineMat=new THREE.LineDashedMaterial({color:0xff6b9d,transparent:true,opacity:0.35,dashSize:0.15,gapSize:0.1});
  vertLine=new THREE.Line(lineGeo,lineMat);vertLine.computeLineDistances();hoverGroup.add(vertLine);
}

function updateHoverEffect(oid,time){
  const m=objMeshes[oid];if(!m)return;const d=m.userData,c=d.centroid,bmin=d.bbox?d.bbox[0]:c,bmax=d.bbox?d.bbox[1]:c;
  const sx=Math.max(bmax[0]-bmin[0],0.1),sy=Math.max(bmax[1]-bmin[1],0.1),sz=Math.max(bmax[2]-bmin[2],0.1),maxR=Math.max(sx,sy,sz)*0.65;
  glowSphere.position.set(c[0],c[1],c[2]);glowSphere.scale.set(maxR,maxR,maxR);glowMat.uniforms.uTime.value=time;
  const groundY=getGroundY();groundRing.position.set(c[0],groundY,c[2]);const ringScale=Math.max(sx,sz)*0.8;groundRing.scale.set(ringScale,ringScale,1);groundRingMat.color.set(THEMES[currentTheme].glow);
  vertLine.position.set(c[0],groundY,c[2]);const lineH=c[1]-groundY;vertLine.scale.set(1,Math.max(lineH,0.01),1);vertLine.computeLineDistances();
  glowMat.uniforms.uGlowColor.value.set(THEMES[currentTheme].glow);
}

function renderData(){
  let totalPts=0;
  for(const[fid,fi]of Object.entries(DATA.floors)){
    const p=fi.centroid_viz,group=new THREE.Group();group.position.set(p[0],p[1],p[2]);group.userData={type:'floor',id:fid,baseY:p[1]};
    const floorGeo=new THREE.OctahedronGeometry(0.20,0);const floorMat=new THREE.MeshPhongMaterial({color:0xffa500,emissive:0x664400,shininess:100,specular:0xffcc00,transparent:true,opacity:0.92});
    const floorMesh=new THREE.Mesh(floorGeo,floorMat);floorMesh.userData={type:'floor-mesh'};group.add(floorMesh);
    const ringGeo=new THREE.TorusGeometry(0.32,0.028,8,48);const ringMat=new THREE.MeshBasicMaterial({color:0xffa500,transparent:true,opacity:0.45});
    const ring=new THREE.Mesh(ringGeo,ringMat);ring.rotation.x=Math.PI/2;ring.userData={type:'floor-ring'};group.add(ring);
    const spriteMat=new THREE.SpriteMaterial({color:0xffa500,transparent:true,opacity:0.2,blending:THREE.AdditiveBlending,depthWrite:false});
    const sprite=new THREE.Sprite(spriteMat);sprite.scale.set(0.8,0.8,1);sprite.userData={type:'floor-glow'};group.add(sprite);
    scene.add(group);nodeGroups.push(group);
    const lbl=makeLabel(fi.name,'floor-label');lbl.position.set(p[0],p[1]+0.55,p[2]);scene.add(lbl);roomLabels.push(lbl);
  }
  function earClipTriangulate(pts2d){
    const n=pts2d.length;if(n<3)return[];
    let area=0;for(let i=0;i<n;i++){const j=(i+1)%n;area+=pts2d[i][0]*pts2d[j][1]-pts2d[j][0]*pts2d[i][1];}
    if(area<0)pts2d=pts2d.slice().reverse();
    const result=[];
    function cross2(o,a,b){return(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);}
    function ptInTriangle(px,py,a,b,c){
      const d1=cross2(a,b,[px,py]),d2=cross2(b,c,[px,py]),d3=cross2(c,a,[px,py]);
      return(d1>=0&&d2>=0&&d3>=0)||(d1<=0&&d2<=0&&d3<=0);
    }
    let remaining=Array.from({length:n},(_,i)=>i);
    let safety=n*3;
    while(remaining.length>3&&safety-->0){
      let earFound=false;
      for(let i=0;i<remaining.length;i++){
        const prev=remaining[(i-1+remaining.length)%remaining.length];
        const curr=remaining[i];
        const next=remaining[(i+1)%remaining.length];
        const a=pts2d[prev],b=pts2d[curr],c=pts2d[next];
        if(cross2(a,b,c)<=0)continue;
        let isEar=true;
        for(let j=0;j<remaining.length;j++){
          if(remaining[j]===prev||remaining[j]===curr||remaining[j]===next)continue;
          const p=pts2d[remaining[j]];
          if(ptInTriangle(p[0],p[1],a,b,c)){isEar=false;break;}
        }
        if(isEar){result.push(prev,curr,next);remaining.splice(i,1);earFound=true;break;}
      }
      if(!earFound)break;
    }
    if(remaining.length===3)result.push(remaining[0],remaining[1],remaining[2]);
    return result;
  }
  for(const[rid,ri]of Object.entries(DATA.rooms)){
    if(ri.floor_poly){
      const outline=ri.floor_poly.outline;const minY=ri.floor_poly.min_y;
      const n=outline.length;
      const verts=new Float32Array(n*3);
      for(let i=0;i<n;i++){verts[i*3]=outline[i][0];verts[i*3+1]=minY;verts[i*3+2]=outline[i][1];}
      const triIndices=earClipTriangulate(outline);
      const fillGeo=new THREE.BufferGeometry();
      fillGeo.setAttribute('position',new THREE.BufferAttribute(verts,3));
      fillGeo.setIndex(triIndices);
      fillGeo.computeVertexNormals();
      const fillMat=new THREE.MeshBasicMaterial({color:0x4dabf7,transparent:true,opacity:0.08,side:THREE.DoubleSide,depthWrite:false});
      const fillMesh=new THREE.Mesh(fillGeo,fillMat);fillMesh.userData={type:'room-floor',id:rid};scene.add(fillMesh);
      const linePts=[];for(let i=0;i<=n;i++){const idx=i%n;linePts.push(new THREE.Vector3(outline[idx][0],minY,outline[idx][1]));}
      const lineGeo=new THREE.BufferGeometry().setFromPoints(linePts);
      const lineMat=new THREE.LineBasicMaterial({color:0x4dabf7,transparent:true,opacity:0.35});
      const line=new THREE.Line(lineGeo,lineMat);line.userData={type:'room-floor',id:rid};scene.add(line);
      roomMeshes[rid]={fill:fillMesh,outline:line};
    }
    const rp=ri.centroid_viz,group=new THREE.Group();group.position.set(rp[0],rp[1],rp[2]);group.userData={type:'room',id:rid,baseY:rp[1]};
    const roomGeo=new THREE.DodecahedronGeometry(0.16,0);const roomMat=new THREE.MeshPhongMaterial({color:0x4dabf7,emissive:0x003366,shininess:80,specular:0x88bbff,transparent:true,opacity:0.88});
    const roomMesh=new THREE.Mesh(roomGeo,roomMat);roomMesh.userData={type:'room-mesh'};group.add(roomMesh);
    const ringGeo=new THREE.TorusGeometry(0.28,0.025,8,32);const ringMat=new THREE.MeshBasicMaterial({color:0x4dabf7,transparent:true,opacity:0.35});
    const ring=new THREE.Mesh(ringGeo,ringMat);ring.rotation.x=Math.PI/2;ring.userData={type:'room-ring'};group.add(ring);
    const spriteMat=new THREE.SpriteMaterial({color:0x4dabf7,transparent:true,opacity:0.15,blending:THREE.AdditiveBlending,depthWrite:false});
    const sprite=new THREE.Sprite(spriteMat);sprite.scale.set(1.0,1.0,1);sprite.userData={type:'room-glow'};group.add(sprite);
    scene.add(group);nodeGroups.push(group);
    const lbl=makeLabel(ri.name,'room-label');lbl.position.set(rp[0],rp[1]+0.4,rp[2]);scene.add(lbl);roomLabels.push(lbl);
  }
  for(const[oid,oi]of Object.entries(DATA.objects)){
    if(!oi.pts||oi.pts.length===0)continue;const n=oi.pts.length/3;const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(oi.pts,3));
    const cArr=new Float32Array(n*3);for(let i=0;i<n;i++){cArr[i*3]=oi.color[0];cArr[i*3+1]=oi.color[1];cArr[i*3+2]=oi.color[2];}geo.setAttribute('color',new THREE.Float32BufferAttribute(cArr,3));
    const mat=new THREE.PointsMaterial({size:0.1,vertexColors:true,transparent:true,opacity:0.92,sizeAttenuation:true});
    const m=new THREE.Points(geo,mat);m.userData={type:'object',id:oid,name:oi.name,roomName:oi.room_name||'',centroid:oi.centroid,bbox:oi.bbox,color:oi.color,ptsCount:n,origColor:[oi.color[0],oi.color[1],oi.color[2]],views:oi.views||[]};
    scene.add(m);objMeshes[oid]=m;totalPts+=n;
    const lbl=makeLabel(oi.name,'object-label');lbl.position.set(oi.centroid[0],oi.bbox[1][1]+0.3,oi.centroid[2]);scene.add(lbl);objLabels.push(lbl);
    if(oi.bbox){const[mn,mx]=oi.bbox;const sz=[mx[0]-mn[0],mx[1]-mn[1],mx[2]-mn[2]];const ct=[(mn[0]+mx[0])/2,(mn[1]+mx[1])/2,(mn[2]+mx[2])/2];
      if(Math.min(...sz)>0.01){const boxColor=new THREE.Color(...oi.color);
        const eg=new THREE.EdgesGeometry(new THREE.BoxGeometry(...sz));const ln=new THREE.LineSegments(eg,new THREE.LineBasicMaterial({color:boxColor,transparent:true,opacity:0.35}));ln.position.set(...ct);ln.userData={type:'bbox-edge',objId:oid,origColor:boxColor.clone()};scene.add(ln);bboxMeshes.push(ln);
        const fillGeo=new THREE.BoxGeometry(...sz);const fillMat=new THREE.MeshBasicMaterial({color:boxColor,transparent:true,opacity:0.06,side:THREE.DoubleSide,depthWrite:false});const fillMesh=new THREE.Mesh(fillGeo,fillMat);fillMesh.position.set(...ct);fillMesh.userData={type:'bbox-fill',objId:oid,origColor:boxColor.clone()};scene.add(fillMesh);bboxMeshes.push(fillMesh);
      }
    }
  }
  for(const[rid,ri]of Object.entries(DATA.rooms)){const fi=DATA.floors[ri.floor_id];if(fi)addEdge(fi.centroid_viz,ri.centroid_viz,0x00cc77,0.35,'floor');}
  for(const[oid,oi]of Object.entries(DATA.objects)){const ri=DATA.rooms[oi.room_id];if(ri)addEdge(ri.centroid_viz,oi.centroid,0x555577,0.2,'obj');}
  document.getElementById('stat-pts').textContent='点数: '+totalPts.toLocaleString();
}

function makeLabel(text,cls){const div=document.createElement('div');div.className='label-2d '+cls;div.textContent=text;return new CSS2DObject(div);}
function addEdge(from,to,color,opacity,edgeType){const g=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...from),new THREE.Vector3(...to)]);const l=new THREE.Line(g,new THREE.LineBasicMaterial({color,transparent:true,opacity}));l.userData={edgeType:edgeType||'obj'};scene.add(l);edgeLines.push(l);}

function buildTree(){
  const root=document.getElementById('tree');
  for(const[fid,fi]of Object.entries(DATA.floors)){
    const roomIds=fi.room_ids||[];const roomCount=roomIds.length;
    const fd=document.createElement('div');fd.className='tree-item floor-item';
    fd.innerHTML='<span class="arrow">▶</span><span class="icon">🏢</span><span class="name">'+fi.name+'</span>';
    const badge=document.createElement('span');badge.className='badge';badge.textContent=roomCount+'房';fd.appendChild(badge);root.appendChild(fd);
    const roomContainer=document.createElement('div');roomContainer.className='tree-children collapsed';
    for(const rid of roomIds){
      const ri=DATA.rooms[rid];if(!ri)continue;const objIds=ri.object_ids||[];const objCount=objIds.length;
      const rd=document.createElement('div');rd.className='tree-item room-item';
      rd.innerHTML='<span class="arrow">▶</span><span class="icon">🚪</span><span class="name">'+ri.name+'</span>';
      const rb=document.createElement('span');rb.className='badge';rb.textContent=objCount+'件';rd.appendChild(rb);roomContainer.appendChild(rd);
      const objContainer=document.createElement('div');objContainer.className='tree-children obj-children collapsed';
      for(const oid of objIds){
        const oi=DATA.objects[oid];if(!oi)continue;
        const od=document.createElement('div');od.className='tree-item object-item';
        od.innerHTML='<span class="arrow hidden-arrow">▶</span><span class="icon">📦</span><span class="name">'+oi.name+'</span>';od.dataset.oid=oid;
        od.addEventListener('click',e=>{e.stopPropagation();flyTo(oi.centroid);selectObj(oid);});
        od.addEventListener('mouseenter',()=>highlightObj(oid));od.addEventListener('mouseleave',()=>unhighlightObj(oid));
        objContainer.appendChild(od);
      }
      if(objContainer.children.length)roomContainer.appendChild(objContainer);
      rd.querySelector('.name').addEventListener('click',e=>{e.stopPropagation();flyTo(ri.centroid_viz);});
      rd.querySelector('.arrow').addEventListener('click',e=>{e.stopPropagation();toggleChildren(rd.querySelector('.arrow'),objContainer);});
    }
    if(roomContainer.children.length)root.appendChild(roomContainer);
    fd.querySelector('.name').addEventListener('click',e=>{e.stopPropagation();flyTo(fi.centroid_viz);});
    fd.querySelector('.arrow').addEventListener('click',e=>{e.stopPropagation();toggleChildren(fd.querySelector('.arrow'),roomContainer);});
  }
}

function toggleChildren(arrow,container){
  const isCollapsed=container.classList.contains('collapsed');
  if(isCollapsed){container.classList.remove('collapsed');arrow.classList.add('expanded');container.style.maxHeight='99999px';
    let p=container.parentElement;while(p){if(p.classList.contains('tree-children')&&!p.classList.contains('collapsed'))p.style.maxHeight='99999px';p=p.parentElement;}
  }else{container.classList.add('collapsed');arrow.classList.remove('expanded');container.style.maxHeight='0';}
}

function onPointerMove(e){const r=renderer.domElement.getBoundingClientRect();mouse.x=((e.clientX-r.left)/r.width)*2-1;mouse.y=-((e.clientY-r.top)/r.height)*2+1;}

function onPointerClick(e){
  const dx=e.clientX-pointerDownPos.x,dy=e.clientY-pointerDownPos.y,dist=Math.sqrt(dx*dx+dy*dy),dt=performance.now()-pointerDownTime;
  if(dist>CLICK_DIST_THRESHOLD||dt>CLICK_TIME_THRESHOLD)return;
  if(hovered){selectObj(hovered);flyTo(objMeshes[hovered].userData.centroid);}
}

function doHover(time){
  raycaster.setFromCamera(mouse,camera);const arr=Object.values(objMeshes);const hits=raycaster.intersectObjects(arr);const tip=document.getElementById('tooltip');
  if(hits.length>0){const m=hits[0].object,d=m.userData;if(hovered!==d.id){if(hovered)unhighlightObj(hovered);highlightObj(d.id);hovered=d.id;}
    updateHoverEffect(d.id,time);hoverGroup.visible=true;
    tip.style.display='block';tip.style.left=((event?.clientX||0)+16)+'px';tip.style.top=((event?.clientY||0)-10)+'px';
    tip.querySelector('.t-name').innerHTML='<span class="t-color" style="background:rgb('+Math.round(d.color[0]*255)+','+Math.round(d.color[1]*255)+','+Math.round(d.color[2]*255)+')"></span>'+d.name;
    tip.querySelector('.t-room').textContent=d.roomName?'📍 '+d.roomName:'';
  }else{if(hovered){unhighlightObj(hovered);hovered=null;}hoverGroup.visible=false;tip.style.display='none';}
}

function highlightObj(oid){const m=objMeshes[oid];if(!m)return;const t=THEMES[currentTheme];m.material.opacity=1;m.material.size=t.objSize*1.8;for(const[id,om]of Object.entries(objMeshes)){if(id!==oid){om.material.opacity=0.12;om.material.size=t.objSize*0.6;}}}
function unhighlightObj(oid){const t=THEMES[currentTheme];for(const om of Object.values(objMeshes)){om.material.opacity=t.objOpacity;om.material.size=t.objSize;}}

function focusHighlightObj(oid){
  if(hovered&&hovered!==oid)unhighlightObj(hovered);
  hovered=oid;highlightObj(oid);updateHoverEffect(oid,performance.now()*0.001);hoverGroup.visible=true;
}

function selectObj(oid){selected=oid;showInfoPanel(oid);showViewsPanel(oid);document.querySelectorAll('.tree-item.object-item').forEach(el=>{el.classList.toggle('active',el.dataset.oid===oid);});}

function showInfoPanel(oid){
  const oi=objMeshes[oid];if(!oi)return;const d=oi.userData;const panel=document.getElementById('info-panel');
  panel.querySelector('.color-dot').style.background='rgb('+Math.round(d.color[0]*255)+','+Math.round(d.color[1]*255)+','+Math.round(d.color[2]*255)+')';
  panel.querySelector('.ip-name').textContent=d.name;panel.querySelector('.ip-room').textContent=d.roomName||'-';
  const ri=DATA.rooms[Object.entries(DATA.rooms).find(([k,v])=>v.object_ids?.includes(oid))?.[0]||''];const fi=ri?DATA.floors[ri.floor_id]:null;
  panel.querySelector('.ip-floor').textContent=fi?fi.name:'-';
  if(d.bbox){const mn=d.bbox[0],mx=d.bbox[1];const sx=(mx[0]-mn[0]).toFixed(2),sy=(mx[1]-mn[1]).toFixed(2),sz=(mx[2]-mn[2]).toFixed(2);panel.querySelector('.ip-size').textContent=sx+' × '+sy+' × '+sz+' m';panel.querySelector('.ip-volume').textContent=(sx*sy*sz).toFixed(2)+' m³';}
  else{panel.querySelector('.ip-size').textContent='-';panel.querySelector('.ip-volume').textContent='-';}
  panel.querySelector('.ip-pts').textContent=(d.ptsCount||0).toLocaleString();panel.querySelector('.ip-centroid').textContent=d.centroid.map(v=>v.toFixed(2)).join(', ');
  panel.classList.add('show');
  panel.querySelector('.ip-focus').onclick=()=>{flyTo(d.centroid);focusHighlightObj(oid);};
}

function showViewsPanel(oid){
  const panel=document.getElementById('views-panel');
  const oi=objMeshes[oid];if(!oi||!oi.userData.views||!oi.userData.views.length){panel.style.display='none';return;}
  const d=oi.userData;
  panel.querySelector('.vp-name').textContent=d.name;
  panel.querySelector('.vp-counter').textContent='('+d.views.length+'张)';
  const wrap=panel.querySelector('.vp-img-wrap');wrap.innerHTML='';
  d.views.forEach(function(src){const img=document.createElement('img');img.src=src;img.loading='lazy';wrap.appendChild(img);});
  panel.style.display='flex';
}
function hideViewsPanel(){document.getElementById('views-panel').style.display='none';}

function hideInfoPanel(){document.getElementById('info-panel').classList.remove('show');hideViewsPanel();selected=null;document.querySelectorAll('.tree-item.object-item.active').forEach(el=>el.classList.remove('active'));}

function flyTo(pos){
  const tgt=new THREE.Vector3(...pos),st=controls.target.clone(),sp=camera.position.clone(),ep=tgt.clone().add(new THREE.Vector3(2,3,4)),t0=performance.now();
  animating=true;(function step(now){let t=Math.min((now-t0)/700,1);t=t<.5?2*t*t:-1+(4-2*t)*t;controls.target.lerpVectors(st,tgt,t);camera.position.lerpVectors(sp,ep,t);if(t<1)requestAnimationFrame(step);else animating=false;})(t0);
}
function resetCamera(){const sc=DATA.scene_center||[0,0,0],ss=DATA.scene_size||10;camera.position.set(sc[0]+ss*0.6,sc[1]+ss*0.5,sc[2]-ss*0.6);controls.target.set(sc[0],sc[1],sc[2]);controls.update();}

function applyTheme(theme){
  currentTheme=theme;document.documentElement.setAttribute('data-theme',theme);const t=THEMES[theme];
  scene.background.set(t.bg);scene.fog.color.set(t.fog);scene.userData.ambient.intensity=t.ambientI;
  const grid=scene.userData.grid;if(grid&&Array.isArray(grid.material)){grid.material[0].color.set(t.gridMain);grid.material[1].color.set(t.gridSub);}
  for(const m of Object.values(objMeshes)){const orig=m.userData.origColor;const colors=m.geometry.attributes.color;if(theme==='light'){let[h,s,l]=rgbToHsl(orig[0],orig[1],orig[2]);s=Math.min(1.0,Math.max(s,0.85));l=0.38;let[rr,gg,bb]=hslToRgb(h,s,l);for(let i=0;i<colors.count;i++)colors.setXYZ(i,rr,gg,bb);}else{for(let i=0;i<colors.count;i++)colors.setXYZ(i,orig[0],orig[1],orig[2]);}colors.needsUpdate=true;m.material.color.set(t.objTint);m.material.size=t.objSize;m.material.opacity=t.objOpacity;m.material.needsUpdate=true;}
  for(const[rid,rm]of Object.entries(roomMeshes)){rm.fill.material.color.set(t.roomColor);rm.fill.material.opacity=t.roomOpacity;rm.fill.material.needsUpdate=true;rm.outline.material.color.set(t.roomColor);rm.outline.material.opacity=t.roomOpacity*2;rm.outline.material.needsUpdate=true;}
  for(const m of bboxMeshes){const oid=m.userData.objId;const objM=objMeshes[oid];if(!objM)continue;const orig=objM.userData.origColor;if(theme==='light'){let[h,s,l]=rgbToHsl(orig[0],orig[1],orig[2]);s=Math.min(1.0,Math.max(s,0.85));l=0.38;let[rr,gg,bb]=hslToRgb(h,s,l);m.material.color.setRGB(rr,gg,bb);}else{m.material.color.copy(m.userData.origColor);}if(m.userData.type==='bbox-edge')m.material.opacity=t.bboxEdgeOpacity;else if(m.userData.type==='bbox-fill')m.material.opacity=t.bboxFillOpacity;}
  for(const g of nodeGroups){g.traverse(child=>{if(!child.isMesh&&!child.isSprite)return;if(g.userData.type==='floor'){if(child.userData.type==='floor-mesh'){child.material.color.set(t.floorColor);child.material.emissive.set(t.floorEmissive);}else if(child.userData.type==='floor-ring'||child.userData.type==='floor-glow'){child.material.color.set(t.floorColor);}}else if(g.userData.type==='room'){if(child.userData.type==='room-mesh'){child.material.color.set(t.roomColor);child.material.emissive.set(t.roomEmissive);}else if(child.userData.type==='room-ring'||child.userData.type==='room-glow'){child.material.color.set(t.roomColor);}}});}
  for(const l of edgeLines){if(l.userData.edgeType==='floor')l.material.opacity=t.edgeFloorOpacity;else l.material.opacity=t.edgeObjOpacity;}
  document.getElementById('btn-theme').textContent=theme==='dark'?'🌓 切换亮色':'🌙 切换暗色';document.getElementById('stat-theme').textContent=theme==='dark'?'🌙 暗色':'☀️ 亮色';localStorage.setItem('sg-viz-theme',theme);
}
function toggleTheme(){applyTheme(currentTheme==='dark'?'light':'dark');}
function onKeyDown(e){if(e.key==='r'||e.key==='R')resetCamera();if(e.key==='t'||e.key==='T')toggleTheme();if(e.key==='Escape')hideInfoPanel();}

function setupUI(){
  const on=(id,fn)=>document.getElementById(id).addEventListener('change',fn);
  on('chk-labels',e=>objLabels.forEach(l=>l.visible=e.target.checked));on('chk-edges',e=>edgeLines.forEach(l=>l.visible=e.target.checked));
  on('chk-rooms',e=>Object.values(roomMeshes).forEach(rm=>{rm.fill.visible=e.target.checked;rm.outline.visible=e.target.checked;}));on('chk-bboxes',e=>bboxMeshes.forEach(m=>m.visible=e.target.checked));
  on('chk-nodes',e=>nodeGroups.forEach(g=>g.visible=e.target.checked));on('chk-roomlabels',e=>roomLabels.forEach(l=>l.visible=e.target.checked));
  document.getElementById('btn-theme').onclick=toggleTheme;document.getElementById('btn-reset').onclick=resetCamera;
  document.getElementById('btn-axes').onclick=()=>{axesVisible=!axesVisible;axesHelper.visible=axesVisible;document.getElementById('btn-axes').classList.toggle('active',axesVisible);};
  document.getElementById('btn-screenshot').onclick=()=>{renderer.render(scene,camera);const a=document.createElement('a');a.href=renderer.domElement.toDataURL('image/png');a.download='scene_'+Date.now()+'.png';a.click();};
  document.querySelector('#info-panel .ip-close').onclick=hideInfoPanel;
  document.querySelector('#views-panel .vp-close').onclick=hideViewsPanel;
  // 拖拽功能
  (function(){const panel=document.getElementById('views-panel'),title=panel.querySelector('.vp-title');let dragging=false,ox=0,oy=0;
    title.addEventListener('mousedown',function(e){if(e.target.classList.contains('vp-close'))return;dragging=true;const r=panel.getBoundingClientRect();ox=e.clientX-r.left;oy=e.clientY-r.top;e.preventDefault();});
    document.addEventListener('mousemove',function(e){if(!dragging)return;panel.style.left=(e.clientX-ox)+'px';panel.style.top=(e.clientY-oy)+'px';panel.style.bottom='auto';panel.style.right='auto';});
    document.addEventListener('mouseup',function(){dragging=false;});
  })();
  const ctrlPanel=document.getElementById('controls'),ctrlToggle=document.getElementById('ctrl-toggle'),ctrlMini=document.getElementById('ctrl-mini');
  ctrlToggle.onclick=()=>{ctrlPanel.classList.add('collapsed');};ctrlMini.onclick=()=>{ctrlPanel.classList.remove('collapsed');};
  const btn=document.getElementById('toggle-sidebar'),sb=document.getElementById('sidebar'),cc=document.getElementById('canvas-container'),stb=document.getElementById('statusbar');
  let collapsed=false;btn.onclick=()=>{collapsed=!collapsed;sb.classList.toggle('collapsed',collapsed);cc.classList.toggle('expanded',collapsed);stb.classList.toggle('expanded',collapsed);btn.textContent=collapsed?'▶':'◀';btn.classList.toggle('shifted',collapsed);setTimeout(onResize,350);};
  document.getElementById('btn-expand-all').onclick=()=>{document.querySelectorAll('.tree-children').forEach(el=>{el.classList.remove('collapsed');el.style.maxHeight='99999px';});document.querySelectorAll('.tree-item .arrow').forEach(a=>a.classList.add('expanded'));};
  document.getElementById('btn-collapse-all').onclick=()=>{document.querySelectorAll('.tree-children').forEach(el=>{el.classList.add('collapsed');el.style.maxHeight='0';});document.querySelectorAll('.tree-item .arrow').forEach(a=>a.classList.remove('expanded'));};
  document.getElementById('search-input').addEventListener('input',e=>{const q=e.target.value.toLowerCase().trim();document.querySelectorAll('.tree-item').forEach(el=>{if(!q){el.classList.remove('hidden');return;}const name=el.querySelector('.name')?.textContent?.toLowerCase()||'';el.classList.toggle('hidden',!name.includes(q));});if(q){document.querySelectorAll('.tree-children').forEach(el=>{el.classList.remove('collapsed');el.style.maxHeight='99999px';});document.querySelectorAll('.tree-item .arrow').forEach(a=>a.classList.add('expanded'));}});
}

function onResize(){const b=document.getElementById('canvas-container');camera.aspect=b.clientWidth/b.clientHeight;camera.updateProjectionMatrix();renderer.setSize(b.clientWidth,b.clientHeight);labelRenderer.setSize(b.clientWidth,b.clientHeight);}

let fc=0,lt=performance.now();
function animate(){
  requestAnimationFrame(animate);const time=performance.now()*0.001;controls.update();if(!animating)doHover(time);
  nodeGroups.forEach((g,i)=>{const baseY=g.userData.baseY;if(baseY!=null)g.position.y=baseY+Math.sin(time*1.2+i*1.1)*0.06;
    g.traverse(child=>{if(child.userData.type==='floor-mesh')child.rotation.y=time*0.4;if(child.userData.type==='room-mesh')child.rotation.y=time*0.6+i;if(child.userData.type==='floor-ring')child.rotation.z=time*0.3;if(child.userData.type==='room-ring')child.rotation.z=time*0.5+i;});
  });
  renderer.render(scene,camera);labelRenderer.render(scene,camera);fc++;const now=performance.now();if(now-lt>=1000){document.getElementById('stat-fps').textContent='FPS: '+fc;fc=0;lt=now;}
}

init();
</script>
</body>
</html>"""


def main(graph_path, manual_negate=False, views_dir=None):
    if not os.path.isabs(graph_path):
        graph_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), graph_path)
    graph_path = os.path.abspath(graph_path)

    if not os.path.isdir(graph_path):
        print(f"错误: 目录不存在: {graph_path}")
        sys.exit(1)

    print(f"加载分层场景图: {graph_path}")

    # ========== 加载楼层 ==========
    floors_ply = sorted(glob.glob(os.path.join(graph_path, "floors", "*.ply")))
    floors_json = sorted(glob.glob(os.path.join(graph_path, "floors", "*.json")))

    floor_infos = {}
    hier_topo = defaultdict(dict)

    for cnt, (ply_p, json_p) in enumerate(zip(floors_ply, floors_json)):
        with open(json_p) as f:
            info = json.load(f)
        fid = info["floor_id"]
        floor_infos[fid] = {k: v for k, v in info.items() if k in ["floor_id", "name", "rooms", "floor_height", "floor_zero_level"]}
        floor_infos[fid]["viz_offset"] = None
        for rid in info["rooms"]:
            hier_topo[fid][rid] = []

    print(f"  楼层: {len(floor_infos)}")

    # ========== 检测是否需要交换Y/Z轴 ==========
    rooms_ply = sorted(glob.glob(os.path.join(graph_path, "rooms", "*.ply")))
    rooms_json = sorted(glob.glob(os.path.join(graph_path, "rooms", "*.json")))

    need_swap_yz = False
    sample_list = []
    for pp in rooms_ply[:5]:
        pcd = o3d.io.read_point_cloud(pp)
        pts = np.asarray(pcd.points)
        if len(pts) > 10:
            sample_list.append(pts[:500])

    if sample_list:
        sample = np.vstack(sample_list)
        y_range = np.ptp(sample[:, 1])
        z_range = np.ptp(sample[:, 2])
        if z_range < y_range * 0.7:
            need_swap_yz = True
        print(f"  坐标轴检测: y范围={y_range:.2f}, z范围={z_range:.2f}, 交换y/z={need_swap_yz}")

    # ========== 加载房间数据 ==========
    room_infos = {}
    room_raw_pts = {}

    for ply_p, json_p in zip(rooms_ply, rooms_json):
        with open(json_p) as f:
            info = json.load(f)
        rid = info["room_id"]
        room_infos[rid] = {k: v for k, v in info.items() if k in ["room_id", "name", "floor_id", "room_height", "room_zero_level"]}
        for oid in info.get("objects", []):
            hier_topo[info["floor_id"]][rid].append(oid)

        pcd = o3d.io.read_point_cloud(ply_p)
        xyz = np.asarray(pcd.points)
        ri = room_infos[rid]

        # ceiling mask
        # 在 Z-up 数据中，高度沿 Z 轴（index 2）；交换后高度沿 Y 轴
        height_axis = 2 if need_swap_yz else 1
        if ri.get("room_zero_level") is not None and ri.get("room_height") is not None and ri["room_height"] > 0:
            ceiling_y = ri["room_zero_level"] + ri["room_height"] - 0.4
            mask = xyz[:, height_axis] < ceiling_y
            if mask.sum() < len(xyz) * 0.2:
                print(f"  ⚠️ 房间 {rid} ceiling mask过于激进({mask.sum()}/{len(xyz)}点保留)，跳过mask")
            else:
                xyz = xyz[mask]

        if need_swap_yz:
            xyz = xyz.copy()
            old_y = xyz[:, 1].copy()
            xyz[:, 1] = xyz[:, 2]
            xyz[:, 2] = -old_y

        tmp = o3d.geometry.PointCloud()
        tmp.points = o3d.utility.Vector3dVector(xyz)
        ds = tmp.voxel_down_sample(voxel_size=ROOM_VOXEL_SIZE)
        pts = np.asarray(ds.points)
        if len(pts) > MAX_ROOM_POINTS:
            idx = np.random.choice(len(pts), MAX_ROOM_POINTS, replace=False)
            pts = pts[idx]

        if len(pts) > 0:
            room_raw_pts[rid] = pts

    print(f"  房间: {len(room_infos)}")

    # ========== 加载物体数据 ==========
    objects_ply = sorted(glob.glob(os.path.join(graph_path, "objects", "*.ply")))
    objects_json = sorted(glob.glob(os.path.join(graph_path, "objects", "*.json")))

    obj_ply_map = {}
    for pp in objects_ply:
        base = os.path.splitext(os.path.basename(pp))[0]
        obj_ply_map[base] = pp

    valid_objs = []
    for json_p in objects_json:
        with open(json_p) as f:
            info = json.load(f)
        oid = info["object_id"]
        name_l = info["name"].lower()
        if any(kw in name_l for kw in EXCLUDE_KEYWORDS):
            continue
        if oid not in obj_ply_map:
            continue
        pcd = o3d.io.read_point_cloud(obj_ply_map[oid])
        if len(pcd.points) <= 10:
            continue
        valid_objs.append((oid, info, pcd))

    cmap = plt.colormaps["tab10"].resampled(max(len(valid_objs), 1))

    obj_raw_pts = {}
    for i, (oid, info, pcd) in enumerate(valid_objs):
        xyz = np.asarray(pcd.points)
        if need_swap_yz:
            xyz = xyz.copy()
            new_y = xyz[:, 2].copy()
            xyz[:, 2] = -xyz[:, 1]
            xyz[:, 1] = new_y

        tmp = o3d.geometry.PointCloud()
        tmp.points = o3d.utility.Vector3dVector(xyz)
        ds = tmp.voxel_down_sample(voxel_size=OBJECT_VOXEL_SIZE)
        pts = np.asarray(ds.points)
        if len(pts) > MAX_OBJECT_POINTS:
            idx = np.random.choice(len(pts), MAX_OBJECT_POINTS, replace=False)
            pts = pts[idx]

        if len(pts) > 0:
            obj_raw_pts[oid] = (pts, info)

    print(f"  物体: {len(obj_raw_pts)}")

    # ========== Y轴方向处理 ==========
    need_negate_y = manual_negate

    if need_negate_y:
        print(f"  ✅ 使用 --negate-y 强制取反Y坐标")
        for rid in room_raw_pts:
            room_raw_pts[rid][:, 1] = -room_raw_pts[rid][:, 1]
        for oid in obj_raw_pts:
            pts_copy = obj_raw_pts[oid][0].copy()
            pts_copy[:, 1] = -pts_copy[:, 1]
            obj_raw_pts[oid] = (pts_copy, obj_raw_pts[oid][1])
    else:
        print(f"  ℹ️ Y轴方向保持原始数据方向")

    # ========== 设置楼层偏移并应用 ==========
    FLOOR_HEIGHT_OFFSET = 5.0
    for cnt, fid in enumerate(sorted(floor_infos.keys())):
        offset = np.array([0.0, FLOOR_HEIGHT_OFFSET * cnt, 0.0])
        floor_infos[fid]["viz_offset"] = offset.tolist()

    room_pts_data = {}
    room_floor_polys = {}
    for rid, pts in room_raw_pts.items():
        fid = room_infos[rid]["floor_id"]
        pts = pts + np.array(floor_infos[fid]["viz_offset"])
        room_pts_data[rid] = np.round(pts.flatten(), COORD_DECIMALS).tolist()

        # Alpha shape 提取房间边界
        xz = pts[:, [0, 2]]
        min_y = float(pts[:, 1].min())

        if len(xz) >= 10:
            import alphashape
            from shapely.geometry import MultiPolygon, Polygon

            from scipy.spatial import cKDTree
            tree = cKDTree(xz)
            dists, _ = tree.query(xz, k=5)
            avg_dist = np.mean(dists[:, 1:])
            alpha = 2.5 * avg_dist

            try:
                alpha_shape = alphashape.alphashape(xz, alpha)

                # 提取外边界
                if isinstance(alpha_shape, MultiPolygon):
                    # 取面积最大的多边形
                    outline_geom = max(alpha_shape.geoms, key=lambda g: g.area)
                elif isinstance(alpha_shape, Polygon):
                    outline_geom = alpha_shape
                else:
                    outline_geom = None

                if outline_geom is not None:
                    coords = list(outline_geom.exterior.coords)
                    if len(coords) > 1 and coords[0] == coords[-1]:
                        coords = coords[:-1]

                    if len(coords) >= 3:
                        outline_xz = [[round(c[0], COORD_DECIMALS), round(c[1], COORD_DECIMALS)] for c in coords]
                        room_floor_polys[rid] = {
                            "outline": outline_xz,
                            "min_y": round(min_y, COORD_DECIMALS),
                        }
                        x_min, z_min = xz.min(axis=0)
                        x_max, z_max = xz.max(axis=0)
                        print(f"  房间 {rid}: alpha shape轮廓 {len(outline_xz)} 顶点, X=[{x_min:.2f}, {x_max:.2f}], Z=[{z_min:.2f}, {z_max:.2f}], min_y={min_y:.2f}")
            except Exception as e:
                print(f"  警告: 房间 {rid} alpha shape 提取失败: {e}")

    object_data = {}
    for i, (oid, info, pcd) in enumerate(valid_objs):
        if oid not in obj_raw_pts:
            continue
        pts = obj_raw_pts[oid][0].copy()
        rid = info["room_id"]
        fid = room_infos[rid]["floor_id"]
        pts = pts + np.array(floor_infos[fid]["viz_offset"])

        color = np.array(cmap(i))[:3]
        centroid = pts.mean(axis=0)
        bmin = pts.min(axis=0)
        bmax = pts.max(axis=0)
        room_name = room_infos[rid]["name"] if rid in room_infos else ""

        object_data[oid] = {
            "name": info["name"],
            "room_id": rid,
            "room_name": room_name,
            "pts": np.round(pts.flatten(), COORD_DECIMALS).tolist(),
            "color": np.round(color, 3).tolist(),
            "centroid": np.round(centroid, COORD_DECIMALS).tolist(),
            "bbox": [np.round(bmin, COORD_DECIMALS).tolist(), np.round(bmax, COORD_DECIMALS).tolist()],
        }

    print(f"  有效物体: {len(object_data)}")

    # ========== 收集物体视角图像（base64嵌入） ==========
    if views_dir is None:
        views_dir = os.path.join(os.path.dirname(graph_path), "object_views")
    if os.path.isdir(views_dir):
        # 构建物体名→文件夹映射
        name_to_folder = {}
        for folder_name in os.listdir(views_dir):
            folder_path = os.path.join(views_dir, folder_name)
            if os.path.isdir(folder_path):
                name_to_folder[folder_name] = folder_path
        # 为每个物体收集图像并编码为base64（压缩）
        views_count = 0
        max_width = 480  # 最大宽度
        jpeg_quality = 50  # JPEG压缩质量
        for oid, oi in object_data.items():
            obj_name = oi["name"]
            if obj_name in name_to_folder:
                folder = name_to_folder[obj_name]
                images = sorted([f for f in os.listdir(folder) if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
                if images:
                    data_uris = []
                    for img_name in images:
                        img_path = os.path.join(folder, img_name)
                        try:
                            with Image.open(img_path) as img:
                                # 缩放到max_width
                                if img.width > max_width:
                                    ratio = max_width / img.width
                                    new_h = int(img.height * ratio)
                                    img = img.resize((max_width, new_h), Image.LANCZOS)
                                # 转为RGB（处理RGBA等情况）
                                if img.mode != 'RGB':
                                    img = img.convert('RGB')
                                # 编码为JPEG
                                buf = io.BytesIO()
                                img.save(buf, format='JPEG', quality=jpeg_quality, optimize=True)
                                img_data = base64.b64encode(buf.getvalue()).decode("ascii")
                                data_uris.append(f"data:image/jpeg;base64,{img_data}")
                        except Exception as e:
                            print(f"  警告: 无法处理图像 {img_path}: {e}")
                    oi["views"] = data_uris
                    views_count += 1
        print(f"  物体视角: {views_count} 个物体有视角图像（已压缩嵌入，{max_width}px/JPEG q{jpeg_quality}）")
    else:
        print(f"  视角目录不存在: {views_dir}")

    # ========== 计算场景中心和大小 ==========
    all_obj_pts = []
    for oid, oi in object_data.items():
        flat = oi["pts"]
        for j in range(0, len(flat), 3):
            all_obj_pts.append([flat[j], flat[j + 1], flat[j + 2]])

    if all_obj_pts:
        all_obj_arr = np.array(all_obj_pts)
        scene_center = all_obj_arr.mean(axis=0)
        scene_min = all_obj_arr.min(axis=0)
        scene_max = all_obj_arr.max(axis=0)
        scene_size = float(np.linalg.norm(scene_max - scene_min))
        if scene_size < 1.0:
            scene_size = 10.0
    else:
        scene_center = np.array([0.0, 0.0, 0.0])
        scene_min = np.array([0.0, 0.0, 0.0])
        scene_max = np.array([0.0, 0.0, 0.0])
        scene_size = 10.0

    print(f"  场景中心: {np.round(scene_center, 2).tolist()}")
    print(f"  场景底部Y: {scene_min[1]:.2f}")
    print(f"  场景大小: {scene_size:.1f}")

    # ========== 计算节点位置 ==========
    node_offset_room = max(scene_size * 0.05, 1.0)
    node_offset_floor = max(scene_size * 0.06, 1.5)

    room_centroids_viz = {}
    for rid, ri in room_infos.items():
        if rid in room_pts_data and len(room_pts_data[rid]) >= 3:
            flat = room_pts_data[rid]
            pts = np.array(flat).reshape(-1, 3)
            c = pts.mean(axis=0)

            max_y = pts[:, 1].max()
            fid = ri["floor_id"]
            for oid in hier_topo[fid].get(rid, []):
                if oid in object_data:
                    obj_top_y = object_data[oid]["bbox"][1][1]
                    max_y = max(max_y, obj_top_y)

            c[1] = max_y + node_offset_room
            room_centroids_viz[rid] = np.round(c, COORD_DECIMALS).tolist()
        else:
            obj_centroids = []
            obj_max_y = -1e9
            fid = ri["floor_id"]
            for oid in hier_topo[fid].get(rid, []):
                if oid in object_data:
                    obj_centroids.append(object_data[oid]["centroid"])
                    obj_max_y = max(obj_max_y, object_data[oid]["bbox"][1][1])
            if obj_centroids:
                c = np.mean(obj_centroids, axis=0)
                c[1] = obj_max_y + node_offset_room
                room_centroids_viz[rid] = np.round(c, COORD_DECIMALS).tolist()
            else:
                room_centroids_viz[rid] = np.round(scene_center, COORD_DECIMALS).tolist()

    floor_centroids_viz = {}
    for fid, fi in floor_infos.items():
        room_node_positions = []
        all_pts = []
        for rid in hier_topo[fid]:
            if rid in room_centroids_viz:
                room_node_positions.append(room_centroids_viz[rid])
            if rid in room_pts_data:
                flat = room_pts_data[rid]
                for j in range(0, len(flat), 3):
                    all_pts.append([flat[j], flat[j + 1], flat[j + 2]])

        if room_node_positions:
            pts_arr = np.array(room_node_positions)
            c = pts_arr.mean(axis=0)
            c[1] = pts_arr[:, 1].max() + node_offset_floor
            floor_centroids_viz[fid] = np.round(c, COORD_DECIMALS).tolist()
        elif all_pts:
            pts_arr = np.array(all_pts)
            c = pts_arr.mean(axis=0)
            c[1] = pts_arr[:, 1].max() + node_offset_floor
            floor_centroids_viz[fid] = np.round(c, COORD_DECIMALS).tolist()
        else:
            floor_centroids_viz[fid] = np.round(scene_center + np.array([0, node_offset_floor, 0]), COORD_DECIMALS).tolist()

    # ========== 构建场景数据 ==========
    scene_data = {
        "floors": {},
        "rooms": {},
        "objects": object_data,
        "scene_center": np.round(scene_center, COORD_DECIMALS).tolist(),
        "scene_size": round(scene_size, 2),
        "scene_min_y": round(float(scene_min[1]), COORD_DECIMALS),
    }

    for fid, fi in floor_infos.items():
        scene_data["floors"][fid] = {
            "name": fi.get("name", fid),
            "centroid_viz": floor_centroids_viz[fid],
            "room_ids": list(hier_topo[fid].keys()),
        }

    for rid, ri in room_infos.items():
        scene_data["rooms"][rid] = {
            "name": ri.get("name", rid),
            "floor_id": ri["floor_id"],
            "centroid_viz": room_centroids_viz[rid],
            "object_ids": [oid for oid in hier_topo[ri["floor_id"]].get(rid, []) if oid in object_data],
            "floor_poly": room_floor_polys.get(rid),
        }

    # ========== 生成HTML ==========
    json_str = json.dumps(scene_data, ensure_ascii=False, separators=(',', ':'))
    json_str = json_str.replace('</script>', '<\\/script>')

    html = HTML_TEMPLATE.replace('__SCENE_DATA__', json_str)

    output_path = os.path.join(graph_path, "visualization.html")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    size_mb = os.path.getsize(output_path) / 1024 / 1024
    print(f"\n✅ 已生成: {output_path}")
    print(f"   文件大小: {size_mb:.1f} MB")
    print(f"   用浏览器打开即可查看（推荐 Chrome）")
    if manual_negate:
        print(f"   ℹ️ 使用了 --negate-y 强制取反")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="生成交互式HTML可视化 - 分层场景图")
    parser.add_argument(
        "graph_path",
        nargs="?",
        default="unified_output/hierarchical_graph",
        help="场景图目录路径 (默认: unified_output/hierarchical_graph)"
    )
    parser.add_argument(
        "--negate-y",
        action="store_true",
        help="强制取反Y坐标修正高度方向"
    )
    parser.add_argument(
        "--views_dir",
        default=None,
        help="物体视角图像目录 (默认: <graph_path>同级/object_views)"
    )
    args = parser.parse_args()
    main(args.graph_path, manual_negate=args.negate_y, views_dir=args.views_dir)

