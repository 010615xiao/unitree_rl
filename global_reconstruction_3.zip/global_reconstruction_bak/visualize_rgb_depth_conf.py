#!/usr/bin/env python3
"""将 RGB、depth、confidence 三图拼接在一起可视化"""

import argparse
import numpy as np
import cv2
from pathlib import Path
from tqdm import tqdm


def visualize_confidence(conf, threshold=0.99):
    conf_norm = (conf * 255).astype(np.uint8)
    conf_color = cv2.applyColorMap(conf_norm, cv2.COLORMAP_JET)
    low_conf_mask = conf < threshold
    if low_conf_mask.sum() > 0:
        conf_color[low_conf_mask] = [0, 0, 255]
    return conf_color


def visualize_depth(depth, max_depth=15.0):
    depth_clipped = np.clip(depth, 0, max_depth)
    depth_norm = (depth_clipped / max_depth * 255).astype(np.uint8)
    depth_color = cv2.applyColorMap(depth_norm, cv2.COLORMAP_TURBO)
    invalid_mask = (depth <= 0) | (depth >= max_depth) | ~np.isfinite(depth)
    if invalid_mask.sum() > 0:
        depth_color[invalid_mask] = [0, 0, 0]
    return depth_color


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, required=True, help='数据集目录')
    parser.add_argument('--output', type=str, required=True, help='输出目录')
    parser.add_argument('--conf-threshold', type=float, default=0.995, help='置信度阈值 (default: 0.99)')
    parser.add_argument('--max-depth', type=float, default=8.0, help='深度最大值 (default: 15.0)')
    args = parser.parse_args()

    dataset_dir = Path(args.dataset)
    depth_dir = dataset_dir / 'depth'
    conf_dir = dataset_dir / 'conf'
    rgb_dir = dataset_dir / 'rgb'

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    depth_files = sorted(depth_dir.glob('*.npy'))
    print(f"找到 {len(depth_files)} 个深度帧")

    for depth_file in tqdm(depth_files, desc="生成拼接图"):
        frame_id = depth_file.stem

        depth = np.load(str(depth_file))
        conf_file = conf_dir / f"{frame_id}_conf.npy"
        rgb_file = rgb_dir / f"{frame_id}.jpg"

        if not conf_file.exists():
            print(f"  警告：{conf_file} 不存在，跳过")
            continue
        if not rgb_file.exists():
            print(f"  警告：{rgb_file} 不存在，跳过")
            continue

        conf = np.load(str(conf_file))
        rgb = cv2.imread(str(rgb_file))

        conf_viz = visualize_confidence(conf, threshold=args.conf_threshold)
        depth_viz = visualize_depth(depth, max_depth=args.max_depth)

        # 统一尺寸（以 RGB 为准）
        h, w = rgb.shape[:2]
        conf_viz = cv2.resize(conf_viz, (w, h))
        depth_viz = cv2.resize(depth_viz, (w, h))

        # 水平拼接: RGB | Depth | Confidence
        combined = np.hstack([rgb, depth_viz, conf_viz])

        out_path = output_dir / f"{frame_id}_combined.png"
        cv2.imwrite(str(out_path), combined)

    print(f"\n拼接图已保存到：{output_dir}")
    print("布局: RGB | Depth(COLORMAP_TURBO) | Confidence(COLORMAP_JET, 红色=<{})".format(args.conf_threshold))


if __name__ == "__main__":
    main()
