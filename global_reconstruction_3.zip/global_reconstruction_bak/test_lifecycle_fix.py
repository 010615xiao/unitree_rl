"""Test lifecycle tracking with the occluded state fix."""
import sys
sys.path.insert(0, '/workspace/wxd/Agent-Skill/agent/my_file/global_reconstruction_bak/global_reconstruction/incremental')

from lifecycle_tracker import LifecycleTracker

def test_occluded_does_not_increment_miss():
    """Occluded objects should not accumulate miss_count."""
    tracker = LifecycleTracker()
    
    # Register an object
    tracker.register_object(
        obj_id=0,
        category='chair',
        frame_id='00000',
        centroid=[1.0, 2.0, 3.0],
        point_count=100
    )
    
    # Frame 1: persisting → should reset miss_count
    tracker.update_observation(0, '00001', [1.0, 2.0, 3.0], 100, state='persisting')
    assert tracker.get_instance(0).miss_count == 0, "persisting should reset miss_count"
    
    # Frame 2: occluded → should NOT increment miss_count
    tracker.update_observation(0, '00002', state='occluded')
    assert tracker.get_instance(0).miss_count == 0, "occluded should NOT increment miss_count"
    
    # Frame 3: occluded again → still no increment
    tracker.update_observation(0, '00003', state='occluded')
    assert tracker.get_instance(0).miss_count == 0, "occluded should NOT increment miss_count"
    
    # Frame 4: unknown → should NOT increment miss_count
    tracker.update_observation(0, '00004', state='unknown')
    assert tracker.get_instance(0).miss_count == 0, "unknown should NOT increment miss_count"
    
    # Frame 5: disappeared → should increment miss_count
    tracker.increment_miss_count(0, '00005', state='disappeared', death_threshold=5)
    assert tracker.get_instance(0).miss_count == 1, "disappeared should increment miss_count"
    
    # Frames 6-9: more disappeared → should reach death threshold
    for i in range(6, 10):
        tracker.increment_miss_count(0, f'{i:05d}', state='disappeared', death_threshold=5)
    
    inst = tracker.get_instance(0)
    assert inst.miss_count == 5, f"miss_count should be 5, got {inst.miss_count}"
    assert inst.is_alive == False, "object should be dead after 5 misses"
    assert inst.current_state == 'disappeared', "final state should be disappeared"
    
    print("✓ Test passed: occluded/unknown don't increment miss_count, only disappeared does")

def test_persisting_resets_miss():
    """Persisting should reset miss_count even after some misses."""
    tracker = LifecycleTracker()
    
    tracker.register_object(0, 'chair', '00000', [1.0, 2.0, 3.0], 100)
    
    # Accumulate some misses
    for i in range(1, 4):
        tracker.increment_miss_count(0, f'{i:05d}', state='disappeared', death_threshold=5)
    
    assert tracker.get_instance(0).miss_count == 3
    
    # Then persisting → should reset
    tracker.update_observation(0, '00004', [1.0, 2.0, 3.0], 100, state='persisting')
    assert tracker.get_instance(0).miss_count == 0, "persisting should reset miss_count"
    assert tracker.get_instance(0).is_alive == True, "object should still be alive"
    
    print("✓ Test passed: persisting resets miss_count")

if __name__ == '__main__':
    test_occluded_does_not_increment_miss()
    test_persisting_resets_miss()
    print("\nAll tests passed!")
