#!/usr/bin/env python3
"""Generate a comprehensive PPTX presentation for the embodied_nav project."""

from pptx import Presentation

# Load VLM config for port number
_base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_config_path = os.path.join(_base_dir, "config", "agent.yaml")
with open(_config_path, "r") as _f:
    _cfg = yaml.safe_load(_f)
_VLM_PORT = _cfg.get("vlm", {}).get("base_url", "http://localhost:8008").split(":")[-1]
from pptx.util import Inches, Pt, Emu
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor
import os

# ── Color Palette ──
DARK_BG      = RGBColor(0x1B, 0x1F, 0x3B)  # deep navy
ACCENT_BLUE  = RGBColor(0x4A, 0x90, 0xD9)
ACCENT_CYAN  = RGBColor(0x00, 0xD4, 0xAA)
ACCENT_GREEN = RGBColor(0x27, 0xAE, 0x60)
ACCENT_ORANGE= RGBColor(0xF3, 0x9C, 0x12)
ACCENT_RED   = RGBColor(0xE7, 0x4C, 0x3C)
ACCENT_PURPLE= RGBColor(0x9B, 0x59, 0xB6)
WHITE        = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY   = RGBColor(0xCC, 0xCC, 0xCC)
MID_GRAY     = RGBColor(0x88, 0x88, 0x88)
CARD_BG      = RGBColor(0x25, 0x2A, 0x4A)
TABLE_HEADER = RGBColor(0x2C, 0x3E, 0x6B)
TABLE_ALT    = RGBColor(0x1E, 0x23, 0x45)

prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)

# ── Helpers ──

def add_bg(slide, color=DARK_BG):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_shape_bg(slide, left, top, width, height, color, alpha=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    return shape

def set_text(tf, text, size=18, color=WHITE, bold=False, alignment=PP_ALIGN.LEFT, font="Calibri"):
    tf.clear()
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.name = font
    p.alignment = alignment
    return p

def add_para(tf, text, size=18, color=WHITE, bold=False, alignment=PP_ALIGN.LEFT, space_before=Pt(6), space_after=Pt(2), font="Calibri"):
    p = tf.add_paragraph()
    p.text = text
    p.font.size = Pt(size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.name = font
    p.alignment = alignment
    if space_before: p.space_before = space_before
    if space_after: p.space_after = space_after
    return p

def add_textbox(slide, left, top, width, height, text, size=18, color=WHITE, bold=False, alignment=PP_ALIGN.LEFT, font="Calibri"):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    set_text(tf, text, size=size, color=color, bold=bold, alignment=alignment, font=font)
    return txBox

def add_accent_line(slide, left, top, width, color=ACCENT_CYAN):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, Pt(3))
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    return shape

# ═══════════════════════════════════════════════════
# SLIDE 1 — TITLE
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
add_bg(slide)

# Top accent line
add_accent_line(slide, Inches(2), Inches(2.2), Inches(9.333), ACCENT_CYAN)

add_textbox(slide, Inches(2), Inches(2.5), Inches(9.333), Inches(1.5),
    "embodied_nav", size=54, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

add_textbox(slide, Inches(2), Inches(3.8), Inches(9.333), Inches(1.0),
    "A Modular, Skill-Based Embodied AI Agent", size=28, color=ACCENT_CYAN, bold=False, alignment=PP_ALIGN.CENTER)

add_accent_line(slide, Inches(2), Inches(5.0), Inches(9.333), ACCENT_CYAN)

add_textbox(slide, Inches(2), Inches(5.3), Inches(9.333), Inches(0.8),
    "ReAct Loop  ·  Progressive Disclosure  ·  Persistent Memory  ·  Pluggable Skills",
    size=16, color=LIGHT_GRAY, alignment=PP_ALIGN.CENTER)

add_textbox(slide, Inches(2), Inches(6.3), Inches(9.333), Inches(0.5),
    "Group Meeting  ·  May 2026", size=14, color=MID_GRAY, alignment=PP_ALIGN.CENTER)


# ═══════════════════════════════════════════════════
# SLIDE 2 — AGENDA / TABLE OF CONTENTS
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(4), Inches(0.8),
    "Agenda", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(2), ACCENT_CYAN)

agenda_items = [
    ("01", "Project Background & Motivation"),
    ("02", "System Architecture — 5-Layer Design"),
    ("03", "Core Layer — VLM Client & Skill System"),
    ("04", "Decision Layer — ReAct Loop"),
    ("05", "Memory System — Short & Long Term"),
    ("06", "Skill Ecosystem — 10 Pluggable Skills"),
    ("07", "Key Design Patterns"),
    ("08", "CLI Interaction & User Experience"),
    ("09", "Deployment & Configuration"),
    ("10", "Demo Walkthrough"),
    ("11", "Strengths & Innovation Highlights"),
    ("12", "Future Work & Roadmap"),
]

y_start = 1.5
for i, (num, title) in enumerate(agenda_items):
    y = y_start + i * 0.45
    # Number badge
    badge = add_shape_bg(slide, Inches(1.0), Inches(y), Inches(0.5), Inches(0.35), ACCENT_CYAN)
    set_text(badge.text_frame, num, size=12, color=DARK_BG, bold=True, alignment=PP_ALIGN.CENTER)
    badge.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
    # Title
    add_textbox(slide, Inches(1.7), Inches(y - 0.02), Inches(5), Inches(0.4),
        title, size=17, color=WHITE if i % 2 == 0 else LIGHT_GRAY)


# Right side — quick stats
card = add_shape_bg(slide, Inches(7.5), Inches(1.5), Inches(5.0), Inches(5.0), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
tf.paragraphs[0].alignment = PP_ALIGN.CENTER
set_text(tf, "Project at a Glance", size=22, color=ACCENT_CYAN, bold=True, alignment=PP_ALIGN.CENTER)
stats = [
    "5  Architecture Layers",
    "10 Pluggable Skills",
    "4  Memory Types",
    "1  ReAct Reasoning Loop",
    "100K  Max Context Tokens",
    "Qwen3.6-35B  Local VLM",
]
for s in stats:
    add_para(tf, "▸  " + s, size=17, color=WHITE, space_before=Pt(14), alignment=PP_ALIGN.LEFT)


# ═══════════════════════════════════════════════════
# SLIDE 3 — PROJECT BACKGROUND
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(6), Inches(0.8),
    "Project Background", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

# Left column — Problem
card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(5.5), Inches(5.3), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "🎯  The Problem", size=22, color=ACCENT_ORANGE, bold=True)
problems = [
    "Embodied AI agents typically require tightly coupled perception → planning → action pipelines",
    "Adding new capabilities means modifying core agent code — fragile and hard to scale",
    "Most systems lack persistent memory across sessions — every interaction starts from scratch",
    "Cloud-dependent agents suffer from latency and privacy concerns",
]
for p in problems:
    add_para(tf, "▸  " + p, size=15, color=LIGHT_GRAY, space_before=Pt(10))

# Right column — Solution
card2 = add_shape_bg(slide, Inches(7.0), Inches(1.5), Inches(5.5), Inches(5.3), CARD_BG)
tf2 = card2.text_frame
tf2.word_wrap = True
set_text(tf2, "💡  Our Solution", size=22, color=ACCENT_GREEN, bold=True)
solutions = [
    "Modular 5-layer architecture — clean separation of concerns",
    "Pluggable skill system — add capabilities without touching core code",
    "File-based persistent memory — learn and remember across sessions",
    "Local VLM deployment — low latency, full privacy, no cloud dependency",
    "Progressive disclosure — model reads skill docs on-demand, not all at once",
]
for s in solutions:
    add_para(tf2, "▸  " + s, size=15, color=LIGHT_GRAY, space_before=Pt(10))


# ═══════════════════════════════════════════════════
# SLIDE 4 — SYSTEM ARCHITECTURE OVERVIEW
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "System Architecture — 5-Layer Design", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3.5), ACCENT_CYAN)

layers = [
    ("Interaction Layer (CLI)", "Terminal I/O, welcome banner, commands", ACCENT_BLUE),
    ("Decision Layer (Agent)",   "ReAct loop, tool routing, memory recall", ACCENT_GREEN),
    ("Memory Layer",             "Short-term (sliding window) + Long-term (file-based .md)", ACCENT_ORANGE),
    ("Skill Layer",              "Pluggable skills: SKILL.md + tools.py", ACCENT_PURPLE),
    ("Core Layer",               "VLMClient, BaseSkill, SkillRegistry", ACCENT_CYAN),
]

y = 1.6
for title, desc, color in layers:
    # Color stripe
    add_shape_bg(slide, Inches(1.5), Inches(y), Inches(0.15), Inches(0.85), color)
    # Title
    add_textbox(slide, Inches(1.9), Inches(y - 0.05), Inches(3.5), Inches(0.4),
        title, size=18, color=color, bold=True)
    # Description
    add_textbox(slide, Inches(1.9), Inches(y + 0.35), Inches(5), Inches(0.4),
        desc, size=14, color=LIGHT_GRAY)
    # Arrow down (except last)
    if layers.index((title, desc, color)) < len(layers) - 1:
        add_textbox(slide, Inches(2.4), Inches(y + 0.85), Inches(1), Inches(0.3),
            "▼", size=12, color=MID_GRAY, alignment=PP_ALIGN.CENTER)
    y += 1.15

# Right side — VLM box
card = add_shape_bg(slide, Inches(8.0), Inches(1.6), Inches(4.5), Inches(2.5), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "🤖  Local VLM", size=22, color=ACCENT_CYAN, bold=True, alignment=PP_ALIGN.CENTER)
add_para(tf, "Qwen3.6-35B", size=20, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER, space_before=Pt(10))
add_para(tf, "llama-server  :8008", size=15, color=LIGHT_GRAY, alignment=PP_ALIGN.CENTER, space_before=Pt(6))
add_para(tf, "OpenAI-compatible API", size=14, color=MID_GRAY, alignment=PP_ALIGN.CENTER, space_before=Pt(4))
add_para(tf, "120K max context", size=14, color=MID_GRAY, alignment=PP_ALIGN.CENTER, space_before=Pt(2))

# Flow diagram on right
card2 = add_shape_bg(slide, Inches(8.0), Inches(4.5), Inches(4.5), Inches(2.2), CARD_BG)
tf2 = card2.text_frame
tf2.word_wrap = True
set_text(tf2, "Request Flow", size=20, color=ACCENT_GREEN, bold=True, alignment=PP_ALIGN.CENTER)
flow = [
    "User Input (CLI)",
    "Agent ReAct Loop",
    "Memory Recall",
    "Skill Tool Call",
    "VLM Generation",
]
for step in flow:
    add_para(tf2, "  " + step, size=14, color=WHITE, space_before=Pt(6), alignment=PP_ALIGN.LEFT)


# ═══════════════════════════════════════════════════
# SLIDE 5 — CORE LAYER: VLM CLIENT
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Core Layer — VLM Client", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

# Key methods
card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(5.5), Inches(5.3), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "VLMClient  (core/llm_client.py)", size=20, color=ACCENT_CYAN, bold=True)
add_para(tf, "", size=8, color=WHITE)

methods = [
    ("chat(messages, tools)", "Sends chat completion to /v1/chat/completions. Handles tool calls returned as JSON from llama-server."),
    ("chat_with_image(text, image_path, system_prompt)", "Vision query using file:// image URLs in message content."),
    ("health_check()", "GET /health endpoint for server availability."),
    ("get_model_name()", "GET /v1/models for model discovery."),
]
for name, desc in methods:
    p = add_para(tf, name, size=15, color=ACCENT_GREEN, bold=True, space_before=Pt(12))
    add_para(tf, "    " + desc, size=13, color=LIGHT_GRAY, space_before=Pt(2))

# Right — key features
card2 = add_shape_bg(slide, Inches(7.0), Inches(1.5), Inches(5.5), Inches(2.8), CARD_BG)
tf2 = card2.text_frame
tf2.word_wrap = True
set_text(tf2, "Key Features", size=20, color=ACCENT_ORANGE, bold=True)
features = [
    "OpenAI-compatible API wrapper",
    "Graceful error handling on connection failures",
    "Support for multi-modal (text + image) inputs",
    "Tool call parsing with 35B model bug recovery",
]
for f in features:
    add_para(tf2, "✓  " + f, size=15, color=WHITE, space_before=Pt(10))

# Config
card3 = add_shape_bg(slide, Inches(7.0), Inches(4.7), Inches(5.5), Inches(2.1), CARD_BG)
tf3 = card3.text_frame
tf3.word_wrap = True
set_text(tf3, "Configuration (config/agent.yaml)", size=18, color=ACCENT_PURPLE, bold=True)
config_lines = [
    "base_url: http://localhost:8008",
    "max_tokens: 120000",
    "temperature: 0.1",
    "top_p: 0.9",
    "timeout: 120s",
]
for line in config_lines:
    add_para(tf3, "  " + line, size=14, color=LIGHT_GRAY, space_before=Pt(5), font="Consolas")


# ═══════════════════════════════════════════════════
# SLIDE 6 — CORE LAYER: SKILL SYSTEM
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Core Layer — Skill System", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

# Skill structure
card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(5.5), Inches(3.0), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "Skill Folder Structure", size=20, color=ACCENT_CYAN, bold=True)
add_para(tf, "", size=6, color=WHITE)
add_para(tf, "skills/", size=16, color=MID_GRAY, font="Consolas")
add_para(tf, "  └── <skill_name>/", size=16, color=MID_GRAY, font="Consolas")
add_para(tf, "       ├── SKILL.md      ← YAML frontmatter + instructions", size=14, color=LIGHT_GRAY, font="Consolas")
add_para(tf, "       └── tools.py       ← Concrete tool functions", size=14, color=LIGHT_GRAY, font="Consolas")

# BaseSkill
card2 = add_shape_bg(slide, Inches(0.8), Inches(4.8), Inches(5.5), Inches(2.0), CARD_BG)
tf2 = card2.text_frame
tf2.word_wrap = True
set_text(tf2, "BaseSkill  (core/skill.py)", size=18, color=ACCENT_GREEN, bold=True)
add_para(tf2, "▸ Loads SKILL.md frontmatter (name, description, version)", size=14, color=LIGHT_GRAY, space_before=Pt(6))
add_para(tf2, "▸ Auto-discovers tools.py functions via introspection", size=14, color=LIGHT_GRAY, space_before=Pt(4))
add_para(tf2, "▸ Generates OpenAI-compatible function calling schemas", size=14, color=LIGHT_GRAY, space_before=Pt(4))

# SkillRegistry
card3 = add_shape_bg(slide, Inches(7.0), Inches(1.5), Inches(5.5), Inches(2.8), CARD_BG)
tf3 = card3.text_frame
tf3.word_wrap = True
set_text(tf3, "SkillRegistry  — Auto-Discovery", size=20, color=ACCENT_ORANGE, bold=True)
add_para(tf3, "1. Scans skills/ directory for subfolders", size=14, color=WHITE, space_before=Pt(8))
add_para(tf3, "2. Parses SKILL.md for metadata", size=14, color=WHITE, space_before=Pt(4))
add_para(tf3, "3. Imports skill.py (or uses DefaultSkill)", size=14, color=WHITE, space_before=Pt(4))
add_para(tf3, "4. Registers two schemas per skill:", size=14, color=WHITE, space_before=Pt(4))
add_para(tf3, "    a) Skill(skill_name) — progressive disclosure", size=13, color=ACCENT_CYAN, space_before=Pt(4))
add_para(tf3, "    b) skill_name__tool_name — actual tools", size=13, color=ACCENT_CYAN, space_before=Pt(4))

# Progressive disclosure explanation
card4 = add_shape_bg(slide, Inches(7.0), Inches(4.7), Inches(5.5), Inches(2.1), CARD_BG)
tf4 = card4.text_frame
tf4.word_wrap = True
set_text(tf4, "Progressive Disclosure", size=20, color=ACCENT_PURPLE, bold=True)
add_para(tf4, "Instead of loading all skill docs into context upfront:", size=14, color=LIGHT_GRAY, space_before=Pt(8))
add_para(tf4, "1. Model sees only tool names in schema", size=14, color=WHITE, space_before=Pt(6))
add_para(tf4, "2. Calls Skill(skill_name) to read full SKILL.md", size=14, color=WHITE, space_before=Pt(4))
add_para(tf4, "3. Then calls the skill's concrete tools", size=14, color=WHITE, space_before=Pt(4))


# ═══════════════════════════════════════════════════
# SLIDE 7 — DECISION LAYER: REACT LOOP
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Decision Layer — ReAct Loop", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3.5), ACCENT_CYAN)

# ReAct steps
steps = [
    ("1", "User Input", "Add to conversation memory", ACCENT_BLUE),
    ("2", "Memory Recall", "VLM selects relevant long-term memories", ACCENT_GREEN),
    ("3", "Context Assembly", "Build messages with system prompt + memories", ACCENT_ORANGE),
    ("4", "VLM Generation", "Call VLM with available tool schemas", ACCENT_PURPLE),
    ("5", "Tool Call Parse", "Handle OpenAI format + 35B malformed JSON", ACCENT_CYAN),
    ("6", "Tool Execution", "Route to appropriate skill's tools.py", ACCENT_GREEN),
    ("7", "Observation", "Feed tool result back to VLM", ACCENT_BLUE),
    ("8", "Repeat / Answer", "Loop until [FINAL_ANSWER] or max steps", ACCENT_ORANGE),
]

y = 1.5
for num, title, desc, color in steps:
    # Step circle
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(1.2), Inches(y), Inches(0.55), Inches(0.55))
    circle.fill.solid()
    circle.fill.fore_color.rgb = color
    circle.line.fill.background()
    set_text(circle.text_frame, num, size=16, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    circle.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

    # Title
    add_textbox(slide, Inches(2.0), Inches(y - 0.02), Inches(3), Inches(0.4),
        title, size=17, color=color, bold=True)
    # Description
    add_textbox(slide, Inches(2.0), Inches(y + 0.3), Inches(5), Inches(0.3),
        desc, size=13, color=LIGHT_GRAY)

    # Arrow
    if steps.index((num, title, desc, color)) < len(steps) - 1:
        add_textbox(slide, Inches(1.35), Inches(y + 0.55), Inches(0.5), Inches(0.25),
            "│", size=10, color=MID_GRAY, alignment=PP_ALIGN.CENTER)
    y += 0.72

# Right — Agent features
card = add_shape_bg(slide, Inches(7.5), Inches(1.5), Inches(5.0), Inches(5.3), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "Agent Capabilities", size=22, color=ACCENT_CYAN, bold=True, alignment=PP_ALIGN.CENTER)

caps = [
    ("Max Reasoning Steps", "20 (configurable)"),
    ("Tool Call History", "Tracks all calls to detect repeats"),
    ("Repeated Call Detection", "Injects corrective feedback + memory index"),
    ("Conversation Compression", "VLM summarizes old messages when window fills"),
    ("Memory Injection", "Insertes recalled memories as system message"),
    ("Malformed JSON Recovery", "Handles 35B model's tool-call format bugs"),
    ("/reset Support", "Clears conversation history on command"),
]

for title, desc in caps:
    add_para(tf, title, size=14, color=ACCENT_GREEN, bold=True, space_before=Pt(10))
    add_para(tf, "    " + desc, size=13, color=LIGHT_GRAY, space_before=Pt(1))


# ═══════════════════════════════════════════════════
# SLIDE 8 — MEMORY LAYER: OVERVIEW
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Memory Layer — Short & Long Term", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

# Short-term memory
card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(5.5), Inches(2.8), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "🧠  Short-Term Memory", size=20, color=ACCENT_BLUE, bold=True)
add_para(tf, "", size=6, color=WHITE)
st_items = [
    "In-memory conversation history",
    "Sliding window: max 50 messages, compress at 40",
    "VLM-based compression: summarizes old messages into 2-4 sentences",
    "Keeps last 15 raw messages + system messages intact",
]
for item in st_items:
    add_para(tf, "▸  " + item, size=14, color=LIGHT_GRAY, space_before=Pt(6))

# Long-term memory
card2 = add_shape_bg(slide, Inches(7.0), Inches(1.5), Inches(5.5), Inches(2.8), CARD_BG)
tf2 = card2.text_frame
tf2.word_wrap = True
set_text(tf2, "📁  Long-Term Memory", size=20, color=ACCENT_ORANGE, bold=True)
add_para(tf2, "", size=6, color=WHITE)
lt_items = [
    "File-based persistent storage (.md files)",
    "YAML frontmatter: key, type, tags, created, updated, expires",
    "Auto-cleans expired memories on load",
    "MEMORY.md index file for fast retrieval",
]
for item in lt_items:
    add_para(tf2, "▸  " + item, size=14, color=LIGHT_GRAY, space_before=Pt(6))

# Memory types
card3 = add_shape_bg(slide, Inches(0.8), Inches(4.7), Inches(11.7), Inches(2.3), CARD_BG)
tf3 = card3.text_frame
tf3.word_wrap = True
set_text(tf3, "4 Memory Types", size=20, color=ACCENT_CYAN, bold=True, alignment=PP_ALIGN.CENTER)

types = [
    ("user", ACCENT_BLUE, "User's role, preferences, responsibilities, knowledge"),
    ("feedback", ACCENT_GREEN, "Guidance on approach — what to avoid and what to keep doing"),
    ("project", ACCENT_ORANGE, "Ongoing work, goals, initiatives, bugs, deadlines"),
    ("reference", ACCENT_PURPLE, "Pointers to external systems (Linear, Grafana, etc.)"),
]

x = 1.2
for name, color, desc in types:
    badge = add_shape_bg(slide, Inches(x), Inches(5.3), Inches(1.5), Inches(0.4), color)
    set_text(badge.text_frame, name, size=14, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    add_textbox(slide, Inches(x), Inches(5.8), Inches(2.5), Inches(0.8),
        desc, size=12, color=LIGHT_GRAY)
    x += 3.0


# ═══════════════════════════════════════════════════
# SLIDE 9 — MEMORY: RECALL & INJECTION
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(10), Inches(0.8),
    "Memory Layer — VLM-Based Recall & Injection", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(4.5), ACCENT_CYAN)

# Flow diagram
card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.3), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "Recall & Inject Flow  (decision/memory_recall.py)", size=20, color=ACCENT_CYAN, bold=True)

flow_steps = [
    ("Step 1", "Get all memory keys from long-term storage"),
    ("Step 2", "Build structured index: key + type + tags + expiry"),
    ("Step 3", "Call VLM with recall prompt → model selects relevant memories as JSON array"),
    ("Step 4", "Load full content of selected keys"),
    ("Step 5", "Insert system message with recalled memories before latest user message"),
    ("Step 6", "Also inject full memory index so model knows valid key names"),
]

for step_title, step_desc in flow_steps:
    add_para(tf, "", size=6, color=WHITE)
    p = add_para(tf, f"{step_title}: ", size=15, color=ACCENT_GREEN, bold=True)
    # Can't easily append to same paragraph, so add as separate
    add_para(tf, "    " + step_desc, size=14, color=WHITE, space_before=Pt(2))

add_para(tf, "", size=10, color=WHITE)
add_para(tf, "Key Insight: The VLM itself decides which memories are relevant — no hardcoded retrieval rules.",
    size=15, color=ACCENT_CYAN, bold=True, space_before=Pt(10))


# ═══════════════════════════════════════════════════
# SLIDE 10 — SKILL ECOSYSTEM TABLE
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Skill Ecosystem — 10 Pluggable Skills", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3.5), ACCENT_CYAN)

# Skills table
rows = 11  # header + 10 skills
cols = 4
table_shape = slide.shapes.add_table(rows, cols, Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.5))
table = table_shape.table

# Set column widths
table.columns[0].width = Inches(2.2)
table.columns[1].width = Inches(5.0)
table.columns[2].width = Inches(1.5)
table.columns[3].width = Inches(3.0)

# Header
headers = ["Skill", "Description", "Version", "Key Tools"]
for j, h in enumerate(headers):
    cell = table.cell(0, j)
    cell.text = h
    p = cell.text_frame.paragraphs[0]
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = WHITE
    cell.fill.solid()
    cell.fill.fore_color.rgb = TABLE_HEADER

skills_data = [
    ("daily_chat",       "Casual Q&A, explanations",        "v1.2.0", "respond(query)"),
    ("env_description",  "Image analysis, screenshots",     "v1.3.0", "describe_image(), screenshot_env()"),
    ("task_planning",    "Goal decomposition into steps",    "v1.1.0", "create_plan(), validate_plan()"),
    ("trajectory_gen",   "Motion trajectory generation",     "v1.3.0", "generate_trajectory(), get_action_template()"),
    ("browser_control",  "Web browser automation",           "v1.2.0", "navigate(), click(), screenshot_page()"),
    ("weather_query",    "Real-time weather via wttr.in",    "v1.3.0", "get_weather(location, format)"),
    ("memory_recall",    "Long-term memory retrieval",       "v1.0.0", "recall_index(), recall_context()"),
    ("memory_save",      "Save cross-session facts",         "v1.0.0", "save_memory(), update_memory()"),
    ("memory_delete",    "Delete stale memories",            "v1.0.0", "delete_memory(key)"),
    ("memory_list",      "View stored memories",             "v1.0.0", "list_memories(), read_memory()"),
]

for i, (name, desc, ver, tools) in enumerate(skills_data):
    row_idx = i + 1
    table.cell(row_idx, 0).text = name
    table.cell(row_idx, 1).text = desc
    table.cell(row_idx, 2).text = ver
    table.cell(row_idx, 3).text = tools
    for j in range(4):
        cell = table.cell(row_idx, j)
        for p in cell.text_frame.paragraphs:
            p.font.size = Pt(12)
            p.font.color.rgb = WHITE if j == 0 else LIGHT_GRAY
            if j == 0: p.font.bold = True
        cell.fill.solid()
        cell.fill.fore_color.rgb = TABLE_ALT if i % 2 == 1 else CARD_BG


# ═══════════════════════════════════════════════════
# SLIDE 11 — KEY DESIGN PATTERNS (1)
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Key Design Patterns  (1/2)", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

patterns1 = [
    ("1. Progressive Disclosure", ACCENT_CYAN,
     "Instead of loading all skill documentation into context upfront (consuming valuable tokens), "
     "the model first calls Skill(skill_name) to read a skill's full SKILL.md on-demand, then calls "
     "the skill's concrete tools. Only a single global Skill() tool appears in the schema — not every "
     "skill's body."),
    ("2. Memory-First Retrieval", ACCENT_GREEN,
     "Before calling any tool that requires information the user didn't explicitly provide, the agent "
     "checks long-term memory. The recall_and_inject() function uses the VLM itself to decide which "
     "memories are relevant. Missing info → check memory → ask user."),
    ("3. Anti-Guessing Rules", ACCENT_ORANGE,
     "The system prompt enforces strict rules: never guess values like cities, times, or people. "
     "If information is missing, the model must first check memory, and only then ask the user. "
     "This prevents hallucination and builds trust."),
]

y = 1.5
for title, color, desc in patterns1:
    card = add_shape_bg(slide, Inches(0.8), Inches(y), Inches(11.7), Inches(1.7), CARD_BG)
    tf = card.text_frame
    tf.word_wrap = True
    set_text(tf, title, size=20, color=color, bold=True)
    add_para(tf, desc, size=14, color=LIGHT_GRAY, space_before=Pt(8))
    y += 1.9


# ═══════════════════════════════════════════════════
# SLIDE 12 — KEY DESIGN PATTERNS (2)
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Key Design Patterns  (2/2)", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

patterns2 = [
    ("4. Repeated Tool Call Detection", ACCENT_PURPLE,
     "The agent tracks all tool calls across reasoning steps. If the same call repeats, it injects "
     "corrective feedback with the memory index to prevent infinite loops and guide the model toward "
     "a different approach."),
    ("5. Malformed JSON Recovery", ACCENT_RED,
     "The 35B model sometimes returns tool calls without the standard 'function' wrapper. The "
     "_parse_tool_calls() method specifically handles this bug, recovering the call when 'skill_name' "
     "is explicitly in arguments, routing to Skill() automatically."),
    ("6. CJK-Aware Terminal Output", ACCENT_BLUE,
     "All styled output functions account for Chinese character display width (2 columns vs 1 for "
     "ASCII). Custom text wrapping functions ensure clean, aligned terminal output even with mixed "
     "Chinese and English text."),
]

y = 1.5
for title, color, desc in patterns2:
    card = add_shape_bg(slide, Inches(0.8), Inches(y), Inches(11.7), Inches(1.7), CARD_BG)
    tf = card.text_frame
    tf.word_wrap = True
    set_text(tf, title, size=20, color=color, bold=True)
    add_para(tf, desc, size=14, color=LIGHT_GRAY, space_before=Pt(8))
    y += 1.9


# ═══════════════════════════════════════════════════
# SLIDE 13 — CLI INTERACTION
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "CLI Interaction & User Experience", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3.5), ACCENT_CYAN)

# Left — Commands
card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(5.5), Inches(3.0), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "Built-in Commands", size=20, color=ACCENT_CYAN, bold=True)

commands = [
    ("/quit",     "Exit the agent"),
    ("/reset",    "Clear conversation history"),
    ("/skills",   "List all available skills"),
    ("/memory",   "List all stored memories"),
    ("/help",     "Show command reference"),
    ("describe <path>", "Send image to env_description skill"),
]
for cmd, desc in commands:
    add_para(tf, cmd, size=14, color=ACCENT_GREEN, bold=True, space_before=Pt(8), font="Consolas")
    add_para(tf, "    " + desc, size=13, color=LIGHT_GRAY, space_before=Pt(1))

# Right — UX features
card2 = add_shape_bg(slide, Inches(7.0), Inches(1.5), Inches(5.5), Inches(3.0), CARD_BG)
tf2 = card2.text_frame
tf2.word_wrap = True
set_text(tf2, "UX Features", size=20, color=ACCENT_ORANGE, bold=True)

ux = [
    "Welcome banner with model name + skills list",
    "Skills dynamically populated from registry",
    "Color-coded output (green=user, blue=agent, yellow=tool call, dim=observation, red=error)",
    "readline history persistence (~/.embodied_agent_history)",
    "CJK-aware text wrapping",
    "Observation output truncated at 300 chars to prevent overflow",
]
for item in ux:
    add_para(tf2, "✓  " + item, size=13, color=WHITE, space_before=Pt(8))

# Factory
card3 = add_shape_bg(slide, Inches(0.8), Inches(4.8), Inches(11.7), Inches(2.2), CARD_BG)
tf3 = card3.text_frame
tf3.word_wrap = True
set_text(tf3, "Agent Factory  (interaction/cli.py)", size=20, color=ACCENT_PURPLE, bold=True)
add_para(tf3, "", size=6, color=WHITE)
add_para(tf3, "create_agent(vlm_url, skills_dir, memory_dir):", size=14, color=ACCENT_CYAN, bold=True, space_before=Pt(8), font="Consolas")
add_para(tf3, "  1. Load defaults from config/agent.yaml", size=13, color=LIGHT_GRAY, space_before=Pt(4))
add_para(tf3, "  2. Create VLMClient, SkillRegistry, MemoryManager", size=13, color=LIGHT_GRAY, space_before=Pt(4))
add_para(tf3, "  3. Build and initialize Agent", size=13, color=LIGHT_GRAY, space_before=Pt(4))
add_para(tf3, "  4. Launch run_cli(agent) for interactive loop", size=13, color=LIGHT_GRAY, space_before=Pt(4))
add_para(tf3, "  5. Handle KeyboardInterrupt and fatal exceptions gracefully", size=13, color=LIGHT_GRAY, space_before=Pt(4))


# ═══════════════════════════════════════════════════
# SLIDE 14 — DEPLOYMENT & CONFIG
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Deployment & Configuration", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

# Dependencies
card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(5.5), Inches(3.0), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "Dependencies", size=20, color=ACCENT_CYAN, bold=True)

deps = [
    ("requests >= 2.28", "HTTP calls to VLM API + wttr.in"),
    ("pyyaml >= 6.0", "YAML config + memory frontmatter parsing"),
    ("playwright >= 1.40", "Browser automation (optional)"),
    ("readline (stdlib)", "CLI history persistence"),
    ("importlib (stdlib)", "Dynamic skill loading"),
    ("ImageMagick (system)", "Screenshot capture via import command"),
]
for name, desc in deps:
    add_para(tf, name, size=14, color=ACCENT_GREEN, bold=True, space_before=Pt(10), font="Consolas")
    add_para(tf, "    " + desc, size=13, color=LIGHT_GRAY, space_before=Pt(1))

# VLM deployment
card2 = add_shape_bg(slide, Inches(7.0), Inches(1.5), Inches(5.5), Inches(3.0), CARD_BG)
tf2 = card2.text_frame
tf2.word_wrap = True
set_text(tf2, "VLM Deployment", size=20, color=ACCENT_ORANGE, bold=True)
add_para(tf2, "", size=6, color=WHITE)
add_para(tf2, "llama-server serves Qwen3.6-35B on port 8008", size=14, color=WHITE, space_before=Pt(8))
add_para(tf2, "OpenAI-compatible /v1/chat/completions endpoint", size=14, color=WHITE, space_before=Pt(6))
add_para(tf2, "Supports tool calling schema (function calling)", size=14, color=WHITE, space_before=Pt(6))
add_para(tf2, "Health check via /health endpoint", size=14, color=WHITE, space_before=Pt(6))
add_para(tf2, "Model discovery via /v1/models", size=14, color=WHITE, space_before=Pt(6))

# Run command
card3 = add_shape_bg(slide, Inches(0.8), Inches(4.8), Inches(11.7), Inches(2.0), CARD_BG)
tf3 = card3.text_frame
tf3.word_wrap = True
set_text(tf3, "How to Run", size=20, color=ACCENT_GREEN, bold=True)
add_para(tf3, "", size=6, color=WHITE)
add_para(tf3, "1. Start llama-server:  llama-server --model Qwen3.6-35B --port 8008", size=15, color=WHITE, space_before=Pt(8), font="Consolas")
add_para(tf3, "2. Install deps:  pip install -r requirements.txt", size=15, color=WHITE, space_before=Pt(4), font="Consolas")
add_para(tf3, "3. Launch:  python main.py", size=15, color=WHITE, space_before=Pt(4), font="Consolas")


# ═══════════════════════════════════════════════════
# SLIDE 15 — DEMO WALKTHROUGH (1)
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Demo Walkthrough — Typical Interaction", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(4), ACCENT_CYAN)

# Simulated conversation
card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.3), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "Example: Weather Query", size=22, color=ACCENT_CYAN, bold=True)

demo = [
    ("User", ACCENT_GREEN, "What's the weather like in Hangzhou today?"),
    ("Agent", ACCENT_BLUE, "[Thought] User asks about weather. I should use weather_query skill."),
    ("Tool Call", ACCENT_ORANGE, "weather_query__get_weather(location='Hangzhou', format='normal')"),
    ("Observation", MID_GRAY, "🌤  Hangzhou: 22°C, Partly Cloudy, Humidity 65%, Wind 12 km/h NW"),
    ("Agent", ACCENT_BLUE, "Today in Hangzhou it's 22°C and partly cloudy, with 65% humidity and a light northwest wind at 12 km/h."),
]

for role, color, text in demo:
    add_para(tf, "", size=4, color=WHITE)
    badge = add_para(tf, f"  {role}", size=14, color=color, bold=True, space_before=Pt(8))
    add_para(tf, "  " + text, size=14, color=WHITE if role == "Agent" else LIGHT_GRAY, space_before=Pt(2))

add_para(tf, "", size=10, color=WHITE)
add_para(tf, "Memory Flow:  Memory recall checks if user has location preferences stored → injects if relevant",
    size=14, color=ACCENT_PURPLE, bold=True, space_before=Pt(8))


# ═══════════════════════════════════════════════════
# SLIDE 16 — DEMO WALKTHROUGH (2)
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Demo Walkthrough — Memory & Planning", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(4), ACCENT_CYAN)

card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.3), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "Example: Task Planning with Memory", size=22, color=ACCENT_CYAN, bold=True)

demo2 = [
    ("User", ACCENT_GREEN, "Help me plan a route to explore the West Lake area."),
    ("Memory", ACCENT_PURPLE, "[Recall] user_location → 'user lives in Hangzhou' — context confirmed"),
    ("Agent", ACCENT_BLUE, "[Thought] User wants to explore West Lake. Let me create a plan and use trajectory generation."),
    ("Tool Call", ACCENT_ORANGE, "task_planning__create_plan(goal='Explore West Lake scenic area', max_steps=5)"),
    ("Observation", MID_GRAY, "Plan: 1. Start at Broken Bridge → 2. Walk along Bai Causeway → 3. Visit Solitary Hill → 4. Take boat to Three Pools → 5. End at Leifeng Pagoda"),
    ("Tool Call", ACCENT_ORANGE, "trajectory_gen__generate_trajectory(action_type='navigate', target='West Lake', params=plan)"),
    ("Agent", ACCENT_BLUE, "Here's your West Lake exploration plan with 5 stops, starting from Broken Bridge and ending at Leifeng Pagoda."),
]

for role, color, text in demo2:
    add_para(tf, "", size=4, color=WHITE)
    add_para(tf, f"  {role}", size=14, color=color, bold=True, space_before=Pt(8))
    add_para(tf, "  " + text, size=14, color=LIGHT_GRAY, space_before=Pt(2))


# ═══════════════════════════════════════════════════
# SLIDE 17 — STRENGTHS & INNOVATION
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Strengths & Innovation Highlights", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3.5), ACCENT_CYAN)

strengths = [
    ("Modularity", ACCENT_CYAN,
     "Skills are completely isolated — each skill is a folder with its own docs and tools. "
     "Adding a new capability means dropping a new folder, zero changes to core code."),
    ("Local-First", ACCENT_GREEN,
     "Runs entirely on a local VLM — no cloud API calls, no data leaves the machine. "
     "Full privacy, low latency, works offline."),
    ("Persistent Memory", ACCENT_ORANGE,
     "File-based long-term memory with 4 types, auto-expiry, and VLM-driven recall. "
     "The agent learns about the user over time."),
    ("Progressive Disclosure", ACCENT_PURPLE,
     "Skill docs loaded on-demand via Skill() call, not all upfront. "
     "Saves context window, scales to dozens of skills."),
    ("Self-Correcting", ACCENT_RED,
     "Repeated call detection, anti-guessing rules, memory-first retrieval — "
     "the agent catches its own mistakes and course-corrects."),
    ("Production-Ready CLI", ACCENT_BLUE,
     "Color-coded output, CJK-aware wrapping, readline history, graceful error handling, "
     "and a clean welcome experience."),
]

y = 1.5
for title, color, desc in strengths:
    card = add_shape_bg(slide, Inches(0.8), Inches(y), Inches(11.7), Inches(0.85), CARD_BG)
    tf = card.text_frame
    tf.word_wrap = True
    set_text(tf, f"✦  {title}", size=18, color=color, bold=True)
    add_para(tf, desc, size=13, color=LIGHT_GRAY, space_before=Pt(2))
    y += 0.92


# ═══════════════════════════════════════════════════
# SLIDE 18 — FUTURE WORK
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Future Work & Roadmap", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

roadmap = [
    ("P0 — Memory Format Unification", ACCENT_RED,
     "Standardize all memory files with YAML frontmatter (key, type, tags, updated). "
     "Enable structured parsing instead of string-searching for metadata."),
    ("P1 — Memory Content Enrichment", ACCENT_ORANGE,
     "Add Why: and Useful for: sections to all memories. "
     "Explore tool-level auto-enrichment via VLM when saving bare facts."),
    ("P2 — Semantic Retrieval", ACCENT_GREEN,
     "Add embedding-based semantic search for memories instead of keyword-only matching. "
     "Enable similarity-based recall for more relevant retrieval."),
    ("P3 — Multi-Modal Skill Extension", ACCENT_CYAN,
     "Enhance env_description skill with video analysis, 3D scene understanding, "
     "and real-time camera feed processing."),
    ("P3 — Skill Auto-Discovery via VLM", ACCENT_PURPLE,
     "Allow the VLM to propose new skills based on user interaction patterns, "
     "then auto-generate SKILL.md scaffolds."),
    ("P3 — Web UI / API Layer", ACCENT_BLUE,
     "Add REST API endpoint and optional web-based chat interface "
     "alongside the CLI for broader accessibility."),
]

y = 1.5
for title, color, desc in roadmap:
    # Priority badge
    badge = add_shape_bg(slide, Inches(0.8), Inches(y + 0.05), Inches(0.6), Inches(0.3), color)
    set_text(badge.text_frame, title.split(" — ")[0], size=10, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

    add_textbox(slide, Inches(1.6), Inches(y), Inches(4), Inches(0.4),
        title.split(" — ", 1)[1] if " — " in title else title, size=17, color=color, bold=True)
    add_textbox(slide, Inches(1.6), Inches(y + 0.35), Inches(10.5), Inches(0.4),
        desc, size=13, color=LIGHT_GRAY)
    y += 0.9


# ═══════════════════════════════════════════════════
# SLIDE 19 — FILE STRUCTURE
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_textbox(slide, Inches(0.8), Inches(0.4), Inches(8), Inches(0.8),
    "Project Structure", size=36, color=WHITE, bold=True)
add_accent_line(slide, Inches(0.8), Inches(1.15), Inches(3), ACCENT_CYAN)

card = add_shape_bg(slide, Inches(0.8), Inches(1.5), Inches(11.7), Inches(5.3), CARD_BG)
tf = card.text_frame
tf.word_wrap = True
set_text(tf, "Directory Layout", size=20, color=ACCENT_CYAN, bold=True)

structure = """embodied_nav/
├── main.py                    # Entry point
├── README.md                  # Project documentation
├── requirements.txt           # Python dependencies
├── config/
│   ├── agent.yaml             # Agent + VLM configuration
│   └── __init__.py
├── core/
│   ├── llm_client.py          # VLM API client (VLMClient)
│   ├── skill.py               # BaseSkill + SkillRegistry
│   └── __init__.py
├── decision/
│   ├── agent.py               # ReAct loop (Agent class)
│   ├── memory_recall.py       # VLM-based memory recall
│   └── __init__.py
├── interaction/
│   ├── cli.py                 # CLI interface + agent factory
│   └── __init__.py
├── memory/
│   ├── memory_manager.py      # Short + Long term memory
│   └── __init__.py
├── skills/
│   ├── daily_chat/            # 10 skill folders
│   │   ├── SKILL.md
│   │   └── tools.py
│   ├── env_description/
│   ├── task_planning/
│   ├── trajectory_gen/
│   ├── browser_control/
│   ├── weather_query/
│   ├── memory_recall/
│   ├── memory_save/
│   ├── memory_delete/
│   └── memory_list/
└── utils/
    ├── styled_output.py       # Color-coded terminal output
    └── __init__.py"""

for line in structure.strip().split("\n"):
    add_para(tf, line, size=13, color=LIGHT_GRAY, space_before=Pt(2), font="Consolas")


# ═══════════════════════════════════════════════════
# SLIDE 20 — SUMMARY
# ═══════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide)

add_accent_line(slide, Inches(2), Inches(2.0), Inches(9.333), ACCENT_CYAN)

add_textbox(slide, Inches(2), Inches(2.3), Inches(9.333), Inches(1.0),
    "Summary", size=48, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

add_textbox(slide, Inches(2), Inches(3.3), Inches(9.333), Inches(2.5),
    """embodied_nav is a modular, skill-based embodied AI agent featuring:

    • 5-layer architecture with clean separation of concerns
    • 10 pluggable skills with progressive disclosure
    • Persistent file-based memory with VLM-driven recall
    • ReAct reasoning loop with self-correction
    • Local VLM deployment for privacy and low latency""",
    size=20, color=LIGHT_GRAY, alignment=PP_ALIGN.CENTER)

add_accent_line(slide, Inches(2), Inches(5.8), Inches(9.333), ACCENT_CYAN)

add_textbox(slide, Inches(2), Inches(6.2), Inches(9.333), Inches(0.5),
    "Thank You  ·  Questions?", size=24, color=ACCENT_CYAN, alignment=PP_ALIGN.CENTER)


# ── Save ──
output_path = "/workspace/wxd/Agent-Skill/agent/embodied_nav/presentation/embodied_nav_presentation.pptx"
os.makedirs(os.path.dirname(output_path), exist_ok=True)
prs.save(output_path)
print(f"Saved: {output_path}")
print(f"Total slides: {len(prs.slides)}")
