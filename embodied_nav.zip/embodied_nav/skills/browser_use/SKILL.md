---
name: browser_use
description: >
  Full autonomous web browsing via Browser-Use AI framework with local LLM.
  Use when the user needs to browse websites, search online, fill forms, extract web content,
  take screenshots, or perform complex multi-step web tasks. **Also use when the user needs
  real-time or current information** (news, stock prices, live results) that training data
  may not have. The sub-agent independently plans and executes browser actions — just pass
  the user's intent as natural language.
version: 2.0.0
---

# Browser Use — Autonomous Web Agent

Browser-Use is a **fully autonomous sub-agent** that independently plans navigation, clicks, inputs, and extraction on the web. You only need to pass a clear task description.

## Triggering

**Use when:**
- Opening URLs and interacting with web pages
- Searching online for real-time information (news, prices, results)
- Filling web forms, submitting data
- Extracting structured content from specific websites
- Taking screenshots of web pages
- Complex multi-step web tasks (login → navigate → extract)

## How It Works

You pass a **natural language task** to `run_browser_task(task)`. The browser-use sub-agent:

1. Opens the browser
2. Plans steps autonomously (navigate → click → input → extract)
3. Executes actions with its own LLM loop
4. Returns the final result

You do **NOT** decide individual actions (navigation URLs, click targets, extraction fields). The sub-agent handles all of that.

## Tool Usage

### `run_browser_task(task, url, max_steps)`

The only tool you need. Launches the full browser-use agent.

**Args:**
- `task`: Natural language task description. Be specific about what to find/extract/do.
- `url`: Optional URL to start from. If None, the agent will search or navigate on its own.
- `max_steps`: Maximum steps for the sub-agent (default: 20).

**Good task examples:**
- "在 Bing 搜索 'AI 最新新闻'，提取前 5 条结果的标题和链接"
- "访问 https://example.com/login，填写用户名 admin、密码 123456，然后登录"

**Bad task examples:**
- "查天气" (too vague — which city?)
- "上网看看" (no specific goal)

## Common Pitfalls

- **Each call takes 10-60s** due to local LLM inference + browser actions.
- **Be specific**: vague tasks cause the sub-agent to wander and waste steps.
- **Network restrictions**: Google and some sites may timeout. Bing and wttr.in work reliably.
- **Don't chain multiple calls** if one can do it all. Combine into a single task.
