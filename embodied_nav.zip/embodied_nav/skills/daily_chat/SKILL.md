---
name: daily_chat
description: >
  Handle casual conversation, answer general questions, and provide explanations.
  Use this skill when the user greets you, asks open-ended questions, requests explanations,
  wants to chat, or asks about concepts that don't require specialized tools.
  **Do NOT use this skill for real-time information** (dates, time, news, stock prices) —
  use `browser_control` for that instead.
  If the user mentions images, websites, planning, navigation, or embodied actions,
  use the specialized skill instead.
version: 1.3.0
---

# Daily Chat

General conversational skill using the VLM's built-in knowledge.

## ⚠️ Critical Rules

### Rule 1: NEVER fabricate real-time information

**If the user asks about dates, time, news, prices, or any information that changes over time:**
- Your training data is outdated. **Do NOT guess or fabricate answers from memory.**
- If `browser_control` is available and working: use it to fetch real-time info.
- If `browser_control` is unavailable: **honestly tell the user** you cannot access real-time information.
- Never invent dates, times, or facts — even if you feel confident.

### Rule 2: Always check memory for relevant context

**Before responding, call `memory_recall__recall_index()` to check if any stored memories are relevant:**
- User identity, preferences, location, relationships — these affect how you respond
- Prior conversations, preferences, or corrections — reference them naturally
- If no relevant memory exists, don't force it — just answer normally

**Example:** If user asks "推荐个餐厅" and you have a memory that they're in Hangzhou, suggest Hangzhou restaurants.

## Triggering

**Use this skill when:**
- The user greets you ("你好", "hi", "hello")
- The user asks general knowledge questions
- The user wants explanations, summaries, or opinions
- The user is chatting casually

**Do NOT use this skill when:**
- The user asks to browse/search a website → use `browser_control`
- The user asks to describe an image or screenshot → use `env_description`
- The user gives a multi-step task → use `task_planning`
- The user asks about movement/navigation → use `trajectory_gen`

## Tool Usage Notes

- `respond(query)`: Passes the query through. The actual response is generated
  by the VLM within this skill's execution — using the full conversation history
  for context (including any prior tool results like memory recalls or weather data).

## Response Guidelines

- Keep responses concise and helpful
- For embodied AI context, relate answers to the simulation environment when relevant
- If unsure about something, say so rather than guessing
