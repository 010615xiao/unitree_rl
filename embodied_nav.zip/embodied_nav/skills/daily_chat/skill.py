"""
Daily Chat Skill - Custom Implementation

Overrides execute() to call the VLM directly with conversation history,
bypassing the sub-agent tool selection loop. This is needed because the
respond tool is just a passthrough — the actual VLM response generation
happens here.
"""

import json
import re

from core.skill import BaseSkill

# Pattern to detect browser page content in observations
BROWSER_PAGE_RE = re.compile(r"\[BROWSER_PAGE:(\d+)\](.*?)\[/BROWSER_PAGE\]", re.DOTALL)


class DailyChatSkill(BaseSkill):
    """Daily chat skill that delegates response generation to the VLM."""

    def execute(self, intent: str, vlm_client=None, messages: list[dict] | None = None,
                chat_system: str = "", **kwargs) -> str:
        """Generate a conversational response using the VLM with full context.

        Unlike other skills, this does NOT run a sub-agent loop. Instead,
        it calls the VLM directly with the conversation history so the model
        knows what happened in the ReAct loop (memory recalls, tool results, etc.).

        Args:
            intent: The user's message/question
            vlm_client: VLMClient instance
            messages: Conversation history from the main agent
            chat_system: System prompt for daily_chat mode
        """
        if vlm_client is None:
            return f"[FINAL_ANSWER]Error: vlm_client required for daily_chat"

        # Build chat messages with system prompt + conversation history
        chat_messages = [{"role": "system", "content": chat_system}]

        if messages:
            for msg in messages:
                if msg["role"] == "system":
                    continue  # Already added our chat_system
                chat_messages.append(msg)

        vlm_response = vlm_client.chat(chat_messages, tools=None)

        # Guard: 8B models may return tool call JSON even when tools=None.
        # This means the model is trying to call a tool — but daily_chat has no
        # sub-agent loop. Return an honest error so the main agent can retry.
        try:
            data = json.loads(vlm_response.strip())
            if isinstance(data, list) and data:
                first = data[0]
                if isinstance(first, dict):
                    if "function" in first:
                        tool_name = first["function"].get("name", "")
                    elif first.get("type") == "function" and "arguments" in first:
                        raw_args = first.get("arguments", {})
                        args = raw_args if isinstance(raw_args, dict) else {}
                        if isinstance(raw_args, str):
                            try:
                                args = json.loads(raw_args)
                            except json.JSONDecodeError:
                                args = {}
                        tool_name = args.get("skill_name", "unknown")
                    else:
                        tool_name = ""

                    if "use_skill" in tool_name or "skill" in tool_name.lower():
                        # Model wants to switch skill — return error so main agent retries
                        return f"[FINAL_ANSWER]I cannot directly access that information. The browser tool is currently unavailable, so I cannot fetch real-time data like the current date or time."
                    # It's a regular tool call (not use_skill) — can't execute here
                    return f"[FINAL_ANSWER]I encountered a technical issue and cannot complete your request at this time. Please try again later."
        except (json.JSONDecodeError, TypeError, KeyError, IndexError):
            pass

        return f"[FINAL_ANSWER]{vlm_response}"
