---
name: env_description
description: >
  Analyze images, screenshots, and visual observations from the environment using VLM vision.
  Use when the user asks to describe an image, analyze a screenshot, or identify objects.
version: 1.3.0
---

# Environment Description

Uses the VLM's vision capabilities to analyze images and describe what it sees.

## Triggering

**Use this skill when:**
- The user asks to describe an image or photo
- The user says "look at this", "what do you see", "describe the scene"
- Another skill just took a screenshot (e.g., `browser_control.screenshot_page()` or
  `env_description.screenshot_env()`) — you MUST call this skill to interpret the screenshot
- The user asks to identify objects, text, or layout in a visual scene
- You need to understand the current simulated environment

**Do NOT use this skill when:**
- The user just wants a casual chat → use `daily_chat`
- The user asks to browse a website (without analyzing the result) → use `browser_control`
- The user asks about planning or movement → use `task_planning` or `trajectory_gen`

## Tool Usage Notes

- `describe_image(image_path)`: Sends the image to the VLM for analysis.
  Returns a detailed text description of what the VLM sees.
- `screenshot_env(display_id)`: Captures the current Xvfb virtual display.
  After screenshot, you MUST call `describe_image()` to interpret what was captured.

## Required Information Before Calling

**You MUST have a valid image before calling `describe_image()`.**

- If the user says "看看这个" or "describe this" but didn't provide an image →
  **do NOT call the tool**. Ask: "请提供图片的路径。"
- If the user says "看看屏幕" or "截个图" →
  call `screenshot_env()` first, then `describe_image()` with the output path.
- If the user provides a file path to an image →
  call `describe_image()` with that path directly.
- If you're unsure whether the image exists or where it is →
  ask the user to specify the path.

## Common Pitfalls

- **Screenshots are just files, not analysis.** After taking a screenshot, always follow up
  with `describe_image()` to actually understand what the image shows.
- **Image path must be valid.** The VLM reads images from the `/workspace/wxd/Agent/images/` directory.
- **Be specific about what to look for.** Context window is limited — ask "what objects are on the table?"
  not just "describe".
