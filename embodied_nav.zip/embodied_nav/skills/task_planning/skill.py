"""
Task Planning Skill - Custom Implementation

Overrides execute() to directly generate a plan JSON without entering
the sub-agent tool selection loop. Plan execution requires other skills
(browser_control, trajectory_gen, etc.) which are outside this skill's scope,
so the plan must be returned to the main VLM for further action.
"""

import json
from core.skill import BaseSkill


class TaskPlanningSkill(BaseSkill):
    """Task planning skill that returns a structured plan, not a sub-agent result."""

    def execute(self, intent: str, vlm_client=None, messages: list[dict] | None = None,
                **kwargs) -> str:
        """Generate a structured plan JSON from the user's intent.

        Unlike the default sub-agent flow, this skill does NOT loop to pick
        concrete tools — it directly calls create_plan and returns the result.
        The main VLM will then decide how to execute each plan step.

        Args:
            intent: The user's goal or task description
            vlm_client: VLMClient instance (used for plan generation)
            messages: Conversation history (for context)
        """
        create_plan = self.tools.get("create_plan")
        if not create_plan:
            return "Error: create_plan tool not found in task_planning skill"

        # Extract max_steps from intent if specified, otherwise use default
        max_steps = 10
        try:
            plan_result = create_plan(goal=intent, max_steps=max_steps)
        except TypeError:
            # Fallback if tool signature differs
            plan_result = create_plan(goal=intent)

        plan_str = str(plan_result)

        # Try to parse and validate the plan JSON for a cleaner output
        try:
            plan_data = json.loads(plan_str)
            formatted = json.dumps(plan_data, indent=2, ensure_ascii=False)
            steps = plan_data.get("steps", [])
            summary = f"Plan generated with {len(steps)} steps:\n\n{formatted}"
        except (json.JSONDecodeError, TypeError):
            summary = plan_str

        return summary
