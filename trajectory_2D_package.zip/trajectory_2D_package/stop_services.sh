#!/bin/bash
# 统一停止脚本：一键停止 SAM2、GroundingDINO 和 Depth-Anything-v3 服务

echo "=========================================="
echo "🛑 停止所有服务..."
echo "=========================================="

# 查找并停止进程
echo ""
echo "正在停止 SAM2 服务 (端口 20020)..."
pkill -f "sam2_server.py.*--port 20020" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ SAM2 服务已停止"
else
    echo "⚠️  未找到 SAM2 服务"
fi

echo ""
echo "正在停止 GroundingDINO 服务 (端口 20021)..."
pkill -f "grounding_dino_server.py.*--port 20021" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ GroundingDINO 服务已停止"
else
    echo "⚠️  未找到 GroundingDINO 服务"
fi

echo ""
echo "正在停止 Depth-Anything-v3 服务 (端口 20022)..."
pkill -f "depth_anything_v3_server.py.*--port 20022" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ Depth-Anything-v3 服务已停止"
else
    echo "⚠️  未找到 Depth-Anything-v3 服务"
fi

# 额外清理：检查端口是否仍被占用
echo ""
echo "🔍 检查端口状态..."

check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
        return 0  # 端口被占用
    else
        return 1  # 端口空闲
    fi
}

if check_port 20020; then
    echo "⚠️  端口 20020 仍被占用，尝试强制停止..."
    kill -9 $(lsof -ti:20020) 2>/dev/null
fi

if check_port 20021; then
    echo "⚠️  端口 20021 仍被占用，尝试强制停止..."
    kill -9 $(lsof -ti:20021) 2>/dev/null
fi

if check_port 20022; then
    echo "⚠️  端口 20022 仍被占用，尝试强制停止..."
    kill -9 $(lsof -ti:20022) 2>/dev/null
fi

echo ""
echo "=========================================="
echo "✅ 所有服务已停止"
echo "=========================================="
