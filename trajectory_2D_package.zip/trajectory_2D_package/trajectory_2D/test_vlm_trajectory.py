#!/usr/bin/env python3
"""
测试 VLM 输出导航轨迹点序列
要求：
1. 轨迹点必须严格限制在地板上
2. 输出格式：[[x1, y1], [x2, y2], ...]
3. 将预测的轨迹点绘制在图片上保存
"""

import base64
import json
import os
import re
import cv2
import numpy as np
from openai import OpenAI
from datetime import datetime

# 配置
DEFAULT_IMAGE_PATH = "/workspace/wxd/Agent/images/trajectory_2D_results/frame_0110/frame_0110_depth_masks.png"
VLM_BASE_URL = "http://localhost:8000/v1"
VLM_MODEL = "RoboBrain2.0-7B"

# 起点坐标（固定值）
START_POINT = (310, 450)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)

# 目标点坐标（可选，由 run_pipeline.py 动态更新）
TARGET_POINT = [375, 173]  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)  # (x, y)


def encode_image_to_base64(image_path: str) -> str:
    """将图像编码为 base64"""
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")


def parse_trajectory(response_text: str) -> list:
    """从 VLM 响应中解析轨迹点"""
    # 尝试匹配 [[x1, y1], [x2, y2], ...] 格式
    pattern = r'\[\s*\[\s*\d+\.?\d*\s*,\s*\d+\.?\d*\s*\][\s*,\s*\[\s*\d+\.?\d*\s*,\s*\d+\.?\d*\s*\]]*\s*\]'
    matches = re.findall(pattern, response_text)

    if matches:
        # 取最后一个匹配（通常是主要答案）
        traj_str = matches[-1]
        try:
            trajectory = json.loads(traj_str)
            # 验证格式
            if isinstance(trajectory, list) and all(
                isinstance(pt, list) and len(pt) == 2 and
                all(isinstance(c, (int, float)) for c in pt)
                for pt in trajectory
            ):
                # 去重：移除连续重复的点
                deduped = [trajectory[0]]
                for pt in trajectory[1:]:
                    if pt != deduped[-1]:
                        deduped.append(pt)
                return deduped
        except json.JSONDecodeError:
            pass

    # 尝试匹配 (x, y) 格式
    pattern2 = r'\(\s*(\d+\.?\d*)\s*,\s*(\d+\.?\d*)\s*\)'
    matches2 = re.findall(pattern2, response_text)
    if matches2:
        trajectory = [[float(x), float(y)] for x, y in matches2]
        # 去重：移除连续重复的点
        deduped = [trajectory[0]]
        for pt in trajectory[1:]:
            if pt != deduped[-1]:
                deduped.append(pt)
        return deduped

    # 尝试匹配 x,y 格式（每行一个点）
    lines = response_text.strip().split('\n')
    trajectory = []
    for line in lines:
        line = line.strip()
        if ',' in line:
            parts = line.replace('[', '').replace(']', '').replace('(', '').replace(')', '').split(',')
            if len(parts) == 2:
                try:
                    x, y = float(parts[0].strip()), float(parts[1].strip())
                    trajectory.append([x, y])
                except ValueError:
                    pass

    if len(trajectory) >= 2:
        # 去重：移除连续重复的点
        deduped = [trajectory[0]]
        for pt in trajectory[1:]:
            if pt != deduped[-1]:
                deduped.append(pt)
        return deduped

    return None


def visualize_trajectory_on_image(
    image_path: str,
    trajectory: list,
    floor_mask_path: str = None,
    output_path: str = None,
    start_point: tuple = None,
    validation_result: dict = None,
    target_point: list = None
) -> str:
    """
    在图像上绘制轨迹（参考 trajectory_planning_agent.py 风格）
    - 起点：绿色大圆圈 + "S" 标签
    - 终点：红色大圆圈 + "T" 标签
    - 中间点：带编号的小圆圈
    - 轨迹线：带箭头的渐变颜色

    Args:
        image_path: 原始图像路径
        trajectory: 轨迹点列表 [[x1, y1], [x2, y2], ...]
        floor_mask_path: floor 掩码图像路径（用于验证轨迹点在地板上）
        output_path: 输出图像路径
        start_point: 起点坐标 (x, y)
        validation_result: 验证结果字典
        target_point: 目标点坐标 (x, y)

    Returns:
        输出图像路径
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]

    # 创建叠加层
    overlay = image_rgb.copy()

    # 加载 floor 掩码（如果有）
    floor_mask = None
    if floor_mask_path and os.path.exists(floor_mask_path):
        # 尝试从 floor 点云可视化图中提取 mask
        mask_img = cv2.imread(floor_mask_path)
        if mask_img is not None:
            # 绿色区域是 floor
            lower_green = np.array([0, 100, 0])
            upper_green = np.array([100, 255, 100])
            mask = cv2.inRange(mask_img, lower_green, upper_green)
            floor_mask = mask > 0
            print(f"✅ 加载 floor 掩码：{floor_mask.sum()} 个像素")

    # 绘制轨迹线和点
    if len(trajectory) >= 2:
        traj_points = [(int(pt[0]), int(pt[1])) for pt in trajectory]

        # 创建验证查找表（如果有验证结果）
        on_floor_set = None
        if validation_result and validation_result.get("success"):
            on_floor_set = set(item["index"] for item in validation_result["on_floor"])
            off_floor_set = set(item["index"] for item in validation_result["off_floor"])

        # 绘制轨迹线段（带箭头和渐变颜色）
        for i in range(len(traj_points) - 1):
            t = i / (len(traj_points) - 1)
            # 渐变颜色：从绿色到红色
            segment_color = (
                int(0 * (1 - t) + 255 * t),      # R
                int(255 * (1 - t) + 0 * t),      # G
                int(0 * (1 - t) + 0 * t)         # B
            )
            # 绘制线段
            cv2.line(overlay, traj_points[i], traj_points[i+1], segment_color, 3)
            # 绘制箭头
            arrow_length = 12
            arrow_angle = 25
            angle = np.arctan2(traj_points[i+1][1] - traj_points[i][1], 
                              traj_points[i+1][0] - traj_points[i][0])
            arrow_pt1 = (
                int(traj_points[i+1][0] - arrow_length * np.cos(angle - np.deg2rad(arrow_angle))),
                int(traj_points[i+1][1] - arrow_length * np.sin(angle - np.deg2rad(arrow_angle)))
            )
            arrow_pt2 = (
                int(traj_points[i+1][0] - arrow_length * np.cos(angle + np.deg2rad(arrow_angle))),
                int(traj_points[i+1][1] - arrow_length * np.sin(angle + np.deg2rad(arrow_angle)))
            )
            cv2.line(overlay, traj_points[i+1], arrow_pt1, segment_color, 3)
            cv2.line(overlay, traj_points[i+1], arrow_pt2, segment_color, 3)

        # 绘制轨迹点
        for i, pt in enumerate(traj_points):
            if i == 0:
                # 起点：绿色大圆圈 + "S" 标签
                cv2.circle(overlay, pt, 12, (0, 255, 0), -1)
                cv2.circle(overlay, pt, 15, (0, 200, 0), 2)
                cv2.putText(overlay, "S", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            elif i == len(traj_points) - 1:
                # 终点：红色大圆圈 + "T" 标签
                cv2.circle(overlay, pt, 12, (0, 0, 255), -1)
                cv2.circle(overlay, pt, 15, (0, 0, 200), 2)
                cv2.putText(overlay, "T", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            else:
                # 中间点：带编号的小圆圈
                # 根据验证结果着色
                if on_floor_set is not None:
                    if i in on_floor_set:
                        circle_color = (0, 255, 0)  # 绿色：在地板上
                    elif i in off_floor_set:
                        circle_color = (0, 0, 255)  # 红色：不在地板上
                    else:
                        circle_color = (200, 200, 200)  # 灰色：未知
                else:
                    circle_color = (200, 200, 200)  # 灰色
                
                cv2.circle(overlay, pt, 8, circle_color, -1)
                cv2.circle(overlay, pt, 10, (150, 150, 150), 1)
                cv2.putText(overlay, str(i), (pt[0] - 5, pt[1] + 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

    # 绘制目标点标记（如果提供了目标点坐标）
    if target_point:
        tx, ty = int(target_point[0]), int(target_point[1])
        # 橙色圆圈表示目标位置 (BGR: 0, 140, 255)
        cv2.circle(overlay, (tx, ty), 10, (0, 140, 255), -1)
        cv2.circle(overlay, (tx, ty), 12, (0, 100, 200), 2)

    # 注意：用户要求不在图像上添加任何文字或图例
    # 不添加统计信息
    # 不添加起点标记
    
    # 保存
    if output_path is None:
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.dirname(image_path)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(output_dir, f"{base_name}_trajectory_{timestamp}.png")
    
    output_bgr = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 轨迹可视化已保存：{output_path}")
    
    return output_path


def query_vlm_trajectory(image_base64: str, client: OpenAI, model: str, prompt: str) -> dict:
    """查询 VLM 获取轨迹"""
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}},
                    ],
                }
            ],
            max_tokens=1000,
            temperature=0.1,
        )
        
        return {
            "success": True,
            "response": response.choices[0].message.content,
            "error": None
        }
        
    except Exception as e:
        return {
            "success": False,
            "response": None,
            "error": str(e)
        }


def validate_trajectory_on_floor(trajectory: list, floor_mask: np.ndarray, image_path: str, skip_first_point: bool = True) -> dict:
    """
    验证轨迹点是否在地板区域上

    Args:
        trajectory: 轨迹点列表 [[x1, y1], [x2, y2], ...]
        floor_mask: 地板掩码 (H, W) 布尔数组
        image_path: 原始图像路径（用于获取尺寸）
        skip_first_point: 是否跳过起点验证（起点是用户指定的固定位置，不是 VLM 规划的）

    Returns:
        验证结果字典
    """
    image = cv2.imread(image_path)
    if image is None:
        return {"success": False, "error": "无法读取图像"}

    h, w = image.shape[:2]

    results = {
        "success": True,
        "total_points": len(trajectory),
        "on_floor": [],
        "off_floor": [],
        "out_of_bounds": [],
        "floor_coverage": 0.0,
        "details": []
    }

    for i, pt in enumerate(trajectory):
        x, y = int(pt[0]), int(pt[1])

        # 检查是否超出图像边界
        if x < 0 or x >= w or y < 0 or y >= h:
            results["out_of_bounds"].append({"index": i, "point": [x, y]})
            results["details"].append({
                "index": i,
                "point": [x, y],
                "status": "out_of_bounds",
                "on_floor": False
            })
            continue

        # 跳过起点验证（起点是用户指定的固定位置）
        if skip_first_point and i == 0:
            results["on_floor"].append({"index": i, "point": [x, y], "note": "start_point"})
            results["details"].append({
                "index": i,
                "point": [x, y],
                "status": "start_point_skipped",
                "on_floor": True
            })
            continue

        # 检查是否在地板掩码上
        if floor_mask is not None:
            is_on_floor = bool(floor_mask[y, x])
        else:
            is_on_floor = False

        if is_on_floor:
            results["on_floor"].append({"index": i, "point": [x, y]})
        else:
            results["off_floor"].append({"index": i, "point": [x, y]})

        results["details"].append({
            "index": i,
            "point": [x, y],
            "status": "on_floor" if is_on_floor else "off_floor",
            "on_floor": is_on_floor
        })

    # 计算地板覆盖率（排除起点）
    valid_points = len(trajectory) - len(results["out_of_bounds"])
    
    # 检测是否有起点标记
    has_start_point = any(item.get("note") == "start_point" for item in results["on_floor"])
    
    if skip_first_point and has_start_point:
        valid_points -= 1  # 排除起点
    
    # 计算在地板上的点数（排除起点）
    on_floor_count = len(results["on_floor"])
    if skip_first_point and has_start_point:
        on_floor_count -= 1  # 排除起点
    
    if valid_points > 0:
        results["floor_coverage"] = on_floor_count / valid_points
    else:
        results["floor_coverage"] = 0.0

    return results


def test_trajectory_prediction(image_path: str, floor_mask_path: str = None):
    """测试 VLM 轨迹预测"""

    print("="*70)
    print("🤖 VLM 导航轨迹预测测试")
    print("="*70)
    print(f"图像路径：{image_path}")
    print(f"VLM 模型：{VLM_MODEL}")
    print("="*70)

    # 检查文件
    if not os.path.exists(image_path):
        print(f"❌ 图像文件不存在：{image_path}")
        return None

    # 编码图像
    print("\n🔄 编码图像...")
    image_base64 = encode_image_to_base64(image_path)
    print(f"✅ 图像编码完成")

    # 获取图像尺寸
    image = cv2.imread(image_path)
    h, w = image.shape[:2]
    print(f"📐 图像尺寸：{w}x{h}")

    # 加载 floor 掩码（如果有）
    floor_mask = None
    if floor_mask_path and os.path.exists(floor_mask_path):
        print(f"\n📍 加载 floor 掩码：{floor_mask_path}")
        # 从 depth_masks 图像中提取绿色区域作为 floor 掩码
        mask_img = cv2.imread(floor_mask_path)
        if mask_img is not None:
            # 使用 HSV 颜色空间提取绿色
            hsv = cv2.cvtColor(mask_img, cv2.COLOR_BGR2HSV)

            # 绿色的 HSV 范围（更宽松）
            # H: 35-85 (绿色色相), S: 40-255 (饱和度), V: 50-255 (亮度)
            lower_green = np.array([35, 40, 50])
            upper_green = np.array([85, 255, 255])
            mask = cv2.inRange(hsv, lower_green, upper_green)
            floor_mask = mask > 0
            print(f"✅ Floor 掩码像素数：{floor_mask.sum()} ({100*floor_mask.sum()/(h*w):.1f}%)")

            # 调试：显示 Top 颜色
            unique_colors = np.unique(mask_img.reshape(-1, 3), axis=0)
            if len(unique_colors) > 0:
                print(f"   图像中唯一颜色数量：{len(unique_colors)}")
                # 检查是否有绿色系颜色
                green_pixels = ((mask_img[:, :, 1] > 100) &
                               (mask_img[:, :, 0] < 150) &
                               (mask_img[:, :, 2] < 150))
                print(f"   绿色系像素数：{green_pixels.sum()}")
        else:
            print("⚠️ 无法加载 floor 掩码")

    # 创建客户端
    client = OpenAI(base_url=VLM_BASE_URL, api_key="not-needed")

    # 设计 Prompt
    # 构建目标位置信息（如果有 2D 坐标）
    target_info = ""
    target_point_str = ""
    if TARGET_POINT:
        target_info = f"""
**Target Position (2D Pixel Coordinates)**
The target object's position is at: **({TARGET_POINT[0]}, {TARGET_POINT[1]})**
- x = {TARGET_POINT[0]} (horizontal, from left edge)
- y = {TARGET_POINT[1]} (vertical, from top edge)
"""
        target_point_str = f"{TARGET_POINT[0]}, {TARGET_POINT[1]}"

    prompt = f"""You are a robot navigation system. Analyze this depth segmentation image and plan a feasible walking path.

**Color Semantics:**
- **Green region**: Floor / walkable area (ONLY valid region for robot movement)
- **Other colors (purple, blue background)**: Background and obstacles (NOT walkable)

**IMPORTANT: Start Point**
The robot's starting position is at pixel coordinate: **({START_POINT[0]}, {START_POINT[1]})**
- x = {START_POINT[0]} (horizontal, from left edge)
- y = {START_POINT[1]} (vertical, from top edge)
{target_info}
**Task:**
Plan a trajectory from the start point to the target object.

**Requirements:**
1. **The first trajectory point MUST be the start point: [{START_POINT[0]}, {START_POINT[1]}]**
2. **The last trajectory point MUST be the target position: [{target_point_str}]**
3. All trajectory points must be **strictly within the green floor region**
4. The trajectory must head towards and end at the target position
5. Avoid all non-green regions (they are obstacles/background)
6. The trajectory should be dense and continuous
7. You are allowed to make turns or large angle changes when necessary to avoid obstacles

**Output Format:**
Your trajectory answer should be formatted as a list of tuples, i.e. [[x1, y1], [x2, y2], ...], where each tuple contains the x and y coordinates of a point.

**Constraints:**
- x coordinate range: [0, {w}]
- y coordinate range: [0, {h}]
- Number of points: 8-15
- ALL points must fall on green pixels

**Answer Format:**
<analysis>
Briefly describe: start position, target direction, floor region distribution
</analysis>

<trajectory>
[[x1, y1], [x2, y2], ..., [xn, yn]]
</trajectory>

<explanation>
Explain why all trajectory points are on the green floor region
</explanation>
"""

    print("\n" + "="*70)
    print("📝 VLM Prompt:")
    print("="*70)
    print(prompt)
    print("="*70)

    print("\n🔄 查询 VLM...")
    result = query_vlm_trajectory(image_base64, client, VLM_MODEL, prompt)
    
    if not result["success"]:
        print(f"❌ VLM 查询失败：{result['error']}")
        return None
    
    print("\n✅ VLM 原始回答:")
    print("-"*70)
    print(result["response"])
    print("-"*70)
    
    # 解析轨迹
    trajectory = parse_trajectory(result["response"])
    
    if trajectory is None:
        print("\n❌ 无法从响应中解析轨迹点")
        print("尝试手动提取...")
        # 显示可能的轨迹部分
        if "<trajectory>" in result["response"]:
            traj_part = result["response"].split("<trajectory>")[1].split("</trajectory>")[0] if "</trajectory>" in result["response"] else result["response"].split("<trajectory>")[1]
            print(f"轨迹部分：{traj_part}")
        return None
    
    print(f"\n✅ 解析成功！轨迹点数：{len(trajectory)}")
    print(f"轨迹点列表：{trajectory}")
    
    # 验证轨迹点是否在图像范围内
    valid_points = []
    invalid_points = []
    for pt in trajectory:
        x, y = pt
        if 0 <= x < w and 0 <= y < h:
            valid_points.append(pt)
        else:
            invalid_points.append(pt)
            print(f"⚠️ 点 ({x}, {y}) 超出图像范围")
    
    if invalid_points:
        print(f"⚠️ {len(invalid_points)} 个点超出范围，已过滤")
        trajectory = valid_points
    
    if len(trajectory) < 2:
        print("❌ 有效轨迹点不足 2 个")
        return None
    
    # ========== 地板约束验证 ==========
    print("\n" + "="*70)
    print("🔍 地板约束验证")
    print("="*70)

    validation_result = validate_trajectory_on_floor(trajectory, floor_mask, image_path)

    if validation_result["success"]:
        on_floor_count = len(validation_result["on_floor"])
        off_floor_count = len(validation_result["off_floor"])
        out_of_bounds_count = len(validation_result["out_of_bounds"])
        coverage = validation_result["floor_coverage"]

        # 计算起点标记
        start_point_item = next((item for item in validation_result["on_floor"] if item.get("note") == "start_point"), None)
        has_start_point = start_point_item is not None
        
        # 实际验证的点数（排除起点）
        validated_points = validation_result["total_points"] - (1 if has_start_point else 0) - out_of_bounds_count

        print(f"\n总轨迹点数：{validation_result['total_points']}")
        if has_start_point:
            print(f"📍 起点 (跳过验证): ({start_point_item['point'][0]}, {start_point_item['point'][1]})")
        print(f"✅ 在地板上：{on_floor_count - (1 if has_start_point else 0)} 个点 ({100*coverage:.1f}%)")

        if off_floor_count > 0:
            print(f"❌ 不在地板上：{off_floor_count} 个点")
            for item in validation_result["off_floor"]:
                print(f"   - 点 {item['index']}: ({item['point'][0]}, {item['point'][1]})")

        if out_of_bounds_count > 0:
            print(f"⚠️ 超出边界：{out_of_bounds_count} 个点")
            for item in validation_result["out_of_bounds"]:
                print(f"   - 点 {item['index']}: ({item['point'][0]}, {item['point'][1]})")

        # 评估结果
        print("\n" + "-"*70)
        if coverage >= 0.8:
            print("✅ 验证通过：轨迹点大部分在地板上")
        elif coverage >= 0.5:
            print("⚠️ 验证警告：部分轨迹点不在地板上")
        else:
            print("❌ 验证失败：大部分轨迹点不在地板上")
    else:
        print(f"❌ 验证失败：{validation_result.get('error', '未知错误')}")
        coverage = 0
    
    # 计算起点（使用固定值）
    start_point = START_POINT
    
    # 可视化
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    output_dir = os.path.dirname(image_path)
    output_path = os.path.join(output_dir, f"{base_name}_vlm_trajectory.png")

    print("\n🎨 绘制轨迹...")
    vis_path = visualize_trajectory_on_image(
        image_path,
        trajectory,
        floor_mask_path,
        output_path,
        start_point,
        validation_result if validation_result else None,
        TARGET_POINT
    )
    
    # 保存轨迹数据
    traj_data = {
        "image_path": image_path,
        "image_size": {"width": w, "height": h},
        "start_point": start_point,
        "trajectory": trajectory,
        "num_points": len(trajectory),
        "timestamp": datetime.now().isoformat(),
        "model": VLM_MODEL,
        "vlm_response": result["response"],
        "validation": validation_result if validation_result else None
    }
    
    traj_json_path = os.path.join(output_dir, f"{base_name}_trajectory_data.json")
    with open(traj_json_path, "w", encoding="utf-8") as f:
        json.dump(traj_data, f, ensure_ascii=False, indent=2)
    print(f"📄 轨迹数据已保存：{traj_json_path}")
    
    print("\n" + "="*70)
    print("✅ 测试完成!")
    print("="*70)
    print(f"起点：{start_point}")
    print(f"轨迹点数：{len(trajectory)}")
    print(f"轨迹可视化：{vis_path}")
    print(f"轨迹数据：{traj_json_path}")
    
    return traj_data


def main():
    import sys
    
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
    else:
        image_path = DEFAULT_IMAGE_PATH
    
    # floor mask 与 depth_masks 是同一张图
    floor_mask_path = image_path
    
    print(f"起点坐标：{START_POINT}")
    test_trajectory_prediction(image_path, floor_mask_path)


if __name__ == "__main__":
    main()
