#!/usr/bin/env python3
"""
简化的新视角渲染模块 - 用于 trajectory_2D run_pipeline.py

与 render_3d_view.py 的区别：
1. 轨迹点都在地板上 → 直接从深度图查询深度值
2. 朝向计算简化 → 主要考虑水平方向的旋转（yaw）
3. 不需要复杂的 pitch 计算 → 地板上的点朝向基本水平

坐标系统：
- 世界坐标系：以原始相机为原点，X 向右，Y 向下，Z 向前
- 轨迹点：2D 像素坐标 (pixel_x, pixel_y) + 深度值 depth_m

运行示例：
    python render_trajectory_view.py \
        --depth_masks /workspace/wxd/Agent/images/trajectory_2D_results/frame_0017/frame_0017_depth_masks.png \
        --trajectory_data /workspace/wxd/Agent/images/trajectory_2D_results/frame_0017/frame_0017_depth_masks_trajectory_data_filtered.json \
        --original_image /workspace/wxd/Agent/images/frames/frame_0017.png \
        --view_index -1
"""

import argparse
import json
import os
import sys
import numpy as np
import cv2
from typing import Dict, List, Optional, Tuple
from datetime import datetime


class TrajectoryViewRenderer:
    """简化的轨迹点新视角渲染器"""

    def __init__(self, output_dir: Optional[str] = None):
        self.output_dir = output_dir
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

    def get_depth_from_depth_map(
        self,
        depth_map: np.ndarray,
        pixel_x: float,
        pixel_y: float,
        use_bilinear: bool = True
    ) -> float:
        """
        从深度图查询指定像素位置的深度值

        Args:
            depth_map: 深度图 [H, W]
            pixel_x: 像素 x 坐标
            pixel_y: 像素 y 坐标
            use_bilinear: 是否使用双线性插值

        Returns:
            深度值（米）
        """
        h, w = depth_map.shape

        if use_bilinear:
            # 双线性插值
            x0, y0 = int(np.floor(pixel_x)), int(np.floor(pixel_y))
            x1, y1 = x0 + 1, y0 + 1

            # 边界检查
            x0 = max(0, min(x0, w - 1))
            x1 = max(0, min(x1, w - 1))
            y0 = max(0, min(y0, h - 1))
            y1 = max(0, min(y1, h - 1))

            # 插值权重
            wx = pixel_x - x0
            wy = pixel_y - y0

            # 双线性插值
            depth = (
                depth_map[y0, x0] * (1 - wx) * (1 - wy) +
                depth_map[y0, x1] * wx * (1 - wy) +
                depth_map[y1, x0] * (1 - wx) * wy +
                depth_map[y1, x1] * wx * wy
            )
        else:
            # 最近邻
            x, y = int(round(pixel_x)), int(round(pixel_y))
            x = max(0, min(x, w - 1))
            y = max(0, min(y, h - 1))
            depth = depth_map[y, x]

        return float(depth)

    def compute_camera_orientation(
        self,
        current_point: np.ndarray,
        next_point: Optional[np.ndarray],
        prev_point: Optional[np.ndarray]
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        计算相机坐标系基向量（简化的朝向计算）

        由于轨迹点在地板上，朝向主要是水平方向的旋转。

        Args:
            current_point: 当前点 3D 坐标 [x, y, z]
            next_point: 下一个点 3D 坐标（可选）
            prev_point: 前一个点 3D 坐标（可选）

        Returns:
            (x_axis, y_axis, z_axis) 相机坐标系基向量
        """
        # 确定朝向方向
        if next_point is not None:
            # 朝向前进方向
            direction = next_point - current_point
        elif prev_point is not None:
            # 朝向后一个点（往回看）
            direction = prev_point - current_point
        else:
            # 孤立点，默认朝前
            direction = np.array([0, 0, 1])

        # 归一化
        norm = np.linalg.norm(direction)
        if norm > 1e-6:
            direction = direction / norm

        # Z 轴 = 朝向方向
        z_axis = direction

        # X 轴 = 水平向右（与 Z 轴和世界 Y 轴垂直）
        # 世界 Y 轴向下 [0, 1, 0]
        x_axis = np.cross([0, 1, 0], z_axis)
        x_norm = np.linalg.norm(x_axis)
        if x_norm > 1e-6:
            x_axis = x_axis / x_norm
        else:
            # Z 轴接近垂直方向，使用默认 X 轴
            x_axis = np.array([1, 0, 0])

        # Y 轴 = Z × X（右手定则）
        y_axis = np.cross(z_axis, x_axis)
        y_axis = y_axis / np.linalg.norm(y_axis)

        return x_axis, y_axis, z_axis

    def render_view(
        self,
        point_cloud: np.ndarray,
        original_image: np.ndarray,
        depth_map: np.ndarray,
        trajectory: List[List[float]],
        view_index: int = -1,
        yaw_offset: float = 0.0,
        intrinsics: Optional[np.ndarray] = None,
        image_path: Optional[str] = None,
        camera_height_offset: float = 0.5  # 默认抬高 0.5 米
    ) -> Optional[Dict[str, str]]:
        """
        从轨迹点渲染新视角

        Args:
            point_cloud: 点云 [H, W, 3]
            original_image: 原始 RGB 图像 [H, W, 3]
            depth_map: 深度图 [H, W]
            trajectory: 轨迹点列表 [[pixel_x, pixel_y], ...]
            view_index: 要渲染的轨迹点索引（-1 表示最后一个点）
            yaw_offset: 额外的 yaw 偏移（度）
            intrinsics: 相机内参 [3, 3]（可选）
            image_path: 原始图像路径（用于生成输出文件名，可选）
            camera_height_offset: 相机高度偏移（米），默认 0.5 米模拟人眼高度

        Returns:
            输出文件路径字典
        """
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        print("\n" + "=" * 70)
        print("🎨 轨迹点新视角渲染")
        print("=" * 70)

        # 获取目标轨迹点
        target_idx = view_index if view_index >= 0 else len(trajectory) + view_index
        target_idx = max(0, min(target_idx, len(trajectory) - 1))

        if target_idx < 0 or target_idx >= len(trajectory):
            print(f"⚠️ 轨迹点索引 {view_index} 超出范围，跳过渲染")
            return None

        target_pixel = trajectory[target_idx]
        pixel_x, pixel_y = target_pixel

        # 从深度图查询深度值
        depth = self.get_depth_from_depth_map(depth_map, pixel_x, pixel_y)
        print(f"   渲染位置：轨迹点 #{target_idx}")
        print(f"   像素坐标：({pixel_x:.1f}, {pixel_y:.1f})")
        print(f"   深度值：{depth:.3f} 米")

        # 获取图像尺寸
        h_orig, w_orig = original_image.shape[:2]
        h_pc, w_pc = point_cloud.shape[:2]

        print(f"   原始图像：{w_orig}x{h_orig}")
        print(f"   点云尺寸：{w_pc}x{h_pc}")

        # 相机内参
        if intrinsics is not None:
            fx = intrinsics[0, 0] * w_orig
            fy = intrinsics[1, 1] * h_orig
            cx = intrinsics[0, 2] * w_orig
            cy = intrinsics[1, 2] * h_orig
            fov_x = 2 * np.arctan(w_orig / (2 * fx)) * 180 / np.pi
            print(f"   相机内参：fx={fx:.1f}, fy={fy:.1f}, cx={cx:.1f}, cy={cy:.1f}")
            print(f"   FOV: {fov_x:.1f}°")
        else:
            # 默认 FOV=60°
            focal_length = w_orig / (2 * np.tan(np.deg2rad(60) / 2))
            fx = fy = focal_length
            cx, cy = w_orig / 2, h_orig / 2
            print(f"   相机内参（默认 FOV=60°）：fx=fy={focal_length:.1f}, cx={cx:.1f}, cy={cy:.1f}")

        # ============================================================
        # 计算轨迹点 3D 坐标
        # ============================================================
        cam_x = (pixel_x - cx) * depth / fx
        cam_y = (pixel_y - cy) * depth / fy
        cam_z = depth

        # 抬高相机位置（模拟人眼/机器人摄像头高度）
        cam_y -= camera_height_offset  # Y 轴向下为正，减去高度即向上移动

        current_point_3d = np.array([cam_x, cam_y, cam_z])
        print(f"   3D 坐标：({cam_x:.3f}, {cam_y:.3f}, {cam_z:.3f}) 米 (相机抬高 {camera_height_offset} 米)")

        # ============================================================
        # 计算前后点 3D 坐标（用于朝向计算）
        # ============================================================
        next_point_3d = None
        prev_point_3d = None

        if target_idx < len(trajectory) - 1:
            next_pixel = trajectory[target_idx + 1]
            next_depth = self.get_depth_from_depth_map(depth_map, next_pixel[0], next_pixel[1])
            next_x = (next_pixel[0] - cx) * next_depth / fx
            next_y = (next_pixel[1] - cy) * next_depth / fy
            next_z = next_depth
            next_point_3d = np.array([next_x, next_y, next_z])

        if target_idx > 0:
            prev_pixel = trajectory[target_idx - 1]
            prev_depth = self.get_depth_from_depth_map(depth_map, prev_pixel[0], prev_pixel[1])
            prev_x = (prev_pixel[0] - cx) * prev_depth / fx
            prev_y = (prev_pixel[1] - cy) * prev_depth / fy
            prev_z = prev_depth
            prev_point_3d = np.array([prev_x, prev_y, prev_z])

        # ============================================================
        # 计算朝向（简化的水平朝向）
        # ============================================================
        # 由于轨迹点在地板上，我们让相机保持水平朝向（不看地面）
        
        # 计算水平朝向方向（忽略 Y 分量，保持水平）
        if next_point_3d is not None:
            # 前进方向（忽略垂直分量）
            direction = next_point_3d - current_point_3d
            direction[1] = 0  # 忽略 Y 分量，保持水平
        elif prev_point_3d is not None:
            # 后视方向（忽略垂直分量）
            direction = prev_point_3d - current_point_3d
            direction[1] = 0  # 忽略 Y 分量，保持水平
        else:
            # 孤立点，默认朝前
            direction = np.array([0, 0, 1])

        # 归一化
        norm = np.linalg.norm(direction)
        if norm > 1e-6:
            direction = direction / norm

        # Z 轴 = 水平朝向方向
        z_axis = direction

        # X 轴 = 水平向右（与世界 Y 轴垂直）
        x_axis = np.cross([0, 1, 0], z_axis)
        x_norm = np.linalg.norm(x_axis)
        if x_norm > 1e-6:
            x_axis = x_axis / x_norm
        else:
            # Z 轴接近垂直方向，使用默认 X 轴
            x_axis = np.array([1, 0, 0])

        # Y 轴 = Z × X（右手定则）
        y_axis = np.cross(z_axis, x_axis)
        y_axis = y_axis / np.linalg.norm(y_axis)

        print(f"   水平朝向：({z_axis[0]:.3f}, {z_axis[1]:.3f}, {z_axis[2]:.3f})")

        # 应用 yaw 偏移
        if yaw_offset != 0:
            print(f"   应用 yaw 偏移：{yaw_offset}°")
            # 在水平面内旋转 Z 轴
            yaw_rad = np.radians(yaw_offset)
            cos_y, sin_y = np.cos(yaw_rad), np.sin(yaw_rad)

            # 旋转矩阵（绕 Y 轴旋转）
            # 注意：世界坐标系 Y 轴向下，旋转方向需要调整
            z_axis_rotated = np.array([
                z_axis[0] * cos_y + z_axis[2] * sin_y,
                z_axis[1],  # Y 分量不变
                -z_axis[0] * sin_y + z_axis[2] * cos_y
            ])
            z_axis = z_axis_rotated / np.linalg.norm(z_axis_rotated)

            # 重新计算 X 和 Y 轴
            x_axis = np.cross([0, 1, 0], z_axis)
            if np.linalg.norm(x_axis) > 1e-6:
                x_axis = x_axis / np.linalg.norm(x_axis)
            else:
                x_axis = np.array([1, 0, 0])
            y_axis = np.cross(z_axis, x_axis)
            y_axis = y_axis / np.linalg.norm(y_axis)

        print(f"\n   相机基向量:")
        print(f"      X: ({x_axis[0]:.3f}, {x_axis[1]:.3f}, {x_axis[2]:.3f})")
        print(f"      Y: ({y_axis[0]:.3f}, {y_axis[1]:.3f}, {y_axis[2]:.3f})")
        print(f"      Z: ({z_axis[0]:.3f}, {z_axis[1]:.3f}, {z_axis[2]:.3f})")

        # 构造旋转矩阵
        R = np.array([x_axis, y_axis, z_axis])

        # ============================================================
        # 渲染：点云变换 + 投影
        # ============================================================
        print(f"\n   开始渲染...")

        # 1. 重塑点云
        points = point_cloud.reshape(-1, 3).copy()

        # 2. 平移
        points[:, 0] -= cam_x
        points[:, 1] -= cam_y
        points[:, 2] -= cam_z

        # 3. 旋转
        points_camera = points @ R.T

        # 4. 投影
        valid_mask = points_camera[:, 2] > 0.01
        points_valid = points_camera[valid_mask]

        u = (points_valid[:, 0] * fx / points_valid[:, 2] + cx).astype(int)
        v = (points_valid[:, 1] * fy / points_valid[:, 2] + cy).astype(int)

        # 过滤在图像外的点
        in_image = (u >= 0) & (u < w_orig) & (v >= 0) & (v < h_orig)
        u = u[in_image]
        v = v[in_image]
        points_valid = points_valid[in_image]

        print(f"   有效点数：{np.sum(valid_mask)} / {len(points)} ({100*np.sum(valid_mask)/len(points):.1f}%)")
        print(f"   图像内点数：{len(u)} / {np.sum(valid_mask)} ({100*len(u)/np.sum(valid_mask):.1f}%)")

        # 5. 获取颜色
        original_indices = np.where(valid_mask)[0]
        original_indices = original_indices[in_image]

        u_orig = original_indices % w_pc
        v_orig = original_indices // w_pc

        image_rgb = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        point_colors = image_rgb[v_orig, u_orig]

        # 6. 渲染（Z-buffer）
        rendered_image = np.zeros((h_orig, w_orig, 3), dtype=np.float32)
        depth_rendered = np.zeros((h_orig, w_orig), dtype=np.float32)

        depths = points_valid[:, 2]
        sort_indices = np.argsort(depths)[::-1]

        draw_count = 0
        for idx in sort_indices:
            ui, vi = u[idx], v[idx]
            depth_val = depths[idx]
            color = point_colors[idx]

            if depth_rendered[vi, ui] == 0 or depth_val < depth_rendered[vi, ui]:
                rendered_image[vi, ui] = color
                depth_rendered[vi, ui] = depth_val
                draw_count += 1

        print(f"   绘制像素数：{draw_count} / {w_orig * h_orig} ({100*draw_count/(w_orig*h_orig):.2f}%)")
        print(f"   空洞率：{100*(1 - draw_count/(w_orig*h_orig)):.1f}%")

        # 7. 颜色增强
        gamma = 0.55
        rendered_image = np.power(rendered_image, 1/gamma)
        rendered_image = rendered_image * 1.2
        rendered_image = np.clip(rendered_image, 0, 1)

        print(f"   颜色增强：gamma={gamma}, 对比度=1.2x")

        # 8. 保存结果
        if image_path:
            base_name = os.path.splitext(os.path.basename(image_path))[0]
        else:
            base_name = "rendered_view"
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        offset_str = f"_yaw{int(yaw_offset)}" if yaw_offset != 0 else ""

        output_rendered = os.path.join(
            self.output_dir or os.path.dirname(original_image),
            f"{base_name}_view{target_idx}_rendered_{timestamp}.png"
        )
        output_depth = os.path.join(
            self.output_dir or os.path.dirname(original_image),
            f"{base_name}_view{target_idx}_depth_{timestamp}.png"
        )

        # 保存渲染图像
        rendered_bgr = (rendered_image * 255).astype(np.uint8)
        rendered_bgr = cv2.cvtColor(rendered_bgr, cv2.COLOR_RGB2BGR)
        cv2.imwrite(output_rendered, rendered_bgr)
        print(f"   ✅ 渲染图像：{output_rendered}")

        # 保存深度图
        depth_vis = np.zeros((h_orig, w_orig), dtype=np.uint8)
        valid_depth = depth_rendered[depth_rendered > 0]
        if len(valid_depth) > 0:
            depth_min, depth_max = valid_depth.min(), valid_depth.max()
            depth_norm = (depth_rendered - depth_min) / (depth_max - depth_min + 1e-6) * 255
            depth_vis[depth_rendered > 0] = depth_norm[depth_rendered > 0].astype(np.uint8)
        depth_vis_colored = cv2.applyColorMap(depth_vis, cv2.COLORMAP_INFERNO)
        cv2.imwrite(output_depth, depth_vis_colored)
        print(f"   ✅ 深度图：{output_depth}")

        return {
            "rendered_image": output_rendered,
            "depth_map": output_depth,
            "view_index": target_idx,
            "pixel_coords": [pixel_x, pixel_y],
            "depth": depth
        }


def load_depth_map_from_npy(depth_npy_path: str) -> Optional[np.ndarray]:
    """
    从 numpy 格式加载真实深度图

    Args:
        depth_npy_path: .npy 文件路径

    Returns:
        深度图数组，失败返回 None
    """
    if not os.path.exists(depth_npy_path):
        return None

    try:
        depth_map = np.load(depth_npy_path)
        print(f"✅ 从 .npy 加载深度图：{depth_npy_path}")
        print(f"   深度范围：{depth_map.min():.3f} - {depth_map.max():.3f} 米")
        return depth_map
    except Exception as e:
        print(f"❌ 加载深度图失败：{e}")
        return None


def load_depth_map_from_image(depth_masks_path: str) -> Optional[np.ndarray]:
    """
    从 depth_masks 图像加载深度图（备用方案）

    Args:
        depth_masks_path: depth_masks 图像路径

    Returns:
        深度图数组，失败返回 None
    """
    if not os.path.exists(depth_masks_path):
        print(f"❌ 文件不存在：{depth_masks_path}")
        return None

    # 读取图像
    img = cv2.imread(depth_masks_path)
    if img is None:
        print(f"❌ 无法读取图像：{depth_masks_path}")
        return None

    # 转换为灰度图作为深度图（或者从 JSON 加载真实深度）
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 注意：这里使用的是简化的深度图
    # 实际应该从 main.py 生成的深度数据中加载真实深度值
    print(f"⚠️ 从 depth_masks 加载深度图（灰度近似）")
    print(f"   深度范围：{gray.min()} - {gray.max()}")

    return gray.astype(np.float32) / 255.0 * 5.0  # 假设深度范围 0-5 米


def main():
    parser = argparse.ArgumentParser(description="从轨迹点渲染新视角图像")
    parser.add_argument("--depth_masks", type=str, required=True,
                        help="depth_masks 图像路径")
    parser.add_argument("--trajectory_data", type=str, required=True,
                        help="轨迹数据 JSON 文件路径")
    parser.add_argument("--original_image", type=str, required=True,
                        help="原始 RGB 图像路径")
    parser.add_argument("--point_cloud_path", type=str, default=None,
                        help="点云 PLY 文件路径（可选，如果不提供则从深度图生成）")
    parser.add_argument("--view_index", type=int, default=-1,
                        help="要渲染的轨迹点索引（-1=最后一个点，-2=倒数第二个点）")
    parser.add_argument("--yaw_offset", type=float, default=0.0,
                        help="额外的 yaw 偏移（度）")
    parser.add_argument("--output_dir", type=str, default=None,
                        help="输出目录")

    args = parser.parse_args()

    # 加载轨迹数据
    print("=" * 70)
    print("📊 加载轨迹数据")
    print("=" * 70)

    with open(args.trajectory_data, 'r') as f:
        trajectory_data = json.load(f)

    trajectory = trajectory_data.get('trajectory', [])
    print(f"   轨迹点数：{len(trajectory)}")

    if len(trajectory) < 2:
        print("❌ 轨迹点数量不足")
        return

    # 加载原始图像
    original_image = cv2.imread(args.original_image)
    if original_image is None:
        print(f"❌ 无法读取原始图像：{args.original_image}")
        return
    print(f"✅ 原始图像：{args.original_image}")

    # 加载深度图
    depth_map = load_depth_map_from_image(args.depth_masks)
    if depth_map is None:
        print("❌ 无法加载深度图")
        return

    # 生成/加载点云
    if args.point_cloud_path and os.path.exists(args.point_cloud_path):
        # 从 PLY 加载点云
        print(f"✅ 从 PLY 加载点云：{args.point_cloud_path}")
        # TODO: 实现 PLY 加载
        point_cloud = None
    else:
        # 从深度图生成简化的点云
        print("🔧 从深度图生成点云...")
        h, w = depth_map.shape

        # 假设 FOV=60°
        focal_length = w / (2 * np.tan(np.deg2rad(60) / 2))
        cx, cy = w / 2, h / 2

        # 反投影
        y, x = np.meshgrid(np.arange(h), np.arange(w), indexing='ij')
        cam_x = (x - cx) * depth_map / focal_length
        cam_y = (y - cy) * depth_map / focal_length
        cam_z = depth_map

        point_cloud = np.stack([cam_x, cam_y, cam_z], axis=-1)
        print(f"✅ 点云已生成：{w}x{h}")

    if point_cloud is None:
        print("❌ 点云加载失败")
        return

    # 渲染
    renderer = TrajectoryViewRenderer(output_dir=args.output_dir)

    result = renderer.render_view(
        point_cloud=point_cloud,
        original_image=original_image,
        depth_map=depth_map,
        trajectory=trajectory,
        view_index=args.view_index,
        yaw_offset=args.yaw_offset
    )

    if result:
        print("\n" + "=" * 70)
        print("✅ 渲染完成!")
        print("=" * 70)
        print(f"渲染图像：{result['rendered_image']}")
        print(f"深度图：{result['depth_map']}")


if __name__ == "__main__":
    main()
