#!/usr/bin/env python3
"""
SAM2 客户端 - 通过 HTTP API 连接 SAM2 服务器
用于获取目标物体的分割掩码

SAM2 服务器 API:
- GET  /health     - 健康检查
- GET  /test       - 测试接口
- POST /infer      - 图像分割推理（支持 point 和 box 提示）
"""

import requests
import numpy as np
from typing import Dict, List, Optional, Tuple
import base64
import io
from PIL import Image
import cv2


class SAM2Client:
    """SAM2 服务器客户端"""

    def __init__(self, host: str = "localhost", port: int = 20020, timeout: int = 60):
        """
        初始化 SAM2 客户端

        Args:
            host: SAM2 服务器主机地址
            port: SAM2 服务器端口
            timeout: 请求超时时间（秒）
        """
        self.host = host
        self.port = port
        self.base_url = f"http://{host}:{port}"
        self.timeout = timeout

        print(f"🔗 SAM2 客户端已初始化：{self.base_url}")

    def health_check(self) -> bool:
        """检查 SAM2 服务器状态"""
        try:
            response = requests.get(f"{self.base_url}/health", timeout=5)
            if response.status_code == 200:
                result = response.json()
                print(f"✅ SAM2 服务器在线：{result.get('model_name', 'unknown')} @ {result.get('device', 'unknown')}")
                return True
            return False
        except Exception as e:
            print(f"⚠️ SAM2 服务器检查失败：{e}")
            return False

    def predict_with_box(
        self,
        image_path: str,
        box: List[float],
        conf: float = 0.5
    ) -> Optional[np.ndarray]:
        """
        使用边界框预测掩码

        Args:
            image_path: 图像路径
            box: 边界框 [x1, y1, x2, y2]
            conf: 置信度阈值

        Returns:
            掩码 (2D numpy array) 或 None
        """
        try:
            # 构建请求（使用 image_path 而不是 base64）
            payload = {
                "image_path": image_path,
                "box": box,
                "conf": conf
            }

            # 调用 API
            response = requests.post(
                f"{self.base_url}/infer",
                json=payload,
                timeout=self.timeout
            )

            if response.status_code == 200:
                result = response.json()
                
                # 解码掩码
                mask_b64 = result["mask"]
                mask_bytes = base64.b64decode(mask_b64)
                
                # 从 PNG 解码掩码
                mask = cv2.imdecode(np.frombuffer(mask_bytes, np.uint8), cv2.IMREAD_GRAYSCALE)
                
                if mask is None:
                    print("❌ 掩码解码失败")
                    return None
                
                # 转换为布尔掩码
                mask = (mask > 0).astype(bool)
                
                print(f"✅ 掩码已生成，尺寸：{mask.shape[0]}x{mask.shape[1]}, 掩码像素数：{mask.sum()}")
                return mask
            else:
                print(f"❌ 预测失败：{response.text}")
                return None

        except Exception as e:
            print(f"❌ 预测异常：{e}")
            import traceback
            traceback.print_exc()
            return None

    def predict_with_points(
        self,
        image_path: str,
        point_coords: List[List[float]],
        point_labels: Optional[List[int]] = None,
        conf: float = 0.5
    ) -> Optional[np.ndarray]:
        """
        使用点提示预测掩码

        Args:
            image_path: 图像路径
            point_coords: 点坐标列表 [[x1, y1], [x2, y2], ...]
            point_labels: 点标签列表 [1, 0, ...] (1=前景点，0=背景点)
            conf: 置信度阈值

        Returns:
            掩码 (2D numpy array) 或 None
        """
        try:
            # 构建请求（使用 image_path 而不是 base64）
            payload = {
                "image_path": image_path,
                "point_coords": point_coords,
                "point_labels": point_labels or [1] * len(point_coords),
                "conf": conf
            }

            # 调用 API
            response = requests.post(
                f"{self.base_url}/infer",
                json=payload,
                timeout=self.timeout
            )

            if response.status_code == 200:
                result = response.json()
                
                # 解码掩码
                mask_b64 = result["mask"]
                mask_bytes = base64.b64decode(mask_b64)
                mask = cv2.imdecode(np.frombuffer(mask_bytes, np.uint8), cv2.IMREAD_GRAYSCALE)
                
                if mask is None:
                    print("❌ 掩码解码失败")
                    return None
                
                mask = (mask > 0).astype(bool)
                print(f"✅ 掩码已生成，尺寸：{mask.shape[0]}x{mask.shape[1]}, 掩码像素数：{mask.sum()}")
                return mask
            else:
                print(f"❌ 预测失败：{response.text}")
                return None

        except Exception as e:
            print(f"❌ 预测异常：{e}")
            return None

    def close(self):
        """关闭客户端"""
        print("🔒 SAM2 客户端已关闭")


def mask_from_base64(mask_b64: str) -> np.ndarray:
    """
    从 base64 解码掩码

    Args:
        mask_b64: base64 编码的掩码

    Returns:
        2D numpy array (bool)
    """
    mask_bytes = base64.b64decode(mask_b64)
    mask = cv2.imdecode(np.frombuffer(mask_bytes, np.uint8), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise ValueError("掩码解码失败")
    return (mask > 0).astype(bool)


def image_to_base64(image_path: str) -> str:
    """
    将图像转换为 base64

    Args:
        image_path: 图像路径

    Returns:
        base64 字符串
    """
    with open(image_path, "rb") as f:
        image_bytes = f.read()
    return base64.b64encode(image_bytes).decode('utf-8')
