# 轨迹点新视角渲染功能

## 概述

为 `run_pipeline.py` 添加了简化的新视角渲染功能，可以从轨迹点视角渲染场景。

## 新增功能

### 1. 相机高度抬高
- 默认抬高 0.5 米，模拟人眼/机器人摄像头高度
- 避免视角被地面遮挡
- 可通过 `--camera_height` 参数调整

### 2. 水平朝向
- 相机朝向保持水平（不看地面）
- 忽略垂直分量，只保留水平方向

### 3. 轨迹点自动插值
- 当过滤后的轨迹点少于 10 个时，自动插值
- 按距离比例分配插值点
- 验证插值点在地板上
- 避免插值点过密

## 与 `render_3d_view.py` 的区别

| 特性 | `render_3d_view.py` | `render_trajectory_view.py` |
|------|---------------------|----------------------------|
| 应用场景 | 通用 3D 点云新视角渲染 | trajectory_2D 项目专用 |
| 深度获取 | 从点云 3D 坐标计算 | 直接从深度图查询像素深度 |
| 朝向计算 | 复杂（pitch + yaw） | 简化（主要 yaw 旋转） |
| 轨迹点位置 | 可能在空中 | 全部在地板上 |

## 使用方法

### 在 Pipeline 中启用渲染

```bash
# 渲染单个轨迹点（默认倒数第二个点）
python run_pipeline.py \
    --image /workspace/wxd/Agent/images/frames/frame_0017.png \
    --instruction "垃圾桶" \
    --filter_floor \
    --render_view \
    --view_index -2 \
    --camera_height 0.5

# 渲染所有轨迹点的新视角（从起点到倒数第二个点）
python run_pipeline.py \
    --image /workspace/wxd/Agent/images/frames/frame_0017.png \
    --instruction "垃圾桶" \
    --filter_floor \
    --render_all_views \
    --camera_height 0.5
```

### 参数说明

- `--render_view`: 启用新视角渲染
- `--render_all_views`: 渲染所有轨迹点的新视角（从起点到倒数第二个点）
- `--view_index`: 要渲染的轨迹点索引
  - `-1`: 最后一个点（终点）
  - `-2`: 倒数第二个点
  - `0`: 第一个点（起点）
  - 正整数：指定索引
- `--yaw_offset`: 额外的 yaw 偏移角度（度），用于微调视角方向
- `--camera_height`: 相机高度偏移（米），默认 0.5 米

### 独立使用渲染模块

```bash
python render_trajectory_view.py \
    --depth_masks /workspace/wxd/Agent/images/trajectory_2D_results/frame_0017/frame_0017_depth_masks.png \
    --trajectory_data /workspace/wxd/Agent/images/trajectory_2D_results/frame_0017/frame_0017_depth_masks_trajectory_data_filtered.json \
    --original_image /workspace/wxd/Agent/images/frames/frame_0017.png \
    --view_index -2 \
    --yaw_offset 15
```

## 输出文件

渲染后会生成两个文件：

1. **渲染图像**: `{base_name}_view{index}_rendered_{timestamp}.png`
   - 从轨迹点视角渲染的 RGB 图像
   
2. **深度图**: `{base_name}_view{index}_depth_{timestamp}.png`
   - 渲染视角的深度可视化（COLORMAP_INFERNO）

## 核心原理

### 1. 深度获取（简化）

由于轨迹点都在地板上，直接从深度图查询对应像素的深度值：

```python
def get_depth_from_depth_map(self, depth_map, pixel_x, pixel_y):
    # 双线性插值查询深度
    depth = depth_map[y, x]  # 简化示例
    return depth
```

### 2. 相机位置抬高

默认抬高 0.5 米，避免视角被地面遮挡：

```python
# Y 轴向下为正，减去高度即向上移动
cam_y -= camera_height_offset
current_point_3d = np.array([cam_x, cam_y, cam_z])
```

### 3. 水平朝向计算

地板上的轨迹点，相机保持水平朝向（不看地面）：

```python
def compute_horizontal_orientation(current_point, next_point):
    # 前进方向（忽略 Y 分量，保持水平）
    direction = next_point - current_point
    direction[1] = 0  # 忽略垂直分量
    
    # Z 轴 = 水平朝向方向
    z_axis = normalize(direction)
    
    # X 轴 = 水平向右
    x_axis = normalize(cross([0, 1, 0], z_axis))
    
    # Y 轴 = Z × X（右手定则）
    y_axis = cross(z_axis, x_axis)
    
    return x_axis, y_axis, z_axis
```

### 4. 轨迹点自动插值

当轨迹点少于 10 个时，按距离比例插值：

```python
def interpolate_trajectory(trajectory, floor_mask, min_points=10):
    # 1. 计算相邻点之间的距离
    # 2. 按距离比例分配插值点到各段
    # 3. 验证插值点在地板上
    # 4. 避免插值点过密（最小间距约束）
    return interpolated_trajectory
```

### 5. 渲染流程

1. **查询深度**: 从深度图获取轨迹点深度值
2. **反投影**: 2D 像素 → 3D 相机坐标
3. **计算朝向**: 根据前后轨迹点确定相机朝向
4. **构造旋转矩阵**: R = [x_axis, y_axis, z_axis]
5. **点云变换**: 平移 + 旋转
6. **透视投影**: 3D → 2D 图像平面
7. **Z-buffer 渲染**: 处理遮挡关系
8. **颜色增强**: gamma 校正 + 对比度调整

## 输出示例

```
================================================================================
🎨 步骤 5: 新视角渲染
================================================================================
✅ 从 .npy 加载深度图：.../frame_0017_depth_map.npy
   深度范围：0.408 - 3.621 米
🔧 从深度图生成点云...
✅ 点云已生成：640x480

======================================================================
🎨 轨迹点新视角渲染
======================================================================
   渲染位置：轨迹点 #4
   像素坐标：(75.0, 360.0)
   深度值：0.559 米
   3D 坐标：(-0.247, 0.121, 0.559) 米
   前进行方向：下一个点 (-0.277, 0.084, 0.542) 米
   
   相机基向量:
      X: (-0.487, 0.000, 0.873)
      Y: (-0.634, 0.688, -0.354)
      Z: (-0.601, -0.726, -0.335)
   
   开始渲染...
   有效点数：65769 / 307200 (21.4%)
   图像内点数：5850 / 65769 (8.9%)
   绘制像素数：5850 / 307200 (1.90%)
   空洞率：98.1%
   
   ✅ 渲染图像：.../frame_0017_view4_rendered_20260327_073608.png
   ✅ 深度图：.../frame_0017_view4_depth_20260327_073608.png
```

## 技术细节

### 相机内参

默认使用 FOV=60°：
```python
focal_length = width / (2 * tan(60° / 2))
fx = fy = focal_length
cx, cy = width / 2, height / 2
```

### 颜色增强

- **Gamma 校正**: gamma=0.55（提亮暗部）
- **对比度增强**: 1.2x

### 坐标系

- **世界坐标系**: 原始相机为原点
  - X 轴：向右
  - Y 轴：向下
  - Z 轴：向前

- **轨迹点坐标**: 2D 像素坐标 + 深度值
  - `pixel_x, pixel_y`: 图像像素坐标
  - `depth_m`: 米制深度值

## 注意事项

1. **深度图精度**: 渲染质量依赖于 Depth-Anything-v3 的深度估计精度
2. **空洞问题**: 由于遮挡关系，渲染图像会有空洞（通常 >95% 空洞率）
3. **相机高度**: 
   - 默认 0.5 米模拟人眼高度
   - 可通过 `--camera_height` 调整
   - 太高会导致视角不自然，太低仍可能被地面遮挡
4. **水平朝向**: 相机始终保持水平，不会看向地面或天空
5. **yaw 偏移**: 可使用 `--yaw_offset` 微调视角方向（±15° 以内效果较好）
6. **轨迹点插值**:
   - 自动触发：过滤后点数 < 10 时
   - 插值点验证：必须在地板上
   - 密度约束：避免插值点过密（最小间距 7.5 像素）
   - 如果地板掩码不连续，可能无法达到 10 个点

## 文件修改清单

- `trajectory_2D/render_trajectory_view.py`: 新增简化的渲染模块
- `trajectory_2D/run_pipeline.py`: 
  - 添加 `--render_view`、`--render_all_views`、`--camera_height` 选项
  - 添加 `interpolate_trajectory()` 插值函数
  - 集成渲染流程和自动插值逻辑
- `trajectory_2D/pointcloud_saver.py`: 保存深度图为 .npy 格式
- `trajectory_2D/RENDER_TRAJECTORY_VIEW.md`: 使用文档
