# Trajectory 2D - 点云分割模块

根据检测目标，分别提取和保存场景点云、目标点云和地板点云。

## 📁 项目结构

```
trajectory_2D/
├── main.py                      # 主流程入口
├── sam2_client.py               # SAM2 服务器客户端
├── pointcloud_segmentation.py   # 点云分割模块
├── pointcloud_saver.py          # 点云保存和可视化
└── README.md                    # 本文档
```

## 🚀 快速开始

### 前置条件

1. **启动 SAM2 服务器** (必须先启动):
```bash
python spagent/external_experts/SAM2/sam2_server.py \
  --checkpoint_path checkpoints/sam2/sam2.1_l.pt \
  --port 20020
```

2. **确保其他服务可用**:
   - VLM 服务 (RoboBrain2.5-8B 或 Qwen3-VL-8B-Instruct) @ `http://localhost:8000/v1`
   - GroundingDINO 模型 @ `checkpoints/grounding_dino/`
   - MoGe2 模型 @ `checkpoints/moge2/moge-2-vitl-normal/model.pt`

### 基本使用

```bash
cd /workspace/wxd/Agent/Spagent/spagent/checkpoints/trajectory_2D

# 方式 1: 交互式运行（推荐）
python main.py

# 方式 2: 命令行指定所有参数
python main.py --image /path/to/image.png --instruction "远处的垃圾桶"

# 方式 3: 只指定图像，指令交互输入
python main.py --image /path/to/image.png

# 方式 4: 只指定指令，使用默认图像
python main.py --instruction "近处的椅子"
```

### 测试示例

```bash
# 使用测试图像运行
python main.py --image /workspace/wxd/Agent/images/test_6.png --instruction "远处的垃圾桶"
```

### 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--image` | 输入图像路径 | (必需) |
| `--instruction` | 自然语言指令 | "远处的垃圾桶" |
| `--output-dir` | 输出目录 | `/workspace/wxd/Agent/images/trajectory_2D_results` |
| `--sam2-host` | SAM2 服务器主机 | `localhost` |
| `--sam2-port` | SAM2 服务器端口 | `20020` |

## 📊 输出文件

运行成功后，输出目录将包含以下文件：

```
trajectory_2D_results/
└── {image_name}/
    ├── {image_name}_full_pointcloud.ply      # 完整场景点云
    ├── {image_name}_target_pointcloud.ply    # 目标物体点云
    ├── {image_name}_floor_pointcloud.ply     # 地板点云
    ├── {image_name}_scene_pointcloud.ply     # 场景点云 (背景)
    ├── {image_name}_3d_pointcloud.png        # 3D 点云可视化
    ├── {image_name}_2d_projection.png        # 2D 投影可视化
    ├── {image_name}_depth_masks.png          # 深度图 + 掩码
    └── {image_name}_metadata.json            # 元数据
```

### PLY 文件格式

每个 PLY 文件包含:
- `x, y, z`: 3D 坐标 (相机坐标系，单位：米)
- `red, green, blue`: RGB 颜色 (0-255)

### 元数据 JSON

```json
{
  "image_path": "/path/to/image.png",
  "instruction": "远处的垃圾桶",
  "intent": {
    "target_objects": ["garbage can"],
    "depth_attribute": "farthest"
  },
  "detection": {
    "box": [x1, y1, x2, y2],
    "confidence": 0.85,
    "phrase": "garbage can"
  },
  "pointcloud_stats": {
    "full": 1228800,
    "target": 15420,
    "floor": 89350,
    "scene": 1124030
  },
  "saved_files": { ... }
}
```

## 🔧 模块说明

### 1. VLM 意图理解 (`main.py: VLMIntentClient`)

解析用户指令，提取:
- 目标物体 (英文)
- 深度属性 (nearest/farthest)
- 位置属性 (left/right/center)
- 序数词 (1st, 2nd, 3rd...)

### 2. GroundingDINO 检测 (`main.py: GroundingDINODetector`)

检测目标物体的 2D 边界框，输出:
- 边界框坐标 (xyxy)
- 置信度
- 检测短语

### 3. SAM2 分割 (`sam2_client.py`)

通过 HTTP API 连接 SAM2 服务器，获取目标的精确掩码:
- 设置图像
- 使用边界框预测掩码
- 返回 2D 掩码

### 4. MoGe2 点云生成 (`pointcloud_segmentation.py`)

从单目图像生成 3D 点云:
- 深度图估计
- 3D 点云重建
- 相机内参估算

### 5. 点云分割 (`pointcloud_segmentation.py: PointCloudSegmentator`)

分离不同部分的点云:
- **目标点云**: SAM2 掩码区域内的点
- **地板点云**: 目标下方区域，Y 坐标较大的点
- **场景点云**: 去除目标和地板后的剩余点

### 6. 点云保存和可视化 (`pointcloud_saver.py`)

保存和可视化:
- PLY 格式 (ASCII)
- 3D matplotlib 可视化
- 2D 投影叠加
- 深度图 + 掩码可视化

## 🎯 技术路线

```
用户指令
    ↓
[VLM 意图理解] → 目标物体名称
    ↓
[GroundingDINO] → 2D 边界框
    ↓
[SAM2 分割] → 目标掩码
    ↓
[MoGe2] → 完整场景点云
    ↓
[点云分割] → 场景/目标/地板点云
    ↓
[保存输出] → PLY + 可视化
```

## 🛠️ 使用 Python API

```python
from trajectory_2D.main import PointCloudSegmentationPipeline

# 创建流程
pipeline = PointCloudSegmentationPipeline(
    output_dir="/path/to/output",
    sam2_host="localhost",
    sam2_port=20020
)

# 运行
result = pipeline.run(
    image_path="test.png",
    instruction="远处的垃圾桶"
)

if result["success"]:
    print(f"目标点云：{result['pointcloud_stats']['target']} 个点")
    print(f"输出目录：{result['output_dir']}")
```

## ⚠️ 注意事项

1. **SAM2 服务器必须先启动**，否则流程会失败
2. **GPU 内存需求**: 建议至少 8GB GPU 内存
3. **深度精度**: MoGe2 估计的深度是相对深度，可能存在尺度误差
4. **地板检测**: 使用几何方法，在目标下方区域寻找 Y 坐标最大的点

## 🔍 查看点云

使用以下工具查看 PLY 文件:
- [MeshLab](https://www.meshlab.net/)
- [CloudCompare](https://www.danielgm.net/cc/)
- Open3D (Python)

```python
import open3d as o3d

# 读取点云
pcd = o3d.io.read_point_cloud("target_pointcloud.ply")
o3d.visualization.draw_geometries([pcd])
```

## 📝 示例输出

```
======================================================================
🚀 开始点云分割流程
======================================================================
   图像：/workspace/wxd/Agent/images/test.png
   指令：远处的垃圾桶
======================================================================

======================================================================
📋 步骤 1: VLM 意图理解
======================================================================
✅ 识别目标：garbage can
   深度属性：farthest
   位置属性：None

======================================================================
🔍 步骤 2: GroundingDINO 目标检测
======================================================================
   检测到：garbage can (置信度：0.852)
   边界框：x1=320.5, y1=180.2, x2=450.8, y2=380.6
✅ 选择检测框：置信度 0.852

======================================================================
✂️  步骤 3: SAM2 分割
======================================================================
✅ SAM2 掩码已生成，像素数：12580

======================================================================
☁️  步骤 4: MoGe2 点云生成与分割
======================================================================
✅ 点云分割完成
   完整点云：1228800 个点
   目标点云：15420 个点
   地板点云：89350 个点
   场景点云：1124030 个点

======================================================================
💾 步骤 5: 保存结果
======================================================================
✅ 点云已保存：.../target_pointcloud.ply (15420 个点)
✅ 点云已保存：.../floor_pointcloud.ply (89350 个点)
✅ 点云已保存：.../scene_pointcloud.ply (1124030 个点)
✅ 3D 可视化已保存：.../3d_pointcloud.png
✅ 2D 投影可视化已保存：.../2d_projection.png
✅ 深度图可视化已保存：.../depth_masks.png
✅ 所有结果已保存：/workspace/wxd/Agent/images/trajectory_2D_results/test

======================================================================
✅ 点云分割流程完成!
======================================================================
```

## 📞 故障排除

### SAM2 服务器不可用
```
❌ SAM2 服务器不可用，请确保已启动：python sam2_server.py ...
```
**解决**: 确保 SAM2 服务器在指定端口运行

### 未检测到目标物体
```
❌ 未检测到目标物体：garbage can
```
**解决**: 
- 检查 GroundingDINO 模型路径是否正确
- 尝试调整 `BOX_THRESHOLD` 和 `TEXT_THRESHOLD`
- 确认目标物体在图像中可见

### 点云为空
```
⚠️ 点云为空，跳过保存
```
**解决**:
- 检查 MoGe2 模型是否正确加载
- 确认图像路径有效
