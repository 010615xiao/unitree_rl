#!/usr/bin/env python3
"""
点云分割模块（HTTP 版本）
使用 SAM2、GroundingDINO 和 Depth-Anything-v3 的 HTTP 服务进行点云分割
"""

import numpy as np
import torch
import cv2
import requests
import base64
import io
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class PointCloudData:
    """点云数据类"""
    points: np.ndarray  # [N, 3] XYZ 坐标
    colors: Optional[np.ndarray] = None  # [N, 3] RGB 颜色
    depths: Optional[np.ndarray] = None  # [N] 深度值
    mask: Optional[np.ndarray] = None  # [H, W] 2D 掩码


class DepthAnythingV3Client:
    """Depth-Anything-v3 深度估计和点云生成客户端"""

    def __init__(self, host: str = "localhost", port: int = 20022, timeout: int = 120):
        """
        初始化 Depth-Anything-v3 客户端

        Args:
            host: Depth-Anything-v3 服务器主机地址
            port: Depth-Anything-v3 服务器端口
            timeout: 请求超时时间（秒）
        """
        self.host = host
        self.port = port
        self.base_url = f"http://{host}:{port}"
        self.timeout = timeout

        print(f"🔗 Depth-Anything-v3 客户端已初始化：{self.base_url}")

    def health_check(self) -> bool:
        """检查 Depth-Anything-v3 服务器状态"""
        try:
            response = requests.get(f"{self.base_url}/health", timeout=5)
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Depth-Anything-v3 服务器在线：{result.get('model', 'unknown')} @ {result.get('device', 'unknown')}")
                return True
            return False
        except Exception as e:
            print(f"⚠️ Depth-Anything-v3 服务器检查失败：{e}")
            return False

    def generate_point_cloud(
        self,
        image_path: str
    ) -> Tuple[np.ndarray, np.ndarray, dict]:
        """
        从图像生成点云

        Args:
            image_path: 图像路径

        Returns:
            points: [H*W, 3] 点云坐标
            colors: [H*W, 3] RGB 颜色
            info: 包含 shape 等信息的字典
        """
        try:
            # 调用 API
            response = requests.post(
                f"{self.base_url}/generate_point_cloud",
                json={"image_path": image_path},
                timeout=self.timeout
            )

            if response.status_code != 200:
                raise Exception(f"Depth-Anything-v3 服务返回错误：{response.status_code}")

            result = response.json()

            if not result.get("success"):
                raise Exception(f"Depth-Anything-v3 服务错误：{result.get('error', 'Unknown error')}")

            # 转换为 numpy 数组
            points = np.array(result["points"])
            colors = np.array(result["colors"])
            shape = result["shape"]

            print(f"✅ 点云已生成：{shape[1]}x{shape[0]}, {len(points)} 个点")
            print(f"   X 范围 [{points[:,0].min():.2f}, {points[:,0].max():.2f}]")

            return points, colors, {"shape": shape, "num_points": len(points)}

        except requests.exceptions.RequestException as e:
            raise Exception(f"无法连接到 Depth-Anything-v3 服务 ({self.base_url}): {e}")

    def generate_depth_map(
        self,
        image_path: str
    ) -> Tuple[np.ndarray, dict]:
        """
        从图像生成深度图

        Args:
            image_path: 图像路径

        Returns:
            depth_map: [H, W] 深度图
            info: 包含 depth_range 等信息的字典
        """
        try:
            response = requests.post(
                f"{self.base_url}/generate_depth",
                json={"image_path": image_path},
                timeout=self.timeout
            )

            if response.status_code != 200:
                raise Exception(f"Depth-Anything-v3 服务返回错误：{response.status_code}")

            result = response.json()

            if not result.get("success"):
                raise Exception(f"Depth-Anything-v3 服务错误：{result.get('error', 'Unknown error')}")

            # 解码深度图
            depth_bytes = base64.b64decode(result["depth_map"])
            depth_map = np.load(io.BytesIO(depth_bytes))

            print(f"✅ 深度图已生成：{depth_map.shape}")
            print(f"   深度范围：{depth_map.min():.2f}-{depth_map.max():.2f} 米")

            return depth_map, result

        except requests.exceptions.RequestException as e:
            raise Exception(f"无法连接到 Depth-Anything-v3 服务 ({self.base_url}): {e}")


class GroundingDINOClient:
    """GroundingDINO 目标检测客户端"""

    def __init__(self, host: str = "localhost", port: int = 20021, timeout: int = 60):
        """
        初始化 GroundingDINO 客户端

        Args:
            host: GroundingDINO 服务器主机地址
            port: GroundingDINO 服务器端口
            timeout: 请求超时时间（秒）
        """
        self.host = host
        self.port = port
        self.base_url = f"http://{host}:{port}"
        self.timeout = timeout

        print(f"🔗 GroundingDINO 客户端已初始化：{self.base_url}")

    def health_check(self) -> bool:
        """检查 GroundingDINO 服务器状态"""
        try:
            response = requests.get(f"{self.base_url}/health", timeout=5)
            if response.status_code == 200:
                result = response.json()
                print(f"✅ GroundingDINO 服务器在线：{result.get('model', 'unknown')}")
                return True
            return False
        except Exception as e:
            print(f"⚠️ GroundingDINO 服务器检查失败：{e}")
            return False

    def detect(
        self,
        image_path: str,
        text_prompt: str,
        box_threshold: float = 0.35,
        text_threshold: float = 0.25
    ) -> Dict:
        """
        目标检测

        Args:
            image_path: 图像路径
            text_prompt: 文本提示（如："chair . table . person"）
            box_threshold: 置信度阈值
            text_threshold: 文本阈值

        Returns:
            dict: 包含 boxes, labels, scores 的字典
        """
        try:
            response = requests.post(
                f"{self.base_url}/detect",
                json={
                    "image_path": image_path,
                    "text_prompt": text_prompt,
                    "box_threshold": box_threshold,
                    "text_threshold": text_threshold
                },
                timeout=self.timeout
            )

            if response.status_code != 200:
                raise Exception(f"GroundingDINO 服务返回错误：{response.status_code}")

            result = response.json()

            if not result.get("success"):
                raise Exception(f"GroundingDINO 服务错误：{result.get('error', 'Unknown error')}")

            print(f"✅ 检测到 {len(result.get('boxes', []))} 个目标")

            return {
                "boxes": result.get("boxes", []),
                "labels": result.get("labels", []),
                "scores": result.get("scores", []),
                "image_size": result.get("image_size", {})
            }

        except requests.exceptions.RequestException as e:
            raise Exception(f"无法连接到 GroundingDINO 服务 ({self.base_url}): {e}")


class PointCloudSegmentator:
    """点云分割器（HTTP 版本）"""

    def __init__(self,
                 sam2_host: str = "localhost", sam2_port: int = 20020,
                 grounding_dino_host: str = "localhost", grounding_dino_port: int = 20021,
                 depth_anything_host: str = "localhost", depth_anything_port: int = 20022):
        """
        初始化点云分割器

        Args:
            sam2_host/port: SAM2 服务器地址和端口
            grounding_dino_host/port: GroundingDINO 服务器地址和端口
            depth_anything_host/port: Depth-Anything-v3 服务器地址和端口
        """
        self.sam2_client = None  # 使用外部传入的 SAM2 客户端
        self.gdino_client = GroundingDINOClient(host=grounding_dino_host, port=grounding_dino_port)
        self.depth_anything_client = DepthAnythingV3Client(host=depth_anything_host, port=depth_anything_port)

        print(f"🔧 点云分割器已初始化（HTTP 版本）")

    def set_sam2_client(self, sam2_client):
        """设置 SAM2 客户端"""
        self.sam2_client = sam2_client

    def detect_objects(
        self,
        image_path: str,
        text_prompt: str
    ) -> Dict:
        """
        检测目标物体

        Args:
            image_path: 图像路径
            text_prompt: 文本提示

        Returns:
            dict: 包含 boxes, labels, scores 的字典
        """
        return self.gdino_client.detect(image_path, text_prompt)

    def generate_point_cloud(
        self,
        image_path: str
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        从图像生成点云和深度图

        Args:
            image_path: 图像路径

        Returns:
            point_cloud: [H, W, 3] 点云
            depth_map: [H, W] 深度图
            image_rgb: [H, W, 3] RGB 图像
        """
        # 读取图像
        image_bgr = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        h, w = image_rgb.shape[:2]

        # 调用 Depth-Anything-v3 API
        points, colors, info = self.depth_anything_client.generate_point_cloud(image_path)
        shape = info["shape"]

        # 重塑为 [H, W, 3] 格式
        point_cloud = points.reshape(h, w, 3)

        # 计算深度图（Z 坐标）
        depth_map = point_cloud[:, :, 2]

        print(f"✅ 点云已生成：{w}x{h}, X 范围 [{point_cloud[:,:,0].min():.2f}, {point_cloud[:,:,0].max():.2f}]")
        print(f"   深度范围：{depth_map.min():.2f}-{depth_map.max():.2f} 米")

        return point_cloud, depth_map, image_rgb

    def segment_target_cloud(
        self,
        points: np.ndarray,
        colors: np.ndarray,
        shape: Tuple[int, int],
        mask: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        分割目标点云

        Args:
            points: [H*W, 3] 点云坐标
            colors: [H*W, 3] RGB 颜色
            shape: [H, W] 图像形状
            mask: [H, W] 2D 掩码

        Returns:
            target_points: [N, 3] 目标点云
            target_colors: [N, 3] 目标点云颜色
        """
        h, w = shape
        pixel_indices = np.arange(h * w).reshape(h, w)
        target_pixels = pixel_indices[mask > 0]

        target_points = points[target_pixels]
        target_colors = colors[target_pixels]

        print(f"✅ 目标点云已分割：{len(target_points)} 个点")

        return target_points, target_colors

    def segment_floor_cloud(
        self,
        points: np.ndarray,
        colors: np.ndarray,
        shape: Tuple[int, int],
        floor_mask: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        分割地板点云

        Args:
            points: [H*W, 3] 点云坐标
            colors: [H*W, 3] RGB 颜色
            shape: [H, W] 图像形状
            floor_mask: [H, W] 地板掩码

        Returns:
            floor_points: [N, 3] 地板点云
            floor_colors: [N, 3] 地板点云颜色
        """
        h, w = shape
        pixel_indices = np.arange(h * w).reshape(h, w)
        floor_pixels = pixel_indices[floor_mask > 0]

        floor_points = points[floor_pixels]
        floor_colors = colors[floor_pixels]

        print(f"✅ 地板点云已分割：{len(floor_points)} 个点")

        return floor_points, floor_colors

    def segment_scene_cloud(
        self,
        points: np.ndarray,
        colors: np.ndarray,
        target_mask: np.ndarray,
        floor_mask: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        分割场景点云（剩余部分）

        Args:
            points: [H*W, 3] 点云坐标
            colors: [H*W, 3] RGB 颜色
            target_mask: [H, W] 目标掩码
            floor_mask: [H, W] 地板掩码

        Returns:
            scene_points: [N, 3] 场景点云
            scene_colors: [N, 3] 场景点云颜色
        """
        # 展平掩码
        target_flat = target_mask.flatten()
        floor_flat = floor_mask.flatten()
        
        # 场景像素 = 所有像素 - 目标像素 - 地板像素
        scene_mask = ~(target_flat | floor_flat)
        
        scene_points = points[scene_mask]
        scene_colors = colors[scene_mask]

        print(f"✅ 场景点云已分割：{len(scene_points)} 个点")

        return scene_points, scene_colors

    def segment(
        self,
        depth_map: np.ndarray,
        point_cloud: np.ndarray,
        target_mask: np.ndarray,
        floor_mask: np.ndarray,
        image_rgb: np.ndarray
    ) -> Dict:
        """
        完整的点云分割流程（兼容旧版接口）

        Args:
            depth_map: [H, W] 深度图
            point_cloud: [H, W, 3] 点云
            target_mask: [H, W] 目标掩码
            floor_mask: [H, W] 地板掩码
            image_rgb: [H, W, 3] RGB 图像

        Returns:
            dict: 包含 target, floor, scene, full 点云的字典
        """
        h, w = depth_map.shape
        shape = (h, w)

        # 展平点云和颜色
        points = point_cloud.reshape(-1, 3)
        colors = image_rgb.reshape(-1, 3) / 255.0

        # 分割各部分点云
        target_points, target_colors = self.segment_target_cloud(points, colors, shape, target_mask)
        floor_points, floor_colors = self.segment_floor_cloud(points, colors, shape, floor_mask)
        scene_points, scene_colors = self.segment_scene_cloud(points, colors, target_mask, floor_mask)

        # 创建兼容的数据结构
        class PointCloudData:
            def __init__(self, points, colors, mask=None):
                self.points = points
                self.colors = colors
                self.mask = mask

        return {
            'target': PointCloudData(target_points, target_colors, target_mask),
            'floor': PointCloudData(floor_points, floor_colors, floor_mask),
            'scene': PointCloudData(scene_points, scene_colors, None),
            'full': PointCloudData(points, colors, None)
        }
