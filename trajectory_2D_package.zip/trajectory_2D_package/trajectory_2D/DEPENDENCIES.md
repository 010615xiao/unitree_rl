# Trajectory 2D Pipeline - 依赖文件与模型清单

## 运行环境

### GPU 配置
- **GPU ID**: 5
- **命令**: `export CUDA_VISIBLE_DEVICES=5`

### 服务端口
| 服务 | 端口 | 说明 |
|------|------|------|
| vLLM (RoboBrain2.0-7B) | 8000 | VLM 意图理解 + 轨迹规划 |
| SAM2 | 20020 | 目标分割 |
| GroundingDINO | 20021 | 目标检测 |
| Depth-Anything-v3 | 20022 | 深度估计 |

---

## 一、Python 模块文件 (trajectory_2D/)

### 核心模块
| 文件 | 说明 | 依赖 |
|------|------|------|
| `run_pipeline.py` | 统一运行脚本（主入口） | main.py, test_vlm_trajectory.py, render_trajectory_view.py |
| `main.py` | 点云分割主流程 | sam2_client.py, pointcloud_segmentation_http.py, pointcloud_saver.py |
| `test_vlm_trajectory.py` | VLM 轨迹预测 | - |
| `render_trajectory_view.py` | 新视角渲染 | - |

### 工具模块
| 文件 | 说明 |
|------|------|
| `sam2_client.py` | SAM2 HTTP 客户端 |
| `pointcloud_segmentation_http.py` | 点云分割器（HTTP 版本） |
| `pointcloud_segmentation.py` | 点云分割器（本地版本） |
| `pointcloud_saver.py` | 点云保存和可视化 |

### 辅助模块
| 文件 | 说明 |
|------|------|
| `__init__.py` | 包初始化 |
| `batch_test.py` | 批量测试脚本 |
| `test_vlm_depth_masks.py` | VLM 深度掩码测试 |

---

## 二、服务端脚本 (checkpoints/)

### 必需服务
| 文件 | 端口 | 说明 |
|------|------|------|
| `sam2_server.py` | 20020 | SAM2 分割服务 |
| `grounding_dino_server.py` | 20021 | GroundingDINO 检测服务 |
| `depth_anything_v3_server.py` | 20022 | Depth-Anything-v3 深度估计服务 |

### 服务管理脚本
| 文件 | 说明 |
|------|------|
| `start_services.sh` | 启动所有服务 |
| `stop_services.sh` | 停止所有服务 |

---

## 三、模型清单

### 3.1 vLLM 模型
| 模型名称 | 路径 | 用途 |
|----------|------|------|
| RoboBrain2.0-7B | `/workspace/wxd/models/RoboBrain2.5-8B` | VLM 意图理解 + 轨迹规划 |

### 3.2 Depth-Anything-v3 模型
| 模型名称 | 路径 | 用途 |
|----------|------|------|
| Depth-Anything-v3 | `/workspace/wxd/Agent/Spagent/spagent/checkpoints/depth_anything/` | 深度图生成 |

### 3.3 SAM2 模型
| 模型名称 | 说明 |
|----------|------|
| sam2.1_hiera_large.pt | SAM2.1 大模型（服务器自动加载） |

### 3.4 GroundingDINO 模型
| 模型名称 | 说明 |
|----------|------|
| groundingdino_swint_ogc | GroundingDINO 检测模型（服务器自动加载） |

---

## 四、配置文件

### 服务配置
```bash
# GPU 配置
export CUDA_VISIBLE_DEVICES=5

# 服务地址
SAM2_HOST="localhost"
SAM2_PORT=20020

GROUNDING_DINO_HOST="localhost"
GROUNDING_DINO_PORT=20021

DEPTH_ANYTHING_HOST="localhost"
DEPTH_ANYTHING_PORT=20022

# vLLM 配置
VLLM_BASE_URL="http://localhost:8000/v1"
VLLM_MODEL="RoboBrain2.0-7B"
```

### 运行参数
```python
# 起点坐标 (2D)
START_POINT_2D = (310, 450)  # (x, y)

# 检测阈值
BOX_THRESHOLD = 0.30
TEXT_THRESHOLD = 0.20

# 默认输出目录
DEFAULT_OUTPUT_DIR = "/workspace/wxd/Agent/images/trajectory_2D_results"
```

---

## 五、使用示例

### 启动服务
```bash
cd /workspace/wxd/Agent/Spagent/spagent/checkpoints
bash start_services.sh
```

### 运行 Pipeline
```bash
cd /workspace/wxd/Agent/Spagent/spagent/checkpoints/trajectory_2D
export CUDA_VISIBLE_DEVICES=5

# 基本用法
python run_pipeline.py --image /path/to/image.png --instruction "垃圾桶"

# 带地板约束过滤
python run_pipeline.py --image /path/to/image.png --instruction "垃圾桶" --filter_floor

# 带新视角渲染
python run_pipeline.py --image /path/to/image.png --instruction "垃圾桶" --render_view --camera_height 0.5

# 渲染所有轨迹点
python run_pipeline.py --image /path/to/image.png --instruction "垃圾桶" --render_all_views --filter_floor
```

### 停止服务
```bash
bash stop_services.sh
```

---

## 六、输出文件

### 点云文件 (.ply)
- `{base_name}_full_pointcloud.ply` - 完整场景点云
- `{base_name}_target_pointcloud.ply` - 目标物体点云
- `{base_name}_floor_pointcloud.ply` - 地板点云
- `{base_name}_scene_pointcloud.ply` - 场景点云（目标 + 地板）

### 深度图
- `{base_name}_depth_map.npy` - 深度图（NumPy 格式）
- `{base_name}_depth_masks.png` - 深度掩码可视化

### 轨迹数据
- `{base_name}_trajectory_data.json` - 原始轨迹数据
- `{base_name}_trajectory_data_postprocessed.json` - 后处理轨迹数据
- `{base_name}_trajectory_data_filtered.json` - 地板约束过滤后轨迹数据
- `{base_name}_trajectory_data_interpolated.json` - 插值后轨迹数据

### 可视化图像
- `{base_name}_3d_pointcloud.png` - 3D 点云可视化
- `{base_name}_2d_projection.png` - 2D 投影可视化
- `{base_name}_trajectory_filtered_*.png` - 过滤后轨迹可视化
- `{base_name}_trajectory_*.png` - 插值后轨迹可视化（深度图 + 原图）
- `{base_name}_view_*.png` - 新视角渲染图像

---

## 七、Python 依赖

```
torch
numpy
opencv-python (cv2)
openai (vLLM 客户端)
PIL (图像处理)
trimesh (3D 可视化)
```

---

## 八、文件结构

```
/workspace/wxd/Agent/Spagent/spagent/checkpoints/
├── trajectory_2D/
│   ├── run_pipeline.py          # 主入口
│   ├── main.py                  # 点云分割主流程
│   ├── test_vlm_trajectory.py   # VLM 轨迹预测
│   ├── render_trajectory_view.py # 新视角渲染
│   ├── pointcloud_segmentation_http.py
│   ├── pointcloud_segmentation.py
│   ├── pointcloud_saver.py
│   ├── sam2_client.py
│   └── __init__.py
│
├── sam2_server.py               # SAM2 服务 (20020)
├── grounding_dino_server.py     # GroundingDINO 服务 (20021)
├── depth_anything_v3_server.py  # Depth-Anything-v3 服务 (20022)
├── start_services.sh            # 启动服务脚本
├── stop_services.sh             # 停止服务脚本
│
└── depth_anything/              # Depth-Anything-v3 模型目录
    └── [模型文件]

/workspace/wxd/models/
└── RoboBrain2.5-8B/             # vLLM 模型
```

---

## 九、打包说明

### 打包内容
1. `trajectory_2D/` - 所有 Python 模块
2. 服务端脚本 (`sam2_server.py`, `grounding_dino_server.py`, `depth_anything_v3_server.py`)
3. 服务管理脚本 (`start_services.sh`, `stop_services.sh`)
4. 本清单文件 (`DEPENDENCIES.md`)

### 不打包内容
1. 模型文件（体积大，单独下载）
2. `__pycache__/` 目录
3. 测试结果和输出文件

### 打包命令
```bash
cd /workspace/wxd/Agent/Spagent/spagent/checkpoints
zip -r trajectory_2D_package.zip \
    trajectory_2D/ \
    sam2_server.py \
    grounding_dino_server.py \
    depth_anything_v3_server.py \
    start_services.sh \
    stop_services.sh \
    DEPENDENCIES.md \
    -x "*.pyc" \
    -x "__pycache__/*" \
    -x "*.zip"
```
