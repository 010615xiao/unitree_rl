#!/usr/bin/env python3
"""
统一运行脚本：先运行 main.py 生成分割掩码，然后运行 VLM 轨迹预测

使用示例:
    python run_pipeline.py --image /workspace/wxd/Agent/images/test_6.png --instruction "远处的垃圾桶"
    python run_pipeline.py --image test.png --instruction "最近的椅子"
"""

import sys
import os
import argparse
import subprocess
import json
import numpy as np
import cv2
from pathlib import Path
from typing import List, Tuple, Optional, Dict
from datetime import datetime


def visualize_trajectory_on_image(
    image_path: str,
    trajectory: List[List[float]],
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    title: str = "Trajectory Visualization",
    output_dir: Optional[str] = None,  # 修改为输出目录
    point_colors: Optional[Dict[str, Tuple[int, int, int]]] = None
) -> str:
    """
    在图像上可视化轨迹

    Args:
        image_path: 图像路径
        trajectory: 轨迹点列表
        start_point: 起点坐标
        target_point: 目标点坐标
        title: 标题
        output_dir: 输出目录（如果不指定，使用图像所在目录）
        point_colors: 点颜色配置

    Returns:
        输出图像路径
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]

    # 创建叠加层
    overlay = image_rgb.copy()

    # 默认颜色配置
    if point_colors is None:
        point_colors = {
            "start": (0, 255, 0),      # 绿色
            "end": (0, 0, 255),        # 红色
            "interpolated": (255, 255, 0),  # 黄色（插值点）
            "original": (255, 255, 255)     # 白色（原始点）
        }

    # 绘制轨迹线（渐变色）
    if len(trajectory) >= 2:
        points = [(int(p[0]), int(p[1])) for p in trajectory]
        for i in range(len(points) - 1):
            t = i / (len(points) - 1)
            color = (int(0 * (1 - t) + 255 * t), int(255 * (1 - t) + 0 * t), 0)
            cv2.line(overlay, points[i], points[i+1], color, 3)

    # 绘制轨迹点
    for i, pt in enumerate(trajectory):
        x, y = int(pt[0]), int(pt[1])
        
        if i == 0:
            # 起点：绿色大圆圈
            cv2.circle(overlay, (x, y), 12, point_colors["start"], -1)
            cv2.putText(overlay, "S", (x - 8, y + 8),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)
        elif i == len(trajectory) - 1:
            # 终点：红色大圆圈
            cv2.circle(overlay, (x, y), 12, point_colors["end"], -1)
            cv2.putText(overlay, "T", (x - 8, y + 8),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        else:
            # 中间点：白色或黄色小圆圈
            color = point_colors.get("interpolated", (255, 255, 0))
            cv2.circle(overlay, (x, y), 8, color, -1)

    # 添加标题和统计信息
    stats_y = 25
    font_scale = 0.5

    cv2.putText(overlay, title, (10, stats_y),
               cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 2)
    cv2.putText(overlay, f"Points: {len(trajectory)}", (10, stats_y + 25),
               cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 2)

    # 保存
    if output_dir is None:
        output_dir = os.path.dirname(image_path)
    
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_path = os.path.join(output_dir, f"{base_name}_trajectory_{timestamp}.png")

    output_bgr = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 轨迹可视化已保存：{output_path}")

    return output_path


def interpolate_trajectory(
    trajectory: List[List[float]],
    floor_mask: np.ndarray,
    min_points: int = 10,
    max_density: float = 15.0  # 最大插值密度（像素间隔）
) -> dict:
    """
    对轨迹点进行插值，确保点数足够且分布合理

    Args:
        trajectory: 原始轨迹点列表
        floor_mask: 地板掩码（用于验证插值点是否在地板上）
        min_points: 最少点数
        max_density: 最大插值密度（点之间的最小像素距离）

    Returns:
        插值结果字典
    """
    if len(trajectory) < 2:
        return {
            "success": False,
            "error": "轨迹点数量不足，无法插值",
            "original_points": len(trajectory)
        }

    original_count = len(trajectory)
    
    # 如果点数已经足够，不需要插值
    if original_count >= min_points:
        return {
            "success": True,
            "interpolated": False,
            "original_points": original_count,
            "interpolated_points": original_count,
            "trajectory": trajectory,
            "added_points": 0
        }

    print("\n" + "=" * 80)
    print("📐 轨迹点插值")
    print("=" * 80)
    print(f"   原始点数：{original_count}")
    print(f"   目标点数：至少 {min_points} 个")

    # ========== 步骤 1: 计算相邻点之间的距离 ==========
    print("\n📌 步骤 1: 分析点间距")
    
    segments = []
    total_length = 0
    
    for i in range(len(trajectory) - 1):
        p1 = np.array(trajectory[i])
        p2 = np.array(trajectory[i + 1])
        dist = np.linalg.norm(p2 - p1)
        segments.append({
            "start_idx": i,
            "p1": p1,
            "p2": p2,
            "distance": dist
        })
        total_length += dist
        print(f"   段 {i}: [{p1[0]:.1f}, {p1[1]:.1f}] → [{p2[0]:.1f}, {p2[1]:.1f}], 距离={dist:.1f} 像素")

    # ========== 步骤 2: 计算需要的插值点数 ==========
    points_needed = min_points - original_count
    print(f"\n📌 步骤 2: 计算插值方案")
    print(f"   需要添加：{points_needed} 个点")
    print(f"   轨迹总长度：{total_length:.1f} 像素")

    # 按距离比例分配插值点到各个段
    interpolated_trajectory = [trajectory[0].copy()]
    added_count = 0
    
    for seg in segments:
        # 计算这个段应该分配的插值点数（按距离比例）
        segment_ratio = seg["distance"] / total_length
        points_for_segment = int(round(points_needed * segment_ratio))
        
        # 确保每个段至少有一个点（如果原距离较大）
        if seg["distance"] > max_density and points_for_segment == 0:
            points_for_segment = 1
        
        # 计算插值点
        num_intervals = points_for_segment + 1
        for j in range(1, num_intervals + 1):
            t = j / num_intervals
            interp_point = seg["p1"] + t * (seg["p2"] - seg["p1"])
            
            # 验证插值点是否在地板上
            x, y = int(round(interp_point[0])), int(round(interp_point[1]))
            h, w = floor_mask.shape
            
            if 0 <= x < w and 0 <= y < h:
                is_on_floor = bool(floor_mask[y, x])
                
                if is_on_floor:
                    # 检查与上一个点的距离（避免太密集）
                    if len(interpolated_trajectory) > 0:
                        last_point = np.array(interpolated_trajectory[-1])
                        dist_to_last = np.linalg.norm(interp_point - last_point)
                        
                        if dist_to_last >= max_density * 0.5:  # 至少达到最小密度的一半
                            interpolated_trajectory.append(interp_point.tolist())
                            added_count += 1
                    else:
                        interpolated_trajectory.append(interp_point.tolist())
                        added_count += 1
    
    # 添加最后一个点
    interpolated_trajectory.append(trajectory[-1].copy())
    
    # ========== 步骤 3: 输出统计 ==========
    print(f"\n📌 步骤 3: 插值结果")
    print(f"   插值后点数：{len(interpolated_trajectory)}")
    print(f"   新增点数：{added_count}")
    
    # 检查是否达到目标
    if len(interpolated_trajectory) < min_points:
        print(f"   ⚠️ 由于地板约束，无法达到 {min_points} 个点")
    
    return {
        "success": True,
        "interpolated": True,
        "original_points": original_count,
        "interpolated_points": len(interpolated_trajectory),
        "trajectory": interpolated_trajectory,
        "added_points": added_count,
        "target_points": min_points
    }


def postprocess_trajectory(
    trajectory: List[List[float]],
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    distance_threshold: float = 5.0
) -> dict:
    """
    对轨迹点进行后处理：去重 + 排序

    Args:
        trajectory: 原始轨迹点列表 [[x1, y1], [x2, y2], ...]
        start_point: 起点坐标 (x, y)
        target_point: 目标点坐标 [x, y]（可选，用于确保终点正确）
        distance_threshold: 融合相近点的距离阈值（像素），默认 5.0

    Returns:
        后处理结果字典，包含：
        - success: 是否成功
        - original_points: 原始点数
        - deduped_points: 去重后的点数
        - sorted_points: 排序后的点数
        - trajectory: 最终轨迹
        - removed_duplicates: 移除的重复点数
    """
    if not trajectory or len(trajectory) < 2:
        return {
            "success": False,
            "error": "轨迹点数量不足",
            "original_points": len(trajectory) if trajectory else 0
        }

    print("\n" + "=" * 80)
    print("🔧 轨迹点后处理")
    print("=" * 80)

    original_count = len(trajectory)
    print(f"原始轨迹点数：{original_count}")

    # ========== 步骤 1: 去重和融合相近点 ==========
    print("\n📌 步骤 1: 去重和融合相近点")
    print(f"   距离阈值：{distance_threshold} 像素")

    deduped = []
    i = 0
    while i < len(trajectory):
        current_point = trajectory[i]

        # 查找与当前点距离小于阈值的所有连续点
        cluster = [current_point]
        j = i + 1
        while j < len(trajectory):
            next_point = trajectory[j]
            dist = np.sqrt((current_point[0] - next_point[0]) ** 2 + (current_point[1] - next_point[1]) ** 2)
            if dist < distance_threshold:
                cluster.append(next_point)
                j += 1
            else:
                break

        # 融合 cluster 中的点（取平均）
        if len(cluster) > 1:
            avg_point = [
                np.mean([p[0] for p in cluster]),
                np.mean([p[1] for p in cluster])
            ]
            deduped.append(avg_point)
            print(f"   融合 {len(cluster)} 个相近点 → [{avg_point[0]:.1f}, {avg_point[1]:.1f}]")
        else:
            deduped.append(current_point)

        i = j

    # ========== 步骤 1.5: 全局去重（移除完全相同的点）==========
    # 在融合相近点后，再检查并移除全局重复的点
    global_deduped = []
    seen_points = set()
    for point in deduped:
        # 转换为元组以便放入集合
        point_tuple = (round(point[0], 1), round(point[1], 1))
        if point_tuple not in seen_points:
            seen_points.add(point_tuple)
            global_deduped.append(point)
    
    if len(global_deduped) < len(deduped):
        print(f"   全局去重：移除 {len(deduped) - len(global_deduped)} 个完全重复的点")
    deduped = global_deduped

    deduped_count = len(deduped)
    removed_count = original_count - deduped_count
    print(f"✅ 去重后点数：{deduped_count} (移除了 {removed_count} 个重复点)")

    # ========== 步骤 2: 按距离起点排序 ==========
    print("\n📌 步骤 2: 按距离起点排序")
    print(f"   起点：{start_point}")

    # 计算每个点到起点的距离
    points_with_dist = []
    for i, point in enumerate(deduped):
        dist_to_start = np.sqrt((point[0] - start_point[0]) ** 2 + (point[1] - start_point[1]) ** 2)
        points_with_dist.append({
            "index": i,
            "point": point,
            "dist_to_start": dist_to_start
        })

    # 如果有目标点，确保目标点是最后一个
    if target_point is not None:
        # 找到离目标点最近的点，将其标记为终点
        min_dist_to_target = float('inf')
        target_idx = -1
        for i, item in enumerate(points_with_dist):
            dist_to_target = np.sqrt((item["point"][0] - target_point[0]) ** 2 + (item["point"][1] - target_point[1]) ** 2)
            if dist_to_target < min_dist_to_target:
                min_dist_to_target = dist_to_target
                target_idx = i

        # 将离目标最近的点移到列表末尾（如果不在末尾）
        if target_idx != -1 and target_idx != len(points_with_dist) - 1:
            target_item = points_with_dist.pop(target_idx)
            points_with_dist.append(target_item)
            print(f"   将离目标点最近的点 (索引{target_idx}, 距离{min_dist_to_target:.1f}) 设为终点")

    # 按距离起点排序（除了最后一个点，确保终点在最后）
    if len(points_with_dist) > 1:
        # 分离终点
        end_point = points_with_dist[-1]
        # 对其余点按距离排序
        sorted_points = sorted(points_with_dist[:-1], key=lambda x: x["dist_to_start"])
        # 重新添加终点
        sorted_points.append(end_point)
    else:
        sorted_points = points_with_dist

    # 提取排序后的轨迹
    sorted_trajectory = [item["point"] for item in sorted_points]

    # 验证排序结果
    print(f"✅ 排序后点数：{len(sorted_trajectory)}")
    print(f"   起点：{sorted_trajectory[0]} (距离起点 0.0)")
    print(f"   终点：{sorted_trajectory[-1]} (距离起点 {points_with_dist[-1]['dist_to_start']:.1f})")

    # ========== 步骤 3: 输出统计信息 ==========
    print("\n📊 后处理统计:")
    print(f"   原始点数：{original_count}")
    print(f"   去重后点数：{deduped_count}")
    print(f"   排序后点数：{len(sorted_trajectory)}")
    print(f"   移除重复点：{removed_count}")
    print(f"   压缩率：{(1 - len(sorted_trajectory) / original_count) * 100:.1f}%")

    return {
        "success": True,
        "original_points": original_count,
        "deduped_points": deduped_count,
        "sorted_points": len(sorted_trajectory),
        "trajectory": sorted_trajectory,
        "removed_duplicates": removed_count
    }


def extract_floor_mask(depth_masks_path: str) -> Optional[np.ndarray]:
    """
    从 depth_masks 图像中提取地板掩码（绿色区域）
    
    Args:
        depth_masks_path: depth_masks 图像路径
        
    Returns:
        地板掩码（布尔数组），如果失败返回 None
    """
    if not os.path.exists(depth_masks_path):
        print(f"❌ depth_masks 文件不存在：{depth_masks_path}")
        return None
    
    # 读取图像
    mask_img = cv2.imread(depth_masks_path)
    if mask_img is None:
        print(f"❌ 无法读取 depth_masks 图像：{depth_masks_path}")
        return None
    
    # 转换到 HSV 颜色空间
    hsv = cv2.cvtColor(mask_img, cv2.COLOR_BGR2HSV)
    
    # 绿色的 HSV 范围
    lower_green = np.array([35, 40, 50])
    upper_green = np.array([85, 255, 255])
    
    # 创建掩码
    mask = cv2.inRange(hsv, lower_green, upper_green)
    floor_mask = mask > 0
    
    print(f"✅ 提取地板掩码：{floor_mask.sum()} 个像素 ({100*floor_mask.sum()/(mask_img.shape[0]*mask_img.shape[1]):.1f}%)")
    
    return floor_mask


def filter_trajectory_on_floor(
    trajectory: List[List[float]],
    floor_mask: np.ndarray,
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    skip_first_point: bool = True
) -> dict:
    """
    过滤轨迹点，只保留在地板上的点
    
    Args:
        trajectory: 原始轨迹点列表
        floor_mask: 地板掩码
        start_point: 起点坐标（始终保留）
        target_point: 目标点坐标（始终保留）
        skip_first_point: 是否跳过起点验证（起点始终保留）
        
    Returns:
        过滤结果字典
    """
    if not trajectory or len(trajectory) < 2:
        return {
            "success": False,
            "error": "轨迹点数量不足",
            "original_points": len(trajectory) if trajectory else 0
        }
    
    if floor_mask is None:
        return {
            "success": False,
            "error": "地板掩码为空",
            "original_points": len(trajectory)
        }
    
    print("\n" + "=" * 80)
    print("🔧 地板约束过滤")
    print("=" * 80)
    
    original_count = len(trajectory)
    print(f"原始轨迹点数：{original_count}")
    
    # ========== 步骤 1: 检查每个点是否在地板上 ==========
    print("\n📌 步骤 1: 检查每个点是否在地板上")
    
    filtered_points = []
    on_floor_points = []
    off_floor_points = []
    
    h, w = floor_mask.shape
    
    for i, point in enumerate(trajectory):
        x, y = int(round(point[0])), int(round(point[1]))
        
        # 检查边界
        if x < 0 or x >= w or y < 0 or y >= h:
            off_floor_points.append({"index": i, "point": [x, y], "reason": "out_of_bounds"})
            continue
        
        # 检查是否在地板上
        is_on_floor = bool(floor_mask[y, x])
        
        # 起点始终保留
        is_start = (i == 0)
        # 终点始终保留（如果提供了目标点且这是最后一个点）
        is_end = (target_point is not None and i == len(trajectory) - 1)
        
        if is_on_floor or is_start or is_end:
            filtered_points.append(point)
            if is_on_floor:
                on_floor_points.append({"index": i, "point": [x, y]})
            else:
                status = "start_point" if is_start else "end_point"
                print(f"   点 {i} [{x}, {y}]: 保留 ({status})")
        else:
            off_floor_points.append({"index": i, "point": [x, y], "reason": "not_on_floor"})
            print(f"   点 {i} [{x}, {y}]: ❌ 不在地板上，移除")
    
    filtered_count = len(filtered_points)
    removed_count = original_count - filtered_count
    
    print(f"\n✅ 过滤后点数：{filtered_count}")
    print(f"   在地板上：{len(on_floor_points)} 个点")
    print(f"   不在地板上：{len(off_floor_points)} 个点 (已移除)")
    
    # ========== 步骤 2: 确保最后一个点是终点 ==========
    print("\n📌 步骤 2: 确保最后一个点是终点")
    
    if target_point is not None and len(filtered_points) > 1:
        # 找到离目标点最近的点
        min_dist = float('inf')
        target_idx = -1
        for i, point in enumerate(filtered_points):
            dist = np.sqrt((point[0] - target_point[0]) ** 2 + (point[1] - target_point[1]) ** 2)
            if dist < min_dist:
                min_dist = dist
                target_idx = i
        
        # 将离目标最近的点移到最后
        if target_idx != -1 and target_idx != len(filtered_points) - 1:
            target_item = filtered_points.pop(target_idx)
            filtered_points.append(target_item)
            print(f"   将离目标点最近的点 (索引{target_idx}, 距离{min_dist:.1f}) 移到末尾")
    
    # ========== 步骤 3: 输出统计 ==========
    print("\n📊 过滤统计:")
    print(f"   原始点数：{original_count}")
    print(f"   过滤后点数：{len(filtered_points)}")
    print(f"   移除点数：{removed_count}")
    print(f"   保留率：{len(filtered_points) / original_count * 100:.1f}%")
    
    return {
        "success": True,
        "original_points": original_count,
        "filtered_points": len(filtered_points),
        "on_floor_count": len(on_floor_points),
        "off_floor_count": len(off_floor_points),
        "removed_count": removed_count,
        "trajectory": filtered_points,
        "on_floor_details": on_floor_points,
        "off_floor_details": off_floor_points
    }


def visualize_trajectory_comparison(
    image_path: str,
    original_trajectory: List[List[float]],
    filtered_trajectory: List[List[float]],
    floor_mask: np.ndarray,
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    output_path: Optional[str] = None
) -> str:
    """
    可视化轨迹过滤前后的对比
    
    Args:
        image_path: depth_masks 图像路径
        original_trajectory: 原始轨迹
        filtered_trajectory: 过滤后的轨迹
        floor_mask: 地板掩码
        start_point: 起点坐标
        target_point: 目标点坐标
        output_path: 输出图像路径
        
    Returns:
        输出图像路径
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    
    # 创建左右并排的对比图
    combined_image = np.zeros((h, w * 2, 3), dtype=np.uint8)
    combined_image[:h, :w] = image_rgb
    combined_image[:h, w:] = image_rgb
    
    # 添加标题
    cv2.putText(combined_image, "Before Filtering", (w // 2 - 100, 30),
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    cv2.putText(combined_image, "After Filtering", (w + w // 2 - 80, 30),
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    def draw_trajectory(img, trajectory, offset_x=0):
        """在图像上绘制轨迹"""
        if len(trajectory) < 2:
            return
        
        points = [(int(p[0]) + offset_x, int(p[1])) for p in trajectory]
        
        # 绘制轨迹线
        for i in range(len(points) - 1):
            t = i / (len(points) - 1)
            color = (int(0 * (1 - t) + 255 * t), int(255 * (1 - t) + 0 * t), 0)
            cv2.line(img, points[i], points[i+1], color, 2)
        
        # 绘制轨迹点
        for i, pt in enumerate(points):
            if i == 0:
                # 起点：绿色
                cv2.circle(img, pt, 8, (0, 255, 0), -1)
            elif i == len(points) - 1:
                # 终点：红色
                cv2.circle(img, pt, 8, (0, 0, 255), -1)
            else:
                # 中间点：蓝色
                cv2.circle(img, pt, 6, (255, 0, 0), -1)
    
    # 绘制原始轨迹（左侧）
    draw_trajectory(combined_image, original_trajectory, offset_x=0)
    
    # 绘制过滤后的轨迹（右侧）
    draw_trajectory(combined_image, filtered_trajectory, offset_x=w)
    
    # 保存
    if output_path is None:
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.dirname(image_path)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(output_dir, f"{base_name}_trajectory_comparison_{timestamp}.png")
    
    output_bgr = cv2.cvtColor(combined_image, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 轨迹对比图已保存：{output_path}")
    
    return output_path


def visualize_filtered_trajectory(
    image_path: str,
    trajectory: List[List[float]],
    floor_mask: np.ndarray,
    start_point: Tuple[int, int],
    target_point: Optional[List[float]] = None,
    filter_result: Optional[dict] = None,
    output_path: Optional[str] = None
) -> str:
    """
    可视化过滤后的轨迹
    
    Args:
        image_path: depth_masks 图像路径
        trajectory: 过滤后的轨迹
        floor_mask: 地板掩码
        start_point: 起点坐标
        target_point: 目标点坐标
        filter_result: 过滤结果字典
        output_path: 输出图像路径
        
    Returns:
        输出图像路径
    """
    # 读取图像
    image = cv2.imread(image_path)
    if image is None:
        print(f"❌ 无法读取图像：{image_path}")
        return None
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = image_rgb.shape[:2]
    
    # 创建叠加层
    overlay = image_rgb.copy()
    
    # 绘制地板掩码（半透明绿色）
    floor_overlay = overlay.copy()
    floor_overlay[floor_mask] = [0, 255, 0]
    cv2.addWeighted(floor_overlay, 0.3, overlay, 0.7, 0, overlay)
    
    # 绘制轨迹
    if len(trajectory) >= 2:
        points = [(int(p[0]), int(p[1])) for p in trajectory]
        
        # 绘制轨迹线（渐变色）
        for i in range(len(points) - 1):
            t = i / (len(points) - 1)
            color = (int(0 * (1 - t) + 255 * t), int(255 * (1 - t) + 0 * t), 0)
            cv2.line(overlay, points[i], points[i+1], color, 3)
        
        # 绘制轨迹点
        for i, pt in enumerate(points):
            if i == 0:
                # 起点：绿色大圆圈
                cv2.circle(overlay, pt, 12, (0, 255, 0), -1)
                cv2.putText(overlay, "S", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            elif i == len(points) - 1:
                # 终点：红色大圆圈
                cv2.circle(overlay, pt, 12, (0, 0, 255), -1)
                cv2.putText(overlay, "T", (pt[0] - 8, pt[1] + 8),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            else:
                # 中间点：白色小圆圈
                cv2.circle(overlay, pt, 6, (255, 255, 255), -1)
    
    # 添加统计信息
    stats_y = 25
    stats_x = 10
    font_scale = 0.5
    
    cv2.putText(overlay, f"Points: {len(trajectory)}", (stats_x, stats_y),
               cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 1)
    
    if filter_result:
        cv2.putText(overlay, f"Removed: {filter_result.get('removed_count', 0)}", 
                   (stats_x, stats_y + 20),
                   cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 1)
        cv2.putText(overlay, f"On Floor: {filter_result.get('on_floor_count', 0)}", 
                   (stats_x, stats_y + 40),
                   cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 1)
    
    # 保存
    if output_path is None:
        base_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.dirname(image_path)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = os.path.join(output_dir, f"{base_name}_trajectory_filtered_{timestamp}.png")
    
    output_bgr = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
    cv2.imwrite(output_path, output_bgr)
    print(f"✅ 过滤后轨迹可视化已保存：{output_path}")
    
    return output_path


def run_main_pipeline(image_path: str, instruction: str, output_dir: str):
    """运行 main.py 生成分割掩码"""
    print("\n" + "=" * 80)
    print("📦 步骤 1: 运行 main.py 生成分割掩码")
    print("=" * 80)
    print(f"图像：{image_path}")
    print(f"指令：{instruction}")
    print(f"输出目录：{output_dir}")

    script_dir = os.path.dirname(os.path.abspath(__file__))
    cmd = [
        sys.executable,
        "main.py",
        "--image", image_path,
        "--instruction", instruction,
        "--output-dir", output_dir
    ]

    # 捕获输出以提取目标点坐标
    result = subprocess.run(cmd, cwd=script_dir, capture_output=True, text=True)

    # 打印输出
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)

    if result.returncode != 0:
        print(f"❌ main.py 运行失败，退出码：{result.returncode}")
        return None, None

    # 从输出中提取目标点 2D 坐标
    target_point_2d = None
    for line in result.stdout.split('\n'):
        if '目标点 2D:' in line:
            try:
                # 解析 "目标点 2D: [x, y]" 格式
                target_point_2d = json.loads(line.split('目标点 2D:')[1].strip())
                print(f"\n✅ 提取目标点 2D: {target_point_2d}")
            except Exception as e:
                print(f"⚠️ 解析目标点失败：{e}")
            break

    # 查找生成的 depth_masks 图像
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    depth_masks_path = os.path.join(output_dir, base_name, f"{base_name}_depth_masks.png")

    if os.path.exists(depth_masks_path):
        print(f"✅ 找到 depth_masks: {depth_masks_path}")
        return depth_masks_path, target_point_2d

    # 尝试不带子目录的路径
    alt_path = os.path.join(output_dir, f"{base_name}_depth_masks.png")
    if os.path.exists(alt_path):
        print(f"✅ 找到 depth_masks (备用路径): {alt_path}")
        return alt_path, target_point_2d

    print(f"❌ 未找到 depth_masks 文件")
    print(f"   预期路径：{depth_masks_path}")
    return None, None


def run_vlm_trajectory(depth_masks_path: str, start_point: tuple = (310, 450), target_point_2d: list = None):
    """运行 test_vlm_trajectory.py 预测轨迹"""
    print("\n" + "=" * 80)
    print("🤖 步骤 2: 运行 VLM 轨迹预测")
    print("=" * 80)
    print(f"depth_masks: {depth_masks_path}")
    print(f"起点坐标：{start_point}")
    if target_point_2d:
        print(f"目标点 2D: {target_point_2d}")

    script_dir = os.path.dirname(os.path.abspath(__file__))
    test_script = os.path.join(script_dir, "test_vlm_trajectory.py")

    # 更新 test_vlm_trajectory.py 中的 START_POINT
    with open(test_script, 'r') as f:
        content = f.read()

    # 使用正则表达式更新 START_POINT
    import re
    new_start_def = f'START_POINT = {start_point}  # (x, y)'
    content = re.sub(
        r'START_POINT\s*=\s*\([^)]+\)',
        new_start_def,
        content
    )

    # 更新 TARGET_POINT（如果提供了目标点）
    if target_point_2d:
        new_target_def = f'TARGET_POINT = {target_point_2d}  # (x, y)'
        content = re.sub(
            r'TARGET_POINT\s*=\s*(None|\[[^\]]+\])',
            new_target_def,
            content
        )

    with open(test_script, 'w') as f:
        f.write(content)

    print(f"✅ 已更新起点坐标：{start_point}")
    if target_point_2d:
        print(f"✅ 已更新目标点坐标：{target_point_2d}")

    # 运行 test_vlm_trajectory.py
    cmd = [
        sys.executable,
        "test_vlm_trajectory.py",
        depth_masks_path
    ]

    result = subprocess.run(cmd, cwd=script_dir)

    if result.returncode != 0:
        print(f"❌ VLM 轨迹预测失败，退出码：{result.returncode}")
        return None

    # 返回轨迹数据路径
    base_name = os.path.splitext(os.path.basename(depth_masks_path))[0]
    output_dir = os.path.dirname(depth_masks_path)
    trajectory_data_path = os.path.join(output_dir, f"{base_name}_trajectory_data.json")

    if os.path.exists(trajectory_data_path):
        print(f"✅ 轨迹数据已保存：{trajectory_data_path}")
        return trajectory_data_path

    return None


def main():
    parser = argparse.ArgumentParser(description="统一运行 2D 轨迹规划 pipeline")
    parser.add_argument("--image", type=str, required=True, help="输入 RGB 图像路径")
    parser.add_argument("--instruction", type=str, required=True, help="用户指令，如'远处的垃圾桶'")
    parser.add_argument("--output_dir", type=str,
                        default="/workspace/wxd/Agent/images/trajectory_2D_results",
                        help="输出目录")
    parser.add_argument("--start_x", type=int, default=310, help="起点 x 坐标")
    parser.add_argument("--start_y", type=int, default=450, help="起点 y 坐标")
    parser.add_argument("--distance_threshold", type=float, default=5.0,
                        help="去重距离阈值（像素），默认 5.0")
    parser.add_argument("--skip_postprocess", action="store_true",
                        help="跳过轨迹点后处理")
    parser.add_argument("--filter_floor", action="store_true",
                        help="启用地板约束过滤（移除不在地板上的点）")
    parser.add_argument("--save_comparison", action="store_true",
                        help="保存过滤前后的可视化对比图")
    parser.add_argument("--render_view", action="store_true",
                        help="渲染轨迹点新视角图像")
    parser.add_argument("--render_all_views", action="store_true",
                        help="渲染所有轨迹点的新视角图像（从起点到倒数第二个点）")
    parser.add_argument("--view_index", type=int, default=-1,
                        help="要渲染的轨迹点索引（-1=最后一个点，-2=倒数第二个点）")
    parser.add_argument("--yaw_offset", type=float, default=0.0,
                        help="额外的 yaw 偏移（度）")
    parser.add_argument("--camera_height", type=float, default=0.06,
                        help="相机高度偏移（米），默认 0.5 米")

    args = parser.parse_args()

    # 检查输入图像
    if not os.path.exists(args.image):
        print(f"❌ 输入图像不存在：{args.image}")
        sys.exit(1)

    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)

    start_point = (args.start_x, args.start_y)

    # 步骤 1: 运行 main.py
    depth_masks_path, target_point_2d = run_main_pipeline(args.image, args.instruction, args.output_dir)

    if depth_masks_path is None:
        print("❌ 步骤 1 失败，无法继续")
        sys.exit(1)

    # 步骤 2: 运行 VLM 轨迹预测
    trajectory_data_path = run_vlm_trajectory(depth_masks_path, start_point, target_point_2d)

    if trajectory_data_path is None:
        print("❌ 步骤 2 失败")
        sys.exit(1)

    # 完成
    print("\n" + "=" * 80)
    print("✅ Pipeline 完成!")
    print("=" * 80)
    print(f"depth_masks: {depth_masks_path}")
    print(f"轨迹数据：{trajectory_data_path}")

    # 加载并显示轨迹数据
    with open(trajectory_data_path, 'r') as f:
        trajectory_data = json.load(f)

    print(f"\n📍 原始轨迹点序列 ({len(trajectory_data.get('trajectory', []))} 个点):")
    for i, point in enumerate(trajectory_data.get('trajectory', [])):
        marker = "🟢" if i == 0 else ("🎯" if i == len(trajectory_data['trajectory']) - 1 else "⚪")
        print(f"  {marker} 点 {i}: {point}")

    if trajectory_data.get('validation'):
        coverage = trajectory_data['validation'].get('floor_coverage', 0)
        print(f"\n📊 地板覆盖率：{coverage * 100:.1f}%")

    # ========== 步骤 3: 轨迹点后处理（去重 + 排序）==========
    if not args.skip_postprocess:
        postprocess_result = postprocess_trajectory(
            trajectory=trajectory_data.get('trajectory', []),
            start_point=start_point,
            target_point=target_point_2d,
            distance_threshold=args.distance_threshold
        )

        if postprocess_result['success']:
            # 更新轨迹数据
            trajectory_data['trajectory'] = postprocess_result['trajectory']
            trajectory_data['postprocess'] = postprocess_result

            # 保存后处理后的轨迹数据
            base_name = os.path.splitext(os.path.basename(trajectory_data_path))[0]
            output_dir = os.path.dirname(trajectory_data_path)
            postprocessed_path = os.path.join(output_dir, f"{base_name}_trajectory_data_postprocessed.json")

            with open(postprocessed_path, 'w', encoding='utf-8') as f:
                json.dump(trajectory_data, f, ensure_ascii=False, indent=2)

            print(f"\n✅ 后处理轨迹数据已保存：{postprocessed_path}")

            # 显示后处理后的轨迹
            print(f"\n📍 后处理轨迹点序列 ({postprocess_result['sorted_points']} 个点):")
            for i, point in enumerate(postprocess_result['trajectory']):
                marker = "🟢" if i == 0 else ("🎯" if i == len(postprocess_result['trajectory']) - 1 else "⚪")
                print(f"  {marker} 点 {i}: [{point[0]:.1f}, {point[1]:.1f}]")
        else:
            print(f"\n⚠️ 后处理失败：{postprocess_result.get('error', '未知错误')}")

    # ========== 步骤 4: 地板约束过滤（可选）==========
    if args.filter_floor:
        print("\n" + "=" * 80)
        print("🌍 步骤 4: 地板约束过滤")
        print("=" * 80)
        
        # 提取地板掩码
        floor_mask = extract_floor_mask(depth_masks_path)
        
        if floor_mask is not None:
            # 获取当前轨迹（后处理后的或原始的）
            current_trajectory = trajectory_data.get('trajectory', [])
            
            # 地板约束过滤
            filter_result = filter_trajectory_on_floor(
                trajectory=current_trajectory,
                floor_mask=floor_mask,
                start_point=start_point,
                target_point=target_point_2d
            )
            
            if filter_result['success']:
                # 更新轨迹数据
                trajectory_data['trajectory'] = filter_result['trajectory']
                trajectory_data['floor_filter'] = filter_result
                
                # 保存过滤后的轨迹数据
                base_name = os.path.splitext(os.path.basename(trajectory_data_path))[0]
                output_dir = os.path.dirname(trajectory_data_path)
                filtered_path = os.path.join(output_dir, f"{base_name}_trajectory_data_filtered.json")
                
                with open(filtered_path, 'w', encoding='utf-8') as f:
                    json.dump(trajectory_data, f, ensure_ascii=False, indent=2)
                
                print(f"\n✅ 过滤后轨迹数据已保存：{filtered_path}")
                
                # 显示过滤后的轨迹
                print(f"\n📍 过滤后轨迹点序列 ({len(filter_result['trajectory'])} 个点):")
                for i, point in enumerate(filter_result['trajectory']):
                    marker = "🟢" if i == 0 else ("🎯" if i == len(filter_result['trajectory']) - 1 else "⚪")
                    print(f"  {marker} 点 {i}: [{point[0]:.1f}, {point[1]:.1f}]")
                
                # 生成可视化
                if args.save_comparison:
                    # 保存过滤前后对比图
                    visualize_trajectory_comparison(
                        image_path=depth_masks_path,
                        original_trajectory=current_trajectory,
                        filtered_trajectory=filter_result['trajectory'],
                        floor_mask=floor_mask,
                        start_point=start_point,
                        target_point=target_point_2d
                    )
                
                # 保存过滤后轨迹可视化
                visualize_filtered_trajectory(
                    image_path=depth_masks_path,
                    trajectory=filter_result['trajectory'],
                    floor_mask=floor_mask,
                    start_point=start_point,
                    target_point=target_point_2d,
                    filter_result=filter_result
                )
                
                # ========== 步骤 4.5: 轨迹点插值（如果点数太少）==========
                if len(filter_result['trajectory']) < 10:
                    print("\n" + "=" * 80)
                    print("📐 步骤 4.5: 轨迹点插值（点数太少）")
                    print("=" * 80)
                    
                    # 对过滤后的轨迹进行插值
                    interp_result = interpolate_trajectory(
                        trajectory=filter_result['trajectory'],
                        floor_mask=floor_mask,
                        min_points=10,
                        max_density=15.0
                    )
                    
                    if interp_result['success'] and interp_result.get('interpolated'):
                        # 更新轨迹数据
                        trajectory_data['trajectory'] = interp_result['trajectory']
                        trajectory_data['interpolation'] = interp_result
                        
                        # 保存插值后的轨迹数据
                        base_name = os.path.splitext(os.path.basename(trajectory_data_path))[0]
                        output_dir = os.path.dirname(trajectory_data_path)
                        interpolated_path = os.path.join(output_dir, f"{base_name}_trajectory_data_interpolated.json")
                        
                        with open(interpolated_path, 'w', encoding='utf-8') as f:
                            json.dump(trajectory_data, f, ensure_ascii=False, indent=2)
                        
                        print(f"\n✅ 插值后轨迹数据已保存：{interpolated_path}")
                        
                        # 显示插值后的轨迹
                        print(f"\n📍 插值后轨迹点序列 ({len(interp_result['trajectory'])} 个点):")
                        for i, point in enumerate(interp_result['trajectory']):
                            marker = "🟢" if i == 0 else ("🎯" if i == len(interp_result['trajectory']) - 1 else "⚪")
                            print(f"  {marker} 点 {i}: [{point[0]:.1f}, {point[1]:.1f}]")
                        
                        # ========== 步骤 4.5.1: 可视化插值后轨迹 ==========
                        # 获取输出目录（与 depth_masks 同一目录）
                        output_subdir = os.path.dirname(depth_masks_path)
                        
                        # 在 depth_masks 上可视化
                        visualize_trajectory_on_image(
                            image_path=depth_masks_path,
                            trajectory=interp_result['trajectory'],
                            start_point=start_point,
                            target_point=target_point_2d,
                            title=f"Interpolated Trajectory ({len(interp_result['trajectory'])} points)",
                            output_dir=output_subdir  # 保存到输出目录
                        )
                        
                        # 在原图上可视化
                        visualize_trajectory_on_image(
                            image_path=args.image,
                            trajectory=interp_result['trajectory'],
                            start_point=start_point,
                            target_point=target_point_2d,
                            title=f"Interpolated Trajectory on Original Image",
                            output_dir=output_subdir  # 保存到输出目录
                        )
                        
                    elif interp_result['success']:
                        print(f"\nℹ️  点数已足够 ({len(filter_result['trajectory'])} >= 10)，跳过插值")
            else:
                print(f"\n⚠️ 地板约束过滤失败：{filter_result.get('error', '未知错误')}")
        else:
            print("\n⚠️ 无法提取地板掩码，跳过地板约束过滤")

    # ========== 步骤 5: 新视角渲染（可选）==========
    if args.render_view or args.render_all_views:
        print("\n" + "=" * 80)
        print("🎨 步骤 5: 新视角渲染")
        print("=" * 80)

        from render_trajectory_view import TrajectoryViewRenderer, load_depth_map_from_npy, load_depth_map_from_image

        # 加载原始图像
        original_image = cv2.imread(args.image)
        if original_image is None:
            print(f"❌ 无法读取原始图像：{args.image}")
        else:
            base_name = os.path.splitext(os.path.basename(args.image))[0]

            # 优先从 .npy 加载真实深度图
            depth_npy_path = os.path.join(args.output_dir, base_name, f"{base_name}_depth_map.npy")
            depth_map = load_depth_map_from_npy(depth_npy_path)

            # 如果 .npy 不存在，使用 depth_masks 作为备用
            if depth_map is None:
                depth_map = load_depth_map_from_image(depth_masks_path)

            if depth_map is not None:
                # 生成点云（从深度图）
                print("🔧 从深度图生成点云...")
                h, w = depth_map.shape
                focal_length = w / (2 * np.tan(np.deg2rad(60) / 2))
                cx, cy = w / 2, h / 2

                y, x = np.meshgrid(np.arange(h), np.arange(w), indexing='ij')
                cam_x = (x - cx) * depth_map / focal_length
                cam_y = (y - cy) * depth_map / focal_length
                cam_z = depth_map

                point_cloud = np.stack([cam_x, cam_y, cam_z], axis=-1)
                print(f"✅ 点云已生成：{w}x{h}")

                # 获取当前轨迹（优先使用插值后的，其次是过滤后的，最后是后处理后的）
                current_trajectory = trajectory_data.get('trajectory', [])

                if len(current_trajectory) >= 2:
                    # 渲染新视角
                    renderer = TrajectoryViewRenderer(output_dir=os.path.dirname(depth_masks_path))

                    # 确定要渲染的轨迹点索引列表
                    if args.render_all_views:
                        # 渲染从第一个点到倒数第二个点（不包含最后一个点）
                        view_indices = list(range(0, len(current_trajectory) - 1))
                        print(f"📸 渲染所有轨迹点的新视角：{len(view_indices)} 个视角")
                    else:
                        # 只渲染指定的单个轨迹点
                        target_idx = args.view_index if args.view_index >= 0 else len(current_trajectory) + args.view_index
                        target_idx = max(0, min(target_idx, len(current_trajectory) - 1))
                        view_indices = [target_idx]
                        print(f"📸 渲染单个轨迹点的新视角：索引 #{target_idx}")

                    # 遍历渲染
                    rendered_files = []
                    for idx in view_indices:
                        result = renderer.render_view(
                            point_cloud=point_cloud,
                            original_image=original_image,
                            depth_map=depth_map,
                            trajectory=current_trajectory,
                            view_index=idx,
                            yaw_offset=args.yaw_offset,
                            image_path=args.image,
                            camera_height_offset=args.camera_height
                        )

                        if result:
                            rendered_files.append(result)
                            print(f"   ✅ 渲染完成：{result['rendered_image']}")

                    if rendered_files:
                        print(f"\n✅ 新视角渲染完成!")
                        print(f"   共渲染 {len(rendered_files)} 个视角")
                        for r in rendered_files:
                            print(f"   - 视角 #{r['view_index']}: {os.path.basename(r['rendered_image'])}")
                else:
                    print("⚠️ 轨迹点数量不足，跳过渲染")


if __name__ == "__main__":
    main()
