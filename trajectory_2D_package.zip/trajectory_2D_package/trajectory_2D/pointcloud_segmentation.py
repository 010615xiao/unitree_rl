#!/usr/bin/env python3
"""
点云分割模块
使用 SAM2 掩码和 MoGe2 点云来分离场景点云、目标点云和地板点云
"""

import numpy as np
import torch
import cv2
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class PointCloudData:
    """点云数据类"""
    points: np.ndarray  # [N, 3] XYZ 坐标
    colors: Optional[np.ndarray] = None  # [N, 3] RGB 颜色
    depths: Optional[np.ndarray] = None  # [N] 深度值
    mask: Optional[np.ndarray] = None  # [H, W] 2D 掩码


class PointCloudSegmentator:
    """点云分割器"""

    def __init__(self, device: str = "cuda", model_path: str = None):
        """
        初始化点云分割器

        Args:
            device: 计算设备
            model_path: MoGe2 模型路径（如果提供则自动加载）
        """
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.moge_model = None
        self.model_path = model_path or "/workspace/wxd/Agent/Spagent/spagent/checkpoints/moge2/moge-2-vitl-normal/model.pt"
        
        # 自动加载模型
        self.load_moge2(self.model_path)
        print(f"🔧 点云分割器已初始化，设备：{self.device}")

    def load_moge2(self, model_path: str) -> None:
        """
        加载 MoGe2 模型

        Args:
            model_path: MoGe2 模型路径
        """
        import sys
        sys.path.insert(0, "/workspace/wxd/Agent/Spagent/spagent/checkpoints/moge2/MoGe")
        from moge.model.v2 import MoGeModel

        print("🔄 加载 MoGe2 模型...")
        self.moge_model = MoGeModel.from_pretrained(model_path).to(self.device)
        self.moge_model.eval()
        print("✅ MoGe2 模型已加载")

    def generate_point_cloud(
        self,
        image_path: str
    ) -> Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
        """
        从图像生成点云和深度图

        Args:
            image_path: 图像路径

        Returns:
            point_cloud: [H, W, 3] 点云
            depth_map: [H, W] 深度图
            image_rgb: [H, W, 3] RGB 图像
        """
        # 读取图像
        image_bgr = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        h, w = image_rgb.shape[:2]

        # 预处理
        input_tensor = torch.tensor(
            image_rgb / 255.0,
            dtype=torch.float32,
            device=self.device
        ).permute(2, 0, 1)

        # 推理
        with torch.no_grad():
            output = self.moge_model.infer(input_tensor)

        # 提取结果
        point_cloud = output["points"].cpu().numpy()  # [H, W, 3]
        depth_map = output["depth"].cpu().numpy()  # [H, W]

        print(f"✅ 点云已生成：{w}x{h}, X 范围 [{point_cloud[:,:,0].min():.2f}, {point_cloud[:,:,0].max():.2f}]")
        print(f"   深度范围：{depth_map.min():.2f}-{depth_map.max():.2f} 米")

        return point_cloud, depth_map, image_rgb

    def segment_target_cloud(
        self,
        point_cloud: np.ndarray,
        depth_map: np.ndarray,
        image_rgb: np.ndarray,
        target_mask: np.ndarray
    ) -> PointCloudData:
        """
        从场景中提取目标物体的点云

        Args:
            point_cloud: [H, W, 3] 完整场景点云
            depth_map: [H, W] 深度图
            image_rgb: [H, W, 3] RGB 图像
            target_mask: [H, W] 目标物体 2D 掩码

        Returns:
            PointCloudData 包含目标物体点云
        """
        # 使用掩码提取点
        target_points = point_cloud[target_mask]
        target_colors = image_rgb[target_mask]
        target_depths = depth_map[target_mask]

        # 过滤无效点（NaN 或深度异常）
        valid_mask = ~np.isnan(target_points[:, 0]) & ~np.isnan(target_points[:, 1]) & ~np.isnan(target_points[:, 2])
        valid_mask &= (target_depths > 0) & (target_depths < depth_map.max() * 0.95)

        print(f"🎯 目标点云：{valid_mask.sum()} / {len(target_points)} 个有效点 ({100*valid_mask.sum()/len(target_points):.1f}%)")

        return PointCloudData(
            points=target_points[valid_mask],
            colors=target_colors[valid_mask],
            depths=target_depths[valid_mask],
            mask=target_mask
        )

    def segment_floor_cloud(
        self,
        point_cloud: np.ndarray,
        depth_map: np.ndarray,
        image_rgb: np.ndarray,
        target_mask: np.ndarray,
        floor_prompt: str = "floor"
    ) -> PointCloudData:
        """
        提取地板点云

        策略：
        1. 在目标物体下方区域寻找
        2. 选择 Y 坐标较大（在图像下方）且深度合理的点
        3. 使用几何约束过滤

        Args:
            point_cloud: [H, W, 3] 完整场景点云
            depth_map: [H, W] 深度图
            image_rgb: [H, W, 3] RGB 图像
            target_mask: [H, W] 目标物体掩码
            floor_prompt: 地面提示词（用于 GroundingDINO 检测）

        Returns:
            PointCloudData 包含地板点云
        """
        h, w = target_mask.shape[:2]

        # 策略 1: 在目标物体下方寻找地板
        # 获取目标物体的底部边界
        ys, xs = np.where(target_mask)
        if len(ys) > 0:
            bottom_y = ys.max()
            # 在物体下方扩展搜索区域
            search_start = min(bottom_y + 20, h - 1)
            search_end = h

            # 获取物体的 x 范围
            x_min, x_max = xs.min(), xs.max()
            x_margin = int((x_max - x_min) * 0.5)
            search_x_min = max(0, x_min - x_margin)
            search_x_max = min(w - 1, x_max + x_margin)

            # 创建地板搜索掩码
            floor_search_mask = np.zeros((h, w), dtype=bool)
            floor_search_mask[search_start:search_end, search_x_min:search_x_max] = True
        else:
            # 如果没有目标掩码，使用图像下半部分
            floor_search_mask = np.zeros((h, w), dtype=bool)
            floor_search_mask[h//2:, :] = True

        # 策略 2: 使用几何特征过滤地板点
        # 地板点特征：
        # - Y 坐标较大（在相机坐标系中向下）
        # - 深度值相对均匀
        # - 在图像下方区域

        # 获取搜索区域内的点
        search_points = point_cloud[floor_search_mask]
        search_depths = depth_map[floor_search_mask]
        search_colors = image_rgb[floor_search_mask]

        if len(search_points) == 0:
            print("⚠️ 未找到地板搜索区域")
            return PointCloudData(points=np.array([]))

        # 过滤无效点
        valid_mask = ~np.isnan(search_points[:, 0]) & \
                     ~np.isnan(search_points[:, 1]) & \
                     ~np.isnan(search_points[:, 2])
        valid_mask &= (search_depths > 0)

        search_points = search_points[valid_mask]
        search_depths = search_depths[valid_mask]
        search_colors = search_colors[valid_mask]

        if len(search_points) == 0:
            print("⚠️ 未找到有效地板点")
            return PointCloudData(points=np.array([]))

        # 策略 3: 选择 Y 坐标最大的点（最可能是地板）
        # 在相机坐标系中，Y 向下为正，地板通常有较大的 Y 值
        y_percentile = np.percentile(search_points[:, 1], 70)
        floor_mask = search_points[:, 1] >= y_percentile

        # 深度过滤：去除异常值
        median_depth = np.median(search_depths[floor_mask])
        depth_threshold = median_depth * 1.5
        floor_mask &= search_depths < depth_threshold

        floor_points = search_points[floor_mask]
        floor_colors = search_colors[floor_mask]
        floor_depths = search_depths[floor_mask]

        print(f"🏠 地板点云：{len(floor_points)} 个点")
        print(f"   Y 坐标范围：[{floor_points[:,1].min():.2f}, {floor_points[:,1].max():.2f}] 米")
        print(f"   深度范围：[{floor_depths.min():.2f}, {floor_depths.max():.2f}] 米")

        # 创建完整的地板掩码
        full_floor_mask = np.zeros((h, w), dtype=bool)
        full_floor_mask[floor_search_mask] = floor_mask

        return PointCloudData(
            points=floor_points,
            colors=floor_colors,
            depths=floor_depths,
            mask=full_floor_mask
        )

    def segment_scene_cloud(
        self,
        point_cloud: np.ndarray,
        depth_map: np.ndarray,
        image_rgb: np.ndarray,
        target_mask: np.ndarray,
        floor_mask: np.ndarray
    ) -> PointCloudData:
        """
        提取场景点云（去除目标和地板）

        Args:
            point_cloud: [H, W, 3] 完整场景点云
            depth_map: [H, W] 深度图
            image_rgb: [H, W, 3] RGB 图像
            target_mask: [H, W] 目标物体掩码
            floor_mask: [H, W] 地板掩码

        Returns:
            PointCloudData 包含场景点云（背景）
        """
        # 场景点云 = 完整点云 - 目标点云 - 地板点云
        exclude_mask = target_mask | floor_mask
        scene_mask = ~exclude_mask

        scene_points = point_cloud[scene_mask]
        scene_colors = image_rgb[scene_mask]
        scene_depths = depth_map[scene_mask]

        # 过滤无效点
        valid_mask = ~np.isnan(scene_points[:, 0]) & \
                     ~np.isnan(scene_points[:, 1]) & \
                     ~np.isnan(scene_points[:, 2])
        valid_mask &= (scene_depths > 0)

        print(f"🌍 场景点云：{valid_mask.sum()} 个点")

        return PointCloudData(
            points=scene_points[valid_mask],
            colors=scene_colors[valid_mask],
            depths=scene_depths[valid_mask],
            mask=scene_mask
        )

    def segment(
        self,
        depth_map: np.ndarray,
        point_cloud: np.ndarray,
        target_mask: np.ndarray,
        floor_mask: np.ndarray,
        image_rgb: Optional[np.ndarray] = None
    ) -> Dict[str, PointCloudData]:
        """
        使用已生成的点云和掩码分割所有点云

        Args:
            depth_map: [H, W] 深度图
            point_cloud: [H, W, 3] 点云
            target_mask: [H, W] 目标物体掩码
            floor_mask: [H, W] 地板掩码
            image_rgb: [H, W, 3] RGB 图像（可选）

        Returns:
            字典包含：
            - scene: 场景点云
            - target: 目标点云
            - floor: 地板点云
            - full: 完整点云
        """
        h, w = point_cloud.shape[:2]
        
        # 如果没有提供图像，使用深度图转换为伪彩色
        if image_rgb is None:
            image_rgb = cv2.cvtColor((depth_map / depth_map.max() * 255).astype(np.uint8), cv2.COLOR_GRAY2RGB)

        # 分割各部分
        target_cloud = self.segment_target_cloud(
            point_cloud, depth_map, image_rgb, target_mask
        )

        # 使用 floor_mask 创建 floor 点云
        floor_points = point_cloud[floor_mask]
        floor_colors = image_rgb[floor_mask]
        floor_depths = depth_map[floor_mask]
        
        # 过滤无效点
        valid_mask = ~np.isnan(floor_points[:, 0]) & \
                     ~np.isnan(floor_points[:, 1]) & \
                     ~np.isnan(floor_points[:, 2])
        valid_mask &= (floor_depths > 0)
        
        floor_cloud = PointCloudData(
            points=floor_points[valid_mask],
            colors=floor_colors[valid_mask],
            depths=floor_depths[valid_mask],
            mask=floor_mask
        )
        print(f"🏠 地板点云：{valid_mask.sum()} 个点")

        scene_cloud = self.segment_scene_cloud(
            point_cloud, depth_map, image_rgb,
            target_mask, floor_mask
        )

        # 完整点云
        full_cloud = PointCloudData(
            points=point_cloud.reshape(-1, 3),
            colors=image_rgb.reshape(-1, 3),
            depths=depth_map.reshape(-1),
            mask=np.ones((h, w), dtype=bool)
        )

        return {
            "scene": scene_cloud,
            "target": target_cloud,
            "floor": floor_cloud,
            "full": full_cloud
        }

    def segment_all(
        self,
        image_path: str,
        target_mask: np.ndarray,
        floor_mask: Optional[np.ndarray] = None
    ) -> Dict[str, PointCloudData]:
        """
        一次性分割所有点云（场景、目标、地板）

        Args:
            image_path: 图像路径
            target_mask: [H, W] 目标物体掩码
            floor_mask: [H, W] 地板掩码（可选）

        Returns:
            字典包含：
            - scene: 场景点云
            - target: 目标点云
            - floor: 地板点云
            - full: 完整点云
        """
        # 生成完整点云
        point_cloud, depth_map, image_rgb = self.generate_point_cloud(image_path)

        # 如果没有提供 floor_mask，使用启发式方法
        if floor_mask is None:
            h, w = depth_map.shape
            floor_mask = np.zeros((h, w), dtype=bool)
            floor_mask[int(h*0.8):, :] = True

        # 使用 segment 方法
        return self.segment(depth_map, point_cloud, target_mask, floor_mask, image_rgb)
