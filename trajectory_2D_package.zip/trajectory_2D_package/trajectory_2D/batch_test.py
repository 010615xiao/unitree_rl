#!/usr/bin/env python3
"""
批量测试脚本（HTTP 服务版本）
测试连续图像帧中的轨迹规划能力

直接调用 run_pipeline.py，
所有轨迹可视化结果保存在同一个文件夹中

使用示例:
    python batch_test.py --start 16 --end 100 --instruction "右边的椅子"
    python batch_test.py --images frame_0016.png frame_0020.png --instruction "远处的桌子"
"""

import sys
import os
import argparse
import json
import subprocess
import numpy as np
from datetime import datetime
from pathlib import Path

# 添加路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 导入 test_vlm_trajectory.py 中的可视化函数（与 run_pipeline.py 使用相同的函数）
from test_vlm_trajectory import visualize_trajectory_on_image


def generate_image_paths(start_frame: int, end_frame: int, base_dir: str) -> list:
    """生成图像路径列表"""
    image_paths = []
    for i in range(start_frame, end_frame + 1):
        image_path = os.path.join(base_dir, f"frame_{i:04d}.png")
        if os.path.exists(image_path):
            image_paths.append(image_path)
        else:
            print(f"⚠️  图像不存在：{image_path}")
    return image_paths


def batch_test(image_paths: list, instruction: str, output_dir: str,
               start_point: tuple = (310, 450)):
    """批量测试"""

    print("\n" + "=" * 80)
    print("📊 批量轨迹规划测试（HTTP 服务版本）")
    print("=" * 80)
    print(f"测试图像数量：{len(image_paths)}")
    print(f"指令：{instruction}")
    print(f"起点坐标：{start_point}")
    print(f"输出目录：{output_dir}")
    print("=" * 80)

    # 创建输出目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(output_dir, f"batch_{timestamp}")
    os.makedirs(output_dir, exist_ok=True)

    # 结果统计
    results = []
    success_count = 0
    fail_count = 0

    # 获取 run_pipeline.py 路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    run_pipeline_path = os.path.join(script_dir, "run_pipeline.py")

    for idx, image_path in enumerate(image_paths):
        frame_name = os.path.splitext(os.path.basename(image_path))[0]
        print(f"\n{'='*80}")
        print(f"📷 测试进度：[{idx+1}/{len(image_paths)}] {frame_name}")
        print(f"{'='*80}")

        result = {
            "frame": frame_name,
            "image_path": image_path,
            "instruction": instruction,
            "success": False,
            "error": None,
            "trajectory": None,
            "floor_coverage": None,
            "target_point": None,
            "output_files": {}
        }

        try:
            # 调用 run_pipeline.py
            print("🚀 运行 run_pipeline.py...")
            cmd = [
                sys.executable,
                run_pipeline_path,
                "--image", image_path,
                "--instruction", instruction,
                "--output_dir", output_dir,
                "--start_x", str(start_point[0]),
                "--start_y", str(start_point[1])
            ]

            proc_result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

            # 检查是否成功
            if "✅ Pipeline 完成!" not in proc_result.stdout:
                result["error"] = "run_pipeline.py 执行失败"
                fail_count += 1
                results.append(result)
                print(f"❌ run_pipeline.py 执行失败")
                print(proc_result.stderr[:500] if proc_result.stderr else "")
                continue

            # 提取目标点（从输出中解析）
            target_point = None
            for line in proc_result.stdout.split('\n'):
                if '目标点 2D:' in line:
                    try:
                        target_point = json.loads(line.split('目标点 2D:')[1].strip())
                    except:
                        pass
                    break

            result["target_point"] = target_point

            # 加载轨迹数据
            base_name = frame_name
            trajectory_data_path = os.path.join(output_dir, base_name, f"{base_name}_depth_masks_trajectory_data.json")

            if not os.path.exists(trajectory_data_path):
                result["error"] = f"轨迹数据文件不存在：{trajectory_data_path}"
                fail_count += 1
                results.append(result)
                continue

            with open(trajectory_data_path, 'r') as f:
                trajectory_data = json.load(f)

            trajectory = trajectory_data.get("trajectory", [])
            validation = trajectory_data.get("validation", {})

            result["trajectory"] = trajectory
            result["floor_coverage"] = validation.get("floor_coverage", 0)
            result["success"] = True

            print(f"✅ 轨迹点序列：{len(trajectory)} 个点")
            print(f"✅ 地板覆盖率：{result['floor_coverage']*100:.1f}%")

            # 可视化轨迹（使用与 run_pipeline.py 相同的函数）
            print("🎨 生成轨迹可视化...")
            
            # 1. 在 depth_masks 上绘制轨迹（与 run_pipeline.py 相同）
            depth_masks_path = os.path.join(output_dir, base_name, f"{base_name}_depth_masks.png")
            vis_output_path = os.path.join(output_dir, f"{frame_name}_trajectory.png")
            
            if os.path.exists(depth_masks_path):
                visualize_trajectory_on_image(
                    image_path=depth_masks_path,
                    trajectory=trajectory,
                    floor_mask_path=None,
                    output_path=vis_output_path,
                    start_point=start_point,
                    validation_result=validation,
                    target_point=target_point
                )
                print(f"✅ 轨迹可视化已保存：{vis_output_path}")
            
            # 2. 在原始图像上绘制轨迹
            original_vis_path = os.path.join(output_dir, f"{frame_name}_trajectory_on_original.png")
            visualize_trajectory_on_image(
                image_path=image_path,
                trajectory=trajectory,
                floor_mask_path=None,
                output_path=original_vis_path,
                start_point=start_point,
                validation_result=None,
                target_point=target_point
            )
            print(f"✅ 原图轨迹可视化已保存：{original_vis_path}")

            result["output_files"]["trajectory_vis"] = vis_output_path
            result["output_files"]["trajectory_on_original"] = original_vis_path
            success_count += 1

            print(f"✅ 测试通过")

        except subprocess.TimeoutExpired:
            result["error"] = "run_pipeline.py 执行超时"
            fail_count += 1
            print(f"❌ 执行超时")
        except Exception as e:
            result["error"] = str(e)
            fail_count += 1
            print(f"❌ 测试异常：{e}")
            import traceback
            traceback.print_exc()

        results.append(result)

    # 保存汇总结果
    summary = {
        "timestamp": timestamp,
        "instruction": instruction,
        "start_point": start_point,
        "total_frames": len(image_paths),
        "success_count": success_count,
        "fail_count": fail_count,
        "success_rate": success_count / len(image_paths) if image_paths else 0,
        "results": results
    }

    summary_path = os.path.join(output_dir, "batch_test_summary.json")
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=2)

    # 打印汇总
    print("\n" + "=" * 80)
    print("📊 批量测试完成!")
    print("=" * 80)
    print(f"总帧数：{len(image_paths)}")
    print(f"✅ 成功：{success_count}")
    print(f"❌ 失败：{fail_count}")
    print(f"📈 成功率：{success_count / len(image_paths) * 100:.1f}%" if image_paths else "N/A")
    print(f"📄 汇总结果：{summary_path}")
    print(f"📁 输出目录：{output_dir}")
    print("=" * 80)

    return summary


def main():
    parser = argparse.ArgumentParser(description="批量测试连续图像帧的轨迹规划能力（HTTP 服务版本）")
    parser.add_argument("--start", type=int, default=16, help="起始帧号")
    parser.add_argument("--end", type=int, default=100, help="结束帧号")
    parser.add_argument("--image-dir", type=str, default="/workspace/wxd/Agent/images/frames",
                        help="图像目录")
    parser.add_argument("--instruction", type=str, default="右边的椅子",
                        help="测试指令")
    parser.add_argument("--output-dir", type=str, default="/workspace/wxd/Agent/images/batch_test_results",
                        help="输出目录")
    parser.add_argument("--start-x", type=int, default=310, help="起点 x 坐标")
    parser.add_argument("--start-y", type=int, default=450, help="起点 y 坐标")
    parser.add_argument("--images", type=str, nargs='+', default=None,
                        help="直接指定图像路径列表（覆盖 --start/--end）")

    args = parser.parse_args()

    # 生成图像路径列表
    if args.images:
        image_paths = [p for p in args.images if os.path.exists(p)]
    else:
        image_paths = generate_image_paths(args.start, args.end, args.image_dir)

    if not image_paths:
        print("❌ 没有找到任何测试图像")
        sys.exit(1)

    start_point = (args.start_x, args.start_y)

    # 执行批量测试
    summary = batch_test(image_paths, args.instruction, args.output_dir, start_point)

    # 如果成功率低于 50%，提示用户
    if summary and summary["success_rate"] < 0.5:
        print("\n⚠️  警告：成功率低于 50%，请检查问题原因")
        sys.exit(1)


if __name__ == "__main__":
    main()
