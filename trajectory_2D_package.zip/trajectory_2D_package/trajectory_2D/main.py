#!/usr/bin/env python3
"""
2D 轨迹规划点云分割主流程 (改进版)
根据用户指令检测目标物体，分割并保存场景点云、目标点云和地板点云

核心改进:
1. VLM 意图理解 - 详细识别深度/位置/序数词/关系型查询
2. 多目标检测 - GroundingDINO 检测所有候选目标
3. 目标选择决策 - 根据深度/位置/序数词选择最终目标
4. 地板检测 - 始终额外执行 floor 的检测和分割

流程:
1. VLM 意图理解 - 解析用户指令，提取目标物体、深度/位置属性、序数词
2. GroundingDINO 检测 - 检测所有候选目标
3. 目标选择决策 - 根据意图选择最终目标 (最近/最远/第 N 个)
4. SAM2 分割 - 使用边界框获取目标的精确掩码
5. Floor 检测 - 额外检测 floor 并分割
6. Depth-Anything-v3 点云生成 - 生成场景 3D 点云
7. 点云分割 - 分离场景、目标、地板点云
8. 保存输出 - PLY 格式点云 + 可视化图像

使用示例:
    python main.py --image test.png --instruction "远处的垃圾桶"
    python main.py --image test.png --instruction "最近的椅子"
    python main.py --image test.png --instruction "左边的桌子"
"""

import sys
import os
import json
import cv2
import numpy as np
import torch
from typing import Dict, Any, Optional, List, Tuple
from openai import OpenAI

# 添加路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/workspace/wxd/Agent/Spagent/spagent/checkpoints")

# 导入自定义模块
from sam2_client import SAM2Client
from pointcloud_segmentation_http import PointCloudSegmentator, DepthAnythingV3Client, GroundingDINOClient
from pointcloud_saver import PointCloudSaver, PointCloudVisualizer

# ============== 配置常量 ==============
BOX_THRESHOLD = 0.30
TEXT_THRESHOLD = 0.20

# 服务配置
SAM2_HOST = "localhost"
SAM2_PORT = 20020
GROUNDING_DINO_HOST = "localhost"
GROUNDING_DINO_PORT = 20021
DEPTH_ANYTHING_HOST = "localhost"
DEPTH_ANYTHING_PORT = 20022

# 默认输出目录
DEFAULT_OUTPUT_DIR = "/workspace/wxd/Agent/images/trajectory_2D_results"

# 起点配置 (2D 坐标，参考 visualize_traj_3d.py)
# 默认使用图像底部中心位置，可根据具体图像调整
START_POINT_2D = (310, 450)  # (x, y)


# ============== VLM 意图理解 ==============
class VLMIntentClient:
    """VLM 客户端，用于解析用户指令意图（使用 RoboBrain2.0-7B）"""

    def __init__(self,
                 base_url="http://localhost:8000/v1",
                 model="RoboBrain2.0-7B"):
        self.client = OpenAI(base_url=base_url, api_key="not-needed")
        self.model = model
        self.use_fallback = False
        print(f"🤖 VLM 意图理解客户端已初始化")
        print(f"   VLM: {model} @ {base_url}")

    def health_check(self) -> Tuple[bool, str]:
        """检查 VLM 服务状态"""
        try:
            models = self.client.models.list()
            return True, f"服务正常，可用模型：{[m.id for m in models.data]}"
        except Exception as e:
            return False, f"{self.model} 服务不可用：{str(e)}"

    def parse_intent(self, instruction: str, image_path: str) -> Dict[str, Any]:
        """
        解析用户指令的意图

        识别:
        - 目标物体 (target_objects)
        - 关系型查询 (reference_object, relation_type)
        - 序数词 (ordinal)
        - 深度/位置属性 (depth_attribute, position_attribute)
        """
        import base64

        with open(image_path, "rb") as f:
            image_base64 = base64.b64encode(f.read()).decode('utf-8')

        prompt = f"""你是一个智能具身 Agent 的意图理解模块。请分析用户的指令，提取关键信息。

用户指令："{instruction}"

重要识别任务:
1. **目标物体**: 识别用户要找的物体类别（英文，如 "garbage can", "water dispenser", "chair"）
2. **关系型查询**:
   - 如果指令包含"closest to X"、"nearest to X"、"farthest from X"、"X 旁边的"、"X 附近的"等
   - 提取 reference_object (参考物体) 和 relation_type ("closest_to" / "farthest_from" / "next_to" 等)
3. **序数词**: 识别"first"、"second"、"third"、"第 1 个"、"第 2 个"、"第一个"、"第二个"等，提取序数 (1, 2, 3...)
4. **深度属性** (非常重要):
   - "farthest"、"furthest"、"最远"、"远处的"、"远端的" → depth_attribute = "farthest"
   - "nearest"、"closest"、"最近"、"近处的"、"近端的"、"旁边的"、"附近的" → depth_attribute = "nearest"
   - 注意："最近的 X" = "nearest X" = depth_attribute = "nearest"
   - 注意："最远的 X" = "farthest X" = depth_attribute = "farthest"
5. **位置属性**:
   - "left"、"左边"、"左侧的" → position_attribute = "left"
   - "right"、"右边"、"右侧的" → position_attribute = "right"
   - "center"、"中间"、"中央的" → position_attribute = "center"

请输出 JSON 格式，包含以下字段:
- task_type: 任务类型 ("simple_selection" / "relational_selection" / "ordinal_selection")
- target_objects: 目标物体列表 (英文，如 ["garbage can", "chair", "sofa"])
- reference_object: 参考物体 (英文，关系型查询需要，如 "tent"，否则为 null)
- relation_type: 关系类型 ("closest_to" / "farthest_from" / "next_to" 等，否则为 null)
- ordinal: 序数 (int, 如 1, 2, 3...，默认为 1)
- depth_attribute: 深度属性 ("nearest" / "farthest" / null)
- position_attribute: 位置属性 ("left" / "right" / "center" / null)
- reasoning: 简要的推理说明（中文，解释为什么这样判断）

只输出 JSON，不要有其他内容。"""

        client_to_use = self.fallback_client if self.use_fallback else self.client
        model_to_use = self.fallback_model if self.use_fallback else self.model

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}}
                ]}],
                max_tokens=600,
                temperature=0.1,
                timeout=120
            )

            result_text = response.choices[0].message.content.strip()
            if not result_text:
                print(f"   ❌ VLM 返回空响应")
                raise ValueError("VLM 返回空响应")
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()

            result = json.loads(result_text)
            result["original_instruction"] = instruction
            result["vlm_model"] = self.model

            # 兼容处理
            if "target_object" in result and "target_objects" not in result:
                result["target_objects"] = [result["target_object"]]

            # 后处理：检查 depth_attribute，如果 VLM 返回 null 但指令包含深度词则修正
            if result.get("depth_attribute") is None:
                instruction_lower = instruction.lower()
                if any(word in instruction_lower or word in instruction for word in
                       ["nearest", "closest", "最近", "近处的", "近端的", "旁边的", "附近的"]):
                    result["depth_attribute"] = "nearest"
                    print(f"   🔄 修正 depth_attribute: null → 'nearest' (指令包含'最近'等词)")
                elif any(word in instruction_lower or word in instruction for word in
                         ["farthest", "furthest", "最远", "远处的", "远端的"]):
                    result["depth_attribute"] = "farthest"
                    print(f"   🔄 修正 depth_attribute: null → 'farthest' (指令包含'最远'等词)")

            return result

        except Exception as e:
            print(f"❌ VLM 意图解析失败：{e}")
            # 返回默认结果
            return {
                "task_type": "simple_selection",
                "target_objects": ["object"],
                "reference_object": None,
                "relation_type": None,
                "ordinal": 1,
                "depth_attribute": None,
                "position_attribute": None,
                "reasoning": f"VLM 解析失败，使用默认设置：{e}",
                "original_instruction": instruction,
                "vlm_model": self.model
            }

    def _rule_based_parse(self, instruction: str) -> Dict[str, Any]:
        """规则解析（降级方案）"""
        instruction_lower = instruction.lower()

        # 深度属性判断
        depth_attr = None
        if any(word in instruction_lower or word in instruction for word in
               ["farthest", "furthest", "最远", "远处的", "远端的"]):
            depth_attr = "farthest"
        elif any(word in instruction_lower or word in instruction for word in
                 ["nearest", "closest", "最近", "近处的", "近端的", "旁边的", "附近的"]):
            depth_attr = "nearest"

        # 位置属性判断
        position_attr = None
        if any(word in instruction_lower or word in instruction for word in
               ["left", "左边", "左侧", "左边的"]):
            position_attr = "left"
        elif any(word in instruction_lower or word in instruction for word in
                 ["right", "右边", "右侧", "右边的"]):
            position_attr = "right"
        elif any(word in instruction_lower or word in instruction for word in
                 ["center", "中间", "中央", "中间的"]):
            position_attr = "center"

        # 序数词判断
        ordinal = 1
        ordinals = {
            "first": 1, "second": 2, "third": 3,
            "第 1 个": 1, "第 2 个": 2, "第 3 个": 3,
            "第一个": 1, "第二个": 2, "第三个": 3
        }
        for key, val in ordinals.items():
            if key in instruction_lower or key in instruction:
                ordinal = val
                break

        # 目标物体提取
        target = self._extract_target(instruction)

        return {
            "task_type": "simple_selection",
            "target_objects": [target],
            "reference_object": None,
            "relation_type": None,
            "ordinal": ordinal,
            "depth_attribute": depth_attr,
            "position_attribute": position_attr,
            "reasoning": "规则解析"
        }

    def _extract_target(self, instruction: str) -> str:
        """从指令中提取目标物体"""
        target = instruction

        # 常见修饰语列表
        modifiers = [
            "最近的", "最远的", "近处的", "远处的", "近端的", "远端的", "旁边的", "附近的",
            "farthest ", "furthest ", "nearest ", "closest ",
            "左边的", "右边的", "中间的", "左侧的", "右侧的", "中央的",
            "left ", "right ", "center ", "middle ",
            "第一个", "第二个", "第三个", "第 1 个", "第 2 个", "第 3 个",
            "first ", "second ", "third ",
            "那个", "这个", "这些", "那些",
            "the ", "a ", "an ", "that ", "this "
        ]

        for mod in modifiers:
            if target.startswith(mod):
                target = target[len(mod):]
                break

        if "的" in target:
            target = target.split("的")[-1]

        if " " in target:
            words = target.split()
            if len(words) >= 2:
                target = " ".join(words[-2:])
            else:
                target = words[-1]

        target = target.strip()
        if not target:
            target = "object"

        return target


# ============== GroundingDINO 检测 ==============
class GroundingDINODetector:
    """GroundingDINO 目标检测器（HTTP 版本）"""

    def __init__(self, host=GROUNDING_DINO_HOST, port=GROUNDING_DINO_PORT):
        self.client = GroundingDINOClient(host=host, port=port)
        print(f"🔍 GroundingDINO 检测器已初始化（HTTP 版本）")

    def detect(
        self,
        image_path: str,
        target_object: str,
        box_threshold: float = BOX_THRESHOLD,
        text_threshold: float = TEXT_THRESHOLD
    ) -> List[Dict]:
        """
        检测目标物体

        Returns:
            检测结果列表，每个包含：box, confidence, phrase, center_x, center_y
        """
        # 使用 HTTP 客户端检测
        result = self.client.detect(
            image_path=image_path,
            text_prompt=target_object,
            box_threshold=box_threshold,
            text_threshold=text_threshold
        )

        # 转换为原有格式
        detections = []
        for i, box in enumerate(result.get("boxes", [])):
            x1, y1, x2, y2 = box
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            detections.append({
                "box": box,
                "confidence": result["scores"][i] if i < len(result["scores"]) else 0.0,
                "phrase": result["labels"][i] if i < len(result["labels"]) else target_object,
                "center_x": center_x,
                "center_y": center_y
            })

        return detections


# ============== 目标选择决策 ==============
class TrajectoryDecisionMaker:
    """轨迹规划决策层：根据意图选择目标"""

    def __init__(self, intent: Dict[str, Any]):
        self.intent = intent
        print(f"🧠 决策器已初始化，意图：{intent.get('task_type', 'unknown')}")

    def select_target(
        self,
        candidates: List[Dict],
        reference_candidates: Optional[List[Dict]] = None
    ) -> Tuple[Optional[Dict], str]:
        """
        根据意图选择目标

        Returns:
            selected_target: 选中的目标
            reasoning: 决策理由
        """
        if not candidates:
            return None, "无候选目标"

        task_type = self.intent.get("task_type", "simple_selection")
        depth_attr = self.intent.get("depth_attribute")
        position_attr = self.intent.get("position_attribute")
        ordinal = self.intent.get("ordinal", 1)
        relation_type = self.intent.get("relation_type")

        print(f"\n🤔 开始决策...")
        print(f"   任务类型：{task_type}")
        print(f"   深度属性：{depth_attr}")
        print(f"   位置属性：{position_attr}")
        print(f"   序数：{ordinal}")
        print(f"   关系类型：{relation_type}")

        # 1. 关系型查询
        if relation_type and reference_candidates:
            return self._relational_select(candidates, reference_candidates, relation_type, ordinal)

        # 2. 序数词选择
        if ordinal > 1:
            return self._ordinal_select(candidates, ordinal)

        # 3. 深度属性选择
        if depth_attr:
            return self._depth_select(candidates, depth_attr)

        # 4. 位置属性选择
        if position_attr:
            return self._position_select(candidates, position_attr)

        # 5. 默认：选择第一个
        return candidates[0], "默认选择第一个候选目标"

    def _depth_select(self, candidates: List[Dict], depth_attr: str) -> Tuple[Dict, str]:
        """根据深度属性选择"""
        depths = [(i, c.get("depth", 0)) for i, c in enumerate(candidates)]

        if depth_attr == "farthest":
            best_idx, best_depth = max(depths, key=lambda x: x[1])
            return candidates[best_idx], f"选择深度最大的目标（深度={best_depth:.3f}米）"
        elif depth_attr == "nearest":
            best_idx, best_depth = min(depths, key=lambda x: x[1])
            return candidates[best_idx], f"选择深度最小的目标（深度={best_depth:.3f}米）"
        else:
            return candidates[0], f"未知深度属性'{depth_attr}'，默认选择第一个"

    def _position_select(self, candidates: List[Dict], position_attr: str) -> Tuple[Dict, str]:
        """根据位置属性选择"""
        # 按 x 坐标排序（使用 center_x）
        sorted_by_x = sorted(candidates, key=lambda c: c["center_x"])

        if position_attr == "left":
            return sorted_by_x[0], f"选择最左侧的目标（x={sorted_by_x[0]['center_x']:.1f}）"
        elif position_attr == "right":
            return sorted_by_x[-1], f"选择最右侧的目标（x={sorted_by_x[-1]['center_x']:.1f}）"
        elif position_attr == "center":
            mid_x = sorted_by_x[len(sorted_by_x) // 2]
            return mid_x, f"选择中间位置的目标（x={mid_x['center_x']:.1f}）"
        else:
            return candidates[0], f"未知位置属性'{position_attr}'，默认选择第一个"

    def _ordinal_select(self, candidates: List[Dict], ordinal: int) -> Tuple[Dict, str]:
        """序数词选择"""
        idx = min(ordinal - 1, len(candidates) - 1)
        idx = max(idx, 0)
        return candidates[idx], f"选择第{ordinal}个目标（共{len(candidates)}个）"

    def _relational_select(
        self,
        candidates: List[Dict],
        reference_candidates: List[Dict],
        relation_type: str,
        ordinal: int
    ) -> Tuple[Dict, str]:
        """关系型查询：计算与参考物体的距离"""
        if not reference_candidates:
            return candidates[0], "无参考物体，默认选择第一个"

        ref = reference_candidates[0]
        ref_x, ref_y = ref["center_x"], ref["center_y"]
        ref_depth = ref["depth"]

        distances = []
        for i, cand in enumerate(candidates):
            dx = cand["center_x"] - ref_x
            dy = cand["center_y"] - ref_y
            ddepth = cand["depth"] - ref_depth

            dist_2d = (dx ** 2 + dy ** 2) ** 0.5
            combined_dist = dist_2d + abs(ddepth) * 100

            distances.append({
                "index": i,
                "distance_2d": dist_2d,
                "depth_diff": abs(ddepth),
                "combined_distance": combined_dist
            })

        if relation_type in ["closest_to", "nearest_to", "next_to"]:
            sorted_distances = sorted(distances, key=lambda x: x["combined_distance"])
            order_desc = "最近"
        elif relation_type in ["farthest_from"]:
            sorted_distances = sorted(distances, key=lambda x: x["combined_distance"], reverse=True)
            order_desc = "最远"
        else:
            sorted_distances = sorted(distances, key=lambda x: x["combined_distance"])
            order_desc = "最近"

        selected_idx = min(max(ordinal - 1, 0), len(sorted_distances) - 1)
        best = sorted_distances[selected_idx]
        selected = candidates[best["index"]]

        reasoning = f"根据空间关系'{relation_type}'，计算每个候选与参考物体的距离，按{order_desc}到远排序。"
        reasoning += f"选择第{ordinal}个，即候选{best['index']}（2D 距离={best['distance_2d']:.1f}px）。"

        return selected, reasoning


# ============== 点云分割主流程 ==============
class PointCloudSegmentationPipeline:
    """点云分割主流程"""

    def __init__(
        self,
        output_dir: str = DEFAULT_OUTPUT_DIR,
        sam2_host: str = SAM2_HOST,
        sam2_port: int = SAM2_PORT,
        grounding_dino_host: str = GROUNDING_DINO_HOST,
        grounding_dino_port: int = GROUNDING_DINO_PORT,
        depth_anything_host: str = DEPTH_ANYTHING_HOST,
        depth_anything_port: int = DEPTH_ANYTHING_PORT
    ):
        self.output_dir = output_dir
        self.sam2_host = sam2_host
        self.sam2_port = sam2_port

        # 初始化组件（全部使用 HTTP 客户端）
        self.vlm = VLMIntentClient()
        self.detector = GroundingDINODetector(host=grounding_dino_host, port=grounding_dino_port)
        self.sam2_client = SAM2Client(host=sam2_host, port=sam2_port)
        self.segmentator = PointCloudSegmentator(
            sam2_host=sam2_host, sam2_port=sam2_port,
            grounding_dino_host=grounding_dino_host, grounding_dino_port=grounding_dino_port,
            depth_anything_host=depth_anything_host, depth_anything_port=depth_anything_port
        )
        self.saver = PointCloudSaver()
        self.visualizer = PointCloudVisualizer()

        print(f"📦 点云分割主流程已初始化（HTTP 版本）")
        print(f"   输出目录：{output_dir}")
        print(f"   SAM2 服务器：{sam2_host}:{sam2_port}")
        print(f"   GroundingDINO 服务器：{grounding_dino_host}:{grounding_dino_port}")
        print(f"   Depth-Anything-v3 服务器：{depth_anything_host}:{depth_anything_port}")

    def run(
        self,
        image_path: str,
        instruction: str,
        save_result: bool = True
    ) -> Dict[str, Any]:
        """
        运行完整的点云分割流程

        Args:
            image_path: 输入图像路径
            instruction: 用户指令
            save_result: 是否保存结果

        Returns:
            包含结果和统计信息的字典
        """
        results = {
            "success": False,
            "image_path": image_path,
            "instruction": instruction
        }

        try:
            # ========== 步骤 1: VLM 意图理解 ==========
            print("\n" + "="*70)
            print("📋 步骤 1: VLM 意图理解")
            print("="*70)

            intent = self.vlm.parse_intent(instruction, image_path)
            print(f"✅ 识别目标：{intent['target_objects'][0]}")
            if intent.get('depth_attribute'):
                print(f"   深度属性：{intent['depth_attribute']}")
            if intent.get('position_attribute'):
                print(f"   位置属性：{intent['position_attribute']}")
            if intent.get('ordinal', 1) > 1:
                print(f"   序数：{intent['ordinal']}")

            # ========== 步骤 2: GroundingDINO 目标检测 ==========
            print("\n" + "="*70)
            print("🔍 步骤 2: GroundingDINO 目标检测")
            print("="*70)

            target_object = intent["target_objects"][0]
            candidates = self.detector.detect(image_path, target_object)

            if not candidates:
                print("❌ 未检测到目标物体")
                return results

            # ========== 步骤 3: Depth-Anything-v3 深度估计 ==========
            print("\n" + "="*70)
            print("📊 步骤 3: Depth-Anything-v3 深度估计")
            print("="*70)

            point_cloud, depth_map, image_rgb = self.segmentator.generate_point_cloud(image_path)
            h, w = depth_map.shape

            # ========== 步骤 4: 为候选目标添加深度信息 ==========
            print("\n" + "="*70)
            print("🎯 步骤 4: 计算候选目标深度")
            print("="*70)

            for cand in candidates:
                box = cand["box"]
                x1, y1, x2, y2 = [int(v) for v in box]
                x1, y1 = max(0, x1), max(0, y1)
                x2, y2 = min(w, x2), min(h, y2)

                region_depth = depth_map[y1:y2, x1:x2]
                if region_depth.size > 0:
                    cand["depth"] = float(np.median(region_depth))
                    cand["point_3d"] = point_cloud[int(cand["center_y"]), int(cand["center_x"])].tolist()
                    print(f"   {cand['phrase']}: 深度={cand['depth']:.3f}米")

            # ========== 步骤 5: 目标选择决策 ==========
            print("\n" + "="*70)
            print("🧠 步骤 5: 目标选择决策")
            print("="*70)

            decision_maker = TrajectoryDecisionMaker(intent)
            selected_target, reasoning = decision_maker.select_target(candidates)

            if selected_target is None:
                print("❌ 无法选择目标")
                return results

            print(f"✅ 选择目标：{selected_target['phrase']}")
            print(f"   理由：{reasoning}")
            print(f"   边界框：{selected_target['box']}")
            print(f"   深度：{selected_target['depth']:.3f}米")

            # ========== 步骤 6: SAM2 分割目标 ==========
            print("\n" + "="*70)
            print("✂️  步骤 6: SAM2 目标分割")
            print("="*70)

            target_box = selected_target["box"]
            target_mask = self.sam2_client.predict_with_box(image_path, target_box)

            if target_mask is None:
                print("❌ SAM2 分割失败")
                return results

            print(f"✅ 目标掩码已生成，像素数：{target_mask.sum()}")

            # ========== 步骤 7: Floor 检测和分割（始终执行） ==========
            print("\n" + "="*70)
            print("🏠 步骤 7: Floor 检测和分割")
            print("="*70)

            floor_candidates = self.detector.detect(image_path, "floor")
            floor_mask = None

            if floor_candidates:
                # 选择所有置信度 > 0.3 的 floor 候选
                valid_candidates = [c for c in floor_candidates if c["confidence"] > 0.3]
                
                if len(valid_candidates) > 1:
                    print(f"✅ 检测到 {len(valid_candidates)} 个 floor 候选，将合并掩码")
                elif len(valid_candidates) == 1:
                    print(f"✅ 检测到 floor (置信度：{valid_candidates[0]['confidence']:.3f})")
                
                # 对每个候选调用 SAM2，然后合并掩码
                floor_mask = np.zeros((h, w), dtype=bool)
                for i, cand in enumerate(valid_candidates):
                    print(f"   [{i+1}/{len(valid_candidates)}] floor (置信度：{cand['confidence']:.3f})")
                    cand_mask = self.sam2_client.predict_with_box(image_path, cand["box"])
                    if cand_mask is not None:
                        floor_mask |= cand_mask  # 合并掩码
                
                if floor_mask.sum() > 0:
                    print(f"✅ Floor 掩码已生成，总像素数：{floor_mask.sum()}")
                else:
                    print("⚠️ SAM2 分割失败，使用启发式方法")
                    floor_mask = np.zeros_like(target_mask)
                    floor_y_start = int(h * 0.8)
                    floor_mask[floor_y_start:, :] = True
                    print(f"✅ 使用启发式 floor 掩码，像素数：{floor_mask.sum()}")
            else:
                print("⚠️ 未检测到 floor，使用启发式方法估计")
                # 启发式：取图像底部 20% 区域
                floor_mask = np.zeros_like(target_mask)
                floor_y_start = int(h * 0.8)
                floor_mask[floor_y_start:, :] = True
                print(f"✅ 使用启发式 floor 掩码，像素数：{floor_mask.sum()}")

            # ========== 步骤 8: 点云分割 ==========
            print("\n" + "="*70)
            print("☁️  步骤 8: 点云分割")
            print("="*70)

            clouds = self.segmentator.segment(
                depth_map=depth_map,
                point_cloud=point_cloud,
                target_mask=target_mask,
                floor_mask=floor_mask,
                image_rgb=image_rgb
            )

            print(f"✅ 点云分割完成")
            print(f"   完整点云：{len(clouds['full'].points)} 个点")
            print(f"   目标点云：{len(clouds['target'].points)} 个点")
            print(f"   地板点云：{len(clouds['floor'].points)} 个点")
            print(f"   场景点云：{len(clouds['scene'].points)} 个点")

            # ========== 步骤 9: 保存结果 ==========
            if save_result:
                print("\n" + "="*70)
                print("💾 步骤 9: 保存结果")
                print("="*70)

                base_name = os.path.splitext(os.path.basename(image_path))[0]
                output_subdir = os.path.join(self.output_dir, base_name)
                os.makedirs(output_subdir, exist_ok=True)

                prefix = f"{base_name}_"
                saved_plys = self.saver.save_all_clouds(clouds, output_subdir, prefix)

                # 计算起点坐标（与 test_vlm_trajectory.py 统一）
                h, w = image_rgb.shape[:2]
                start_point = START_POINT_2D  # 使用配置的起点 (310, 450)

                # 提取目标物体的 2D 目标点（底部中心点，用于轨迹终点）
                target_point_2d = None
                if target_mask is not None and target_mask.sum() > 0:
                    # 获取目标物体掩码的底部中心点
                    ys, xs = np.where(target_mask)
                    if len(ys) > 0:
                        # 找到底部区域（y 坐标最大的 20% 像素）
                        y_max = ys.max()
                        bottom_region_mask = (ys >= y_max * 0.8)
                        bottom_xs = xs[bottom_region_mask]
                        bottom_ys = ys[bottom_region_mask]
                        
                        # 取底部区域的中心点
                        target_x = int(np.median(bottom_xs))
                        target_y = int(np.median(bottom_ys))
                        target_point_2d = [target_x, target_y]
                        print(f"   目标点 2D: {target_point_2d}")

                saved_vis = self.visualizer.visualize_all(
                    clouds, image_path, depth_map, output_subdir, prefix,
                    start_point=start_point
                )

                metadata = {
                    "image_path": image_path,
                    "instruction": instruction,
                    "intent": intent,
                    "detection": {
                        "all_candidates": candidates,
                        "selected": selected_target,
                        "reasoning": reasoning
                    },
                    "floor_detection": {
                        "candidates": floor_candidates,
                        "mask_pixels": int(floor_mask.sum()) if floor_mask is not None else 0
                    },
                    "pointcloud_stats": {
                        "full": len(clouds["full"].points),
                        "target": len(clouds["target"].points),
                        "floor": len(clouds["floor"].points),
                        "scene": len(clouds["scene"].points)
                    },
                    "trajectory_config": {
                        "start_point_2d": start_point,  # (x, y) 像素坐标
                        "target_point_2d": target_point_2d  # (x, y) 像素坐标
                    },
                    "saved_files": {
                        "ply": saved_plys,
                        "visualization": saved_vis
                    }
                }

                metadata_path = os.path.join(output_subdir, f"{prefix}metadata.json")
                with open(metadata_path, "w") as f:
                    json.dump(metadata, f, indent=2)

                print(f"✅ 所有结果已保存：{output_subdir}")

                results["output_dir"] = output_subdir
                results["saved_files"] = {
                    "ply": saved_plys,
                    "visualization": saved_vis,
                    "metadata": metadata_path
                }

            results["success"] = True
            results["intent"] = intent
            results["detection"] = {
                "all_candidates": candidates,
                "selected": selected_target
            }
            results["pointcloud_stats"] = {
                "full": len(clouds["full"].points),
                "target": len(clouds["target"].points),
                "floor": len(clouds["floor"].points),
                "scene": len(clouds["scene"].points)
            }

        except Exception as e:
            print(f"\n❌ 流程执行异常：{e}")
            import traceback
            traceback.print_exc()
            results["error"] = str(e)

        print("\n" + "="*70)
        if results["success"]:
            print("✅ 点云分割流程完成!")
        else:
            print("❌ 点云分割流程失败")
        print("="*70)

        return results


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(
        description="2D 轨迹规划点云分割",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 完整参数
  python main.py --image test.png --instruction "远处的垃圾桶"
  
  # 交互式输入（不传参数）
  python main.py
  
  # 只指定图像，指令交互输入
  python main.py --image test.png
  
  # 只指定指令，使用默认图像
  python main.py --instruction "近处的椅子"
        """
    )
    parser.add_argument("--image", type=str, default=None, help="输入图像路径（可选，不传则交互输入）")
    parser.add_argument("--instruction", type=str, default=None, help="自然语言指令（可选，不传则交互输入）")
    parser.add_argument("--output-dir", type=str, default=DEFAULT_OUTPUT_DIR, help="输出目录")
    parser.add_argument("--sam2-host", type=str, default=SAM2_HOST, help="SAM2 服务器主机")
    parser.add_argument("--sam2-port", type=int, default=SAM2_PORT, help="SAM2 服务器端口")

    args = parser.parse_args()

    # 交互式输入
    print("\n" + "="*70)
    print("📋 Trajectory 2D - 点云分割")
    print("="*70)

    image_path = args.image
    if image_path is None:
        default_images = [
            "/workspace/wxd/Agent/images/test_6.png",
            "/workspace/wxd/Agent/images/test_navigation_2.png",
            "/workspace/wxd/Agent/images/test_2.png",
        ]
        print("\n🖼️  请选择或输入图像路径:")
        for i, img in enumerate(default_images, 1):
            if os.path.exists(img):
                print(f"   [{i}] {img}")
        print(f"   [0] 输入其他路径")
        
        choice = input("\n   请选择 (0-3): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(default_images):
            image_path = default_images[int(choice) - 1]
        else:
            image_path = input("   请输入图像路径：").strip()
    
    if not os.path.exists(image_path):
        print(f"❌ 图像不存在：{image_path}")
        return

    instruction = args.instruction
    if instruction is None:
        print(f"\n📷 当前图像：{image_path}")
        print("\n💬 请输入指令（示例）:")
        print("   - 远处的垃圾桶")
        print("   - 近处的椅子")
        print("   - 左边的桌子")
        print("   - 最近的饮水机")
        instruction = input("\n   请输入指令：").strip()
        if not instruction:
            instruction = "远处的垃圾桶"

    print("\n" + "="*70)
    print(f"✅ 配置确认")
    print(f"   图像：{image_path}")
    print(f"   指令：{instruction}")
    print("="*70)

    pipeline = PointCloudSegmentationPipeline(
        output_dir=args.output_dir,
        sam2_host=args.sam2_host,
        sam2_port=args.sam2_port
    )

    result = pipeline.run(
        image_path=image_path,
        instruction=instruction,
        save_result=True
    )

    if result["success"]:
        print("\n📊 结果摘要:")
        print(f"   目标：{result['intent']['target_objects'][0]}")
        print(f"   检测置信度：{result['detection']['selected']['confidence']:.3f}")
        print(f"   完整点云：{result['pointcloud_stats']['full']} 个点")
        print(f"   目标点云：{result['pointcloud_stats']['target']} 个点")
        print(f"   地板点云：{result['pointcloud_stats']['floor']} 个点")
        print(f"   场景点云：{result['pointcloud_stats']['scene']} 个点")
        print(f"   输出目录：{result['output_dir']}")
    else:
        print(f"\n❌ 失败：{result.get('error', '未知错误')}")


if __name__ == "__main__":
    main()
