#!/usr/bin/env python3
"""
测试 VLM 模型是否能理解 depth_masks 图像
"""

import base64
from openai import OpenAI

# 配置
IMAGE_PATH = "/workspace/wxd/Agent/images/trajectory_2D_results/test_6/test_6_depth_masks.png"
VLM_BASE_URL = "http://localhost:8000/v1"
VLM_MODEL = "RoboBrain2.0-7B"


def encode_image_to_base64(image_path: str) -> str:
    """将图像编码为 base64"""
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")


def test_vlm_description(image_path: str, prompt: str = "描述一下图片内容"):
    """测试 VLM 图像理解"""
    
    client = OpenAI(base_url=VLM_BASE_URL, api_key="not-needed")
    
    # 方法 1: 使用本地文件路径（如果 VLM 支持）
    print("="*60)
    print("测试 VLM 图像理解")
    print("="*60)
    print(f"图像路径：{image_path}")
    print(f"VLM 服务：{VLM_BASE_URL}")
    print(f"模型：{VLM_MODEL}")
    print(f"提示词：{prompt}")
    print("="*60)
    
    try:
        # 尝试使用图像路径直接调用
        print("\n🔄 方法 1: 使用图像路径直接调用...")
        response = client.chat.completions.create(
            model=VLM_MODEL,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"file://{image_path}"}},
                    ],
                }
            ],
            max_tokens=500,
            temperature=0.1,
        )
        
        print("\n✅ VLM 回复:")
        print(response.choices[0].message.content)
        return True
        
    except Exception as e:
        print(f"❌ 方法 1 失败：{e}")
        print("\n🔄 尝试方法 2: 使用 base64 编码...")
        
        try:
            # 方法 2: 使用 base64 编码
            base64_image = encode_image_to_base64(image_path)
            
            response = client.chat.completions.create(
                model=VLM_MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}},
                        ],
                    }
                ],
                max_tokens=500,
                temperature=0.1,
            )
            
            print("\n✅ VLM 回复:")
            print(response.choices[0].message.content)
            return True
            
        except Exception as e2:
            print(f"❌ 方法 2 也失败了：{e2}")
            return False


def test_with_specific_questions(image_path: str):
    """测试更具体的问题"""
    
    questions = [
        "描述一下这张图片中有哪些颜色区域，每个区域代表什么？",
        "图片中的青色圆点标记的是什么位置？",
        "绿色区域和红色区域分别代表什么？",
        "这是一个深度图，请描述图中不同颜色的含义",
    ]
    
    client = OpenAI(base_url=VLM_BASE_URL, api_key="not-needed")
    base64_image = encode_image_to_base64(image_path)
    
    print("\n" + "="*60)
    print("测试具体问题")
    print("="*60)
    
    for i, question in enumerate(questions, 1):
        print(f"\n【问题 {i}】{question}")
        print("-"*60)
        
        try:
            response = client.chat.completions.create(
                model=VLM_MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": question},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}},
                        ],
                    }
                ],
                max_tokens=300,
                temperature=0.1,
            )
            
            print(f"VLM 回复：{response.choices[0].message.content}")
            
        except Exception as e:
            print(f"❌ 失败：{e}")


if __name__ == "__main__":
    import sys
    
    # 如果命令行提供了图像路径，使用它
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
    else:
        image_path = IMAGE_PATH
    
    # 检查文件是否存在
    import os
    if not os.path.exists(image_path):
        print(f"❌ 图像文件不存在：{image_path}")
        print("请先运行 trajectory_2D 模块生成 depth_masks 图像")
        sys.exit(1)
    
    # 基础测试
    test_vlm_description(image_path)
    
    # 具体问题测试
    test_with_specific_questions(image_path)
