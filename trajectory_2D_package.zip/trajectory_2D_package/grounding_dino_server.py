#!/usr/bin/env python3
"""
GroundingDINO 目标检测服务器
通过 HTTP 提供开放词汇目标检测服务

使用示例:
    python grounding_dino_server.py --checkpoint_path checkpoints/grounding_dino/groundingdino_swinb_cogcoor.pth --port 20021
"""

import base64
import cv2
import io
import logging
import numpy as np
import torch
import os
import sys
import argparse
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import traceback

from groundingdino.util.inference import load_model, load_image, predict, annotate
from groundingdino.util.utils import clean_state_dict
import groundingdino.datasets.transforms as T

# 配置日志格式
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)

app = Flask(__name__)
CORS(app)

# 全局变量存储模型和配置
model = None
transform = None


def load_grounding_dino_model(model_path: str):
    """加载 Grounding DINO 模型"""
    global model, transform

    try:
        logging.info(f"正在加载 Grounding DINO 模型：{model_path}")

        # 配置文件路径（使用全局安装的 groundingdino 配置）
        try:
            # 尝试使用全局安装的配置
            import groundingdino
            config_path = os.path.join(os.path.dirname(groundingdino.__file__), "..", "spagent", "external_experts", "GroundingDINO", "configs", "GroundingDINO_SwinB_cfg.py")
            if not os.path.exists(config_path):
                # 使用项目中的配置文件
                config_path = "/workspace/wxd/Agent/Spagent/spagent/spagent/external_experts/GroundingDINO/configs/GroundingDINO_SwinB_cfg.py"
        except:
            config_path = "/workspace/wxd/Agent/Spagent/spagent/spagent/external_experts/GroundingDINO/configs/GroundingDINO_SwinB_cfg.py"
        
        logging.info(f"使用配置文件：{config_path}")
        
        # 加载模型
        model = load_model(config_path, model_path)

        # 设置设备
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        model = model.to(device)
        model.eval()

        # 创建图像变换
        transform = T.Compose([
            T.RandomResize([800], max_size=1333),
            T.ToTensor(),
            T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])

        logging.info(f"使用设备：{device}")
        logging.info("Grounding DINO 模型加载完成！")
        return True
    except Exception as e:
        logging.error(f"模型加载失败：{e}")
        logging.error(traceback.format_exc())
        return False


@app.route('/health', methods=['GET'])
def health_check():
    """健康检查接口"""
    try:
        status = {
            "status": "ok",
            "model": "GroundingDINO",
        }
        return jsonify(status)
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500


@app.route('/detect', methods=['POST'])
def detect():
    """
    GroundingDINO 目标检测
    
    输入:
        - image: base64 编码的图像 或 image_path: 图像路径
        - text_prompt: 文本提示（如："chair . table . person"）
        - box_threshold: 置信度阈值 (默认：0.35)
        - text_threshold: 文本阈值 (默认：0.25)
    输出:
        - boxes: [N, 4] 边界框数组 [x1, y1, x2, y2] (归一化到 0-1)
        - labels: [N] 标签列表
        - scores: [N] 置信度分数
    """
    global model

    if model is None:
        return jsonify({"error": "模型未加载"}), 500

    try:
        data = request.get_json()

        # 加载图像
        if "image_path" in data:
            image_path = data["image_path"]
            if not os.path.exists(image_path):
                return jsonify({"error": f"图像文件不存在：{image_path}"}), 400
            image = cv2.imread(image_path)
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image_pil = Image.fromarray(image_rgb)
        elif "image" in data:
            image_bytes = base64.b64decode(data['image'])
            image = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), cv2.IMREAD_COLOR)
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image_pil = Image.fromarray(image_rgb)
        else:
            return jsonify({"error": "需要提供 image 或 image_path"}), 400

        # 获取参数
        text_prompt = data.get('text_prompt', 'object')
        box_threshold = data.get('box_threshold', 0.35)
        text_threshold = data.get('text_threshold', 0.25)

        logging.info(f"正在进行目标检测，文本提示：{text_prompt}")

        # 转换图像
        image_transformed, _ = transform(image_pil, None)

        # 预测
        boxes, logits, phrases = predict(
            model=model,
            image=image_transformed,
            caption=text_prompt,
            box_threshold=box_threshold,
            text_threshold=text_threshold
        )

        if boxes is None or len(boxes) == 0:
            return jsonify({
                "success": True,
                "boxes": [],
                "labels": [],
                "scores": [],
                "message": "未检测到目标"
            })

        # 处理检测结果
        boxes_list = []
        labels_list = []
        scores_list = []
        
        h, w = image_rgb.shape[:2]

        for i, (box, logit, phrase) in enumerate(zip(boxes, logits, phrases)):
            # box 是归一化坐标 [cx, cy, w, h]，需要转换为像素坐标 [x1, y1, x2, y2]
            cx, cy, bw, bh = box.cpu().numpy()
            # 转换为绝对像素坐标
            x1 = (cx - bw / 2) * w
            y1 = (cy - bh / 2) * h
            x2 = (cx + bw / 2) * w
            y2 = (cy + bh / 2) * h
            boxes_list.append([float(x1), float(y1), float(x2), float(y2)])
            labels_list.append(str(phrase))
            scores_list.append(float(logit))

        logging.info(f"检测完成，发现 {len(boxes_list)} 个目标")
        return jsonify({
            "success": True,
            "boxes": boxes_list,
            "labels": labels_list,
            "scores": scores_list,
            "image_size": {"width": w, "height": h},
            "num_detections": len(boxes_list)
        })

    except Exception as e:
        logging.error(f"推理失败：{e}")
        logging.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


def main():
    parser = argparse.ArgumentParser(description='Grounding DINO Server')
    parser.add_argument('--checkpoint_path', type=str, required=True,
                        help='Path to Grounding DINO model checkpoint')
    parser.add_argument('--port', type=int, default=20021,
                        help='Port to run the server on (default: 20021)')
    parser.add_argument('--host', type=str, default='0.0.0.0',
                        help='Host to run the server on (default: 0.0.0.0)')

    args = parser.parse_args()

    logging.info("正在启动 Grounding DINO 服务器...")
    logging.info(f"模型路径：{args.checkpoint_path}")
    logging.info(f"服务端口：{args.port}")

    # 加载指定模型
    if not load_grounding_dino_model(args.checkpoint_path):
        logging.error("无法启动服务器：模型加载失败")
        exit(1)

    logging.info("模型加载成功，正在启动服务器...")
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == '__main__':
    main()
