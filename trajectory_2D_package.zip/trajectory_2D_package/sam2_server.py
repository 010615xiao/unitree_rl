#!/usr/bin/env python3
"""
SAM2 分割服务器（使用 Ultralytics）
通过 HTTP 提供图像分割服务

使用示例:
    python sam2_server.py --checkpoint_path checkpoints/sam2/sam2.1_l.pt --port 20020
"""

import base64
import cv2
import io
import logging
import numpy as np
import torch
import os
import argparse
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import traceback
from ultralytics import SAM

# 配置日志格式
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)

app = Flask(__name__)
CORS(app)

# 全局变量存储模型和配置
model = None
model_name = None


def load_model(model_path: str):
    """加载 SAM2 模型"""
    global model, model_name
    
    try:
        logging.info(f"正在加载 SAM2 模型：{model_path}")
        model = SAM(model_path)
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        logging.info(f"使用设备：{device}")
        model = model.to(device).eval()
        logging.info("SAM2 模型加载完成！")
        return True
    except Exception as e:
        logging.error(f"模型加载失败：{e}")
        logging.error(traceback.format_exc())
        return False


@app.route('/health', methods=['GET'])
def health_check():
    """健康检查接口"""
    try:
        status = {
            "status": "ok",
            "model": "SAM2",
        }
        return jsonify(status)
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500


@app.route('/predict', methods=['POST'])
def predict():
    """
    SAM2 分割预测
    
    输入:
        - image: base64 编码的图像 或 image_path: 图像路径
        - boxes: [N, 4] 边界框数组 [x1, y1, x2, y2]
        - points: [N, 2] 点坐标数组 [x, y] (可选)
        - labels: [N] 点标签数组 1=前景，0=背景 (可选)
    输出:
        - masks: [N, H, W] 掩码数组（列表形式）
        - scores: [N] 置信度分数
    """
    global model

    if model is None:
        return jsonify({"error": "模型未加载"}), 500

    try:
        data = request.get_json()

        # 加载图像
        if "image_path" in data:
            image_path = data["image_path"]
            if not os.path.exists(image_path):
                return jsonify({"error": f"图像文件不存在：{image_path}"}), 400
            image = cv2.imread(image_path)
        elif "image" in data:
            image_bytes = base64.b64decode(data['image'])
            image = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), cv2.IMREAD_COLOR)
        else:
            return jsonify({"error": "需要提供 image 或 image_path"}), 400

        # 获取提示信息
        prompts = {}
        
        if "boxes" in data:
            prompts['bboxes'] = data['boxes']
        
        if "points" in data and "labels" in data:
            prompts['points'] = data['points']
            prompts['labels'] = data['labels']

        # 运行推理
        logging.info("正在进行分割...")
        results = model.predict(
            image,
            **prompts,
            conf=data.get('conf', 0.5),
            save=False
        )

        # 获取掩码
        masks_result = results[0].masks
        if masks_result is None:
            return jsonify({
                "success": True,
                "masks": [],
                "scores": [],
                "message": "未检测到目标"
            })

        # 处理掩码
        masks_list = []
        scores_list = []
        
        for i, mask in enumerate(masks_result.data):
            mask_array = mask.data.detach().cpu().numpy().squeeze()
            masks_list.append(mask_array.tolist())
            scores_list.append(float(results[0].boxes.scores[i]) if results[0].boxes.scores is not None else 1.0)

        logging.info(f"分割完成，检测到 {len(masks_list)} 个对象")
        return jsonify({
            "success": True,
            "masks": masks_list,
            "scores": scores_list,
            "image_shape": list(image.shape[:2]),
            "num_detections": len(masks_list)
        })

    except Exception as e:
        logging.error(f"推理失败：{e}")
        logging.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route('/segment', methods=['POST'])
def segment():
    """
    简化的分割接口，只使用边界框

    输入:
        - image_path: 图像路径
        - box: [x1, y1, x2, y2] 单个边界框
    输出:
        - mask: [H, W] 掩码（base64 编码）
        - score: 置信度分数
    """
    global model

    if model is None:
        return jsonify({"error": "模型未加载"}), 500

    try:
        data = request.get_json()

        image_path = data.get("image_path")
        box = data.get("box")

        if not image_path:
            return jsonify({"error": "需要提供 image_path"}), 400
        if not os.path.exists(image_path):
            return jsonify({"error": f"图像文件不存在：{image_path}"}), 400
        if box is None:
            return jsonify({"error": "需要提供 box"}), 400

        # 加载图像
        image = cv2.imread(image_path)

        # 运行推理
        logging.info("正在进行分割...")
        results = model.predict(
            image,
            bboxes=[box],
            conf=data.get('conf', 0.5),
            save=False
        )

        # 获取掩码
        masks_result = results[0].masks
        if masks_result is None or len(masks_result.data) == 0:
            return jsonify({
                "success": False,
                "message": "未检测到目标"
            })

        # 获取第一个掩码
        mask_array = masks_result.data[0].detach().cpu().numpy().squeeze()
        mask_uint8 = (mask_array * 255).astype(np.uint8)

        # 获取置信度（使用 .conf 而不是 .scores）
        score = 1.0
        if results[0].boxes is not None and results[0].boxes.conf is not None:
            score = float(results[0].boxes.conf[0])

        # 编码掩码为 base64
        _, buffer = cv2.imencode('.png', mask_uint8)
        mask_base64 = base64.b64encode(buffer.tobytes()).decode('utf-8')

        logging.info(f"分割完成")
        return jsonify({
            "success": True,
            "mask": mask_base64,
            "score": score,
            "image_shape": list(image.shape[:2])
        })

    except Exception as e:
        logging.error(f"推理失败：{e}")
        logging.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


# /infer 端点作为 /segment 的别名（兼容旧的 sam2_client.py）
@app.route('/infer', methods=['POST'])
def infer():
    """
    图像分割推理接口（兼容旧版本 sam2_client.py）
    调用 segment 函数处理请求
    """
    return segment()


def main():
    parser = argparse.ArgumentParser(description='SAM2 Server')
    parser.add_argument('--checkpoint_path', type=str, required=True,
                        help='Path to SAM2 model checkpoint')
    parser.add_argument('--port', type=int, default=20020,
                        help='Port to run the server on (default: 20020)')
    parser.add_argument('--host', type=str, default='0.0.0.0',
                        help='Host to run the server on (default: 0.0.0.0)')

    args = parser.parse_args()

    logging.info("正在启动 SAM2 服务器...")
    logging.info(f"模型路径：{args.checkpoint_path}")
    logging.info(f"服务端口：{args.port}")

    # 加载指定模型
    if not load_model(args.checkpoint_path):
        logging.error("无法启动服务器：模型加载失败")
        exit(1)

    logging.info("模型加载成功，正在启动服务器...")
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == '__main__':
    main()
