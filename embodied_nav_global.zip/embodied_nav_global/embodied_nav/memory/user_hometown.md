---
key: user_hometown
type: user
tags:
- 用户信息
- 家乡
created: '2026-05-09'
updated: '2026-05-09'
---

用户老家在河南洛阳