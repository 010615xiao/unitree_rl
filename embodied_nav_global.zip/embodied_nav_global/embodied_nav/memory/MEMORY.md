# Long-Term Memory Index

Auto-generated. Each entry links to a .md file with full content.

- [user_hometown](user_hometown.md) — [user] 用户老家在河南洛阳 (用户信息, 家乡)
- [user_location](user_location.md) — [user] 用户当前居住城市是杭州。 (用户信息, 位置)
- [user_name](user_name.md) — [user] 用户的新名字是 dad。 (用户信息，名字)
- [user_seafood_allergy](user_seafood_allergy.md) — [user] 用户对海鲜过敏。 (用户信息，健康，饮食禁忌)
