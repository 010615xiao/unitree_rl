"""
Memory Layer

Handles three layers of memory:
- Conversation history (short-term): sliding window with compression
- Task state (ephemeral): cleared each run(), tracks tool calls
- Long-term memory (.md files): persistent across sessions with YAML frontmatter

Memory file format:
---
key: user_location
type: user          # user | feedback | project | reference
tags: [用户信息, 位置]
created: 2026-05-09
updated: 2026-05-09
expires: null       # optional ISO date, auto-cleanup on expiry
---

Body content (fact, then optional Why / How to apply)
"""

import os
import re
import json
from pathlib import Path
from datetime import datetime, date
from typing import Optional

import yaml


class ShortTermMemory:
    """In-memory conversation history with sliding window and compression.

    Keeps the system message(s) plus the most recent N messages.
    When the window nears capacity (compress_at threshold), old messages
    are compressed into a summary by the VLM to preserve context.
    """

    def __init__(self, max_messages: int = 50, compress_at: int = 40):
        self.max_messages = max_messages
        self.compress_at = compress_at  # trigger compression when exceeded
        self.history: list[dict] = []
        self._summary = ""  # accumulated summary of compressed messages

    def add(self, role: str, content: str, images: list[str] | None = None):
        """Add a message to conversation history."""
        message = {"role": role, "content": content}
        if images:
            message["content"] = [
                {"type": "text", "text": content},
                *[{"type": "image_url", "image_url": {"url": img}} for img in images]
            ]
        self.history.append(message)
        self._trim()

    def _trim(self):
        """Enforce sliding window: keep system messages + last N messages."""
        system_msgs = [m for m in self.history if m.get("role") == "system"]
        non_system = [m for m in self.history if m.get("role") != "system"]

        if len(non_system) > self.max_messages:
            non_system = non_system[-self.max_messages:]

        self.history = system_msgs + non_system

    def compress(self, vlm_client):
        """Compress old messages into a summary using VLM.

        Triggered when message count exceeds compress_at threshold.
        Keeps the most recent messages as-is, compresses older ones.
        """
        non_system = [m for m in self.history if m.get("role") != "system"]

        if len(non_system) <= self.compress_at:
            return  # no need to compress yet

        # Split: keep last 15 messages raw, compress the rest
        keep_count = 15
        to_compress = non_system[:-keep_count]
        to_keep = non_system[-keep_count:]

        if not to_compress:
            return

        # Build text for compression
        lines = []
        for msg in to_compress:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            # Handle multi-modal content
            if isinstance(content, list):
                content = " ".join(
                    c.get("text", "[image]") for c in content if c.get("type") == "text"
                )
            lines.append(f"{role}: {content}")

        compress_text = "\n".join(lines)

        # Ask VLM to summarize
        summary_messages = [
            {
                "role": "system",
                "content": (
                    "You are summarizing a conversation history. "
                    "Produce a concise summary (2-4 sentences) that captures "
                    "the key context, decisions, and outcomes. "
                    "Only output the summary, nothing else."
                ),
            },
            {
                "role": "user",
                "content": f"Summarize this conversation history:\n\n{compress_text}",
            },
        ]

        try:
            summary = vlm_client.chat(summary_messages)
            self._summary = summary
        except Exception:
            pass  # compression is best-effort

        # Rebuild history: system + new summary + kept messages
        system_msgs = [m for m in self.history if m.get("role") == "system"]
        summary_msg = {
            "role": "system",
            "content": f"[Compressed conversation summary] {self._summary}",
        }
        self.history = system_msgs + [summary_msg] + to_keep

    def get_messages(self) -> list[dict]:
        """Return full message history for LLM API call."""
        return self.history.copy()

    def clear(self):
        """Clear conversation history (keep system messages)."""
        self.history = [m for m in self.history if m.get("role") == "system"]
        self._summary = ""

    def get_summary(self) -> str:
        """Return the compressed summary of old messages."""
        return self._summary

    def __len__(self):
        return len(self.history)


# ============================================================
# Memory Entry — structured representation of a single memory
# ============================================================
class MemoryEntry:
    """Structured representation of a single long-term memory."""

    def __init__(
        self,
        key: str,
        type: str = "user",
        tags: list[str] | None = None,
        created: str = "",
        updated: str = "",
        expires: str | None = None,
        content: str = "",
    ):
        self.key = key
        self.type = type
        self.tags = tags or []
        self.created = created or date.today().isoformat()
        self.updated = updated or self.created
        self.expires = expires
        self.content = content

    @property
    def is_expired(self) -> bool:
        """Check if this memory has expired."""
        if not self.expires:
            return False
        try:
            expiry_date = date.fromisoformat(self.expires)
            return date.today() > expiry_date
        except ValueError:
            return False

    def to_frontmatter(self) -> str:
        """Serialize to YAML frontmatter + body format."""
        fm = {
            "key": self.key,
            "type": self.type,
            "tags": self.tags,
            "created": self.created,
            "updated": self.updated,
        }
        if self.expires:
            fm["expires"] = self.expires

        fm_yaml = yaml.dump(fm, default_flow_style=False, allow_unicode=True, sort_keys=False)
        return f"---\n{fm_yaml}---\n\n{self.content}"

    @classmethod
    def from_file(cls, path: Path) -> Optional["MemoryEntry"]:
        """Parse a .md memory file into a MemoryEntry.

        Supports both new YAML frontmatter format and legacy plain-text format.
        """
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            return None

        fm_pattern = r"^---\s*\n(.*?)\n---\s*\n(.*)"
        match = re.match(fm_pattern, text, re.DOTALL)
        if match:
            fm = yaml.safe_load(match.group(1))
            body = match.group(2).strip()
            return cls(
                key=fm.get("key", path.stem),
                type=fm.get("type", "user"),
                tags=fm.get("tags", []),
                created=fm.get("created", ""),
                updated=fm.get("updated", ""),
                expires=fm.get("expires"),
                content=body,
            )

        # Fallback: legacy plain-text format (Tags: line + body)
        tags = []
        body_lines = []
        for line in text.split("\n"):
            stripped = line.strip()
            if stripped.lower().startswith("tags:"):
                tags = [t.strip() for t in stripped[len("tags:"):].split(",") if t.strip()]
            else:
                body_lines.append(line)
        return cls(
            key=path.stem,
            type="user",
            tags=tags,
            created="",
            updated="",
            content="\n".join(body_lines).strip(),
        )

    def get_summary(self, max_len: int = 150) -> str:
        """Get a one-line summary of the memory body."""
        if not self.content:
            return "(empty)"
        for line in self.content.split("\n"):
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.lower().startswith(("why:", "useful for:", "how to apply:", "applies_to:", "key:", "content:")):
                continue
            return stripped[:max_len] + ("..." if len(stripped) > max_len else "")
        return "(empty)"


# ============================================================
# Long-Term Memory — file-based persistent storage
# ============================================================
class LongTermMemory:
    """File-based persistent memory across sessions with YAML frontmatter."""

    VALID_TYPES = {"user", "feedback", "project", "reference"}

    def __init__(self, memory_dir: str):
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self._entries: dict[str, MemoryEntry] = {}
        self._load_all()
        self._cleanup_expired()

    def _load_all(self):
        """Load all .md memory files from the memory directory."""
        for f in self.memory_dir.glob("*.md"):
            if f.name == "MEMORY.md":
                continue
            entry = MemoryEntry.from_file(f)
            if entry:
                self._entries[entry.key] = entry

    def _cleanup_expired(self):
        """Delete memory files that have expired."""
        expired = [k for k, e in self._entries.items() if e.is_expired]
        for key in expired:
            path = self.memory_dir / f"{key}.md"
            try:
                path.unlink()
                print(f"[LongTermMemory] Removed expired memory: {key}")
            except Exception as e:
                print(f"[LongTermMemory] Failed to remove expired memory {key}: {e}")
            self._entries.pop(key, None)

    # ── Public API ──────────────────────────────────────────────────

    def get(self, key: str) -> Optional[str]:
        """Get memory body content by key."""
        entry = self._entries.get(key)
        return entry.content if entry else None

    def get_entry(self, key: str) -> Optional[MemoryEntry]:
        """Get full MemoryEntry by key."""
        return self._entries.get(key)

    def set(
        self,
        key: str,
        content: str,
        type: str = "user",
        tags: list[str] | None = None,
        expires: str | None = None,
    ):
        """Save or update a memory entry.

        Args:
            key: Unique identifier (kebab-case recommended)
            content: Memory body content
            type: Memory type (user/feedback/project/reference)
            tags: List of tags for indexing
            expires: Optional ISO date string for auto-cleanup
        """
        if type not in self.VALID_TYPES:
            type = "user"

        existing = self._entries.get(key)
        now = date.today().isoformat()

        if existing:
            entry = MemoryEntry(
                key=key,
                type=type,
                tags=tags if tags is not None else existing.tags,
                created=existing.created or now,
                updated=now,
                expires=expires if expires is not None else existing.expires,
                content=content,
            )
        else:
            entry = MemoryEntry(
                key=key,
                type=type,
                tags=tags or [],
                created=now,
                updated=now,
                expires=expires,
                content=content,
            )

        path = self.memory_dir / f"{key}.md"
        path.write_text(entry.to_frontmatter(), encoding="utf-8")
        self._entries[key] = entry

    def update(
        self,
        key: str,
        content: str,
        tags: list[str] | None = None,
        expires: str | None = None,
    ) -> bool:
        """Update an existing memory. Returns False if key doesn't exist."""
        if key not in self._entries:
            return False
        existing = self._entries[key]
        self.set(key, content, type=existing.type, tags=tags, expires=expires)
        return True

    def delete(self, key: str):
        """Delete a memory file."""
        path = self.memory_dir / f"{key}.md"
        if path.exists():
            path.unlink()
        self._entries.pop(key, None)

    def list_keys(self) -> list[str]:
        """List all non-expired memory keys."""
        return list(self._entries.keys())

    def get_all(self) -> dict[str, str]:
        """Return all memories as a {key: content} dict."""
        return {k: e.content for k, e in self._entries.items()}

    def get_index(self) -> list[dict]:
        """Return a structured index of all memories (key + type + tags + summary).

        Used by recall_index() and MEMORY.md generation.
        """
        return [
            {
                "key": e.key,
                "type": e.type,
                "tags": e.tags,
                "summary": e.get_summary(),
                "updated": e.updated,
                "expires": e.expires,
            }
            for e in sorted(self._entries.values(), key=lambda x: x.updated or "", reverse=True)
        ]

    def get_summary(self, key: str) -> str:
        """Get a one-line summary of a memory (compatibility with old API)."""
        entry = self._entries.get(key)
        return entry.get_summary() if entry else ""

    def generate_memory_md(self) -> str:
        """Generate and write MEMORY.md index to the memory/ directory."""
        entries = sorted(self._entries.values(), key=lambda x: x.key)
        if not entries:
            content = "# Long-Term Memory Index\n\nNo memories stored yet.\n"
        else:
            lines = [
                "# Long-Term Memory Index",
                "",
                "Auto-generated. Each entry links to a .md file with full content.",
                "",
            ]
            for e in entries:
                tags_str = f" ({', '.join(e.tags)})" if e.tags else ""
                expiry_str = f" ⏰ expires {e.expires}" if e.expires else ""
                lines.append(f"- [{e.key}]({e.key}.md) — [{e.type}] {e.get_summary()}{tags_str}{expiry_str}")
            lines.append("")
            content = "\n".join(lines)

        # Write to file
        memory_md_path = Path(self.memory_dir) / "MEMORY.md"
        memory_md_path.write_text(content, encoding="utf-8")
        return content


# ============================================================
# Memory Manager — unified interface
# ============================================================
class MemoryManager:
    """Unified interface for short-term and long-term memory."""

    def __init__(self, memory_dir: str = "./memory", max_messages: int = 50, compress_at: int = 40):
        self.short_term = ShortTermMemory(max_messages=max_messages, compress_at=compress_at)
        self.long_term = LongTermMemory(memory_dir=memory_dir)

    def add_user_message(self, content: str, images: list[str] | None = None):
        self.short_term.add("user", content, images)

    def add_assistant_message(self, content: str):
        self.short_term.add("assistant", content)

    def add_system_message(self, content: str):
        self.short_term.add("system", content)

    def get_context(self) -> list[dict]:
        return self.short_term.get_messages()

    def recall(self, key: str) -> Optional[str]:
        return self.long_term.get(key)

    def remember(self, key: str, value: str):
        self.long_term.set(key, value)

    def forget(self, key: str):
        self.long_term.delete(key)

    def list_memories(self) -> list[str]:
        return self.long_term.list_keys()

    def search_memory(self, keyword: str) -> list[tuple[str, str]]:
        """Search memories by keyword (fallback — VLM-based recall is preferred)."""
        results = []
        for key, entry in self.long_term._entries.items():
            if keyword.lower() in key.lower() or keyword.lower() in entry.content.lower():
                results.append((key, entry.content))
        return results

    def clear_conversation(self):
        """Clear short-term conversation history."""
        self.short_term.clear()

    def get_short_term_length(self) -> int:
        """Return number of messages in short-term memory."""
        return len(self.short_term)

    def trigger_compression(self, vlm_client):
        """Trigger compression if message count exceeds threshold."""
        self.short_term.compress(vlm_client)
