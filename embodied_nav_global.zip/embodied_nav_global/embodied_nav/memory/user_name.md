---
key: user_name
type: user
tags:
- 用户信息，名字
created: '2026-05-18'
updated: '2026-05-22'
---

用户的新名字是 dad。

Why: 用户明确告知更改了名字，需要更新记忆以正确称呼用户。

Useful for: 未来对话中正确称呼用户，避免使用旧名字 didi。