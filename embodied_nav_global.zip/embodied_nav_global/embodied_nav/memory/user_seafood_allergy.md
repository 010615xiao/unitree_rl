---
key: user_seafood_allergy
type: user
tags:
- 用户信息，健康，饮食禁忌
created: '2026-05-13'
updated: '2026-05-13'
---

用户对海鲜过敏。

Why: 在推荐餐厅、菜谱或讨论饮食时，需要避免推荐海鲜类食物，确保用户饮食安全。

Useful for: 餐厅推荐、菜谱建议、饮食咨询等场景