"""
Styled Output Utilities

Provides colored and formatted terminal output for the CLI interaction.
Uses ANSI escape codes for cross-platform compatibility (works on most modern terminals).
"""

import re
import shutil
import sys
import textwrap
import unicodedata


# ============================================================
# ANSI Color Codes
# ============================================================
class Colors:
    """ANSI color codes for terminal styling."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    UNDERLINE = "\033[4m"

    # Foreground colors
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bright variants
    BRIGHT_BLACK = "\033[90m"
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"

    # Background colors
    BG_BLACK = "\033[40m"
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_WHITE = "\033[47m"
    BG_BRIGHT_GREEN = "\033[102m"
    BG_BRIGHT_CYAN = "\033[106m"


# ============================================================
# Helper Functions
# ============================================================
def _display_width(text: str) -> int:
    """Calculate the display width of text considering CJK characters (2 cols)."""
    width = 0
    for ch in text:
        if unicodedata.east_asian_width(ch) in ('F', 'W', 'A'):
            width += 2  # Full-width, Wide, or Ambiguous (CJK)
        else:
            width += 1
    return width


def _wrap_text_cjk(text: str, max_width: int) -> list[str]:
    """Wrap text respecting CJK display width. Handles multi-line input."""
    # Split by newlines first (paragraph mode)
    paragraphs = text.split('\n')
    all_lines = []

    for para in paragraphs:
        if not para.strip():
            all_lines.append('')
            continue
        if _display_width(para) <= max_width:
            all_lines.append(para)
        else:
            current_line = ""
            current_width = 0
            for ch in para:
                ch_width = 2 if unicodedata.east_asian_width(ch) in ('F', 'W', 'A') else 1
                if current_width + ch_width > max_width:
                    all_lines.append(current_line)
                    current_line = ch
                    current_width = ch_width
                else:
                    current_line += ch
                    current_width += ch_width
            if current_line:
                all_lines.append(current_line)

    return all_lines


def _colorize(text: str, color: str, bold: bool = False, dim: bool = False) -> str:
    """Apply color and style to text."""
    styles = ""
    if bold:
        styles += Colors.BOLD
    if dim:
        styles += Colors.DIM
    return f"{styles}{color}{text}{Colors.RESET}"


def _get_terminal_width() -> int:
    """Get current terminal width, fallback to 80."""
    try:
        return shutil.get_terminal_size().columns or 80
    except Exception:
        return 80


def _wrap_text(text: str, width: int, indent: int = 2) -> str:
    """Wrap text to fit within terminal width."""
    available = width - indent
    if available < 40:
        available = 40
    return textwrap.fill(text, width=available, initial_indent=" " * indent, subsequent_indent=" " * indent)


# ============================================================
# Styled Print Functions
# ============================================================
def print_system(text: str, title: str = "SYSTEM") -> None:
    """Print system message in a cyan box."""
    width = _get_terminal_width()
    border = f"{Colors.DIM}{Colors.CYAN}╭{'─' * (width - 2)}╮{Colors.RESET}"
    border_bottom = f"{Colors.DIM}{Colors.CYAN}╰{'─' * (width - 2)}╯{Colors.RESET}"
    styled_title = _colorize(f" {title} ", Colors.BG_CYAN + Colors.BLACK, bold=True)
    styled_text = _wrap_text(text, width, indent=2)
    styled_text_colored = f"{Colors.DIM}{Colors.CYAN}{styled_text.strip()}{Colors.RESET}"

    print(f"\n{border}")
    print(f"{Colors.DIM}{Colors.CYAN}│{Colors.RESET} {styled_title}  {Colors.DIM}{Colors.CYAN}{Colors.RESET}")
    print(styled_text_colored)
    print(f"{border_bottom}\n")


def print_user_input(text: str) -> None:
    """Print user input in a compact, styled horizontal bar."""
    width = _get_terminal_width()
    inner_w = width - 2

    top = f"{Colors.DIM}{Colors.BRIGHT_GREEN}╭{'─' * inner_w}╮{Colors.RESET}"
    bottom = f"{Colors.DIM}{Colors.BRIGHT_GREEN}╰{'─' * inner_w}╯{Colors.RESET}"

    label = _colorize(" You ", Colors.BG_BRIGHT_GREEN + Colors.BLACK, bold=True)

    # Wrap content with CJK awareness
    content_max_w = inner_w - 2 - 5 - 2  # " You " = 5 display cols
    content_lines = _wrap_text_cjk(text, content_max_w) or ['']
    # Prepend label to first line
    content_lines[0] = f"{label}  {content_lines[0]}"

    print(f"\n{top}")
    for line in content_lines:
        clean_line = re.sub(r'\033\[[0-9;]*m', '', line)
        dw = _display_width(clean_line)
        fill = inner_w - dw
        if fill < 0:
            fill = 0
        print(f"{Colors.DIM}{Colors.BRIGHT_GREEN}│{Colors.RESET} {line}{' ' * fill}{Colors.DIM}{Colors.BRIGHT_GREEN}│{Colors.RESET}")
    # One empty row for breathing room
    print(f"{Colors.DIM}{Colors.BRIGHT_GREEN}│{' ' * inner_w}│{Colors.RESET}")
    print(f"{bottom}")


def print_agent_response(text: str) -> None:
    """Print agent final response in a blue-bordered box."""
    width = _get_terminal_width()
    inner_w = width - 2  # full width minus 1 col each side border

    top = f"{Colors.BRIGHT_BLUE}┌{'─' * inner_w}┐{Colors.RESET}"
    bottom = f"{Colors.BRIGHT_BLUE}└{'─' * inner_w}┘{Colors.RESET}"
    side_l = f"{Colors.BRIGHT_BLUE}│{Colors.RESET}"
    side_r = f"{Colors.BRIGHT_BLUE}│{Colors.RESET}"

    # Strip ANSI codes, then wrap with CJK awareness
    clean_text = re.sub(r'\033\[[0-9;]*m', '', text)
    content_max_w = inner_w - 2  # left pad + right border
    content_lines = _wrap_text_cjk(clean_text, content_max_w) or ['']
    content_lines[0] = f"💬 Agent: {content_lines[0]}"

    print(f"\n{top}")
    for line in content_lines:
        if not line.strip():
            # Empty line (from \n)
            print(f"{side_l}{' ' * inner_w}{side_r}")
        else:
            dw = _display_width(line)
            fill = inner_w - dw - 1
            if fill < 0:
                fill = 0
            print(f"{side_l} {Colors.BRIGHT_WHITE}{line}{Colors.RESET}{' ' * fill}{side_r}")
    print(f"{bottom}")


def print_tool_call(tool_name: str, args: dict) -> None:
    """Print tool call in yellow with gear icon."""
    icon = f"{Colors.BRIGHT_YELLOW}⚙{Colors.RESET}"
    styled_name = _colorize(tool_name, Colors.BRIGHT_YELLOW, bold=True)
    styled_args = _colorize(str(args), Colors.DIM + Colors.YELLOW)
    print(f"  {icon} Calling: {styled_name} {styled_args}", flush=True)


def print_tool_observation(text: str) -> None:
    """Print tool observation output in dimmed text."""
    icon = f"{Colors.DIM}↪{Colors.RESET}"
    # Limit observation length for readability
    if len(text) > 300:
        text = text[:300] + f"{Colors.DIM}... (truncated){Colors.RESET}"
    styled_text = _colorize(text, Colors.DIM + Colors.BRIGHT_BLACK)
    print(f"  {icon} {styled_text}", flush=True)


def print_tool_error(text: str) -> None:
    """Print tool error in red."""
    icon = f"{Colors.BRIGHT_RED}✗{Colors.RESET}"
    styled_text = _colorize(text, Colors.BRIGHT_RED, bold=True)
    print(f"  {icon} Error: {styled_text}", flush=True)


def print_step_indicator(step: int, max_steps: int) -> None:
    """Print reasoning step indicator."""
    styled_step = _colorize(f"Step {step}/{max_steps}", Colors.DIM + Colors.BRIGHT_BLACK, bold=True)
    print(f"\n  {Colors.DIM}─── {styled_step} ───{Colors.RESET}", flush=True)


def print_skill_enter(skill_name: str, intent: str) -> None:
    """Print skill entry with a tree branch and truncated intent."""
    icon = f"{Colors.BRIGHT_MAGENTA}▶{Colors.RESET}"
    styled_name = _colorize(skill_name, Colors.BRIGHT_MAGENTA, bold=True)
    # Truncate intent if too long
    max_intent_len = 60
    if len(intent) > max_intent_len:
        intent = intent[:max_intent_len] + f"{Colors.DIM}…{Colors.RESET}"
    styled_intent = _colorize(intent, Colors.DIM)
    print(f"  {icon} Entering skill: {styled_name} — {styled_intent}", flush=True)


def print_sub_agent_tool(tool_name: str, args: dict) -> None:
    """Print sub-agent's internal tool call (indented under skill)."""
    icon = f"{Colors.DIM}├─ ⚙{Colors.RESET}"
    styled_name = _colorize(tool_name, Colors.DIM + Colors.YELLOW)
    # Truncate args for readability
    args_str = str(args)
    if len(args_str) > 80:
        args_str = args_str[:80] + "…"
    styled_args = _colorize(args_str, Colors.DIM)
    print(f"    {icon} Calling: {styled_name} {styled_args}", flush=True)


def print_sub_agent_result(text: str) -> None:
    """Print sub-agent's internal tool result."""
    icon = f"{Colors.DIM}│  ↪{Colors.RESET}"
    if len(text) > 200:
        text = text[:200] + f"{Colors.DIM}… (truncated){Colors.RESET}"
    styled_text = _colorize(text, Colors.DIM + Colors.BRIGHT_BLACK)
    print(f"    {icon} {styled_text}", flush=True)


def print_skill_exit(skill_name: str) -> None:
    """Print skill exit marker."""
    icon = f"{Colors.DIM}◀{Colors.RESET}"
    styled_name = _colorize(skill_name, Colors.DIM + Colors.BRIGHT_BLACK)
    print(f"  {icon} Leaving skill: {styled_name}", flush=True)


def print_skills_list(skills_text: str) -> None:
    """Print available skills in a formatted list."""
    width = _get_terminal_width()
    header = f"{Colors.BG_MAGENTA}{Colors.WHITE}{' Available Skills '}{Colors.RESET}"
    border = f"{Colors.DIM}{Colors.MAGENTA}{'─' * min(50, width)}{Colors.RESET}"

    print(f"\n{border}")
    print(f"  {header}")
    print(f"{border}")

    # Parse and format skills
    for line in skills_text.strip().split("\n"):
        if line.startswith("Available Skills:"):
            continue
        if line.strip().startswith("- "):
            # Parse: "  - name (v1.0): description"
            content = line.strip()[2:]
            if ":" in content:
                name_part, desc = content.split(":", 1)
                styled_name = _colorize(name_part.strip(), Colors.BRIGHT_MAGENTA, bold=True)
                styled_desc = _colorize(desc.strip(), Colors.DIM)
                print(f"  {styled_name}: {styled_desc}")
            else:
                print(f"  {Colors.DIM}{line.strip()}{Colors.RESET}")
        else:
            print(f"  {Colors.DIM}{line}{Colors.RESET}")

    print(f"{border}\n")


def print_welcome(version: str = "1.0.0", model_name: str = "", skills_raw: str = "") -> None:
    """Print welcome banner."""
    width = _get_terminal_width()
    inner_w = width - 2

    top = f"{Colors.BRIGHT_CYAN}╔{'═' * inner_w}╗{Colors.RESET}"
    bottom = f"{Colors.BRIGHT_CYAN}╚{'═' * inner_w}╝{Colors.RESET}"
    side = f"{Colors.BRIGHT_CYAN}║{Colors.RESET}"

    title = _colorize(" Embodied Agent ", Colors.BG_BRIGHT_CYAN + Colors.BLACK, bold=True)
    version_text = _colorize(f"v{version}", Colors.DIM + Colors.CYAN)
    model_text = _colorize(f"Model: {model_name}", Colors.CYAN) if model_name else ""

    # Parse skills from raw text into compact comma-separated list
    skill_names = []
    if skills_raw:
        for line in skills_raw.strip().split('\n'):
            if line.strip().startswith('- '):
                content = line.strip()[2:]
                name = content.split(' ')[0]  # "daily_chat (v1.0): desc" -> "daily_chat"
                skill_names.append(name)
    skills_text = _colorize(f"Skills: {', '.join(skill_names) if skill_names else 'loading...'}", Colors.CYAN)

    prompt_hint = _colorize("Type /help for commands, /memory to view memories, /quit to exit", Colors.DIM)

    def _center_line(t: str) -> str:
        dw = _display_width(re.sub(r'\033\[[0-9;]*m', '', t))
        fill = inner_w - dw
        if fill < 0:
            fill = 0
        left = fill // 2
        right = fill - left
        return f"{side}{' ' * left}{t}{' ' * right}{side}"

    lines = ["", title, version_text]
    if model_text:
        lines.append(model_text)
    lines.extend(["", skills_text, "", prompt_hint, ""])

    print(f"\n{top}")
    for line in lines:
        print(_center_line(line))
    print(f"{bottom}\n")


def print_help() -> None:
    """Print help message with formatted commands."""
    width = _get_terminal_width()
    header = f"{Colors.BG_BRIGHT_CYAN}{Colors.BLACK}{' Commands '}{Colors.RESET}"
    border = f"{Colors.DIM}{Colors.BRIGHT_CYAN}{'─' * min(40, width)}{Colors.RESET}"

    print(f"\n{border}")
    print(f"  {header}")
    print(f"{border}")

    commands = [
        ("/skills", "List all available skills"),
        ("/memory", "List all long-term memories"),
        ("/reset", "Clear conversation history"),
        ("/help", "Show this help message"),
        ("/quit", "Exit the agent"),
        ("describe <path>", "Send an image for VLM analysis"),
        ("<text>", "Send a task/question to the agent"),
    ]

    for cmd, desc in commands:
        styled_cmd = _colorize(f"  {cmd:<20}", Colors.BRIGHT_CYAN, bold=True)
        styled_desc = _colorize(desc, Colors.DIM)
        print(f"{styled_cmd} {styled_desc}")

    print(f"{border}\n")


def print_memory_list(memories: dict[str, str]) -> None:
    """Print long-term memories in a formatted list."""
    width = _get_terminal_width()
    header = f"{Colors.BG_MAGENTA}{Colors.WHITE}{' Long-Term Memories '}{Colors.RESET}"
    border = f"{Colors.DIM}{Colors.MAGENTA}{'─' * min(50, width)}{Colors.RESET}"

    print(f"\n{border}")
    print(f"  {header}")
    print(f"{border}")

    if not memories:
        print(f"  {Colors.DIM}(No memories stored yet){Colors.RESET}")
    else:
        for key, value in memories.items():
            styled_key = _colorize(f"  [{key}]", Colors.BRIGHT_MAGENTA, bold=True)
            # Truncate long values for display
            display_value = value[:200] + "..." if len(value) > 200 else value
            styled_value = _colorize(display_value, Colors.DIM)
            print(f"{styled_key} {styled_value}")

    print(f"{border}\n")


# ============================================================
# Task Planning — Compact Progress Display
# ============================================================
_task_plan_active: bool = False
_task_plan_total: int = 0
_task_plan_done: int = 0


def _task_progress_bar(done: int, total: int, width: int = 16) -> str:
    """Build a compact progress bar: ▓▓▓░░░░░░░░░"""
    if total <= 0:
        return "░" * width
    filled = round(done / total * width)
    return f"{Colors.BRIGHT_CYAN}{'▓' * filled}{'░' * (width - filled)}{Colors.RESET}"


def print_task_plan_start(goal: str, steps: list[dict]) -> None:
    """Print task plan header. The progress bar follows in print_task_step_start.

    Args:
        goal: The user's goal being planned
        steps: List of step dicts with 'skill' and 'intent'
    """
    global _task_plan_active, _task_plan_total, _task_plan_done
    _task_plan_active = True
    _task_plan_total = len(steps)
    _task_plan_done = 0

    width = _get_terminal_width()
    max_goal = width - 24
    clean_goal = re.sub(r'\033\[[0-9;]*m', '', goal)
    if len(clean_goal) > max_goal:
        display_goal = clean_goal[:max_goal] + "…"
    else:
        display_goal = goal

    header = _colorize(" task plan ", Colors.BG_BRIGHT_CYAN + Colors.BLACK, bold=True)

    print(f"\n  {Colors.BRIGHT_CYAN}┌─{Colors.RESET} {header} {display_goal}", flush=True)


def print_task_step_start(step_idx: int, step: dict) -> None:
    """Print the start of a plan step.

    Args:
        step_idx: 1-based step number
        step: dict with 'skill' and 'intent'
    """
    global _task_plan_done
    total = _task_plan_total
    done = _task_plan_done

    bar = _task_progress_bar(done, total)
    label = _colorize(f"{done}/{total}", Colors.BRIGHT_CYAN, bold=True)
    skill_name = _colorize(step.get("skill", "?"), Colors.BRIGHT_MAGENTA, bold=True)
    intent = step.get("intent", "")

    # Truncate intent
    width = _get_terminal_width()
    max_intent = width - 16
    clean_intent = re.sub(r'\033\[[0-9;]*m', '', intent)
    if len(clean_intent) > max_intent:
        intent = clean_intent[:max_intent] + "…"

    print(f"  {Colors.BRIGHT_CYAN}│{Colors.RESET} {bar} {label}", flush=True)
    print(f"  {Colors.BRIGHT_CYAN}├─{Colors.RESET} Step {step_idx}: [{skill_name}] {intent}", flush=True)


def print_task_step_done(step_idx: int, result_preview: str = "") -> None:
    """Mark the current step as done with a compact result preview.

    Args:
        step_idx: 1-based step number
        result_preview: Short preview of the result
    """
    global _task_plan_done, _task_plan_total
    _task_plan_done += 1
    if _task_plan_done > _task_plan_total:
        _task_plan_done = _task_plan_total  # Cap at total to prevent >100%

    done = _task_plan_done
    total = _task_plan_total
    icon = f"{Colors.BRIGHT_GREEN}✓{Colors.RESET}"

    # Truncate preview
    width = _get_terminal_width()
    max_preview = width - 14
    clean_preview = re.sub(r'\033\[[0-9;]*m', '', result_preview)
    if len(clean_preview) > max_preview:
        preview = clean_preview[:max_preview] + "…"
    else:
        preview = result_preview

    if preview:
        print(f"  {Colors.BRIGHT_CYAN}│{Colors.RESET} {icon} {Colors.DIM}{preview}{Colors.RESET}", flush=True)
    else:
        print(f"  {Colors.BRIGHT_CYAN}│{Colors.RESET} {icon}", flush=True)


def print_task_step_failed(step_idx: int, error: str = "") -> None:
    """Mark the current step as failed.

    Args:
        step_idx: 1-based step number
        error: Error message
    """
    global _task_plan_done, _task_plan_total
    _task_plan_done += 1
    if _task_plan_done > _task_plan_total:
        _task_plan_done = _task_plan_total  # Cap at total to prevent >100%

    icon = f"{Colors.BRIGHT_RED}✗{Colors.RESET}"
    # Truncate error
    width = _get_terminal_width()
    max_err = width - 14
    clean_err = re.sub(r'\033\[[0-9;]*m', '', error)
    if len(clean_err) > max_err:
        err = clean_err[:max_err] + "…"
    else:
        err = error

    print(f"  {Colors.BRIGHT_CYAN}│{Colors.RESET} {icon} {Colors.BRIGHT_RED}{err}{Colors.RESET}", flush=True)


def print_task_plan_end(status: str = "done") -> None:
    """Print task plan completion.

    Args:
        status: 'done', 'failed', or 'stopped'
    """
    global _task_plan_active, _task_plan_done, _task_plan_total
    _task_plan_active = False

    done = _task_plan_done
    total = _task_plan_total
    bar = _task_progress_bar(done, total)
    label = _colorize(f"{done}/{total}", Colors.BRIGHT_CYAN, bold=True)

    if status == "done":
        icon = f"{Colors.BRIGHT_GREEN}✓{Colors.RESET}"
        text = _colorize("Plan complete", Colors.BRIGHT_GREEN)
    elif status == "failed":
        icon = f"{Colors.BRIGHT_RED}✗{Colors.RESET}"
        text = _colorize("Plan finished with failures", Colors.BRIGHT_RED)
    else:
        icon = f"{Colors.DIM}◀{Colors.RESET}"
        text = _colorize("Plan stopped", Colors.DIM)

    print(f"  {Colors.BRIGHT_CYAN}│{Colors.RESET} {bar} {label}", flush=True)
    print(f"  {Colors.BRIGHT_CYAN}└─ {icon} {text}{Colors.RESET}", flush=True)


# ============================================================
# Browser-Use Real-Time Status Display
# ============================================================
_browser_status_line: str = ""
_browser_step: int = 0


def print_browser_use_start() -> None:
    """Print the start marker for browser-use session."""
    global _browser_step
    _browser_step = 0
    print(f"  {Colors.DIM}┌─ browser-use agent running{Colors.RESET}", flush=True)


def update_browser_use_status(step: int, message: str, status: str = "working") -> None:
    """Update a single status line in-place for browser-use progress.

    Args:
        step: Current step number
        message: What the agent is doing
        status: 'working', 'done', 'error'
    """
    global _browser_step
    _browser_step = step

    # Move cursor up 1 line, clear it, print new status
    sys.stdout.write("\033[A\033[2K")

    icons = {
        "working": f"{Colors.BRIGHT_CYAN}⏳{Colors.RESET}",
        "done": f"{Colors.BRIGHT_GREEN}✓{Colors.RESET}",
        "error": f"{Colors.BRIGHT_RED}✗{Colors.RESET}",
    }
    icon = icons.get(status, icons["working"])
    step_text = _colorize(f"Step {step}", Colors.BRIGHT_CYAN, bold=True)

    # Truncate message to fit terminal width
    max_msg_len = _get_terminal_width() - 20
    clean_msg = re.sub(r'\033\[[0-9;]*m', '', message)
    if len(clean_msg) > max_msg_len:
        message = clean_msg[:max_msg_len] + "…"
    else:
        message = _colorize(message, Colors.DIM)

    line = f"  {Colors.DIM}│{Colors.RESET} {icon} {step_text} — {message}"
    sys.stdout.write(f"{line}\n")
    sys.stdout.flush()


def print_browser_use_end(result_summary: str, status: str = "done") -> None:
    """Print the final status line for browser-use session."""
    icons = {
        "done": f"{Colors.BRIGHT_GREEN}✓{Colors.RESET}",
        "error": f"{Colors.BRIGHT_RED}✗{Colors.RESET}",
    }
    icon = icons.get(status, icons["done"])
    styled_summary = _colorize(result_summary, Colors.DIM)
    print(f"  {Colors.DIM}└─ {icon} {styled_summary}{Colors.RESET}", flush=True)
