# Open3D Official Installation Instructions

**Source:** https://www.open3d.org/docs/release/getting_started.html (Open3D 0.19.0)

## Pip Install Commands

### Standard Installation (GPU + CPU)
```bash
pip install open3d
```

### CPU-only Installation (x86_64 Linux, since v0.17+)
```bash
pip install open3d-cpu
```

### Development Version (latest HEAD of main branch)
```bash
pip install -U -f https://www.open3d.org/docs/latest/getting_started.html --only-binary open3d open3d
```

## System Requirements

### Supported Python Versions
- Python 3.8
- Python 3.9
- Python 3.10
- Python 3.11
- Python 3.12

### Supported Operating Systems (Python)
- Ubuntu 18.04+
- macOS 10.15+ (Intel or Apple Silicon)
- Windows 10+ (64-bit)

### Viewer System Requirements
- Linux: Ubuntu 20.04+ or glibc 2.31+
- macOS: v10.15+
- Windows: 10+ (64-bit)

## Important Notes

1. **numpy compatibility:** Versions of numpy >= 2.0.0 require Open3D > 0.18.0 or the latest development version. For older Open3D versions, downgrade numpy:
   ```bash
   pip install "numpy<2.0.0"
   ```

2. **pip version:** Upgrade pip to >= 20.3 for Linux installations:
   ```bash
   pip install -U "pip>=20.3"
   ```

3. **Virtual environments recommended:** Use a virtual environment or conda environment.

4. **Alternative commands** (if needed):
   ```bash
   pip3 install open3d
   pip install --user open3d
   python3 -m pip install --user open3d
   ```

5. For other Python versions or operating systems not listed above, build from source.

