"""
Decision Layer - Agent Core

Two-phase ReAct loop:
  Phase 1 (main VLM): selects skill + describes intent
  Phase 2 (sub-agent): skill's own VLM picks concrete tool from its own schema
"""

import json
import re
import sys
import os
from typing import Optional

# Ensure stdout is unbuffered for real-time display
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(line_buffering=True)

# Ensure project root is in path
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from core.llm_client import VLMClient
from core.skill import SkillRegistry
from utils.styled_output import (
    print_tool_call,
    print_tool_observation,
    print_tool_error,
    print_step_indicator,
    print_skill_enter,
    print_sub_agent_tool,
    print_sub_agent_result,
    print_skill_exit,
    Colors,
    _colorize,
)
from decision.memory_recall import recall_and_inject
from decision.task_state import TaskState
from utils.styled_output import (
    print_task_plan_start,
    print_task_step_start,
    print_task_step_done,
    print_task_step_failed,
    print_task_plan_end,
)

# Pattern to detect browser page content in tool results
# Format: [BROWSER_PAGE:total_chars]...content...[/BROWSER_PAGE]
BROWSER_PAGE_RE = re.compile(r"\[BROWSER_PAGE:(\d+)\](.*?)\[/BROWSER_PAGE\]", re.DOTALL)


# System prompt for the two-phase agent
SYSTEM_PROMPT = """You are an AI agent with a modular skill-based architecture.

## How to process user requests:
- The user tells you what they want.
- Call `use_skill(skill_name, intent)` to select the right skill and pass the user's full intent.
- The skill will internally decide which concrete tool(s) to call — you do NOT need to select tools directly.

## CRITICAL RULE for multi-step tasks:
If the user's request involves multiple actions or steps (e.g., "先...然后...", "go to X and then Y",
"check A before doing B"), you MUST first call `task_planning` to decompose the goal into a plan.
Do NOT try to execute multi-step tasks by calling skills one at a time yourself. The plan will tell you
which skill to use for each step.

## BEFORE calling any skill, check for missing information:
1. **Missing required info**: Does the user's message provide everything needed? If NO -> check recalled memories. If no memory has it -> ask the user.
2. **Ambiguous/vague input**: Did the user use a vague reference (e.g., "去找她", "那里", "之前的")? If YES -> check memories for the concrete meaning. If still unclear -> ask the user.
3. **Random/arbitrary defaults**: Are you about to pick a default value (e.g., city, time, person) that the user didn't specify? If YES -> check memories. If no memory -> ask the user. NEVER guess.

## When to give a final answer:
- After a skill has returned a result for the user's request, respond to the user directly with a
  natural language summary. Do NOT call the same skill again.
- Do NOT repeat any tool call. If you already called a skill, use its result — move on or give a final answer.

Rules:
- Think step by step before acting.
- Keep responses concise.

Available Skills will be listed below. Use your judgment to decide which skill matches the user's intent."""


class Agent:
    """Main agent that orchestrates skills, memory, and LLM calls."""

    def __init__(
        self,
        vlm_client: VLMClient,
        skill_registry: SkillRegistry,
        memory_manager,  # MemoryManager instance
        system_prompt: str = SYSTEM_PROMPT,
        max_reasoning_steps: int = 20,
    ):
        self.vlm = vlm_client
        self.skills = skill_registry
        self.memory = memory_manager
        self.system_prompt = system_prompt
        self.max_reasoning_steps = max_reasoning_steps
        self._running = False

    def initialize(self):
        """Load system prompt and skill list into memory."""
        skill_list = self.skills.list_skills()
        self.full_system = f"{self.system_prompt}\n\n{skill_list}"
        self.memory.add_system_message(self.full_system)
        # Simplified prompt for daily_chat — includes identity and skills,
        # but NOT tool-calling instructions.
        self.chat_system = f"""You are an AI agent with a modular skill-based architecture.
{skill_list}

CRITICAL: Respond with natural language text ONLY. Do NOT generate any tool calls.
- Do NOT output JSON with "function", "arguments", or "type" fields.
- Do NOT try to call any tools. Just answer the user's question directly in plain text.
- If you don't know the answer or a tool failed earlier, say so honestly in plain text.

Respond naturally and concisely."""

        # Health check
        if not self.vlm.health_check():
            print("[WARNING] VLM server is not reachable. Agent will still accept input.")

    def run(self, user_input: str, images: list[str] | None = None) -> str:
        """Process a user input through the two-phase ReAct loop.

        Args:
            user_input: User's text input
            images: Optional image paths for vision input

        Returns:
            Final response string
        """
        self._running = True

        # Handle /reset command - clear conversation history
        if user_input.strip() == "/reset":
            self.memory.clear_conversation()
            self._tool_call_history = []
            self._skill_successes = {}
            if hasattr(self, '_task_state'):
                self._task_state.reset()
            return "[System] Conversation history has been cleared."

        # Clear per-run tool call history
        self._tool_call_history = []
        self._skill_successes = {}

        # Initialize or reset task state for this run
        self._task_state = TaskState(goal=user_input)

        # Add user message to memory
        self.memory.add_user_message(user_input, images)

        # Check if conversation history needs compression
        self.memory.trigger_compression(self.vlm)

        # Build messages for LLM
        messages = self.memory.get_context()

        # Memory recall & injection — let the VLM decide which memories are relevant
        messages, recalled_keys = recall_and_inject(user_input, self.memory, self.vlm, messages)
        # Display as a visible step matching the ReAct loop style
        if recalled_keys:
            print(f'  {Colors.DIM}───{Colors.RESET} {Colors.DIM + Colors.BRIGHT_BLACK}{_colorize("Recall Memory", Colors.DIM + Colors.BRIGHT_BLACK, bold=True)}{Colors.RESET} {Colors.DIM}───{Colors.RESET}', flush=True)
            print_tool_call("memory_recall__recall_index", recalled_keys)
            keys_str = ", ".join(recalled_keys)
            print_tool_observation(f"Recalled: {keys_str}")

        # Also inject the full memory index (keys + tags) so the model knows
        # what keys exist when it decides to call recall_context during the ReAct loop.
        # This prevents the model from fabricating key names like "partner_info".
        mem_skill = self.skills.get("memory_recall")
        if mem_skill:
            index = mem_skill.tools.get("recall_index", lambda: "")()
            if not index.startswith("No long-term memories"):
                msg = "Available memory keys (call recall_index for full list):\n" + index
                messages.append({"role": "system", "content": msg})

        self._current_messages = messages  # Store for use in tool execution
        tools = self.skills.get_all_schemas()  # Single `use_skill` tool

        # ReAct loop
        step = 0
        while self._running and step < self.max_reasoning_steps:
            step += 1

            # Inject TaskState status into messages if there are steps
            task_msg = self._task_state.format_status()
            if task_msg:
                # Remove previous task status if any (keep only latest)
                messages = [
                    m for m in messages
                    if not (m.get("role") == "system" and "TASK STATE" in m.get("content", ""))
                ]
                # Find the last user message (observation from previous step)
                # and insert task state AFTER it so it's prominent in context
                last_user_idx = -1
                for i in range(len(messages) - 1, -1, -1):
                    if messages[i].get("role") == "user":
                        last_user_idx = i
                        break
                if last_user_idx >= 0:
                    messages.insert(last_user_idx + 1, {"role": "system", "content": task_msg})
                else:
                    messages.append({"role": "system", "content": task_msg})

            # Call VLM
            response = self.vlm.chat(messages, tools=tools)

            # Check if it's a tool call
            tool_calls = self._parse_tool_calls(response)

            # When all plan steps are done and VLM keeps calling tools, intercept
            if tool_calls and self._task_state and self._task_state.status == "done":
                # Block: all steps complete, VLM should give final answer
                print_step_indicator(step, self.max_reasoning_steps)
                print("  ⚠ All steps complete — blocking tool call, forcing final answer")
                messages.append({"role": "assistant", "content": response})
                # Build a prompt that forces final answer with summary
                summary_lines = [
                    f"All {len(self._task_state.steps)} plan steps are completed:",
                ]
                for s in self._task_state.steps:
                    preview = s.output[:200].replace("\n", " ") if s.output else "(no output)"
                    summary_lines.append(f"  Step {s.id} [{s.skill}]: {s.intent} → {preview}")
                summary_lines.append("")
                summary_lines.append("Do NOT call any more tools. Give a concise final answer to the user based on these results.")
                messages.append({"role": "user", "content": "\n".join(summary_lines)})
                self.memory.add_assistant_message(response)
                self.memory.add_user_message("\n".join(summary_lines))
                continue  # Back to top of loop — next response must be final

            if tool_calls:
                # Execute tools and build observation
                print_step_indicator(step, self.max_reasoning_steps)
                observations = []
                for tc in tool_calls:
                    try:
                        tool_name = tc["function"]["name"]
                    except (KeyError, TypeError):
                        print_tool_error(f"Malformed tool call: {str(tc)[:100]}")
                        observations.append("Error: Malformed tool call from model")
                        continue

                    # --- Pre-execution check: block calls to already-completed plan steps ---
                    blocked_result = self._task_state_check_duplicate(tc)
                    if blocked_result is not None:
                        # This tool call matches a step that's already done — skip execution
                        print(f"  ⚠ Blocked: repeating completed plan step → {blocked_result[:80]}...")
                        observations.append(f"Tool {tool_name}: {blocked_result}")
                        continue

                    try:
                        raw = tc["function"]["arguments"]
                        args = raw if isinstance(raw, dict) else json.loads(raw)
                    except (json.JSONDecodeError, KeyError, TypeError):
                        args = {}
                    print_tool_call(tool_name, args)

                    result = self._execute_tool_call(tc, messages)

                    # If task_planning returned a plan, parse it into TaskState
                    try:
                        args = tc["function"].get("arguments", {})
                        if isinstance(args, str):
                            args = json.loads(args)
                        if args.get("skill_name") == "task_planning":
                            self._task_state_parse_plan(result)
                    except (json.JSONDecodeError, KeyError, TypeError):
                        pass

                    # Update TaskState if this tool call matches current step
                    self._task_state_update(tc, result)

                    # If the sub-agent returns a final answer marker:
                    if result.startswith("[FINAL_ANSWER]"):
                        ts = getattr(self, '_task_state', None)
                        if ts and ts.status == "executing" and ts.steps:
                            # There's an active plan with remaining steps — continue the loop
                            clean = result[len("[FINAL_ANSWER]"):]
                            print_tool_observation(clean)
                            self.memory.add_assistant_message(clean)
                            observations.append(f"Tool {tool_name}: {result}")
                        else:
                            # No plan or all steps done — return to user
                            clean = result[len("[FINAL_ANSWER]"):]
                            print_tool_observation(clean)
                            self.memory.add_assistant_message(clean)
                            self._running = False
                            return clean
                    else:
                        # Print result or error
                        if result.startswith("Error:"):
                            print_tool_error(result)
                        else:
                            print_tool_observation(result)

                        observations.append(f"Tool {tool_name}: {result}")

                # Detect repeated tool calls — track ALL calls across steps
                is_repeat = False
                corrective = ""
                for tc in tool_calls:
                    try:
                        tn = tc["function"]["name"]
                        raw = tc["function"].get("arguments", {})
                        args = raw if isinstance(raw, dict) else json.loads(raw) if isinstance(raw, str) else {}
                    except (KeyError, TypeError):
                        continue
                    call_key = f"{tn}:{json.dumps(args, sort_keys=True)}"
                    if call_key in self._tool_call_history:
                        is_repeat = True
                        # Inject corrective feedback
                        mem_skill = self.skills.get("memory_recall")
                        if mem_skill:
                            index = mem_skill.tools.get("recall_index", lambda: "")()
                            corrective = (
                                f"⚠️ You are repeating the same tool call: {tn}\\n"
                                f"Available memory keys:\\n{index}\\n\\n"
                                f"Either pick a different key or ask the user for info."
                            )
                        else:
                            corrective = f"⚠️ You are repeating the same tool call: {tn}. Try a different approach."
                        break
                    else:
                        self._tool_call_history.append(call_key)

                # Detect skill-level repeat: same skill called with semantically
                # similar intent after a successful result (not just exact JSON match).
                if not is_repeat:
                    for tc in tool_calls:
                        try:
                            raw = tc["function"].get("arguments", {})
                            args = raw if isinstance(raw, dict) else json.loads(raw) if isinstance(raw, str) else {}
                        except (KeyError, TypeError):
                            continue
                        skill_name = args.get("skill_name", "")
                        intent = args.get("intent", "").lower()
                        if not skill_name or not intent:
                            continue
                        # Check if this skill already returned a successful result
                        if skill_name in self._skill_successes:
                            prev_intent = self._skill_successes[skill_name]
                            # Simple overlap: if 3+ words overlap, consider it a repeat
                            prev_words = set(prev_intent.split())
                            curr_words = set(intent.split())
                            overlap = prev_words & curr_words
                            if len(overlap) >= 3:
                                is_repeat = True
                                corrective = (
                                    f"⚠️ You already called use_skill('{skill_name}') with a similar intent and got a successful result.\\n"
                                    f"Previous intent: \"{prev_intent}\"\\n"
                                    f"Current intent: \"{intent}\"\\n\\n"
                                    f"Do NOT call the same skill again. Use the result you already have to give a final answer to the user."
                                )
                                break

                if is_repeat:
                    observation_text = "\n".join(observations) + f"\\n\\n{corrective}"
                else:
                    observation_text = "\n".join(observations)
                    # Track successful skill calls for future repeat detection
                    # Only when no error results and not already a repeat
                    if not any(obs.startswith("Tool ") and ("[Error]" in obs or obs.startswith("Tool use_skill: Error")) for obs in observations):
                        if not hasattr(self, '_skill_successes'):
                            self._skill_successes = {}
                        for tc in tool_calls:
                            try:
                                raw = tc["function"].get("arguments", {})
                                args = raw if isinstance(raw, dict) else json.loads(raw) if isinstance(raw, str) else {}
                            except (KeyError, TypeError):
                                continue
                            skill_name = args.get("skill_name", "")
                            intent = args.get("intent", "")
                            if skill_name and intent:
                                self._skill_successes[skill_name] = intent.lower()

                # Add assistant response and observation to messages
                messages.append({"role": "assistant", "content": response})
                messages.append({"role": "user", "content": f"Observation: {observation_text}"})

                # Add to short-term memory with browser content summarized
                def _page_to_summary(m):
                    total = int(m.group(1))
                    return f"[browser_control] Page content read ({total} chars, content summarized)"
                memory_obs = BROWSER_PAGE_RE.sub(_page_to_summary, observation_text)
                self.memory.add_assistant_message(response)
                self.memory.add_user_message(f"Observation: {memory_obs}")
            else:
                # Validate: if response is a tool call JSON, try to execute it.
                # If it looks like a tool call but can't be executed, feed it back
                # so the model self-corrects instead of returning raw JSON to user.
                try:
                    data = json.loads(response)
                    if isinstance(data, list) and data:
                        first = data[0]
                        if isinstance(first, dict) and "function" in first:
                            # Execute the tool call
                            result = self._execute_tool_call(first, messages)
                            if result.startswith("[FINAL_ANSWER]"):
                                response = result[len("[FINAL_ANSWER]"):]
                            else:
                                messages.append({"role": "assistant", "content": response})
                                obs_content = f"Observation: {result}\n\nThat was a tool call, not a response. Please generate a proper response to the user based on this observation."
                                messages.append({"role": "user", "content": obs_content})
                                mem_obs = BROWSER_PAGE_RE.sub(
                                    lambda m: f"[browser_control] Page content read ({int(m.group(1))} chars, content summarized)",
                                    result
                                )
                                self.memory.add_assistant_message(response)
                                self.memory.add_user_message(f"Observation: {mem_obs}\n\nThat was a tool call, not a response.")
                                continue  # Back to top of loop
                        elif "type" in first and "arguments" in first:
                            # Malformed tool call JSON (has type+args but not OpenAI format)
                            messages.append({"role": "assistant", "content": response})
                            messages.append({"role": "user", "content": "That is a raw tool call JSON, not a response. Please generate a proper natural language response to the user."})
                            continue
                except (json.JSONDecodeError, TypeError):
                    # Also detect malformed tool call JSON by pattern matching
                    stripped = response.strip()
                    is_tool_like = False
                    if ("function" in stripped) or ("arguments" in stripped):
                        if "__" in stripped or "tool" in stripped.lower():
                            is_tool_like = True
                    if stripped.startswith("[{") and '"type"' in stripped and '"arguments"' in stripped:
                        is_tool_like = True

                    if is_tool_like:
                        messages.append({"role": "assistant", "content": response})
                        messages.append({"role": "user", "content": "That looks like a tool call, not a response. Please generate a proper response to the user."})
                        continue

                self.memory.add_assistant_message(response)
                self._running = False
                return response

        # If max steps reached without final answer
        tool_calls_made = []
        for msg in getattr(self, '_current_messages', []):
            if msg["role"] == "user" and "Observation:" in str(msg.get("content", "")):
                obs = msg["content"]
                for skill_name in ["weather_query", "memory__", "browser_control", "daily_chat"]:
                    if f"[{skill_name.rstrip('_')}]" in obs or f"[{skill_name}]" in obs:
                        if skill_name not in str(tool_calls_made):
                            tool_calls_made.append(skill_name)
        context = ""
        if tool_calls_made:
            context = f" I retrieved: {', '.join(tool_calls_made)}."

        final = f"[Agent] I used all {self.max_reasoning_steps} reasoning steps without reaching a complete answer.{context} Please rephrase your query or ask a more specific question."
        self.memory.add_assistant_message(final)
        return final

    def _parse_tool_calls(self, response: str) -> list[dict]:
        """Parse tool calls from VLM response.

        Handles two formats:
        1. Standard OpenAI: [{"type": "function", "function": {"name": "...", "arguments": {...}}}]
        2. Malformed: [{"type": "function", "arguments": {"skill_name": "..."}, "id": "..."}]
        """
        try:
            data = json.loads(response)
            if not isinstance(data, list) or not data:
                return []

            normalized = []
            for item in data:
                if not isinstance(item, dict):
                    return []

                if "function" in item:
                    normalized.append(item)
                elif item.get("type") == "function" and "arguments" in item:
                    # Malformed: model forgot "function" wrapper
                    args = item["arguments"]
                    if isinstance(args, dict) and "skill_name" in args:
                        # Recover as use_skill call
                        normalized.append({
                            "type": "function",
                            "function": {
                                "name": "use_skill",
                                "arguments": {
                                    "skill_name": args["skill_name"],
                                    "intent": args.get("intent", "User requested this skill")
                                }
                            }
                        })
                    else:
                        # Generic malformed tool call → treat as use_skill
                        normalized.append({
                            "type": "function",
                            "function": {
                                "name": "use_skill",
                                "arguments": args
                            }
                        })
                else:
                    return []

            return normalized
        except (json.JSONDecodeError, TypeError):
            pass
        return []

    def _execute_tool_call(self, tool_call: dict, messages: list[dict]) -> str:
        """Execute a tool call by dispatching to skill.execute().

        Two-phase: the main VLM selected a skill, now we run the skill's
        sub-agent loop to pick and execute the right concrete tool.
        """
        full_name = tool_call["function"]["name"]
        raw_args = tool_call["function"].get("arguments", {})
        if isinstance(raw_args, str):
            try:
                args = json.loads(raw_args)
            except json.JSONDecodeError:
                args = {}
        elif isinstance(raw_args, dict):
            args = raw_args
        else:
            args = {}

        if full_name != "use_skill":
            return f"Error: Unknown tool '{full_name}'. Expected 'use_skill'"

        skill_name = args.get("skill_name", "")
        intent = args.get("intent", "")
        if not skill_name:
            return "Error: 'skill_name' is required"
        if not intent:
            return "Error: 'intent' is required — describe what the user wants"

        skill = self.skills.get(skill_name)
        if not skill:
            available = ', '.join(sorted(self.skills.skills.keys()))
            return f"Error: Unknown skill '{skill_name}'. Available: {available}"

        try:
            # Show skill entry
            print_skill_enter(skill_name, intent)

            # Two-phase: skill internally runs its own VLM to select the right tool
            result = skill.execute(
                intent=intent, vlm_client=self.vlm, messages=messages,
                chat_system=getattr(self, 'chat_system', ''),
            )
            result_str = str(result)

            # Show skill exit
            print_skill_exit(skill_name)

            # Summarize browser page content for display
            def _page_to_summary(m):
                total = int(m.group(1))
                return f"[browser_control] Page content ({total} chars, summarized)"
            display_result = BROWSER_PAGE_RE.sub(_page_to_summary, result_str)

            return display_result
        except Exception as e:
            return f"Error executing skill '{skill_name}': {str(e)}"

    def _task_state_check_duplicate(self, tool_call: dict) -> str | None:
        """Pre-execution check: return a warning if this tool call matches an already-completed/failed step.

        Returns a warning string if blocked, None if execution should proceed.
        """
        ts = getattr(self, '_task_state', None)
        if ts is None:
            return None

        try:
            raw_args = tool_call["function"].get("arguments", {})
            args = raw_args if isinstance(raw_args, dict) else json.loads(raw_args)
        except (json.JSONDecodeError, KeyError, TypeError):
            return None

        called_skill = args.get("skill_name", "")
        called_intent = args.get("intent", "")
        if not called_skill or not called_intent:
            return None

        for step in ts.steps:
            if step.status in ("done", "failed") and step.skill == called_skill:
                # Check intent overlap (30-char prefix match)
                if (
                    step.intent.lower()[:30] in called_intent.lower()
                    or called_intent.lower()[:30] in step.intent.lower()
                ):
                    status_label = "completed" if step.status == "done" else "failed"
                    return (
                        f"⚠️ ALREADY {status_label.upper()} — Step '{step.intent}' (Step {step.id}) "
                        f"is already {status_label}. DO NOT repeat this skill. "
                        f"Look at the task plan — move to the next pending step or give a final answer."
                    )

        return None

    def _task_state_update(self, tool_call: dict, result: str):
        """Update TaskState based on tool execution result.

        If the executed tool matches the current plan step, mark it as done/failed.
        Also handles retries of failed steps: if VLM retries a failed step with a
        different intent but same skill and gets a valid result, mark it done.
        """
        ts = getattr(self, '_task_state', None)
        if ts is None:
            return

        # Check if the tool call matches any plan step
        try:
            raw_args = tool_call["function"].get("arguments", {})
            args = raw_args if isinstance(raw_args, dict) else json.loads(raw_args)
        except (json.JSONDecodeError, KeyError, TypeError):
            args = {}

        called_skill = args.get("skill_name", "")
        called_intent = args.get("intent", "")

        # Determine if result indicates success (not error, not incomplete JSON)
        stripped = result.strip()
        is_error_result = stripped.startswith("Error:") or stripped.startswith("[Error]")
        is_final_answer = "[FINAL_ANSWER]" in stripped
        is_pure_json_call = (
            stripped.startswith("[")
            and '"type"' in stripped
            and '"function"' in stripped
            and not stripped.startswith("Observation:")
            and not stripped.startswith("[FINAL_ANSWER]")
        )
        is_valid_result = not is_error_result and not is_pure_json_call and not is_final_answer

        # Special case: sub-agent may return a raw JSON tool call that actually indicates
        # success (e.g., it planned navigation to a concrete target). Treat as valid.
        if is_pure_json_call and called_skill:
            import re
            nav_match = re.search(r'plan_navigation.*?target.*?:.*?"(\w+_\d+|microwave_\d+|room_\d+)"', stripped, re.IGNORECASE | re.DOTALL)
            if nav_match:
                is_valid_result = True
                is_pure_json_call = False

        # Try to match the current (pending) step
        current = ts.get_current_step()
        if current is not None:
            skill_match = called_skill == current.skill
            intent_match = (
                current.intent.lower()[:30] in called_intent.lower()
                or called_intent.lower()[:30] in current.intent.lower()
            )

            if skill_match and intent_match:
                ts.update_current(result)
                self._task_state_display_update(ts)
                return

        # If no match with current step, check if this is a retry of a FAILED step.
        # This handles the case where:
        # 1. Step 1 failed → current_index advanced to Step 2
        # 2. VLM retries with different intent for Step 1's skill
        # 3. Retry succeeds → we should mark Step 1 as done and fix current_index
        if called_skill and is_valid_result:
            for i, step in enumerate(ts.steps):
                if step.status == "failed" and step.skill == called_skill:
                    # Successful retry of a failed step
                    step.status = "done"
                    step.output = result
                    step.error = ""
                    ts.context[f"step_{step.id}_retry"] = result

                    # Fix current_index: should point after the last resolved step
                    ts.current_index = i + 1
                    while ts.current_index < len(ts.steps) and ts.steps[ts.current_index].status in ("done", "failed", "skipped"):
                        ts.current_index += 1

                    # Check overall status
                    all_resolved = all(s.status in ("done", "failed", "skipped") for s in ts.steps)
                    if all_resolved:
                        ts.status = "failed" if any(s.status == "failed" for s in ts.steps) else "done"
                    else:
                        ts.status = "executing"

                    self._task_state_display_update(ts)
                    return

        # If no match and result is an error on current step, mark it failed
        if current is not None and is_error_result:
            ts.update_current(result)
            self._task_state_display_update(ts)

    def _task_state_display_update(self, ts):
        """Display step completion/failure UI."""
        # Track which steps have already been displayed to avoid double-counting
        if not hasattr(self, '_task_state_displayed'):
            self._task_state_displayed = set()

        # Find the most recently completed/failed step that hasn't been displayed yet
        for i in range(len(ts.steps) - 1, -1, -1):
            step = ts.steps[i]
            if step.id in self._task_state_displayed:
                continue
            if step.status == "done":
                preview = step.output.split("\n")[0] if step.output else ""
                print_task_step_done(step.id, preview)
                self._task_state_displayed.add(step.id)
                break
            elif step.status == "failed" and step.error:
                print_task_step_failed(step.id, step.error)
                self._task_state_displayed.add(step.id)
                break

        # If there are more steps, show next step starting
        next_step = ts.get_current_step()
        if next_step:
            print_task_step_start(next_step.id, next_step.to_dict())

        # If plan is fully done, print end marker
        if ts.status in ("done", "failed"):
            print_task_plan_end(ts.status)

    def _task_state_parse_plan(self, plan_output: str):
        """Parse a plan from task_planning output into TaskState steps.

        The task_planning tool returns a formatted string like:
        "Plan generated with N steps:\n\n{json...}"
        """
        ts = getattr(self, '_task_state', None)
        if ts is None:
            return

        # Reset display tracking for new plan
        self._task_state_displayed = set()

        # Extract JSON from the output
        try:
            # Try to find the JSON block
            start = plan_output.find("{")
            end = plan_output.rfind("}") + 1
            if start >= 0 and end > start:
                plan_json = plan_output[start:end]
                ts.parse_plan_json(plan_json)

                # Display the plan to user
                if ts.steps:
                    steps_list = [s.to_dict() for s in ts.steps]
                    print_task_plan_start(ts.goal, steps_list)
                    # Show first step starting
                    if ts.steps:
                        print_task_step_start(1, ts.steps[0].to_dict())
        except (json.JSONDecodeError, ValueError):
            pass

    def stop(self):
        """Stop the current reasoning loop."""
        self._running = False

    def reset(self):
        """Reset agent state (clear conversation, reinitialize)."""
        self._running = False
        self.memory.clear_conversation()
        if hasattr(self, '_task_state'):
            self._task_state.reset()
        self.initialize()
