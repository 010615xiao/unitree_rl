"""
Task State — Plan tracking for multi-step agent execution.

Tracks:
  - Goal being pursued
  - Steps with status (pending/done/failed)
  - Accumulated context from completed steps
  - Current step pointer

Injected into every VLM call so the model sees "where we are"
without having to infer it from conversation history.
"""

import json
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class PlanStep:
    """A single step in a plan."""
    id: int
    skill: str           # Which skill handles this step
    intent: str          # What to accomplish (natural language)
    status: str = "pending"   # pending | done | failed | skipped
    output: str = ""     # Result from execution
    error: str = ""      # Error message if failed

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "skill": self.skill,
            "intent": self.intent,
            "status": self.status,
        }


class TaskState:
    """Tracks plan execution across ReAct loop iterations.

    Usage:
      ts = TaskState("go to kitchen and bring food")
      ts.add_step("global_navigation", "navigate to kitchen")
      ts.add_step("env_description", "look inside kitchen")
      ts.add_step("global_navigation", "navigate back to user")

      # After each tool call:
      ts.update_current(result_string)

      # Before each VLM call:
      ts.inject_prompt() → returns system message text
    """

    def __init__(self, goal: str):
        self.goal = goal
        self.steps: list[PlanStep] = []
        self.current_index: int = 0  # Points to the step being executed
        self.status: str = "executing"   # planning | executing | done | failed | stopped
        self.context: dict = {}        # Accumulated context: {step_id: output}

    # ── Plan building ───────────────────────────────────────────────

    def add_step(self, skill: str, intent: str) -> PlanStep:
        step = PlanStep(id=len(self.steps) + 1, skill=skill, intent=intent)
        self.steps.append(step)
        return step

    def parse_plan_json(self, plan_json: str):
        """Parse a JSON plan string from task_planning's create_plan.

        Expected format:
        {
          "goal": "...",
          "steps": [
            {"skill": "global_navigation", "intent": "navigate to kitchen"},
            {"skill": "env_description", "intent": "look at fridge"}
          ]
        }
        """
        try:
            plan = json.loads(plan_json)
        except json.JSONDecodeError:
            # Try to extract JSON from markdown fences
            import re
            match = re.search(r'```(?:json)?\s*(.*?)\s*```', plan_json, re.DOTALL)
            if match:
                plan = json.loads(match.group(1))
            else:
                return

        for item in plan.get("steps", []):
            skill = item.get("skill", "")
            intent = item.get("intent", item.get("description", item.get("step", "")))
            if skill and intent:
                self.add_step(skill, intent)

    # ── Execution ───────────────────────────────────────────────────

    def get_current_step(self) -> Optional[PlanStep]:
        """Get the step currently being executed."""
        if 0 <= self.current_index < len(self.steps):
            return self.steps[self.current_index]
        return None

    def update_current(self, result: str):
        """Mark the current step as done or failed based on result."""
        step = self.get_current_step()
        if step is None:
            return

        # Detect error conditions
        is_error = result.startswith("[Error]") or result.startswith("Error:")

        # Detect incomplete results: raw JSON tool calls should not be marked done
        is_incomplete = False
        if not is_error:
            # First try strict JSON parse
            try:
                parsed = json.loads(result)
                if isinstance(parsed, list) and parsed and parsed[0].get("type") == "function":
                    is_incomplete = True
            except (json.JSONDecodeError, TypeError, KeyError):
                # 8B models often generate malformed JSON (missing braces, etc.)
                # Use pattern matching as fallback
                stripped = result.strip()
                if stripped.startswith("[") and '"type"' in stripped and '"function"' in stripped:
                    if '"name"' in stripped and ("__" in stripped or "tool" in stripped.lower()):
                        is_incomplete = True

        if is_error or is_incomplete:
            step.status = "failed"
            if is_incomplete:
                step.error = "Incomplete: sub-agent returned a tool call instead of a result"
            else:
                step.error = result[:200]
            # Auto-progression: on failure, advance to next step so VLM can decide
            self.current_index += 1
            # CRITICAL: cap current_index to prevent it exceeding len(steps)
            if self.current_index > len(self.steps):
                self.current_index = len(self.steps)
        else:
            step.status = "done"
            step.output = result
            self.context[f"step_{step.id}"] = result
            self.current_index += 1
            # CRITICAL: cap current_index to prevent it exceeding len(steps)
            if self.current_index > len(self.steps):
                self.current_index = len(self.steps)

        # Check if all steps are done
        if self.current_index >= len(self.steps):
            # Check if any step failed
            failed = [s for s in self.steps if s.status == "failed"]
            if failed:
                self.status = "failed"
            else:
                self.status = "done"
        else:
            self.status = "executing"

    def skip_current(self, reason: str = ""):
        """Skip the current step (e.g., user decided not to do it)."""
        step = self.get_current_step()
        if step:
            step.status = "skipped"
            step.error = reason
            self.current_index += 1
            if self.current_index >= len(self.steps):
                self.status = "done"

    # ── Context injection for VLM ───────────────────────────────────

    def format_status(self) -> str:
        """Format the current task state as a system message for VLM injection."""
        if not self.steps:
            return ""

        done_count = sum(1 for s in self.steps if s.status == 'done')
        failed_count = sum(1 for s in self.steps if s.status == 'failed')
        pending_count = sum(1 for s in self.steps if s.status == 'pending')

        lines = [
            f"TASK STATE — You are executing a multi-step plan.",
            f"Goal: {self.goal}",
            f"Overall status: {self.status}",
            f"",
            f"Progress: {done_count}/{len(self.steps)} steps completed, {failed_count} failed, {pending_count} remaining",
        ]

        # Step list
        lines.append("")
        lines.append("Steps:")
        for step in self.steps:
            icon = {"pending": "○", "done": "✓", "failed": "✗", "skipped": "⊘"}.get(step.status, "?")
            marker = " ← CURRENT" if step == self.get_current_step() and self.status == "executing" else ""
            lines.append(f"  {icon} Step {step.id}: [{step.skill}] {step.intent}{marker}")
            if step.status == "done" and step.output:
                # Show a concise output summary
                preview = step.output[:150].replace("\n", " ")
                if len(step.output) > 150:
                    preview += "..."
                lines.append(f"       → {preview}")
            elif step.status == "failed":
                lines.append(f"       → Failed: {step.error[:100]}")

        # Completed steps context (for VLM to reference)
        completed = {s.id: s.output for s in self.steps if s.status == "done"}
        if completed:
            lines.append("")
            lines.append("Completed step outputs (available as context):")
            for step_id, output in completed.items():
                preview = output[:200].replace("\n", " ")
                if len(output) > 200:
                    preview += "..."
                lines.append(f"  Step {step_id}: {preview}")

        # Next step guidance
        current = self.get_current_step()
        if current and self.status == "executing":
            lines.append("")
            lines.append(f"YOUR NEXT ACTION: Execute Step {current.id}")
            lines.append(f"  Call use_skill(skill_name=\"{current.skill}\", intent=\"{current.intent}\")")
        elif self.status in ("done", "failed"):
            lines.append("")
            lines.append(f"Plan is {self.status}. Give a final answer to the user based on the results above.")

        # Critical instruction: do NOT repeat completed/failed steps
        lines.append("")
        lines.append("IMPORTANT RULES:")
        lines.append("1. Do NOT call the same skill with the same intent that already appears in a completed (✓) or failed (✗) step — it is FINAL.")
        lines.append("2. The CURRENT step (marked ← CURRENT) is the one you should execute now.")
        lines.append("3. If all steps are done or failed, give a final answer to the user.")
        lines.append("4. If a step failed, you may retry it with a DIFFERENT intent, or skip to the next step.")

        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Serialize for debugging or saving."""
        return {
            "goal": self.goal,
            "status": self.status,
            "current_index": self.current_index,
            "steps": [s.to_dict() for s in self.steps],
            "context_keys": list(self.context.keys()),
        }

    def reset(self):
        """Reset task state for a new run."""
        self.steps.clear()
        self.current_index = 0
        self.status = "executing"
        self.context.clear()
