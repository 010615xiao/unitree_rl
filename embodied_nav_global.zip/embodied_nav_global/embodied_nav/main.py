#!/usr/bin/env python3
"""
Embodied Agent - Main Entry Point

Usage:
    python -m embodied_nav.main
    python main.py
"""

import os
import sys

# Ensure stdout is unbuffered for real-time display
os.environ["PYTHONUNBUFFERED"] = "1"

# Add project root to path
project_root = os.path.dirname(os.path.abspath(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from interaction.cli import create_agent, run_cli


def main():
    """Entry point for the embodied agent."""
    # Resolve paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    skills_dir = os.path.join(base_dir, "skills")
    memory_dir = os.path.join(base_dir, "memory")
    
    # Ensure memory dir exists
    os.makedirs(memory_dir, exist_ok=True)
    
    # Create and launch agent
    try:
        agent = create_agent(
            vlm_url=None,  # Read from config/agent.yaml
            skills_dir=skills_dir,
            memory_dir=memory_dir,
        )
        run_cli(agent)
    except KeyboardInterrupt:
        print("\nAgent stopped by user.")
    except Exception as e:
        print(f"\n[FATAL] Agent crashed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
