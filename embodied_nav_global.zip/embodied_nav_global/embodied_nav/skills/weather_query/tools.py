"""
Weather Query Skill - Tools

Fetches real-time weather data using wttr.in (free, no API key).
Returns structured weather data — the VLM generates natural suggestions from it.
"""

import requests
import time


# Cache: {location: (timestamp, data)}
_cache: dict[str, tuple[float, str]] = {}
_CACHE_TTL = 600  # 10 minutes


def _format_weather(data: dict, location: str, fmt: str, days: int = 1) -> str:
    """Format weather data into a beautiful, readable string.

    Args:
        data: JSON response from wttr.in
        location: City name
        fmt: Output format (short/normal/full)
        days: Number of days to show (1=today only, 2=today+tomorrow)

    Returns:
        Formatted weather text
    """
    now = data.get("current_condition", [{}])[0]
    temp = now.get("temp_C", "--")
    feels = now.get("FeelsLikeC", temp)
    desc = now.get("weatherDesc", [{}])[0].get("value", "Unknown").strip()
    humidity = now.get("humidity", "--")
    wind = now.get("windspeedKmph", "--")
    vis = now.get("visibility", "--")
    pressure = now.get("pressure", "--")
    uv = now.get("uvIndex", "--")

    # Weather emoji
    weather_code = int(now.get("weatherCode", 113))
    emoji_map = {
        113: "☀️", 116: "⛅", 119: "☁️", 122: "☁️",
        143: "🌫️", 176: "🌦️", 179: "🌨️", 182: "🌨️",
        185: "🌨️", 200: "⛈️", 227: "🌨️", 230: "❄️",
        248: "🌫️", 260: "🌫️", 263: "🌦️", 266: "🌧️",
        281: "🌧️", 284: "🌧️", 293: "🌦️", 296: "🌧️",
        299: "🌧️", 302: "🌧️", 305: "🌧️", 308: "⛈️",
        311: "🌧️", 314: "🌧️", 317: "🌨️", 320: "🌨️",
        323: "🌨️", 326: "🌨️", 329: "❄️", 332: "❄️",
        335: "❄️", 338: "❄️", 350: "🌨️", 353: "🌦️",
        356: "🌧️", 359: "⛈️", 362: "🌨️", 365: "❄️",
        368: "🌨️", 371: "❄️", 374: "🌨️", 377: "🌨️",
        386: "⛈️", 389: "⛈️", 392: "🌨️", 395: "❄️",
    }
    weather_emoji = emoji_map.get(weather_code, "🌡️")

    if fmt == "short":
        return (
            f"{weather_emoji} **{location} · 当前天气**\n"
            f"{desc}  |  {temp}°C（体感 {feels}°C）\n"
            f"湿度 {humidity}%  |  风速 {wind} km/h  |  UV {uv}"
        )

    # Build forecast section grouped by day
    weather_data = data.get("weather", [])
    forecast_block = ""

    # Day labels for display
    day_labels = ["今天", "明天", "后天"]

    for day_idx, day_data in enumerate(weather_data[:days]):
        date_str = day_data.get("date", "")
        avg_temp = day_data.get("avgtempC", "--")
        max_temp = day_data.get("maxtempC", "--")
        min_temp = day_data.get("mintempC", "--")

        if day_idx == 0:
            # Current day — show current condition header + forecast
            forecast_block = (
                f"\n📅 **未来预报**\n"
                f"  ☀️ 00:00  {min_temp}°C ~ {max_temp}°C  {desc}\n"
            )
        else:
            # Future day — group by day
            day_label = day_labels[day_idx] if day_idx < len(day_labels) else f"第{day_idx+1}天"
            forecast_block += (
                f"\n📅 **{day_label}（{date_str}）**\n"
                f"  🌡️ 温度: {min_temp}°C ~ {max_temp}°C  |  平均 {avg_temp}°C\n"
            )
            # Show key hours for this day
            hours_shown = 0
            for hour in day_data.get("hourly", []):
                if hours_shown >= 4:
                    break
                t = hour.get("time", "0")
                hour_num = int(t) // 100
                h_temp = hour.get("tempC", "--")
                h_desc = hour.get("weatherDesc", [{}])[0].get("value", "--").strip()
                h_rain = hour.get("chanceofrain", "0")
                h_code = int(hour.get("weatherCode", 113))
                h_emoji = emoji_map.get(h_code, "🌡️")
                forecast_block += f"  {h_emoji} {hour_num:02d}:00  {h_temp}°C  {h_desc}  降水概率 {h_rain}%\n"
                hours_shown += 1

    result = (
        f"{weather_emoji} **{location} · 当前天气**\n"
        f"{desc}\n"
        f"\n"
        f"🌡️ 温度 {temp}°C  （体感 {feels}°C）\n"
        f"💧 湿度 {humidity}%\n"
        f"💨 风速 {wind} km/h\n"
        f"👁️ 能见度 {vis} km\n"
        f"🔘 气压 {pressure} hPa\n"
        f"☀️ UV 指数 {uv}"
    )

    if forecast_block:
        result += forecast_block

    return result


def get_weather(location: str = None, format: str = "normal", days: int = 1) -> str:
    """Fetch real-time weather data for a location.

    Args:
        location: City name (English preferred, e.g. "Hangzhou", "Beijing", "New York").
                  MUST be explicitly specified by the user — do NOT guess.
        format: "short" (compact), "normal" (current + forecast, default),
                "full" (detailed + full forecast)
        days: Number of days to forecast (1 = today, 2 = today+tomorrow, max 3).
              If the user asks about "明天" or "tomorrow", set days=2.

    Returns:
        Formatted weather text ready for VLM to interpret and add suggestions
    """
    global _cache

    # Guard: location is required
    if not location or not location.strip():
        return (
            "[Error] 未提供城市名称。请先询问用户想查询哪个城市。"
        )

    # Clamp days to 1-3
    days = max(1, min(3, int(days)))

    # Check cache
    cache_key = f"{location}_{days}"
    now_ts = time.time()
    cached = _cache.get(cache_key)
    if cached and (now_ts - cached[0]) < _CACHE_TTL:
        return f"[weather_query] (缓存) {cached[1]}"

    # Fetch JSON data
    url = f"https://wttr.in/{location}?format=j1"
    params = {"lang": "zh"}

    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.ConnectionError:
        return "[Error] 无法连接天气服务，请检查网络"
    except Exception as e:
        return f"[Error] 天气查询失败: {str(e)}"

    # Format the result
    result = _format_weather(data, location, format, days)

    # Cache
    _cache[cache_key] = (now_ts, result)

    return f"[weather_query] {result}"
