---
name: weather_query
description: >
  Query real-time weather data for any location using wttr.in API.
  Use when the user asks about weather, temperature, forecast, or weather conditions
  for a specific city or location.
version: 1.3.0
---

# Weather Query

Fetches accurate, real-time weather data from wttr.in (no API key).

## ⚠️ BEFORE CALLING get_weather()

**If the user did NOT name a city in their message:**

1. Check the **"RECALLED MEMORIES"** system message already injected into your conversation. It contains the full content of relevant memories (e.g., `user_location` → city name). Use that city.
2. If no recalled memory has location info → ask the user "请问你想查哪个城市？"
3. **NEVER assume or guess a city.**

Examples:
- "今天天气怎么样" → check RECALLED MEMORIES system message → use the city found there
- "杭州今天热吗" → call `get_weather(location="Hangzhou")`
- "天气怎么样" → if no memory has it → ask first, do NOT pick a default

## Triggering

**Use this skill when:**
- The user asks about weather ("天气", "weather", "temperature", "forecast", "气温")
- The user asks about rain, snow, wind, humidity for a location

**Do NOT use this skill when:**
- The user asks about weather in the simulated environment → use `env_description`
- The user asks about general climate or seasons → use `daily_chat`

## Tool Usage

- `get_weather(location, format, days)`: `location` is city name (English preferred).
  `format`: `"short"`, `"normal"` (default), `"full"`
  `days`: Number of forecast days (1 = today, 2 = today + tomorrow, max 3).

  **How to choose `days`:**
  - "今天" → `days=1`
  - "明天" → `days=2` (today + tomorrow, report tomorrow's data)
  - "后天" / "未来几天" / "这周末" → `days=3`
  - When in doubt, use `days=1` (current weather is always included)

  **Good examples:**
  - "明天杭州天气" → `get_weather("Hangzhou", days=2)` → 从返回数据中提取明天的部分
  - "后面几天的天气" → `get_weather("Hangzhou", days=3)` → 从返回数据中筛选未来几天
  - "今天天气怎么样" → `get_weather("Hangzhou", days=1)`

  **Bad examples:**
  - 问"明天天气"却用 `days=1` → 只能拿到当前天气，没有预报
  - 拿到数据后直接全文返回 → 应该根据用户问题提取对应天数的数据

## How to Generate Suggestions

After getting weather data, use your reasoning to generate natural, helpful suggestions.
Think about what this weather means for daily life — rain → umbrella, hot → sunscreen, etc.
Be natural, not template-like.

## Common Pitfalls

- **Never guess weather from memory.** Always call `get_weather()` for current data.
- **English city names** work more reliably.
- **Tool output is data, not the final answer.** Interpret it for the user.
