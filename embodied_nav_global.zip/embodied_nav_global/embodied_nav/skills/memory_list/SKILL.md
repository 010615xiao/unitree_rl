---
name: memory_list
description: >
  List and read long-term memories. Use when the user asks "what do you remember" or before searching for something specific.
version: 1.0.0
---

# Memory List

View all stored memories and their content.

**When to use:**
- The user asks "what do you remember", "show me your notes"
- Before searching for something specific

**Tools:**
- `list_memories()` — Lists all memory keys.
- `read_memory(key)` — Reads a specific memory by key with full metadata. Use only if you know the exact key.
