"""
Memory List Skill - Tools

List and read long-term memories.
"""


def list_memories(memory_dir: str = "./memory") -> str:
    """List all memory keys.

    Args:
        memory_dir: Directory to read from

    Returns:
        Comma-separated list of memory keys
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    keys = ltm.list_keys()
    if not keys:
        return "[memory] No memories stored."
    return f"[memory] {len(keys)} entries: {', '.join(sorted(keys))}"


def read_memory(key: str, memory_dir: str = "./memory") -> str:
    """Read a specific memory by key.

    Args:
        key: Memory key to read
        memory_dir: Directory

    Returns:
        Full memory content with metadata
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    entry = ltm.get_entry(key)
    if entry is None:
        return f"[memory] Key '{key}' not found. Use list_memories() to see available keys."

    tags_str = ", ".join(entry.tags) if entry.tags else "(no tags)"
    return f"[memory] {key} (type: {entry.type}, tags: {tags_str})\n\n{entry.content}"
