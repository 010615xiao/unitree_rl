"""
Task Planning Skill - Tools

Uses VLM to decompose high-level goals into real, executable step sequences
with concrete skill names and intents.
"""

import json


def create_plan(
    goal: str,
    vlm_client=None,
    available_skills: str = "",
    max_steps: int = 10,
) -> str:
    """Generate a structured plan using VLM reasoning.

    Args:
        goal: High-level task description (e.g., "go to the kitchen and bring me food")
        vlm_client: VLMClient instance for plan generation. If None, returns placeholder.
        available_skills: Available skill names (injected by caller for context)
        max_steps: Maximum number of steps in the plan

    Returns:
        JSON string with ordered steps, each specifying skill and intent.
    """
    if vlm_client is None:
        # Fallback: return placeholder (shouldn't happen in normal flow)
        return json.dumps({
            "goal": goal,
            "steps": [
                {"skill": "unknown", "intent": "[VLM client not available to generate plan]"}
            ],
            "note": "Plan generation requires VLM client."
        }, indent=2, ensure_ascii=False)

    # Build the planning prompt
    skill_context = f"Available skills:\n{available_skills}" if available_skills else ""

    prompt = f"""You are a task planning assistant. Decompose high-level goals into a sequence of steps.

Each step must specify:
- "skill": Which skill handles this step (use ONLY skills from the available list)
- "intent": A natural language description of what to accomplish in this step

{skill_context}

Rules:
- Keep plans short: 2-{max_steps} steps max
- Be specific about the intent — include enough detail for the skill's sub-agent to execute
- If the goal is simple (1 step), return just that step
- If the goal is complex, break it into logical sub-tasks
- If a step's result is needed by a later step, mention it in the intent
- Do NOT invent skills that don't exist
- Do NOT include steps for memory recall unless the goal explicitly references past context

Goal: {goal}

Return ONLY valid JSON, nothing else:
{{
  "goal": "{goal}",
  "steps": [
    {{"skill": "skill_name", "intent": "what to do"}},
    {{"skill": "skill_name", "intent": "what to do"}}
  ]
}}"""

    messages = [
        {"role": "system", "content": "You are a task planner. Output valid JSON only."},
        {"role": "user", "content": prompt},
    ]

    try:
        response = vlm_client.chat(messages)

        # Extract JSON from response (may have markdown fences)
        cleaned = response.strip()
        if cleaned.startswith("```"):
            import re
            match = re.search(r'```(?:json)?\s*(.*?)\s*```', cleaned, re.DOTALL)
            if match:
                cleaned = match.group(1).strip()

        # Validate JSON
        plan = json.loads(cleaned)
        if "goal" not in plan or "steps" not in plan:
            raise ValueError("Missing 'goal' or 'steps' in plan")

        # Limit steps
        plan["steps"] = plan["steps"][:max_steps]

        return json.dumps(plan, indent=2, ensure_ascii=False)

    except Exception as e:
        return json.dumps({
            "goal": goal,
            "steps": [
                {"skill": "daily_chat", "intent": f"Could not generate a structured plan. Error: {str(e)[:100]}"}
            ],
            "note": f"VLM plan generation failed: {str(e)[:100]}"
        }, indent=2, ensure_ascii=False)


def validate_plan(plan: str, context: str = "") -> str:
    """Check if a plan is feasible.

    Args:
        plan: JSON string of the plan to validate
        context: Current environment/situation context

    Returns:
        Validation result with feasibility assessment
    """
    try:
        plan_data = json.loads(plan)
        steps = plan_data.get("steps", [])
        return json.dumps({
            "valid": True,
            "steps_count": len(steps),
            "steps": [
                {"id": i + 1, "skill": s.get("skill", "?"), "intent": s.get("intent", "?")}
                for i, s in enumerate(steps)
            ],
            "note": "Plan structure is valid. Execution feasibility depends on available skills and environment."
        }, indent=2)
    except json.JSONDecodeError:
        return '{"valid": false, "reason": "Invalid plan format"}'


def refine_plan(goal: str, feedback: str, vlm_client=None, available_skills: str = "") -> str:
    """Improve a plan based on execution feedback.

    Args:
        goal: Original goal
        feedback: What went wrong or what needs adjustment
        vlm_client: VLMClient instance
        available_skills: Available skill names

    Returns:
        Refined plan
    """
    if vlm_client is None:
        return json.dumps({
            "goal": goal,
            "feedback_incorporated": feedback,
            "note": "Plan refinement requires VLM client."
        }, indent=2)

    prompt = f"""You are a task planning assistant. Refine a plan based on execution feedback.

{available_skills}

Original goal: {goal}
Execution feedback: {feedback}

Create a new plan that accounts for the feedback. Keep it concise (2-10 steps).

Return ONLY valid JSON:
{{
  "goal": "{goal}",
  "steps": [
    {{"skill": "skill_name", "intent": "what to do"}}
  ]
}}"""

    messages = [
        {"role": "system", "content": "You are a task planner. Output valid JSON only."},
        {"role": "user", "content": prompt},
    ]

    try:
        response = vlm_client.chat(messages)
        cleaned = response.strip()
        if cleaned.startswith("```"):
            import re
            match = re.search(r'```(?:json)?\s*(.*?)\s*```', cleaned, re.DOTALL)
            if match:
                cleaned = match.group(1).strip()
        plan = json.loads(cleaned)
        return json.dumps(plan, indent=2, ensure_ascii=False)
    except Exception as e:
        return json.dumps({
            "goal": goal,
            "feedback_incorporated": feedback,
            "error": str(e)[:100]
        }, indent=2)
