---
name: task_planning
description: >
  Decompose high-level user goals into ordered sequences of actionable steps. Use this skill
  when the user gives a complex task that requires planning (e.g., "clean the room", "make
  breakfast", "go to the kitchen and get a cup of water"). If the user's request implies
  multiple sequential actions, use this skill first before executing anything. Also use it
  when the user explicitly asks for a plan, steps, or strategy.
version: 2.0.0
---

# Task Planning

Breaks down complex user goals into structured, sequential plans with **real skill names**.

## Triggering

**Use this skill when:**
- The user gives a high-level goal that implies multiple actions (e.g., "clean the room",
  "prepare breakfast", "go to the kitchen")
- The user asks for a plan, steps, or strategy
- You need to organize actions before executing them
- The current task has failed and needs replanning

**Do NOT use this skill when:**
- The task is simple and direct (e.g., "what time is it?", "open this URL") → use
  `daily_chat` or `browser_control`
- The user asks about visual observation → use `env_description`
- The user asks about specific movement/navigation → use `global_navigation`

## Tool Usage Notes

- `create_plan(goal, vlm_client, available_skills, max_steps)`: Generates a real JSON plan
  with ordered steps, each specifying which skill handles it and what to do.
  - `goal`: The high-level task description from the user
  - `vlm_client`: Required — VLM decomposes the goal using reasoning
  - `available_skills`: List of available skills for the VLM to choose from
  - `max_steps`: Limit the plan length (default 10). Keep plans short — the VLM works
    best with 3-7 steps.
  - Returns JSON: `{"goal": "...", "steps": [{"skill": "...", "intent": "..."}]}`

- `validate_plan(plan, context)`: Check if a plan structure is valid.
  - Returns step count and validation status.

- `refine_plan(goal, feedback, vlm_client, available_skills)`: Re-plan based on feedback.
  - `feedback`: What went wrong during execution (e.g., "couldn't reach the kitchen, door
    is closed")
  - Use this when a plan fails during execution.

## Common Pitfalls

- **Don't over-plan.** The plan is a high-level guide, not a detailed script. Let the
  ReAct loop handle the fine-grained decisions.
- **Plans are abstract, not executable.** The plan tells you WHAT to do, not HOW. You
  still need to call the right skills (browser_control, global_navigation, etc.) for each step.
- **Keep plans short.** If a plan has more than 10 steps, break it into sub-plans. The
  VLM's context window is limited (12K tokens).
