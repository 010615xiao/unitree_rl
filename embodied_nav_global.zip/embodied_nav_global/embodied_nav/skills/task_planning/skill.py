"""
Task Planning Skill - Custom Implementation

Overrides execute() to generate a real plan via VLM with actual step
sequences using concrete skill names. Returns the plan to the main
VLM, which will execute it step by step.
"""

import json
from core.skill import BaseSkill


class TaskPlanningSkill(BaseSkill):
    """Task planning skill that uses VLM to generate real executable plans."""

    def execute(self, intent: str, vlm_client=None, messages: list[dict] | None = None,
                **kwargs) -> str:
        """Generate a structured plan JSON from the user's intent.

        Uses VLM to decompose the goal into real steps with skill names.

        Args:
            intent: The user's goal or task description
            vlm_client: VLMClient instance (required for plan generation)
            messages: Conversation history (for context)
        """
        create_plan = self.tools.get("create_plan")
        if not create_plan:
            return "Error: create_plan tool not found in task_planning skill"

        # Build available skills context
        available_skills = ""
        if self._registry:
            skills_list = self._registry.get_all()
            available_skills = "\n".join(
                f"  - {s.name}: {s.description}"
                for s in skills_list
                if s.name != self.name
            )

        try:
            plan_result = create_plan(
                goal=intent,
                vlm_client=vlm_client,
                available_skills=available_skills,
                max_steps=10,
            )
        except TypeError:
            # Fallback if tool signature is different
            plan_result = create_plan(goal=intent, vlm_client=vlm_client)

        plan_str = str(plan_result)

        # Format for readability
        try:
            plan_data = json.loads(plan_str)
            steps = plan_data.get("steps", [])
            summary = f"Plan generated with {len(steps)} steps:\n\n{json.dumps(plan_data, indent=2, ensure_ascii=False)}"
        except (json.JSONDecodeError, TypeError):
            summary = plan_str

        return summary
