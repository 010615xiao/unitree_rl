"""
Memory Delete Skill - Tools

Delete stale or unwanted long-term memories.
"""


def delete_memory(key: str, memory_dir: str = "./memory") -> str:
    """Delete a memory entry.

    Args:
        key: Memory key to delete
        memory_dir: Directory

    Returns:
        Confirmation message
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    ltm.delete(key)
    ltm.generate_memory_md()
    return f"[memory] Deleted '{key}'"
