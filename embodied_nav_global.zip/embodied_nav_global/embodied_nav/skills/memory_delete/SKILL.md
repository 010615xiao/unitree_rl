---
name: memory_delete
description: >
  Delete stale or unwanted long-term memories. Use when the user says "forget...", "delete that memory".
version: 1.0.0
---

# Memory Delete

Permanently remove memories that are no longer relevant.

**When to use:**
- The user says "forget...", "delete that memory"
- A memory is no longer relevant (deadline passed, project complete)

**When NOT to use:**
- Just to tidy up — only delete if the memory is truly stale or the user asks

**Tools:**
- `delete_memory(key)` — Permanently removes a memory. Confirm with the user before deleting if they didn't explicitly say "forget".
