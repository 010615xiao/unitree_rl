"""
Daily Chat Skill - Tools

Responds to casual queries using the VLM's built-in knowledge.
"""


def respond(query: str) -> str:
    """Respond to a casual query using VLM knowledge.

    Args:
        query: The user's question or message

    Returns:
        The query text (the agent will use its VLM to generate the actual response).
    """
    return f"[daily_chat] Query received: {query}"
