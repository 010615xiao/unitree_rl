---
name: daily_chat
description: >
  Handle casual conversation, answer general questions, and provide explanations.
  Use this skill when the user greets you, asks open-ended questions, requests explanations,
  wants to chat, or asks about concepts that don't require specialized tools.
  **Do NOT use this skill for real-time information** (dates, time, news, stock prices) —
  use `browser_control` for that instead.
  If the user mentions images, websites, planning, navigation, or embodied actions,
  use the specialized skill instead.
version: 1.3.0
---

# Daily Chat

General conversational skill using the VLM's built-in knowledge.

## ⚠️ Critical Rules

### Rule 1: NEVER fabricate real-time information

**If the user asks about dates, time, news, prices, or any information that changes over time:**
- Your training data is outdated. **Do NOT guess or fabricate answers from memory.**
- If `browser_control` is available and working: use it to fetch real-time info.
- If `browser_control` is unavailable: **honestly tell the user** you cannot access real-time information.
- Never invent dates, times, or facts — even if you feel confident.

### Rule 2: Use recalled memories for relevant context

**Relevant long-term memories are already injected into your conversation as "RECALLED MEMORIES" — you do NOT need to call memory_recall tools.**

- If RECALLED MEMORIES are present and contain facts that help answer the user, use them naturally in your response.
- If the user asks "你怎么知道...": explain that you remembered it from a past conversation.
- If no RECALLED MEMORIES section is present, or the recalled facts are not relevant to the current query, answer normally without forcing memory references.

**The key principle:** When you have the needed information in RECALLED MEMORIES, use it. When you don't, don't pretend you have it — answer honestly.

## Triggering

**Use this skill when:**
- The user greets you ("你好", "hi", "hello")
- The user asks general knowledge questions
- The user wants explanations, summaries, or opinions
- The user is chatting casually

**Do NOT use this skill when:**
- The user asks to browse/search a website → use `browser_control`
- The user asks to describe an image or screenshot → use `env_description`
- The user gives a multi-step task → use `task_planning`
- The user asks about movement/navigation → use `global_navigation`

## Tool Usage Notes

- `respond(query)`: Passes the query through. The actual response is generated
  by the VLM within this skill's execution — using the full conversation history
  for context (including any prior tool results like memory recalls or weather data).

## Response Guidelines

- Keep responses concise and helpful
- For embodied AI context, relate answers to the simulation environment when relevant
- If unsure about something, say so rather than guessing
