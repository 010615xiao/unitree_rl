"""
Environment Description Skill - Tools

Tools for analyzing images and capturing screenshots of the virtual environment.
"""

import os


def describe_image(image_path: str) -> str:
    """Analyze an image using the VLM and return a description.

    Args:
        image_path: Path to the image file to analyze

    Returns:
        Detailed text description of the image
    """
    import base64
    from core.llm_client import VLMClient

    if not os.path.exists(image_path):
        return f"[env_description] Image not found: {image_path}"

    try:
        client = VLMClient()
        # Read image and encode as base64 data URL
        with open(image_path, "rb") as f:
            image_b64 = base64.b64encode(f.read()).decode("utf-8")

        ext = os.path.splitext(image_path)[1].lower().lstrip(".")
        mime = f"image/{ext}" if ext in ("png", "jpeg", "jpg", "gif", "webp") else "image/png"

        messages = [
            {"role": "user", "content": [
                {"type": "text", "text": "Describe this image in detail. What do you see?"},
                {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{image_b64}"}}
            ]}
        ]
        result = client.chat(messages)
        return f"[env_description] {result}"
    except Exception as e:
        return f"[env_description] VLM analysis failed: {e}"


def screenshot_env(display_id: str = ":99") -> str:
    """Take a screenshot of the current virtual display (Xvfb).

    Args:
        display_id: X11 display identifier (default ':99' for Xvfb)

    Returns:
        Path to the saved screenshot file
    """
    import subprocess

    output_dir = "/workspace/wxd/Agent/images"
    os.makedirs(output_dir, exist_ok=True)

    screenshot_path = os.path.join(output_dir, "latest_env.png")

    try:
        cmd = ["import", "-window", "root", "-display", display_id, screenshot_path]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return f"[env_description] Screenshot saved: {screenshot_path}"
        else:
            return f"[Error] Screenshot failed: {result.stderr}"
    except FileNotFoundError:
        return "[Error] 'import' command not found. Install imagemagick."
    except Exception as e:
        return f"[Error] Screenshot error: {e}"
