"""
Browser Use Skill - Tools

Launch a fully autonomous Browser-Use agent with a natural language task.
Progress is shown as a single updating status line with the current action.

Uses browser-use's built-in register_new_step_callback for real-time progress,
not logging interception.
"""

import asyncio
import logging
import os
import re
import sys
import threading

# Ensure browser-use-main is on sys.path (it lives inside this skill directory)
_skill_dir = os.path.dirname(os.path.abspath(__file__))
_browser_use_main = os.path.join(_skill_dir, "browser-use-main")
if _browser_use_main not in sys.path:
    sys.path.insert(0, _browser_use_main)

# Silence ALL browser-use related loggers — we show clean status lines via callbacks
_NOISE_LOGGERS = [
    "browser_use", "browser_use.agent", "browser_use.browser",
    "browser_use.agent.service", "browser_use.tools",
    "browser_use.tools.registry", "browser_use.dom",
    "playwright", "playwright._impl",
    "bubus", "cdp_use", "cdp_use.client",
    "urllib3", "asyncio",
]


def _silence_all_browser_logs():
    """Completely silence all browser-use related loggers."""
    for name in _NOISE_LOGGERS:
        logger = logging.getLogger(name)
        for h in list(logger.handlers):
            logger.removeHandler(h)
        logger.addHandler(logging.NullHandler())
        logger.setLevel(logging.CRITICAL + 1)
        logger.propagate = False


class _BrowserStatusDisplay:
    """Shows browser-use agent's current action as a single updating terminal line.

    Uses a background thread to continuously animate the spinner on the current
    line. When a step completes, the line is "locked" and a new spinning line
    starts for the next action.
    """

    FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self):
        self._frame_idx = 0
        self._lock = threading.Lock()
        self._current_action = ""
        self._is_locking = False
        self._stop_event = threading.Event()
        self._thread = None

    def _render_loop(self):
        """Background thread that continuously updates the current spinner line."""
        from utils.styled_output import Colors, _get_terminal_width

        while not self._stop_event.is_set():
            with self._lock:
                action = self._current_action
                is_locking = self._is_locking
                if not is_locking:
                    frame = self.FRAMES[self._frame_idx % len(self.FRAMES)]
                    self._frame_idx += 1

            if not action or is_locking:
                self._stop_event.wait(0.1)
                continue

            clean_action = re.sub(r'\033\[[0-9;]*m', '', action)
            max_len = _get_terminal_width() - 15
            if len(clean_action) > max_len:
                clean_action = clean_action[:max_len] + "…"

            colored_frame = f"{Colors.BRIGHT_CYAN}{frame}{Colors.RESET}"
            colored_action = f"{Colors.DIM}{clean_action}{Colors.RESET}"
            line = f"  {colored_frame} {colored_action}"

            sys.stdout.write(f"\r{line}\033[K")
            sys.stdout.flush()

            self._stop_event.wait(0.1)  # 10 FPS

    def start(self):
        """Start the background render thread."""
        self._thread = threading.Thread(target=self._render_loop, daemon=True)
        self._thread.start()

    def update(self, action_text: str):
        """Set a new action text — the render thread will show it immediately."""
        if not action_text:
            return
        with self._lock:
            self._current_action = action_text
            self._is_locking = False

    def lock(self):
        """Stop spinning, finalize the current line with a checkmark, and move to next line."""
        from utils.styled_output import Colors, _get_terminal_width

        with self._lock:
            action = self._current_action
            if not action:
                return
            clean_action = re.sub(r'\033\[[0-9;]*m', '', action)
            max_len = _get_terminal_width() - 15
            if len(clean_action) > max_len:
                clean_action = clean_action[:max_len] + "…"
            self._is_locking = True

        checkmark = f"{Colors.BRIGHT_GREEN}✓{Colors.RESET}"
        colored_action = f"{Colors.DIM}{clean_action}{Colors.RESET}"
        sys.stdout.write(f"\r  {checkmark} {colored_action}\n")
        sys.stdout.flush()

    def stop(self):
        """Stop the background render thread."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=1)


def run_browser_task(
    task: str,
    url: str = None,
    max_steps: int = 20,
) -> str:
    """Launch a fully autonomous Browser-Use agent."""
    try:
        from browser_use import Agent, Browser, ChatOpenAI
    except ImportError:
        return "[Error] browser-use not installed."

    # Silence ALL browser-use logs — we use callbacks instead
    _silence_all_browser_logs()

    full_task = task
    if url:
        full_task = f"访问 {url}，然后{task}"

    # Create status display
    status = _BrowserStatusDisplay()

    # Callback: called after LLM responds with planned actions, before execution
    async def on_new_step(state, output, step_number):
        """Extract planned action and update display."""
        try:
            display_text = None
            actions = getattr(output, 'action', None)
            if actions and isinstance(actions, list) and len(actions) > 0:
                action = actions[0]
                # model_dump(exclude_unset=True) -> {action_name: params_dict}
                action_dict = action.model_dump(exclude_unset=True)

                for action_name, params_dict in action_dict.items():
                    if params_dict and isinstance(params_dict, dict):
                        parts = []
                        for k, v in params_dict.items():
                            if v is not None:
                                val_str = str(v)[:60]
                                parts.append(f"{k}={val_str}")
                        if parts:
                            display_text = f"{action_name}: {', '.join(parts)}"
                        else:
                            display_text = action_name
                        break

            if not display_text:
                # Fallback: next_goal or thinking
                next_goal = getattr(output, 'next_goal', '')
                if next_goal:
                    display_text = next_goal[:80]
                else:
                    thinking = getattr(output, 'thinking', '')
                    if thinking:
                        display_text = thinking[:80]

            if display_text:
                # Lock the previous action, then start spinning on the new one
                status.lock()
                status.update(display_text)
        except Exception as e:
            # Show debug info on error
            status.update(f"[debug] {type(e).__name__}: {str(e)[:50]}")

    # Create browser-use objects
    browser = Browser(
        headless=True,
        enable_default_extensions=False,
    )

    llm = ChatOpenAI(
        model="Qwen3.6-35B-A3B",
        base_url="http://localhost:8010/v1",
        api_key="not-needed",
        temperature=0.0,
    )

    agent = Agent(
        task=full_task,
        llm=llm,
        browser=browser,
        file_system_path=os.getcwd(),
        register_new_step_callback=on_new_step,
        extend_system_message=(
            "When searching or navigating, ALWAYS prefer Bing (bing.com) as the search engine. "
            "NEVER use Google. Be concise and efficient with your steps."
        ),
    )

    # Print initial "Starting..." line and begin spinning
    status.update("Starting...")
    status.start()

    async def _run():
        # on_step_start: show step number
        async def on_step_start(agent):
            step = getattr(agent.state, 'n_steps', 0)
            # Just update display via callback, no need for separate handling

        return await agent.run(max_steps=max_steps, on_step_start=on_step_start)

    try:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(asyncio.run, _run)
                    result = future.result(timeout=300)
            else:
                result = loop.run_until_complete(_run())
        except RuntimeError:
            result = asyncio.run(_run())
    finally:
        # Lock the last spinning line and stop the render thread
        status.lock()
        status.stop()

    final = result.final_result() or "[Browser-Use agent returned no result]"
    history = getattr(result, 'history', [])
    step_count = len(history) if history else 0

    from utils.styled_output import print_browser_use_end
    print_browser_use_end(f"Completed in {step_count} steps", "done")

    return final
