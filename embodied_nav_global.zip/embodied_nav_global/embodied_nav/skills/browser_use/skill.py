"""
Browser Use Skill - Custom Implementation

Overrides execute() to launch a fully autonomous Browser-Use agent.
This bypasses the embodied_nav sub-agent ReAct loop entirely, because
Browser-Use has its own internal LLM loop for browser automation.

Flow:
  1. Main VLM selects browser_use skill + passes user intent
  2. This execute() launches Browser-Use agent with that intent
  3. Browser-Use agent independently plans & executes browser actions
  4. Final result returned to main VLM → main VLM responds to user
"""

from core.skill import BaseSkill


class BrowserUseSkill(BaseSkill):
    """Browser-Use skill that delegates to the autonomous Browser-Use framework."""

    def execute(
        self,
        intent: str,
        vlm_client=None,
        messages: list[dict] | None = None,
        **kwargs,
    ) -> str:
        """Launch a Browser-Use agent with the user's intent.

        Unlike DefaultSkill, this does NOT run the embodied_nav sub-agent loop.
        Browser-Use has its own internal LLM loop that handles all browser
        planning (navigation, clicks, inputs, extraction).

        Args:
            intent: What the user wants to accomplish (natural language).
                    The Browser-Use agent will independently plan how to achieve this.
            vlm_client: Not used — Browser-Use connects to its own LLM.
            messages: Conversation history (not used — Browser-Use is stateless).

        Returns:
            Final result from the Browser-Use agent, prefixed with [FINAL_ANSWER].
        """
        run_browser_task = self.tools.get("run_browser_task")
        if not run_browser_task:
            return "[FINAL_ANSWER]Error: run_browser_task tool not found in browser_use skill"

        # Extract optional parameters from kwargs if provided
        url = kwargs.get("url")
        max_steps = kwargs.get("max_steps", 20)

        # Launch the autonomous Browser-Use agent
        result = run_browser_task(task=intent, url=url, max_steps=max_steps)

        return f"[FINAL_ANSWER]{result}"
