"""
测试 browser-use 连接本地 llama.cpp 模型
"""
from browser_use import Agent, Browser, ChatOpenAI
import asyncio

async def main():
    browser = Browser(
        headless=True,  # Docker 容器中没有图形界面，必须用 headless
        enable_default_extensions=False,  # 禁用默认扩展，避免下载超时
    )
    
    # 连接本地 llama.cpp 服务器
    llm = ChatOpenAI(
        model="Qwen3.6-35B-A3B",
        base_url="http://localhost:8010/v1",
        api_key="not-needed",
        temperature=0.0
    )
    
    agent = Agent(
        task="查询特朗普访华的最新消息",
        llm=llm,
        browser=browser,
        max_steps=20,
        extend_system_message="When searching or navigating, ALWAYS prefer Bing (bing.com) as the search engine. NEVER use Google."
    )
    
    result = await agent.run()
    
    # 查看结果
    print("\n=== 完成 ===")
    print(f"最终结果: {result.final_result()}")
    print(f"访问的 URLs: {result.urls()}")

if __name__ == "__main__":
    asyncio.run(main())
