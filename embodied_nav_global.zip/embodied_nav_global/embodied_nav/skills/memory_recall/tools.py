"""
Memory Recall Skill - Tools

Recall long-term persistent memory before tool calls.
"""

import json
import os
from pathlib import Path


def recall_index(memory_dir: str = "./memory") -> str:
    """Get a lightweight index (key + type + tags) of all memories.

    This returns keys, types, and tags as hints, but NOT the actual content.
    Call recall_context(keys="...") to load details of relevant memories.

    Args:
        memory_dir: Directory to read from (default: ./memory)

    Returns:
        Index of all memories with key + type + tags, or message if none exist
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    index = ltm.get_index()

    if not index:
        return "[memory] No long-term memories stored yet."

    lines = [f"[memory] Memory index ({len(index)} entries). Call recall_context(keys=\"...\") to load details:\n"]
    for entry in index:
        tags_str = f" (tags: {', '.join(entry['tags'])})" if entry["tags"] else ""
        type_str = f" [{entry['type']}]"
        expiry_str = f" ⏰ expires {entry['expires']}" if entry.get("expires") else ""
        lines.append(f"  - {entry['key']}{type_str}{tags_str}{expiry_str}")

    return "\n".join(lines)


def recall_context(keys: str, memory_dir: str = "./memory") -> str:
    """Load full content of specific memories by key.

    Use this AFTER reviewing the memory index (recall_index) to load
    the full content of memories that are relevant to the user's query.

    CRITICAL: You MUST only use keys that exist in the memory store.
    Call recall_index() first to see available keys, then pick the closest match.
    NEVER invent key names.

    Args:
        keys: Comma-separated list of memory keys (e.g., "user_location,user_language")
        memory_dir: Directory to read from (default: ./memory)

    Returns:
        Full content of requested memories, or error for invalid keys
    """
    import json
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)

    # Handle both comma-separated and JSON array formats
    stripped = keys.strip()
    if stripped.startswith("["):
        try:
            key_list = json.loads(stripped)
            if isinstance(key_list, str):
                key_list = [key_list]
            elif not isinstance(key_list, list):
                key_list = [str(key_list)]
        except json.JSONDecodeError:
            key_list = [k.strip() for k in stripped.split(",") if k.strip()]
    else:
        key_list = [k.strip().strip('"').strip("'") for k in stripped.split(",") if k.strip()]

    if not key_list:
        return "[memory] No keys provided. Use recall_index() to see available memories."

    valid_keys = ltm.list_keys()
    invalid = [k for k in key_list if k not in valid_keys]
    if invalid:
        return (
            f"[memory] ERROR: Keys {invalid} do not exist.\n"
            f"Valid keys: {', '.join(sorted(valid_keys))}\n\n"
            f"You MUST only use keys listed above. NEVER invent key names."
        )

    lines = []
    for key in key_list:
        entry = ltm.get_entry(key)
        if entry:
            tags_str = f" (type: {entry.type}, tags: {', '.join(entry.tags)})" if entry.tags else f" (type: {entry.type})"
            lines.append(f"--- {key}{tags_str} ---\n{entry.content}\n")

    return f"[memory] Loaded {len(lines)} memories:\n" + "\n".join(lines)


def spatial_query(query: str) -> str:
    """Query the spatial scene graph for information about rooms and objects.

    Use this to answer questions about:
    - Which room an object is in (e.g., "chair_0 在哪个房间")
    - What objects are in a room (e.g., "room 1 有什么")
    - Object locations, categories, and spatial relationships
    - Room centers, areas, and object lists

    Args:
        query: Natural language query about the scene.
               Examples: "chair_0 在哪个房间", "room 1 有什么物体", "chair 有哪些实例"

    Returns:
        Information from the scene graph relevant to the query,
        or an error if the scene graph cannot be found.
    """
    # Find scene_graph.json — search known locations
    possible_paths = [
        Path(__file__).parent.parent.parent.parent.parent / "scene_graph.json",
        Path(__file__).parent.parent / "global_navigation" / "src" / "data" / "scene_graph.json",
        Path("./scene_graph.json").resolve(),
    ]

    sg_path = None
    for p in possible_paths:
        if p.exists():
            sg_path = p
            break

    if sg_path is None:
        return "[spatial] ERROR: scene_graph.json not found. The spatial scene is unavailable."

    try:
        with open(sg_path, "r") as f:
            scene = json.load(f)
    except Exception as e:
        return f"[spatial] ERROR: failed to load scene_graph.json: {e}"

    rooms = scene.get("rooms", [])
    objects = scene.get("objects", [])

    # Build room id → info map
    room_map = {}
    for r in rooms:
        room_map[r["id"]] = r

    # Parse query keywords
    q = query.lower().strip()

    # Pattern: "有哪些 X" / "list X" — check FIRST if query asks for a category listing
    # Keywords that indicate "list all instances of category"
    list_keywords = ['有哪些', 'list', '所有', '全部', 'instances', '几个']
    is_list_query = any(kw in q for kw in list_keywords)

    if is_list_query:
        for obj in objects:
            if obj.get("category", "").lower() in q:
                cat = obj["category"]
                cat_objects = [o for o in objects if o.get("category") == cat]
                lines = [f"[spatial] Found {len(cat_objects)} '{cat}' objects:"]
                for o in cat_objects[:15]:
                    rid = o.get("room_id")
                    lines.append(f"  {o['name']} → room {rid}, location {o['center']}")
                if len(cat_objects) > 15:
                    lines.append(f"  ... and {len(cat_objects) - 15} more")
                return "\n".join(lines)

    # Pattern: "X 在哪个房间" / "X in which room" — find a specific object
    target_name = None
    for obj in objects:
        if obj["name"].lower() in q or obj.get("category", "").lower() in q:
            target_name = obj["name"]
            break

    if target_name:
        for obj in objects:
            if obj["name"] == target_name:
                room_id = obj.get("room_id")
                room_info = room_map.get(room_id, {})
                room_center = room_info.get("center", [0, 0, 0])
                return (
                    f"[spatial] Object: {obj['name']} (category: {obj['category']})\n"
                    f"  Room: {room_id}\n"
                    f"  Location: {obj['center']}\n"
                    f"  Room center: {room_center}\n"
                    f"  Room area: {room_info.get('area', 'unknown')}\n"
                    f"  Nearby objects: {_format_nearby(obj.get('nearby_objects', []))}"
                )

    # Pattern: "room N 有什么" / "what's in room N"
    import re
    room_id_match = re.search(r'room[_\s]?(\d+)', q)
    if room_id_match:
        rid = int(room_id_match.group(1))
        room_objects = [o for o in objects if o.get("room_id") == rid]
        room_info = room_map.get(rid, {})
        if not room_objects:
            return f"[spatial] Room {rid}: no objects found."
        categories = {}
        for o in room_objects:
            cat = o.get("category", "unknown")
            categories.setdefault(cat, []).append(o["name"])
        lines = [f"[spatial] Room {rid} ({len(room_objects)} objects):"]
        for cat, names in sorted(categories.items()):
            lines.append(f"  {cat} ({len(names)}): {', '.join(names[:5])}{'...' if len(names) > 5 else ''}")
        return "\n".join(lines)

    # Pattern: "有哪些 X" / "list X"
    for obj in objects:
        if obj.get("category", "").lower() in q:
            cat = obj["category"]
            cat_objects = [o for o in objects if o.get("category") == cat]
            lines = [f"[spatial] Found {len(cat_objects)} '{cat}' objects:"]
            for o in cat_objects[:15]:
                rid = o.get("room_id")
                lines.append(f"  {o['name']} → room {rid}, location {o['center']}")
            if len(cat_objects) > 15:
                lines.append(f"  ... and {len(cat_objects) - 15} more")
            return "\n".join(lines)

    # Fallback: return scene summary
    categories = {}
    for o in objects:
        cat = o.get("category", "unknown")
        categories[cat] = categories.get(cat, 0) + 1
    lines = [f"[spatial] Scene summary ({len(objects)} objects, {len(rooms)} rooms):"]
    lines.append(f"  Categories: {', '.join(f'{k}({v})' for k, v in sorted(categories.items())[:20])}")
    if len(categories) > 20:
        lines.append(f"  ... and {len(categories) - 20} more categories")
    return "\n".join(lines)


def _format_nearby(nearby):
    """Format nearby_objects list for display."""
    if not nearby:
        return "none"
    if isinstance(nearby, list) and len(nearby) > 0 and isinstance(nearby[0], dict):
        cats = [item.get("category", "?") for item in nearby[:8]]
        return ", ".join(cats)
    return str(nearby)[:100]

