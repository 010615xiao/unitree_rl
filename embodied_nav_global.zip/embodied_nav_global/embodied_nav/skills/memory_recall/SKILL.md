---
name: memory_recall
description: >
  Recall information from two memory sources: long-term user memories (personal facts, preferences)
  and spatial scene memory (objects, rooms, locations). Use BEFORE calling any tool that needs
  information the user didn't provide. Returns an index of all memories, then loads full content
  for relevant ones. Also supports querying the spatial scene graph for room/object information.
version: 1.0.0
---

# Memory Recall

Recall information **BEFORE** calling any tool that needs information the user didn't explicitly provide.

**Two memory sources:**

1. **Long-term user memories** — Personal facts, preferences, relationships, identity
   - Examples: user name, location, allergies, language, relationships
   - Use `recall_index()` → `recall_context(keys)`

2. **Spatial scene memory** — The 3D reconstructed environment: rooms, objects, locations
   - Examples: "chair_0 在哪个房间", "room 1 有什么物体", "有哪些 chair"
   - Use `spatial_query(query)` directly — no index needed

**When to use:**
- The user's message is missing required info for a tool (e.g., location for weather)
- You're uncertain about a fact (who someone is, where they live, what they prefer)
- The user uses vague references ("去找她", "那里", "之前说的")
- The user asks about objects/rooms in the spatial scene ("这个椅子在哪个房间")

**When NOT to use:**
- The user already provided all needed info explicitly
- Casual chat — use `daily_chat`

**Tools:**
- `recall_index()` — Returns a lightweight index (keys + types + tags) of ALL memories. Use this FIRST.
- `recall_context(keys)` — Loads full content of specific memories. **You MUST call this to learn what a memory actually says** — the index only shows tags. Takes comma-separated keys (e.g., `"user_location,user_language"`).
- `spatial_query(query)` — Query the spatial scene graph for room/object information. Natural language input. Examples: "chair_0 在哪个房间", "room 1 有什么物体", "chair 有哪些实例"

**Critical rules:**
- You MUST only use key names that appear in the `recall_index()` output. NEVER invent keys.
- If the key you want doesn't exist: use `recall_index()` to see what actually exists and pick the closest match.
- If no memory is relevant, ask the user — do NOT guess.
- For spatial scene questions (objects, rooms, locations), prefer `spatial_query()` over `recall_index()`.
