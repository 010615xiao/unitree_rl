"""
Error Handling Skill - Tools

Tools for analyzing tool errors, deciding recoverability, and generating
honest user-facing failure reports.
"""


def analyze_error(error_message: str, failed_tool: str = "") -> str:
    """Analyze a tool error and classify it into a category with suggested recovery steps.

    This helps the agent decide: WHAT went wrong, IS IT FIXABLE, and HOW to recover.

    Args:
        error_message: The error message returned by the failed tool.
        failed_tool: The name of the tool that failed (e.g., 'browser_control__navigate').

    Returns:
        Error classification, fixability assessment, and concrete next steps.
    """
    error_lower = error_message.lower()

    # ── Category 1: Permission / authentication errors (check EARLY, specific) ─
    auth_patterns = [
        "access denied", "unauthorized", "forbidden", "permission denied",
        "authentication required", "login required", "insufficient privileges",
    ]
    for pat in auth_patterns:
        if pat in error_lower:
            return (
                f"[error_handling] Category: PERMISSION_ERROR\n"
                f"Fixable: NO (requires user credentials or access)\n"
                f"What happened: You lack the credentials, login, or permissions needed.\n"
                f"Failed tool: {failed_tool}\n"
                f"Next steps:\n"
                f"  1. Do NOT retry — you don't have access.\n"
                f"  2. Call error_handling__report_to_user and tell the user:\n"
                f"     - What you were trying to do\n"
                f"     - What access/credential is needed\n"
                f"     - Ask if they can provide it or suggest an alternative."
            )

    # ── Category 2: Selector / resource not found (check BEFORE env errors) ───
    # These contain "not found" which overlaps with env patterns, so check first.
    selector_indicators = [
        "selector", "css selector", "element", "no element",
        "404", "page not found",
    ]
    # "not found" / "does not exist" / "doesn't exist" only count as selector errors
    # when combined with selector-related context
    has_selector_context = any(s in error_lower for s in selector_indicators)
    has_not_found = any(s in error_lower for s in ["not found", "doesn't exist", "does not exist"])

    if has_selector_context or (has_not_found and "browser" in failed_tool.lower()):
        return (
            f"[error_handling] Category: RESOURCE_NOT_FOUND\n"
            f"Fixable: YES (try a different identifier or approach)\n"
            f"What happened: The target element, URL, file, or resource doesn't exist "
            f"or the identifier is wrong.\n"
            f"Failed tool: {failed_tool}\n"
            f"Next steps:\n"
            f"  1. If browsing: call the tool that lists available elements/selectors "
            f"(e.g., browser_control__get_selectors()), then use an exact one from the result.\n"
            f"  2. If a URL/file: verify the path, try the parent directory or homepage.\n"
            f"  3. If you have no way to discover the correct identifier, "
            f"call error_handling__report_to_user and tell the user what you were looking for."
        )

    # ── Category 3: Timeout / slow response ──────────────────────────────────
    timeout_patterns = [
        "timeout", "timed out", "took too long",
    ]
    for pat in timeout_patterns:
        if pat in error_lower:
            return (
                f"[error_handling] Category: TIMEOUT_ERROR\n"
                f"Fixable: SOMETIMES (retry once, or try a lighter approach)\n"
                f"What happened: The operation was too slow or unresponsive.\n"
                f"Failed tool: {failed_tool}\n"
                f"Next steps:\n"
                f"  1. If the tool supports a longer timeout or a 'wait' step, try that once.\n"
                f"  2. Otherwise, try a different tool or lighter approach (e.g., get text instead of screenshot).\n"
                f"  3. If it keeps failing, the service may be down — call error_handling__report_to_user."
            )

    # ── Category 4: Environment / dependency errors (check LAST, broad) ──────
    # These are broad patterns — checked after more specific categories above.
    env_patterns = [
        "not installed", "no such file", "command not found",
        "executable", "no browser",
    ]
    for pat in env_patterns:
        if pat in error_lower:
            return (
                f"[error_handling] Category: ENVIRONMENT_ERROR\n"
                f"Fixable: NO (requires user action)\n"
                f"What happened: A required dependency, file, or environment is missing.\n"
                f"Failed tool: {failed_tool}\n"
                f"Next steps:\n"
                f"  1. Do NOT retry the same tool — it will fail the same way.\n"
                f"  2. If the tool name suggests what's missing (e.g., 'Playwright'), "
                f"call error_handling__report_to_user with:\n"
                f"     - error_summary: the exact error message\n"
                f"     - impact: what the user's request cannot be fulfilled\n"
                f"     The report will extract the fix command from the error message.\n"
                f"  3. If there's a completely different tool/approach that doesn't "
                f"depend on the missing thing, try that instead.\n"
                f"  4. Otherwise, tell the user honestly — do NOT fabricate an answer."
            )

    # ── Default: Unknown error ───────────────────────────────────────────────
    return (
        f"[error_handling] Category: UNKNOWN_ERROR\n"
        f"Fixable: UNKNOWN (try a different approach first)\n"
        f"Error: {error_message}\n"
        f"Failed tool: {failed_tool}\n"
        f"Next steps:\n"
        f"  1. Try a different tool or approach to achieve the same goal.\n"
        f"  2. Check available skills with Skill(skill_name='...').\n"
        f"  3. If nothing else works, call error_handling__report_to_user and "
        f"tell the user honestly what happened.\n"
        f"  4. NEVER fabricate an answer after a tool failure."
    )


def retry_with_fallback(original_tool: str, original_args: str = "", error_message: str = "") -> str:
    """Suggest a different strategy when the original tool fails.

    Rather than hardcoding specific tool fallbacks, this provides general
    fallback principles based on the type of tool that failed.

    Args:
        original_tool: The tool that failed (e.g., 'browser_control__navigate').
        original_args: The arguments passed to the failed tool.
        error_message: The error message from the failed tool.

    Returns:
        General fallback principles based on the tool category.
    """
    tool_lower = original_tool.lower()

    # Browser tools — try simpler browser operations, or give up
    if "browser_control" in tool_lower:
        browser_ops = [
            "navigate", "click", "type", "screenshot", "get_content",
            "get_selectors", "scroll", "wait_for",
        ]
        op = ""
        for o in browser_ops:
            if o in tool_lower:
                op = o
                break

        if op in ("navigate", "click", "type", "wait_for"):
            return (
                f"[error_handling] Fallback for browser operation '{op}':\n"
                f"  - If the browser IS available: try a simpler operation first "
                f"(e.g., navigate to a simple URL, or call get_selectors to see what's on page).\n"
                f"  - If the browser is NOT available (environment error): "
                f"no browser operation will work. Give up on browsing and either:\n"
                f"    1. Use a non-browser skill (memory_recall, etc.) if applicable.\n"
                f"    2. Tell the user honestly."
            )
        elif op == "screenshot":
            return (
                f"[error_handling] Fallback for screenshot:\n"
                f"  - Try get_content('body') to extract text instead.\n"
                f"  - If screenshot fails for all pages, the browser may be misconfigured."
            )
        else:
            return (
                f"[error_handling] Fallback for browser operation:\n"
                f"  - Try get_selectors() to see what's available on the page.\n"
                f"  - If the browser isn't available at all, no browser tool will work."
            )

    # Non-browser tools — general principles
    return (
        f"[error_handling] General fallback principles:\n"
        f"  1. Can the same goal be achieved with a different tool or skill? Check available skills.\n"
        f"  2. Is there a simpler version of the request that might work? (e.g., text instead of image)\n"
        f"  3. If nothing else works, call error_handling__report_to_user and tell the user honestly."
    )


def report_to_user(error_summary: str, impact: str = "") -> str:
    """Generate an honest message to tell the user about a tool failure.

    A good failure report includes three things:
    1. What went wrong (specific error)
    2. What it means for the user's request
    3. What the user can do about it (fix command, alternative, or honest admission)

    Args:
        error_summary: What went wrong. Include the exact error message from the tool.
        impact: How this affects the user's original request.

    Returns:
        A [FINAL_ANSWER] formatted message for the user.
    """
    impact_part = f"\n\nThis means: {impact}" if impact else ""

    # Try to extract a fix command or suggestion from the error message
    # Error messages often contain helpful text like "Run: pip install ..."
    fix_part = ""
    error_lower = error_summary.lower()

    # Extract actionable suggestions: "Run: ...", "Try: ...", "Install: ..."
    for keyword in ["run:", "try:", "install:", "please run", "please install"]:
        idx = error_lower.find(keyword)
        if idx != -1:
            suggestion = error_summary[idx:].strip()
            fix_part = f"\n\nSuggested fix: {suggestion}"
            break

    # If no explicit fix command found, give a general hint
    if not fix_part:
        if "not installed" in error_lower or "no such file" in error_lower or "command not found" in error_lower:
            fix_part = f"\n\nPlease check that all required dependencies and tools are set up correctly."
        elif "access denied" in error_lower or "unauthorized" in error_lower:
            fix_part = f"\n\nPlease check that you have the necessary credentials or permissions."
        elif "timeout" in error_lower:
            fix_part = f"\n\nThe service may be slow or unavailable. Try again later."

    message = (
        f"I encountered a problem: {error_summary}.{impact_part}{fix_part}\n"
        f"\n\nI cannot complete your request with the currently available tools."
    )
    return f"[FINAL_ANSWER]{message}"
