---
name: error_handling
description: >
  When ANY tool fails, use this skill to decide: retry, try a different approach,
  or honestly tell the user. Teaches the model how to classify errors by recoverability
  (can it be fixed?) and how to report failures to the user with the right information
  (what went wrong, what it means for their request, what they can do about it).
version: 1.1.0
---

# Error Handling

A framework for recovering from tool failures instead of silently fabricating answers.

## Core Principle

**A tool failure is NOT a reason to make up an answer.** It's a signal to:
1. Understand *why* it failed
2. Decide *if it can be fixed* (retry? different approach?)
3. If not fixable, *tell the user honestly* with the right information

## Decision Tree for Every Tool Failure

When any tool returns an error, follow this decision process:

```
Did a tool fail?
  │
  ├─ Step 1: Understand the error
  │   → Call error_handling__analyze_error(error_message, failed_tool)
  │   → This tells you: WHAT went wrong, and IS IT FIXABLE?
  │
  ├─ Step 2: Is it fixable?
  │   │
  │   ├─ YES (e.g., wrong selector, slow page, temporary issue)
  │   │   → Follow the recovery steps from analyze_error
  │   │   → Try the suggested approach ONCE
  │   │   → If it also fails → go back to Step 1 with the new error
  │   │
  │   └─ NO (e.g., missing dependency, no access, feature doesn't exist)
  │       → There is no way to complete the request
  │       → Go to Step 3
  │
  └─ Step 3: Tell the user honestly
      → Call error_handling__report_to_user(error_summary, impact)
      → Say: WHAT failed, WHAT it means for their request, WHAT they can do
      → Do NOT fabricate an answer. Do NOT pretend it worked.
```

## How to Report a Failure to the User

When you must tell the user that their request cannot be completed, include **three things**:

1. **What went wrong** — the specific error, not a vague "something failed"
2. **What it means for their request** — why you can't do what they asked
3. **What they can do about it** — a fix command, an alternative, or honest admission

**Good example:**
> "I tried to browse the web to check today's date, but the browser tool failed with:
> 'Playwright not installed'. I cannot access real-time information without the browser.
> To fix this, run: `pip install playwright && playwright install chromium`."

**Bad example (vague, no fix):**
> "I can't browse the web right now."

**Bad example (fabrication):**
> "Today is October 27, 2023." ← Just because a tool failed doesn't mean you should guess.

## What NOT to Do

- **Skip error analysis** → Seeing "Error: ..." and then making up an answer is the #1 failure mode.
- **Retry blindly** → If the error won't change (missing dependency, no permission), retrying wastes steps.
- **Hide behind vague language** → "Something went wrong" is less helpful than "The browser isn't installed."
- **Call daily_chat for real-time info** → If browser_control can't access the web, daily_chat can't either.
- **Give up after one error** → Some errors ARE fixable (wrong selector, slow page). Analyze first, then decide.

## Tool Usage

- `analyze_error(error_message, failed_tool)`: Classifies the error and tells you whether it's fixable, with specific recovery steps if it is.
- `retry_with_fallback(original_tool, original_args, error_message)`: Suggests a different tool or approach that might work.
- `report_to_user(error_summary, impact)`: Generates an honest message with what failed, what it means, and what the user can do.
