"""
Global Navigation Skill - Tools

Wraps the FloorNavigator from the navigation project to provide
global trajectory planning from semantic indoor maps.

Data files (point cloud, scene graph, rooms) are read from the original
navigation project at /workspace/wxd/Agent-Skill/agent/my_file/reconstruction_global_trajectory/.
"""

import json
import pickle
import sys
import os
import re
import threading
import numpy as np
from pathlib import Path
from typing import Optional

# ── Path configuration ──────────────────────────────────────────────
# Navigation source code lives in this skill's src/ directory.
# We add the skill dir (parent of src/) to sys.path so that `src` is
# importable as a proper Python package (with relative imports working).
_skill_dir = Path(__file__).parent.resolve()
if str(_skill_dir) not in sys.path:
    sys.path.insert(0, str(_skill_dir))

# Lazy import helper
def _import_navigator_helpers():
    """Import navigator utilities after sys.path is set up."""
    from src.navigator import resample_path as _rp
    return _rp

# Data directory — self-contained within the skill's src/
_DATA_DIR = _skill_dir / "src" / "data"

# Poses file locations (searched in order)
_POSES_CANDIDATES = [
    _DATA_DIR / "poses.txt",
    Path("/workspace/wxd/VLN/datasets/icra_ic7f/poses.txt"),
    Path("/workspace/wxd/VLN/datasets/icra_ic4f/poses.txt"),
]


# ── Pose extraction helpers (from navigate.py) ──────────────────────
def _pose_to_world_position(tx, ty, tz, qx, qy, qz, qw):
    """Convert a TUM-format pose to world coordinates."""
    import numpy as np
    from scipy.spatial.transform import Rotation as R

    quat = [qx, qy, qz, qw]
    rot_matrix = R.from_quat(quat).as_matrix()

    T_w2c = np.eye(4)
    T_w2c[:3, :3] = rot_matrix
    T_w2c[:3, 3] = [tx, ty, tz]

    T_c2w = np.linalg.inv(T_w2c)

    T_SWITCH_AXIS = np.array([
        [1, 0, 0, 0],
        [0, 0, 1, 0],
        [0, -1, 0, 0],
        [0, 0, 0, 1]
    ], dtype=np.float64)
    T_c2w = T_SWITCH_AXIS @ T_c2w

    return T_c2w[:3, 3]


def _find_poses_file():
    """Find the poses.txt file."""
    for p in _POSES_CANDIDATES:
        if p.exists():
            return p
    return _POSES_CANDIDATES[0]


def _get_start_from_frame(poses_file, frame_number=1):
    """Extract camera pose from frame N as start position."""
    poses_file = Path(poses_file)
    if not poses_file.exists():
        return None

    with open(poses_file, "r") as f:
        lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]

    if frame_number < 1 or frame_number > len(lines):
        return None

    parts = lines[frame_number - 1].split()
    if len(parts) >= 8:
        tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
        qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])
        pos = _pose_to_world_position(tx, ty, tz, qx, qy, qz, qw)
        return pos.tolist()

    return None


def _get_start_from_timestamp(poses_file, timestamp):
    """Extract camera pose by timestamp as start position."""
    poses_file = Path(poses_file)
    if not poses_file.exists():
        return None

    with open(poses_file, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if parts[0] == timestamp and len(parts) >= 8:
                tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
                qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])
                pos = _pose_to_world_position(tx, ty, tz, qx, qy, qz, qw)
                return pos.tolist()

    return None


# ── Data loading ────────────────────────────────────────────────────
def _get_rooms() -> list:
    """Load room data from scene_graph.json (primary source)."""
    sg_path = _DATA_DIR / "scene_graph.json"
    if sg_path.exists():
        with open(sg_path, "r") as f:
            rooms = json.load(f).get("rooms", [])
            if rooms:
                return rooms
    return []


def _get_default_start() -> list:
    """Get default start position from first frame pose, or fallback to origin."""
    poses_file = _find_poses_file()
    start = _get_start_from_frame(poses_file, frame_number=1)
    if start:
        print(f"  [global_navigation] Start from first frame: ({start[0]:.2f}, {start[1]:.2f}, {start[2]:.2f})")
        return start
    return [0.0, 0.0, 0.0]


# ── Navigator singleton ─────────────────────────────────────────────
# The navigator is expensive to initialize (loads 2.5M point cloud,
# builds grid map). Cache it after first creation.
_navigator_cache: dict = {}  # (use_cost_map,) → FloorNavigator


def _get_navigator(use_cost_map: bool = True):
    """Get or create the FloorNavigator singleton."""
    key = (use_cost_map,)
    if key not in _navigator_cache:
        from src.navigator import FloorNavigator
        _navigator_cache[key] = FloorNavigator(
            global_pcd_path=str(_DATA_DIR / "global/global_pointcloud.ply"),
            resolution=0.05,
            use_cost_map=use_cost_map,
            cost_sigma=0.5,
            cost_weight=5.0,
        )
    return _navigator_cache[key]


# ── Skill tools ─────────────────────────────────────────────────────

class _NavigationStatusDisplay:
    """Show navigation progress as sequential status lines."""

    def __init__(self):
        self._last_step = ""

    def update(self, step: str):
        """Print a pending status line."""
        if not step or step == self._last_step:
            return
        self._last_step = step
        import sys
        from utils.styled_output import Colors
        frame = f"{Colors.BRIGHT_CYAN}⏳{Colors.RESET}"
        clean = re.sub(r'\033\[[0-9;]*m', '', step)
        colored_step = f"{Colors.DIM}{clean}{Colors.RESET}"
        sys.stdout.write(f"\r  {frame} {colored_step}\033[K\n")
        sys.stdout.flush()

    def done(self, step: str = ""):
        """Mark current step as complete."""
        import sys
        from utils.styled_output import Colors
        if step:
            self._last_step = step
            clean = re.sub(r'\033\[[0-9;]*m', '', step)
            colored_step = f"{Colors.DIM}{clean}{Colors.RESET}"
            checkmark = f"{Colors.BRIGHT_GREEN}✓{Colors.RESET}"
            sys.stdout.write(f"\r  {checkmark} {colored_step}\033[K\n")
            sys.stdout.flush()

    def fail(self, step: str = ""):
        """Mark current step as failed."""
        import sys
        from utils.styled_output import Colors
        if step:
            self._last_step = step
            clean = re.sub(r'\033\[[0-9;]*m', '', step)
            colored_step = f"{Colors.BRIGHT_RED}{clean}{Colors.RESET}"
            xmark = f"{Colors.BRIGHT_RED}✗{Colors.RESET}"
            sys.stdout.write(f"\r  {xmark} {colored_step}\033[K\n")
            sys.stdout.flush()

    def start(self):
        """No-op — replaced background thread with direct line output."""
        pass

    def stop(self):
        """No-op — no background thread to stop."""
        pass


def plan_navigation(target: str, start: str = None) -> str:
    """Plan a global navigation trajectory to a target.

    Args:
        target: Target object name ("chair_0"), coordinates ("1.5,0,3.2"),
                or fuzzy intent ("帮我找个能坐的地方")
        start: Optional start position "x,y,z" (default: first frame camera pose)

    Returns:
        Navigation result with path summary, distance, and gateway sequence.
        On failure, returns error message with diagnostic suggestions.
    """
    import io as _io
    from contextlib import redirect_stdout as _redirect_stdout

    status = _NavigationStatusDisplay()
    status.start()

    # Suppress all navigator verbose output (except our callback)
    with _redirect_stdout(_io.StringIO()):
        navigator = _get_navigator(use_cost_map=True)
        rooms = _get_rooms()

        # Resolve start
        if start:
            try:
                start_pos = [float(x) for x in start.split(",")]
                assert len(start_pos) == 3
            except (ValueError, AssertionError):
                status.stop()
                return "[Error] Invalid start format. Use 'x,y,z' (e.g., '0,0,0')"
        else:
            start_pos = _get_default_start()

        # Step 1: Find target — direct lookup first, then fuzzy intent via VLM
        status.update("正在检索目标: " + target)
        goal_position = navigator.find_object_location(target)
        resolved_target_name = target

        # Direct lookup failed — try fuzzy intent matching via IntentMatcher
        if goal_position is None:
            status.update("正在解析意图: " + target)
            from src.intent_matcher import IntentMatcher, MatchResult

            sg_path = _DATA_DIR / "scene_graph.json"
            if sg_path.exists():
                with _redirect_stdout(_io.StringIO()):
                    matcher = IntentMatcher(str(sg_path))
                    match_result: MatchResult = matcher.match(
                        target,
                        start_position=start_pos,
                        navigator=navigator,
                        rooms=rooms,
                    )
                if match_result and match_result.object_name:
                    resolved_target_name = match_result.object_name
                    status.update(f"意图匹配: {target} → {resolved_target_name}")
                    goal_position = navigator.find_object_location(resolved_target_name)

    # Navigator output suppressed — handle result outside the redirect block
    if goal_position is None:
        status.fail("未找到目标: " + target)
        status.stop()
        suggestions = _build_navigation_suggestions(target, navigator, rooms)
        return f"[Error] 找不到目标物体\n{suggestions}"

    status.done("目标位置确定: ({:.1f}, {:.1f}, {:.1f})".format(*goal_position))

    # Step 2-5: Delegate to navigator.plan() with status callback
    status.update("正在规划轨迹...")

    def _cb(msg):
        status.update(msg)

    with _redirect_stdout(_io.StringIO()):
        # Use the resolved target name (e.g., "chair_0") instead of fuzzy intent
        result = navigator.plan(start_pos, resolved_target_name, rooms, status_callback=_cb)

    if not result.get('success'):
        status.fail("规划失败: " + result.get('error', 'unknown'))
        status.stop()
        suggestions = _build_navigation_suggestions(target, navigator, rooms)
        return f"[Error] 路径规划失败: {result.get('error')}\n{suggestions}"

    status.done("导航完成: {:.1f}m, {} 个路径点".format(
        result['total_distance'], result['num_path_points']))
    status.stop()

    # Format summary
    s = start_pos
    g = goal_position
    summary = (
        f"Navigation planned successfully\n"
        f"  Start: ({s[0]:.1f}, {s[1]:.1f}, {s[2]:.1f})\n"
        f"  Goal:  ({g[0]:.1f}, {g[1]:.1f}, {g[2]:.1f})"
    )
    if resolved_target_name != target:
        summary += f"\n  Intent: '{target}' → {resolved_target_name}"
    summary += (
        f"\n  Distance: {result['total_distance']:.1f}m\n"
        f"  Path points: {result['num_path_points']} (resampled: {result['num_path_points_resampled']})\n"
    )

    gw = result.get('gateway_sequence', [])
    if gw:
        summary += f"  Route: {' → '.join(gw)}\n"

    return f"[global_navigation] {summary}"


def _build_navigation_suggestions(query: str, navigator, rooms: list) -> str:
    """Build concise diagnostic info when navigation fails.

    Kept intentionally short to avoid context bloat in ReAct loop.
    """
    lines = ["\nDiagnostic info:"]

    # 1. Available rooms — compact format, limited to 5 rooms
    if rooms:
        room_parts = []
        for room in rooms[:5]:
            room_id = room.get('id', '?')
            room_objs = [o for o in navigator.objects if o.get('room_id') == room_id]
            room_cats = sorted(set(o.get('category', '') for o in room_objs
                                   if o.get('category', '') not in ('floor', 'door', 'wall', 'person')))
            cat_summary = ', '.join(room_cats[:4])
            room_parts.append(f"Room {room_id}({cat_summary or 'empty'})")
        lines.append(f"  Rooms: {'; '.join(room_parts)}")
        if len(rooms) > 5:
            lines.append(f"  ... +{len(rooms)-5} more rooms (use list_rooms() to see all)")

    # 2. Similar object names — limited to 3
    if navigator.objects:
        query_lower = query.lower()
        similar = []
        for obj in navigator.objects:
            name = obj.get('name', '')
            cat = obj.get('category', '')
            if (query_lower in name.lower() or query_lower in cat.lower()):
                similar.append(f"{name}[{cat}]")
        if similar:
            lines.append(f"  Similar objects: {', '.join(similar[:3])}")
            if len(similar) > 3:
                lines.append(f"  ... +{len(similar)-3} more (use list_objects() to see all)")

    # 3. Top categories — limited to 8
    if navigator.objects:
        cats = {}
        for obj in navigator.objects:
            cat = obj.get('category', 'unknown')
            cats[cat] = cats.get(cat, 0) + 1
        top_cats = sorted(cats.items(), key=lambda x: -x[1])[:8]
        lines.append(f"  Top categories: {', '.join(f'{c}({n})' for c, n in top_cats)}")

    # 4. Recovery hint
    lines.append("  Hint: use list_rooms() for room IDs, list_objects(category) for object names")

    return "\n".join(lines)


def list_rooms() -> str:
    """List all rooms in the scene graph with their key objects.

    This is the PRIMARY way to discover what rooms/spaces exist in the environment.
    Use this when navigation fails with '找不到目标物体' to find the correct room name.

    Returns:
        Room list with IDs, centers, and key object categories in each room.
    """
    import io as _io
    from contextlib import redirect_stdout as _redirect_stdout

    with _redirect_stdout(_io.StringIO()):
        navigator = _get_navigator(use_cost_map=False)
    rooms = _get_rooms()

    if not rooms:
        return "[global_navigation] No rooms found in scene graph"

    lines = [f"Rooms in scene ({len(rooms)}):"]
    for room in rooms:
        room_id = room.get('id', '?')
        center = room.get('center', [0, 0, 0])
        area = room.get('area', 0)

        # Find objects in this room
        room_objs = [o for o in navigator.objects if o.get('room_id') == room_id]
        room_cats = {}
        for o in room_objs:
            cat = o.get('category', 'unknown')
            if cat not in ('floor', 'door', 'wall', 'person'):
                room_cats[cat] = room_cats.get(cat, 0) + 1

        cat_summary = ', '.join(f"{c}({n})" for c, n in sorted(room_cats.items(), key=lambda x: -x[1])[:10])
        if len(room_cats) > 10:
            cat_summary += f" +{len(room_cats)-10} more"

        lines.append(
            f"  Room {room_id}: center=({center[0]:.1f}, {center[1]:.1f}, {center[2]:.1f}), "
            f"area={area:.0f}m²"
        )
        if cat_summary:
            lines.append(f"    Objects: {cat_summary}")
        else:
            lines.append(f"    Objects: (none)")

    return "\n".join(lines)


def list_objects(category: str = None) -> str:
    """List available objects in the scene, optionally filtered by category."""
    import io as _io
    from contextlib import redirect_stdout as _redirect_stdout

    with _redirect_stdout(_io.StringIO()):
        navigator = _get_navigator(use_cost_map=False)

    if not navigator.objects:
        return "[global_navigation] No objects found in scene graph"

    objects = navigator.objects
    if category:
        objects = [o for o in objects if o.get("category", "").lower() == category.lower()]

    if not objects:
        return f"[global_navigation] No objects of category '{category}'"

    lines = [f"Scene objects ({len(objects)} found):"]
    max_show = 20  # limit to avoid context bloat
    for obj in objects[:max_show]:
        c = obj.get("center", [0, 0, 0])
        room = obj.get("room_id", "?")
        lines.append(
            f"  {obj['name']:25s} [{obj['category']:15s}] "
            f"({c[0]:.1f}, {c[1]:.1f}, {c[2]:.1f}) room={room}"
        )
    if len(objects) > max_show:
        lines.append(f"  ... and {len(objects)-max_show} more (use plan_navigation() with a specific name)")

    return "\n".join(lines)


def get_scene_summary() -> str:
    """Get a high-level summary of the navigable environment."""
    import io as _io
    import numpy as np
    from contextlib import redirect_stdout as _redirect_stdout

    with _redirect_stdout(_io.StringIO()):
        navigator = _get_navigator(use_cost_map=False)

    gm = navigator.grid_map
    summary = [
        "Scene summary:",
        f"  Grid map: {gm.width}x{gm.height} (resolution={gm.resolution}m)",
        f"  World range: X[{gm.x_min:.1f}, {gm.x_max:.1f}], Z[{gm.z_min:.1f}, {gm.z_max:.1f}]",
    ]

    grid = gm.get_grid()
    summary.append(
        f"  Walkable: {int(np.sum(grid == 1)):,}, "
        f"Obstacles: {int(np.sum(grid == 100)):,}, "
        f"Unknown: {int(np.sum(grid == 0)):,}"
    )

    if navigator.gateways:
        gw_lines = [f"  Gateways ({len(navigator.gateways)}):"]
        for gw in navigator.gateways:
            gw_lines.append(
                f"    GW{gw.id}: Room {gw.room_a} ↔ Room {gw.room_b} "
                f"@ ({gw.position[0]:.1f}, {gw.position[1]:.1f}), width={gw.width:.2f}m"
            )
        summary.extend(gw_lines)

    if navigator.objects:
        cats = {}
        for obj in navigator.objects:
            cat = obj.get("category", "unknown")
            cats[cat] = cats.get(cat, 0) + 1
        cat_str = ", ".join(f"{k}({v})" for k, v in sorted(cats.items()))
        summary.append(f"  Objects: {cat_str}")

    return "\n".join(summary)


def save_path(name: str, target: str, start: str = None) -> str:
    """Plan navigation and save the path to a JSON file.

    Args:
        name: Output filename (without extension)
        target: Target (same as plan_navigation — supports fuzzy intents)
        start: Optional start position "x,y,z"

    Returns:
        Confirmation with file path and path summary
    """
    import io as _io
    from contextlib import redirect_stdout as _redirect_stdout

    status = _NavigationStatusDisplay()
    status.start()

    with _redirect_stdout(_io.StringIO()):
        navigator = _get_navigator(use_cost_map=True)
        rooms = _get_rooms()

        start_pos = _get_default_start()
        if start:
            try:
                start_pos = [float(x) for x in start.split(",")]
            except (ValueError, AssertionError):
                return "[Error] Invalid start format. Use 'x,y,z'"

        # Resolve fuzzy intent if direct lookup fails
        goal_position = navigator.find_object_location(target)
        resolved_target_name = target

        if goal_position is None:
            status.update("正在解析意图: " + target)
            from src.intent_matcher import IntentMatcher, MatchResult

            sg_path = _DATA_DIR / "scene_graph.json"
            if sg_path.exists():
                with _redirect_stdout(_io.StringIO()):
                    matcher = IntentMatcher(str(sg_path))
                    match_result: MatchResult = matcher.match(
                        target, start_position=start_pos, navigator=navigator, rooms=rooms,
                    )
                if match_result and match_result.object_name:
                    resolved_target_name = match_result.object_name
                    status.update(f"意图匹配: {target} → {resolved_target_name}")
                    goal_position = navigator.find_object_location(resolved_target_name)

        if goal_position is None:
            status.fail("未找到目标: " + target)
            status.stop()
            return f"[Error] 找不到目标物体: {target}"

        status.done("目标位置确定: ({:.1f}, {:.1f}, {:.1f})".format(*goal_position))
        status.update("正在规划轨迹...")

        def _cb(msg):
            status.update(msg)

        result = navigator.plan(start_pos, resolved_target_name, rooms=rooms, status_callback=_cb)

    if not result.get("success"):
        status.fail("规划失败")
        status.stop()
        return f"[Error] Path planning failed: {result.get('error')}"

    status.done("导航完成: {:.1f}m".format(result['total_distance']))
    status.stop()

    # Save to skill's own paths directory
    paths_dir = _skill_dir / "paths"
    paths_dir.mkdir(parents=True, exist_ok=True)
    output_path = paths_dir / f"{name}.json"

    with open(output_path, "w") as f:
        json.dump(result, f, indent=2, default=str)

    intent_note = f"\n  Intent: '{target}' → {resolved_target_name}" if resolved_target_name != target else ""
    return (
        f"Path saved to {output_path}\n"
        f"  Distance: {result['total_distance']:.1f}m\n"
        f"  Points: {result['num_path_points_resampled']}"
        f"{intent_note}"
    )
