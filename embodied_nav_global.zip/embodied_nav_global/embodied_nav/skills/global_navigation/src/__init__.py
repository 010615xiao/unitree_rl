from .grid_map import GridMap, create_grid_map_from_pointcloud
from .path_planner import AStarPlanner, rdp_simplify
from .navigator import FloorNavigator, resample_path
from .export_ply import export_navigation_results
from .cost_map import CostMap, create_cost_map_from_grid
from .gateway_detector import GatewayDetector, Gateway, run_gateway_detection
from .intent_matcher import IntentMatcher, SceneInventory, MatchResult

__all__ = [
    'GridMap',
    'create_grid_map_from_pointcloud',
    'AStarPlanner',
    'rdp_simplify',
    'FloorNavigator',
    'resample_path',
    'export_navigation_results',
    'CostMap',
    'create_cost_map_from_grid',
    'GatewayDetector',
    'Gateway',
    'run_gateway_detection',
    'detect_gateways_from_trajectory',
    'IntentMatcher',
    'SceneInventory',
    'MatchResult',
]


def detect_gateways_from_trajectory(*args, **kwargs):
    """便捷函数: 从轨迹检测 gateway"""
    import numpy as np
    from .gateway_detector import GatewayDetector
    from .navigator import FloorNavigator

    # 这是一个需要 Navigator 实例的方法
    # 使用示例:
    # navigator = FloorNavigator(...)
    # navigator.detect_gateways_from_trajectory(trajectory, rooms)
    pass
