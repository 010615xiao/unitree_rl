"""
调用 Trajectory 2D API 为每张图片生成轨迹并绘制

流程:
  1. 加载投影后的图片 (带 floor mask 筛选后的轨迹点)
  2. 对每张图片，将该轨迹点的像素坐标作为目标点调用 /api/trajectory_pixel
  3. 将 API 返回的轨迹叠加到原图上
  4. 输出原图 + 轨迹可视化

用法:
  # 基本用法
  python draw_trajectory_on_images.py \
    --images paths/我想打印资料_images_projected \
    --projected-images paths/我想打印资料_images_projected

  # 自定义 API 地址
  python draw_trajectory_on_images.py \
    --images paths/我想打印资料_images_projected \
    --projected-images paths/我想打印资料_images_projected \
    --api-url http://localhost:9000
"""

import argparse
import base64
import cv2
import numpy as np
import requests
from pathlib import Path


def call_trajectory_pixel_api(image_path, pixel_x, pixel_y, api_url):
    """
    调用 /api/trajectory_pixel 生成从起点到目标点的轨迹

    Returns:
        dict with keys:
          success, message, trajectory, num_points, start_point,
          input_pixel, rendered_views, error
    """
    try:
        resp = requests.post(
            f"{api_url}/api/trajectory_pixel",
            files={"image": open(image_path, "rb")},
            data={
                "pixel_x": str(int(pixel_x)),
                "pixel_y": str(int(pixel_y)),
                "render_all_views": "false",
                "return_rendered_views": "true",
                "save_zip": "false",
                "save_trajectory_3d": "false",
            },
            timeout=120,
        )
        result = resp.json()

        # API 返回 500 时 error 在 detail 字段
        if resp.status_code != 200:
            return {
                "success": False,
                "message": result.get("detail", f"HTTP {resp.status_code}"),
                "error": result.get("detail", ""),
            }

        return result
    except requests.exceptions.Timeout:
        return {"success": False, "message": "API 超时 (120s)", "error": "timeout"}
    except Exception as e:
        return {"success": False, "message": str(e), "error": str(e)}


def draw_trajectory_on_image(image, api_result, traj_point_uv):
    """
    在原图上绘制 API 返回的轨迹 + 当前帧的投影点

    - 轨迹: 黄色线 + 小圆点
    - 投影点: 红色大圆点 (已在原图上)
    """
    result = image.copy()

    if not api_result.get("success"):
        # 绘制失败信息
        cv2.putText(result, f"FAIL: {api_result.get('message', 'unknown')[:60]}",
                   (10, result.shape[0] - 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
        return result

    trajectory = api_result.get("trajectory", [])
    if len(trajectory) < 2:
        cv2.putText(result, f"No trajectory ({len(trajectory)} pts)",
                   (10, result.shape[0] - 20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        return result

    # 绘制轨迹线 (黄色, 2px)
    pts = np.array([(int(p["x"]), int(p["y"])) for p in trajectory], dtype=np.int32)
    cv2.polylines(result, [pts], False, (0, 255, 255), 2)

    # 绘制轨迹点 (黄色小圆)
    for i, p in enumerate(trajectory):
        px, py = int(p["x"]), int(p["y"])
        cv2.circle(result, (px, py), 3, (0, 255, 255), -1)
        # 起点和终点标记
        if i == 0:
            cv2.circle(result, (px, py), 8, (0, 255, 0), 2)  # 起点: 绿色圈
        elif i == len(trajectory) - 1:
            cv2.circle(result, (px, py), 8, (255, 0, 0), 2)  # 终点: 蓝色圈

    # 绘制目标点标记 (当前投影点位置, 青色十字)
    if traj_point_uv is not None:
        tx, ty = int(traj_point_uv[0]), int(traj_point_uv[1])
        cv2.drawMarker(result, (tx, ty), (255, 255, 0), cv2.MARKER_CROSS, 15, 2)

    return result


def main():
    parser = argparse.ArgumentParser(description="为投影图片生成并绘制导航轨迹")
    parser.add_argument("--images", type=str, required=True,
                       help="原始图片目录 (用于调用 API)")
    parser.add_argument("--projected-images", type=str, required=True,
                       help="已投影的图片目录 (带 floor mask 筛选后的轨迹点)")
    parser.add_argument("--output", type=str, default=None,
                       help="输出目录 (默认: <projected-images>_with_trajectory/)")
    parser.add_argument("--api-url", type=str, default="http://localhost:9000",
                       help="Trajectory 2D API 地址")
    parser.add_argument("--skip-failed", action="store_true",
                       help="跳过失败的图片 (默认失败时也保存原图)")
    args = parser.parse_args()

    images_dir = Path(args.images)
    projected_dir = Path(args.projected_images)

    if not images_dir.exists():
        print(f"错误: 原图目录不存在: {images_dir}")
        return
    if not projected_dir.exists():
        print(f"错误: 投影图目录不存在: {projected_dir}")
        return

    # 输出目录
    if args.output:
        output_dir = Path(args.output)
    else:
        output_dir = projected_dir.parent / f"{projected_dir.name}_with_trajectory"
    output_dir.mkdir(parents=True, exist_ok=True)

    # 查找图片
    img_files = sorted(projected_dir.glob("*.png"))
    if not img_files:
        img_files = sorted(projected_dir.glob("*.jpg"))
    if not img_files:
        print(f"错误: 投影图目录为空: {projected_dir}")
        return

    print(f"找到 {len(img_files)} 张图片")
    print(f"API: {args.api_url}")
    print(f"输出: {output_dir}")

    # 健康检查
    try:
        health = requests.get(f"{args.api_url}/health", timeout=5).json()
        print(f"API 状态: {health}")
    except Exception as e:
        print(f"API 健康检查失败: {e}")
        return

    processed = 0
    success = 0
    failed = 0
    total_traj_points = 0

    for img_file in img_files:
        timestamp = img_file.stem
        original_img = images_dir / img_file.name

        if not original_img.exists():
            print(f"  跳过: {img_file.name} (找不到原图)")
            failed += 1
            continue

        # 读取投影后的图片 (带轨迹点)
        projected_img = cv2.imread(str(img_file))
        if projected_img is None:
            print(f"  跳过: {img_file.name} (读取失败)")
            failed += 1
            continue

        # 读取原图 (用于 API 调用)
        original_img_data = cv2.imread(str(original_img))
        if original_img_data is None:
            print(f"  跳过: {original_img.name} (读取失败)")
            failed += 1
            continue

        # 查找红色轨迹点的中心位置 (从投影后的图片中提取)
        # 红色 BGR=(0,0,255), 找红色像素的中心
        red_channel = projected_img[:, :, 2].astype(np.float32)
        blue_channel = projected_img[:, :, 0].astype(np.float32)
        green_channel = projected_img[:, :, 1].astype(np.float32)

        # 红色区域: R > 200, G < 100, B < 100
        red_mask = (red_channel > 200) & (green_channel < 100) & (blue_channel < 100)
        red_pixels = np.where(red_mask)

        if len(red_pixels[0]) > 0:
            # 计算红色区域的中心 (取平均)
            center_y = float(np.mean(red_pixels[0]))
            center_x = float(np.mean(red_pixels[1]))
            target_pixel = (center_x, center_y)
        else:
            # 没有红色点, 跳过
            print(f"  [{processed+1}/{len(img_files)}] {img_file.name}: 无轨迹点, 跳过")
            # 复制原图
            cv2.imwrite(str(output_dir / img_file.name), projected_img)
            processed += 1
            continue

        print(f"  [{processed+1}/{len(img_files)}] {img_file.name}: target=({target_pixel[0]:.0f}, {target_pixel[1]:.0f})")

        # 调用 API 生成轨迹
        api_result = call_trajectory_pixel_api(
            str(original_img),
            target_pixel[0], target_pixel[1],
            args.api_url
        )

        if api_result.get("success"):
            num_pts = api_result.get("num_points", 0)
            total_traj_points += num_pts
            print(f"    OK: {num_pts} 点, 耗时 {api_result.get('processing_time_seconds', 0):.1f}s")
            success += 1
        else:
            print(f"    FAIL: {api_result.get('message', 'unknown')}")
            failed += 1

        # 绘制
        result = draw_trajectory_on_image(original_img_data, api_result, target_pixel)

        # 添加信息文字
        info_lines = [f"Trajectory: {api_result.get('message', 'failed')[:80]}"]
        if api_result.get("success"):
            info_lines.append(f"  Points: {api_result.get('num_points', 0)}, "
                            f"Time: {api_result.get('processing_time_seconds', 0):.1f}s")
            if api_result.get("start_point"):
                sp = api_result["start_point"]
                info_lines.append(f"  Start: ({sp[0]}, {sp[1]})")

        y_offset = 25
        for line in info_lines:
            cv2.putText(result, line, (10, y_offset),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1)
            y_offset += 18

        cv2.imwrite(str(output_dir / img_file.name), result)
        processed += 1

    print(f"\n完成!")
    print(f"  处理: {processed} 张")
    print(f"  成功: {success} 张")
    print(f"  失败: {failed} 张")
    if success > 0:
        print(f"  平均轨迹点数: {total_traj_points / success:.1f}")
    print(f"  输出: {output_dir}")


if __name__ == "__main__":
    main()
