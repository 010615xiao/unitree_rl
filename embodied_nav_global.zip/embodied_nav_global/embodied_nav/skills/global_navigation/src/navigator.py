#!/usr/bin/env python3
"""
基于房间分割和 Cost Map 的导航器

核心改进:
1. Gateway: 从 watershed 房间分割结果中提取相邻房间边界,不再依赖 VLM door 检测
2. Cost Map: 基于 distance transform 让 A* 倾向走远离障碍物的安全区域
3. 两层规划: 高层房间图 + 微观 A* 路径
"""

import numpy as np
import json
import pickle
import heapq
from pathlib import Path
from typing import List, Dict, Tuple, Optional

from .grid_map import GridMap, create_grid_map_from_pointcloud
from .path_planner import AStarPlanner, rdp_simplify
from .cost_map import CostMap
from .gateway_detector import GatewayDetector, Gateway


def resample_path(path_3d, step_size=0.01):
    """
    沿导航路径按固定步长重采样 (真实 3D 欧氏距离)

    参数:
        path_3d: (N, 3) 原始路径点
        step_size: 采样步长 (米), 默认 0.01m (1cm)

    返回:
        resampled: (M, 3) 重采样后的路径点
    """
    if len(path_3d) < 2:
        return path_3d

    path_3d = np.array(path_3d)

    # 计算累计距离
    distances = np.zeros(len(path_3d))
    for i in range(1, len(path_3d)):
        distances[i] = distances[i - 1] + np.linalg.norm(path_3d[i] - path_3d[i - 1])

    total_length = distances[-1]

    if total_length < 1e-8:
        return path_3d

    # 生成等距采样距离 (包含起点和终点)
    num_samples = int(np.ceil(total_length / step_size)) + 1
    sample_distances = np.linspace(0, total_length, num_samples)

    # 线性插值得到采样点
    resampled = np.zeros((num_samples, 3))
    for i, sd in enumerate(sample_distances):
        idx = np.searchsorted(distances, sd, side='right') - 1
        idx = min(max(idx, 0), len(path_3d) - 2)

        seg_start_dist = distances[idx]
        seg_end_dist = distances[idx + 1]
        seg_length = seg_end_dist - seg_start_dist

        if seg_length > 1e-8:
            t = (sd - seg_start_dist) / seg_length
        else:
            t = 0.0

        resampled[i] = path_3d[idx] + t * (path_3d[idx + 1] - path_3d[idx])

    return resampled.tolist()


class FloorNavigator:
    def __init__(self, global_pcd_path, resolution=0.05, grid_map_path=None,
                 scene_graph_path=None, floor_y_threshold=0.6,
                 use_cost_map=True, cost_sigma=0.5, cost_weight=5.0,
                 complete_boundary_wall=True):
        self.global_pcd_path = Path(global_pcd_path)
        self.resolution = resolution
        self.use_cost_map = use_cost_map
        self.floor_y_threshold = floor_y_threshold  # 保存 floor 检测阈值

        # 加载或生成栅格地图
        if grid_map_path and Path(grid_map_path).exists():
            print(f"加载栅格地图: {grid_map_path}")
            with open(grid_map_path, 'rb') as f:
                grid_data = pickle.load(f)
            self.grid_map = self._reconstruct_gridmap(grid_data)
            self.floor_y = grid_data['floor_y']
        else:
            print("从点云生成栅格地图...")
            sg_path = scene_graph_path or str(self.global_pcd_path.parent.parent / 'scene_graph.json')
            self.grid_map, self.floor_y = create_grid_map_from_pointcloud(
                str(self.global_pcd_path), sg_path,
                resolution, self.floor_y_threshold
            )

            if grid_map_path:
                save_path = Path(grid_map_path)
            else:
                save_path = self.global_pcd_path.parent.parent / 'navigation' / 'grid_map_floor.pkl'
            save_path.parent.mkdir(parents=True, exist_ok=True)
            with open(save_path, 'wb') as f:
                pickle.dump({
                    'grid': self.grid_map.get_grid(),
                    'x_min': self.grid_map.x_min,
                    'z_min': self.grid_map.z_min,
                    'resolution': self.grid_map.resolution,
                    'padding': self.grid_map.padding,
                    'floor_y': self.floor_y,
                    'width': self.grid_map.width,
                    'height': self.grid_map.height,
                    'connected_components': self.grid_map.connected_components,
                    'component_gateways': self.grid_map.component_gateways,
                    'doors': self.grid_map.doors,
                }, f)
            print(f"  栅格数据已保存: {save_path}")

        # 创建 / 加载 Cost Map
        self.cost_map = None
        if self.use_cost_map:
            # 缓存路径: 文件名包含 sigma 和 weight 参数
            nav_dir = self.global_pcd_path.parent.parent / 'navigation'
            cost_map_cache = nav_dir / f'cost_map_s{cost_sigma:.1f}_w{cost_weight:.1f}.pkl'

            if Path(cost_map_cache).exists():
                print(f"\n加载 Cost Map 缓存: {cost_map_cache}")
                import time as _time
                _t0 = _time.time()
                with open(cost_map_cache, 'rb') as f:
                    cm_data = pickle.load(f)
                self.cost_map = CostMap.__new__(CostMap)
                self.cost_map.grid = cm_data['grid']
                self.cost_map.resolution = cm_data['resolution']
                self.cost_map.x_min = cm_data['x_min']
                self.cost_map.z_min = cm_data['z_min']
                self.cost_map.sigma = cm_data['sigma']
                self.cost_map.distance_weight = cm_data['distance_weight']
                self.cost_map.base_cost = cm_data['base_cost']
                self.cost_map.height = cm_data['height']
                self.cost_map.width = cm_data['width']
                self.cost_map.cost_map = cm_data['cost_map']
                self.cost_map.distance_map = cm_data['distance_map']
                _elapsed = _time.time() - _t0
                print(f"  Cost Map 缓存加载: {_elapsed:.3f}s (σ={cost_sigma}m, w={cost_weight})")
            else:
                print(f"\n创建 Cost Map...")
                import time as _time
                _t0 = _time.time()
                self.cost_map = CostMap(
                    grid=self.grid_map.get_grid(),
                    resolution=self.grid_map.resolution,
                    x_min=self.grid_map.x_min,
                    z_min=self.grid_map.z_min,
                    sigma=cost_sigma,
                    distance_weight=cost_weight,
                    base_cost=1.0,
                    complete_boundary_wall=complete_boundary_wall
                )
                _elapsed = _time.time() - _t0
                # 保存到缓存
                nav_dir.mkdir(parents=True, exist_ok=True)
                with open(cost_map_cache, 'wb') as f:
                    pickle.dump({
                        'grid': self.cost_map.grid,
                        'resolution': self.cost_map.resolution,
                        'x_min': self.cost_map.x_min,
                        'z_min': self.cost_map.z_min,
                        'sigma': self.cost_map.sigma,
                        'distance_weight': self.cost_map.distance_weight,
                        'base_cost': self.cost_map.base_cost,
                        'height': self.cost_map.height,
                        'width': self.cost_map.width,
                        'cost_map': self.cost_map.cost_map,
                        'distance_map': self.cost_map.distance_map,
                    }, f)
                print(f"  Cost Map 已缓存: {cost_map_cache} ({_elapsed:.3f}s)")

        # 创建 A* 规划器 (带 cost map)
        self.planner = AStarPlanner(self.grid_map, cost_map=self.cost_map)

        # 加载 scene graph (用于物体位置)
        sg_path = scene_graph_path or str(self.global_pcd_path.parent.parent / 'scene_graph.json')
        if Path(sg_path).exists():
            with open(sg_path, 'r') as f:
                self.scene_graph = json.load(f)
            self.objects = self.scene_graph.get('objects', [])
            self.rooms_data = self.scene_graph.get('rooms', [])
        else:
            self.scene_graph = None
            self.objects = []
            self.rooms_data = []

        # Gateway (初始为空,需要调用 detect_gateways 或 load_gateways)
        self.gateways: List[Gateway] = []
        self.room_adjacency: Dict[Tuple[int, int], List] = {}

        # 加载轨迹平面信息 (用于路径 Y 高度计算)
        plane_info_path = self.global_pcd_path.parent.parent / 'trajectory_plane.json'
        self.trajectory_plane = None
        if Path(plane_info_path).exists():
            with open(plane_info_path, 'r') as f:
                plane_data = json.load(f)
            self.trajectory_plane = {
                'normal': np.array(plane_data['normal']),
                'd': plane_data['d'],
                'centroid': np.array(plane_data['centroid']),
                'inlier_ratio': plane_data.get('inlier_ratio', 0),
                'mean_distance': plane_data.get('mean_distance', 0),
            }
            print(f"\n加载轨迹平面: {plane_info_path}")
            print(f"  法向量: {self.trajectory_plane['normal']}")
            print(f"  内点比例: {self.trajectory_plane['inlier_ratio']:.1f}%")
        else:
            print(f"\n警告: 未找到 trajectory_plane.json，路径 Y 高度将使用固定 floor_y")

        # 自动加载 gateway (如果已存在)
        gateway_json_path = self.global_pcd_path.parent.parent / 'navigation' / 'gateways' / 'gateways.json'
        if not Path(gateway_json_path).exists():
            # 兼容旧路径
            gateway_json_path = self.global_pcd_path.parent.parent / 'navigation' / 'trajectory_gateways' / 'gateways.json'
        if Path(gateway_json_path).exists():
            self.load_gateways_from_json(str(gateway_json_path))

        # Pre-compute room adjacency graph and cKDTree (scene structure is static)
        self._room_graph: Dict[int, List[Tuple[int, Gateway]]] = {}
        self._room_tree = None
        if self.gateways:
            self._build_room_graph_cache()
        if self.rooms_data:
            self._build_room_tree_cache()

    def _build_room_graph_cache(self):
        """Build room adjacency graph once from gateways — cached for all plan calls."""
        graph = {}
        for gw in self.gateways:
            if gw.room_a not in graph:
                graph[gw.room_a] = []
            if gw.room_b not in graph:
                graph[gw.room_b] = []
            graph[gw.room_a].append((gw.room_b, gw))
            graph[gw.room_b].append((gw.room_a, gw))
        self._room_graph = graph

    def _build_room_tree_cache(self):
        """Build cKDTree of room centers once — cached for all lookups."""
        from scipy.spatial import cKDTree
        room_centers = np.array([[r['center'][0], r['center'][2]] for r in self.rooms_data])
        self._room_tree = cKDTree(room_centers)

    def _reconstruct_gridmap(self, grid_data):
        dummy_pts = np.array([[grid_data['x_min'], grid_data['z_min']],
                              [grid_data['x_min'] + 1, grid_data['z_min'] + 1]])
        grid_map = GridMap(dummy_pts, np.array([]), resolution=grid_data['resolution'])
        grid_map.grid = grid_data['grid']
        grid_map.x_min = grid_data['x_min']
        grid_map.z_min = grid_data['z_min']
        grid_map.width = grid_data['width']
        grid_map.height = grid_data['height']
        grid_map.padding = grid_data['padding']
        grid_map.connected_components = grid_data.get('connected_components', {})
        grid_map.component_gateways = grid_data.get('component_gateways', [])
        grid_map.doors = grid_data.get('doors', [])
        grid_map.component_labels = None
        return grid_map

    def load_gateways_from_json(self, gateway_json_path: str):
        """
        从重建流程保存的 gateway JSON 文件加载

        Args:
            gateway_json_path: gateway JSON 文件路径
        """
        import json
        from pathlib import Path

        json_path = Path(gateway_json_path)
        if not json_path.exists():
            print(f"  Gateway 文件不存在: {gateway_json_path}")
            return

        with open(json_path, 'r') as f:
            gw_data = json.load(f)

        gateways_list = gw_data.get('gateways', [])
        self.gateways = []
        self.room_adjacency = {}

        for gw_dict in gateways_list:
            gw = Gateway(
                id=gw_dict['id'],
                room_a=gw_dict['room_a'],
                room_b=gw_dict['room_b'],
                position=np.array(gw_dict['position']),
                position_3d=np.array(gw_dict['position_3d']),
                grid_cell=(0, 0),  # 从 JSON 加载时不需要栅格位置
                width=gw_dict.get('width', 1.0),
                confidence=gw_dict.get('confidence', 0.5)
            )
            self.gateways.append(gw)
            self.room_adjacency[(gw.room_a, gw.room_b)] = gw

        print(f"\n加载 Gateway: {len(self.gateways)} 个 (来自 {gateway_json_path})")

    def detect_gateways(self, rooms: List[Dict]):
        """
        从房间分割结果检测 gateway (原始方法,基于房间相邻性)

        Args:
            rooms: 房间列表,每个 room 包含 'id', 'points', 'center'
        """
        print("\n" + "=" * 60)
        print("Gateway 检测 (基于房间相邻性)")
        print("=" * 60)

        # 提取 floor 点云用于检测
        floor_points = self._extract_floor_points()

        detector = GatewayDetector(floor_points, resolution=self.resolution)
        self.gateways = detector.detect_gateways(rooms, floor_grid=self.grid_map.get_grid())

        # 构建房间邻接图
        for gw in self.gateways:
            self.room_adjacency[(gw.room_a, gw.room_b)] = gw

        print(f"\nGateway 检测完成: {len(self.gateways)} 个 gateway")
        return self.gateways

    def detect_gateways_from_trajectory(self, trajectory: np.ndarray,
                                         rooms: List[Dict],
                                         merge_distance: float = 1.0):
        """
        从机器人实际行走轨迹提取 gateway

        策略:
        1. 对轨迹中每个点,判断所属房间
        2. 检测房间变化的位置 → gateway
        3. 融合相同房间对的 gateway

        Args:
            trajectory: (N, 3) 轨迹点云 (x, y, z)
            rooms: 房间列表 (含 'id', 'center')
            merge_distance: 同一房间对 gateway 合并距离阈值 (m)
        """
        print("\n" + "=" * 60)
        print("Gateway 检测 (基于实际行走轨迹)")
        print("=" * 60)

        # 提取 floor 点云用于检测
        floor_points = self._extract_floor_points()

        detector = GatewayDetector(floor_points, resolution=self.resolution)
        self.gateways = detector.detect_gateways_from_trajectory(
            trajectory, rooms,
            floor_grid=self.grid_map.get_grid(),
            merge_distance=merge_distance
        )

        # 构建房间邻接图
        for gw in self.gateways:
            self.room_adjacency[(gw.room_a, gw.room_b)] = gw

        print(f"\nGateway 检测完成: {len(self.gateways)} 个 gateway")
        return self.gateways

    def _extract_floor_points(self) -> np.ndarray:
        """从全局点云提取 floor 点"""
        import open3d as o3d
        
        pcd = o3d.io.read_point_cloud(str(self.global_pcd_path))
        points = np.asarray(pcd.points)
        
        z_min_all = points[:, 2].min()
        z_max_all = points[:, 2].max()
        
        floor_3d_list = []
        band_size = 5.0
        z_bands = np.arange(z_min_all - band_size, z_max_all + band_size, band_size)
        
        for i in range(len(z_bands) - 1):
            z_low = z_bands[i]
            z_high = z_bands[i + 1]
            
            band_mask = (points[:, 2] >= z_low) & (points[:, 2] < z_high)
            band_pts = points[band_mask]
            
            if len(band_pts) < 100:
                continue
            
            y_10 = np.percentile(band_pts[:, 1], 10)
            floor_y = y_10 + 1.0
            
            floor_mask = band_pts[:, 1] < floor_y
            floor_pts = band_pts[floor_mask]
            if len(floor_pts) > 0:
                floor_3d_list.append(floor_pts)
        
        if not floor_3d_list:
            return points
        
        return np.vstack(floor_3d_list)

    def find_object_location(self, target_query):
        """查找目标物体位置"""
        try:
            coords = [float(x) for x in target_query.split(',')]
            if len(coords) == 3:
                return coords
        except:
            pass

        # Try room names: "Room 2", "room_2", "Room2", etc.
        import re
        room_match = re.match(r'room[_\s]?(\d+)', target_query, re.IGNORECASE)
        if room_match:
            room_id = int(room_match.group(1))
            for room in getattr(self, 'rooms_data', []):
                if room.get('id') == room_id:
                    center = room['center']
                    return [center[0], center[1], center[2]]
            return None

        for obj in self.objects:
            if obj.get('name', '').lower() == target_query.lower() or \
               obj.get('category', '').lower() == target_query.lower():
                center = obj['center']
                return [center[0], center[1], center[2]]

        for obj in self.objects:
            if target_query.lower() in obj.get('name', '').lower() or \
               target_query.lower() in obj.get('category', '').lower():
                center = obj['center']
                return [center[0], center[1], center[2]]

        return None

    def find_room_for_position(self, position, rooms: List[Dict] = None) -> Optional[int]:
        """找某个位置属于哪个房间 — uses cached cKDTree if available."""
        pos_2d = [position[0], position[2]]

        # Use cached tree if we have it
        if self._room_tree is not None and self.rooms_data:
            _, idx = self._room_tree.query(pos_2d)
            return self.rooms_data[idx]['id']

        # Fallback: build tree on the fly (for backward compat)
        from scipy.spatial import cKDTree
        room_list = rooms if rooms else self.rooms_data
        room_centers = np.array([[r['center'][0], r['center'][2]] for r in room_list])
        tree = cKDTree(room_centers)
        _, idx = tree.query(pos_2d)
        return room_list[idx]['id']

    def plan_high_level_path(self, start_position, goal_position, rooms: List[Dict]):
        """
        高层路径: 基于房间邻接图的 BFS/Dijkstra

        策略:
        1. 确定起点和终点所在的房间
        2. 在房间邻接图上找最短房间序列
        3. 提取房间序列之间的 gateway 作为路径点
        """
        if not self.gateways:
            print("  警告: 没有 gateway,使用直接路径")
            return [start_position, goal_position], []

        # 找房间 (uses cached cKDTree)
        start_room = self.find_room_for_position(start_position)
        goal_room = self.find_room_for_position(goal_position)

        if start_room is None or goal_room is None:
            print("  警告: 无法确定房间,使用直接路径")
            return [start_position, goal_position], []

        if start_room == goal_room:
            return [start_position, goal_position], []

        # Use cached room graph if available, otherwise build on the fly
        room_graph = self._room_graph if self._room_graph else {}
        if not room_graph:
            for gw in self.gateways:
                if gw.room_a not in room_graph:
                    room_graph[gw.room_a] = []
                if gw.room_b not in room_graph:
                    room_graph[gw.room_b] = []
                room_graph[gw.room_a].append((gw.room_b, gw))
                room_graph[gw.room_b].append((gw.room_a, gw))

        # BFS/Dijkstra 找最短房间序列
        dist = {start_room: 0}
        prev = {start_room: None}
        prev_gw = {start_room: None}
        pq = [(0, start_room)]
        visited = set()

        while pq:
            d, current = heapq.heappop(pq)

            if current == goal_room:
                # 重建房间路径
                room_path = []
                gw_path = []
                node = goal_room
                while node is not None:
                    room_path.append(node)
                    if prev_gw[node] is not None:
                        gw_path.append(prev_gw[node])
                    node = prev[node]
                room_path.reverse()
                gw_path.reverse()

                # 转为 3D 路径
                path_3d = [start_position]
                for gw in gw_path:
                    path_3d.append([gw.position_3d[0], gw.position_3d[1], gw.position_3d[2]])
                path_3d.append(goal_position)

                gw_names = [f"GW{gw.id}(R{gw.room_a}↔R{gw.room_b})" for gw in gw_path]
                return path_3d, gw_names

            if current in visited:
                continue
            visited.add(current)

            for neighbor, gw in room_graph.get(current, []):
                if neighbor in visited:
                    continue
                new_dist = d + 1  # 每跳权重为 1
                if new_dist < dist.get(neighbor, float('inf')):
                    dist[neighbor] = new_dist
                    prev[neighbor] = current
                    prev_gw[neighbor] = gw
                    heapq.heappush(pq, (new_dist, neighbor))

        print(f"  错误: 无法找到从房间 {start_room} 到 {goal_room} 的路径")
        return None, None

    def plan_low_level_path(self, start_world, goal_world):
        """微观路径: A* 在 floor grid 上,使用 cost map"""
        start_2d = [start_world[0], start_world[2]]
        goal_2d = [goal_world[0], goal_world[2]]

        path_2d = self.planner.plan(start_2d, goal_2d)
        if path_2d is None:
            return None

        # 平滑 + 简化
        path_2d = self.planner.smooth_path(path_2d)

        if len(path_2d) > 10:
            path_2d = rdp_simplify(np.array(path_2d), epsilon=0.1)

        # 转 3D
        path_3d = []
        for x, z in path_2d:
            # Y 高度计算: 优先使用轨迹平面投影，否则用固定 floor_y
            if self.trajectory_plane is not None:
                # 初始路径点 (x, floor_y, z)
                pt = np.array([x, self.floor_y, z])
                
                # 沿法向量投影到平面: P_proj = P - (n·P + d) * n
                normal = self.trajectory_plane['normal']
                d = self.trajectory_plane['d']
                
                dist_to_plane = np.dot(normal, pt) + d
                pt_proj = pt - dist_to_plane * normal
                
                # 投影后的点就是地面高度
                y_height = pt_proj[1]
                
                # 如果 cost map 可用，根据离障碍物距离微调 (最多 +0.3m)
                if self.cost_map:
                    row, col = self.grid_map._world_to_grid(x, z)
                    dist_to_obs = self.cost_map.get_distance(row, col)
                    y_height += min(dist_to_obs * 0.1, 0.3)
            else:
                # 无平面信息，使用固定 floor_y
                if self.cost_map:
                    row, col = self.grid_map._world_to_grid(x, z)
                    dist_to_obs = self.cost_map.get_distance(row, col)
                    y_height = self.floor_y + min(dist_to_obs * 0.1, 0.3)
                else:
                    y_height = self.floor_y
            
            path_3d.append([x, y_height, z])

        return path_3d

    def plan(self, start_position, target_query, rooms: List[Dict] = None,
             status_callback=None):
        """
        完整的两层路径规划

        Args:
            start_position: 起点 [x, y, z]
            target_query: 目标物体名称或坐标
            rooms: 房间列表 (用于 gateway 检测)
            status_callback: Optional callable(str) for progress updates (e.g. status line display)
        """
        def _status(msg):
            if status_callback:
                status_callback(msg)

        # Step 0: 检测 gateway (如果还没做)
        _status("检测 gateway 连接...")
        if not self.gateways and rooms:
            self.detect_gateways(rooms)
        elif not self.gateways:
            _status("⚠ 无房间数据，使用直接路径")

        # Step 1: 查找目标
        _status("正在检索目标: " + target_query)
        goal_position = self.find_object_location(target_query)
        if goal_position is None:
            return {'success': False, 'error': '找不到目标物体'}
        _status(f"目标位置确定: ({goal_position[0]:.1f}, {goal_position[1]:.1f}, {goal_position[2]:.1f})")

        # Step 2: 高层路径 (通过 gateway)
        _status("规划高层路径...")

        if self.gateways and rooms:
            high_level_path, gw_sequence = self.plan_high_level_path(
                start_position, goal_position, rooms
            )
        else:
            high_level_path = [start_position, goal_position]
            gw_sequence = []

        if high_level_path is None:
            high_level_path = [start_position, goal_position]
            gw_sequence = []

        waypoints_3d = high_level_path

        # Step 3: 微观路径 (逐段 A*)
        _status("微观路径规划 (A*) ...")
        full_path_3d = []

        for i in range(len(waypoints_3d) - 1):
            seg_start = waypoints_3d[i]
            seg_goal = waypoints_3d[i + 1]

            seg_path = self.plan_low_level_path(seg_start, seg_goal)
            if seg_path is None:
                full_path_3d.append(seg_start)
                full_path_3d.append(seg_goal)
            else:
                if i > 0 and len(full_path_3d) > 0:
                    seg_path = seg_path[1:]  # 避免重复
                full_path_3d.extend(seg_path)

        # Step 4: 统计
        total_distance = 0
        for i in range(len(full_path_3d) - 1):
            total_distance += np.linalg.norm(
                np.array(full_path_3d[i]) - np.array(full_path_3d[i+1])
            )

        _status(f"路径规划完成: {total_distance:.1f}m, {len(full_path_3d)} 个路径点")

        # Step 5: 路径重采样 (按 0.01m 间距)
        full_path_3d_resampled = resample_path(full_path_3d, step_size=0.01)

        # 重新计算重采样后的总距离
        total_distance_resampled = 0
        for i in range(len(full_path_3d_resampled) - 1):
            total_distance_resampled += np.linalg.norm(
                np.array(full_path_3d_resampled[i]) - np.array(full_path_3d_resampled[i+1])
            )

        return {
            'success': True,
            'start_position': start_position,
            'goal_position': goal_position,
            'high_level_path': waypoints_3d,
            'gateway_sequence': gw_sequence,
            'low_level_path': full_path_3d,
            'low_level_path_resampled': full_path_3d_resampled,
            'waypoints': waypoints_3d,
            'total_distance': total_distance_resampled,
            'num_path_points': len(full_path_3d),
            'num_path_points_resampled': len(full_path_3d_resampled),
        }
