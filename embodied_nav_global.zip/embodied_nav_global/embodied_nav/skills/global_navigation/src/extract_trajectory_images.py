"""
从导航轨迹中提取对应的原始图片

对于轨迹上的每个点，在 poses.txt 中找到最近的相机位姿，
将对应的图片复制到输出文件夹，并按轨迹顺序重命名 (0000.png, 0001.png, ...)，
同时生成 manifest.json 映射文件记录顺序和原始时间戳。

用法:
  # 从已保存的路径 JSON 提取
  python extract_trajectory_images.py --path paths/path_我想打印资料.json

  # 指定自定义 poses 和图片目录
  python extract_trajectory_images.py --path paths/path_我想打印资料.json \
    --poses /workspace/wxd/VLN/datasets/icra_ic7f/poses.txt \
    --images /workspace/wxd/VLN/datasets/icra_ic7f/images

  # 保留原始文件名 (不重命名, 旧行为)
  python extract_trajectory_images.py --path paths/path_我想打印资料.json --keep-original-names
"""

import argparse
import json
import shutil
import numpy as np
from pathlib import Path
from scipy.spatial.transform import Rotation as R


def load_poses_as_positions(poses_file):
    """
    加载 poses.txt，返回 [(timestamp, position_3d), ...]
    使用与 build_pointcloud.py / navigate.py 相同的坐标变换
    """
    T_SWITCH_AXIS = np.array([
        [1, 0, 0, 0],
        [0, 0, 1, 0],
        [0, -1, 0, 0],
        [0, 0, 0, 1]
    ], dtype=np.float64)

    entries = []
    with open(poses_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) < 8:
                continue

            timestamp = parts[0]
            tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
            qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

            quat = [qx, qy, qz, qw]
            rot_matrix = R.from_quat(quat).as_matrix()

            T_w2c = np.eye(4)
            T_w2c[:3, :3] = rot_matrix
            T_w2c[:3, 3] = [tx, ty, tz]

            T_c2w = np.linalg.inv(T_w2c)
            T_c2w = T_SWITCH_AXIS @ T_c2w

            position = T_c2w[:3, 3]
            entries.append((timestamp, position))

    return entries


def find_nearest_pose(traj_point, pose_entries):
    """找到距离轨迹点最近的相机位姿"""
    positions = np.array([p[1] for p in pose_entries])
    dists = np.linalg.norm(positions - np.array(traj_point), axis=1)
    idx = np.argmin(dists)
    return pose_entries[idx], dists[idx]


def main():
    parser = argparse.ArgumentParser(description='从导航轨迹提取对应的原始图片')
    parser.add_argument('--path', type=str, required=True,
                       help='导航路径 JSON 文件')
    parser.add_argument('--poses', type=str, default=None,
                       help='poses.txt 路径 (默认自动查找)')
    parser.add_argument('--images', type=str, default=None,
                       help='图片目录路径 (默认自动查找)')
    parser.add_argument('--output', type=str, default=None,
                       help='输出目录 (默认: paths/<path_name>_images/)')
    parser.add_argument('--keep-original-names', action='store_true',
                       help='保留原始时间戳文件名 (不重命名)')
    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parent

    # 加载路径
    path_file = Path(args.path)
    if not path_file.exists():
        # 尝试在 paths/ 目录下查找
        alt = base_dir / 'paths' / path_file.name
        if alt.exists():
            path_file = alt
        else:
            print(f"错误: 路径文件不存在: {args.path}")
            return

    with open(path_file, 'r') as f:
        path_data = json.load(f)

    if not path_data.get('success'):
        print("错误: 该路径规划失败")
        return

    # 选择使用的路径数据 (默认重采样路径)
    path_key = 'low_level_path_resampled'
    trajectory = path_data[path_key]
    print(f"加载路径: {path_file.name}")
    print(f"  使用: {path_key}")
    print(f"  轨迹点数: {len(trajectory)}")
    print(f"  总距离: {path_data['total_distance']:.2f}m")

    # 查找 poses.txt
    if args.poses:
        poses_file = Path(args.poses)
    else:
        candidates = [
            base_dir.parent / 'poses.txt',
            Path('/workspace/wxd/VLN/datasets/icra_ic7f/poses.txt'),
            Path('/workspace/wxd/VLN/datasets/icra_ic4f/poses.txt'),
        ]
        poses_file = None
        for p in candidates:
            if p.exists():
                poses_file = p
                break
        if poses_file is None:
            print("错误: 未找到 poses.txt，请使用 --poses 指定")
            return

    # 查找图片目录
    if args.images:
        images_dir = Path(args.images)
    else:
        candidates = [
            base_dir.parent / 'images',
            Path('/workspace/wxd/VLN/datasets/icra_ic7f/images'),
            Path('/workspace/wxd/VLN/datasets/icra_ic4f/images'),
        ]
        images_dir = None
        for p in candidates:
            if p.exists():
                images_dir = p
                break
        if images_dir is None:
            print("错误: 未找到图片目录，请使用 --images 指定")
            return

    # 加载所有相机位姿
    print(f"\n加载位姿: {poses_file}")
    pose_entries = load_poses_as_positions(poses_file)
    print(f"  共 {len(pose_entries)} 帧")

    # 为每个轨迹点找到最近的相机位姿 (默认跳过重复)
    print("\n匹配轨迹点到相机位姿...")
    matched = []
    used_timestamps = set()
    dup_count = 0

    for i, pt in enumerate(trajectory):
        nearest_pose, dist = find_nearest_pose(pt, pose_entries)
        timestamp, position = nearest_pose

        if timestamp in used_timestamps:
            dup_count += 1
            continue

        used_timestamps.add(timestamp)
        matched.append({
            'traj_index': i,
            'traj_point': pt,
            'timestamp': timestamp,
            'pose_position': position.tolist(),
            'distance': float(dist),
        })

        if i == 0 or i % 10 == 0 or i == len(trajectory) - 1:
            print(f"  [{i}/{len(trajectory)}] 点({pt[0]:.2f}, {pt[1]:.2f}, {pt[2]:.2f}) → "
                  f"帧 {timestamp}, 距离={dist:.3f}m")

    print(f"\n匹配结果:")
    print(f"  唯一帧数: {len(matched)}")
    print(f"  跳过重复: {dup_count}")

    # 计算距离统计
    distances = [m['distance'] for m in matched]
    print(f"  匹配距离: 平均={np.mean(distances):.3f}m, "
          f"最大={np.max(distances):.3f}m, "
          f"最小={np.min(distances):.3f}m")

    # 复制图片
    output_dir = args.output
    if output_dir is None:
        stem = path_file.stem.replace('path_', '')
        output_dir = base_dir / 'paths' / f'{stem}_images'

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n复制图片到: {output_dir}")
    copied = 0
    missing = 0

    # 构建 manifest 记录映射关系
    manifest = {
        'path_file': str(path_file.name),
        'path_key': path_key,
        'total_trajectory_points': len(trajectory),
        'extracted_frames': len(matched),
        'frames': [],
    }

    use_sequential_names = not args.keep_original_names

    for idx, m in enumerate(matched):
        timestamp = m['timestamp']
        img_file = images_dir / f'{timestamp}.png'

        if use_sequential_names:
            # 按轨迹顺序重命名: 0000.png, 0001.png, ...
            dest_name = f'{idx:04d}.png'
        else:
            # 保留原始时间戳文件名
            dest_name = img_file.name

        if img_file.exists():
            shutil.copy2(img_file, output_dir / dest_name)
            manifest['frames'].append({
                'sequence_index': idx,
                'filename': dest_name,
                'original_timestamp': timestamp,
                'traj_index': m['traj_index'],
                'traj_point': m['traj_point'],
                'pose_position': m['pose_position'],
                'distance_to_pose': m['distance'],
            })
            copied += 1
        else:
            print(f"  警告: 图片不存在: {img_file}")
            missing += 1

    # 写入 manifest
    manifest_file = output_dir / 'manifest.json'
    with open(manifest_file, 'w') as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)

    print(f"\n完成!")
    print(f"  复制: {copied} 张")
    if missing > 0:
        print(f"  缺失: {missing} 张")
    if use_sequential_names:
        print(f"  命名方式: 顺序编号 (0000.png ~ {copied - 1:04d}.png)")
        print(f"  映射文件: {manifest_file}")
    else:
        print(f"  命名方式: 原始时间戳")
    print(f"  输出目录: {output_dir}")


if __name__ == '__main__':
    main()
