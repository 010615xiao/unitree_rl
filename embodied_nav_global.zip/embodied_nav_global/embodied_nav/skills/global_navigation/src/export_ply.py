#!/usr/bin/env python3
"""
导出导航结果为 PLY 点云文件 (MeshLab 可视化)
"""

import numpy as np
import json
import open3d as o3d
from pathlib import Path


def export_ply_points(points, colors, output_path):
    """导出点云为 PLY"""
    if len(points) == 0:
        return
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(np.array(points))
    pcd.colors = o3d.utility.Vector3dVector(np.array(colors))
    o3d.io.write_point_cloud(str(output_path), pcd)
    print(f"  已导出: {output_path} ({len(points)} 点)")


def export_navigation_results(path_result_path, ply_output_dir,
                               include_global_pcd=False,
                               global_pcd_path=None):
    path_result_path = Path(path_result_path)
    ply_output_dir = Path(ply_output_dir)
    ply_output_dir.mkdir(parents=True, exist_ok=True)
    
    with open(path_result_path, 'r') as f:
        result = json.load(f)
    
    if not result.get('success', False):
        print("规划失败，跳过 PLY 导出")
        return
    
    waypoints = result['waypoints']
    path_points = result['low_level_path']
    
    # 绿色 - 起点
    start_pt = waypoints[0]
    start_cloud = [start_pt + np.random.normal(0, 0.05, 3) for _ in range(50)]
    start_colors = [[0.0, 1.0, 0.0]] * len(start_cloud)
    export_ply_points(start_cloud, start_colors, ply_output_dir / 'start.ply')

    # 蓝色 - 目标
    target_pt = waypoints[-1]
    target_cloud = [target_pt + np.random.normal(0, 0.05, 3) for _ in range(50)]
    target_colors = [[0.0, 0.0, 1.0]] * len(target_cloud)
    export_ply_points(target_cloud, target_colors, ply_output_dir / 'target.ply')

    # 黄色 - 中间 waypoints / gateway (始终导出)
    if len(waypoints) > 2:
        mid_waypoints = waypoints[1:-1]
    else:
        # 无中间 waypoint 时仍导出一张空文件
        mid_waypoints = []

    gateway_cloud = []
    gateway_colors = []
    for wp in mid_waypoints:
        for _ in range(50):
            pt = wp + np.random.normal(0, 0.05, 3)
            gateway_cloud.append(pt)
            gateway_colors.append([1.0, 1.0, 0.0])

    # 即使没有 gateway 也导出一张至少包含起/终点之间连线的参考点云
    if not gateway_cloud and len(waypoints) >= 2:
        for t in np.linspace(0, 1, 20):
            pt = (1 - t) * np.array(waypoints[0]) + t * np.array(waypoints[-1])
            gateway_cloud.append(pt.tolist())
            gateway_colors.append([0.8, 0.8, 0.0])

    export_ply_points(gateway_cloud, gateway_colors, ply_output_dir / 'waypoints.ply')
    
    # 红色 - 路径线
    path_cloud = []
    path_colors = []
    for pt in path_points:
        path_cloud.append(pt)
        path_colors.append([1.0, 0.0, 0.0])
    
    # 添加路径段之间的插值点
    for i in range(len(path_points) - 1):
        p1, p2 = np.array(path_points[i]), np.array(path_points[i+1])
        dist = np.linalg.norm(p2 - p1)
        n_interp = max(int(dist / 0.05), 1)
        for t in np.linspace(0, 1, n_interp):
            interp_pt = (1-t) * p1 + t * p2
            path_cloud.append(interp_pt.tolist())
            path_colors.append([1.0, 0.0, 0.0])
    
    export_ply_points(path_cloud, path_colors, ply_output_dir / 'path_line.ply')
    
    # 全局点云
    if include_global_pcd and global_pcd_path:
        pcd = o3d.io.read_point_cloud(str(global_pcd_path))
        o3d.io.write_point_cloud(str(ply_output_dir / 'global_pointcloud.ply'), pcd)
        print(f"  已复制全局点云: {ply_output_dir / 'global_pointcloud.ply'}")
    
    # 摘要
    print(f"\n" + "=" * 40)
    print("MeshLab 使用指南:")
    print(f"  1. 打开 MeshLab")
    print(f"  2. File → Import Mesh → 选择 {ply_output_dir}/ 下的 .ply 文件")
    print(f"  3. 建议按顺序:")
    print(f"     a) 全局点云 (灰色背景)")
    print(f"     b) 路径线 (红色)")
    print(f"     c) 起点 (绿色), 目标 (蓝色), Gateway (黄色)")
    print(f"  4. 点击 Point Size 放大点显示")
    print(f"  5. 勾选/取消各层控制显示")
    print(f"=" * 40)
    
    return {
        'start': ply_output_dir / 'start.ply',
        'target': ply_output_dir / 'target.ply',
        'waypoints': ply_output_dir / 'waypoints.ply',
        'path_line': ply_output_dir / 'path_line.ply',
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description='导出导航结果为 PLY 点云')
    parser.add_argument('--path-result', type=str,
                       default='navigation/path_result.json')
    parser.add_argument('--ply-dir', type=str,
                       default='navigation/ply_output')
    parser.add_argument('--with-global', action='store_true')
    parser.add_argument('--global-pcd', type=str,
                       default='unified_output/global/global_pointcloud.ply')
    args = parser.parse_args()
    
    from pathlib import Path
    base_dir = Path(__file__).resolve().parent.parent
    path_result = base_dir / args.path_result
    global_pcd = base_dir / args.global_pcd
    
    export_navigation_results(
        str(path_result), str(base_dir / args.ply_dir),
        include_global_pcd=args.with_global,
        global_pcd_path=str(global_pcd) if args.with_global else None
    )


if __name__ == '__main__':
    main()
