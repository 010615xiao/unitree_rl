---
name: global_navigation
description: >
  Plan global navigation trajectories in a reconstructed indoor environment.
  SINGLE-CALL: after plan_navigation() returns successfully, the task is COMPLETE.
  Do NOT call again to "execute", "start", or "move" — there is no execution step.
  Use when the user asks to navigate to an object, room, or location
  (e.g., "go to the kitchen", "find chair_0", "帮我找个能坐的地方").
  Supports exact object names, coordinates, and fuzzy natural language intents.
version: 1.0.0
---

# Global Navigation

## Decision Guide

**Fuzzy intent (e.g., "帮我找个能坐的地方"):**
→ `plan_navigation(target="帮我找个能坐的地方")` — auto-resolved by VLM. One call, then stop.

**Specific object (e.g., "去 chair_0"):**
→ `plan_navigation(target="chair_0")` — one call, then stop.

**Room (e.g., "去厨房"):**
→ `list_rooms()` to find Room ID, then `plan_navigation(target="Room N")`.

**Coordinates (e.g., "去1.5,0,3.2"):**
→ `plan_navigation(target="1.5,0,3.2")`.

**If navigation fails:**
→ Use `list_rooms()` or `list_objects()` to find the correct target, retry once.

## Rules

1. **After `plan_navigation()` succeeds, you are DONE.** Report the result. Do NOT call any more tools.
2. **Fuzzy intents are auto-resolved.** No need to call `list_objects()` first.
3. **When reporting results, use ONLY the tool's actual output.** The tool returns: target name (e.g., `refrigerator_0`), distance, and route. Your response MUST include these. Do NOT re-explain the broader plan or list future steps — you don't know what step you're on.
   - ✅ "已规划路线到 refrigerator_0，距离 12.5m，路线: gw_1 → gw_2"
   - ❌ "好的，我已经为你规划好了步骤：1.去冰箱 2.洗苹果 3.返回"

## Tools

- `get_scene_summary()`: Quick overview — grid stats, gateways, categories
- `list_rooms()`: All rooms with IDs, centers, key objects
- `list_objects(category?)`: Objects with positions and rooms
- `plan_navigation(target, start?)`: Plan path — returns distance, waypoints, gateways
- `save_path(name, target, start?)`: Plan + save to JSON file
