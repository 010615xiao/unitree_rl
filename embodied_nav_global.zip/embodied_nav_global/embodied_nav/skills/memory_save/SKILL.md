---
name: memory_save
description: >
  Save new information to long-term memory. Use when conversation contains cross-session valuable facts, preferences, relationships, corrections, or feedback.
version: 1.0.0
---

# Memory Save

Save cross-session valuable information to long-term memory.

**When to use:**
- You learn something about the user that persists across sessions: identity, preferences, location, relationships, goals, feedback on your behavior
- The user shares personal information (even casually) that would be useful in future conversations
- You complete a task and the result should be recorded for future sessions

**When NOT to use:**
- Temporary context (current file paths, current file content, one-off answers) — these are in conversation history

**Tip:** When the user says "记住...", "记一下", "remember..." — definitely call `save_memory`. But you can also save proactively when you learn something valuable, even if the user didn't explicitly ask.

**Memory types:**

| type | When to use |
|------|------------|
| `user` | User identity, preferences, facts |
| `feedback` | Corrections to agent behavior |
| `project` | Time-bound work, goals, deadlines |
| `reference` | External resources, links, APIs |

**Tools:**
- `save_memory(key, content, tags, type)` — Creates a new memory. Pick a short, descriptive English key in snake_case (e.g., `user_hometown`, `girlfriend_location`).
- `update_memory(key, content, tags)` — Replaces an existing memory entirely. Verify the key exists first.

**CRITICAL: Memory content MUST follow this format:**

```
{The fact — 1-2 sentences}

Why: {Why this matters for future conversations}

Useful for: {2-3 scenarios where this helps}
```

**Good example:**
```
用户的老家是河南省洛阳市。

Why: 用户在查询天气、规划行程、或聊到家乡时可能需要这个信息。

Useful for: 用户未指定城市但需要城市信息时（如天气查询、本地推荐、交通规划、旅游建议等场景）
```

**Bad example (bare fact — DO NOT DO THIS):**
```
用户住在杭州。
```
