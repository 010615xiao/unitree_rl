"""
Memory Save Skill - Tools

Save new information to long-term persistent memory.
"""


def save_memory(key: str, content: str, tags: str, type: str = "user", memory_dir: str = "./memory", expires: str = None) -> str:
    """Save a new fact to long-term memory. Proactively save valuable info when you learn something about the user (identity, preferences, location, relationships, feedback, goals). Do NOT wait for explicit "记住" commands.

    Args:
        key: REQUIRED English snake_case key (e.g., "user_hometown", "girlfriend_job"). Use ONLY English letters and underscores. No Chinese characters in key.
        content: REQUIRED. MUST follow this exact format (3 parts, separated by blank lines):
            {The fact - 1-2 sentences}
            <blank line>
            Why: {Why this matters for future conversations}
            <blank line>
            Useful for: {2-3 scenarios where this helps}
            Example: "用户的老家是河南省洛阳市。\n\nWhy: 用户在查询天气、规划行程、或聊到家乡时可能需要这个信息。\n\nUseful for: 用户未指定城市但需要城市信息时（如天气查询、本地推荐、交通规划等场景）"
        tags: Comma-separated tags in Chinese (e.g., "用户信息, 位置, 女朋友")
        type: Memory type: user, feedback, project, reference (default: user)
        memory_dir: Directory to save to
        expires: Optional ISO date for auto-cleanup (e.g., "2026-06-01")

    Returns:
        Confirmation message with the saved key
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    tag_list = [t.strip() for t in tags.split(",") if t.strip()]

    valid_types = ("user", "feedback", "project", "reference")
    if type not in valid_types:
        type = "user"

    ltm.set(key, content, type=type, tags=tag_list, expires=expires)
    ltm.generate_memory_md()
    return f"[memory] Saved to '{key}'"


def update_memory(key: str, content: str, tags: str = None, memory_dir: str = "./memory") -> str:
    """Update existing memory content.

    Args:
        key: Memory key to update
        content: New content
        tags: Optional comma-separated tags (preserves existing if not provided)
        memory_dir: Directory

    Returns:
        Confirmation message
    """
    from memory.memory_manager import LongTermMemory

    ltm = LongTermMemory(memory_dir=memory_dir)
    existing = ltm.get_entry(key)
    if existing is None:
        return f"[memory] Key '{key}' does not exist. Use memory_list__list_memories() to see available keys."

    tag_list = None
    if tags:
        tag_list = [t.strip() for t in tags.split(",") if t.strip()]

    success = ltm.update(key, content, tags=tag_list)
    if success:
        return f"[memory] Updated '{key}'"
    return f"[memory] Failed to update '{key}'"
