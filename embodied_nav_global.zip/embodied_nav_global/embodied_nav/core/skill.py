"""
Skill Base Class & Registry

Two-phase architecture:
  Phase 1 (main VLM): selects skill by name + describes intent
  Phase 2 (sub-agent): skill's own VLM picks the right tool from its own schema

All skills inherit from BaseSkill and follow the standard:
  - SKILL.md: YAML frontmatter + markdown body (declaration)
  - tools.py: Concrete tool function implementations (execution)
"""

import os
import re
import json
import yaml
import inspect
import importlib
import importlib.util
from pathlib import Path
from abc import ABC, abstractmethod
from typing import Any, Callable


# ============================================================
# YAML Frontmatter parser
# ============================================================
def parse_frontmatter(md_path: str) -> tuple[dict, str]:
    """Parse YAML frontmatter and body from a .md file.

    Returns:
        (frontmatter_dict, body_text)
    """
    with open(md_path, 'r', encoding='utf-8') as f:
        content = f.read()

    pattern = r'^---\s*\n(.*?)\n---\s*\n(.*)'
    match = re.match(pattern, content, re.DOTALL)
    if not match:
        raise ValueError(f"Invalid skill.md format: missing YAML frontmatter in {md_path}")

    fm = yaml.safe_load(match.group(1))
    body = match.group(2).strip()
    return fm, body


# ============================================================
# Docstring parser for parameter descriptions
# ============================================================
def _parse_docstring_params(docstring: str) -> dict[str, str]:
    """Extract parameter descriptions from a Google-style docstring.

    Supports:
        Args:
            param_name: description text
            param_name (type): description text
    """
    params = {}
    if not docstring:
        return params

    in_args = False
    for line in docstring.split('\n'):
        stripped = line.strip()
        if stripped == 'Args:':
            in_args = True
            continue
        if in_args:
            if stripped in ('Returns:', 'Raises:', 'Yields:', 'Examples:', 'Note:'):
                in_args = False
                continue
            match = re.match(r'^(\w+)(?:\s*\(.*?\))?\s*:\s*(.*)', stripped)
            if match:
                param_name = match.group(1)
                param_desc = match.group(2).strip()
                params[param_name] = param_desc
    return params


# ============================================================
# Base Skill
# ============================================================
class BaseSkill(ABC):
    """All skills must inherit from this class."""

    def __init__(self, md_path: str):
        """Initialize skill from SKILL.md file."""
        self.md_path = md_path
        self.meta, self.body = parse_frontmatter(md_path)
        self.name = self.meta.get('name', 'unknown')
        self.description = self.meta.get('description', '')
        self.version = self.meta.get('version', '1.0.0')
        self.tools: dict[str, Callable] = {}
        self._registry: 'SkillRegistry | None' = None  # Set by registry after loading
        self._load_tools()

    def _load_tools(self):
        """Dynamically load tools.py from the same directory as SKILL.md."""
        tools_dir = Path(self.md_path).parent
        tools_path = tools_dir / 'tools.py'
        if tools_path.exists():
            spec = importlib.util.spec_from_file_location(
                f"tools_{self.name}", str(tools_path)
            )
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            for attr_name in dir(module):
                if attr_name.startswith('_'):
                    continue
                attr = getattr(module, attr_name)
                if callable(attr) and getattr(attr, '__module__', None) == module.__name__:
                    self.tools[attr_name] = attr

    @abstractmethod
    def execute(self, intent: str, vlm_client=None, **kwargs) -> Any:
        """Execute the skill with a natural-language intent.

        Two-phase: the main VLM selects this skill and passes `intent`.
        The skill internally decides which concrete tool(s) to call.

        Args:
            intent: What the user wants to accomplish (natural language)
            vlm_client: VLMClient instance for sub-agent tool selection
        """
        pass

    def get_tool_schema(self) -> list[dict]:
        """Return OpenAI-compatible function calling schemas for this skill's tools.

        Used by the sub-agent VLM to select the right concrete tool.
        """
        tool_list = []

        for name, func in self.tools.items():
            doc = func.__doc__ or ""
            param_descriptions = _parse_docstring_params(doc)

            sig = inspect.signature(func)
            properties = {}
            required = []
            for param_name, param in sig.parameters.items():
                if param_name == 'self':
                    continue
                p_type = param.annotation
                type_str = "string"
                if p_type == int:
                    type_str = "integer"
                elif p_type == float:
                    type_str = "number"
                elif p_type == bool:
                    type_str = "boolean"
                elif p_type == list:
                    type_str = "array"

                prop_schema = {"type": type_str}
                desc = param_descriptions.get(param_name)
                if desc:
                    prop_schema["description"] = desc
                properties[param_name] = prop_schema

                if param.default == inspect.Parameter.empty:
                    required.append(param_name)

            tool_list.append({
                "type": "function",
                "function": {
                    "name": f"{self.name}__{name}",
                    "description": doc.split('\n')[0] if doc else f"Execute {name}",
                    "parameters": {
                        "type": "object",
                        "properties": properties,
                        "required": required
                    }
                }
            })
        return tool_list

    # ============================================================
    # Sub-agent execution (used by DefaultSkill and custom skills)
    # ============================================================
    def run_sub_agent(
        self,
        intent: str,
        vlm_client,
        messages: list[dict] | None = None,
        max_steps: int = 5,
        max_same_error: int = 2,
    ) -> str:
        """Run a mini ReAct loop inside this skill to select and execute tools.

        The sub-agent VLM only sees this skill's tool schemas (not all ~30 tools),
        drastically reducing the decision space.

        Args:
            intent: What the user wants (natural language)
            vlm_client: VLMClient for sub-agent calls
            messages: Optional conversation history from the main agent
            max_steps: Maximum sub-agent reasoning steps
            max_same_error: Terminate if the same error repeats this many times

        Returns:
            Final result string from the sub-agent
        """
        tools_schema = self.get_tool_schema()

        # Inject global tools (memory CRUD, etc.) into sub-agent context
        # so any skill can access memory during execution
        if self._registry:
            global_tools = self._registry.get_global_tool_schemas()
            tools_schema = tools_schema + global_tools
        if not tools_schema:
            # No tools — just return intent for the main VLM to handle
            return f"[FINAL_ANSWER]Skill '{self.name}' has no tools. Please respond directly."

        if messages:
            # Use provided history (includes system prompt, user message, etc.)
            sub_messages = [m for m in messages if m["role"] != "system"]
            # Prepend the skill's SKILL.md body as guidance
            if self.body:
                sub_messages = [
                    {"role": "system", "content": f"--- Skill Rules: {self.name} ---\n{self.body}\n--- End Rules ---"}
                ] + sub_messages
            else:
                sub_messages = [{"role": "system", "content": f"You are using the '{self.name}' skill."}] + sub_messages
        else:
            sub_messages = [{"role": "user", "content": intent}]

        # Inject error handling rule into EVERY sub-agent's prompt
        # Make the trigger condition very specific to prevent 8B model from
        # hallucinating errors on valid data.
        error_rule = (
            "⚠️ ERROR HANDLING RULE:\n"
            "ONLY call error_handling__analyze_error when a tool output EXPLICITLY starts with '[Error]' or 'Error:'.\n"
            "Do NOT judge whether data 'looks abnormal' or 'format is wrong' — if the tool returned data (even if "
            "unexpected), accept it as valid and use it.\n"
            "Examples of when to use error_handling:\n"
            '  - Tool returns "[Error] Browser not initialized"\n'
            '  - Tool returns "Error: Weather service unavailable"\n'
            "Examples of when NOT to use error_handling:\n"
            "  - Tool returns weather data you didn't expect — use it anyway\n"
            "  - Tool returns a result that seems incomplete but has no error marker — use it\n"
            "  - Tool returns data in a different format than expected — use it\n"
            "If you need to tell the user about a fixable error, call error_handling__report_to_user."
        )
        # Prepend as system message so it's visible before any tool call
        sub_messages.insert(0, {"role": "system", "content": error_rule})

        for step in range(max_steps):
            response = vlm_client.chat(sub_messages, tools=tools_schema)

            # Try to parse tool calls
            tool_calls = self._parse_sub_tool_calls(response)

            if not tool_calls:
                # Plain text response — sub-agent is done.
                # Wrap in [FINAL_ANSWER] so the main agent knows this is the
                # completed result and should respond to the user directly,
                # rather than treating it as another intermediate observation.
                return f"[FINAL_ANSWER]{response}"

            tc = tool_calls[0]  # Sub-agent calls one tool at a time
            full_name = tc["function"]["name"]
            raw_args = tc["function"].get("arguments", {})

            # VLM may return arguments as a JSON string — normalize to dict
            if isinstance(raw_args, str):
                try:
                    args = json.loads(raw_args)
                except json.JSONDecodeError:
                    args = {}
            elif isinstance(raw_args, dict):
                args = raw_args
            else:
                args = {}

            # Resolve the tool — could be from this skill OR a global skill
            if "__" in full_name:
                tool_skill_name, tool_name = full_name.split("__", 1)
                if tool_skill_name == self.name:
                    tool_func = self.tools.get(tool_name)
                elif self._registry:
                    other_skill = self._registry.get(tool_skill_name)
                    tool_func = other_skill.tools.get(tool_name) if other_skill else None
                else:
                    tool_func = None
            else:
                tool_name = full_name
                tool_func = self.tools.get(tool_name)

            if tool_func is None:
                sub_messages.append({"role": "assistant", "content": response})
                sub_messages.append({"role": "user", "content": f"Error: Tool '{full_name}' not found"})
                continue

            try:
                result = tool_func(**args)
                # Handle async results
                if hasattr(result, '__await__'):
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        result = loop.run_until_complete(result)
                    finally:
                        loop.close()
            except Exception as e:
                result = f"Error: {str(e)}"

            # Print sub-agent tool call and result
            if hasattr(self, '_registry') and self._registry:
                from utils.styled_output import print_sub_agent_tool, print_sub_agent_result
                print_sub_agent_tool(full_name, args)
                print_sub_agent_result(str(result))

            result_str = str(result)

            # Any tool returning [FINAL_ANSWER] should be propagated immediately
            # (e.g., error_handling__report_to_user, daily_chat__respond)
            if result_str.startswith("[FINAL_ANSWER]"):
                return result_str

            # Auto-trigger error analysis on first tool failure
            # This removes dependency on 8B model's ability to call error_handling manually
            is_error = result_str.startswith("Error:") or result_str.startswith("[Error]")
            if is_error and not hasattr(self, '_error_analyzed'):
                self._error_analyzed = True
                analyze = self._registry.get('error_handling').tools.get('analyze_error') if self._registry else None
                if analyze:
                    try:
                        analysis = analyze(error_message=result_str, failed_tool=full_name)
                        result_str = f"{result_str}\n\n[Auto error analysis]\n{analysis}"
                    except Exception:
                        pass  # If analyze_error fails, fall through with original error

            # Detect repeated same error — if the same tool fails with the same
            # error max_same_error times, terminate the sub-agent early
            if is_error:
                error_key = f"{full_name}:{result_str}"
                if not hasattr(self, '_error_counts'):
                    self._error_counts = {}
                self._error_counts[error_key] = self._error_counts.get(error_key, 0) + 1
                if self._error_counts[error_key] >= max_same_error:
                    # Terminal error — return a proper FINAL_ANSWER
                    return f"[FINAL_ANSWER]I tried to help but encountered a persistent error: {result_str}"

            sub_messages.append({"role": "assistant", "content": response})
            sub_messages.append({"role": "user", "content": f"Observation: {result_str}"})

        # Max steps reached — return last observation
        last_content = sub_messages[-1]["content"]
        # If the last message is a raw tool call JSON, return an error instead
        # of confusing the main VLM with an unexecuted function call
        try:
            parsed = json.loads(last_content)
            if isinstance(parsed, list) and parsed and parsed[0].get("type") == "function":
                return f"Error: Sub-agent reached max steps ({max_steps}) without completing the task. Last attempted tool: {parsed[0].get('function', {}).get('name', 'unknown')}"
        except (json.JSONDecodeError, TypeError, KeyError):
            pass
        return last_content

    @staticmethod
    def _parse_sub_tool_calls(response: str) -> list[dict]:
        """Parse tool calls from sub-agent VLM response."""
        try:
            data = json.loads(response)
            if not isinstance(data, list) or not data:
                return []
            normalized = []
            for item in data:
                if not isinstance(item, dict):
                    return []
                if "function" in item:
                    normalized.append(item)
                elif item.get("type") == "function" and "arguments" in item:
                    normalized.append(item)
                else:
                    return []
            return normalized
        except (json.JSONDecodeError, TypeError):
            pass
        return []

    def __repr__(self):
        return f"<Skill: {self.name} v{self.version} | tools: {list(self.tools.keys())}>"


# ============================================================
# Default concrete implementation (used when no skill.py exists)
# ============================================================
class DefaultSkill(BaseSkill):
    """Default skill that delegates tool selection to a sub-agent VLM.

    Two-phase execution:
      1. Main VLM selects this skill and passes the user's intent
      2. This skill runs a sub-agent loop: its own VLM call picks the right tool
         from ONLY this skill's tool schemas (not all ~30 tools)
    """

    def execute(self, intent: str, vlm_client=None, messages: list[dict] | None = None, **kwargs) -> Any:
        """Run sub-agent to select and execute the right tool for this intent."""
        if vlm_client is None:
            return f"Error: vlm_client required for skill '{self.name}' execution"
        return self.run_sub_agent(intent, vlm_client, messages=messages)


# ============================================================
# Skill Registry
# ============================================================
class SkillRegistry:
    """Auto-discovers and loads all skills from the skills/ directory."""

    def __init__(self, skills_dir: str):
        """
        Args:
            skills_dir: Path to the skills/ directory containing skill subfolders
        """
        self.skills_dir = Path(skills_dir)
        self.skills: dict[str, BaseSkill] = {}
        self._discover_and_load()

    def _discover_and_load(self):
        """Scan skills_dir for SKILL.md files and load each skill."""
        if not self.skills_dir.exists():
            raise FileNotFoundError(f"Skills directory not found: {self.skills_dir}")

        for skill_folder in sorted(self.skills_dir.iterdir()):
            if not skill_folder.is_dir():
                continue
            md_path = skill_folder / 'SKILL.md'
            if not md_path.exists():
                md_path = skill_folder / 'skill.md'
            if not md_path.exists():
                continue

            try:
                skill_class_path = skill_folder / 'skill.py'
                if skill_class_path.exists():
                    spec = importlib.util.spec_from_file_location(
                        f"skill_{skill_folder.name}", str(skill_class_path)
                    )
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if (isinstance(attr, type) and
                            issubclass(attr, BaseSkill) and
                            attr is not BaseSkill):
                            skill_instance = attr(str(md_path))
                            skill_instance._registry = self  # Wire registry reference
                            self.skills[skill_instance.name] = skill_instance
                            break
                else:
                    skill = DefaultSkill(str(md_path))
                    skill._registry = self  # Wire registry reference
                    self.skills[skill.name] = skill

                print(f"[SkillRegistry] Loaded: {md_path}")
            except Exception as e:
                print(f"[SkillRegistry] Failed to load {md_path}: {e}")

    def get(self, name: str) -> BaseSkill | None:
        """Get a skill by name."""
        return self.skills.get(name)

    def get_all(self) -> list[BaseSkill]:
        """Get all loaded skills."""
        return list(self.skills.values())

    # Names of skills whose tools should be globally available in all sub-agents
    # Memory CRUD: any skill may need to recall context, save discoveries, or clean up
    # Error handling: every sub-agent should be able to recover from tool failures
    GLOBAL_SKILLS = ('memory_recall', 'memory_save', 'memory_delete', 'memory_list', 'error_handling')

    def get_global_tool_schemas(self) -> list[dict]:
        """Return tool schemas for globally-available skills (memory CRUD, etc.).

        These tools are injected into EVERY sub-agent's context so that any skill
        can access memory during execution — e.g., weather_query can call
        memory_recall to resolve an ambiguous city reference.
        """
        global_tools = []
        for skill_name in self.GLOBAL_SKILLS:
            skill = self.skills.get(skill_name)
            if skill:
                global_tools.extend(skill.get_tool_schema())
        return global_tools

    def get_all_schemas(self) -> list[dict]:
        """Return the single top-level tool schema: `use_skill(skill_name, intent)`.

        Two-phase: the main VLM only sees this ONE tool, not all ~30 concrete tools.
        Skill selection narrows the decision space for the sub-agent VLM.
        """
        skill_list = ', '.join(sorted(self.skills.keys()))
        skill_descriptions = '\n'.join(
            f"    - {s.name}: {s.description}"
            for s in sorted(self.skills.values(), key=lambda s: s.name)
        )
        return [{
            "type": "function",
            "function": {
                "name": "use_skill",
                "description": (
                    "Select the skill that best matches the user's intent. "
                    "Pass the full user intent as natural language — the skill will "
                    "internally decide which concrete tool(s) to call.\n\n"
                    f"Available skills:\n{skill_descriptions}"
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "skill_name": {
                            "type": "string",
                            "description": f"Available skills: {skill_list}"
                        },
                        "intent": {
                            "type": "string",
                            "description": (
                                "The user's full intent in natural language, including "
                                "any context from the conversation. This is what the "
                                "skill's sub-agent VLM will see to decide which tool to call."
                            )
                        }
                    },
                    "required": ["skill_name", "intent"]
                }
            }
        }]

    def list_skills(self) -> str:
        """Return a human-readable list of available skills."""
        lines = ["Available Skills:"]
        for s in self.skills.values():
            lines.append(f"  - {s.name} (v{s.version}): {s.description}")
        return '\n'.join(lines)
