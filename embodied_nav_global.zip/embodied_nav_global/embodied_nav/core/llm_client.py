"""
LLM Client Layer

Wraps the local llama-server OpenAI-compatible API for text and vision calls.
"""

import json
import requests
from typing import Optional


class VLMClient:
    """Client for the local llama-server VLM endpoint."""
    
    def __init__(
        self,
        base_url: str,  # Required — no default, must come from config
        model: str = "local-vlm",
        max_tokens: int = 120000,
        temperature: float = 0.7,
    ):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.api_url = f"{self.base_url}/v1/chat/completions"
    
    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> str:
        """Send a chat completion request.
        
        Args:
            messages: OpenAI-format message list
            tools: Optional OpenAI function calling schemas
            max_tokens: Override default max_tokens
            temperature: Override default temperature
            
        Returns:
            Assistant's text response
        """
        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens or self.max_tokens,
            "temperature": temperature if temperature is not None else self.temperature,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        
        try:
            resp = requests.post(self.api_url, json=payload, timeout=120)
            resp.raise_for_status()
            data = resp.json()
            choice = data["choices"][0]
            
            # Check if model returned a tool call
            if choice["message"].get("tool_calls"):
                return json.dumps(choice["message"]["tool_calls"])
            
            return choice["message"]["content"]
        except requests.exceptions.ConnectionError:
            return "[ERROR] Cannot connect to VLM server. Is llama-server running?"
        except Exception as e:
            return f"[ERROR] VLM call failed: {str(e)}"
    
    def chat_with_image(
        self,
        text: str,
        image_path: str,
        system_prompt: str = "You are a helpful visual assistant.",
        max_tokens: Optional[int] = None,
    ) -> str:
        """Send a vision query (text + image).

        Args:
            text: Question about the image
            image_path: Local file path to the image
            system_prompt: System prompt
            max_tokens: Override max tokens (defaults to instance setting)

        Returns:
            VLM's description/answer
        """
        messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": text},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"file://{image_path}"}
                    }
                ]
            }
        ]
        return self.chat(messages, max_tokens=max_tokens)
    
    def health_check(self) -> bool:
        """Check if the VLM server is reachable."""
        try:
            resp = requests.get(f"{self.base_url}/health", timeout=10)
            return resp.status_code == 200
        except:
            return False

    def get_model_name(self) -> str:
        """Query the server for the actual model name."""
        try:
            resp = requests.get(f"{self.base_url}/v1/models", timeout=10)
            resp.raise_for_status()
            data = resp.json()
            if "data" in data and len(data["data"]) > 0:
                model_info = data["data"][0]
                # Use id if available, fallback to meta name
                return model_info.get("id", model_info.get("meta", {}).get("name", self.model))
        except:
            pass
        return self.model
