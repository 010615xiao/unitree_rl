# Embodied Agent

A modular, skill-based embodied AI agent running on a headless server with a local VLM.

## Architecture

```
┌──────────────────────────────────────────┐
│          Interaction Layer (CLI)         │  ← User input/output
├──────────────────────────────────────────┤
│           Decision Layer (Agent)         │  ← ReAct loop, tool routing
├──────────────────────────────────────────┤
│          Memory Layer (Short/Long)       │  ← Conversation + file memory
├──────────────────────────────────────────┤
│   Skill Layer (Pluggable .md + .py)      │  ← Discoverable capabilities
├──────────────────────────────────────────┤
│     Core Layer (LLM Client + Skill)      │  ← VLM API wrapper, base classes
├──────────────────────────────────────────┤
│         llama-server (port 8008)         │  ← Local Qwen3.6-35B VLM
└──────────────────────────────────────────┘
```

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
playwright install chromium  # for browser_control skill
```

### 2. Start the VLM server

```bash
./llama-server \
  -m /workspace/wxd/models/Qwen3.6-35B-A3B-GGUF/Qwen3.6-35B-A3B-UD-Q4_K_M.gguf \
  --mmproj /workspace/wxd/models/Qwen3.6-35B-A3B-GGUF/mmproj-F32.gguf \
  --port 8008 --host 0.0.0.0 \
  --media-path /workspace/wxd/Agent/images \
  --ctx-size 120000 --reasoning-budget 0
```

### 3. Run the agent

```bash
cd agent/embodied_nav
python main.py
```

## Skill System

### Skill Format

Each skill is a folder with two files:

```
skills/my_skill/
├── skill.md    # YAML frontmatter + description (declaration)
└── tools.py    # Python functions (execution)
```

### skill.md Format

```markdown
---
name: my_skill
description: What this skill does
version: 1.0.0
---

# My Skill

Detailed description of capabilities and when to use it.

Tools:
- `tool_name(param)`: What it does
```

### tools.py Format

```python
def tool_name(param: str) -> str:
    """Describe what this tool does.
    
    Args:
        param: Description
        
    Returns:
        Result description
    """
    return f"[my_skill] Result for {param}"
```

### Adding a New Skill

1. Create a folder under `skills/`: `mkdir skills/my_new_skill`
2. Write `skill.md` with frontmatter + description
3. Write `tools.py` with your tool functions
4. Restart the agent — it auto-discovers all skills

**No changes to core code needed.**

## Available Skills

| Skill | Description |
|-------|-------------|
| `daily_chat` | Casual conversation and Q&A |
| `env_description` | Image analysis and environment description via VLM |
| `task_planning` | Decompose goals into step-by-step plans |
| `global_navigation` | Plan global navigation trajectories in reconstructed indoor environments |
| `browser_control` | Real browser automation via Playwright |

## CLI Commands

| Command | Action |
|---------|--------|
| (text) | Send to agent for processing |
| `/skills` | List all available skills |
| `/reset` | Clear conversation history |
| `/quit` | Exit the agent |
| `describe <path>` | Send an image for VLM analysis |

## Directory Structure

```
embodied_nav/
├── core/
│   ├── llm_client.py    # VLM API client
│   └── skill.py         # BaseSkill + SkillRegistry
├── skills/              # All skills (pluggable)
│   ├── daily_chat/
│   ├── env_description/
│   ├── task_planning/
│   ├── global_navigation/
│   └── browser_control/
├── memory/
│   └── memory_manager.py  # Short + long term memory
├── decision/
│   └── agent.py           # ReAct loop + tool routing
├── interaction/
│   └── cli.py             # CLI interface + agent factory
├── config/
│   └── agent.yaml         # Configuration
├── memory/                # Persistent memory files (created at runtime)
├── main.py                # Entry point
└── requirements.txt       # Dependencies
```
