"""recompute_bbox 几何计算回归测试。

修复点：centroid/aabb 改用 live 体素（log_odds>=0）计算，排除已衰减（log_odds<0、
正在被 carve）的体素，避免关联质心被"物体待过的位置"拉偏、AABB 虚胖。落实设计注记
"关联用 live 体素 centroid/aabb" 的意图（旧实现误用全部 owned 体素）。

只导入 incremental.object_tracker，无模块级副作用，可独立运行。
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
from global_reconstruction.incremental.object_tracker import ObjectInstance

VS = 0.05
CFG = {"voxel_valid_log_odds": 0.0}


def _mk(oid, keys_vals):
    """keys_vals: [(key, log_odds), ...]，逐个添加（测试用量小，简单即可）。"""
    inst = ObjectInstance(obj_id=oid, category="box", voxel_size=VS, birth_frame="f0")
    for key, val in keys_vals:
        inst._add_keys(np.array([key], dtype=np.int32), val)
    inst.recompute_bbox(CFG, {})
    return inst


def test_centroid_uses_live_voxels_not_decayed():
    """质心/AABB 只用 live 体素(log_odds>=0)，排除已衰减(log_odds<0)体素。"""
    A = [[0, 0, 40], [1, 0, 40], [0, 1, 40]]         # live(log_odds=2)，中心 x≈0.017
    B = [[100, 0, 40], [101, 0, 40], [100, 1, 40]]    # decayed(log_odds=-1)，中心 x≈5.02
    kv = [(k, 2.0) for k in A] + [(k, -1.0) for k in B]
    inst = _mk(0, kv)
    A_mean_x = float(np.mean([k[0] * VS for k in A]))
    all_mean_x = float(np.mean([k[0] * VS for k in A + B]))
    assert abs(inst.centroid[0] - A_mean_x) < 0.01, \
        f"质心应靠近 live 位置 {A_mean_x:.4f}，而非含衰减的全体素 {all_mean_x:.4f}"
    assert inst.aabb_max[0] < 0.1, "AABB 不应包含已衰减体素所在的 x≈5 区域"
    assert inst.valid_voxel_count == 3, "valid 体素(log_odds>0) 应为 3"


def test_new_instance_keeps_centroid():
    """NEW 实例(init log_odds=0) 仍应有质心(live 含 ==0)，valid_count=0。"""
    inst = _mk(1, [([0, 0, 40], 0.0), ([2, 0, 40], 0.0)])
    assert inst.centroid is not None, "NEW 实例(live 含 log_odds==0) 质心应有定义"
    assert inst.valid_voxel_count == 0


def test_all_decayed_falls_back_to_all_voxels():
    """体素全衰减(无 live) 时质心兜底为全体素均值(非 None)。

    否则 _decay_pass 会因质心 None 跳过该实例，导致 decay->剪除->死亡进程卡死。
    """
    inst = _mk(2, [([0, 0, 40], -1.0), ([2, 0, 40], -1.0)])
    assert inst.centroid is not None, "全衰减实例质心应兜底非 None"


if __name__ == "__main__":
    for fn in [test_centroid_uses_live_voxels_not_decayed,
               test_new_instance_keeps_centroid,
               test_all_decayed_falls_back_to_all_voxels]:
        fn()
        print(f"  ✓ {fn.__name__}")
    print("全部通过")
