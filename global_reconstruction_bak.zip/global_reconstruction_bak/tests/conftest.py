import sys
from pathlib import Path

# 让 tests/ 下的测试能导入项目根目录的 global_reconstruction 包
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
