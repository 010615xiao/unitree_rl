"""save_final_object_lifecycle 的 dominant_state / observation_count 回归测试。

修复点：
  - dominant_state 旧逻辑检查 persisting/occluded/unknown，但 tracker 只产出
    new/candidate/stable/disappeared -> 恒为 disappeared（bug）。改为二值：
    有任一存活实例 -> persisting，否则 disappeared。
  - observation_count 旧读 inst['observation_count']，但 tracker.to_dict 从未写它 -> 恒 0。
    现 to_dict 写 hit_count，读取端并对旧数据回退 len(observed_frames)。

本测试需导入 reconstruct_and_segment（有模块级副作用），故先搭一个最小 standard 数据目录
并设 GLOBAL_RECON_DATA_DIR；若环境无法导入则 skip。
"""
import os
import sys
import json
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np

# ---- 先搭最小数据目录并设 env，再导入有副作用的主模块 ----
def _make_minimal_dataset(root: Path):
    import cv2
    (root / "images").mkdir(parents=True, exist_ok=True)
    (root / "depth").mkdir(parents=True, exist_ok=True)
    with open(root / "camera.yaml", "w") as f:
        f.write("fx: 500.0\nfy: 500.0\ncx: 160.0\ncy: 120.0\n")
    cv2.imwrite(str(root / "images" / "00000.png"), np.zeros((240, 320, 3), np.uint8))
    cv2.imwrite(str(root / "depth" / "00000.png"), np.zeros((240, 320), np.uint16))

_TMP = Path(tempfile.mkdtemp(prefix="ras_test_data_"))
_make_minimal_dataset(_TMP)
os.environ["GLOBAL_RECON_DATA_DIR"] = str(_TMP)

try:
    import global_reconstruction.reconstruction.reconstruct_and_segment as rs
    from global_reconstruction.incremental.object_tracker import ObjectTracker, ObjectInstance
    _IMPORT_OK = True
    _IMPORT_ERR = None
except Exception as e:  # 环境无法导入主模块时跳过（不算失败）
    _IMPORT_OK = False
    _IMPORT_ERR = e

import pytest

VS = 0.05


def _make_instance(oid, category, state, alive, hit_count, frames, voxel_key):
    inst = ObjectInstance(obj_id=oid, category=category, voxel_size=VS, birth_frame=frames[0])
    inst.state = state
    inst.is_alive = alive
    inst.hit_count = hit_count
    inst.observed_frames = list(frames)
    inst._add_keys(np.array([voxel_key], dtype=np.int32), 2.0 if alive else -3.0)
    inst.recompute_bbox({}, {})
    return inst


@pytest.mark.skipif(not _IMPORT_OK, reason=f"主模块导入失败: {_IMPORT_ERR}")
def test_dominant_state_and_observation_count():
    work = Path(tempfile.mkdtemp(prefix="ras_test_work_"))

    # tracker：1 个存活 STABLE 实例 + 1 个 DEAD 实例
    tr = ObjectTracker(voxel_size=VS, config={})
    tr.instances.append(_make_instance(0, "chair", "STABLE", True, 5,
                                       ["f0", "f1", "f2", "f3", "f4"], [0, 0, 40]))
    tr.instances.append(_make_instance(1, "cup", "DEAD", False, 2,
                                       ["f0", "f1"], [10, 0, 40]))
    tr._next_id = 2
    tr.save(work / "lifecycle")  # -> work/lifecycle/object_instances.json

    # 先验证 to_dict 写出的字段（Fix A 的数据基础）
    data = json.loads((work / "lifecycle" / "object_instances.json").read_text())
    objs = {o["obj_id"]: o for o in data["objects"]}
    assert objs[0]["observation_count"] == 5
    assert objs[0]["current_state"] == "stable" and objs[0]["is_alive"] is True
    assert objs[1]["observation_count"] == 2
    assert objs[1]["current_state"] == "disappeared" and objs[1]["is_alive"] is False

    # 三个最终物体：仅存活 / 仅死亡 / 混合
    pts = np.zeros((3, 3), np.float32)
    final_objects = [
        {"name": "chair_0", "category": "chair", "id": 0, "points": pts, "source_instance_ids": [0]},
        {"name": "cup_0", "category": "cup", "id": 1, "points": pts, "source_instance_ids": [1]},
        {"name": "mix_0", "category": "mix", "id": 2, "points": pts, "source_instance_ids": [0, 1]},
    ]

    rs.save_final_object_lifecycle(final_objects, work)
    out = json.loads((work / "final_object_lifecycle" / "final_object_instances.json").read_text())
    recs = {r["final_object_id"]: r for r in out["objects"]}

    # 仅存活 -> persisting, obs=5
    assert recs[0]["dominant_state"] == "persisting", f"仅存活应为 persisting, got {recs[0]['dominant_state']}"
    assert recs[0]["observation_count"] == 5
    # 仅死亡 -> disappeared, obs=2
    assert recs[1]["dominant_state"] == "disappeared", f"仅死亡应为 disappeared, got {recs[1]['dominant_state']}"
    assert recs[1]["observation_count"] == 2
    # 混合(含存活) -> persisting, obs=max(5,2)=5
    assert recs[2]["dominant_state"] == "persisting", f"含存活应为 persisting, got {recs[2]['dominant_state']}"
    assert recs[2]["observation_count"] == 5


if __name__ == "__main__":
    if not _IMPORT_OK:
        print(f"跳过（主模块导入失败）: {_IMPORT_ERR}")
        sys.exit(0)
    test_dominant_state_and_observation_count()
    print("  ✓ test_dominant_state_and_observation_count")
    print("全部通过")
