"""ObjectTracker 自由空间 carving 行为回归测试。

只导入 incremental.object_tracker —— 无模块级副作用，不依赖数据目录或外部服务，
可直接 `pytest tests/` 或 `python tests/test_tracker_decay.py` 运行。

覆盖（均对应一次真实 bug 修复，防止回归）：
  1. matched 实例的自由空间体素应被 carve —— 修复"移动物体体素残影"
     （旧实现用 `if id(inst) in matched_inst_ids: continue` 整段跳过 matched 实例，
      注释谎称已在不存在的 integrate_observation 里 decay；别把该 skip 当优化加回来）
  2. carve 四情形：matched+自由空间 / matched+遮挡 / matched+已claim / unmatched+自由空间
     —— 只 carve"可见且自由空间且未 claim"的体素，不误伤遮挡/已 claim/不可见
  3. 部分可见的大物体（质心出画）其可见体素应被 carve —— 放宽视野门控后的行为
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
from global_reconstruction.incremental.object_tracker import ObjectTracker, ObjectInstance

VS = 0.05
# 相机在世界原点朝 +Z；f=100, 主点 (50,50), 100x100 图像
K = np.array([[100, 0, 50], [0, 100, 50], [0, 0, 1]], dtype=float)
T_C2W = np.eye(4)


def _make_tracker():
    return ObjectTracker(voxel_size=VS, config={})  # 空 config -> _decay_pass 用内置默认


def _add_instance(tr, oid, keys, log_odds_val, category="box"):
    inst = ObjectInstance(obj_id=oid, category=category, voxel_size=VS,
                          birth_frame="f0", creation_tick=0)
    inst._add_keys(np.array(keys, dtype=np.int32), log_odds_val)
    inst.recompute_bbox(tr.config, tr.voxel_owner)
    for k in keys:
        tr.voxel_owner[(int(k[0]), int(k[1]), int(k[2]))] = oid
    tr.instances.append(inst)
    tr._next_id = max(tr._next_id, oid + 1)
    return inst


def test_matched_instance_free_space_is_carved():
    """matched 实例本帧被关联，但旧位置体素处于自由空间 -> 应被 carve（不再残影）。"""
    tr = _make_tracker()
    inst = _add_instance(tr, 0, [[0, 0, 40], [1, 0, 40], [0, 1, 40]], 1.0)
    depth = np.full((100, 100), 5.0, dtype=np.float32)  # 远背景 -> z=2 体素为自由空间
    claims = {0: {(-99, -99, -99)}}  # matched（obj_id 在 claims），但旧体素未被 claim
    before = inst.log_odds.copy()
    tr._decay_pass(depth, K, T_C2W, None, 0.0, "f1", 1, claims, tr.config, set(), {0: inst})
    assert np.all(inst.log_odds < before - 1e-6), "matched 实例的自由空间体素应被 carve"


def test_decay_carve_four_cases():
    """carve 只发生在'可见 + 自由空间 + 未 claim'的体素，不误伤遮挡/已 claim/不可见。"""
    tr = _make_tracker()
    # 四个体素 z=2、不同 x -> 投影 u = 50/70/30/90
    inst0 = _add_instance(tr, 0, [[0, 0, 40]], 1.0)    # u=50 自由, matched 未 claim -> carve
    inst1 = _add_instance(tr, 1, [[8, 0, 40]], 1.0)    # u=70 遮挡(深度=1.0), matched -> 不 carve
    inst2 = _add_instance(tr, 2, [[-8, 0, 40]], 1.0)   # u=30 自由, matched 且已 claim -> 不 carve
    inst3 = _add_instance(tr, 3, [[16, 0, 40]], 1.0)   # u=90 自由, unmatched -> carve
    depth = np.full((100, 100), 5.0, dtype=np.float32)
    depth[50, 70] = 1.0  # inst1 像素处放近处遮挡物
    claims = {0: {(-99, -99, -99)}, 1: {(-99, -99, -99)}, 2: {(-8, 0, 40)}}
    insts = [inst0, inst1, inst2, inst3]
    before = {i: inst.log_odds.copy() for i, inst in enumerate(insts)}
    idmap = {inst.obj_id: inst for inst in insts}
    tr._decay_pass(depth, K, T_C2W, None, 0.0, "f1", 1, claims, tr.config, set(), idmap)
    after = {i: inst.log_odds.copy() for i, inst in enumerate(insts)}
    carved = lambda i: bool(np.all(after[i] < before[i] - 1e-6))
    assert carved(0), "inst0 matched+自由空间 应 carve"
    assert not carved(1), "inst1 matched+遮挡 不应 carve"
    assert not carved(2), "inst2 matched+已 claim 不应 carve"
    assert carved(3), "inst3 unmatched+自由空间 应 carve"


def test_partial_view_large_object_carved():
    """质心出画但部分体素可见的大物体：可见自由空间体素应被 carve，不可见体素不动。"""
    tr = _make_tracker()
    # x=0 画内(u=50)；x≈2.0~2.15 画外。质心 x≈1.66 -> u≈133 出画
    inst = _add_instance(tr, 0, [[0, 0, 40], [40, 0, 40], [41, 0, 40], [42, 0, 40], [43, 0, 40]],
                         1.0, category="sofa")
    u0 = 100 * inst.centroid[0] / inst.centroid[2] + 50
    assert u0 > 100, "测试前提：质心应出画"
    depth = np.full((100, 100), 5.0, dtype=np.float32)
    before = inst.log_odds.copy()
    tr._decay_pass(depth, K, T_C2W, None, 0.0, "f1", 1, {}, tr.config, set(), {0: inst})  # unmatched
    assert inst.log_odds[0] < before[0] - 1e-6, "画内体素(x=0) 应被 carve"
    assert np.all(inst.log_odds[1:] == before[1:]), "画外体素不应受影响"


if __name__ == "__main__":
    for fn in [test_matched_instance_free_space_is_carved,
               test_decay_carve_four_cases,
               test_partial_view_large_object_carved]:
        fn()
        print(f"  ✓ {fn.__name__}")
    print("全部通过")
