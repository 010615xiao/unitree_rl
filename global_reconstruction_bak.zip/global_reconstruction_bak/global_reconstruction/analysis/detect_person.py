#!/usr/bin/env python3
"""
person检测与分割脚本

VLM + SAM3
1. VLM 检测图片中是否有人
2. SAM3 文本分割生成人体掩码 (text prompt → masks + boxes)
3. 将掩码反投影为 3D 点云
4. 输出到 unified_output/person/ 目录:
   - {frame}_original.png      原图
   - {frame}_mask.png          掩码
   - {frame}_overlay.png       原图+掩码叠加
   - {frame}_points.ply        3D 点云
   - {frame}_info.json         元信息 (帧号,点数,框坐标等)
"""

import sys
import json
import base64
import os
import numpy as np
import cv2
import open3d as o3d
import requests
from pathlib import Path

from global_reconstruction.core.data_adapter import DatasetAdapter
from global_reconstruction.core.config_loader import get_config, model_path, project_root, service_url
from global_reconstruction.reconstruction.reconstruct_and_segment import (
    load_poses,
    image_to_base64,
    clean_json_output,
    sam3_segment,
    mask_to_3d_points,
    SAM3_URL,
)

# ================= 配置 =================
cfg = get_config()

BASE_DIR = project_root()
DATA_DIR = Path(os.environ.get("GLOBAL_RECON_DATA_DIR", cfg.data.default_dir))

VLM_API_URL = service_url('vlm_api_url')

# 输出目录
OUTPUT_DIR = BASE_DIR / cfg.output.base_dir / cfg.output.person_output_subdir

# 点云参数
DEPTH_MIN = cfg.reconstruction.depth_min
DEPTH_MAX = cfg.reconstruction.depth_max

import global_reconstruction.reconstruction.reconstruct_and_segment as rs_module
rs_module.DEPTH_MIN = DEPTH_MIN
rs_module.DEPTH_MAX = DEPTH_MAX
VOXEL_SIZE = cfg.reconstruction.voxel_size

# 跳帧: 每 N 帧检测一次
DETECTION_INTERVAL = cfg.person_detection.detection_interval

# VLM 检测参数
VLM_MODEL = model_path('vlm_model_legacy')
VLM_MAX_TOKENS = cfg.person_detection.max_tokens
VLM_TEMPERATURE = cfg.person_detection.temperature


def vlm_check_person(image_path):
    """
    VLM 检测图片中是否有人

    返回:
        has_person: bool
        confidence: float 0-1
    """
    prompt = """You are a person detection assistant. Analyze the provided image and determine if there is at least one person (human) visible.

## Output Format (MANDATORY)
Output ONLY a valid JSON object with this exact structure:
{"has_person":true,"confidence":0.95}

## Rules
- has_person: true if ANY human/person is clearly visible (full body or partial)
- confidence: 0.9-1.0 = clearly visible full/partial person; 0.6-0.89 = person partially visible; 0.0-0.59 = no person or too uncertain
- Consider reflections, shadows, and partial occlusions
- Do NOT count photos of people, TV screens, posters, etc.
- If no person is visible, set has_person to false and confidence to 0.0

Output ONLY the JSON object NOW:"""

    try:
        image_b64 = image_to_base64(image_path)

        payload = {
            "model": VLM_MODEL,
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}},
                    {"type": "text", "text": prompt}
                ]
            }],
            "max_tokens": VLM_MAX_TOKENS,
            "temperature": VLM_TEMPERATURE,
            "stream": False,
        }

        response = requests.post(VLM_API_URL, json=payload, timeout=60)
        response.raise_for_status()

        result = response.json()
        content = result['choices'][0]['message']['content'].strip()
        content = clean_json_output(content)
        parsed = json.loads(content)

        has_person = bool(parsed.get('has_person', False))
        confidence = float(parsed.get('confidence', 0.0))

        return has_person, confidence

    except Exception as e:
        print(f"  VLM person check failed: {e}")
        return False, 0.0


def visualize_person_mask(image_rgb, mask_2d, frame_name, output_dir):
    """
    保存原图、掩码、叠加图

    参数:
        image_rgb: RGB 图像 (H, W, 3)
        mask_2d: 二值掩码 (H, W), 0/255
        frame_name: 帧名称 (用于文件名)
        output_dir: 输出目录
    """
    height, width = image_rgb.shape[:2]

    # 1. 原图
    original_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    original_path = output_dir / f"{frame_name}_original.png"
    cv2.imwrite(str(original_path), original_bgr)

    # 2. 掩码图
    mask_visual = np.ones((height, width, 3), dtype=np.uint8) * 255
    mask_binary = (mask_2d > 128)
    mask_visual[mask_binary] = 0
    mask_path = output_dir / f"{frame_name}_mask.png"
    cv2.imwrite(str(mask_path), mask_visual)

    # 3. 叠加图
    overlay = image_rgb.copy()
    if mask_binary.any():
        red_tint = np.array([255, 50, 50], dtype=np.float32)
        highlighted = overlay[mask_binary].astype(np.float32)
        overlay[mask_binary] = np.clip(0.5 * highlighted + 0.5 * red_tint, 0, 255).astype(np.uint8)

        mask_uint8 = mask_binary.astype(np.uint8) * 255
        contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        overlay_bgr_for_contour = cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR)
        cv2.drawContours(overlay_bgr_for_contour, contours, -1, (0, 255, 0), 2)
        overlay = cv2.cvtColor(overlay_bgr_for_contour, cv2.COLOR_BGR2RGB)

    overlay_path = output_dir / f"{frame_name}_overlay.png"
    cv2.imwrite(str(overlay_path), cv2.cvtColor(overlay, cv2.COLOR_RGB2BGR))

    return {
        'original': str(original_path),
        'mask': str(mask_path),
        'overlay': str(overlay_path),
    }


def save_pointcloud(points_3d, frame_name, output_dir):
    """保存 3D 点云为 PLY 文件"""
    if len(points_3d) == 0:
        return None

    # 体素下采样
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points_3d)

    colors = np.ones((len(points_3d), 3)) * [1.0, 0.2, 0.2]
    pcd.colors = o3d.utility.Vector3dVector(colors)

    # 下采样去噪
    pcd = pcd.voxel_down_sample(VOXEL_SIZE)

    ply_path = output_dir / f"{frame_name}_points.ply"
    o3d.io.write_point_cloud(str(ply_path), pcd, write_ascii=False, compressed=True)

    return str(ply_path), len(pcd.points)


def check_services():
    """检查 VLM, SAM3 服务是否可用"""
    ok = True

    # VLM
    try:
        r = requests.post(VLM_API_URL, json={
            "model": VLM_MODEL,
            "messages": [{"role": "user", "content": [{"type": "text", "text": "test"}]}],
            "max_tokens": 10,
        }, timeout=5)
        # 200 = healthy; 400 = service running but rejected bad input (also OK)
        if r.status_code in (200, 400):
            print(f"  ✓ VLM")
        else:
            print(f"  ✗ VLM (HTTP {r.status_code})")
            ok = False
    except Exception as e:
        print(f"  ✗ VLM ({str(e)[:50]})")
        ok = False

    # SAM3
    sam3_health = SAM3_URL.rsplit('/', 1)[0] + '/health'
    try:
        r = requests.get(sam3_health, timeout=5)
        if r.status_code == 200:
            print(f"  ✓ SAM3")
        else:
            print(f"  ✗ SAM3 (HTTP {r.status_code})")
            ok = False
    except Exception as e:
        print(f"  ✗ SAM3 ({str(e)[:50]})")
        ok = False

    return ok


def main():
    print("=" * 70)
    print("人体检测与分割 (VLM + SAM3)")
    print("=" * 70)

    OUTPUT_DIR.mkdir(exist_ok=True, parents=True)

    # 检查服务
    print("\n[0] 检查服务连接...")
    if not check_services():
        print("\n错误: 部分服务不可用,请确保 VLM, SAM3 已启动")
        sys.exit(1)

    # 初始化数据适配器
    print("\n[1] 初始化数据适配器...")
    adapter = DatasetAdapter(DATA_DIR)
    adapter.print_info()

    K = adapter.K
    poses = load_poses(adapter.poses_file)
    depth_files = adapter.get_depth_file_list()
    file_to_pose = adapter.build_pose_timestamp_map(poses)

    print(f"  位姿: {len(poses)} 个")
    print(f"  深度图: {len(depth_files)} 个")
    print(f"  检测间隔: 每 {DETECTION_INTERVAL} 帧")

    # 遍历帧
    print("\n[2] 开始检测人体...")
    person_count = 0
    total_frames = 0

    for i, depth_file in enumerate(depth_files):
        if i % DETECTION_INTERVAL != 0:
            continue

        timestamp_str = depth_file.stem
        if timestamp_str not in file_to_pose:
            continue
        pose_timestamp = file_to_pose[timestamp_str]
        if pose_timestamp not in poses:
            continue

        # 读取深度图
        depth = adapter.load_depth(depth_file, target_resolution=adapter.rgb_resolution)
        if depth is None:
            continue

        if depth.dtype == np.uint16:
            depth = depth.astype(np.float32) / 1000.0
        elif depth.dtype == np.uint8:
            depth = depth.astype(np.float32)

        # 读取彩色图
        color_file = adapter.match_color_file(pose_timestamp)
        if color_file is None:
            continue

        color = cv2.imread(str(color_file))
        if color is None:
            continue
        color = cv2.cvtColor(color, cv2.COLOR_BGR2RGB)

        if color.shape[:2] != depth.shape:
            color = cv2.resize(color, (depth.shape[1], depth.shape[0]))

        total_frames += 1
        frame_name = f"frame_{i:05d}"

        # Step 1: VLM 检测是否有人
        has_person, vlm_confidence = vlm_check_person(color_file)

        if not has_person:
            print(f"  [{i}/{len(depth_files)}] {frame_name}: 无人 (VLM confidence={vlm_confidence:.2f})")
            continue

        print(f"  [{i}/{len(depth_files)}] {frame_name}: 检测到人体 (VLM confidence={vlm_confidence:.2f})")

        # Step 2: SAM3 文本分割人体 (text prompt → masks + boxes，一次调用替代旧的 GroundingDINO+SAM2 两步)
        masks = sam3_segment(color_file, "person")
        if not masks:
            print(f"    SAM3: 未生成人体掩码")
            continue

        print(f"    SAM3: {len(masks)} 个掩码")
        masks = masks[:3]

        # Step 4: 每个掩码反投影为 3D 点云并保存
        T_c2w = poses[pose_timestamp]

        for j, mask_data in enumerate(masks):
            mask_2d = mask_data['mask']
            box = mask_data['box']
            score = mask_data.get('score', 0.0)

            # SAM3 可能返回与彩色图不同分辨率的掩码，统一到彩色图尺寸（box 同步缩放）
            if mask_2d.shape[:2] != color.shape[:2]:
                mh, mw = mask_2d.shape[:2]
                ch, cw = color.shape[:2]
                mask_2d = cv2.resize(mask_2d.astype(np.float32), (cw, ch),
                                     interpolation=cv2.INTER_NEAREST).astype(np.uint8)
                if box is not None and len(box) == 4:
                    sx, sy = cw / mw, ch / mh
                    box = [box[0] * sx, box[1] * sy, box[2] * sx, box[3] * sy]

            # 2D -> 3D
            points_3d = mask_to_3d_points(mask_2d, depth, K, T_c2w)

            if len(points_3d) < 50:
                print(f"    掩码 {j}: 3D 点数不足 ({len(points_3d)} < 50), 跳过")
                continue

            instance_name = f"{frame_name}_person_{j}"
            person_count += 1

            # 保存可视化
            vis_paths = visualize_person_mask(color, mask_2d, instance_name, OUTPUT_DIR)

            # 保存点云
            pc_result = save_pointcloud(points_3d, instance_name, OUTPUT_DIR)

            # 保存元信息
            info = {
                'frame_index': i,
                'frame_name': frame_name,
                'instance_name': instance_name,
                'vlm_confidence': round(vlm_confidence, 3),
                'sam3_score': round(score, 3),
                'bbox': [int(round(x)) for x in box],
                'mask_area_pixels': int((mask_2d > 128).sum()),
                'point_cloud_3d_points': len(points_3d),
                'point_cloud_downsampled': pc_result[1] if pc_result else 0,
                'files': vis_paths,
                'point_cloud_file': pc_result[0] if pc_result else None,
                'camera_pose_timestamp': pose_timestamp,
            }

            info_path = OUTPUT_DIR / f"{instance_name}_info.json"
            with open(info_path, 'w', encoding='utf-8') as f:
                json.dump(info, f, indent=2, ensure_ascii=False)

            print(f"    ✓ {instance_name}: {len(points_3d)} 3D 点, {pc_result[1] if pc_result else 0} 下采样后点")

    print("\n" + "=" * 70)
    print(f"检测完成")
    print(f"  总检测帧数: {total_frames}")
    print(f"  检测到人体帧数: {person_count}")
    print(f"  输出目录: {OUTPUT_DIR}")
    print("=" * 70)


if __name__ == "__main__":
    main()
