"""Object-level incremental scene graph updates."""

from global_reconstruction.incremental.visibility_visualizer import (
    visualize_visibility,
    load_visibility_viz_config,
)
