"""Visibility detection and reprojection visualization for historical objects.

This module handles:
- Geometric projection-based visibility filtering
- Distance-based visibility culling
- Side-by-side visualization of historical objects vs current detections
- Per-frame structured visibility records (JSON) for lifecycle tracking
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np


# ================= Config Loading =================

def load_visibility_viz_config(cfg: dict[str, Any]) -> dict[str, Any]:
    """Load visibility visualization config from the main config dict.

    Args:
        cfg: Full config dict (from config.yaml)

    Returns:
        Dict with visibility viz parameters
    """
    viz_cfg = dict(cfg.get('object_segmentation', {}).get('visibility_viz', {}) or {})
    return {
        'enabled': bool(viz_cfg.get('enabled', False)),
        'point_size': int(viz_cfg.get('projected_point_size', 3)),
        'mask_alpha': float(viz_cfg.get('mask_alpha', 0.45)),
        'max_points_per_obj': int(viz_cfg.get('max_points_per_object', 8000)),
        'max_distance': float(viz_cfg.get('max_visible_distance', 6.0)),
        'merge_centroid_distance': float(viz_cfg.get('merge_centroid_distance', 0.5)),
        # State detection
        'state_detection_enabled': bool(viz_cfg.get('state_detection_enabled', False)),
        'depth_tolerance': float(viz_cfg.get('depth_tolerance', 0.15)),
        'min_valid_samples': int(viz_cfg.get('min_valid_samples', 20)),
        'persist_ratio_threshold': float(viz_cfg.get('persist_ratio_threshold', 0.5)),
        'valid_ratio_threshold': float(viz_cfg.get('valid_ratio_threshold', 0.5)),
        'miss_death_threshold': int(viz_cfg.get('miss_death_threshold', 5)),
    }


# ================= Helper Functions =================

def _generate_distinct_colors(n: int):
    """Generate n visually distinct BGR colors using golden-angle HSV spacing."""
    if n == 0:
        return []
    colors = []
    golden_angle = 137.508
    for i in range(n):
        hue = (i * golden_angle) % 360
        hsv = np.uint8([[[int(hue / 2), 200, 230]]])
        bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)[0, 0]
        colors.append((int(bgr[0]), int(bgr[1]), int(bgr[2])))
    return colors


# ================= Visibility Filtering =================

def filter_visible_objects(
    all_objects: list,
    K: np.ndarray,
    T_c2w: np.ndarray,
    depth: np.ndarray,
    max_distance: float = 6.0,
    min_visible_ratio: float = 0.20,
    state_results: list | None = None,
    dead_object_indices: set | None = None,
):
    """Filter objects by geometric projection visibility.

    Returns:
        visible_items: list of (obj_idx, obj) tuples for visible objects
        visibility_records: list of per-object visibility records

    Note:
        obj_idx 是 all_objects 列表的索引，用于数组访问。
        稳定 ID 存储在 visibility_records 的 'stable_id' 字段中。
        state_results 用于底部统计栏显示 live/occluded/miss/unknown 状态。
        dead_object_indices 包含 miss_count >= 5 (is_alive == False) 的物体索引，
        这些物体不应再被投影，即使相机回到它们的位置。
    """
    h, w = depth.shape[:2]
    T_w2c = np.linalg.inv(T_c2w)
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    _STRUCTURAL_CATS = {'floor', 'wall', 'ceiling'}
    visible_items = []
    visibility_records = []

    # dead_object_indices contains obj_idx of objects with miss_count >= 5 (is_alive == False)
    # These objects should not be re-projected even if camera returns to their position
    if dead_object_indices is None:
        dead_object_indices = set()

    for obj_idx, obj in enumerate(all_objects):
        pts = obj['points']
        if len(pts) == 0:
            continue

        cat = obj.get('category', '')
        if cat in _STRUCTURAL_CATS:
            continue

        # Skip dead objects (miss_count >= 5) — they should not be re-projected
        if obj_idx in dead_object_indices:
            continue

        pts_hom = np.hstack([pts, np.ones((len(pts), 1))])
        pts_cam = (T_w2c @ pts_hom.T).T[:, :3]
        in_front = pts_cam[:, 2] > 0.1
        pts_in_front = pts_cam[in_front]
        if len(pts_in_front) == 0:
            continue

        obj_center_cam = pts_in_front.mean(axis=0)
        obj_distance = float(np.linalg.norm(obj_center_cam))
        if obj_distance > max_distance:
            continue

        z = pts_in_front[:, 2]
        u = (pts_in_front[:, 0] * fx / z + cx).astype(np.int32)
        v = (pts_in_front[:, 1] * fy / z + cy).astype(np.int32)
        in_image = (u >= 0) & (u < w) & (v >= 0) & (v < h)
        visible_ratio = float(np.sum(in_image)) / len(pts)
        if visible_ratio < min_visible_ratio:
            continue

        visible_items.append((obj_idx, obj))

        # 使用 _merge_id 作为稳定 ID（M-prefix 格式，如 "M2"）
        stable_id = obj.get('_merge_id', f'M{obj_idx}')

        centroid_world = obj.get('_centroid', pts.mean(axis=0))
        visibility_records.append({
            'obj_idx': int(obj_idx),      # 数组索引，用于访问
            'stable_id': stable_id,       # 稳定 ID（M-prefix），用于显示
            'category': cat,
            'centroid_3d': centroid_world.tolist(),
            'distance': obj_distance,
            'visible_ratio': round(visible_ratio, 4),
            'point_count': int(len(pts)),
            'merged_from': obj.get('_merged_from', [obj.get('_det_id', f'D{obj_idx}')]),
        })

    return visible_items, visibility_records


# ================= Main Visualization =================

def visualize_visibility(
    color_bgr: np.ndarray,
    K: np.ndarray,
    T_c2w: np.ndarray,
    depth: np.ndarray,
    all_objects: list,
    current_detections: list,
    frame_id: str,
    output_dir: Path,
    point_size: int = 3,
    mask_alpha: float = 0.45,
    max_points_per_obj: int = 8000,
    max_distance: float = 6.0,
    state_results: list | None = None,
    dead_object_indices: set | None = None,
):
    """左侧=当前帧应可见的历史物体反投影，右侧=当前帧检测掩码。

    左侧通过几何投影过滤物体（中心在相机前方、投影落在图像范围内、距离不超过阈值）。

    Args:
        color_bgr: 当前帧 BGR 图像 (H,W,3)
        K: 3x3 内参矩阵
        T_c2w: 4x4 相机到世界坐标变换
        depth: 当前帧深度图 (H,W) float32, 单位米
        all_objects: 已累积的所有物体列表 (含 'points', 'category')
        current_detections: 当前帧检测结果列表 (含 'mask', 'category', 'score')
        frame_id: 帧标识符
        output_dir: 输出目录
        point_size: 投影点正方形填充的半边长 (像素)
        mask_alpha: 掩码叠加透明度
        max_points_per_obj: 每个物体最大投影点数 (随机采样)
        max_distance: 物体距相机最大可见距离 (米)，超过视为不可见
        state_results: 可选，状态检测结果列表 (含 'obj_idx', 'state')，用于在统计栏显示 live/occluded/miss/unknown 物体
        dead_object_indices: 可选，miss_count >= 5 (is_alive == False) 的物体索引集合，这些物体不应再被投影
    """
    h, w = color_bgr.shape[:2]
    T_w2c = np.linalg.inv(T_c2w)
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    # ---- 可见性过滤：只保留当前帧应可见的物体 ----
    _MIN_VISIBLE_RATIO = 0.20  # 物体至少 20% 的点云在当前帧可见才投影
    visible_items, visibility_records = filter_visible_objects(
        all_objects=all_objects,
        K=K,
        T_c2w=T_c2w,
        depth=depth,
        max_distance=max_distance,
        min_visible_ratio=_MIN_VISIBLE_RATIO,
        state_results=state_results,
        dead_object_indices=dead_object_indices,
    )

    # ---- 左侧：可见历史物体反投影 ----
    left = color_bgr.copy()

    if len(visible_items) > 0:
        obj_colors = _generate_distinct_colors(len(visible_items))

        for vis_idx, (obj_idx, obj) in enumerate(visible_items):
            pts_world = obj['points']
            if len(pts_world) > max_points_per_obj:
                indices = np.random.choice(len(pts_world), max_points_per_obj, replace=False)
                pts_world = pts_world[indices]

            # 世界 → 相机
            pts_hom = np.hstack([pts_world, np.ones((len(pts_world), 1))])
            pts_cam = (T_w2c @ pts_hom.T).T[:, :3]

            # 过滤相机后方
            in_front = pts_cam[:, 2] > 0.1
            pts_cam = pts_cam[in_front]
            if len(pts_cam) == 0:
                continue

            # 投影到图像
            z_cam = pts_cam[:, 2]
            u = (pts_cam[:, 0] * fx / z_cam + cx).astype(np.int32)
            v = (pts_cam[:, 1] * fy / z_cam + cy).astype(np.int32)

            # 过滤图像范围外
            valid = (u >= 0) & (u < w) & (v >= 0) & (v < h)
            u, v = u[valid], v[valid]
            if len(u) == 0:
                continue

            bgr = obj_colors[vis_idx]
            r = point_size
            # Vectorized: set (2r+1)x(2r+1) block per point via meshgrid + fancy indexing
            offs = np.arange(-r, r + 1)
            dv, du = np.meshgrid(offs, offs, indexing='ij')  # (2r+1, 2r+1)
            vv = (v[:, None, None] + dv[None]).ravel()       # (N*(2r+1)^2,)
            uu = (u[:, None, None] + du[None]).ravel()
            vmask = (vv >= 0) & (vv < h) & (uu >= 0) & (uu < w)
            left[vv[vmask], uu[vmask]] = bgr

            # 2D 边界框：从投影点计算
            x_min, x_max = int(u.min()), int(u.max())
            y_min, y_max = int(v.min()), int(v.max())
            cv2.rectangle(left, (x_min, y_min), (x_max, y_max), bgr, 1)

            # 将 bbox 写入可见性记录
            if vis_idx < len(visibility_records):
                visibility_records[vis_idx]['bbox_2d'] = [x_min, y_min, x_max, y_max]

            # 标签：物体稳定 ID + 类别
            # 使用 stable_id 确保同一物体在不同帧中编号一致
            stable_id = visibility_records[vis_idx].get('stable_id', obj_idx) if vis_idx < len(visibility_records) else obj_idx
            lx, ly = x_max + 4, y_min - 4
            label = f"#{stable_id} {obj['category'][:8]}"
            cv2.putText(left, label, (lx, max(12, ly)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, bgr, 1, cv2.LINE_AA)

    # ---- 右侧：当前帧检测掩码 ----
    right = color_bgr.copy()

    if len(current_detections) > 0:
        det_colors = _generate_distinct_colors(len(current_detections))

        for det_idx, det in enumerate(current_detections):
            mask = det['mask']
            if mask is None:
                continue

            if mask.shape[:2] != (h, w):
                mask = cv2.resize(mask.astype(np.float32), (w, h),
                                  interpolation=cv2.INTER_NEAREST)
            mask_bool = mask > 128

            bgr = det_colors[det_idx]
            color_layer = np.zeros_like(right)
            color_layer[mask_bool] = bgr
            right[mask_bool] = (
                right[mask_bool].astype(np.float32) * (1.0 - mask_alpha)
                + color_layer[mask_bool].astype(np.float32) * mask_alpha
            ).astype(np.uint8)

            mask_uint8 = mask_bool.astype(np.uint8) * 255
            contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(right, contours, -1, bgr, 2)

            ys, xs = np.where(mask_bool)
            if len(xs) > 0:
                cx_det, cy_det = int(xs.mean()), int(ys.mean())
                score = det.get('score', 0)
                label = f"#{det_idx} {det['category'][:8]} ({score:.2f})"
                cv2.putText(right, label, (cx_det + 4, cy_det - 4),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.35, bgr, 1, cv2.LINE_AA)

    # ---- 合并左右 + 标注 ----
    separator = np.ones((h, 2, 3), dtype=np.uint8) * 128
    combined = np.hstack([left, separator, right])

    # 顶部标题栏
    bar_h = 28
    bar = np.ones((bar_h, combined.shape[1], 3), dtype=np.uint8) * 40
    cv2.putText(bar, f"Frame: {frame_id}", (8, 19),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
    left_title_x = w // 2 - 140
    cv2.putText(bar, f"Visible History ({len(visible_items)}/{len(all_objects)})", (left_title_x, 19),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (100, 220, 255), 1, cv2.LINE_AA)
    right_title_x = w + 2 + w // 2 - 80
    cv2.putText(bar, f"Current Detections ({len(current_detections)})", (right_title_x, 19),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (100, 255, 150), 1, cv2.LINE_AA)

    combined = np.vstack([bar, combined])

    # 底部统计栏（多行自动换行）
    _FONT = cv2.FONT_HERSHEY_SIMPLEX
    _FONT_SCALE = 0.35
    _LINE_H = 16          # 每行高度（像素）
    _PAD_TOP = 4           # 首行顶部内边距
    _PAD_BOT = 4           # 末行底部内边距
    _TEXT_COLOR = (200, 200, 200)
    _MARGIN_X = 8          # 左边距

    visible_cats = set(obj['category'] for _, obj in visible_items)
    summary_text = (f"Total objects: {len(all_objects)} | "
                    f"Visible: {len(visible_items)} ({len(visible_cats)} cats) | "
                    f"Detections: {len(current_detections)}")

    # 构建状态分段列表，每个元素 (label, items_str) 用于智能换行
    state_segments: list[tuple[str, str]] = []
    if state_results is not None and len(state_results) > 0:
        persisting_items = []
        occluded_items = []
        disappeared_items = []
        unknown_items = []
        for result in state_results:
            obj_idx = result.get('obj_idx')
            state = result.get('state', '')
            category = all_objects[obj_idx]['category'] if obj_idx < len(all_objects) else '?'
            if obj_idx < len(all_objects):
                stable_id = all_objects[obj_idx].get('_merge_id', f'M{obj_idx}')
            else:
                stable_id = f'M{obj_idx}'
            item_str = f"#{stable_id} {category}"
            if state == 'persisting':
                persisting_items.append(item_str)
            elif state == 'occluded':
                occluded_items.append(item_str)
            elif state == 'disappeared':
                disappeared_items.append(item_str)
            elif state == 'unknown':
                unknown_items.append(item_str)

        if persisting_items:
            state_segments.append(("Live", ", ".join(persisting_items)))
        if occluded_items:
            state_segments.append(("Occluded", ", ".join(occluded_items)))
        if disappeared_items:
            state_segments.append(("Miss", ", ".join(disappeared_items)))
        if unknown_items:
            state_segments.append(("Unknown", ", ".join(unknown_items)))

    def _text_width(text: str) -> int:
        (tw, _), _ = cv2.getTextSize(text, _FONT, _FONT_SCALE, 1)
        return tw

    max_text_w = combined.shape[1] - 2 * _MARGIN_X

    # 将状态分段拆成多行，每行不超过 max_text_w
    # 策略：summary 独占第一行；每个状态标签单独成行，items 过长时截断并标注数量
    state_lines: list[str] = []
    for label, items_str in state_segments:
        prefix = f"{label}: "
        full = f"{prefix}[{items_str}]"
        if _text_width(full) <= max_text_w:
            state_lines.append(full)
        else:
            # 逐个 item 拼接，超出宽度则截断，显示剩余数量
            items = [s.strip() for s in items_str.split(",")]
            cur = prefix + "["
            shown = 0
            for item in items:
                candidate = cur + (", " if shown > 0 else "") + item + "...]"
                if _text_width(candidate) > max_text_w and shown > 0:
                    # 当前行已满，截断并标注剩余
                    remaining = len(items) - shown
                    cur = cur.rstrip() + f", ... (+{remaining})]"
                    break
                cur = prefix + "[" + (", " if shown > 0 else "") + item
                shown += 1
                # 检查加上闭合括号是否超限（最后一项时）
                if shown == len(items):
                    cur += "]"
            state_lines.append(cur)

    n_lines = 1 + len(state_lines)   # summary + 状态行
    stats_h = _PAD_TOP + n_lines * _LINE_H + _PAD_BOT
    stats_bar = np.ones((stats_h, combined.shape[1], 3), dtype=np.uint8) * 40

    # 绘制 summary 第一行
    cv2.putText(stats_bar, summary_text, (_MARGIN_X, _PAD_TOP + 12),
                _FONT, _FONT_SCALE, _TEXT_COLOR, 1, cv2.LINE_AA)

    # 绘制状态行
    for line_i, line_text in enumerate(state_lines):
        y = _PAD_TOP + (1 + line_i) * _LINE_H + 12
        # 用标签颜色区分状态
        label = line_text.split(":")[0]
        if label == "Live":
            color = (100, 255, 150)    # 绿
        elif label == "Occluded":
            color = (80, 180, 255)     # 橙
        elif label == "Miss":
            color = (100, 100, 255)    # 红
        elif label == "Unknown":
            color = (180, 180, 100)    # 灰蓝
        else:
            color = _TEXT_COLOR
        cv2.putText(stats_bar, line_text, (_MARGIN_X, y),
                    _FONT, _FONT_SCALE, color, 1, cv2.LINE_AA)

    combined = np.vstack([combined, stats_bar])

    # 保存
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / f"visibility_viz_{frame_id}.jpg"
    cv2.imwrite(str(out_path), combined, [cv2.IMWRITE_JPEG_QUALITY, 85])

    # 保存可见性记录 JSON
    record_path = output_dir / f"visibility_records_{frame_id}.json"
    frame_record = {
        'frame_id': frame_id,
        'total_objects': len(all_objects),
        'visible_count': len(visible_items),
        'visible_objects': visibility_records,
    }
    with open(record_path, 'w', encoding='utf-8') as f:
        json.dump(frame_record, f, ensure_ascii=False, indent=2)

    return out_path, len(visible_items), visibility_records
