"""物体跟踪模块：track-by-detection + 共享体素归属图。

每个物体维护自己的体素集合（log-odds 占据概率）。
前景物体走完整生命周期状态机；floor/wall 作为结构单例（不衰减/不转移/不竞争）。

状态机:

    NEW --(第2次命中)--> CANDIDATE --(promote_hits)--> STABLE --(体素清空连续 K 帧)--> DEAD

逐体素消失判定（深度 + 归属）:
  * persist  : 本帧命中且深度匹配
  * occluded : 深度射线落在物体前方（有更近的东西）-> 保留
  * unknown  : 深度证据无效 -> 保留
  * miss     : 深度穿过（自由空间，d_X < d_obs - margin）-> carve
  * replaced : 深度匹配但被别的物体 claim -> 归属转移
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np


# ===========================================================================
# 体素工具
# ===========================================================================

def points_to_voxel_keys(points: np.ndarray, voxel_size: float) -> np.ndarray:
    """世界坐标点"""
    if len(points) == 0:
        return np.empty((0, 3), dtype=np.int32)
    keys = np.floor(points / voxel_size).astype(np.int32)
    kmin = keys.min(axis=0)
    shifted = keys - kmin
    spans = shifted.max(axis=0) + 1
    # mixed-radix 1D 哈希去重
    hashes = shifted[:, 2] + spans[2] * (shifted[:, 1] + spans[1] * shifted[:, 0])
    _, uniq_idx = np.unique(hashes, return_index=True)
    return keys[uniq_idx]


def _aabb_iou(a_min, a_max, b_min, b_max) -> float:
    """两个轴对齐包围盒（AABB）的 3D IoU"""
    inter_min = np.maximum(a_min, b_min)
    inter_max = np.minimum(a_max, b_max)
    inter = np.maximum(inter_max - inter_min, 0.0)
    inter_vol = float(inter.prod())
    if inter_vol <= 0.0:
        return 0.0
    a_vol = float(max(np.prod(np.maximum(a_max - a_min, 0.0)), 1e-12))
    b_vol = float(max(np.prod(np.maximum(b_max - b_min, 0.0)), 1e-12))
    return inter_vol / (a_vol + b_vol - inter_vol)


@dataclass
class Ownership:
    """共享归属图中单个体素的归属记录"""
    owner_id: int
    last_claim: int      # 该 owner 最近一次 claim 的 tick
    prob: float          # 占据概率


# ===========================================================================
# ObjectInstance
# ===========================================================================

@dataclass
class ObjectInstance:
    """被跟踪物体拥有的体素集合（在共享归属图中）"""

    obj_id: int
    category: str
    voxel_size: float
    birth_frame: str
    state: str = "NEW"                       # NEW | CANDIDATE | STABLE | DEAD
    hit_count: int = 1                       # 创建即算第 1 次观测
    miss_count: int = 0
    is_alive: bool = True
    empty_streak: int = 0
    creation_tick: int = -1                  # 创建时的 tick（用于 NEW 超时剪除）
    observed_frames: List[str] = field(default_factory=list)
    state_history: List[Tuple] = field(default_factory=list)
    source_views: List[dict] = field(default_factory=list)
    source_frames: List[str] = field(default_factory=list)
    source_images: List[str] = field(default_factory=list)

    voxel_keys: np.ndarray = field(default_factory=lambda: np.empty((0, 3), dtype=np.int32))
    log_odds: np.ndarray = field(default_factory=lambda: np.empty((0,), dtype=np.float32))
    _ki: Dict[Tuple[int, int, int], int] = field(default_factory=dict)
    centroid: Optional[np.ndarray] = None
    aabb_min: Optional[np.ndarray] = None
    aabb_max: Optional[np.ndarray] = None
    valid_voxel_count: int = 0
    last_det_centroid: Optional[np.ndarray] = None

    @property
    def owned_keys(self) -> Set[Tuple[int, int, int]]:
        """拥有的体素键集合（_ki.keys() 的视图）。"""
        return self._ki.keys()

    @property
    def owned_keys_arr(self) -> np.ndarray:
        return self.voxel_keys

    @property
    def n_voxels(self) -> int:
        return len(self.voxel_keys)

    def _add_keys(self, keys: np.ndarray, log_odds_val: float) -> None:
        """追加新体素键"""
        if len(keys) == 0:
            return
        start = len(self.voxel_keys)
        self.voxel_keys = np.vstack([self.voxel_keys, keys.astype(np.int32, copy=False)])
        self.log_odds = np.concatenate([self.log_odds, np.full(len(keys), log_odds_val, dtype=np.float32)])
        for i, k in enumerate(keys):
            self._ki[(int(k[0]), int(k[1]), int(k[2]))] = start + i

    def _remove_indices(self, idx: np.ndarray) -> None:
        """按索引删除体素，保持数组致密且 _ki 索引同步。

        布尔过滤 + 整体重建 _ki（O(N)，N 为本实例体素数），仅在体素真正被
        释放/转移时触发（decay 剪除或 _claim_voxels 转移）
        """
        if len(idx) == 0:
            return
        idx = np.asarray(idx, dtype=np.int64)
        keep = np.ones(len(self.voxel_keys), dtype=bool)
        keep[idx] = False
        self.voxel_keys = self.voxel_keys[keep]
        self.log_odds = self.log_odds[keep]
        self._ki = {(int(self.voxel_keys[i, 0]), int(self.voxel_keys[i, 1]),
                     int(self.voxel_keys[i, 2])): i for i in range(len(self.voxel_keys))}

    def recompute_bbox(self, cfg: dict, voxel_owner: Optional[dict] = None) -> None:
        """在存活体素（log_odds >= 0）上重算质心/AABB，向量化"""
        thr = float(cfg.get("voxel_valid_log_odds", 0.0))
        if len(self.voxel_keys) == 0:
            self.centroid = None
            self.aabb_min = None
            self.aabb_max = None
            self.valid_voxel_count = 0
            return
        self.valid_voxel_count = int(np.sum(self.log_odds > thr))
        live_mask = self.log_odds >= 0.0
        geo_keys = self.voxel_keys[live_mask] if np.any(live_mask) else self.voxel_keys
        pts = geo_keys.astype(np.float64) * self.voxel_size
        self.centroid = pts.mean(axis=0)
        self.aabb_min = pts.min(axis=0)
        self.aabb_max = pts.max(axis=0)

    def to_record(self, R_align: Optional[np.ndarray] = None,
                  cfg: Optional[dict] = None,
                  voxel_owner: Optional[dict] = None,
                  structural_voxels: Optional[Dict[Tuple[int, int, int], float]] = None) -> dict:
        thr = float((cfg or {}).get("voxel_valid_log_odds", 0.0))
        if structural_voxels is not None:
            # 结构单例：prob 存在 structural dict，键在 _ki（不维护 voxel_keys 数组）
            valid_keys = [k for k in self._ki if structural_voxels.get(k, -999.0) > thr]
            if valid_keys:
                pts = np.array(valid_keys, dtype=np.float64) * self.voxel_size
                if R_align is not None:
                    pts = (R_align @ pts.T).T
                pts = pts.astype(np.float32)
                center = pts.mean(axis=0)
            else:
                pts = np.empty((0, 3), dtype=np.float32)
                center = np.zeros(3, dtype=np.float32)
        else:
            valid_idx = np.where(self.log_odds > thr)[0]
            if len(valid_idx) > 0:
                pts = self.voxel_keys[valid_idx].astype(np.float64) * self.voxel_size
                if R_align is not None:
                    pts = (R_align @ pts.T).T
                pts = pts.astype(np.float32)
                center = pts.mean(axis=0)
            else:
                pts = np.empty((0, 3), dtype=np.float32)
                center = np.zeros(3, dtype=np.float32)

        det_id = f"D{self.obj_id}"
        rep_view = self.source_views[0] if self.source_views else None
        return {
            'category': self.category,
            'points': pts,
            'center': center,
            'frame': self.birth_frame,
            'image_path': self.source_images[0] if self.source_images else '',
            '_det_id': det_id,
            '_merged_from': [det_id],
            'source_instance_ids': [self.obj_id],
            '_centroid': center,
            '_point_count': int(len(pts)),
            'source_views': list(self.source_views),
            'source_frames': list(self.source_frames),
            'source_images': list(self.source_images),
            'num_frames': self.hit_count,
            'representative_source_view': rep_view,
            'representative_frame': (rep_view or {}).get('frame') or (self.source_frames[0] if self.source_frames else None),
            'representative_image': (rep_view or {}).get('image_path') or (self.source_images[0] if self.source_images else None),
            'obj_id': self.obj_id,
            'state': self.state,
            'is_alive': self.is_alive,
            'hit_count': self.hit_count,
            'miss_count': self.miss_count,
            'birth_frame': self.birth_frame,
            'last_seen_frame': self.observed_frames[-1] if self.observed_frames else self.birth_frame,
        }

    def to_dict(self) -> dict:
        """导出生命周期 dict（object_instances.json）"""
        traj = [{'frame_id': f, 'centroid_3d': (self.centroid.tolist() if self.centroid is not None else [0, 0, 0]),
                 'point_count': self.valid_voxel_count} for f in self.observed_frames]
        return {
            'obj_id': self.obj_id,
            'category': self.category,
            'birth_frame': self.birth_frame,
            'observed_frames': list(self.observed_frames),
            'centroid_trajectory': traj,
            'is_alive': self.is_alive,
            'miss_count': self.miss_count,
            'observation_count': self.hit_count,
            'current_state': self.state.lower() if self.state != "DEAD" else "disappeared",
            'state_history': [{'frame_id': t[0], 'state': t[1], 'miss_count': t[2]} for t in self.state_history],
        }


# ===========================================================================
# ObjectTracker
# ===========================================================================

class ObjectTracker:
    """基于共享体素归属图的 track-by-detection 跟踪器"""

    def __init__(self, voxel_size: float, config: Optional[dict] = None) -> None:
        self.voxel_size = float(voxel_size)
        self.config = dict(config or {})
        self.instances: List[ObjectInstance] = []          # 前景物体（有生命周期）
        self.structural: Dict[str, ObjectInstance] = {}   # floor/wall 结构单例（无生命周期）
        self.structural_cats: Set[str] = set(
            self.config.get('structural_categories', ['floor', 'wall']))
        self._next_id = 0
        self._tick = 0
        # 共享归属：体素键 -> owner_id。仅前景物体
        self.voxel_owner: Dict[Tuple[int, int, int], int] = {}
        # 每个 owner 最近一次 claim 任意体素的 tick（用于转移的 stale 判定）
        self._owner_last_claim: Dict[int, int] = {}
        # 结构体素：category -> {key -> prob}
        self._structural_voxels: Dict[str, Dict[Tuple[int, int, int], float]] = {}

    def _get_structural_singleton(self, category: str, frame_id: str) -> ObjectInstance:
        """获取（或创建）某结构类别的单例"""
        inst = self.structural.get(category)
        if inst is None:
            inst = ObjectInstance(
                obj_id=self._next_id, category=category,
                voxel_size=self.voxel_size, birth_frame=frame_id,
            )
            inst.state = "STABLE"   # 结构单例始终视为 stable
            self._next_id += 1
            self.structural[category] = inst
        return inst

    def update_frame(
        self,
        detections: List[dict],
        depth: np.ndarray,
        color,
        K: np.ndarray,
        T_c2w: np.ndarray,
        confidence: Optional[np.ndarray],
        conf_threshold: float,
        frame_id: str,
    ) -> dict:
        """处理一帧：检测描述 -> 结构 claim -> 前景关联 -> claim -> decay -> 生命周期"""
        tick = self._tick
        self._tick += 1
        cfg = self.config

        # 1) 每个检测的描述符（体素键、质心、AABB）
        descs: List[dict] = []
        for det in detections:
            pts = det.get('points_3d')
            if pts is None or len(pts) == 0:
                continue
            vkeys = points_to_voxel_keys(pts, self.voxel_size)
            descs.append({
                'category': det['category'],
                'points_3d': pts,
                'source_view': det.get('source_view'),
                'image_path': det.get('image_path', ''),
                'score': det.get('score', 0.0),
                'centroid': pts.mean(axis=0),
                'aabb_min': pts.min(axis=0),
                'aabb_max': pts.max(axis=0),
                'voxel_keys': vkeys,
            })

        # 拆分结构类（floor/wall 单例）与前景
        struct_descs = [d for d in descs if d['category'] in self.structural_cats]
        fg_descs = [d for d in descs if d['category'] not in self.structural_cats]

        touched: Set[int] = set()
        claims_this_frame: Dict[int, Set[Tuple[int, int, int]]] = {}
        id_to_inst: Dict[int, ObjectInstance] = {i.obj_id: i for i in self.instances}
        id_to_inst.update({i.obj_id: i for i in self.structural.values()})

        # 2) 结构单例：直接 claim 进各自的 _structural_voxels（不进共享 voxel_owner）
        init_log_odds = float(cfg.get("voxel_init_log_odds", 0.0))
        hit_log_odds = float(cfg.get("voxel_hit_log_odds", 0.55))
        max_log_odds = float(cfg.get("voxel_max_log_odds", 5.0))
        for d in struct_descs:
            inst = self._get_structural_singleton(d['category'], frame_id)
            sv = self._structural_voxels.setdefault(d['category'], {})
            for k in d['voxel_keys']:
                key = (int(k[0]), int(k[1]), int(k[2]))
                if key in sv:
                    sv[key] = min(max_log_odds, sv[key] + hit_log_odds)
                else:
                    sv[key] = init_log_odds
                if key not in inst._ki:
                    inst._ki[key] = len(inst._ki)
            inst.hit_count += 1
            inst.last_det_centroid = d['centroid']
            if d['source_view'] is not None and not inst.source_views:
                inst.source_views.append(d['source_view'])
            if d['image_path'] and d['image_path'] not in inst.source_images:
                inst.source_images.append(d['image_path'])
            if frame_id and frame_id not in inst.source_frames:
                inst.source_frames.append(frame_id)
            if frame_id and (not inst.observed_frames or inst.observed_frames[-1] != frame_id):
                inst.observed_frames.append(frame_id)

        # 3) 前景：关联到已有存活实例
        alive = [i for i in self.instances if i.is_alive]
        matches = self._associate(fg_descs, alive, cfg)
        matched_desc: Set[int] = set()
        det_to_inst: Dict[int, ObjectInstance] = {}
        for di, inst in matches:
            det_to_inst[di] = inst
            matched_desc.add(di)

        # 4) 未匹配的检测创建新前景实例
        for di, d in enumerate(fg_descs):
            if di in matched_desc:
                continue
            inst = ObjectInstance(
                obj_id=self._next_id, category=d['category'],
                voxel_size=self.voxel_size, birth_frame=frame_id,
                creation_tick=tick,
            )
            inst.state_history.append((frame_id, "created", 0))
            if frame_id and (not inst.observed_frames or inst.observed_frames[-1] != frame_id):
                inst.observed_frames.append(frame_id)
            self.instances.append(inst)
            self._next_id += 1
            id_to_inst[inst.obj_id] = inst
            det_to_inst[di] = inst

        # 5) 前景体素 claim：先匹配的（优先），再新建的
        order = [di for di, _ in matches] + [di for di in range(len(fg_descs)) if di not in matched_desc]
        for di in order:
            inst = det_to_inst[di]
            d = fg_descs[di]
            key_set = {(int(k[0]), int(k[1]), int(k[2])) for k in d['voxel_keys']}
            claims_this_frame[inst.obj_id] = claims_this_frame.get(inst.obj_id, set()) | key_set
            self._claim_voxels(inst, d['voxel_keys'], tick, cfg, id_to_inst, touched)
            inst.last_det_centroid = d['centroid']
            touched.add(inst.obj_id)

        # 6) 重算 touched 的 bbox（让 decay 的视野门控用到最新质心）
        for oid in touched:
            id_to_inst[oid].recompute_bbox(cfg, self.voxel_owner)

        # 7) decay：carve 所有在视野实例（含已匹配）的自由空间
        self._decay_pass(depth, K, T_c2w, confidence, conf_threshold,
                         frame_id, tick, claims_this_frame, cfg, touched, id_to_inst)

        # 8) carve 后重算 touched 的 bbox
        for oid in touched:
            id_to_inst[oid].recompute_bbox(cfg, self.voxel_owner)

        # 9) 记录 + 晋升
        promote_hits = int(cfg.get("candidate_promote_hits", 3))
        for di, inst in det_to_inst.items():
            if di in matched_desc:
                inst.hit_count += 1
                inst.miss_count = 0
                inst.empty_streak = 0
                if frame_id and (not inst.observed_frames or inst.observed_frames[-1] != frame_id):
                    inst.observed_frames.append(frame_id)
                d = fg_descs[di]
                if d['source_view'] is not None:
                    inst.source_views.append(d['source_view'])
                if d['image_path'] and d['image_path'] not in inst.source_images:
                    inst.source_images.append(d['image_path'])
                if frame_id and frame_id not in inst.source_frames:
                    inst.source_frames.append(frame_id)
                old = inst.state
                if inst.state == "NEW" and inst.hit_count >= 2:
                    inst.state = "CANDIDATE"
                if inst.state in ("NEW", "CANDIDATE") and inst.hit_count >= promote_hits:
                    inst.state = "STABLE"
                if inst.state != old:
                    inst.state_history.append((frame_id, inst.state, inst.miss_count))
            else:
                inst.empty_streak = 0
                d = fg_descs[di]
                if d['source_view'] is not None:
                    inst.source_views.append(d['source_view'])
                if d['image_path'] and d['image_path'] not in inst.source_images:
                    inst.source_images.append(d['image_path'])
                if frame_id and frame_id not in inst.source_frames:
                    inst.source_frames.append(frame_id)

        # 10) 存活判定 + 死亡
        death_thr = int(cfg.get("death_threshold", 5))
        new_grace = int(cfg.get("new_grace", 5))
        for inst in self.instances:
            if not inst.is_alive:
                continue
            dead = False
            if inst.miss_count >= death_thr:
                dead = True   # 连续 death_thr 帧深度穿过（自由空间）-> 消失
            if len(inst._ki) == 0:
                inst.empty_streak += 1
                if inst.empty_streak >= death_thr:
                    dead = True   # 体素全部被 carve/转移走
            else:
                inst.empty_streak = 0
            # 未确认的 NEW（一直没拿到第 2 次命中）超过 grace -> 剪除
            if inst.state == "NEW" and (tick - inst.creation_tick) >= new_grace:
                dead = True
            if dead:
                inst.is_alive = False
                inst.state = "DEAD"
                # 从共享归属图释放它拥有的全部体素
                for i in range(len(inst.voxel_keys)):
                    key = (int(inst.voxel_keys[i, 0]), int(inst.voxel_keys[i, 1]),
                           int(inst.voxel_keys[i, 2]))
                    self.voxel_owner.pop(key, None)
                inst.voxel_keys = np.empty((0, 3), dtype=np.int32)
                inst.log_odds = np.empty((0,), dtype=np.float32)
                inst._ki.clear()
                inst.state_history.append((frame_id, "dead", inst.miss_count))

        return {
            'n_detections': len(descs),
            'n_matched': len(matches),
            'n_new': len(descs) - len(matched_desc),
            'n_alive': sum(1 for i in self.instances if i.is_alive),
        }

    def _claim_voxels(
        self,
        inst: ObjectInstance,
        voxel_keys: np.ndarray,
        tick: int,
        cfg: dict,
        id_to_inst: Dict[int, ObjectInstance],
        touched: Set[int],
    ) -> None:
        """为 inst claim 体素。

        voxel_owner[key] -> owner_id；prob 存在各实例的 log_odds 数组。
        从 stale 的 owner 转移；冲突时保持现 owner。
        """
        init_log_odds = float(cfg.get("voxel_init_log_odds", 0.0))
        hit_log_odds = float(cfg.get("voxel_hit_log_odds", 0.55))
        max_log_odds = float(cfg.get("voxel_max_log_odds", 5.0))
        grace = int(cfg.get("claim_grace", 2))
        owner_last_claim = self._owner_last_claim

        # 按归属分类体素键，减少逐键分支
        new_keys: list = []          # 无主 -> 新增
        hit_idx: list = []           # 自己的 -> 命中加 prob
        transfer_keys: list = []     # 别人的且 stale -> 转移
        transfer_other_ids: list = []
        for k in voxel_keys:
            key = (int(k[0]), int(k[1]), int(k[2]))
            owner = self.voxel_owner.get(key)
            if owner is None:
                new_keys.append(key)
            elif owner == inst.obj_id:
                idx = inst._ki.get(key)
                if idx is not None:
                    hit_idx.append(idx)
            else:
                if tick - owner_last_claim.get(owner, 0) >= grace:
                    transfer_keys.append(key)
                    transfer_other_ids.append(owner)

        # 命中：向量化加 prob
        if hit_idx:
            idx_arr = np.asarray(hit_idx, dtype=np.int64)
            inst.log_odds[idx_arr] = np.minimum(max_log_odds, inst.log_odds[idx_arr] + hit_log_odds)

        # 新增 + 转移：都以 init prob 归本实例所有
        add = transfer_keys + new_keys
        if add:
            add_arr = np.asarray(add, dtype=np.int32)
            inst._add_keys(add_arr, init_log_odds)
            for key in add:
                self.voxel_owner[key] = inst.obj_id
            owner_last_claim[inst.obj_id] = tick

        # 转移：从原 owner 的数组删除
        if transfer_keys:
            by_other: Dict[int, List[Tuple]] = {}
            for key, oid in zip(transfer_keys, transfer_other_ids):
                by_other.setdefault(oid, []).append(key)
            for oid, keys in by_other.items():
                other = id_to_inst.get(oid)
                if other is None:
                    continue
                rem_idx = [other._ki[k] for k in keys if k in other._ki]
                if rem_idx:
                    other._remove_indices(rem_idx)
                    touched.add(oid)

    def _decay_pass(
        self,
        depth: np.ndarray,
        K: np.ndarray,
        T_c2w: np.ndarray,
        confidence: Optional[np.ndarray],
        conf_threshold: float,
        frame_id: str,
        tick: int,
        claims_this_frame: Dict[int, Set[Tuple[int, int, int]]],
        cfg: dict,
        touched: Set[int],
        id_to_inst: Dict[int, ObjectInstance],
    ) -> None:
        """carve 在视野实例的自由空间体素"""
        if not self.instances:
            return
        T_w2c = np.linalg.inv(T_c2w)
        fx, fy = K[0, 0], K[1, 1]
        cx, cy = K[0, 2], K[1, 2]
        h, w = depth.shape[:2]
        max_dist = float(cfg.get('decay_max_distance', cfg.get('depth_max', 8.0)))
        margin = float(cfg.get('voxel_free_margin', 0.08))
        miss_log_odds = float(cfg.get('voxel_miss_log_odds', 0.35))
        min_log_odds = float(cfg.get('voxel_min_log_odds', -4.0))
        prune_log_odds = float(cfg.get('voxel_prune_log_odds', -2.5))
        depth_min = float(cfg.get('depth_min', 0.01))
        depth_max = float(cfg.get('depth_max', 8.0))
        max_voxels = int(cfg.get('max_voxels_per_instance', 20000))

        for inst in self.instances:
            if not inst.is_alive or len(inst._ki) == 0 or inst.centroid is None:
                continue
            # 视野门控：质心投影在图像内、在相机前方、距离范围内
            c_cam = (T_w2c @ np.append(inst.centroid, 1.0))[:3]
            if c_cam[2] <= 0.1:
                continue
            if float(np.linalg.norm(c_cam)) > max_dist:
                continue

            keys_arr = inst.owned_keys_arr
            if keys_arr is None or len(keys_arr) == 0:
                continue
            keys_arr = keys_arr.astype(np.float64, copy=False)
            if len(keys_arr) > max_voxels:
                rng = np.random.default_rng(inst.obj_id * 1000003 + tick)
                sel = rng.choice(len(keys_arr), max_voxels, replace=False)
                keys_arr = keys_arr[sel]

            # 体素中心投影到当前帧
            centers = keys_arr * self.voxel_size
            hom = np.hstack([centers, np.ones((len(centers), 1))])
            cam = (T_w2c @ hom.T).T[:, :3]
            z = cam[:, 2]
            in_front = z > 0.1
            if not np.any(in_front):
                continue
            cam_f, z_f, keys_f = cam[in_front], z[in_front], keys_arr[in_front]
            u = (cam_f[:, 0] * fx / z_f + cx).astype(np.int64)
            v = (cam_f[:, 1] * fy / z_f + cy).astype(np.int64)
            in_img = (u >= 0) & (u < w) & (v >= 0) & (v < h)
            if not np.any(in_img):
                continue
            u_v, v_v, z_v = u[in_img], v[in_img], z_f[in_img]
            keys_v = keys_f[in_img]
            d_obs = depth[v_v, u_v].astype(np.float64)

            valid = (d_obs > depth_min) & (d_obs < depth_max)
            if confidence is not None and conf_threshold > 0:
                valid &= (confidence[v_v, u_v] >= conf_threshold)
            # 自由空间：体素比观测表面更近（d_X < d_obs - margin）
            free = valid & (z_v < d_obs - margin)

            # miss 记账（仅对本帧未 claim 的实例；匹配=存在=不 miss）
            if inst.obj_id not in claims_this_frame:
                n_total = len(z_v)
                n_valid = int(valid.sum())
                n_free = int(free.sum())
                miss_free_ratio = float(cfg.get('miss_free_ratio', 0.5))
                miss_min_samples = int(cfg.get('miss_min_samples', 20))
                miss_valid_ratio = float(cfg.get('miss_valid_ratio', 0.5))
                if (n_total >= miss_min_samples
                        and n_valid / max(n_total, 1) >= miss_valid_ratio):
                    if n_free / max(n_valid, 1) > miss_free_ratio:
                        inst.miss_count += 1   # 消失到自由空间
                    else:
                        inst.miss_count = 0    # 深度匹配（还在）-> 清零
                # 否则 unknown（有效深度不足）-> 不改变

            if free.sum() == 0:
                continue

            # carve：向量化更新 log_odds（与全局融合同模型：miss -= 0.35）
            free_idx = np.where(free)[0]
            free_keys = keys_v[free_idx]
            claimed = claims_this_frame.get(inst.obj_id, set())

            # 把自由空间体素映射回实例本地索引（跳过已 claim 和非本实例的）
            local_idx = []
            for j in range(len(free_keys)):
                key = (int(free_keys[j, 0]), int(free_keys[j, 1]), int(free_keys[j, 2]))
                if key in claimed:
                    continue
                li = inst._ki.get(key)
                if li is not None:
                    local_idx.append(li)

            if not local_idx:
                continue

            li_arr = np.asarray(local_idx, dtype=np.int64)
            inst.log_odds[li_arr] -= miss_log_odds
            np.maximum(inst.log_odds, min_log_odds, out=inst.log_odds)
            # 低于剪除阈值的释放（从归属图 + 实例数组删除）
            rel_mask = inst.log_odds[li_arr] <= prune_log_odds
            if rel_mask.any():
                rel_li = li_arr[rel_mask]
                for li in rel_li:
                    key = (int(inst.voxel_keys[li, 0]),
                           int(inst.voxel_keys[li, 1]),
                           int(inst.voxel_keys[li, 2]))
                    self.voxel_owner.pop(key, None)
                inst._remove_indices(rel_li)
                touched.add(inst.obj_id)

    def _containment(self, d: dict, inst: ObjectInstance) -> float:
        """双向体素包含率取大者：较小物体的体素落在较大物体 AABB 内的比例。"""
        d_keys = d['voxel_keys']
        if (len(d_keys) == 0 or len(inst._ki) == 0
                or inst.aabb_min is None or d['aabb_min'] is None):
            return 0.0
        i_keys = inst.owned_keys_arr
        if i_keys is None or len(i_keys) == 0:
            return 0.0
        vs = self.voxel_size
        # AABB -> 体素键空间
        d_vmin = np.floor(d['aabb_min'] / vs).astype(np.int64)
        d_vmax = np.floor(d['aabb_max'] / vs).astype(np.int64)
        i_vmin = np.floor(inst.aabb_min / vs).astype(np.int64)
        i_vmax = np.floor(inst.aabb_max / vs).astype(np.int64)
        # 检测体素落在实例 AABB 内的比例
        d_in_i = float(np.sum(np.all((d_keys >= i_vmin) & (d_keys <= i_vmax), axis=1))) / len(d_keys)
        # 实例体素落在检测 AABB 内的比例
        i_in_d = float(np.sum(np.all((i_keys >= d_vmin) & (i_keys <= d_vmax), axis=1))) / len(i_keys)
        return max(d_in_i, i_in_d)

    def _associate(
        self,
        descs: List[dict],
        alive: List[ObjectInstance],
        cfg: dict,
    ) -> List[Tuple[int, ObjectInstance]]:
        """关联：同类 且 ((AABB IoU>iou_thr 或 包含率>=cont_thr) 或 质心距离<dist_thr)。"""
        iou_thr = float(cfg.get("association_iou_threshold", 0.3))
        cont_thr = float(cfg.get("association_containment_threshold", 0.5))
        dist_thr = float(cfg.get("association_distance", 0.3))

        scored: List[Tuple[float, int, ObjectInstance]] = []
        for di, d in enumerate(descs):
            for inst in alive:
                if inst.category != d['category']:
                    continue
                ic = inst.centroid if inst.centroid is not None else inst.last_det_centroid
                if ic is None:
                    continue
                dist = float(np.linalg.norm(d['centroid'] - ic))
                if inst.aabb_min is not None and inst.aabb_max is not None:
                    iou = _aabb_iou(d['aabb_min'], d['aabb_max'], inst.aabb_min, inst.aabb_max)
                else:
                    iou = 0.0
                # 足够近 -> 直接按距离关联（无需重叠）
                if dist < dist_thr:
                    cont = 0.0
                elif iou > iou_thr:
                    cont = 0.0
                elif iou > 0:
                    # AABB 重叠但 IoU 低（尺寸悬殊/部分重叠）：只有高包含率才关联
                    cont = self._containment(d, inst)
                    if cont < cont_thr:
                        continue
                else:
                    # AABB 不重叠且不近 -> 不可能关联
                    continue
                score = max(iou, cont) - 0.3 * (dist / max(dist_thr, 1e-6))
                scored.append((score, di, inst))

        scored.sort(key=lambda x: x[0], reverse=True)
        used_desc, used_inst = set(), set()
        matches: List[Tuple[int, ObjectInstance]] = []
        for score, di, inst in scored:
            if di in used_desc or id(inst) in used_inst:
                continue
            matches.append((di, inst))
            used_desc.add(di)
            used_inst.add(id(inst))
        return matches

    def alive_instances(self) -> List[ObjectInstance]:
        """存活的前景实例（结构单例始终存活，单独由 records() 处理）。"""
        return [i for i in self.instances if i.is_alive]

    def snapshot_records(self, cfg: Optional[dict] = None) -> List[dict]:
        """仅前景（可视化/状态检测忽略 floor/wall 结构类）。"""
        out = []
        for inst in self.alive_instances():
            rec = inst.to_record(None, cfg or self.config, self.voxel_owner)
            if len(rec['points']) == 0:
                continue
            out.append(rec)
        return out

    def records(self, R_align: Optional[np.ndarray] = None,
                cfg: Optional[dict] = None) -> List[dict]:
        """前景 + 结构单例（floor/wall），用于最终导出。"""
        out = []
        for inst in self.alive_instances():
            rec = inst.to_record(R_align, cfg or self.config, self.voxel_owner)
            if len(rec['points']) == 0:
                continue
            out.append(rec)
        for inst in self.structural.values():
            sv = self._structural_voxels.get(inst.category, {})
            rec = inst.to_record(R_align, cfg or self.config, None, structural_voxels=sv)
            if len(rec['points']) == 0:
                continue
            out.append(rec)
        return out

    def save(self, output_dir) -> Path:
        """保存生命周期数据（object_instances.json + frame_merge_groups.json）。"""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        all_inst = list(self.instances) + list(self.structural.values())
        instances_data = {
            'total_objects': len(all_inst),
            'objects': [i.to_dict() for i in sorted(all_inst, key=lambda x: x.obj_id)],
        }
        with open(output_dir / 'object_instances.json', 'w', encoding='utf-8') as f:
            json.dump(instances_data, f, ensure_ascii=False, indent=2)
        with open(output_dir / 'frame_merge_groups.json', 'w', encoding='utf-8') as f:
            json.dump({'total_frames': 0, 'frames': {}}, f, ensure_ascii=False, indent=2)
        return output_dir
