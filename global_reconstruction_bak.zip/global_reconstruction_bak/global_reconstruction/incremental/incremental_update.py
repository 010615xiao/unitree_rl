#!/usr/bin/env python3
"""Incrementally update object lifecycle from one new RGB-D observation.

 Current detections can come from VLM+SAM or any detector as JSON:

[
  {
    "category": "chair",
    "bbox_xyxy": [120, 80, 260, 300],
    "center": [1.2, 0.4, 3.1],
    "bbox": {"min": [...], "max": [...]}
  }
]

If detections are omitted, pass --auto-detect to call VLM + SAM3 on the current
image and materialize detections automatically.
"""

from __future__ import annotations

import argparse
import base64
import cv2
from copy import deepcopy
from datetime import datetime
import json
from pathlib import Path
import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np

try:
    import requests
except ImportError:  # pragma: no cover - depends on runtime environment
    requests = None

from global_reconstruction.incremental.object_visibility import (
    bbox_iou_2d,
    load_depth_meters,
    load_intrinsics,
    load_pose_matrix,
)


DEFAULT_UPDATE_CONFIG: Dict[str, float] = {
    "min_detection_iou": 0.05,
    "same_object_center_distance": 0.8,
    "move_distance_threshold": 0.6,
    "max_move_distance": 3.0,
    "disappear_after_misses": 2,
}

DEFAULT_VLM_URL = "http://localhost:8010/v1/chat/completions"
DEFAULT_VLM_MODEL = "Qwen3.6-35B-A3B"
DEFAULT_SAM3_URL = "http://localhost:20023/predict"
DEFAULT_SAM3_BATCH_URL = "http://localhost:20023/predict_batch"


def _slug(value: Any) -> str:
    text = re.sub(r"[^a-zA-Z0-9]+", "_", str(value or "object").lower()).strip("_")
    return text or "object"


def _vec3(value: Any) -> Optional[np.ndarray]:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return None
    try:
        return np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError):
        return None


def _center(record: Dict[str, Any]) -> Optional[np.ndarray]:
    center = _vec3(record.get("center"))
    if center is not None:
        return center
    bbox = record.get("bbox")
    if isinstance(bbox, dict):
        lower = _vec3(bbox.get("min"))
        upper = _vec3(bbox.get("max"))
        if lower is not None and upper is not None:
            return (lower + upper) * 0.5
    return None


def _persistent_id(obj: Dict[str, Any]) -> str:
    lifecycle = obj.get("lifecycle") if isinstance(obj.get("lifecycle"), dict) else {}
    return str(obj.get("persistent_id") or lifecycle.get("persistent_id") or obj.get("name") or f"object_{obj.get('id', 0)}")


def _missed_count(obj: Dict[str, Any]) -> int:
    lifecycle = obj.get("lifecycle") if isinstance(obj.get("lifecycle"), dict) else {}
    try:
        return int(lifecycle.get("missing_evidence_count", lifecycle.get("missed_observations", 0)))
    except (TypeError, ValueError):
        return 0


def _detection_bbox(det: Dict[str, Any]) -> Optional[List[float]]:
    for key in ("bbox_xyxy", "projected_bbox", "bbox_2d", "box"):
        value = det.get(key)
        if isinstance(value, (list, tuple)) and len(value) == 4:
            try:
                return [float(v) for v in value]
            except (TypeError, ValueError):
                return None
    return None


def load_detections(path: Optional[str]) -> List[Dict[str, Any]]:
    if not path:
        return []
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = data.get("objects", data.get("detections", []))
    if not isinstance(data, list):
        raise ValueError("Detection JSON must be a list or contain objects/detections")
    return [item for item in data if isinstance(item, dict)]


def _image_to_base64(image_path: Any) -> str:
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def _clean_json_output(content: str) -> str:
    content = str(content or "").strip()
    if content.startswith("```json"):
        content = content[7:]
    if content.startswith("```"):
        content = content[3:]
    if content.endswith("```"):
        content = content[:-3]
    content = content.strip()

    array_start = content.find("[")
    array_end = content.rfind("]") + 1
    object_start = content.find("{")
    if array_start >= 0 and array_end > array_start and (object_start < 0 or array_start < object_start):
        return content[array_start:array_end]

    start = content.find("{")
    end = content.rfind("}") + 1
    if start >= 0 and end > start:
        return content[start:end]
    return content


def _known_categories(scene_graph: Dict[str, Any], limit: int = 32) -> List[str]:
    seen = []
    for obj in scene_graph.get("objects", []) or []:
        category = _slug(obj.get("category"))
        if category and category not in seen:
            seen.append(category)
        if len(seen) >= limit:
            break
    return seen


def vlm_detect_categories(
    image_path: Any,
    scene_graph: Dict[str, Any],
    vlm_url: str = DEFAULT_VLM_URL,
    vlm_model: str = DEFAULT_VLM_MODEL,
    timeout: int = 60,
    max_objects: int = 12,
) -> List[Dict[str, Any]]:
    """Detect current-frame object categories with a VLM.

    This call intentionally sends only the current image. Historical scene graph
    categories are text hints, not historical images, so old visual evidence
    cannot reintroduce removed objects.
    """
    if requests is None:
        raise ImportError("requests is required for VLM detection")

    known = _known_categories(scene_graph)
    known_line = ""
    if known:
        known_line = (
            "\nKnown categories from the existing scene graph: "
            + ", ".join(known)
            + ". Use these exact names when visible in the current image.\n"
        )

    prompt = f"""You are an indoor object detection assistant. Detect objects in the CURRENT image only.

Output STRICT JSON:
{{"objects":[{{"category":"name"}},...]}}

Rules:
1. Use lowercase short category names.
2. Include only objects visibly present in the current image.
3. Do not infer objects from memory or prior frames.
4. Max {int(max_objects)} categories. Prioritize prominent indoor objects.
5. Skip ceiling, sky, outdoor objects, pets.{known_line}
Output only JSON now:"""

    image_b64 = _image_to_base64(image_path)
    payload = {
        "model": vlm_model,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"}},
                {"type": "text", "text": prompt},
            ],
        }],
        "max_tokens": 1200,
        "temperature": 0.01,
        "stream": False,
        "reasoning": False,
    }
    response = requests.post(vlm_url, json=payload, timeout=timeout)
    response.raise_for_status()
    result = response.json()
    msg = result["choices"][0]["message"]
    content = msg.get("content", "").strip() or msg.get("reasoning_content", "").strip()
    parsed = json.loads(_clean_json_output(content))
    if isinstance(parsed, dict):
        objects = parsed.get("objects", [])
        if not objects and "category" in parsed:
            objects = [parsed]
    else:
        objects = parsed
    if not isinstance(objects, list):
        return []

    seen = set()
    detections = []
    for obj in objects:
        if not isinstance(obj, dict):
            continue
        category = _slug(obj.get("category"))
        if not category or category in seen or category == "ceiling":
            continue
        seen.add(category)
        prompt_text = obj.get("sam3_prompt") or category.replace("_", " ")
        detections.append({"category": category, "sam3_prompt": prompt_text})
        if len(detections) >= max_objects:
            break
    return detections


def _decode_mask_b64(b64_str: str) -> Optional[np.ndarray]:
    buf = base64.b64decode(b64_str)
    arr = np.frombuffer(buf, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_UNCHANGED)


def sam3_segment_category(
    image_path: Any,
    category_prompt: str,
    sam3_url: str = DEFAULT_SAM3_URL,
    timeout: int = 30,
    max_detections: int = 5,
) -> List[Dict[str, Any]]:
    if requests is None:
        raise ImportError("requests is required for SAM3 detection")

    payload = {"image_path": str(image_path), "text": category_prompt,
               "mask_format": "base64_png"}
    response = requests.post(sam3_url, json=payload, timeout=timeout)
    response.raise_for_status()
    result = response.json()
    if not result.get("success", False):
        return []

    mask_format = result.get("mask_format", "json")
    image_shape = result.get("image_shape")
    scores = result.get("scores", []) or []
    boxes = result.get("boxes", []) or []

    items = []
    if mask_format == "base64_png":
        masks_b64 = result.get("masks_b64", []) or []
        for idx, b64 in enumerate(masks_b64):
            mask_u8 = _decode_mask_b64(b64)
            if mask_u8 is None:
                continue
            box = None
            if idx < len(boxes) and isinstance(boxes[idx], (list, tuple)) and len(boxes[idx]) == 4:
                box = [float(v) for v in boxes[idx]]
            score = float(scores[idx]) if idx < len(scores) else 0.0
            items.append({"mask": mask_u8, "box": box, "score": score,
                          "sam3_image_shape": image_shape})
    else:
        masks = result.get("masks", []) or []
        for idx, mask in enumerate(masks):
            mask_arr = np.asarray(mask, dtype=np.float32)
            mask_u8 = (mask_arr > 0.5).astype(np.uint8) * 255
            box = None
            if idx < len(boxes) and isinstance(boxes[idx], (list, tuple)) and len(boxes[idx]) == 4:
                box = [float(v) for v in boxes[idx]]
            score = float(scores[idx]) if idx < len(scores) else 0.0
            items.append({"mask": mask_u8, "box": box, "score": score,
                          "sam3_image_shape": image_shape})

    items.sort(key=lambda item: item.get("score", 0.0), reverse=True)
    return items[:max_detections]


def sam3_segment_batch(
    image_path: Any,
    category_prompts: List[Dict[str, Any]],
    sam3_batch_url: str = DEFAULT_SAM3_BATCH_URL,
    timeout: int = 60,
    max_detections: int = 5,
) -> Dict[str, List[Dict[str, Any]]]:
    """批量 SAM3 分割 — 图像编码一次，多个 prompt 复用。

    Args:
        image_path: 图片路径
        category_prompts: [{"category": ..., "sam3_prompt": ...}, ...]
        sam3_batch_url: 批量接口 URL
        timeout: 请求超时
        max_detections: 每个 prompt 最大检测数

    Returns:
        {sam3_prompt: [detection, ...], ...}
    """
    prompts_with_keys = []
    for info in category_prompts:
        cat = _slug(info.get("category"))
        prompt = str(info.get("sam3_prompt") or cat.replace("_", " "))
        prompts_with_keys.append((cat, prompt))

    texts = list(dict.fromkeys(p for _, p in prompts_with_keys))
    empty: Dict[str, List[Dict[str, Any]]] = {p: [] for _, p in prompts_with_keys}
    if not texts:
        return empty

    try:
        payload = {"image_path": str(image_path), "texts": texts,
                   "mask_format": "base64_png"}
        response = requests.post(sam3_batch_url, json=payload, timeout=timeout)
        response.raise_for_status()
        result = response.json()
        if not result.get("success", False):
            return empty
        mask_format = result.get("mask_format", "json")
        results_map = result.get("results", {})
    except Exception:
        return empty

    output: Dict[str, List[Dict[str, Any]]] = {}
    for text in texts:
        data = results_map.get(text, {})
        scores = data.get("scores", []) or []
        boxes = data.get("boxes", []) or []
        image_shape = data.get("image_shape")

        items: List[Dict[str, Any]] = []
        if mask_format == "base64_png":
            masks_b64 = data.get("masks_b64", []) or []
            for idx, b64 in enumerate(masks_b64):
                mask_u8 = _decode_mask_b64(b64)
                if mask_u8 is None:
                    continue
                box = None
                if idx < len(boxes) and isinstance(boxes[idx], (list, tuple)) and len(boxes[idx]) == 4:
                    box = [float(v) for v in boxes[idx]]
                score = float(scores[idx]) if idx < len(scores) else 0.0
                items.append({"mask": mask_u8, "box": box, "score": score,
                              "sam3_image_shape": image_shape})
        else:
            masks = data.get("masks", []) or []
            for idx, mask in enumerate(masks):
                mask_arr = np.asarray(mask, dtype=np.float32)
                mask_u8 = (mask_arr > 0.5).astype(np.uint8) * 255
                box = None
                if idx < len(boxes) and isinstance(boxes[idx], (list, tuple)) and len(boxes[idx]) == 4:
                    box = [float(v) for v in boxes[idx]]
                score = float(scores[idx]) if idx < len(scores) else 0.0
                items.append({"mask": mask_u8, "box": box, "score": score,
                              "sam3_image_shape": image_shape})

        items.sort(key=lambda item: item.get("score", 0.0), reverse=True)
        output[text] = items[:max_detections]

    return output


def _resize_mask_nearest(mask: np.ndarray, target_shape: Tuple[int, int]) -> np.ndarray:
    target_h, target_w = target_shape
    if mask.shape[:2] == (target_h, target_w):
        return mask.astype(np.uint8)
    src_h, src_w = mask.shape[:2]
    if src_h <= 0 or src_w <= 0:
        return np.zeros((target_h, target_w), dtype=np.uint8)
    y_idx = np.clip(np.round(np.linspace(0, src_h - 1, target_h)).astype(np.int32), 0, src_h - 1)
    x_idx = np.clip(np.round(np.linspace(0, src_w - 1, target_w)).astype(np.int32), 0, src_w - 1)
    return mask[y_idx[:, None], x_idx[None, :]].astype(np.uint8)


def _mask_bbox_xyxy(mask: np.ndarray) -> Optional[List[int]]:
    ys, xs = np.where(mask > 128)
    if len(xs) == 0:
        return None
    return [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]


def _points_from_mask(
    mask: np.ndarray,
    depth: np.ndarray,
    K: np.ndarray,
    T_c2w: np.ndarray,
    depth_min: float = 0.0,
    depth_max: float = 15.0,
) -> np.ndarray:
    mask = _resize_mask_nearest(mask, depth.shape[:2])
    valid = (mask > 128) & np.isfinite(depth) & (depth > depth_min) & (depth < depth_max)
    if not np.any(valid):
        return np.empty((0, 3), dtype=np.float64)
    v, u = np.where(valid)
    z = depth[v, u].astype(np.float64)
    x = (u.astype(np.float64) - K[0, 2]) * z / K[0, 0]
    y = (v.astype(np.float64) - K[1, 2]) * z / K[1, 1]
    points_cam = np.column_stack([x, y, z, np.ones_like(z)])
    return (T_c2w @ points_cam.T).T[:, :3]


def _detection_from_mask(
    category: str,
    mask_item: Dict[str, Any],
    depth: np.ndarray,
    K: np.ndarray,
    T_c2w: np.ndarray,
    min_points: int = 30,
    depth_min: float = 0.0,
    depth_max: float = 15.0,
) -> Optional[Dict[str, Any]]:
    mask_original = np.asarray(mask_item.get("mask"), dtype=np.uint8)
    mask_depth = _resize_mask_nearest(mask_original, depth.shape[:2])
    bbox_2d = _mask_bbox_xyxy(mask_depth)
    if bbox_2d is None:
        return None

    points = _points_from_mask(mask_depth, depth, K, T_c2w, depth_min=depth_min, depth_max=depth_max)
    if len(points) < min_points:
        return None

    lower = points.min(axis=0)
    upper = points.max(axis=0)
    center = points.mean(axis=0)
    return {
        "category": _slug(category),
        "bbox_xyxy": bbox_2d,
        "center": center.tolist(),
        "bbox": {
            "min": lower.tolist(),
            "max": upper.tolist(),
        },
        "num_points": int(len(points)),
        "score": float(mask_item.get("score", 0.0)),
        "source": "vlm_sam3_current_frame",
    }


def auto_detect_current_frame(
    image_path: Any,
    scene_graph: Dict[str, Any],
    depth: np.ndarray,
    K: np.ndarray,
    T_c2w: np.ndarray,
    categories: Optional[List[str]] = None,
    vlm_url: str = DEFAULT_VLM_URL,
    vlm_model: str = DEFAULT_VLM_MODEL,
    sam3_url: str = DEFAULT_SAM3_URL,
    sam3_batch_url: str = DEFAULT_SAM3_BATCH_URL,
    sam3_max_detections: int = 5,
    min_points: int = 30,
    depth_min: float = 0.0,
    depth_max: float = 15.0,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    if not image_path:
        raise ValueError("--image is required for --auto-detect")

    if categories:
        category_prompts = [{"category": _slug(cat), "sam3_prompt": _slug(cat).replace("_", " ")} for cat in categories]
        category_source = "cli_categories"
    else:
        category_prompts = vlm_detect_categories(
            image_path=image_path,
            scene_graph=scene_graph,
            vlm_url=vlm_url,
            vlm_model=vlm_model,
        )
        category_source = "vlm"

    detections: List[Dict[str, Any]] = []
    per_category = []

    # 批量 SAM3 分割 (图像编码一次，多个 prompt 复用)
    batch_results = sam3_segment_batch(
        image_path=image_path,
        category_prompts=category_prompts,
        sam3_batch_url=sam3_batch_url,
        max_detections=sam3_max_detections,
    )

    for category_info in category_prompts:
        category = _slug(category_info.get("category"))
        prompt = str(category_info.get("sam3_prompt") or category.replace("_", " "))
        masks = batch_results.get(prompt, [])
        kept = 0
        for mask_item in masks:
            detection = _detection_from_mask(
                category=category,
                mask_item=mask_item,
                depth=depth,
                K=K,
                T_c2w=T_c2w,
                min_points=min_points,
                depth_min=depth_min,
                depth_max=depth_max,
            )
            if detection is None:
                continue
            detections.append(detection)
            kept += 1
        per_category.append({
            "category": category,
            "sam3_prompt": prompt,
            "sam3_masks": len(masks),
            "detections_kept": kept,
        })

    info = {
        "source": category_source,
        "categories": [item.get("category") for item in category_prompts],
        "num_detections": len(detections),
        "per_category": per_category,
    }
    return detections, info


def _match_detection(
    obj: Dict[str, Any],
    visibility: Dict[str, Any],
    detections: List[Dict[str, Any]],
    used_detection_indices: set,
    cfg: Dict[str, float],
) -> Tuple[Optional[int], Optional[Dict[str, Any]]]:
    obj_category = _slug(obj.get("category"))
    obj_center = _center(obj)
    projected_bbox = visibility.get("projected_bbox")

    best_idx = None
    best = None
    for idx, det in enumerate(detections):
        if idx in used_detection_indices:
            continue
        if _slug(det.get("category")) != obj_category:
            continue

        det_bbox = _detection_bbox(det)
        iou2d = bbox_iou_2d(projected_bbox, det_bbox)
        det_center = _center(det)
        center_distance = None
        if obj_center is not None and det_center is not None:
            center_distance = float(np.linalg.norm(obj_center - det_center))

        qualifies = iou2d >= cfg["min_detection_iou"]
        if center_distance is not None and center_distance <= cfg["max_move_distance"]:
            qualifies = True
        if not qualifies:
            continue

        distance_score = 0.0
        if center_distance is not None:
            distance_score = max(0.0, 1.0 - center_distance / max(cfg["max_move_distance"], 1e-6))
        score = iou2d + distance_score
        if best is None or score > best["score"]:
            best_idx = idx
            best = {
                "score": round(float(score), 6),
                "iou2d": round(float(iou2d), 6),
                "center_distance": round(float(center_distance), 6) if center_distance is not None else None,
                "detection": det,
            }
    return best_idx, best


def _match_detection_simple(
    obj: Dict[str, Any],
    detections: List[Dict[str, Any]],
    used_detection_indices: set,
    cfg: Dict[str, float],
) -> Tuple[Optional[int], Optional[Dict[str, Any]]]:
    """Match an object to a detection using only center distance (no visibility/projection)."""
    obj_category = _slug(obj.get("category"))
    obj_center = _center(obj)

    best_idx = None
    best = None
    for idx, det in enumerate(detections):
        if idx in used_detection_indices:
            continue
        if _slug(det.get("category")) != obj_category:
            continue

        det_center = _center(det)
        center_distance = None
        if obj_center is not None and det_center is not None:
            center_distance = float(np.linalg.norm(obj_center - det_center))

        if center_distance is None or center_distance > cfg["max_move_distance"]:
            continue

        distance_score = max(0.0, 1.0 - center_distance / max(cfg["max_move_distance"], 1e-6))
        score = distance_score
        if best is None or score > best["score"]:
            best_idx = idx
            best = {
                "score": round(float(score), 6),
                "iou2d": 0.0,
                "center_distance": round(float(center_distance), 6),
                "detection": det,
            }
    return best_idx, best


def _next_object_name(category: str, objects: List[Dict[str, Any]]) -> str:
    category = _slug(category)
    used = {str(obj.get("name")) for obj in objects}
    index = 0
    while True:
        name = f"{category}_{index}"
        if name not in used:
            return name
        index += 1


def _can_materialize_detection(det: Dict[str, Any]) -> bool:
    return _center(det) is not None and isinstance(det.get("bbox"), dict)


def _geometry_snapshot(record: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    snapshot: Dict[str, Any] = {}
    center = _center(record)
    if center is not None:
        snapshot["center"] = center.astype(float).tolist()

    bbox = record.get("bbox")
    if isinstance(bbox, dict):
        lower = _vec3(bbox.get("min"))
        upper = _vec3(bbox.get("max"))
        if lower is not None and upper is not None:
            snapshot["bbox"] = {
                "min": np.minimum(lower, upper).astype(float).tolist(),
                "max": np.maximum(lower, upper).astype(float).tolist(),
            }
    return snapshot or None


def _copy_detection_observation(det: Dict[str, Any], frame_id: Optional[str]) -> Dict[str, Any]:
    observation = {
        "frame_id": frame_id,
        "category": det.get("category"),
        "bbox_xyxy": _detection_bbox(det),
        "source": det.get("source"),
    }
    for key in ("score", "num_points"):
        if key in det:
            observation[key] = det.get(key)
    geometry = _geometry_snapshot(det)
    if geometry is not None:
        observation["geometry"] = geometry
    return observation


def _replace_object_geometry_from_detection(obj: Dict[str, Any], det: Dict[str, Any]) -> None:
    center = _center(det)
    if center is not None:
        obj["center"] = center.astype(float).tolist()

    bbox = det.get("bbox")
    if isinstance(bbox, dict):
        lower = _vec3(bbox.get("min"))
        upper = _vec3(bbox.get("max"))
        if lower is not None and upper is not None:
            obj["bbox"] = {
                "min": np.minimum(lower, upper).astype(float).tolist(),
                "max": np.maximum(lower, upper).astype(float).tolist(),
            }


def _merge_object_geometry_from_detection(obj: Dict[str, Any], det: Dict[str, Any]) -> bool:
    obj_bbox = obj.get("bbox")
    det_bbox = det.get("bbox")
    if not isinstance(obj_bbox, dict) or not isinstance(det_bbox, dict):
        return False

    obj_lower = _vec3(obj_bbox.get("min"))
    obj_upper = _vec3(obj_bbox.get("max"))
    det_lower = _vec3(det_bbox.get("min"))
    det_upper = _vec3(det_bbox.get("max"))
    if obj_lower is None or obj_upper is None or det_lower is None or det_upper is None:
        return False

    lower = np.minimum(np.minimum(obj_lower, obj_upper), np.minimum(det_lower, det_upper))
    upper = np.maximum(np.maximum(obj_lower, obj_upper), np.maximum(det_lower, det_upper))
    obj["bbox"] = {"min": lower.astype(float).tolist(), "max": upper.astype(float).tolist()}
    obj["center"] = ((lower + upper) * 0.5).astype(float).tolist()
    return True


def update_scene_graph_with_observation(
    scene_graph: Dict[str, Any],
    detections: Optional[List[Dict[str, Any]]] = None,
    update_config: Optional[Dict[str, Any]] = None,
    frame_id: Optional[str] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Update the scene graph with new detections.

    Objects are managed purely by detection matching — no visibility state.
    """
    cfg = dict(DEFAULT_UPDATE_CONFIG)
    for key, value in (update_config or {}).items():
        if key in cfg and value is not None:
            cfg[key] = float(value)
    cfg["disappear_after_misses"] = max(1, int(cfg["disappear_after_misses"]))

    detections = detections or []
    objects = [deepcopy(obj) for obj in scene_graph.get("objects", []) if isinstance(obj, dict)]
    used_detection_indices = set()
    events: List[Dict[str, Any]] = []

    for obj in objects:
        pid = _persistent_id(obj)
        obj["persistent_id"] = pid
        lifecycle = dict(obj.get("lifecycle") or {})
        previous_missing = _missed_count(obj)

        # Try to match this object with a detection
        match_idx, match = _match_detection_simple(obj, detections, used_detection_indices, cfg)
        if match_idx is not None and match is not None:
            used_detection_indices.add(match_idx)
            matched_detection = match["detection"]
            center_distance = match.get("center_distance")
            moved = center_distance is not None and center_distance >= cfg["move_distance_threshold"]
            can_merge_geometry = _can_materialize_detection(matched_detection)
            event_type = "moved" if moved else ("merged" if can_merge_geometry else "observed")
            previous_geometry = _geometry_snapshot(obj)
            detection_geometry = _geometry_snapshot(matched_detection)
            geometry_update = "confirmed_by_current_detection"

            if moved and detection_geometry is not None:
                _replace_object_geometry_from_detection(obj, matched_detection)
                geometry_update = "replaced_by_current_detection"
            elif event_type == "merged":
                merged_geometry = _merge_object_geometry_from_detection(obj, matched_detection)
                geometry_update = "expanded_with_current_detection" if merged_geometry else "matched_without_geometry_change"

            if detection_geometry is not None:
                obj["last_observation"] = _copy_detection_observation(matched_detection, frame_id)

            if event_type == "merged":
                lifecycle["merged_observations_count"] = int(lifecycle.get("merged_observations_count", 0)) + 1
            lifecycle.update({
                "persistent_id": pid,
                "status": "active",
                "event": event_type,
                "last_seen_frame": frame_id,
                "missing_evidence_count": 0,
                "matched_current_detection": True,
                "match": {k: v for k, v in match.items() if k != "detection"},
                "geometry_update": geometry_update,
                "previous_geometry": previous_geometry,
                "current_detection_geometry": detection_geometry,
            })
            obj["is_active"] = True
            obj["lifecycle"] = lifecycle
            events.append({
                "type": event_type,
                "persistent_id": pid,
                "object_id": obj.get("id"),
                "detection_index": match_idx,
                "category": obj.get("category"),
                "center_distance": center_distance,
                "iou2d": match.get("iou2d"),
                "geometry_update": geometry_update,
            })
            continue

        # No detection matched — increment missing count
        missing_count = previous_missing + 1
        status = "disappeared" if missing_count >= cfg["disappear_after_misses"] else "missing"
        event_type = "disappeared" if status == "disappeared" else "missing_evidence"
        lifecycle.update({
            "persistent_id": pid,
            "status": status,
            "event": event_type,
            "last_checked_frame": frame_id,
            "missing_evidence_count": missing_count,
            "matched_current_detection": False,
        })
        obj["is_active"] = status != "disappeared"
        obj["lifecycle"] = lifecycle
        events.append({
            "type": event_type,
            "persistent_id": pid,
            "object_id": obj.get("id"),
            "category": obj.get("category"),
            "missing_evidence_count": missing_count,
        })

    new_detection_events = []
    for idx, det in enumerate(detections):
        if idx in used_detection_indices:
            continue
        event = {
            "type": "new_detection",
            "detection_index": idx,
            "category": det.get("category"),
            "materialized_in_scene_graph": False,
        }
        if _can_materialize_detection(det):
            new_obj = deepcopy(det)
            new_obj["id"] = len(objects)
            new_obj["name"] = new_obj.get("name") or _next_object_name(new_obj.get("category", "object"), objects)
            new_obj["persistent_id"] = new_obj["name"]
            new_obj["lifecycle"] = {
                "persistent_id": new_obj["persistent_id"],
                "status": "active",
                "event": "new",
                "first_seen_frame": frame_id,
                "missing_evidence_count": 0,
            }
            new_obj["is_active"] = True
            objects.append(new_obj)
            event["persistent_id"] = new_obj["persistent_id"]
            event["object_id"] = new_obj["id"]
            event["materialized_in_scene_graph"] = True
        new_detection_events.append(event)
        events.append(event)

    updated = deepcopy(scene_graph)
    updated["objects"] = objects
    updated["num_objects"] = len(objects)
    updated["timestamp"] = datetime.now().isoformat()

    summary = {
        "objects_total": len(objects),
        "detections_total": len(detections),
        "observed": sum(1 for e in events if e["type"] == "observed"),
        "merged": sum(1 for e in events if e["type"] == "merged"),
        "moved": sum(1 for e in events if e["type"] == "moved"),
        "missing_evidence": sum(1 for e in events if e["type"] == "missing_evidence"),
        "disappeared": sum(1 for e in events if e["type"] == "disappeared"),
        "new_detection": len(new_detection_events),
    }

    report = {
        "schema_version": 1,
        "generated_at": datetime.now().isoformat(),
        "frame_id": frame_id,
        "summary": summary,
        "update_thresholds": cfg,
        "events": events,
    }
    updated["last_incremental_update"] = report
    return updated, report


def _parse_key_values(values: Optional[List[str]]) -> Dict[str, float]:
    result: Dict[str, float] = {}
    for item in values or []:
        if "=" not in item:
            continue
        key, value = item.split("=", 1)
        try:
            result[key.strip()] = float(value)
        except ValueError:
            continue
    return result


def _load_pipeline_config(path: Optional[str]) -> Dict[str, Any]:
    if not path:
        return {}

    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file does not exist: {config_path}")

    text = config_path.read_text(encoding="utf-8")
    if config_path.suffix.lower() == ".json":
        data = json.loads(text)
    else:
        try:
            import yaml  # type: ignore
        except ImportError as exc:  # pragma: no cover - depends on runtime environment
            raise ImportError("PyYAML is required to load YAML config files") from exc
        data = yaml.safe_load(text)
    return data if isinstance(data, dict) else {}


def _parse_categories(value: Optional[str]) -> Optional[List[str]]:
    if not value:
        return None
    categories = [_slug(item) for item in str(value).split(",")]
    categories = [item for item in categories if item]
    return categories or None


def _parse_image_shape(value: Optional[str], depth: np.ndarray) -> Tuple[int, int]:
    if not value:
        return int(depth.shape[0]), int(depth.shape[1])
    normalized = str(value).lower().replace("x", ",").replace(" ", ",")
    parts = [item for item in normalized.split(",") if item]
    if len(parts) != 2:
        raise ValueError("--image-shape must be H,W or HxW")
    return int(parts[0]), int(parts[1])


def main() -> None:
    parser = argparse.ArgumentParser(description="One-frame object-level scene graph update")
    parser.add_argument("--scene-graph", required=True, help="Previous scene_graph.json")
    parser.add_argument("--config", default=None, help="Optional config.yaml/json for thresholds and service endpoints")
    parser.add_argument("--image", default=None, help="Current RGB image path, required for --auto-detect")
    parser.add_argument("--depth", required=True, help="Current depth file (.npy meters or uint16 depth image)")
    parser.add_argument("--pose", required=True, help="Current camera-to-world pose file/line")
    parser.add_argument("--intrinsics", required=True, help="fx fy cx cy file or JSON")
    parser.add_argument("--detections", default=None, help="Optional current-frame detection JSON")
    parser.add_argument("--auto-detect", action="store_true", help="Call VLM + SAM3 to produce current-frame detections")
    parser.add_argument("--categories", default=None, help="Comma-separated categories for SAM3; skips VLM category discovery")
    parser.add_argument("--vlm-url", default=None, help="OpenAI-compatible VLM chat completions URL")
    parser.add_argument("--vlm-model", default=None, help="VLM model name")
    parser.add_argument("--sam3-url", default=None, help="SAM3 /predict URL")
    parser.add_argument("--sam3-max-detections", type=int, default=5, help="Max SAM3 masks per category")
    parser.add_argument("--min-detection-points", type=int, default=30, help="Min 3D points to keep an auto-detected object")
    parser.add_argument("--detection-output", default=None, help="Optional path to save generated/current detections JSON")
    parser.add_argument("--output", default=None, help="Updated scene graph output path")
    parser.add_argument("--report", default=None, help="Incremental update report output path")
    parser.add_argument("--frame-id", default=None, help="Current frame id/name")
    parser.add_argument("--depth-scale", type=float, default=1000.0, help="Scale for integer depth images")
    parser.add_argument("--depth-min", type=float, default=0.0, help="Minimum valid depth in meters")
    parser.add_argument("--depth-max", type=float, default=15.0, help="Maximum valid depth in meters")
    parser.add_argument("--image-shape", default=None, help="Projection shape H,W. Default: depth shape")
    parser.add_argument("--update-param", action="append", default=[], help="Override update threshold, key=value")
    args = parser.parse_args()

    pipeline_config = _load_pipeline_config(args.config)
    update_config = dict(pipeline_config.get("object_lifecycle", {}) or {})
    update_config.update(_parse_key_values(args.update_param))

    services = pipeline_config.get("services", {}) or {}
    models = pipeline_config.get("models", {}) or {}
    vlm_url = args.vlm_url or services.get("vlm_api_url") or DEFAULT_VLM_URL
    vlm_model = args.vlm_model or models.get("vlm_model_name") or DEFAULT_VLM_MODEL
    sam3_url = args.sam3_url or services.get("sam3_url") or DEFAULT_SAM3_URL
    sam3_batch_url = sam3_url.rsplit("/", 1)[0] + "/predict_batch"

    scene_graph_path = Path(args.scene_graph)
    scene_graph = json.loads(scene_graph_path.read_text(encoding="utf-8"))
    depth = load_depth_meters(args.depth, depth_scale=args.depth_scale)
    image_shape = _parse_image_shape(args.image_shape, depth)
    K = load_intrinsics(args.intrinsics)
    T_c2w = load_pose_matrix(args.pose)
    detections = load_detections(args.detections)

    auto_detection_info = None
    if args.auto_detect and not detections:
        detections, auto_detection_info = auto_detect_current_frame(
            image_path=args.image,
            scene_graph=scene_graph,
            depth=depth,
            K=K,
            T_c2w=T_c2w,
            categories=_parse_categories(args.categories),
            vlm_url=vlm_url,
            vlm_model=vlm_model,
            sam3_url=sam3_url,
            sam3_batch_url=sam3_batch_url,
            sam3_max_detections=args.sam3_max_detections,
            min_points=args.min_detection_points,
            depth_min=args.depth_min,
            depth_max=args.depth_max,
        )

    if args.detection_output:
        detection_output_path = Path(args.detection_output)
        detection_output_path.parent.mkdir(parents=True, exist_ok=True)
        detection_output_path.write_text(
            json.dumps({"objects": detections, "auto_detection": auto_detection_info}, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    updated, report = update_scene_graph_with_observation(
        scene_graph=scene_graph,
        detections=detections,
        update_config=update_config,
        frame_id=args.frame_id,
    )
    if auto_detection_info is not None:
        report["auto_detection"] = auto_detection_info
        updated["last_incremental_update"] = report
    if args.config:
        report["config_file"] = str(Path(args.config))
        updated["last_incremental_update"] = report

    output_path = Path(args.output) if args.output else scene_graph_path.with_name("scene_graph_incremental.json")
    report_path = Path(args.report) if args.report else scene_graph_path.with_name("incremental_update_report.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(updated, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

    print(f"Updated scene graph: {output_path}")
    print(f"Incremental report: {report_path}")
    print(json.dumps(report["summary"], indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
