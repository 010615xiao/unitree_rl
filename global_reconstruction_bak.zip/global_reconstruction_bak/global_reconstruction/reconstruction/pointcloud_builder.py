"""点云重建后端：统一封装三种重建策略（点云叠加 / 稀疏体素融合 / TSDF）。

主脚本 reconstruct_and_segment.py 只负责编排（调度、轨迹对齐、房间/物体分割、保存），
本模块负责点云重建的具体实现：

  - integrate_frame : 逐帧融合（fusion.integrate 或 depth_to_pointcloud + 增量下采样；+ TSDF.integrate）
  - build           : 循环后导出主点云（fusion stable/complete 或 叠加最终下采样）+ DBSCAN 去噪
  - extract_tsdf    : TSDF 旁路点云导出（原始，未旋转；主脚本套轨迹对齐后保存）
  - filter_objects_by_voxel_stability : 用融合体素状态过滤瞬态物体（依赖 fusion_map）

轨迹对齐旋转仍由主脚本统一处理（点云 + poses + 物体一致），故 build() 产出的是
里程计坐标系下的原始点云；voxel_downsample 作为公共函数被 segment_floors 等也使用。
"""

import json
import numpy as np
import open3d as o3d

from global_reconstruction.reconstruction.voxel_fusion import SparseVoxelFusion


# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------

def voxel_downsample(points, colors, voxel_size):
    """体素下采样（公共函数，segment_floors 等也使用）。"""
    if len(points) == 0:
        return points, colors

    indices = np.floor(points / voxel_size).astype(np.int64)
    _, unique_idx = np.unique(indices, axis=0, return_index=True)

    return points[unique_idx], colors[unique_idx]


def _depth_to_pointcloud(depth, color, K, T_c2w, depth_min, depth_max,
                         confidence=None, conf_threshold=0.0):
    """深度图 + 彩色图 -> 3D 点云。"""
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    valid_mask = (depth > depth_min) & (depth < depth_max)
    if confidence is not None and conf_threshold > 0:
        valid_mask &= (confidence >= conf_threshold)
    v, u = np.where(valid_mask)

    if len(u) == 0:
        return np.empty((0, 3)), np.empty((0, 3))

    depths = depth[v, u].flatten()

    X_cam = (u - cx) * depths / fx
    Y_cam = (v - cy) * depths / fy
    Z_cam = depths

    points_cam = np.stack([X_cam, Y_cam, Z_cam, np.ones_like(X_cam)], axis=1)
    points_world = (T_c2w @ points_cam.T).T[:, :3]

    colors = color[v, u]
    return points_world, colors


def _dbscan_filter_point_cloud(points, colors, eps, min_points, label="pointcloud"):
    """Run DBSCAN and keep the largest non-noise cluster."""
    stats = {
        "label": label,
        "before": int(len(points)),
        "after": int(len(points)),
        "removed": 0,
        "kept_cluster_label": None,
    }
    if len(points) == 0:
        return points, colors, stats

    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    pcd.colors = o3d.utility.Vector3dVector(colors) if len(colors) == len(points) else None

    labels = np.array(pcd.cluster_dbscan(eps=eps, min_points=min_points, print_progress=False))
    valid_labels = labels[labels >= 0]
    if len(valid_labels) == 0:
        return points, colors, stats

    cluster_sizes = np.bincount(valid_labels)
    max_cluster = int(np.argmax(cluster_sizes))
    inlier_mask = labels == max_cluster
    filtered_points = points[inlier_mask]
    filtered_colors = colors[inlier_mask]

    stats.update({
        "after": int(len(filtered_points)),
        "removed": int(len(points) - len(filtered_points)),
        "kept_cluster_label": max_cluster,
    })
    return filtered_points, filtered_colors, stats


# ---------------------------------------------------------------------------
# 重建后端
# ---------------------------------------------------------------------------

class PointCloudBuilder:
    """统一封装 点云叠加 / 稀疏体素融合 / TSDF 三种策略。

    用法：
        builder = PointCloudBuilder.from_config(cfg)
        for frame in frames:
            builder.integrate_frame(depth, color, K, T_c2w, confidence, frame_id)
        if not builder.build(OUTPUT_DIR):
            return
        global_points = builder.global_points   # 原始（里程计系）点云，主脚本再做轨迹对齐
    """

    def __init__(self, *, voxel_size, depth_min, depth_max, confidence_threshold,
                 fusion_enabled, fusion_config, tsdf_enabled, tsdf_voxel_length,
                 tsdf_sdf_trunc, tsdf_depth_sampling_stride, tsdf_export_mesh,
                 dbscan_eps, dbscan_min_points, incremental_ds_every=50):
        self.voxel_size = voxel_size
        self.depth_min = depth_min
        self.depth_max = depth_max
        self.confidence_threshold = confidence_threshold
        self.fusion_enabled = fusion_enabled
        self.fusion_config = fusion_config
        self.tsdf_enabled = tsdf_enabled
        self.tsdf_export_mesh = tsdf_export_mesh
        self.dbscan_eps = dbscan_eps
        self.dbscan_min_points = dbscan_min_points
        self.incremental_ds_every = incremental_ds_every

        # 稀疏体素融合图
        self.fusion_map = None
        if fusion_enabled:
            self.fusion_map = SparseVoxelFusion.from_config(
                fusion_config,
                voxel_size=voxel_size,
                depth_min=depth_min,
                depth_max=depth_max,
                confidence_threshold=confidence_threshold,
            )

        # TSDF 旁路 volume（Open3D ScalableTSDFVolume）
        self.tsdf_volume = None
        if tsdf_enabled:
            self.tsdf_volume = o3d.pipelines.integration.ScalableTSDFVolume(
                voxel_length=tsdf_voxel_length,
                sdf_trunc=tsdf_sdf_trunc,
                color_type=o3d.pipelines.integration.TSDFVolumeColorType.RGB8,
                depth_sampling_stride=tsdf_depth_sampling_stride,
            )

        # 点云叠加缓冲区（仅 fusion 关闭时使用）
        self._all_global_points = []
        self._all_global_colors = []
        self._merged_global_points = np.empty((0, 3), dtype=np.float32)
        self._merged_global_colors = np.empty((0, 3), dtype=np.uint8)

        # build() 后填充：
        self.global_points = None
        self.global_colors = None
        self.stable_raw_points = None
        self.stable_raw_colors = None
        self.complete_raw_points = None
        self.complete_raw_colors = None
        self.complete_denoised_points = None
        self.complete_denoised_colors = None
        self.fusion_stats = None

    @classmethod
    def from_config(cls, cfg):
        rec = cfg.reconstruction
        fusion_config = rec.get('fusion', {}) or {}
        tsdf_config = rec.get('tsdf', {}) or {}
        return cls(
            voxel_size=rec.voxel_size,
            depth_min=rec.depth_min,
            depth_max=rec.depth_max,
            confidence_threshold=getattr(rec, 'confidence_threshold', 0.0),
            fusion_enabled=bool(fusion_config.get('enabled', True)),
            fusion_config=fusion_config,
            tsdf_enabled=bool(tsdf_config.get('enabled', False)),
            tsdf_voxel_length=float(tsdf_config.get('voxel_length', rec.voxel_size)),
            tsdf_sdf_trunc=float(tsdf_config.get('sdf_trunc', 0.08)),
            tsdf_depth_sampling_stride=int(tsdf_config.get('depth_sampling_stride', 4)),
            tsdf_export_mesh=bool(tsdf_config.get('export_mesh', False)),
            dbscan_eps=rec.dbscan_eps,
            dbscan_min_points=rec.dbscan_min_points,
        )

    # ------------------------------------------------------------------
    # 逐帧
    # ------------------------------------------------------------------
    def integrate_frame(self, depth, color, K, T_c2w, confidence=None, frame_id=None):
        """逐帧融合一帧 RGB-D。fusion 与 tsdf 由配置独立控制。"""
        if self.fusion_enabled:
            self.fusion_map.integrate(
                depth, color, K, T_c2w,
                confidence=confidence, frame_id=frame_id,
            )
        else:
            points_global, colors_global = _depth_to_pointcloud(
                depth, color, K, T_c2w,
                self.depth_min, self.depth_max,
                confidence, self.confidence_threshold,
            )

            if len(points_global) > 0:
                self._all_global_points.append(points_global)
                self._all_global_colors.append(colors_global)

            # 增量式下采样: 每 N 帧合并+体素下采样, 控制内存
            if len(self._all_global_points) >= self.incremental_ds_every:
                batch_pts = np.vstack(self._all_global_points)
                batch_cols = np.vstack(self._all_global_colors)
                if len(self._merged_global_points) > 0:
                    batch_pts = np.vstack([self._merged_global_points, batch_pts])
                    batch_cols = np.vstack([self._merged_global_colors, batch_cols])
                self._merged_global_points, self._merged_global_colors = voxel_downsample(
                    batch_pts, batch_cols, self.voxel_size)
                self._all_global_points = []
                self._all_global_colors = []

        if self.tsdf_enabled:
            # extrinsic 传 w->c (np.linalg.inv(T_c2w))；depth_scale=1.0 (depth 已是 float32 米)
            # 与 fusion/叠加一致的距离过滤 [depth_min, depth_max] + 置信度过滤
            _valid = (depth > self.depth_min) & (depth < self.depth_max)
            if confidence is not None and self.confidence_threshold > 0:
                _valid &= (confidence >= self.confidence_threshold)
            _depth_tsdf = np.where(_valid, depth, 0.0).astype(np.float32)
            _rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
                o3d.geometry.Image(color.astype(np.uint8)),
                o3d.geometry.Image(_depth_tsdf),
                depth_scale=1.0,
                depth_trunc=self.depth_max,
                convert_rgb_to_intensity=False,
            )
            _h_ds, _w_ds = depth.shape[:2]
            _K_tsdf = o3d.camera.PinholeCameraIntrinsic(
                _w_ds, _h_ds,
                float(K[0, 0]), float(K[1, 1]),
                float(K[0, 2]), float(K[1, 2]),
            )
            self.tsdf_volume.integrate(_rgbd, _K_tsdf, np.linalg.inv(T_c2w))

    # ------------------------------------------------------------------
    # 导出
    # ------------------------------------------------------------------
    def build(self, output_dir=None):
        """循环结束后调用：导出主点云 + DBSCAN 去噪。

        填充 self.global_points/colors 等属性。返回 False 表示点云为空
        （主脚本据此 return，等价于原内联逻辑的 early return）。
        """
        if self.fusion_enabled:
            assert self.fusion_map is not None
            global_points, global_colors = self.fusion_map.to_point_cloud(mode="stable")
            if self.fusion_config.get("export_complete_map", True):
                complete_global_points, complete_global_colors = self.fusion_map.to_point_cloud(mode="complete")
            else:
                complete_global_points = np.empty((0, 3), dtype=np.float32)
                complete_global_colors = np.empty((0, 3), dtype=np.uint8)

            self.stable_raw_points = global_points.copy()
            self.stable_raw_colors = global_colors.copy()
            self.complete_raw_points = complete_global_points.copy()
            self.complete_raw_colors = complete_global_colors.copy()
            self.fusion_stats = self.fusion_map.stats()
            self.fusion_stats["stable_before_denoise_points"] = int(len(self.stable_raw_points))
            self.fusion_stats["complete_before_denoise_points"] = int(len(self.complete_raw_points))
            self.fusion_stats["main_output_mode"] = "stable"

            if len(global_points) == 0 and len(complete_global_points) > 0:
                print("  警告：稳定层为空，使用 complete 点云作为主输出兜底")
                global_points = complete_global_points.copy()
                global_colors = complete_global_colors.copy()
                self.fusion_stats["main_output_mode"] = "complete_fallback"

            fusion_stats_file = None
            if output_dir is not None:
                fusion_stats_file = output_dir / "global" / "voxel_fusion_stats.json"
                fusion_stats_file.parent.mkdir(parents=True, exist_ok=True)

            if len(global_points) == 0:
                print("  错误：融合地图没有导出任何可用点云")
                if fusion_stats_file is not None:
                    with open(fusion_stats_file, "w", encoding="utf-8") as f:
                        json.dump(self.fusion_stats, f, indent=2, ensure_ascii=False)
                    print(f"  融合统计已保存：{fusion_stats_file}")
                return False

            print(
                f"\n  全局点云 raw (stable): {self.fusion_stats['stable_before_denoise_points']:,} 点, "
                f"complete: {self.fusion_stats['complete_before_denoise_points']:,} 点, "
                f"main: {len(global_points):,} 点 "
                f"/ {self.fusion_stats['total_voxels']:,} voxels"
            )
        else:
            # 合并已增量下采样的点云 + 最后一批未下采样的点
            if self._all_global_points:
                batch_pts = np.vstack(self._all_global_points)
                batch_cols = np.vstack(self._all_global_colors)
                if len(self._merged_global_points) > 0:
                    batch_pts = np.vstack([self._merged_global_points, batch_pts])
                    batch_cols = np.vstack([self._merged_global_colors, batch_cols])
                self._merged_global_points, self._merged_global_colors = voxel_downsample(
                    batch_pts, batch_cols, self.voxel_size)
                self._all_global_points = []
                self._all_global_colors = []

            if len(self._merged_global_points) == 0:
                print("  错误：没有生成任何点云!")
                return False

            global_points = self._merged_global_points
            global_colors = self._merged_global_colors
            print(f"\n  全局点云 (增量下采样后): {len(global_points):,} 点")

        # DBSCAN 去噪 (main/stable)
        print("\n  DBSCAN 去噪...")
        global_points, global_colors, stable_denoise_stats = _dbscan_filter_point_cloud(
            global_points, global_colors,
            self.dbscan_eps, self.dbscan_min_points,
            label="main_stable",
        )
        print(
            f"  stable/main: {stable_denoise_stats['before']:,} -> "
            f"{stable_denoise_stats['after']:,} 点 "
            f"(移除 {stable_denoise_stats['removed']:,})"
        )

        if self.fusion_enabled and self.complete_raw_points is not None and len(self.complete_raw_points) > 0:
            self.complete_denoised_points, self.complete_denoised_colors, complete_denoise_stats = _dbscan_filter_point_cloud(
                self.complete_raw_points,
                self.complete_raw_colors,
                self.dbscan_eps,
                self.dbscan_min_points,
                label="complete",
            )
            print(
                f"  complete: {complete_denoise_stats['before']:,} -> "
                f"{complete_denoise_stats['after']:,} 点 "
                f"(移除 {complete_denoise_stats['removed']:,})"
            )
        else:
            complete_denoise_stats = None

        if self.fusion_enabled and self.fusion_stats is not None:
            self.fusion_stats["stable_after_denoise_points"] = int(len(global_points))
            self.fusion_stats["stable_denoise"] = stable_denoise_stats
            if complete_denoise_stats is not None:
                self.fusion_stats["complete_after_denoise_points"] = int(len(self.complete_denoised_points))
                self.fusion_stats["complete_denoise"] = complete_denoise_stats
            else:
                self.fusion_stats["complete_after_denoise_points"] = 0
            if fusion_stats_file is not None:
                with open(fusion_stats_file, "w", encoding="utf-8") as f:
                    json.dump(self.fusion_stats, f, indent=2, ensure_ascii=False)
                print(f"  融合统计已保存：{fusion_stats_file}")

        self.global_points = global_points
        self.global_colors = global_colors
        return True

    # ------------------------------------------------------------------
    # 视频渲染：获取当前累积点云
    # ------------------------------------------------------------------
    def get_current_cloud(self):
        """返回当前已累积的点云 (points, colors)，用于增量视频渲染。

        fusion 模式：从 fusion_map 导出 stable 层；
        叠加模式：合并 _merged + 缓冲区。
        不做 DBSCAN 去噪（那是 build() 的事）。
        """
        if self.fusion_enabled and self.fusion_map is not None:
            pts, cols = self.fusion_map.to_point_cloud(mode="stable")
            return pts, cols
        # 叠加模式
        pts_list = list(self._all_global_points)
        cols_list = list(self._all_global_colors)
        if len(self._merged_global_points) > 0:
            pts_list.insert(0, self._merged_global_points)
            cols_list.insert(0, self._merged_global_colors)
        if not pts_list:
            return np.empty((0, 3), dtype=np.float32), np.empty((0, 3), dtype=np.uint8)
        return np.vstack(pts_list), np.vstack(cols_list)

    # ------------------------------------------------------------------
    # TSDF 旁路
    # ------------------------------------------------------------------
    def extract_tsdf(self):
        """提取 TSDF 旁路点云（原始，未旋转）。

        返回 (points_float32, colors_uint8) 或 None。主脚本套轨迹对齐后保存。
        """
        if not self.tsdf_enabled or self.tsdf_volume is None:
            return None
        pcd = self.tsdf_volume.extract_point_cloud()
        pts = np.asarray(pcd.points, dtype=np.float32)
        if len(pcd.colors) == len(pts):
            cols = (np.clip(np.asarray(pcd.colors), 0.0, 1.0) * 255.0).astype(np.uint8)
        else:
            cols = np.tile(np.array([128, 128, 128], dtype=np.uint8), (len(pts), 1))
        return pts, cols

    def extract_tsdf_mesh(self):
        """提取 TSDF triangle mesh（仅 export_mesh=True 时主脚本调用）。"""
        if self.tsdf_volume is None:
            return None
        return self.tsdf_volume.extract_triangle_mesh()

    # ------------------------------------------------------------------
    # 物体体素稳定性过滤
    # ------------------------------------------------------------------
    def filter_objects_by_voxel_stability(self, objects, min_stable_ratio, R_inv=None,
                                          merge_categories=None, downsample=True):
        """用融合体素状态过滤物体：物体点云中有多少比例落在稳定体素上。

        仅 fusion 启用有效。返回 (filtered_objects, removed_objects_list)。

        参数:
            merge_categories: 需跳过稳定性过滤的结构背景类 (如 ['wall','floor'])。
                这些类直接保留，不参与瞬态伪影判定。
            downsample: True 时对物体点云先按 voxel_size 做体素下采样再判定，
                避免合并后的 wall/floor 物体点云过大 (可达上亿点) 导致极慢/爆内存。
        """
        if self.fusion_map is None:
            return list(objects), []

        soa = self.fusion_map._soa
        n_voxels = soa.n
        vs = self.fusion_map.voxel_size

        # merge_categories 转小写集合，便于按类别跳过
        if merge_categories:
            skip_cats = {str(c).lower() for c in merge_categories}
        else:
            skip_cats = set()

        all_keys = soa.keys[:n_voxels]
        stable_mask = soa.is_stable[:n_voxels]

        # 用 np.unique 去重后转 tuple（去重后数量大幅减少，速度可接受）
        def _keys_to_set(keys):
            if len(keys) == 0:
                return set()
            unique = np.unique(keys, axis=0)
            return {tuple(k) for k in unique}

        stable_keys_set = _keys_to_set(all_keys[stable_mask])
        all_keys_set = _keys_to_set(all_keys)

        filtered = []
        filtered_out = []
        for obj in objects:
            pts = obj['points']
            if len(pts) == 0:
                filtered_out.append((obj, "空点云"))
                continue

            # 结构背景类 (wall/floor) 跳过瞬态过滤，直接保留
            cat = str(obj.get('category', '')).lower()
            if cat in skip_cats:
                obj['voxel_stable_ratio'] = None
                obj['voxel_observed_ratio'] = None
                filtered.append(obj)
                continue

            if R_inv is not None:
                pts_for_lookup = (R_inv @ pts.T).T
            else:
                pts_for_lookup = pts

            # 体素下采样：避免合并后的大物体 (上亿点) 导致 np.unique 极慢/爆内存。
            # 下采样到 vs 网格，等价于直接 floor 到体素键再取唯一，与稳定率判定单位一致。
            keys = np.floor(pts_for_lookup / vs).astype(np.int64)
            if downsample:
                # np.unique(axis=0) 本身就是按体素去重，等价于体素下采样
                unique_keys = np.unique(keys, axis=0)
            else:
                unique_keys = keys
            unique_set = _keys_to_set(unique_keys)

            stable_count = len(unique_set & stable_keys_set)
            observed_count = len(unique_set & all_keys_set)

            stable_ratio = stable_count / len(unique_keys)
            observed_ratio = observed_count / len(unique_keys)

            if stable_ratio >= min_stable_ratio:
                obj['voxel_stable_ratio'] = round(stable_ratio, 3)
                obj['voxel_observed_ratio'] = round(observed_ratio, 3)
                filtered.append(obj)
            else:
                filtered_out.append((obj, f"stable_ratio={stable_ratio:.1%}, observed_ratio={observed_ratio:.1%}"))

        return filtered, filtered_out
