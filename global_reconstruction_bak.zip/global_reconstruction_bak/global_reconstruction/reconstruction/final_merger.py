"""Final object merging using voxel overlap and centroid distance.

Provides voxel-based merge strategies for consolidating object instances
across frames into final scene graph objects.
"""

from collections import defaultdict
import numpy as np


def can_merge_objects(obj_a, obj_b, overlap_threshold=0.30, voxel_size=0.02,
                      containment_threshold=0.50, centroid_distance_threshold=0.50):
    """Determine if two objects should be merged.
    
    Uses three complementary strategies:
    
    Strategy 1 - Bidirectional voxel occupancy:
        The ratio of voxels in the AABB intersection region, both must exceed
        threshold to merge. Suitable for objects of similar size.
    
    Strategy 2 - Containment ratio:
        What proportion of the smaller object's voxels fall within the larger
        object's AABB. Triggers merge when small object is almost entirely
        contained by large object, solving cases where AABB IoU fails for
        size-disparate objects.
    
    Strategy 3 - Centroid distance:
        When voxel overlap is insufficient, check centroid distance. Suitable
        for cases where the same physical object is detected from different
        frames with non-overlapping point clouds.
    
    Supports precomputed voxel data (via _precomputed field) to avoid
    redundant voxelization.
    
    Args:
        obj_a: First object dict with 'points' key
        obj_b: Second object dict with 'points' key
        overlap_threshold: Minimum bidirectional voxel occupancy ratio
        voxel_size: Voxel size in meters for voxelization
        containment_threshold: Minimum containment ratio for strategy 2
        centroid_distance_threshold: Maximum centroid distance in meters for strategy 3
    
    Returns:
        bool: True if objects should be merged
    """
    if len(obj_a['points']) == 0 or len(obj_b['points']) == 0:
        return False

    # Use precomputed data if available, otherwise compute on demand
    pre_a = obj_a.get('_precomputed')
    pre_b = obj_b.get('_precomputed')

    if pre_a is not None:
        unique_voxels_a = pre_a['unique_voxels']
        bbox_a_min, bbox_a_max = pre_a['bbox_min'], pre_a['bbox_max']
    else:
        pts_a = obj_a['points']
        bbox_a_min, bbox_a_max = pts_a.min(axis=0), pts_a.max(axis=0)
        unique_voxels_a = np.unique(np.floor(pts_a / voxel_size).astype(np.int64), axis=0)

    if pre_b is not None:
        unique_voxels_b = pre_b['unique_voxels']
        bbox_b_min, bbox_b_max = pre_b['bbox_min'], pre_b['bbox_max']
    else:
        pts_b = obj_b['points']
        bbox_b_min, bbox_b_max = pts_b.min(axis=0), pts_b.max(axis=0)
        unique_voxels_b = np.unique(np.floor(pts_b / voxel_size).astype(np.int64), axis=0)

    total_voxels_a = len(unique_voxels_a)
    total_voxels_b = len(unique_voxels_b)

    # AABB pre-filter: skip if not intersecting
    inter_min = np.maximum(bbox_a_min, bbox_b_min)
    inter_max = np.minimum(bbox_a_max, bbox_b_max)
    if np.any(inter_min >= inter_max):
        return False

    def count_voxels_in_bbox(unique_voxels, region_min, region_max, voxel_size):
        rmin = np.floor(region_min / voxel_size).astype(np.int64)
        rmax = np.floor(region_max / voxel_size).astype(np.int64)
        in_region = np.all((unique_voxels >= rmin) & (unique_voxels <= rmax), axis=1)
        return int(np.sum(in_region))

    # Strategy 2: Containment ratio
    if total_voxels_a >= total_voxels_b:
        small_voxels, large_bbox_min, large_bbox_max = unique_voxels_b, bbox_a_min, bbox_a_max
        small_total = total_voxels_b
    else:
        small_voxels, large_bbox_min, large_bbox_max = unique_voxels_a, bbox_b_min, bbox_b_max
        small_total = total_voxels_a

    small_in_large = count_voxels_in_bbox(small_voxels, large_bbox_min, large_bbox_max, voxel_size)
    containment_ratio = small_in_large / small_total if small_total > 0 else 0.0

    if containment_ratio >= containment_threshold:
        return True

    # Strategy 1: Bidirectional voxel occupancy
    voxels_a_in_inter = count_voxels_in_bbox(unique_voxels_a, inter_min, inter_max, voxel_size)
    voxels_b_in_inter = count_voxels_in_bbox(unique_voxels_b, inter_min, inter_max, voxel_size)

    ratio_a = voxels_a_in_inter / total_voxels_a if total_voxels_a > 0 else 0.0
    ratio_b = voxels_b_in_inter / total_voxels_b if total_voxels_b > 0 else 0.0

    if ratio_a >= overlap_threshold and ratio_b >= overlap_threshold:
        return True

    # NOTE: the legacy "centroid distance" merge (merge close-but-non-overlapping
    # point clouds) is intentionally REMOVED. The track-by-detection ObjectTracker
    # already associates same-object multi-frame detections into one instance in
    # the loop, so close non-overlapping instances are genuinely different objects
    # (e.g. two chairs side by side) and must NOT be merged. Keeping it caused
    # union-find to chain-merge all nearby chairs into one (86k-point chair_1).
    return False


def precompute_voxel_data(obj, voxel_size):
    """Precompute voxelized data and AABB for an object.
    
    Args:
        obj: Object dict with 'points' key
        voxel_size: Voxel size in meters
    
    Returns:
        dict with 'unique_voxels', 'bbox_min', 'bbox_max'
    """
    pts = obj['points']
    if len(pts) == 0:
        return {'unique_voxels': np.empty((0, 3), dtype=np.int64),
                'bbox_min': np.zeros(3), 'bbox_max': np.zeros(3)}
    return {
        'unique_voxels': np.unique(np.floor(pts / voxel_size).astype(np.int64), axis=0),
        'bbox_min': pts.min(axis=0),
        'bbox_max': pts.max(axis=0),
    }


def merge_cluster(cluster, merge_source_views_fn, object_source_view_limit):
    """Merge all object instances in a cluster into a single object.
    
    Args:
        cluster: List of object dicts to merge
        merge_source_views_fn: Function to merge source views
        object_source_view_limit: Maximum number of source views to keep
    
    Returns:
        Merged object dict with source_instance_ids preserved
    """
    all_pts = np.vstack([c['points'] for c in cluster])
    source_views = merge_source_views_fn(cluster)
    
    # Deduplicate source frames and images
    source_frames = []
    source_images = []
    seen_frames = set()
    seen_images = set()
    
    for c in cluster:
        frame = c.get('frame')
        if frame and frame not in seen_frames and len(source_frames) < object_source_view_limit:
            source_frames.append(str(frame))
            seen_frames.add(frame)
        
        image_path = c.get('image_path')
        if image_path and image_path not in seen_images and len(source_images) < object_source_view_limit:
            source_images.append(str(image_path))
            seen_images.add(image_path)
    
    for view in source_views:
        frame = view.get('frame')
        if frame and frame not in seen_frames and len(source_frames) < object_source_view_limit:
            source_frames.append(str(frame))
            seen_frames.add(frame)
        
        image_path = view.get('image_path')
        if image_path and image_path not in seen_images and len(source_images) < object_source_view_limit:
            source_images.append(str(image_path))
            seen_images.add(image_path)
    
    representative_source_view = source_views[0] if source_views else None

    # Unify category names: take the MAJORITY category, weighted by voxel count
    # (len(points)). This ensures that if a cluster spans multiple categories (e.g.
    # via cross-category merge of semantically-similar names), the dominant object's
    # category wins -- not whichever instance happened to be first. Falls back to
    # instance-count, then hits, as tie-breaks.
    cat_voxels = {}
    cat_insts = {}
    cat_hits = {}
    for c in cluster:
        cat = c.get('category', '')
        cat_voxels[cat] = cat_voxels.get(cat, 0) + len(c.get('points', []))
        cat_insts[cat] = cat_insts.get(cat, 0) + 1
        cat_hits[cat] = cat_hits.get(cat, 0) + c.get('num_frames', 1)
    unified = max(cat_voxels, key=lambda cat: (cat_voxels[cat], cat_insts[cat], cat_hits[cat]))
    
    # Extract source instance IDs from all members
    # Each member may have either:
    # - '_merged_from': list of D-indices (from object_tracker to_record)
    # - '_det_id': single D-index (from raw detection)
    source_instance_ids = []
    seen_ids = set()
    for c in cluster:
        if '_merged_from' in c:
            for det_id in c['_merged_from']:
                if isinstance(det_id, str) and det_id.startswith('D'):
                    obj_idx = int(det_id[1:])
                elif isinstance(det_id, int):
                    obj_idx = det_id
                else:
                    continue
                if obj_idx not in seen_ids:
                    source_instance_ids.append(obj_idx)
                    seen_ids.add(obj_idx)
        elif '_det_id' in c:
            det_id = c['_det_id']
            if isinstance(det_id, str) and det_id.startswith('D'):
                obj_idx = int(det_id[1:])
            elif isinstance(det_id, int):
                obj_idx = det_id
            else:
                continue
            if obj_idx not in seen_ids:
                source_instance_ids.append(obj_idx)
                seen_ids.add(obj_idx)

    return {
        'category': unified,
        'points': all_pts,
        'num_frames': len(cluster),
        'source_frames': source_frames,
        'source_images': source_images,
        'source_views': source_views,
        'source_instance_ids': source_instance_ids,  # 保存原始实例 ID
        'representative_source_view': representative_source_view,
        'representative_frame': (
            representative_source_view.get('frame')
            if representative_source_view
            else next((str(c.get('frame')) for c in cluster if c.get('frame')), None)
        ),
        'representative_image': (
            representative_source_view.get('image_path')
            if representative_source_view
            else next((str(c.get('image_path')) for c in cluster if c.get('image_path')), None)
        ),
    }


def iterative_merge_objects(all_objects, voxel_size, overlap_threshold=0.30,
                            containment_threshold=0.50, centroid_distance_threshold=0.50,
                            merge_source_views_fn=None, object_source_view_limit=10,
                            categories_semantically_similar_fn=None, max_rounds=4):
    """Iteratively merge objects using union-find to handle transitive relationships.
    
    Optimization: precompute voxel data + group by category for comparison,
    avoiding O(n²) all-pairs comparison + redundant voxelization.
    
    Args:
        all_objects: List of all object dicts
        voxel_size: Voxel size in meters
        overlap_threshold: Threshold for bidirectional voxel occupancy
        containment_threshold: Threshold for containment ratio
        centroid_distance_threshold: Threshold for centroid distance in meters
        merge_source_views_fn: Function to merge source views
        object_source_view_limit: Maximum number of source views to keep
        max_rounds: Maximum number of merge rounds
    
    Returns:
        List of merged object dicts
    """
    objects = list(all_objects)

    # Precompute voxel data and AABB for each object
    for obj in objects:
        obj['_precomputed'] = precompute_voxel_data(obj, voxel_size)

    rounds = [
        {'overlap': overlap_threshold, 'semantic': True, 'dist': None, 
         'label': f'体素占用≥{int(overlap_threshold*100)}% (含同义词)'},
    ]

    for round_idx, params in enumerate(rounds[:max_rounds]):
        prev_count = len(objects)
        n = len(objects)

        parent = list(range(n))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py

        # Group by category, only compare within same category (or semantically similar)
        cat_groups = defaultdict(list)
        for i in range(n):
            cat_groups[objects[i]['category']].append(i)

        cat_list = list(cat_groups.keys())

        for ci_idx in range(len(cat_list)):
            cat_a = cat_list[ci_idx]
            indices_a = cat_groups[cat_a]

            # Compare within same category
            for ii in range(len(indices_a)):
                for jj in range(ii + 1, len(indices_a)):
                    i, j = indices_a[ii], indices_a[jj]
                    if find(i) == find(j):
                        continue

                    if params['dist'] is not None:
                        ci = objects[i]['points'].mean(axis=0)
                        cj = objects[j]['points'].mean(axis=0)
                        if np.linalg.norm(ci - cj) > params['dist']:
                            continue

                    should_merge = False
                    if params['overlap'] > 0:
                        should_merge = can_merge_objects(
                            objects[i], objects[j],
                            overlap_threshold=params['overlap'],
                            voxel_size=voxel_size,
                            containment_threshold=containment_threshold,
                            centroid_distance_threshold=centroid_distance_threshold,
                        )
                    else:
                        should_merge = True

                    if should_merge:
                        union(i, j)

            # Compare between semantically similar categories
            if params['semantic'] and categories_semantically_similar_fn:
                for cj_idx in range(ci_idx + 1, len(cat_list)):
                    cat_b = cat_list[cj_idx]
                    if not categories_semantically_similar_fn(cat_a, cat_b):
                        continue
                    indices_b = cat_groups[cat_b]
                    for i in indices_a:
                        for j in indices_b:
                            if find(i) == find(j):
                                continue
                            if params['overlap'] > 0:
                                if can_merge_objects(objects[i], objects[j],
                                                      overlap_threshold=params['overlap'],
                                                      voxel_size=voxel_size,
                                                      containment_threshold=containment_threshold,
                                                      centroid_distance_threshold=centroid_distance_threshold):
                                    union(i, j)
                            else:
                                union(i, j)

        clusters = defaultdict(list)
        for i in range(n):
            clusters[find(i)].append(objects[i])

        new_objects = [merge_cluster(cluster, merge_source_views_fn, object_source_view_limit) 
                       for cluster in clusters.values()]

        # Recompute voxel data after merge (point cloud changed)
        for obj in new_objects:
            obj['_precomputed'] = precompute_voxel_data(obj, voxel_size)

        print(f"  Round {round_idx+1} ({params['label']}): {prev_count} → {len(new_objects)} 个物体")
        objects = new_objects

        if len(new_objects) >= prev_count:
            break

    # Clean up temporary fields
    for obj in objects:
        obj.pop('_precomputed', None)

    return objects
