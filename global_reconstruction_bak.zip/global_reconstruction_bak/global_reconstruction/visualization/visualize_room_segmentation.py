#!/usr/bin/env python3
"""
可视化房间分割结果：俯视图 + Voronoi 图 + 分割叠加图
"""

import numpy as np
import open3d as o3d
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scipy.spatial import Voronoi, voronoi_plot_2d
import json
import argparse
from pathlib import Path
from global_reconstruction.core.config_loader import project_root

BASE_DIR = project_root()
DEFAULT_OUTPUT_DIR = BASE_DIR / "unified_output" / "top_view"


def load_point_cloud(pcd_path):
    """加载点云"""
    pcd = o3d.io.read_point_cloud(pcd_path)
    points = np.asarray(pcd.points)
    colors = np.asarray(pcd.colors)
    if len(colors) == 0:
        colors = np.ones_like(points) * 0.5
    return points, colors


def create_top_view(points, colors, resolution=1000, height_range=None, floor_zero_level=None,
                    vertical_axis=1, horizontal_axes=None):
    """俯视图（水平面投影）"""
    if horizontal_axes is None:
        horizontal_axes = [i for i in range(3) if i != vertical_axis]

    if height_range is None:
        height_range = (points[:, vertical_axis].min(), points[:, vertical_axis].max())

    # 使用 floor_zero_level 作为高度过滤基准（避免 outlier 点影响范围）
    v_base = floor_zero_level if floor_zero_level is not None else height_range[0]

    # 从 floor_zero_level 向下 0.5m 到向上 4m，包含地面和墙面
    mask = (points[:, vertical_axis] >= v_base - 0.5) & \
           (points[:, vertical_axis] <= v_base + 4.0)
    proj_points = points[mask][:, horizontal_axes]
    proj_colors = colors[mask]

    print(f"    投影点：{len(proj_points):,} 点 (原始点云)")
    print(f"    高度范围：[{v_base - 0.5:.2f}, {v_base + 4.0:.2f}] (base={v_base:.2f})")

    # 创建 2D 直方图
    x_min, z_min = proj_points.min(axis=0)
    x_max, z_max = proj_points.max(axis=0)

    # 使用 bincount 加速计算（完全向量化）
    x_bins = np.linspace(x_min, x_max, resolution + 1)
    z_bins = np.linspace(z_min, z_max, resolution + 1)

    # 分配点到 bin
    x_idx = np.clip(np.digitize(proj_points[:, 0], x_bins) - 1, 0, resolution - 1)
    z_idx = np.clip(np.digitize(proj_points[:, 1], z_bins) - 1, 0, resolution - 1)

    # 密度图和颜色图
    # 直接使用 z_idx：z_min 映射到图像第 0 行（底部），z_max 映射到最后一行（顶部）
    flat_idx = z_idx * resolution + x_idx

    # 计算每个 bin 的点数
    count_img = np.bincount(flat_idx, minlength=resolution*resolution)
    count_img = count_img.reshape(resolution, resolution)

    # 计算每个 bin 的颜色和
    color_sum = np.zeros((resolution * resolution, 3))
    np.add.at(color_sum, flat_idx, proj_colors)
    color_sum = color_sum.reshape(resolution, resolution, 3)

    # 平均颜色
    mask_2d = count_img > 0
    density_img = np.zeros((resolution, resolution, 3))
    density_img[mask_2d] = color_sum[mask_2d] / count_img[mask_2d][:, np.newaxis]

    return density_img, (x_min, x_max, z_min, z_max)


def plot_voronoi_with_rooms(ax, room_centers, room_bboxes, bounds, colors=None,
                            horizontal_axes=None):
    """Voronoi 图和房间边界"""
    if horizontal_axes is None:
        horizontal_axes = [0, 2]

    x_min, x_max, z_min, z_max = bounds

    if colors is None:
        colors = plt.cm.tab10(np.linspace(0, 1, max(len(room_centers), 1)))

    # 房间中心
    ax.scatter(room_centers[:, 0], room_centers[:, 1],
               c=colors[:, :3], s=100, edgecolors='black',
               linewidths=1.5, zorder=5, label='Room centers')

    # Voronoi 图需要至少 3 个点
    if len(room_centers) >= 3:
        vor = Voronoi(room_centers)
        voronoi_plot_2d(vor, ax, show_vertices=False, line_colors='gray',
                        line_width=1, line_alpha=0.5, point_size=0)
    else:
        ax.set_title(f'Room segmentation ({len(room_centers)} room, Voronoi skipped)', fontsize=9)

    # 房间边界框
    for i, (center, bbox) in enumerate(zip(room_centers, room_bboxes)):
        # 从房间点云计算实际边界
        if 'points' in bbox and len(bbox['points']) > 0:
            pts = np.array(bbox['points'])[:, horizontal_axes]
            rect = plt.Rectangle(
                pts.min(axis=0),
                *(pts.max(axis=0) - pts.min(axis=0)),
                fill=True, alpha=0.3, color=colors[i, :3],
                linewidth=2, edgecolor='black'
            )
            ax.add_patch(rect)

        ax.annotate(f'R{i}', center, fontsize=9, ha='center', va='center',
                   fontweight='bold', color='white',
                   bbox=dict(boxstyle='round', facecolor='black',
                            alpha=0.7, pad=0.3))

    ax.set_xlim(x_min, x_max)
    ax.set_ylim(z_min, z_max)  # Z 轴正方向朝上（与俯视图 origin='lower' 一致）
    ax.set_aspect('equal')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Z (m)')
    ax.set_title('Voronoi Diagram + Room Boundaries')
    ax.grid(True, alpha=0.3)

    return ax


def plot_segmentation_overlay(ax, points, room_labels, room_centers, bounds,
                               alpha=0.6):
    """俯视图叠加房间分割结果"""
    x_min, x_max, z_min, z_max = bounds

    n_rooms = len(room_centers)
    cmap = plt.cm.tab10(np.linspace(0, 1, n_rooms))

    scatter = ax.scatter(points[:, 0], points[:, 1],
                         c=room_labels, cmap='tab10',
                         s=1, alpha=alpha, edgecolors='none')

    ax.scatter(room_centers[:, 0], room_centers[:, 1],
               c='red', s=150, marker='x',
               linewidths=3, zorder=10, label='Room centers')

    ax.set_xlim(x_min, x_max)
    ax.set_ylim(z_min, z_max)  # Z 轴正方向朝上（与俯视图 origin='lower' 一致）
    ax.set_aspect('equal')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Z (m)')
    ax.set_title('Room Segmentation Overlay')
    ax.grid(True, alpha=0.3)
    ax.legend()

    return ax


def assign_points_to_rooms(points, room_centers, horizontal_axes=None):
    """将点分配到最近的房间中心"""
    if horizontal_axes is None:
        horizontal_axes = [0, 2]
    points_2d = points[:, horizontal_axes]
    # room_centers 已经是 2D 的水平投影
    centers_2d = room_centers

    # 房间分割为空（所有候选房间被占据率过滤丢弃）时，全部点归为 -1，避免广播失败
    if centers_2d is None or len(centers_2d) == 0:
        print("    警告：未检测到房间，所有点标记为未分配（label=-1）")
        return np.full(len(points_2d), -1, dtype=np.int64)

    # 计算每个点到所有房间中心的距离
    dists = np.linalg.norm(points_2d[:, np.newaxis] - centers_2d, axis=2)
    labels = np.argmin(dists, axis=1)

    return labels


def generate_top_view_visualization(points, colors, rooms, output_dir, resolution=1000,
                                    floor_zero_level=None, vertical_axis=1, horizontal_axes=None):
    """
    俯视图可视化

    参数:
        points: 点云坐标 (N, 3)
        colors: 点云颜色 (N, 3)，范围 0-1 或 0-255
        rooms: 房间列表，每个房间包含 center, bbox, area 等信息
        output_dir: 输出目录路径
        resolution: 图像分辨率（像素数量）
        floor_zero_level: 地板零平面高度（用于正确的高度过滤）
        vertical_axis: 垂直轴索引 (默认 1=Y)
        horizontal_axes: 水平轴列表 (默认 [0,2]=XZ)

    返回:
        生成的文件路径列表
    """
    if horizontal_axes is None:
        horizontal_axes = [i for i in range(3) if i != vertical_axis]

    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True, parents=True)

    # 自动检测颜色范围并归一化到 0-1
    colors = np.asarray(colors, dtype=np.float32)
    if colors.max() > 1.0:
        colors = colors / 255.0
        print(f"    检测到颜色范围 0-255，已归一化到 0-1")

    print("=" * 60)
    print("生成俯视图可视化")
    print("=" * 60)

    # 提取房间中心和边界
    # rooms 为空时构造 (0,2) 空数组，保证下游 room_centers[:,0] 等索引合法（返回空数组而非报错）
    if len(rooms) == 0:
        print("  警告：房间分割未检出任何房间，俯视图将不包含房间信息")
        room_centers = np.zeros((0, 2), dtype=np.float64)
    else:
        room_centers = np.array([[r['center'][horizontal_axes[0]], r['center'][horizontal_axes[1]]] for r in rooms])
    room_bboxes = []
    for r in rooms:
        if 'bbox' in r:
            bbox_min = np.array(r['bbox']['min'])
            bbox_max = np.array(r['bbox']['max'])
            room_bboxes.append({'points': np.array([bbox_min, bbox_max])})
        else:
            room_bboxes.append({})
    
    # 创建俯视图
    print("\n[1] 创建俯视图...")
    density_img, bounds = create_top_view(points, colors, resolution=resolution,
                                          floor_zero_level=floor_zero_level,
                                          vertical_axis=vertical_axis,
                                          horizontal_axes=horizontal_axes)
    x_min, x_max, z_min, z_max = bounds
    print(f"    范围：[{x_min:.2f}, {z_min:.2f}] ~ [{x_max:.2f}, {z_max:.2f}]")

    # 将点分配到房间
    print("\n[2] 分配点到房间...")
    room_labels = assign_points_to_rooms(points, room_centers, horizontal_axes=horizontal_axes)
    
    # 创建可视化
    print("\n[3] 生成可视化...")
    
    fig = plt.figure(figsize=(20, 5))
    
    ax1 = fig.add_subplot(141)
    ax1.imshow(density_img, origin='lower',
               extent=[x_min, x_max, z_min, z_max])
    ax1.set_xlabel('X (m)')
    ax1.set_ylabel('Z (m)')
    ax1.set_title('Top View (XZ Projection)')
    ax1.set_aspect('equal')
    ax1.grid(True, alpha=0.3)
    
    # Voronoi 图 + 房间边界
    ax2 = fig.add_subplot(142)
    plot_voronoi_with_rooms(ax2, room_centers, room_bboxes, bounds,
                            horizontal_axes=horizontal_axes)

    # 分割叠加图
    ax3 = fig.add_subplot(143)
    v_base = floor_zero_level if floor_zero_level is not None else points[:, vertical_axis].min()
    height_mask = (points[:, vertical_axis] >= v_base - 0.5) & (points[:, vertical_axis] <= v_base + 4.0)
    plot_segmentation_overlay(ax3, points[height_mask][:, horizontal_axes],
                              room_labels[height_mask], room_centers, bounds)
    
    # 房间面积统计
    ax4 = fig.add_subplot(144)
    areas = [r['area'] for r in rooms]
    room_ids = range(len(rooms))
    bars = ax4.bar(room_ids, areas, color=plt.cm.tab10(np.linspace(0, 1, len(rooms))))
    ax4.set_xlabel('Room ID')
    ax4.set_ylabel('Area (m²)')
    ax4.set_title('Room Areas')
    ax4.set_xticks(room_ids)
    ax4.grid(True, alpha=0.3, axis='y')
    
    for bar, area in zip(bars, areas):
        ax4.annotate(f'{area:.1f}',
                     xy=(bar.get_x() + bar.get_width() / 2, bar.get_height()),
                     xytext=(0, 3), textcoords="offset points",
                     ha='center', va='bottom', fontsize=9)
    
    plt.tight_layout()
    combined_file = output_dir / "top_view_combined.png"
    plt.savefig(combined_file, dpi=150, bbox_inches='tight')
    print(f"    组合图：{combined_file}")
    plt.close(fig)
    
    fig_top = plt.figure(figsize=(12, 10))
    ax_top = fig_top.add_subplot(111)
    ax_top.imshow(density_img, origin='lower',
                  extent=[x_min, x_max, z_min, z_max])
    ax_top.set_xlabel('X (m)', fontsize=14)
    ax_top.set_ylabel('Z (m)', fontsize=14)
    ax_top.set_title('Top View (XZ Projection)', fontsize=16)
    ax_top.set_aspect('equal')
    ax_top.grid(True, alpha=0.3)
    plt.tight_layout()
    
    topview_file = output_dir / "top_view.png"
    plt.savefig(topview_file, dpi=300, bbox_inches='tight')
    print(f"    俯视图：{topview_file}")
    plt.close(fig_top)
    
    fig2, ax = plt.subplots(figsize=(12, 10))
    plot_voronoi_with_rooms(ax, room_centers, room_bboxes, bounds,
                            horizontal_axes=horizontal_axes)
    plt.tight_layout()

    voronoi_file = output_dir / "top_view_voronoi.png"
    plt.savefig(voronoi_file, dpi=150, bbox_inches='tight')
    print(f"    Voronoi 图：{voronoi_file}")
    plt.close(fig2)

    fig3, ax = plt.subplots(figsize=(12, 10))
    v_min = points[:, vertical_axis].min()
    v_max = points[:, vertical_axis].max()
    height_mask = (points[:, vertical_axis] >= v_min) & (points[:, vertical_axis] <= v_max)
    plot_segmentation_overlay(ax, points[height_mask][:, horizontal_axes],
                              room_labels[height_mask], room_centers, bounds)
    plt.tight_layout()
    
    overlay_file = output_dir / "top_view_segmentation_overlay.png"
    plt.savefig(overlay_file, dpi=150, bbox_inches='tight')
    print(f"    分割叠加图：{overlay_file}")
    plt.close(fig3)
    
    print("\n" + "=" * 60)
    print("完成！")
    print("=" * 60)
    
    return [combined_file, topview_file, voronoi_file, overlay_file]


def main():
    parser = argparse.ArgumentParser(description='可视化房间分割')
    parser.add_argument('--pcd', type=str, 
                        default='unified_output/global/global_pointcloud.ply',
                        help='全局点云文件')
    parser.add_argument('--scene-graph', type=str,
                        default='unified_output/scene_graph.json',
                        help='场景图 JSON 文件')
    parser.add_argument('--output-dir', type=str,
                        default=str(DEFAULT_OUTPUT_DIR),
                        help='输出目录路径')
    parser.add_argument('--resolution', type=int, default=1000,
                        help='俯视图分辨率（像素数量）')
    args = parser.parse_args()
    
    print(f"\n[加载点云] {args.pcd}")
    points, colors = load_point_cloud(args.pcd)
    print(f"    {len(points):,} 点")
    
    print(f"\n[加载场景图] {args.scene_graph}")
    with open(args.scene_graph, 'r') as f:
        scene_graph = json.load(f)
    
    rooms = scene_graph['rooms']
    print(f"    {len(rooms)} 个房间")
    
    generate_top_view_visualization(points, colors, rooms, args.output_dir, args.resolution)


if __name__ == '__main__':
    main()
