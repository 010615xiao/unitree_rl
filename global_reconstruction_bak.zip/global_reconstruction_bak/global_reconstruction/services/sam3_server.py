#!/usr/bin/env python3
"""
SAM 3.1 分割服务器
支持文本提示和几何提示（box/point）

使用示例:
    python -m global_reconstruction.services.sam3_server --checkpoint_path /path/to/sam3.1_multiplex.pt --port 20023
"""

import base64
import cv2
import io
import logging
import numpy as np
import os
import sys
import torch
import argparse
import traceback
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
from global_reconstruction.core.config_loader import project_root

# 添加 sam3 到路径
SAM3_DIR = str(project_root() / "external" / "sam3-main")
if SAM3_DIR not in sys.path:
    sys.path.insert(0, SAM3_DIR)

from sam3.model_builder import build_sam3_image_model
from sam3.model.sam3_image_processor import Sam3Processor
from sam3.model.data_misc import FindStage, interpolate
from sam3.model import box_ops

# 配置日志格式
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)

app = Flask(__name__)
CORS(app)

# 全局变量
model = None
processor = None
device = "cuda" if torch.cuda.is_available() else "cpu"
DEFAULT_CONFIDENCE_THRESHOLD = 0.5

# fp16 混合精度开关（--fp16 启动时打开）。打开后推理用 fp16，实测 image_encoder
# 1.7x、全流程 ~1.5x 提速，精度几乎无损（mask IoU 0.9995）。关闭时行为与原实现完全一致。
USE_AMP = False
AMP_DTYPE = torch.float16


def _amp_ctx():
    """推理用的 autocast 上下文；USE_AMP=False 时为空操作（保持 fp32）。"""
    return torch.autocast(device_type="cuda", dtype=AMP_DTYPE, enabled=USE_AMP)


def _encode_mask_b64(mask_uint8: np.ndarray) -> str:
    """Encode a binary mask (0/255 uint8 H×W) as base64 PNG."""
    _, buf = cv2.imencode('.png', mask_uint8)
    return base64.b64encode(buf.tobytes()).decode('utf-8')


@torch.inference_mode()
def _batched_text_inference(texts: list, state: dict, conf_threshold: float):
    """Run grounding for N text prompts in a single GPU call.

    Returns: {text: {"masks": np.ndarray list, "scores": list, "boxes": list}, ...}
    """
    N = len(texts)
    if N == 0:
        return {}

    # 1. Encode all texts at once
    text_outputs = model.backbone.forward_text(texts, device=device)
    state["backbone_out"].update(text_outputs)
    if "geometric_prompt" not in state:
        state["geometric_prompt"] = model._get_dummy_prompt(num_prompts=N)

    # 2. Build batched FindStage: same image, different text per batch element
    find_input = FindStage(
        img_ids=torch.zeros(N, device=device, dtype=torch.long),
        text_ids=torch.arange(N, device=device, dtype=torch.long),
        input_boxes=None,
        input_boxes_mask=None,
        input_boxes_label=None,
        input_points=None,
        input_points_mask=None,
    )

    # 3. Single forward_grounding call
    outputs = model.forward_grounding(
        backbone_out=state["backbone_out"],
        find_input=find_input,
        geometric_prompt=state["geometric_prompt"],
        find_target=None,
    )

    # 4. Post-process: split results by prompt index
    out_bbox = outputs["pred_boxes"]       # [N, Q, 4]
    out_logits = outputs["pred_logits"]     # [N, Q]
    out_masks = outputs["pred_masks"]       # [N, Q, H, W]
    out_probs = out_logits.sigmoid()
    presence_score = outputs["presence_logit_dec"].sigmoid().unsqueeze(1)  # [N, 1]
    out_probs = (out_probs * presence_score).squeeze(-1)  # [N, Q]

    img_h = state["original_height"]
    img_w = state["original_width"]
    scale_fct = torch.tensor([img_w, img_h, img_w, img_h], device=device)

    results = {}
    for idx in range(N):
        probs_i = out_probs[idx]           # [Q]
        masks_i = out_masks[idx]           # [Q, H, W]
        bbox_i = out_bbox[idx]             # [Q, 4]

        keep = probs_i > conf_threshold
        probs_i = probs_i[keep]
        masks_i = masks_i[keep]
        bbox_i = bbox_i[keep]

        if masks_i.numel() == 0:
            results[texts[idx]] = {"masks": [], "scores": [], "boxes": []}
            continue

        # Convert boxes to xyxy pixel coords
        boxes_xyxy = box_ops.box_cxcywh_to_xyxy(bbox_i) * scale_fct[None, :]

        # Upsample masks to original image size
        masks_up = interpolate(
            masks_i.unsqueeze(1), (img_h, img_w),
            mode="bilinear", align_corners=False,
        ).sigmoid()

        masks_np = [(m.squeeze().cpu().numpy() > 0.5).astype(np.uint8) * 255 for m in masks_up]
        scores_list = [float(s.item()) for s in probs_i]
        boxes_list = [[float(x.item()) for x in b] for b in boxes_xyxy]

        results[texts[idx]] = {
            "masks": masks_np,
            "scores": scores_list,
            "boxes": boxes_list,
        }

    return results


def load_model(model_path: str):
    """加载 SAM 3.1 模型"""
    global model, processor

    try:
        logging.info(f"正在加载 SAM 3.1 模型：{model_path}")

        # BPE tokenizer 路径
        bpe_path = os.path.join(SAM3_DIR, "sam3", "assets", "bpe_simple_vocab_16e6.txt.gz")
        if not os.path.exists(bpe_path):
            alt_paths = [
                os.path.join(SAM3_DIR, "assets", "bpe_simple_vocab_16e6.txt.gz"),
                str(project_root() / "external" / "sam3-main" / "sam3" / "assets" / "bpe_simple_vocab_16e6.txt.gz"),
            ]
            for p in alt_paths:
                if os.path.exists(p):
                    bpe_path = p
                    break
            else:
                raise FileNotFoundError(f"找不到 BPE tokenizer 文件: {bpe_path}")

        logging.info(f"使用 BPE 路径：{bpe_path}")

        model = build_sam3_image_model(
            bpe_path=bpe_path,
            checkpoint_path=model_path,
            device=device,
            eval_mode=True,
            load_from_HF=False,
        )
        processor = Sam3Processor(model, device=device, confidence_threshold=DEFAULT_CONFIDENCE_THRESHOLD)

        logging.info("SAM 3.1 模型加载完成！")
        return True
    except Exception as e:
        logging.error(f"模型加载失败：{e}")
        logging.error(traceback.format_exc())
        return False


def load_image_from_data(data: dict):
    """从请求数据加载图像"""
    if "image_path" in data:
        image_path = data["image_path"]
        if not os.path.exists(image_path):
            return None, f"图像文件不存在：{image_path}"
        image = Image.open(image_path).convert("RGB")
        return image, None
    elif "image" in data:
        image_bytes = base64.b64decode(data['image'])
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        return image, None
    else:
        return None, "需要提供 image 或 image_path"


@app.route('/health', methods=['GET'])
def health_check():
    """健康检查接口"""
    try:
        return jsonify({
            "status": "ok",
            "model": "SAM3.1",
            "device": device,
        })
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500


@app.route('/predict', methods=['POST'])
def predict():
    """
    SAM 3 分割预测 - 支持文本提示和几何提示

    输入:
        - image: base64 编码的图像 或 image_path: 图像路径
        - text: 文本提示 (例如 "a red car")
        - boxes: [N, 4] 边界框数组 [x1, y1, x2, y2] (可选)
        - confidence_threshold: 置信度阈值 (默认 0.35)
    输出:
        - masks: [N, H, W] 掩码数组（列表形式）
        - scores: [N] 置信度分数
        - boxes: [N, 4] 边界框 [x0, y0, x1, y1]
    """
    global model, processor

    if model is None:
        return jsonify({"error": "模型未加载"}), 500

    try:
        data = request.get_json()
        mask_format = data.get("mask_format", "json")  # "json" | "base64_png"

        # 加载图像
        image, error = load_image_from_data(data)
        if error:
            return jsonify({"error": error}), 400

        # 文本提示
        text_prompt = data.get("text", None)
        if not text_prompt:
            return jsonify({"error": "需要提供 text 文本提示"}), 400

        # GPU 推理（fp16 时走 autocast）
        with _amp_ctx():
            # 设置图像
            inference_state = processor.set_image(image)
            output = processor.set_text_prompt(state=inference_state, prompt=text_prompt)

            # 可选：添加几何提示（box）
            if "boxes" in data and len(data["boxes"]) > 0:
                for box in data["boxes"]:
                    x1, y1, x2, y2 = box
                    w, h = image.size
                    cx, cy = (x1 + x2) / (2 * w), (y1 + y2) / (2 * h)
                    bw, bh = (x2 - x1) / w, (y2 - y1) / h
                    processor.add_geometric_prompt(
                        box=[cx, cy, bw, bh],
                        label=True,
                        state=inference_state,
                    )
                output = inference_state

        # 获取结果
        masks = output.get("masks", None)
        boxes = output.get("boxes", None)
        scores = output.get("scores", None)

        if masks is None or masks.numel() == 0:
            resp = {"success": True, "scores": [], "boxes": [],
                    "image_shape": [image.size[1], image.size[0]],
                    "num_detections": 0, "mask_format": mask_format}
            resp["masks_b64" if mask_format == "base64_png" else "masks"] = []
            return jsonify(resp)

        # 处理结果
        scores_list = []
        boxes_list = []
        for i in range(masks.shape[0]):
            scores_list.append(float(scores[i].item()) if scores is not None else 1.0)
            if boxes is not None:
                boxes_list.append([float(x.item()) for x in boxes[i]])

        resp = {
            "success": True,
            "scores": scores_list,
            "boxes": boxes_list,
            "image_shape": [image.size[1], image.size[0]],
            "num_detections": masks.shape[0],
            "mask_format": mask_format,
        }

        if mask_format == "base64_png":
            resp["masks_b64"] = [
                _encode_mask_b64((masks[i].squeeze().cpu().numpy() > 0.5).astype(np.uint8) * 255)
                for i in range(masks.shape[0])
            ]
        else:
            resp["masks"] = [masks[i].squeeze().cpu().numpy().tolist() for i in range(masks.shape[0])]

        logging.info(f"分割完成，检测到 {masks.shape[0]} 个对象 (format={mask_format})")
        return jsonify(resp)

    except Exception as e:
        logging.error(f"推理失败：{e}")
        logging.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route('/predict_batch', methods=['POST'])
def predict_batch():
    """
    批量文本提示分割 — 图像编码只执行一次，多个文本提示复用。

    输入:
        - image_path 或 image: 图像
        - texts: [str, ...] 多个文本提示
        - confidence_threshold: 置信度阈值 (默认 0.35)
    输出:
        - results: {text: {masks, scores, boxes}, ...}
    """
    global model, processor

    if model is None:
        return jsonify({"error": "模型未加载"}), 500

    try:
        data = request.get_json()
        texts = data.get("texts", [])
        if not texts:
            return jsonify({"error": "需要提供 texts 列表"}), 400

        image, error = load_image_from_data(data)
        if error:
            return jsonify({"error": error}), 400

        conf_threshold = data.get("confidence_threshold", 0.35)
        mask_format = data.get("mask_format", "json")  # "json" | "base64_png"

        # 图像编码 + 批量推理（fp16 时走 autocast）
        BATCH_CHUNK = 32
        results = {}
        with _amp_ctx():
            inference_state = processor.set_image(image)
            # 分块批量推理: 每块最多 BATCH_CHUNK 个 prompt，避免 OOM
            for chunk_start in range(0, len(texts), BATCH_CHUNK):
                chunk = texts[chunk_start:chunk_start + BATCH_CHUNK]
                # 每块需要重新 set_image（state 会被 forward_text 修改）
                if chunk_start > 0:
                    inference_state = processor.set_image(image)
                chunk_results = _batched_text_inference(chunk, inference_state, conf_threshold)

                for text_prompt in chunk:
                    entry_raw = chunk_results.get(text_prompt, {"masks": [], "scores": [], "boxes": []})
                    masks_np = entry_raw["masks"]
                    entry = {"scores": entry_raw["scores"], "boxes": entry_raw["boxes"]}
                    if mask_format == "base64_png":
                        entry["masks_b64"] = [_encode_mask_b64(m) for m in masks_np]
                    else:
                        entry["masks"] = [m.tolist() for m in masks_np]
                    results[text_prompt] = entry

        n_det = sum(len(v.get("masks_b64", v.get("masks", []))) for v in results.values())
        logging.info(f"批量分割完成，{len(texts)} 个提示 → {n_det} detections (format={mask_format}, batched)")
        return jsonify({"success": True, "mask_format": mask_format, "results": results})

    except Exception as e:
        logging.error(f"批量推理失败：{e}")
        logging.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route('/segment', methods=['POST'])
def segment():
    """
    分割接口，使用文本提示 + 可选 box

    输入:
        - image: base64 编码的图像 或 image_path: 图像路径
        - text: 文本提示
        - box: [x1, y1, x2, y2] 单个边界框 (可选)
    输出:
        - mask: [H, W] 掩码（base64 编码）
        - score: 置信度分数
    """
    global model, processor

    if model is None:
        return jsonify({"error": "模型未加载"}), 500

    try:
        data = request.get_json()

        text_prompt = data.get("text", None)
        if not text_prompt:
            return jsonify({"error": "需要提供 text 文本提示"}), 400

        # 加载图像
        image, error = load_image_from_data(data)
        if error:
            return jsonify({"error": error}), 400

        # 设置图像并运行文本提示（fp16 时走 autocast）
        with _amp_ctx():
            inference_state = processor.set_image(image)
            output = processor.set_text_prompt(state=inference_state, prompt=text_prompt)

            # 可选：添加 box 提示
            box = data.get("box", None)
            if box:
                w, h = image.size
                x1, y1, x2, y2 = box
                cx, cy = (x1 + x2) / (2 * w), (y1 + y2) / (2 * h)
                bw, bh = (x2 - x1) / w, (y2 - y1) / h
                processor.add_geometric_prompt(
                    box=[cx, cy, bw, bh],
                    label=True,
                    state=inference_state,
                )
                output = inference_state

        # 获取结果
        masks = output.get("masks", None)
        scores = output.get("scores", None)

        if masks is None or masks.numel() == 0:
            return jsonify({
                "success": False,
                "message": "未检测到目标"
            })

        # 获取最高分的掩码
        best_idx = scores.argmax().item()
        mask = masks[best_idx].squeeze().cpu().numpy()
        score = float(scores[best_idx].item())

        mask_uint8 = (mask * 255).astype(np.uint8)

        # 编码掩码为 base64
        _, buffer = cv2.imencode('.png', mask_uint8)
        mask_base64 = base64.b64encode(buffer.tobytes()).decode('utf-8')

        logging.info(f"分割完成，最高分: {score:.3f}")
        return jsonify({
            "success": True,
            "mask": mask_base64,
            "score": score,
            "image_shape": [image.size[1], image.size[0]]
        })

    except Exception as e:
        logging.error(f"推理失败：{e}")
        logging.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route('/infer', methods=['POST'])
def infer():
    """图像分割推理接口（/segment 的别名）"""
    return segment()


def warmup(warmup_image: str = None):
    """预热 GPU：跑几轮推理让 CUDA kernel / 显存分配稳定下来。"""
    if model is None:
        return
    import time
    from PIL import Image as PILImage

    # 用一张真实图片或合成_dummy 图片
    if warmup_image and os.path.exists(warmup_image):
        img = PILImage.open(warmup_image).convert("RGB")
    else:
        img = PILImage.new("RGB", (640, 480), color=(128, 128, 128))

    prompts = ["object", "floor", "wall", "chair", "table", "door", "window", "person"]
    logging.info(f"预热中 (image={img.size}, prompts={len(prompts)})...")

    # 跑 3 轮（fp16 时走 autocast，让对应 kernel 预热）
    for i in range(3):
        t0 = time.perf_counter()
        with _amp_ctx():
            state = processor.set_image(img)
            _batched_text_inference(prompts, state, conf_threshold=0.35)
        elapsed = time.perf_counter() - t0
        logging.info(f"  预热 round {i+1}: {elapsed*1000:.0f}ms")

    logging.info("预热完成")


def main():
    parser = argparse.ArgumentParser(description='SAM 3.1 Server')
    parser.add_argument('--checkpoint_path', type=str, required=True,
                        help='Path to SAM 3.1 model checkpoint')
    parser.add_argument('--port', type=int, default=20023,
                        help='Port to run the server on (default: 20023)')
    parser.add_argument('--host', type=str, default='0.0.0.0',
                        help='Host to run the server on (default: 0.0.0.0)')
    parser.add_argument('--warmup_image', type=str, default=None,
                        help='Path to an image for warmup (optional)')
    parser.add_argument('--fp16', action='store_true',
                        help='Enable fp16 mixed-precision inference (~1.5x faster, negligible accuracy loss)')

    args = parser.parse_args()

    # 设置 fp16 开关
    global USE_AMP
    USE_AMP = args.fp16 and device == "cuda"
    if args.fp16 and device != "cuda":
        logging.warning("--fp16 需要 CUDA，当前设备非 cuda，已忽略")

    logging.info("正在启动 SAM 3.1 服务器...")
    logging.info(f"fp16 混合精度：{'开启' if USE_AMP else '关闭 (fp32)'}")
    logging.info(f"模型路径：{args.checkpoint_path}")
    logging.info(f"服务端口：{args.port}")

    # 加载指定模型
    if not load_model(args.checkpoint_path):
        logging.error("无法启动服务器：模型加载失败")
        exit(1)

    warmup(args.warmup_image)

    logging.info("模型加载成功，正在启动服务器...")
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == '__main__':
    main()
