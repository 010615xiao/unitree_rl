# 计划：物体 = 稳定体素（track-by-detection 状态机）

## 目标

物体不再存原始点云，而是**每个物体维护自身的稳定体素图**。bbox、合并、重投影、导出全部从稳定体素派生。通过逐帧 track-by-detection 状态机（新检测 -> 候选 -> 稳定），让物体的体素随多帧观测概率收敛，噪声/溢出/瞬态体素自然衰减，bbox 收敛到紧致稳定状态。

**全局 `SparseVoxelFusion` 保留**，继续负责场景点云 / 房间分割 / floor 检测，不退役。per-object 体素图只吃 SAM3 mask 内像素，与全局图几乎不重叠。

## 核心设计

### 体素归属：共享 ownership map（一体素一主）

每个物体不再有独立 `voxel_map`，而是共享一个 `voxel_owner: dict[key -> Ownership(owner_id, last_claim, prob)]`。每个体素只有一个 owner，从根上消除"同位置两个物体"的重复归属，并把"替换"变成 ownership 转移。

**claim 规则**（每帧对每个检测的体素）：
- 无主 -> 归本物体，prob=init
- 主==本物体 -> 确认 hit，prob+=（cap）
- 主==别的物体 -> 仅当 `tick - other.last_claim >= claim_grace(2)`（other 久不 claim = 已离开/被换）才**转移**给本物体（prob 重置 init，新主需重新确认）；否则保持现主（冲突/other 仍活跃）

**carve（自由空间）**：在视野内、本帧未 claim 的 owned 体素，深度显示自由空间（`d_X < d_obs - margin`）-> prob-= ；<=0 则释放（无主）。被遮挡/无效深度不动。

**死亡**：owned 体素全空（被 carve 或转移光）连续 `death_threshold` 帧 -> DEAD，释放残留体素。

**替换如何被检测**：box 被换 -> 不再 claim 其体素 -> `last_claim` 老化 -> 超 grace 后 chair claim 这些体素 -> 归属从 box 转 chair -> box owned 归零 -> DEAD。不会存两个物体。SAM3 漏检（depth 匹配、无人 claim）-> 不 carve 不转移 -> 保留。同类替换（chair 换 chair）SAM3 仍检出 chair -> 旧实例仍 matched -> 不转移（不可区分，视为同一物体）。

**消失分类（per-voxel）**：存活(O claim+深度匹配) / 遮挡(深度在前) / unknown(深度无效) / miss(自由空间 carve) / 替换(深度匹配但别物 claim -> 转移)。



```
新检测(NEW) --第2次关联成功--> 候选(CANDIDATE) --连续N次关联成功--> 稳定(STABLE)
                                   \--miss超coast窗口--> 死亡(DEAD, 剔除)
```

- **NEW**：首次观测创建。体素图初始化（每个观测体素 P=init_prob）。
- **CANDIDATE**：累积观测中。bbox 由"有效体素(P>thr)"导出，但未晋升。
- **STABLE**：连续 N 次成功关联且体素数趋于稳定。bbox = 稳定体素 AABB，用于 scene graph 导出。
- **DEAD**：连续 miss 超 `death_threshold`，剔除。

### 体素概率模型（复用 SparseVoxelFusion 概念，轻量实现）

每个 ObjectInstance 维护 `voxel_map: dict[(x,y,z) -> float_prob]`（int32 键，里程计系）。**不用 SoA/Numba**（65536 cap × N 物体会爆内存），物体小，纯 Python dict 几百~几千键足够。

更新规则（每帧对匹配上的实例）：
- **命中（hit）**：当前帧 mask 内体素。map 中已有 -> `P += voxel_hit_prob`（cap 1.0）；新体素 -> `P = voxel_init_prob`（代表 1 次观测）。
- **未命中（miss，carving）**：对实例 map 中每个体素 X（距相机 d_X），投影到当前帧像素，采当前深度 d_obs：
  - `d_X < d_obs - margin` → 体素在观测表面**前方** = 自由空间 → `P -= voxel_miss_prob`（<=0 则删除）
  - `d_X ≈ d_obs (±margin)` → 命中，已在 hit 处理
  - `d_X > d_obs + margin` → 体素在表面**后方** = 被遮挡/未知 → **不动**（不 carve，避免误杀遮挡体素）
- **有效体素**：`P > voxel_valid_threshold`。bbox = 有效体素 AABB。

> ⚠️ 关键修正：carving 判据是"体素比观测表面更近（d_X < d_obs - margin）"，**不是**"射线到 aabb 边界"。后者会误删被遮挡的体素（人挡住椅子靠背时靠背会被错误 carve）。这与全局 `SparseVoxelFusion` free-space carving（只 carve `[相机, depth-margin]` 段）一致。"投影体素+采样深度"复用 `object_state_detector.project_and_sample`。

### 概率参数天然实现"首帧不稳定"

init_prob=0.5、valid_threshold=0.5(严格>)：单次观测的体素 P=0.5 不算有效 → bbox 为空；第 2 次命中 P=0.8 才进 bbox。这自动落实"首帧不判稳定、候选需多帧"。

## 新模块：`incremental/object_tracker.py`

### `class ObjectInstance`

```python
@dataclass
class ObjectInstance:
    obj_id: int
    category: str
    state: str            # 'NEW' | 'CANDIDATE' | 'STABLE' | 'DEAD'
    voxel_map: dict       # {(x,y,z): float prob}，里程计系
    centroid: np.ndarray  # 有效体素中心均值（动态）
    current_aabb: dict     # {'min':..., 'max':...} 有效体素 AABB
    birth_frame: str
    last_seen_frame: str
    hit_count: int        # 累计成功关联帧数
    miss_count: int       # 连续未关联帧数
    is_alive: bool
    source_views: list    # 累积的 grounded views
    observed_frames: list
    state_history: list

    def integrate_observation(self, points_3d, depth, K, T_c2w, confidence, frame_id):
        # 1) 当前帧体素 = floor(points_3d/vs)；hit: P+= 或 init
        # 2) decay_unobserved: 投影现有体素采 d_obs，d_X<d_obs-margin 的 P-= (删0)
        # 3) recompute_bbox(): 有效体素(P>thr) AABB + centroid
        # 4) hit_count++, miss_count=0, last_seen_frame=frame_id
        # 5) promote_if_ready()

    def decay_unobserved(self, depth, K, T_c2w, confidence):
        # 复用 project_and_sample 的投影逻辑，逐体素判 hit/miss/occluded

    def recompute_bbox(self): ...
    def promote_if_ready(self):
        # hit_count>=candidate_promote_hits 且 有效体素数近N帧稳定 -> STABLE
    def mark_miss(self, frame_id):
        # miss_count++；超 death_threshold -> DEAD
    def valid_voxel_centers(self) -> np.ndarray:
        # P>thr 的体素中心（里程计），供重投影/导出
    def to_record(self, R_align=None) -> dict:
        # 导出 scene_graph 兼容记录（bbox/center/points=有效体素中心）
```

### `class ObjectTracker`

```python
class ObjectTracker:
    def __init__(self, config): self.instances=[]
    def update_frame(self, detections, depth, color, K, T_c2w, confidence, frame_id, color_file):
        # detections: [{'mask','category','score'}, ...]
        # 1) 每个 detection: mask_to_3d_points -> 临时 points_3d; 算 centroid_t, aabb_t, voxel_keys
        # 2) associate: 同类 alive 实例，3D IoU(aabb_t vs instance.current_aabb/stable_bbox)
        #    + 质心距离；按得分降序贪心分配 + 已占用标记
        # 3) matched: instance.integrate_observation(...)
        # 4) unmatched: 新建 ObjectInstance(NEW)，init voxel_map
        # 5) 未匹配上的 alive 实例: mark_miss (coast 窗口内不删，超 death_threshold 才 DEAD)
        # 6) promote 检查
    def alive_instances(self): [i for i in instances if i.is_alive]
    def stable_instances(self): [i for i in instances if i.state=='STABLE']
    def to_records(self, R_align): [i.to_record(R_align) for i in alive+stable]
    def save(self, dir): # 兼容 object_instances.json 格式
```

### 关联算法（`associate`）

- 只与**同类** alive 实例匹配。
- 得分 = w1·3D_IoU(aabb_t, instance_aabb) - w2·dist(centroid_t, instance_center)。阈值：`IoU > iou_thr(0.1) AND dist < dist_thr(1.0m)`。
- 按 (IoU 降序, 距离升序) 贪心，已占用实例/检测跳过（避免多对一冲突；同类多实例紧挨时比"最高分赢"更稳）。
- **Coasting**：关联失败的 alive 实例不立即删，`miss_count++`，仅做轻 decay；超 `death_threshold` 才 DEAD。短暂遮挡不拆 track。

## 主循环集成（替换 `reconstruct_and_segment.py:3134-3521` detect 分支）

```
tracker = ObjectTracker(cfg)              # 循环前
for frame:
    ... SAM3 batch -> detections ...      # 不变
    tracker.update_frame(detections, depth, color, K_frame, T_c2w, confidence, timestamp_str, color_file)
    # 可见性可视化：用 tracker.alive_instances() 的有效体素中心做重投影
    #   （左侧=实例稳定体素重投影，右侧=当前 mask；语义同原 visualize_visibility）
```

- `all_objects` 平铺 D 实例 + `IncrementalMergeTracker` + 循环内 `lifecycle_tracker.register/update` 全部由 `tracker.update_frame` 取代。
- 可见性/状态：`detect_object_states` 的判定被概率体素图吸收（实例 state + 有效体素数即隐含 persisting/occluded/disappeared）。`project_and_sample` 被复用到 `decay_unobserved`。`visualize_visibility` 输入改为 `tracker.to_records()`，底部状态栏改用实例 `state` 统计。

## 循环后处理

- **轨迹对齐**（不变）：R_align 旋转 poses/全局点云/wall/floor 物体。`tracker` 实例的 `voxel_map` 键保持里程计系（与全局图一致），导出时 `to_record(R_align)` 物化有效体素中心 -> R_align 旋转 -> AABB（对齐系）。
- **跨帧合并（收缩）**：`iterative_merge_objects` 仍跑，但只在 `tracker.stable_instances()` + 残留 candidate 上做 split-track 修复合并（同一物体 track 断裂重连成两条）。合并对象用实例的有效体素键集合直接算 IoU/containment（`precompute_voxel_data` 改读实例体素键，不再 floor 原始点）。
- **wall/floor 背景**：不进 tracker，仍走全局图 + 强制单实例（不变）。
- **floor 以下过滤 / 体素稳定性过滤**：保留。`filter_objects_by_voxel_stability` 变成对实例有效体素的二次校验（与全局 stable 体素比对），可保留也可后续移除。
- **scene graph / 导出**：`build_scene_graph` 的 bbox/center/num_points 改读实例 `to_record(R_align)` 的稳定体素 bbox；`.ply` 导出用有效体素中心；`export_hierarchical_graph` 同理。

## 配置（`config.yaml` 新增 `object_tracking` 节）

```yaml
object_tracking:
  candidate_promote_hits: 3       # 候选->稳定 需累计成功关联帧数
  miss_coast_frames: 3             # 关联失败容忍窗口（coasting，不立刻删）
  death_threshold: 5               # miss 超此值判 DEAD
  voxel_init_prob: 0.5             # 新观测体素初始概率（单次<阈值，天然不稳定）
  voxel_hit_prob: 0.3              # 命中增量（cap 1.0）
  voxel_miss_prob: 0.1             # 自由空间未命中衰减
  voxel_valid_threshold: 0.5       # P>此值算有效体素（严格大于）
  voxel_free_margin: 0.08          # d_X < d_obs - margin 才 carve
  association_iou_threshold: 0.1
  association_distance: 1.0
  max_voxels_per_instance: 20000   # 实例体素数上限（防异常膨胀，超出按距离裁剪）
```

`object_segmentation.visibility_viz.*` 等已有配置继续生效。

## 分阶段实施

### B-1 核心（本次主体）

1. 新建 `incremental/object_tracker.py`：`ObjectInstance`（状态机 + 轻量 voxel_map + integrate/decay/promote）+ `ObjectTracker`（associate + update_frame + coasting）。
2. `decay_unobserved` 复用 `object_state_detector.project_and_sample` 的投影采样。
3. 主循环 detect 分支改调 `tracker.update_frame`；移除 `IncrementalMergeTracker`、循环内 `LifecycleTracker.register/update`、平铺 `all_objects.append`。
4. `visualize_visibility` / `filter_visible_objects` 输入改 `tracker.to_records()`（循环内快照，先快照再 update 以保留"历史 vs 当前"对比语义）。
5. `iterative_merge_objects` / `precompute_voxel_data` / `merge_cluster` 改用实例体素键集合；`build_scene_graph` bbox/center 改读 `to_record(R_align)`；`.ply` 导出用有效体素中心。
6. `tracker.save` 产出兼容 `object_instances.json`（birth/observed/miss/alive/state_history 字段对齐，下游 final lifecycle 聚合无需改）。
7. 新增 `object_tracking` 配置节 + 主脚本常量。

### B-2 清理（后续，不在本次）

- `detect_object_states` / `classify_state_object_level` 移除或仅留 viz（已被概率体素图吸收）。
- `filter_objects_by_voxel_stability` 评估是否退役（实例已概率稳定）。
- `IncrementalMergeTracker` / 旧 `LifecycleTracker` 删除。
- `rebuild_final_object_grounded_views`（当前死代码）改用实例稳定体素重投影激活或删除。

## 涉及文件

| 文件 | 改动 |
|---|---|
| `incremental/object_tracker.py` | **新建**：ObjectInstance + ObjectTracker |
| `reconstruction/reconstruct_and_segment.py` | detect 分支改 `tracker.update_frame`；循环后合并/导出改读实例体素；配置常量 |
| `incremental/object_state_detector.py` | `project_and_sample` 被 ObjectInstance.decay 复用；`detect_object_states` 角色收缩（B-2 移除） |
| `incremental/visibility_visualizer.py` | `filter_visible_objects` / `visualize_visibility` 输入适配实例 records |
| `reconstruction/final_merger.py` | `precompute_voxel_data` / `can_merge_objects` / `merge_cluster` 改用体素键集合；`iterative_merge_objects` 角色收缩为 split-track 修复 |
| `incremental/lifecycle_tracker.py` | 被 ObjectInstance 取代（B-2 删除），B-1 期间保留 save 格式兼容 |
| `incremental/object_merger.py`（IncrementalMergeTracker） | 循环内不再用（B-2 删除） |
| `config.yaml` | 新增 `object_tracking` 节 |

## 风险与取舍

- **关联断裂**：快速移动/稀疏检测时 IoU 低，靠距离 + coasting 兜底；断裂产生 split track 由最终合并修复。可后续加重心速度预测增强。
- **carving 仍需 margin 调参**：`voxel_free_margin` 太小→噪声深度误 carve；太大→carve 不动。沿用全局图 0.08m。
- **遮挡 vs 消失**：概率衰减隐含多帧缓冲（P 从 1.0 衰到 0.5 需多帧），稳态体素抗短暂遮挡；但长期遮挡仍会被缓慢 carve。可接受（物体真长期不见本应衰减）。
- **一致溢出（SAM3 每帧溢到同表面）**：hit-count 也会累积，残留。可选后续：减去 floor/wall 物体体素。本次不做。
- **内存/性能**：实例数 × 体素数 dict；decay 每帧投影实例体素（cap `max_voxels_per_instance`）。检测帧每 2 帧一次，可接受。
- **可见性可视化语义**：循环内先快照实例再 update，保留"左侧历史重投影 vs 右侧当前 mask"对比。
- **不破坏全局管线**：全局 `SparseVoxelFusion` / 房间分割 / floor / gateway / scene graph 框架不动，只换物体表示与跟踪。

## 验证

1. 跑全流程，确认 `scene_graph.json` 物体 bbox 紧致、无异常长条；对比改前体积应显著缩小。
2. 抽查 `object_instances.json`：实例有 NEW/CANDIDATE/STABLE 状态流转、hit_count/miss_count 合理。
3. 可见性可视化：左侧实例稳定体素重投影与右侧当前 mask 吻合度提升。
4. 确认 wall/floor 背景类不受影响（走全局图）。
5. 确认 room_id 归属（依赖 center）未错乱。
6. 对比改前改后 `.ply` 物体点云：应更干净（有效体素中心，无飞点）。

## 不做的事

- 不退役/不改全局 `SparseVoxelFusion`（保留做场景/房间/floor）。
- 不改 SAM3/VLM 检测链路。
- 不做 per-object Numba 加速（纯 Python dict 足够，后续若性能不足再优化）。
- B-2 清理项本次不做。
- 不引入重心速度预测（关联增强留后续）。
