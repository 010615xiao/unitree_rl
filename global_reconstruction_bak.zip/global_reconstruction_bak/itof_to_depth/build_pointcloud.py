#!/usr/bin/env python3
"""从 depth_fused + RGB + 相机位姿 叠加重建带颜色的场景点云。

用法:
    python build_pointcloud.py                          # 默认参数
    python build_pointcloud.py --max_depth 3.0          # 限制最大深度
    python build_pointcloud.py --voxel_size 0.02        # 体素下采样
    python build_pointcloud.py --output result.ply      # 自定义输出
"""

import argparse
from pathlib import Path

import cv2
import numpy as np

# iTOF 相机内参 (640x352)
FX, FY = 267.730011, 267.730011
CX, CY = 315.010010, 214.380050
H, W = 352, 640


def _pose_lines(pose_file: Path) -> list[str]:
    """返回位姿文件的非注释非空行列表。"""
    lines = []
    with open(pose_file) as f:
        for line in f:
            s = line.strip()
            if s and not s.startswith("#"):
                lines.append(s)
    return lines


def load_poses(pose_file: Path) -> list[np.ndarray]:
    """从 rgb_camera_poses.txt 加载 T_world_camera 4x4 矩阵列表。"""
    poses = []
    for line in _pose_lines(pose_file):
        parts = line.split()
        if len(parts) < 17:
            continue
        vals = [float(x) for x in parts[-16:]]
        poses.append(np.array(vals).reshape(4, 4))
    return poses


def flatten_pose(T: np.ndarray) -> np.ndarray:
    """强制 roll=pitch=0，只保留 yaw 和 translation。"""
    yaw = np.arctan2(T[1, 0], T[0, 0])
    c, s = np.cos(yaw), np.sin(yaw)
    T_flat = np.eye(4)
    T_flat[0, 0] = c
    T_flat[0, 1] = -s
    T_flat[1, 0] = s
    T_flat[1, 1] = c
    T_flat[:3, 3] = T[:3, 3]
    return T_flat


# 相机光学帧 → 机器人本体帧的固定旋转 (与 odom_to_camera_pose.py 一致)
R_CAM2ROBOT = np.array([
    [0, 0, 1],
    [-1, 0, 0],
    [0, -1, 0],
], dtype=np.float64)


def load_odom_camera_poses(pose_file: Path) -> tuple[list[np.ndarray], list[str]]:
    """从 odom_matched_camera.txt 加载位姿。

    用 R_world_yaw @ R_CAM2ROBOT 构建旋转矩阵，与 odom_to_camera_pose.py 一致。
    """
    poses = []
    names = []
    with open(pose_file) as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 7:
                continue
            name = parts[0]
            x = float(parts[1]) / 1000.0  # mm -> m
            y = float(parts[2]) / 1000.0
            yaw = float(parts[6])

            # R_world_camera = Rz(yaw) @ R_CAM2ROBOT
            cy, sy = np.cos(yaw), np.sin(yaw)
            Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])
            R = Rz @ R_CAM2ROBOT

            T = np.eye(4)
            T[:3, :3] = R
            T[:3, 3] = [x, y, 0.0]
            poses.append(T)
            names.append(name)
    return poses, names


def build_frame_pointcloud(depth: np.ndarray, rgb: np.ndarray | None = None,
                           depth_unit: str = "mm"):
    """将单帧深度图反投影为相机坐标系下的点云。

    Args:
        depth: (H, W) 深度图
        rgb: (H, W, 3) RGB 图像 (BGR from cv2), 可选
        depth_unit: "mm" 或 "m"

    Returns:
        points: (N, 3) 相机坐标系点云
        colors: (N, 3) RGB 颜色 (0-255), 无 rgb 时返回 None
    """
    valid = depth > 0
    if not valid.any():
        return np.zeros((0, 3), dtype=np.float64), None

    v, u = np.where(valid)
    z = depth[v, u].astype(np.float64)
    if depth_unit == "mm":
        z = z / 1000.0  # mm -> m

    x = (u - CX) * z / FX
    y = (v - CY) * z / FY

    points = np.stack([x, y, z], axis=1)

    colors = None
    if rgb is not None:
        colors = rgb[v, u].astype(np.float64)  # (N, 3) BGR

    return points, colors


def main():
    parser = argparse.ArgumentParser(description="depth_fused + 位姿 -> 场景点云")
    parser.add_argument("--data-dir", type=Path,
                        default=Path(__file__).resolve().parent / "data",
                        help="pipeline 产出的 data/ 目录")
    parser.add_argument("--depth-dir", type=Path, default=None,
                        help="深度图目录 (默认 data/depth_fused/)")
    parser.add_argument("--depth-unit", choices=["mm", "m"], default="mm",
                        help="深度图单位 (默认 mm)")
    parser.add_argument("--flat", action="store_true",
                        help="强制 roll=pitch=0，只保留 yaw 旋转")
    parser.add_argument("--pose-file", type=Path, default=None,
                        help="位姿文件 (默认 data/rgb_camera_poses.txt)")
    parser.add_argument("--max-depth", type=float, default=5.0,
                        help="最大深度 m (默认 5.0)")
    parser.add_argument("--voxel-size", type=float, default=0.0,
                        help="体素下采样尺寸 m (0=不下采样, 默认 0)")
    parser.add_argument("--trajectory", action="store_true",
                        help="同时输出相机轨迹点云 (trajectory.ply)")
    parser.add_argument("--frame-range", type=str, default=None,
                        help="帧范围, 格式 start:end (默认全部)")
    parser.add_argument("--output", type=Path, default=None,
                        help="输出 PLY 路径 (默认 data/pointcloud_fused.ply)")
    args = parser.parse_args()

    data_dir = args.data_dir
    depth_dir = args.depth_dir or (data_dir / "depth_fused")
    # 自动检测 RGB 目录: jpg/ 或 rgb/
    jpg_dir = data_dir / "jpg"
    if not jpg_dir.is_dir():
        jpg_dir = data_dir / "rgb"
    pose_file = args.pose_file or (data_dir / "rgb_camera_poses.txt")

    if not depth_dir.is_dir():
        raise FileNotFoundError(f"深度目录不存在: {depth_dir}")
    if not pose_file.exists():
        raise FileNotFoundError(f"位姿文件不存在: {pose_file}")

    depth_files = sorted(depth_dir.glob("*.npy"))

    # 检测位姿文件格式并加载
    is_odom_format = pose_file.name == "odom_matched_camera.txt"
    if is_odom_format:
        poses_raw, pose_names = load_odom_camera_poses(pose_file)
        # odom 名称与深度文件名不匹配，按索引配对
        name_to_pose = None
    else:
        poses_raw = load_poses(pose_file)
        name_to_pose = {}
        for T, line_text in zip(poses_raw, _pose_lines(pose_file)):
            name = line_text.split()[0]
            name_to_pose[name] = T

    # 构建 name -> jpg 映射
    name_to_jpg = {}
    if jpg_dir.is_dir():
        for jf in sorted(jpg_dir.glob("*.jpg")):
            name_to_jpg[jf.stem] = jf

    # 配对: 名称匹配 或 索引匹配
    pairs = []
    if name_to_pose is not None:
        # 名称匹配
        for df in depth_files:
            stem = df.stem
            if stem in name_to_pose:
                rgb_path = name_to_jpg.get(stem)
                pairs.append((df, name_to_pose[stem], rgb_path))
        print(f"配对成功: {len(pairs)} 帧 (depth={len(depth_files)}, poses={len(name_to_pose)}, rgb={len(name_to_jpg)})")
        if len(pairs) < len(depth_files):
            missing = len(depth_files) - len(pairs)
            print(f"  !! {missing} 帧 depth 无对应位姿")
    else:
        # 索引匹配 (odom 格式)
        n = min(len(depth_files), len(poses_raw))
        for i in range(n):
            df = depth_files[i]
            stem = df.stem
            rgb_path = name_to_jpg.get(stem)
            pairs.append((df, poses_raw[i], rgb_path))
        print(f"配对成功: {n} 帧 (depth={len(depth_files)}, poses={len(poses_raw)}, rgb={len(name_to_jpg)})")

    # 帧范围过滤
    if args.frame_range:
        start, end = map(int, args.frame_range.split(":"))
        pairs = pairs[start:end+1]
        print(f"  帧范围 [{start}:{end}] -> {len(pairs)} 帧")

    all_points = []
    all_colors = []
    use_color = any(p[2] is not None for p in pairs)

    for i, (df, T, rgb_path) in enumerate(pairs):
        depth = np.load(str(df))

        rgb = None
        if rgb_path and rgb_path.exists():
            rgb = cv2.imread(str(rgb_path))  # BGR, (H, W, 3)

        # 强制 roll=pitch=0
        if args.flat:
            T = flatten_pose(T)

        pts_cam, colors = build_frame_pointcloud(depth, rgb, args.depth_unit)

        # 深度过滤
        mask = pts_cam[:, 2] <= args.max_depth
        pts_cam = pts_cam[mask]
        if colors is not None:
            colors = colors[mask]

        if len(pts_cam) == 0:
            continue

        # 变换到世界坐标系
        pts_world = (T[:3, :3] @ pts_cam.T + T[:3, 3:4]).T
        all_points.append(pts_world)
        if colors is not None:
            all_colors.append(colors)

        if (i + 1) % 100 == 0:
            print(f"  [{i+1}/{len(pairs)}] 累计 {sum(len(p) for p in all_points)} 点")

    if not all_points:
        print("!! 没有有效点")
        return

    points = np.vstack(all_points)
    colors = np.vstack(all_colors) if all_colors and use_color else None
    print(f"原始点云: {len(points)} 点" + (f", 带颜色" if colors is not None else ""))

    # 体素下采样
    if args.voxel_size > 0:
        try:
            import open3d as o3d
            pcd = o3d.geometry.PointCloud()
            pcd.points = o3d.utility.Vector3dVector(points)
            if colors is not None:
                pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
            pcd = pcd.voxel_down_sample(args.voxel_size)
            points = np.asarray(pcd.points)
            colors = np.asarray(pcd.colors) * 255.0 if pcd.colors else None
            print(f"体素下采样 (voxel={args.voxel_size}m): {len(points)} 点")
        except ImportError:
            print("  !! open3d 未安装，跳过体素下采样 (pip install open3d)")

    # 保存 PLY
    out_path = args.output or (data_dir / "pointcloud_fused.ply")
    try:
        import open3d as o3d
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        if colors is not None:
            pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
        o3d.io.write_point_cloud(str(out_path), pcd)
    except ImportError:
        # 纯 numpy 写 PLY
        if colors is not None:
            out_path.write_text(_ply_header_colored(len(points)) + _ply_body_colored(points, colors))
        else:
            out_path.write_text(_ply_header(len(points)) + _ply_body(points))

    print(f"已保存: {out_path}  ({len(points)} 点)")

    # 输出轨迹点云
    if args.trajectory:
        traj_points = np.array([T[:3, 3] for _, T, _ in pairs])
        n_traj = len(traj_points)
        # 按时间渐变着色: 蓝→红
        traj_colors = np.zeros((n_traj, 3), dtype=np.float64)
        traj_colors[:, 0] = np.linspace(0, 1, n_traj)   # R: 0→1
        traj_colors[:, 2] = np.linspace(1, 0, n_traj)   # B: 1→0

        traj_path = data_dir / "trajectory.ply"
        try:
            import open3d as o3d
            pcd = o3d.geometry.PointCloud()
            pcd.points = o3d.utility.Vector3dVector(traj_points)
            pcd.colors = o3d.utility.Vector3dVector(traj_colors)
            o3d.io.write_point_cloud(str(traj_path), pcd)
        except ImportError:
            traj_path.write_text(
                _ply_header_colored(n_traj) +
                _ply_body_colored(traj_points, traj_colors * 255)
            )
        print(f"轨迹点云: {traj_path}  ({n_traj} 点, 蓝→红=时间)")


def _ply_header(n: int) -> str:
    return (
        "ply\nformat ascii 1.0\n"
        f"element vertex {n}\nproperty float x\nproperty float y\nproperty float z\nend_header\n"
    )


def _ply_body(points: np.ndarray) -> str:
    lines = [f"{p[0]:.6f} {p[1]:.6f} {p[2]:.6f}" for p in points]
    return "\n".join(lines) + "\n"


def _ply_header_colored(n: int) -> str:
    return (
        "ply\nformat ascii 1.0\n"
        f"element vertex {n}\n"
        "property float x\nproperty float y\nproperty float z\n"
        "property uchar red\nproperty uchar green\nproperty uchar blue\n"
        "end_header\n"
    )


def _ply_body_colored(points: np.ndarray, colors: np.ndarray) -> str:
    lines = []
    for p, c in zip(points, colors):
        r, g, b = int(c[0]), int(c[1]), int(c[2])
        lines.append(f"{p[0]:.6f} {p[1]:.6f} {p[2]:.6f} {r} {g} {b}")
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    main()
