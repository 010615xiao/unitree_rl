#!/usr/bin/env python3
"""
iTOF -> 标准数据集预处理管线

从原始 iTOF 传感器数据 (OdomPose.txt + jpg_bin/) ，经过：
  1. 时间戳对齐 (match_data)
  2. bin -> npy 深度转换 (convert_depth)
  3. 双曝光融合 (fuse_depth)
  3.5. 过滤有效深度过少的帧 (filter_depth)
  4. 远距离遮罩 (mask_depth)
  5. 机器人里程计 -> 相机位姿 (odom_to_camera_pose)
  6. LingBot-Depth 稀疏->稠密深度补全 (batch_infer_itof)
  7. 导出为全局重建标准格式到 datasets/<name>/

Usage:
    # 使用 config.yaml 默认值
    python itof_to_depth/pipeline.py

    # 指定数据集名称
    python itof_to_depth/pipeline.py --name itof_0617 --raw_dir itof_to_depth/itof_0622
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Optional

import numpy as np

# ============================================================
# 路径常量
# ============================================================
PIPELINE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PIPELINE_DIR.parent
CONVERT_DIR = PIPELINE_DIR / "convert_script"
LINGBOT_DIR = PROJECT_ROOT / "external" / "lingbot-depth"
DATASETS_DIR = PROJECT_ROOT / "datasets"

PYTHON = sys.executable


# ============================================================
# 格式检测
# ============================================================
def detect_format(raw_dir: Path) -> str:
    """根据目录结构自动检测数据格式。"""
    if (raw_dir / "pointcloud1").is_dir() and (raw_dir / "odometry.txt").exists():
        return "0707"
    # (pointcloud1/2/images 同名) + OdomPose.txt (按时间戳最近匹配)
    if (raw_dir / "pointcloud1").is_dir() and (raw_dir / "OdomPose.txt").exists():
        return "ep0005"
    return "0622"


# ============================================================
# 配置加载
# ============================================================
def load_config() -> dict:
    """加载 itof_to_depth/config.yaml，返回嵌套字典。文件不存在则返回空字典。"""
    config_path = PIPELINE_DIR / "config.yaml"
    if not config_path.exists():
        return {}
    import yaml
    with open(config_path) as f:
        return yaml.safe_load(f) or {}


def cfg_get(config: dict, *keys, default=None):
    """从嵌套 config 字典中按路径取值。cfg_get(cfg, 'camera', 'height', default=0.065)"""
    node = config
    for k in keys:
        if not isinstance(node, dict) or k not in node:
            return default
        node = node[k]
    return node


def resolve_path(value, base_dir: Optional[Path] = None) -> Optional[Path]:
    """将字符串路径解析为绝对路径。相对于 base_dir (默认 PROJECT_ROOT)。"""
    if value is None:
        return None
    p = Path(str(value))
    if p.is_absolute():
        return p
    return (base_dir or PROJECT_ROOT) / p


# ============================================================
# 工具函数
# ============================================================
def log(msg: str) -> None:
    print(f"[pipeline] {msg}")


def run_cmd(cmd: List[str], step_name: str, cwd: Optional[str] = None) -> bool:
    log(f"  $ {' '.join(str(c) for c in cmd)}")
    t0 = time.time()
    result = subprocess.run(cmd, cwd=cwd)
    elapsed = time.time() - t0
    if result.returncode != 0:
        log(f"  !! Step '{step_name}' 失败 (returncode={result.returncode}, {elapsed:.1f}s)")
        return False
    log(f"  OK ({elapsed:.1f}s)")
    return True


def dir_has_files(directory: Path, ext: str = "*") -> bool:
    """检查目录是否存在且包含文件。"""
    if not directory.is_dir():
        return False
    return any(directory.glob(ext))


def ensure_intrinsics(work_data_dir: Path, intrinsics_path: Optional[Path]) -> None:
    """确保 work_dir/data/intrinsics.txt。"""
    dst = work_data_dir / "intrinsics.txt"
    if dst.exists():
        return
    if intrinsics_path and intrinsics_path.exists():
        shutil.copy2(intrinsics_path, dst)
        log(f"  拷贝内参文件 -> {dst}")
    else:
        log(f"  !! 内参文件不存在: {dst}，LingBot 推理可能失败")


# ============================================================
# Step 1: match_data
# ============================================================
def step1_match_data(raw_dir: Path, work_dir: Path, fmt: str = "0622") -> bool:
    """数据对齐: 根据格式匹配 jpg + bin + odom 数据。

    0622: 时间戳对齐, 输出 bin_long/, bin_short/, jpg/, mapping.txt, odom_matched.txt
    0707: 名称对齐, 输出 bin_pc1/, bin_pc2/, jpg/, odom_matched.txt
    """
    log("=" * 60)
    log(f"Step 1: match_data (格式: {fmt})")

    data_dir = work_dir / "data"
    # 0622 检查 mapping.txt, 0707 检查 odom_matched.txt
    check_file = "mapping.txt" if fmt == "0622" else "odom_matched.txt"
    if (data_dir / check_file).exists():
        log(f"  [SKIP] data/{check_file} 已存在")
        return True

    cmd = [PYTHON, str(CONVERT_DIR / "match_data.py"),
           str(raw_dir),
           "--format", fmt,
           "--output-dir", str(data_dir)]
    return run_cmd(cmd, "match_data")


# ============================================================
# Step 2: convert_depth
# ============================================================
def step2_convert_depth(work_dir: Path, fmt: str = "0622") -> bool:
    """bin -> npy 深度转换。

    0622: bin_long/ -> depth_long/, bin_short/ -> depth_short/
    0707: bin_pc1/ -> depth_pc1/, bin_pc2/ -> depth_pc2/
    """
    log("=" * 60)
    log(f"Step 2: convert_depth (bin -> npy, 格式: {fmt})")

    data_dir = work_dir / "data"

    if fmt == "0707":
        # 0707: 转换 bin_pc1 和 bin_pc2
        pairs = [("bin_pc1", "depth_pc1"), ("bin_pc2", "depth_pc2")]
    else:
        # 0622: 转换 bin_long 和 bin_short
        pairs = [("bin_long", "depth_long"), ("bin_short", "depth_short")]

    for bin_subdir, depth_subdir in pairs:
        bin_dir = data_dir / bin_subdir
        depth_dir = data_dir / depth_subdir

        expected = len(list(bin_dir.glob("*.bin"))) if bin_dir.is_dir() else 0
        actual = len(list(depth_dir.glob("*.npy"))) if depth_dir.is_dir() else 0

        if actual >= expected > 0:
            log(f"  [SKIP] {depth_subdir}/ 已完整 ({actual} 帧)")
            continue

        if actual > 0:
            log(f"  {depth_subdir}: {actual}/{expected} 帧, 重新转换")

        log(f"  转换 {bin_subdir}/ -> {depth_subdir}/")
        cmd = [PYTHON, str(CONVERT_DIR / "convert_depth.py"),
               "-i", str(bin_dir),
               "-o", str(depth_dir)]
        if not run_cmd(cmd, f"convert_depth ({bin_subdir})"):
            return False

    return True


# ============================================================
# Step 3: fuse_depth
# ============================================================
def step3_fuse_depth(work_dir: Path, fmt: str = "0622") -> bool:
    """深度图融合。

    0622: 叠加 depth_long + depth_short -> depth_fused，long 优先（同一位置都有值时取 long）
    0707: 叠加 pc1/pc2 -> depth_fused，pc1 优先（同一位置都有值时取 pc1）
    """
    log("=" * 60)
    log("Step 3: fuse_depth")

    data_dir = work_dir / "data"
    depth_fused = data_dir / "depth_fused"

    if fmt == "0707":
        log("  0707 overlay: pc1 + pc2 -> depth_fused (pc1 priority)")
        pc1_dir = data_dir / "depth_pc1"
        pc2_dir = data_dir / "depth_pc2"
        if not pc1_dir.is_dir():
            log(f"!! depth_pc1/ 不存在: {pc1_dir}")
            return False
        if not pc2_dir.is_dir():
            log(f"!! depth_pc2/ 不存在: {pc2_dir}")
            return False

        expected = len(list(pc1_dir.glob("*.npy")))
        if depth_fused.is_dir():
            actual = len(list(depth_fused.glob("*.npy")))
            if actual >= expected > 0:
                log(f"  [SKIP] depth_fused/ 已完整 ({actual} 帧)")
                return True

        depth_fused.mkdir(parents=True, exist_ok=True)
        count = 0
        for npy_file in sorted(pc1_dir.glob("*.npy")):
            depth_pc1 = np.load(npy_file)
            depth_pc2_file = pc2_dir / npy_file.name
            if depth_pc2_file.is_file():
                depth_pc2 = np.load(depth_pc2_file)
                fused = np.where(depth_pc1 > 0, depth_pc1, depth_pc2)
            else:
                fused = depth_pc1.copy()
            np.save(depth_fused / npy_file.name, fused)
            count += 1
        log(f"  叠加完成: {count} 帧 -> {depth_fused}")
        return True

    log("  0622 overlay: long + short -> depth_fused (long priority)")
    long_dir = data_dir / "depth_long"
    short_dir = data_dir / "depth_short"
    if not long_dir.is_dir():
        log(f"!! depth_long/ 不存在: {long_dir}")
        return False
    if not short_dir.is_dir():
        log(f"!! depth_short/ 不存在: {short_dir}")
        return False

    expected = len(list(long_dir.glob("*.npy")))
    if depth_fused.is_dir():
        actual = len(list(depth_fused.glob("*.npy")))
        if actual >= expected > 0:
            log(f"  [SKIP] depth_fused/ 已完整 ({actual} 帧)")
            return True

    depth_fused.mkdir(parents=True, exist_ok=True)
    count = 0
    for npy_file in sorted(long_dir.glob("*.npy")):
        depth_long = np.load(npy_file)
        depth_short_file = short_dir / npy_file.name
        if depth_short_file.is_file():
            depth_short = np.load(depth_short_file)
            fused = np.where(depth_long > 0, depth_long, depth_short)
        else:
            fused = depth_long.copy()
        np.save(depth_fused / npy_file.name, fused)
        count += 1
    log(f"  叠加完成: {count} 帧 -> {depth_fused}")
    return True


# ============================================================
# Step 3.5: filter_depth (过滤有效深度过少的帧)
# ============================================================
def step3_5_filter_depth(work_dir: Path, min_valid: int, fmt: str = "0622") -> bool:
    """
    过滤双曝光融合后有效深度像素数 < min_valid 的帧
    """
    log("=" * 60)
    log(f"Step 3.5: filter_depth (有效深度 < {min_valid} 的帧移除, 格式: {fmt})")

    data_dir = work_dir / "data"
    depth_dir = data_dir / "depth_fused"
    jpg_dir = data_dir / "jpg"
    odom_file = data_dir / "odom_matched.txt"
    pose_file = data_dir / "rgb_camera_poses.txt"
    mapping_file = data_dir / "mapping.txt"

    if not depth_dir.is_dir():
        log(f"!! depth_fused/ 不存在: {depth_dir}")
        return False

    depth_out = data_dir / "depth_fused_filtered_out"
    jpg_out = data_dir / "jpg_filtered_out"

    if depth_out.is_dir() and any(depth_out.glob("*.npy")):
        log(f"  [SKIP] 已过滤 (depth_fused_filtered_out/ 存在)")
        if not (data_dir / "poses_filtered.txt").exists():
            log(f"  补充过滤 odom/poses...")
            removed_bins = set()
            for npy_f in depth_out.glob("*.npy"):
                stem = npy_f.stem
                removed_bins.add(stem)
                removed_bins.add(stem + ".bin")
                # 0622: 通过 mapping.txt 找到对应的 short bin
                if fmt == "0622" and mapping_file.exists():
                    with open(mapping_file) as f:
                        for line in f:
                            line = line.strip()
                            if not line or line.startswith("#") or line.startswith("---"):
                                continue
                            parts = [p.strip() for p in line.split("|")]
                            if len(parts) >= 5:
                                if parts[1].strip() == stem + ".bin":
                                    removed_bins.add(parts[1].strip())
                                    removed_bins.add(parts[1].strip().replace(".bin", ""))

            # 过滤 odom_matched.txt
            if odom_file.exists():
                odom_lines = odom_file.read_text().splitlines()
                kept = []
                removed = 0
                for line in odom_lines:
                    if not line.strip():
                        kept.append(line)
                        continue
                    bin_in_line = line.split()[0] if line.split() else ""
                    if bin_in_line in removed_bins:
                        removed += 1
                    else:
                        kept.append(line)
                odom_file.write_text("\n".join(kept) + "\n" if kept else "")
                log(f"  odom_matched.txt: 移除 {removed} 行")

            # 过滤 rgb_camera_poses.txt
            if pose_file.exists():
                pose_lines = pose_file.read_text().splitlines()
                kept = []
                removed = 0
                for line in pose_lines:
                    if not line.strip() or line.startswith("#"):
                        kept.append(line)
                        continue
                    bin_in_line = line.split()[0] if line.split() else ""
                    if bin_in_line in removed_bins:
                        removed += 1
                    else:
                        kept.append(line)
                pose_file.write_text("\n".join(kept) + "\n" if kept else "")
                log(f"  rgb_camera_poses.txt: 移除 {removed} 行")

            (data_dir / "poses_filtered.txt").touch()
        return True

    npy_files = sorted(depth_dir.glob("*.npy"))
    if not npy_files:
        log("  !! depth_fused/ 为空")
        return False

    # 构建 depth_fused 文件名 -> jpg 文件名的映射
    depth_to_jpg = {}
    if fmt == "0622" and mapping_file.exists():
        with open(mapping_file) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("---"):
                    continue
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 5:
                    bin_name = parts[1].strip()  # e.g. itof_output_08_14_45_58_769.bin
                    jpg_name = parts[4].strip()  # e.g. seg_input_08_14_45_58_399.jpg
                    depth_name = bin_name.replace(".bin", ".npy")
                    depth_to_jpg[depth_name] = jpg_name
    else:
        # depth_fused 文件名与 jpg 文件名相同
        jpg_files = sorted(jpg_dir.glob("*.jpg")) if jpg_dir.is_dir() else []
        for npy_f in npy_files:
            jpg_name = npy_f.stem + ".jpg"
            for jf in jpg_files:
                if jf.name == jpg_name:
                    depth_to_jpg[npy_f.name] = jpg_name
                    break

    # 创建过滤输出目录
    depth_out.mkdir(exist_ok=True)
    jpg_out.mkdir(exist_ok=True)

    removed_depth = []
    kept = 0

    for npy_file in npy_files:
        depth = np.load(npy_file)
        valid_count = int(np.count_nonzero(depth > 0))
        if valid_count < min_valid:
            # 移动 depth
            dst = depth_out / npy_file.name
            if not dst.exists():
                shutil.move(str(npy_file), str(dst))
            removed_depth.append(npy_file.name)
            # 移动对应的 jpg
            jpg_name = depth_to_jpg.get(npy_file.name)
            if jpg_name:
                jpg_src = jpg_dir / jpg_name
                jpg_dst = jpg_out / jpg_name
                if jpg_src.exists() and not jpg_dst.exists():
                    shutil.move(str(jpg_src), str(jpg_dst))
        else:
            kept += 1

    # 过滤 odom_matched.txt
    if odom_file.exists() and removed_depth:
        # 收集被移除的 bin 文件名（用于匹配 odom 行）
        removed_bins = set()
        for depth_name in removed_depth:
            stem = depth_name.replace(".npy", "")
            removed_bins.add(stem)
            removed_bins.add(stem + ".bin")
            # 0622: 每个 jpg 对应 2 个 bin (long+short)，都需要移除
            if fmt == "0622" and mapping_file.exists():
                with open(mapping_file) as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("#") or line.startswith("---"):
                            continue
                        parts = [p.strip() for p in line.split("|")]
                        if len(parts) >= 5 and parts[4].strip() == depth_to_jpg.get(depth_name, ""):
                            removed_bins.add(parts[1].strip())
                            removed_bins.add(parts[1].strip().replace(".bin", ""))

        odom_lines = odom_file.read_text().splitlines()
        kept_lines = []
        removed_odom = 0
        for line in odom_lines:
            if not line.strip():
                kept_lines.append(line)
                continue
            bin_in_line = line.split()[0] if line.split() else ""
            if bin_in_line in removed_bins:
                removed_odom += 1
            else:
                kept_lines.append(line)
        odom_file.write_text("\n".join(kept_lines) + "\n" if kept_lines else "")
        log(f"  odom_matched.txt: 移除 {removed_odom} 行")

        # 过滤 rgb_camera_poses.txt (格式同 odom_matched.txt)
        if pose_file.exists():
            pose_lines = pose_file.read_text().splitlines()
            kept_pose_lines = []
            removed_pose = 0
            for line in pose_lines:
                if not line.strip() or line.startswith("#"):
                    kept_pose_lines.append(line)
                    continue
                bin_in_line = line.split()[0] if line.split() else ""
                if bin_in_line in removed_bins:
                    removed_pose += 1
                else:
                    kept_pose_lines.append(line)
            pose_file.write_text("\n".join(kept_pose_lines) + "\n" if kept_pose_lines else "")
            log(f"  rgb_camera_poses.txt: 移除 {removed_pose} 行")

    log(f"  保留 {kept} 帧, 移除 {len(removed_depth)} 帧 (阈值: {min_valid} 有效像素)")
    return True


# ============================================================
# Step 4: mask_depth
# ============================================================
def step4_mask_depth(work_dir: Path, max_depth_m: float, fmt: str = "0622") -> bool:
    """远距离遮罩: >max_depth -> 0, mm -> m。

    两种格式均从 depth_fused/ 读取（0707 在 step3 已完成叠加）。
    """
    log("=" * 60)
    log(f"Step 4: mask_depth (远距离遮罩 + mm->m, 格式: {fmt})")

    data_dir = work_dir / "data"
    output = data_dir / "depth_fused_masked"

    # step3 对两种格式都产出 depth_fused/
    input_dir = data_dir / "depth_fused"

    expected = len(list(input_dir.glob("*.npy"))) if input_dir.is_dir() else 0
    actual = len(list(output.glob("*.npy"))) if output.is_dir() else 0

    if actual >= expected > 0:
        log(f"  [SKIP] depth_fused_masked/ 已完整 ({actual} 帧)")
        return True

    if actual > 0:
        log(f"  depth_fused_masked: {actual}/{expected} 帧, 重新遮罩")

    cmd = [PYTHON, str(CONVERT_DIR / "mask_depth.py"),
           "--input", str(input_dir),
           "--output", str(output),
           "--max_depth", str(max_depth_m),
           "--unit", "mm"]
    return run_cmd(cmd, "mask_depth")


# ============================================================
# Step 4.5: 自动计算相机高度 (SAM3 floor 分割)
# ============================================================
_ITOF_FX, _ITOF_FY = 267.730011, 267.730011
_ITOF_CX, _ITOF_CY = 315.010010, 214.380050


def _load_itof_intrinsics(work_data_dir: Path) -> tuple:
    """
    从 data/intrinsics.txt 读取 (fx, fy, cx, cy)
    """
    intr_path = work_data_dir / "intrinsics.txt"
    if intr_path.exists():
        try:
            fx, fy, cx, cy = _parse_intrinsics(intr_path)
            log(f"  内参取自 {intr_path.name}: fx={fx:.4f}, fy={fy:.4f}, "
                f"cx={cx:.4f}, cy={cy:.4f}")
            return fx, fy, cx, cy
        except ValueError as e:
            log(f"  !! 解析 {intr_path} 失败 ({e}), 使用兜底内参")
    else:
        log(f"  !! 未找到 {intr_path}, 使用兜底内参 (可能不准)")
    return _ITOF_FX, _ITOF_FY, _ITOF_CX, _ITOF_CY


def step_auto_camera_height(work_dir: Path, sam3_url: str,
                            sample_ratio: float = 0.3) -> float:
    """利用 SAM3 分割 floor，结合深度图自动计算相机高度。

    原理: 地板像素在相机坐标系中 y_cam = (v - cy) * depth / fy,
    对所有地板像素取直方图峰值 → 相机离地高度。

    Args:
        sample_ratio: 采样比例 (0.0-1.0)

    Returns:
        相机高度 (m)
    """
    import requests

    log("=" * 60)
    log("Step 4.5: 自动计算相机高度 (SAM3 floor 分割)")

    data_dir = work_dir / "data"
    depth_dir = data_dir / "depth_fused_masked"
    jpg_dir = data_dir / "jpg"

    # 内参从 data/intrinsics.txt 动态读取, 与深度/点云所用内参保持一致
    itof_fx, itof_fy, _itof_cx, itof_cy = _load_itof_intrinsics(data_dir)

    # 检查输出是否已缓存
    cache_file = data_dir / "camera_height_auto.txt"
    if cache_file.exists():
        h = float(cache_file.read_text().strip())
        log(f"  [SKIP] 已缓存: {h*1000:.1f}mm ({cache_file.name})")
        return h

    # 收集帧对 (depth npy + jpg)
    depth_files = sorted(depth_dir.glob("*.npy")) if depth_dir.is_dir() else []
    jpg_files = sorted(jpg_dir.glob("*.jpg")) if jpg_dir.is_dir() else []

    if not depth_files or not jpg_files:
        raise RuntimeError(f"  !! 无法计算: depth={len(depth_files)}, jpg={len(jpg_files)}")

    # 两个列表按排序后顺序一一对应
    num_pairs = min(len(depth_files), len(jpg_files))
    # 按采样比例均匀采样
    num_samples = max(1, int(num_pairs * sample_ratio))
    if num_samples < num_pairs:
        indices = np.linspace(0, num_pairs - 1, num_samples, dtype=int)
    else:
        indices = list(range(num_pairs))

    log(f"  SAM3: {sam3_url}")
    log(f"  采样 {len(indices)}/{num_pairs} 帧 ({sample_ratio*100:.0f}%)")

    heights = []
    for frame_idx, idx in enumerate(indices):
        npy_path = depth_files[idx]
        jpg_path = jpg_files[idx]

        try:
            resp = requests.post(
                f"{sam3_url}/predict",
                json={"image_path": str(jpg_path), "text": "floor",
                      "mask_format": "base64_png"},
                timeout=30,
            )
            data = resp.json()
            if not data.get("success") or data.get("num_detections", 0) == 0:
                continue

            best_idx = int(np.argmax(data["scores"]))
            mask_format = data.get("mask_format", "json")
            if mask_format == "base64_png":
                import base64 as _b64, cv2 as _cv2
                buf = _b64.b64decode(data["masks_b64"][best_idx])
                arr = np.frombuffer(buf, dtype=np.uint8)
                mask = _cv2.imdecode(arr, _cv2.IMREAD_UNCHANGED)
            else:
                mask = np.array(data["masks"][best_idx], dtype=np.uint8)

            depth = np.load(str(npy_path))
            valid = np.isfinite(depth) & (depth > 0.1) & (depth < 10.0)
            floor_mask = mask.astype(bool) & valid

            v_coords, _u_coords = np.where(floor_mask)
            if len(v_coords) < 50:
                continue

            z_vals = depth[v_coords, _u_coords].astype(np.float64)
            y_camera = (v_coords - itof_cy) * z_vals / itof_fy

            # 地板应该在相机下方 (y_cam > 0 表示图像中往下)
            pos = y_camera[(y_camera > 0) & (y_camera < 0.5)]
            if len(pos) < 50:
                continue

            hist, edges = np.histogram(pos, bins=np.arange(0, 0.5, 0.005))
            if hist.max() < 50:
                continue
            peak_idx = int(np.argmax(hist))
            h = (edges[peak_idx] + edges[peak_idx + 1]) / 2
            heights.append(h)

        except Exception as e:
            log(f"  Frame {idx}: {e}")

    if not heights:
        raise RuntimeError("  !! SAM3 未能计算出有效相机高度 (所有帧都失败)")

    heights_arr = np.array(heights)
    median_h = float(np.median(heights_arr))

    # 缓存结果
    cache_file.write_text(f"{median_h:.6f}\n")

    log(f"  成功 {len(heights)}/{len(indices)} 帧")
    log(f"  相机高度: median={median_h*1000:.1f}mm, "
        f"mean={heights_arr.mean()*1000:.1f}mm, "
        f"std={heights_arr.std()*1000:.1f}mm")
    log(f"  已缓存 -> {cache_file.name}")
    return median_h


# ============================================================
# Step 5: odom_to_camera_pose
# ============================================================
def step5_odom_to_camera_pose(work_dir: Path, camera_height: float, fmt: str = "0622") -> bool:
    """机器人里程计 -> RGB 相机位姿 (4x4 矩阵)。"""
    log("=" * 60)
    log("Step 5: odom_to_camera_pose")

    data_dir = work_dir / "data"
    poses_file = data_dir / "rgb_camera_poses.txt"

    if poses_file.exists():
        log("  [SKIP] rgb_camera_poses.txt 已存在")
        return True

    cmd = [PYTHON, str(CONVERT_DIR / "odom_to_camera_pose.py"),
           "--odom", str(data_dir / "odom_matched.txt"),
           "--camera_height", str(camera_height),
           "--format", fmt]
    return run_cmd(cmd, "odom_to_camera_pose")


# ============================================================
# Step 6: batch_infer_itof (LingBot-Depth)
# ============================================================
def step6_batch_infer(work_dir: Path, model_path: str, device: str,
                      filter_flying: float) -> bool:
    """LingBot-Depth 稀疏->稠密深度补全。"""
    log("=" * 60)
    log("Step 6: batch_infer_itof (LingBot-Depth 稠密化)")

    data_dir = work_dir / "data"
    input_dir = data_dir / "depth_fused_masked"
    output_depth = data_dir / "dense_depth_fused"
    output_conf = data_dir / "dense_conf_fused"
    output_ply = data_dir / "dense_depth_ply"

    # 检查是否已完成
    if dir_has_files(output_depth, "*.npy"):
        in_count = len(list(input_dir.glob("*.npy"))) if input_dir.is_dir() else 0
        out_count = len(list(output_depth.glob("*.npy")))
        if out_count >= in_count and in_count > 0:
            log(f"  [SKIP] dense_depth_fused/ 已有 {out_count} 帧 (>= 输入 {in_count} 帧)")
            return True

    # 确保 intrinsics.txt 存在
    ensure_intrinsics(data_dir.parent, None)
    ensure_intrinsics(work_dir, None)

    cmd = [PYTHON, str(LINGBOT_DIR / "batch_infer_itof.py"),
           "--data-dir", str(work_dir),
           "--depth-dir", str(input_dir),
           "--out-depth-dir", str(output_depth),
           "--out-conf-dir", str(output_conf),
           "--out-ply-dir", str(output_ply),
           "--model", str(resolve_path(model_path) or model_path),
           "--device", device,
           "--filter-flying", str(filter_flying),
           "--skip-existing"]
    return run_cmd(cmd, "batch_infer_itof", cwd=str(LINGBOT_DIR))


# ============================================================
# Step 7: export_dataset
# ============================================================
def _parse_intrinsics(intrinsics_path: Path) -> tuple:
    """从内参文件中提取 fx, fy, cx, cy。

    支持多种格式，跳过非数值行。
    """
    with open(intrinsics_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 4:
                try:
                    vals = [float(x) for x in parts[:4]]
                    return tuple(vals)
                except ValueError:
                    continue
    raise ValueError(f"无法从 {intrinsics_path} 解析内参 (fx fy cx cy)")


def _export_poses(pose_src: Path, pose_dst: Path, num_frames: int,
                  fmt: str = "0622") -> None:
    """从 rgb_camera_poses.txt 导出 camera_poses.txt（按数量截断）。"""
    poses = []
    with open(pose_src) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 17:
                matrix_vals = parts[-16:]
                poses.append(" ".join(matrix_vals))

    if fmt == "0622":
        deduped = poses[::2]
    else:
        deduped = poses

    deduped = deduped[:num_frames]

    with open(pose_dst, "w") as f:
        for line in deduped:
            f.write(line + "\n")

    log(f"  导出 {len(deduped)} 条位姿 -> {pose_dst}")


def _export_poses_filtered(pose_src: Path, pose_dst: Path,
                           matched_jpg: list, fmt: str = "0622") -> None:
    """从 rgb_camera_poses.txt 按 matched_jpg 的 stem 过滤导出 camera_poses.txt。"""
    # 构建 stem -> pose 映射
    name_to_pose = {}
    with open(pose_src) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 17:
                continue
            name = parts[0]
            matrix_vals = parts[-16:]
            name_to_pose[name] = " ".join(matrix_vals)

    poses = []
    for jf in matched_jpg:
        pose_line = name_to_pose.get(jf.stem)
        if pose_line:
            poses.append(pose_line)

    with open(pose_dst, "w") as f:
        for line in poses:
            f.write(line + "\n")

    log(f"  导出 {len(poses)} 条位姿 -> {pose_dst}")


def step7_export(work_dir: Path, dataset_name: str,
                 intrinsics_path: Optional[Path],
                 output_dir: Optional[Path],
                 fmt: str = "0622") -> bool:
    """导出为 da3_ezviz 标准格式。"""
    log("=" * 60)
    log("Step 7: export_dataset (导出标准数据集)")

    data_dir = work_dir / "data"
    out = output_dir or (DATASETS_DIR / dataset_name)
    out.mkdir(parents=True, exist_ok=True)

    # ---- 源文件检查 ----
    jpg_dir = data_dir / "jpg"
    depth_dir = data_dir / "dense_depth_fused"
    conf_dir = data_dir / "dense_conf_fused"
    pose_src = data_dir / "rgb_camera_poses.txt"

    for src, name in [(jpg_dir, "jpg/"), (depth_dir, "dense_depth_fused/"),
                      (conf_dir, "dense_conf_fused/"), (pose_src, "rgb_camera_poses.txt")]:
        if not src.exists():
            log(f"  !! 源文件不存在: {name}")
            return False

    # ---- 收集文件列表 ----
    jpg_files = sorted(jpg_dir.glob("*.jpg"))
    depth_files = sorted(depth_dir.glob("*.npy"))
    conf_files = sorted(conf_dir.glob("*.npy"))

    # 按文件名 stem 取交集，确保 jpg/depth/conf 一一对应
    depth_stems = {f.stem for f in depth_files}
    conf_stems = {f.stem for f in conf_files}
    valid_stems = depth_stems & conf_stems

    matched_jpg = []
    matched_depth = []
    matched_conf = []
    for jf in jpg_files:
        if jf.stem in valid_stems:
            matched_jpg.append(jf)
            matched_depth.append(depth_dir / f"{jf.stem}.npy")
            matched_conf.append(conf_dir / f"{jf.stem}.npy")

    num_frames = len(matched_jpg)
    dropped = len(jpg_files) - num_frames
    log(f"  帧数: {num_frames} (jpg={len(jpg_files)}, depth={len(depth_files)}, conf={len(conf_files)})")
    if dropped > 0:
        log(f"  !! {dropped} 帧缺少 depth/conf，已丢弃")

    if num_frames == 0:
        log("  !! 没有找到任何完整帧")
        return False

    # ---- 7a. rgb/ ----
    rgb_out = out / "rgb"
    rgb_out.mkdir(exist_ok=True)
    for i, src in enumerate(matched_jpg):
        dst = rgb_out / f"{i:05d}.jpg"
        if not dst.exists():
            shutil.copy2(src, dst)
    log(f"  rgb/: {num_frames} 帧")

    # ---- 7b. depth/ ----
    depth_out = out / "depth"
    depth_out.mkdir(exist_ok=True)
    for i, src in enumerate(matched_depth):
        dst = depth_out / f"{i:05d}.npy"
        if not dst.exists():
            shutil.copy2(src, dst)
    log(f"  depth/: {num_frames} 帧")

    # ---- 7c. conf/ ----
    conf_out = out / "conf"
    conf_out.mkdir(exist_ok=True)
    for i, src in enumerate(matched_conf):
        dst = conf_out / f"{i:05d}_conf.npy"
        if not dst.exists():
            shutil.copy2(src, dst)
    log(f"  conf/: {num_frames} 帧")

    # ---- 7d. camera_poses.txt (按 matched_jpg 的 stem 过滤位姿) ----
    pose_dst = out / "camera_poses.txt"
    _export_poses_filtered(pose_src, pose_dst, matched_jpg, fmt)

    # ---- 7d2. odom_matched_camera.txt (按 matched_jpg 的 stem 过滤) ----
    odom_cam_src = data_dir / "odom_matched_camera.txt"
    if odom_cam_src.exists():
        odom_cam_dst = out / "odom_matched_camera.txt"
        # 构建 stem -> odom lines 映射
        name_to_odom = {}
        with open(odom_cam_src) as f:
            for line in f:
                parts = line.split()
                if parts:
                    name_to_odom.setdefault(parts[0], []).append(line)

        with open(odom_cam_dst, "w") as fout:
            for jf in matched_jpg:
                lines = name_to_odom.get(jf.stem, [])
                if fmt == "0622":
                    # 0622: 每个 jpg 对应 2 条 odom，取第 1 条
                    if lines:
                        fout.write(lines[0])
                else:
                    for line in lines:
                        fout.write(line)
        log(f"  odom_matched_camera.txt: {num_frames} 行")

    # ---- 7d3. camera_height.txt ----
    height_file = data_dir / "camera_height.txt"
    if not height_file.exists():
        height_file = data_dir / "camera_height_auto.txt"
    if height_file.exists():
        shutil.copy2(height_file, out / "camera_height.txt")
        log(f"  camera_height.txt: {height_file.read_text().strip()}m")

    # ---- 7e. intrinsic.txt ----
    intrinsic_dst = out / "intrinsic.txt"
    if intrinsics_path and intrinsics_path.exists():
        fx, fy, cx, cy = _parse_intrinsics(intrinsics_path)
        with open(intrinsic_dst, "w") as f:
            for _ in range(num_frames):
                f.write(f"{fx} {fy} {cx} {cy}\n")
        log(f"  intrinsic.txt: {num_frames} 行 (fx={fx}, fy={fy}, cx={cx}, cy={cy})")
    else:
        log("  !! 未提供 --intrinsics，跳过 intrinsic.txt 导出")

    # ---- 完成 ----
    log("=" * 60)
    log(f"导出完成 -> {out}")
    log(f"  rgb/:      {len(list(rgb_out.glob('*.jpg')))} 帧")
    log(f"  depth/:    {len(list(depth_out.glob('*.npy')))} 帧")
    log(f"  conf/:     {len(list(conf_out.glob('*_conf.npy')))} 帧")
    log(f"  camera_poses.txt: {sum(1 for l in open(pose_dst) if l.strip())} 行")
    if intrinsic_dst.exists():
        log(f"  intrinsic.txt:  {sum(1 for l in open(intrinsic_dst) if l.strip())} 行")
    log("")
    log(f"主项目使用:")
    log(f"  python -m global_reconstruction.reconstruction.reconstruct_and_segment")
    log(f"  (设置 data.default_dir: \"{out}\" 或 GLOBAL_RECON_DATA_DIR={out})")
    return True


# ============================================================
# 主流程
# ============================================================
def main() -> int:
    # 加载配置文件
    config = load_config()

    parser = argparse.ArgumentParser(
        description="iTOF -> 标准数据集预处理管线",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--raw_dir", type=Path, default=None,
                        help="原始数据目录 (默认从 config.yaml)")
    parser.add_argument("--work_dir", type=Path, default=None,
                        help="中间产物目录 (默认从 config.yaml)")
    parser.add_argument("--format", type=str, default=None,
                        choices=["0622", "0707", "ep0005"],
                        help="数据格式: 0622=时间戳匹配+双曝光, 0707=名称匹配, "
                             "ep0005=0707布局+OdomPose时间戳最近匹配 (默认自动检测)")
    parser.add_argument("--name", type=str, default=None,
                        help="输出数据集名称 (默认从 config.yaml)")
    parser.add_argument("--intrinsics", type=Path, default=None,
                        help="内参文件路径 (默认自动检测 work_dir/data/intrinsics.txt)")
    parser.add_argument("--camera_height", type=str, default=None,
                        help="相机高度 m (数字) 或 'auto' (SAM3 自动计算, 默认从 config.yaml)")
    parser.add_argument("--max_depth", type=float, default=None,
                        help="遮罩最大深度 m (默认从 config.yaml)")
    parser.add_argument("--min-valid-depth", type=int, default=None,
                        help="双曝光融合后有效深度像素数阈值，低于此值的帧被过滤 (默认从 config.yaml)")
    parser.add_argument("--model", type=str, default=None,
                        help="LingBot-Depth 模型路径 (默认从 config.yaml)")
    parser.add_argument("--device", type=str, default=None,
                        choices=["auto", "cuda", "cpu"],
                        help="推理设备 (默认从 config.yaml)")
    parser.add_argument("--filter-flying", type=float, default=None,
                        help="LingBot 边缘裁剪比例 (默认从 config.yaml)")
    parser.add_argument("--sample-ratio", type=float, default=None,
                        help="SAM3 相机高度采样比例 0.0-1.0 (默认从 config.yaml)")
    parser.add_argument("--skip-infer", action="store_true",
                        help="跳过 LingBot-Depth 推理 (Step 6)")
    parser.add_argument("--export-only", action="store_true",
                        help="仅执行导出步骤 (Step 7)")
    parser.add_argument("--output-dir", type=Path, default=None,
                        help="自定义输出路径 (默认 datasets/<name>/)")
    args = parser.parse_args()

    # ---- config + CLI ----
    raw_dir = resolve_path(args.raw_dir or cfg_get(config, "defaults", "raw_dir"))
    work_dir = resolve_path(args.work_dir or cfg_get(config, "defaults", "work_dir")) or raw_dir
    dataset_name = args.name or cfg_get(config, "defaults", "name", default="itof_dataset")
    raw_height = args.camera_height if args.camera_height is not None \
        else cfg_get(config, "camera", "height", default=0.065)

    # camera_height
    auto_camera_height = str(raw_height).strip().lower() in ("auto", "sam3")
    if auto_camera_height:
        camera_height = None  # 在 step4 之后自动计算
    else:
        camera_height = float(raw_height)

    sam3_url = cfg_get(config, "services", "sam3_url", default="http://localhost:20023")
    sample_ratio = args.sample_ratio if args.sample_ratio is not None \
        else cfg_get(config, "services", "camera_height_sample_ratio", default=0.3)

    max_depth = args.max_depth if args.max_depth is not None \
        else cfg_get(config, "depth", "max_depth", default=2.5)
    min_valid_depth = args.min_valid_depth if args.min_valid_depth is not None \
        else cfg_get(config, "depth", "min_valid_depth", default=500)
    model_path = args.model or cfg_get(config, "lingbot", "model",
                                       default=str(LINGBOT_DIR / "model" / "model.pt"))
    device = args.device or cfg_get(config, "lingbot", "device", default="auto")
    filter_flying = args.filter_flying if args.filter_flying is not None \
        else cfg_get(config, "lingbot", "filter_flying", default=0.0)

    # ---- 内参自动检测 ----
    intrinsics = None
    if args.intrinsics:
        intrinsics = args.intrinsics.resolve()
    else:
        # 按优先级查找: work_dir/data/intrinsics.txt → config 指定路径
        candidates = [
            work_dir / "data" / "intrinsics.txt",
            work_dir / "intrinsics.txt",
        ]
        cfg_intrinsics = cfg_get(config, "camera", "intrinsics_file")
        if cfg_intrinsics:
            candidates.append(resolve_path(cfg_intrinsics, work_dir))
            candidates.append(resolve_path(cfg_intrinsics))
        for c in candidates:
            if c and c.exists():
                intrinsics = c
                break

    # ---- 格式检测 ----
    fmt = args.format if args.format else detect_format(raw_dir)

    # ep0005 = 0707 布局(深度侧按 0707 处理: bin_pc1/pc2) + 0622 风格 OdomPose
    #         (位姿侧按 0622 处理: 读取 roll/pitch)。其余格式 depth_fmt==pose_fmt==fmt。
    depth_fmt = "0707" if fmt == "ep0005" else fmt   # 用于 step2/3/3.5/4/7
    pose_fmt = "0622" if fmt == "ep0005" else fmt    # 用于 step5

    out_dir = args.output_dir or (DATASETS_DIR / dataset_name)

    log("=" * 60)
    log("iTOF -> 标准数据集预处理管线")
    log("=" * 60)
    log(f"  raw_dir:      {raw_dir}")
    log(f"  work_dir:     {work_dir}")
    log(f"  format:       {fmt}" + (f" (深度侧={depth_fmt}, 位姿侧={pose_fmt})" if fmt == "ep0005" else ""))
    log(f"  output:       {out_dir}")
    log(f"  intrinsics:   {intrinsics or '(未找到)'}")
    log(f"  camera_height: {'auto (SAM3)' if auto_camera_height else f'{camera_height}m'}")
    if auto_camera_height:
        log(f"  sam3_url:    {sam3_url}")
    log(f"  max_depth:    {max_depth}m")
    log(f"  model:        {model_path}")
    log(f"  device:       {device}")

    # 预检查
    if not args.export_only:
        if fmt == "0622":
            if not (raw_dir / "jpg_bin").is_dir():
                log(f"!! raw_dir 下未找到 jpg_bin/: {raw_dir}")
                return 1
            if not (raw_dir / "OdomPose.txt").exists():
                log(f"!! raw_dir 下未找到 OdomPose.txt: {raw_dir}")
                return 1
        elif fmt == "ep0005":
            if not (raw_dir / "pointcloud1").is_dir():
                log(f"!! ep0005 格式需要 pointcloud1/: {raw_dir}")
                return 1
            if not (raw_dir / "OdomPose.txt").exists():
                log(f"!! ep0005 格式需要 OdomPose.txt: {raw_dir}")
                return 1
        else:  # 0707
            if not (raw_dir / "pointcloud1").is_dir():
                log(f"!! 0707 格式需要 pointcloud1/: {raw_dir}")
                return 1
            if not (raw_dir / "odometry.txt").exists():
                log(f"!! 0707 格式需要 odometry.txt: {raw_dir}")
                return 1

    # 确保 intrinsics.txt 在 work_dir/data/ 中存在（LingBot 硬编码依赖）
    if intrinsics:
        data_dir = work_dir / "data"
        data_dir.mkdir(parents=True, exist_ok=True)
        ensure_intrinsics(data_dir, intrinsics)

    t_start = time.time()

    if not args.export_only:
        # Step 1-4: 数据预处理
        prep_steps = [
            lambda: step1_match_data(raw_dir, work_dir, fmt),
            lambda: step2_convert_depth(work_dir, depth_fmt),
            lambda: step3_fuse_depth(work_dir, depth_fmt),
            lambda: step3_5_filter_depth(work_dir, min_valid_depth, depth_fmt),
            lambda: step4_mask_depth(work_dir, max_depth, depth_fmt),
        ]
        for step_fn in prep_steps:
            if not step_fn():
                return 1

        # Step 4.5 (可选): SAM3 自动计算相机高度
        actual_height = camera_height
        if auto_camera_height:
            try:
                actual_height = step_auto_camera_height(work_dir, sam3_url, sample_ratio)
            except RuntimeError as e:
                log(f"  !! 自动计算失败: {e}")
                log(f"  !! 请手动指定 --camera_height 或在 config.yaml 中设置具体数值")
                return 1

        # Step 5: 位姿转换
        if not step5_odom_to_camera_pose(work_dir, actual_height, pose_fmt):
            return 1

        # 写入相机高度供导出使用
        data_dir = work_dir / "data"
        height_file = data_dir / "camera_height.txt"
        height_file.write_text(f"{actual_height:.6f}\n")
        log(f"  相机高度: {actual_height*1000:.1f}mm -> {height_file.name}")

        # Step 6: LingBot-Depth (可选)
        if args.skip_infer:
            log("=" * 60)
            log("Step 6: batch_infer_itof [SKIP] (--skip-infer)")
        else:
            if not step6_batch_infer(work_dir, model_path, device, filter_flying):
                return 1

    # Step 7: 导出
    if not step7_export(work_dir, dataset_name, intrinsics, args.output_dir, depth_fmt):
        return 1

    total = time.time() - t_start
    log(f"总耗时: {total:.1f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
