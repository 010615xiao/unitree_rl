#!/usr/bin/env python3
"""可视化对比 odom 转换前后的位姿（位置 + 方向箭头）"""

import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def load_odom_xy_yaw(path, fmt="0622"):
    """提取每帧的 (x, y, yaw)，单位 m / rad

    0622: tab-sep, cols 1/2/3 = x(mm)/y(mm)/yaw(rad)
    0707: space-sep, cols 6/7/8 = x(mm)/y(mm)/yaw(rad)
    """
    xs, ys, yaws = [], [], []
    sep = '\t' if fmt == '0622' else ' '
    min_parts = 6 if fmt == '0622' else 9
    xi, yi, yi_yaw = (1, 2, 3) if fmt == '0622' else (6, 7, 8)
    with open(path) as f:
        for line in f:
            parts = line.strip().split(sep)
            if len(parts) < min_parts:
                continue
            xs.append(float(parts[xi]) / 1000.0)
            ys.append(float(parts[yi]) / 1000.0)
            yaws.append(float(parts[yi_yaw]))
    return np.array(xs), np.array(ys), np.array(yaws)


def subsample(xs, ys, yaws, stride=5):
    """等间隔采样，避免箭头过密"""
    idx = np.arange(0, len(xs), stride)
    return xs[idx], ys[idx], yaws[idx], idx


def plot_comparison(xs_orig, ys_orig, yaws_orig,
                    xs_new, ys_new, yaws_new,
                    output_path):
    fig, axes = plt.subplots(1, 2, figsize=(20, 9))

    # ---- 左图: 原始位姿 ----
    ax = axes[0]
    ax.plot(xs_orig, ys_orig, 'b-', linewidth=0.8, alpha=0.6, label='trajectory')
    ax.plot(xs_orig[0], ys_orig[0], 'go', markersize=10, zorder=5, label='start')
    ax.plot(xs_orig[-1], ys_orig[-1], 'rs', markersize=10, zorder=5, label='end')

    # 方向箭头（每 stride 帧画一个）
    stride = max(1, len(xs_orig) // 60)
    xs_s, ys_s, yaws_s, idx_s = subsample(xs_orig, ys_orig, yaws_orig, stride)
    arrow_len = max(0.15, (xs_orig.max() - xs_orig.min()) * 0.015)
    for x, y, yaw in zip(xs_s, ys_s, yaws_s):
        dx = arrow_len * np.cos(yaw)
        dy = arrow_len * np.sin(yaw)
        ax.annotate('', xy=(x + dx, y + dy), xytext=(x, y),
                    arrowprops=dict(arrowstyle='->', color='orange', lw=1.2))

    ax.set_title('Before conversion (robot odom)', fontsize=14, fontweight='bold')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')
    ax.legend(loc='upper right')
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)

    # ---- 右图: 转换后位姿 ----
    ax = axes[1]
    ax.plot(xs_new, ys_new, 'b-', linewidth=0.8, alpha=0.6, label='trajectory')
    ax.plot(xs_new[0], ys_new[0], 'go', markersize=10, zorder=5, label='start')
    ax.plot(xs_new[-1], ys_new[-1], 'rs', markersize=10, zorder=5, label='end')

    xs_s2, ys_s2, yaws_s2, idx_s2 = subsample(xs_new, ys_new, yaws_new, stride)
    arrow_len2 = max(0.15, (xs_new.max() - xs_new.min()) * 0.015)
    for x, y, yaw in zip(xs_s2, ys_s2, yaws_s2):
        dx = arrow_len2 * np.cos(yaw)
        dy = arrow_len2 * np.sin(yaw)
        ax.annotate('', xy=(x + dx, y + dy), xytext=(x, y),
                    arrowprops=dict(arrowstyle='->', color='red', lw=1.2))

    ax.set_title('After conversion (camera pose)', fontsize=14, fontweight='bold')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')
    ax.legend(loc='upper right')
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)

    fig.suptitle('Odometry → Camera Pose Comparison\n(orange arrows = original yaw, red arrows = converted yaw)',
                 fontsize=13, y=1.01)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"Saved -> {output_path}")


def plot_yaw_comparison(yaws_orig, yaws_new, output_path):
    """yaw 角度随帧数变化对比"""
    fig, ax = plt.subplots(figsize=(14, 4))
    frames = np.arange(len(yaws_orig))
    ax.plot(frames, np.degrees(yaws_orig), 'b-', alpha=0.7, label='original yaw', linewidth=0.8)
    ax.plot(frames, np.degrees(yaws_new), 'r-', alpha=0.7, label='converted yaw', linewidth=0.8)
    ax.set_xlabel('Frame')
    ax.set_ylabel('Yaw (deg)')
    ax.set_title('Yaw angle comparison (before vs after conversion)')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"Saved -> {output_path}")


def plot_overlay(xs_orig, ys_orig, yaws_orig,
                 xs_new, ys_new, yaws_new,
                 output_path):
    """叠加图：同一坐标系下对比两条轨迹和方向"""
    fig, ax = plt.subplots(figsize=(12, 10))

    # 原始
    ax.plot(xs_orig, ys_orig, 'b-', linewidth=0.6, alpha=0.4, label='original trajectory')
    ax.plot(xs_orig[0], ys_orig[0], 'go', markersize=10, zorder=5)
    ax.plot(xs_orig[-1], ys_orig[-1], 'rs', markersize=10, zorder=5)

    # 转换后
    ax.plot(xs_new, ys_new, 'r-', linewidth=0.6, alpha=0.4, label='converted trajectory')
    ax.plot(xs_new[0], ys_new[0], 'g^', markersize=10, zorder=5)
    ax.plot(xs_new[-1], ys_new[-1], 'r^', markersize=10, zorder=5)

    # 方向箭头
    stride = max(1, len(xs_orig) // 50)
    arrow_len = 0.2

    xs_s1, ys_s1, yaws_s1, _ = subsample(xs_orig, ys_orig, yaws_orig, stride)
    for x, y, yaw in zip(xs_s1, ys_s1, yaws_s1):
        dx = arrow_len * np.cos(yaw)
        dy = arrow_len * np.sin(yaw)
        ax.annotate('', xy=(x + dx, y + dy), xytext=(x, y),
                    arrowprops=dict(arrowstyle='->', color='dodgerblue', lw=1.0, alpha=0.8))

    xs_s2, ys_s2, yaws_s2, _ = subsample(xs_new, ys_new, yaws_new, stride)
    for x, y, yaw in zip(xs_s2, ys_s2, yaws_s2):
        dx = arrow_len * np.cos(yaw)
        dy = arrow_len * np.sin(yaw)
        ax.annotate('', xy=(x + dx, y + dy), xytext=(x, y),
                    arrowprops=dict(arrowstyle='->', color='red', lw=1.0, alpha=0.8))

    # 用虚线连接对应帧的原始/转换位置
    connect_stride = max(1, len(xs_orig) // 20)
    for i in range(0, len(xs_orig), connect_stride):
        if i < len(xs_new):
            ax.plot([xs_orig[i], xs_new[i]], [ys_orig[i], ys_new[i]],
                    'k--', linewidth=0.4, alpha=0.4)

    ax.set_title('Overlay: Original (blue) vs Converted (red)\n'
                 'Dashed lines connect corresponding frames',
                 fontsize=13, fontweight='bold')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')
    ax.legend(loc='upper right')
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"Saved -> {output_path}")


def detect_format(path):
    """自动检测 odom 文件格式"""
    with open(path) as f:
        for line in f:
            if not line.strip():
                continue
            if '\t' in line:
                return "0622"
            return "0707"
    return "0707"


def main():
    import argparse
    parser = argparse.ArgumentParser(description="可视化对比 odom 转换前后的位姿")
    parser.add_argument("--format", choices=["0622", "0707"], default=None,
                        help="数据集格式 (默认: 自动检测)")
    args = parser.parse_args()

    orig_path = os.path.join(DATA_DIR, "odom_matched.txt")
    new_path = os.path.join(DATA_DIR, "odom_matched_camera.txt")
    fmt = args.format or detect_format(orig_path)
    print(f"Detected format: {fmt}")

    xs_orig, ys_orig, yaws_orig = load_odom_xy_yaw(orig_path, fmt)
    xs_new, ys_new, yaws_new = load_odom_xy_yaw(new_path, fmt)

    print(f"Original: {len(xs_orig)} frames")
    print(f"Converted: {len(xs_new)} frames")
    print(f"\nOriginal range: X[{xs_orig.min():.3f}, {xs_orig.max():.3f}] "
          f"Y[{ys_orig.min():.3f}, {ys_orig.max():.3f}]")
    print(f"Converted range: X[{xs_new.min():.3f}, {xs_new.max():.3f}] "
          f"Y[{ys_new.min():.3f}, {ys_new.max():.3f}]")

    out_dir = DATA_DIR
    # 1. 左右对比
    plot_comparison(xs_orig, ys_orig, yaws_orig,
                    xs_new, ys_new, yaws_new,
                    os.path.join(out_dir, "pose_compare_side_by_side.png"))
    # 2. yaw 角度对比
    plot_yaw_comparison(yaws_orig, yaws_new,
                        os.path.join(out_dir, "yaw_compare.png"))
    # 3. 叠加图
    plot_overlay(xs_orig, ys_orig, yaws_orig,
                 xs_new, ys_new, yaws_new,
                 os.path.join(out_dir, "pose_compare_overlay.png"))


if __name__ == "__main__":
    main()
