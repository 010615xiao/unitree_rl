#!/usr/bin/env python3
"""将 odom 转换前后的轨迹导出为 PLY 点云，并生成 3D 对比图"""

import os
import numpy as np

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def write_ply(path, points, colors=None, normals=None):
    """写入 PLY 点云文件 (ascii)，可选带法线(方向)和颜色"""
    n = len(points)
    has_color = colors is not None and len(colors) == n
    has_normal = normals is not None and len(normals) == n
    with open(path, 'w') as f:
        f.write("ply\n")
        f.write("format ascii 1.0\n")
        f.write(f"element vertex {n}\n")
        f.write("property float x\n")
        f.write("property float y\n")
        f.write("property float z\n")
        if has_normal:
            f.write("property float nx\n")
            f.write("property float ny\n")
            f.write("property float nz\n")
        if has_color:
            f.write("property uchar red\n")
            f.write("property uchar green\n")
            f.write("property uchar blue\n")
        f.write("end_header\n")
        for i in range(n):
            x, y, z = points[i]
            line = f"{x:.6f} {y:.6f} {z:.6f}"
            if has_normal:
                nx, ny, nz = normals[i]
                line += f" {nx:.6f} {ny:.6f} {nz:.6f}"
            if has_color:
                r, g, b = colors[i]
                line += f" {r} {g} {b}"
            f.write(line + "\n")
    print(f"PLY saved -> {path}  ({n} points"
          f"{', +normals' if has_normal else ''}"
          f"{', +color' if has_color else ''})")


def detect_odom_format(path) -> str:
    """自动检测 odom 文件格式: 0622 (tab分隔) 或 0707 (空格分隔)。"""
    with open(path) as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            return "0622" if "\t" in s else "0707"
    return "0707"


def load_odom_positions(path, fmt=None):
    """从 odom_matched.txt 提取 (x, y, 0) 位置和 yaw"""
    if fmt is None:
        fmt = detect_odom_format(path)
    sep = '\t' if fmt == '0622' else ' '
    xi, yi = (1, 2) if fmt == '0622' else (6, 7)
    yaw_i = 3 if fmt == '0622' else 8
    min_parts = 6 if fmt == '0622' else 9
    pts, yaws = [], []
    with open(path) as f:
        for line in f:
            parts = line.strip().split(sep)
            if len(parts) < min_parts:
                continue
            x = float(parts[xi]) / 1000.0
            y = float(parts[yi]) / 1000.0
            pts.append([x, y, 0.0])
            yaws.append(float(parts[yaw_i]))
    return np.array(pts), np.array(yaws)


def load_camera_positions(path):
    """从 rgb_camera_poses.txt 提取相机位置 (m03, m13, m23) 和 yaw"""
    pts, yaws = [], []
    with open(path) as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.strip().split('\t')
            if len(parts) < 17:
                continue
            x = float(parts[5])
            y = float(parts[9])
            z = float(parts[13])
            pts.append([x, y, z])
            # yaw from optical axis (+Z): arctan2(m12, m02)
            m02 = float(parts[4])
            m12 = float(parts[8])
            yaws.append(np.arctan2(m12, m02))
    return np.array(pts), np.array(yaws)


def _draw_3d_arrows(ax, pts, yaws, stride, arrow_len, color):
    """每隔 stride 帧在 3D 图上画方向箭头"""
    idx = np.arange(0, len(pts), stride)
    xs, ys, zs = pts[idx, 0], pts[idx, 1], pts[idx, 2]
    u = arrow_len * np.cos(yaws[idx])
    v = arrow_len * np.sin(yaws[idx])
    w = np.zeros_like(u)
    ax.quiver(xs, ys, zs, u, v, w,
              length=1.0, normalize=True,
              color=color, alpha=0.8, linewidth=0.8,
              arrow_length_ratio=0.3)


def plot_3d_compare(pts_odom, pts_cam, yaws_odom, yaws_cam, output_path):
    """3D 对比图 (带方向箭头)"""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(16, 7))

    # 左图: 原始轨迹
    ax1 = fig.add_subplot(121, projection='3d')
    ax1.plot(pts_odom[:, 0], pts_odom[:, 1], pts_odom[:, 2],
             'b-', linewidth=0.5, alpha=0.7)
    ax1.scatter(pts_odom[0, 0], pts_odom[0, 1], pts_odom[0, 2],
                c='green', s=60, zorder=5, label='start')
    ax1.scatter(pts_odom[-1, 0], pts_odom[-1, 1], pts_odom[-1, 2],
                c='red', s=60, zorder=5, label='end')
    stride1 = max(1, len(pts_odom) // 50)
    arrow_len1 = max(0.15, (pts_odom[:, 0].max() - pts_odom[:, 0].min()) * 0.02)
    _draw_3d_arrows(ax1, pts_odom, yaws_odom, stride1, arrow_len1, 'orange')
    ax1.set_title('Before conversion (robot odom)', fontweight='bold')
    ax1.set_xlabel('X (m)')
    ax1.set_ylabel('Y (m)')
    ax1.set_zlabel('Z (m)')
    ax1.legend()

    # 右图: 转换后轨迹
    ax2 = fig.add_subplot(122, projection='3d')
    ax2.plot(pts_cam[:, 0], pts_cam[:, 1], pts_cam[:, 2],
             'r-', linewidth=0.5, alpha=0.7)
    ax2.scatter(pts_cam[0, 0], pts_cam[0, 1], pts_cam[0, 2],
                c='green', s=60, zorder=5, label='start')
    ax2.scatter(pts_cam[-1, 0], pts_cam[-1, 1], pts_cam[-1, 2],
                c='red', s=60, zorder=5, label='end')
    stride2 = max(1, len(pts_cam) // 50)
    arrow_len2 = max(0.15, (pts_cam[:, 0].max() - pts_cam[:, 0].min()) * 0.02)
    _draw_3d_arrows(ax2, pts_cam, yaws_cam, stride2, arrow_len2, 'red')
    ax2.set_title('After conversion (camera pose)', fontweight='bold')
    ax2.set_xlabel('X (m)')
    ax2.set_ylabel('Y (m)')
    ax2.set_zlabel('Z (m)')
    ax2.legend()

    fig.suptitle('Trajectory Comparison (arrows = moving direction)', fontsize=14, y=1.01)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"3D plot saved -> {output_path}")


def plot_overlay_3d(pts_odom, pts_cam, yaws_odom, yaws_cam, output_path):
    """叠加 3D 图 (带方向箭头)"""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    ax.plot(pts_odom[:, 0], pts_odom[:, 1], pts_odom[:, 2],
            'b-', linewidth=0.8, alpha=0.6, label='robot odom')
    ax.scatter(pts_odom[0, 0], pts_odom[0, 1], pts_odom[0, 2], c='cyan', s=50, zorder=5)
    ax.scatter(pts_odom[-1, 0], pts_odom[-1, 1], pts_odom[-1, 2], c='blue', s=50, zorder=5)

    ax.plot(pts_cam[:, 0], pts_cam[:, 1], pts_cam[:, 2],
            'r-', linewidth=0.8, alpha=0.6, label='camera pose')
    ax.scatter(pts_cam[0, 0], pts_cam[0, 1], pts_cam[0, 2], c='orange', s=50, zorder=5)
    ax.scatter(pts_cam[-1, 0], pts_cam[-1, 1], pts_cam[-1, 2], c='red', s=50, zorder=5)

    # 每隔 N 帧连线
    conn_stride = max(1, len(pts_odom) // 30)
    n = min(len(pts_odom), len(pts_cam))
    for i in range(0, n, conn_stride):
        ax.plot([pts_odom[i, 0], pts_cam[i, 0]],
                [pts_odom[i, 1], pts_cam[i, 1]],
                [pts_odom[i, 2], pts_cam[i, 2]],
                'k--', linewidth=0.3, alpha=0.4)

    # 方向箭头
    arrow_stride = max(1, len(pts_odom) // 40)
    arrow_len = max(0.15, (pts_odom[:, 0].max() - pts_odom[:, 0].min()) * 0.015)
    _draw_3d_arrows(ax, pts_odom, yaws_odom, arrow_stride, arrow_len, 'dodgerblue')
    _draw_3d_arrows(ax, pts_cam, yaws_cam, arrow_stride, arrow_len, 'red')

    ax.set_title('Overlay: Robot Odom (blue) vs Camera Pose (red)\narrows = moving direction',
                 fontweight='bold')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')
    ax.set_zlabel('Z (m)')
    ax.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"Overlay 3D plot saved -> {output_path}")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="轨迹转点云 (PLY) + 3D 对比图")
    parser.add_argument("--format", choices=["0622", "0707"], default=None,
                        help="数据集格式 (默认自动检测)")
    parser.add_argument("--odom", default=None, help="odom_matched.txt 路径 (默认: data/odom_matched.txt)")
    parser.add_argument("--poses", default=None, help="rgb_camera_poses.txt 路径 (默认: data/rgb_camera_poses.txt)")
    parser.add_argument("--outdir", default=None, help="输出目录 (默认: data/)")
    args = parser.parse_args()
    fmt = args.format

    data_dir = DATA_DIR
    odom_path = args.odom or os.path.join(data_dir, "odom_matched.txt")
    poses_path = args.poses or os.path.join(data_dir, "rgb_camera_poses.txt")
    out_dir = args.outdir or data_dir

    os.makedirs(out_dir, exist_ok=True)

    # 加载原始轨迹
    pts_odom, yaws_odom = load_odom_positions(odom_path, fmt)
    print(f"Robot odom: {len(pts_odom)} frames")
    if len(pts_odom) == 0:
        print(f"  !! 无法解析 odom 文件: {odom_path}")
        return
    print(f"  X[{pts_odom[:, 0].min():.3f}, {pts_odom[:, 0].max():.3f}] "
          f"Y[{pts_odom[:, 1].min():.3f}, {pts_odom[:, 1].max():.3f}]")
    print(f"  yaw range: [{np.degrees(yaws_odom.min()):.1f}, {np.degrees(yaws_odom.max()):.1f}] deg")

    # 加载转换后轨迹
    pts_cam, yaws_cam = load_camera_positions(poses_path)
    print(f"Camera pose: {len(pts_cam)} frames")
    print(f"  X[{pts_cam[:, 0].min():.3f}, {pts_cam[:, 0].max():.3f}] "
          f"Y[{pts_cam[:, 1].min():.3f}, {pts_cam[:, 1].max():.3f}] "
          f"Z[{pts_cam[:, 2].min():.3f}, {pts_cam[:, 2].max():.3f}]")
    print(f"  yaw range: [{np.degrees(yaws_cam.min()):.1f}, {np.degrees(yaws_cam.max()):.1f}] deg")

    # 生成颜色: 按帧索引渐变
    n_odom = len(pts_odom)
    n_cam = len(pts_cam)
    colors_odom = np.zeros((n_odom, 3), dtype=np.uint8)
    colors_odom[:, 0] = np.linspace(0, 255, n_odom).astype(np.uint8)   # R: 0→255
    colors_odom[:, 2] = np.linspace(255, 0, n_odom).astype(np.uint8)   # B: 255→0

    colors_cam = np.zeros((n_cam, 3), dtype=np.uint8)
    colors_cam[:, 0] = np.linspace(255, 0, n_cam).astype(np.uint8)     # R: 255→0
    colors_cam[:, 2] = np.linspace(0, 255, n_cam).astype(np.uint8)     # B: 0→255

    # yaw → 法线方向 (nx, ny, 0)
    normals_odom = np.column_stack([np.cos(yaws_odom), np.sin(yaws_odom),
                                     np.zeros_like(yaws_odom)])
    normals_cam = np.column_stack([np.cos(yaws_cam), np.sin(yaws_cam),
                                    np.zeros_like(yaws_cam)])

    # 导出 PLY (带法线=方向)
    write_ply(os.path.join(out_dir, "trajectory_odom.ply"), pts_odom, colors_odom, normals_odom)
    write_ply(os.path.join(out_dir, "trajectory_camera.ply"), pts_cam, colors_cam, normals_cam)

    # 合并 PLY (方便一起查看)
    pts_all = np.vstack([pts_odom, pts_cam])
    colors_all = np.vstack([colors_odom, colors_cam])
    normals_all = np.vstack([normals_odom, normals_cam])
    write_ply(os.path.join(out_dir, "trajectory_both.ply"), pts_all, colors_all, normals_all)

    # 3D 对比图
    plot_3d_compare(pts_odom, pts_cam, yaws_odom, yaws_cam,
                    os.path.join(out_dir, "trajectory_3d_compare.png"))
    plot_overlay_3d(pts_odom, pts_cam, yaws_odom, yaws_cam,
                    os.path.join(out_dir, "trajectory_3d_overlay.png"))

    print("\nDone! Files:")
    print(f"  {out_dir}/trajectory_odom.ply      — 转换前 (robot odom)")
    print(f"  {out_dir}/trajectory_camera.ply     — 转换后 (camera pose)")
    print(f"  {out_dir}/trajectory_both.ply       — 合并 (蓝→红=时间渐变)")
    print(f"  {out_dir}/trajectory_3d_compare.png — 3D 左右对比图")
    print(f"  {out_dir}/trajectory_3d_overlay.png — 3D 叠加图")


if __name__ == "__main__":
    main()
