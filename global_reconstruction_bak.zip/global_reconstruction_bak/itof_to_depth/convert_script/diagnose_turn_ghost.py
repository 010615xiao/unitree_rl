#!/usr/bin/env python3
"""诊断转弯重影: 量化相邻帧位姿一致性残差, 并测试挂装方向假设的敏感性。

重影本质: 相邻两帧位姿 T_wc_i, T_wc_j 对同一静态世界点 P 给出不同世界坐标。
本脚本用 itof_0622 实际 odom 重建位姿 (复刻 odom_to_camera_pose 逻辑),
取每帧相机正前方 1m 处的"墙点", 检查相邻帧能否把它对齐 -> 残差即重影量。

输出:
  1. 直行 vs 转弯段的拼接残差 (mm) -> 证明转弯处残差骤增。
  2. 四种挂装方向 (前/后 × 左/右) 的残差对比 -> 判断哪个方向假设更自洽。
     注意: 此残差主要反映 odom 自洽性, 不能单独证明挂装物理真值 (见下)。

局限 (重要):
  相机轨迹完全由 odom 公式推出, 没有独立于公式的相机测量, 所以残差小只能
  说明模型自洽, 不能证明挂装方向对应物理现实。要验证物理挂装需用真实点云
  叠加 (build_pointcloud.py) 看墙地是否贴合。
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from odom_to_camera_pose import (  # noqa: E402
    R_CAM2ROBOT, TFC_RAW, TOC_RAW,
    invert_transform, robot_to_world_rotmat,
)


def calibration_raw_translation():
    Tfc = TFC_RAW.copy(); Toc = TOC_RAW.copy()
    Tfc[:3, 3] /= 1000.0; Toc[:3, 3] /= 1000.0
    Tfo = Tfc @ invert_transform(Toc)
    return invert_transform(Tfo)[:3, 3].copy()


def build_T_body_camera(fx_sign: int, fy_sign: int, raw_t: np.ndarray):
    """fx_sign/fy_sign: +1 或 -1, 对标定链平移 x/y 加方向 (mount 先验)。"""
    T = np.eye(4)
    T[:3, :3] = R_CAM2ROBOT
    T[0, 3] = fx_sign * abs(raw_t[0])
    T[1, 3] = fy_sign * abs(raw_t[1])
    T[2, 3] = raw_t[2]
    return T


def load_odom(path):
    xs, ys, yaws, rolls, pitches = [], [], [], [], []
    with open(path) as f:
        for line in f:
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 6:
                continue
            xs.append(float(parts[1]) / 1000.0)
            ys.append(float(parts[2]) / 1000.0)
            yaws.append(float(parts[3]))
            rolls.append(float(parts[4]))
            pitches.append(float(parts[5]))
    return (np.array(xs), np.array(ys), np.array(yaws),
            np.array(rolls), np.array(pitches))


def make_T_wc(x, y, yaw, roll, pitch, height, T_bc):
    R_wb = robot_to_world_rotmat(yaw, pitch, roll)
    T = np.eye(4)
    T[:3, :3] = R_wb @ T_bc[:3, :3]
    T[:3, 3] = R_wb @ T_bc[:3, 3] + np.array([x, y, 0.0])
    T[2, 3] = height
    return T


def resid_for_mount(xs, ys, yaws, rolls, pitches, height, T_bc,
                    idx_list, wall_dist=1.0):
    """计算相邻帧 (按 idx_list 顺序) 对 1m 墙点的拼接残差 (mm)。"""
    resids = []
    for i in idx_list:
        j = i + 1
        if j >= len(xs):
            continue
        Twi = make_T_wc(xs[i], ys[i], yaws[i], rolls[i], pitches[i], height, T_bc)
        Twj = make_T_wc(xs[j], ys[j], yaws[j], rolls[j], pitches[j], height, T_bc)
        P = Twi[:3, 3] + Twi[:3, 2] * wall_dist
        P_cam_j = invert_transform(Twj)[:3, :3] @ (P - Twj[:3, 3])
        resids.append(np.linalg.norm(P_cam_j - np.array([0, 0, wall_dist])) * 1000)
    return np.array(resids)


def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--odom", type=Path, default=Path("../itof_0622/OdomPose.txt"))
    p.add_argument("--camera-height", type=float, default=0.065)
    p.add_argument("--wall-dist", type=float, default=1.0, help="墙点距离 (m)")
    args = p.parse_args()

    xs, ys, yaws, rolls, pitches = load_odom(args.odom)
    n = len(xs)
    print(f"加载 {n} 帧 odom")

    uw = np.unwrap(yaws)
    dyaw = np.diff(uw)
    body_step = np.hypot(np.diff(xs), np.diff(ys))

    # 转弯 = 30 帧窗口累计 |dyaw| 大; 直行 = 累计小且 body 在动
    win = 30
    acc = np.convolve(np.abs(dyaw), np.ones(win), mode="valid")
    acc_full = np.full(len(dyaw), np.nan)
    acc_full[win // 2:win // 2 + len(acc)] = acc
    turn = np.nan_to_num(acc_full > np.nanpercentile(acc_full, 95)).astype(bool)
    straight = np.nan_to_num(
        (acc_full < np.nanpercentile(acc_full, 30)) & (body_step > 1e-4)
    ).astype(bool)
    print(f"转弯 {turn.sum()} 帧, 直行 {straight.sum()} 帧")

    raw_t = calibration_raw_translation()
    h = args.camera_height
    T_bc = build_T_body_camera(+1, +1, raw_t)

    # 1. 当前挂装 (前左) 下直行/转弯残差
    turn_idx = np.where(turn)[0]
    straight_idx = np.where(straight)[0]
    # 采样以加速
    t_sample = turn_idx[np.linspace(0, len(turn_idx) - 1, min(500, len(turn_idx)), dtype=int)]
    s_sample = straight_idx[np.linspace(0, len(straight_idx) - 1, min(500, len(straight_idx)), dtype=int)]

    r_turn = resid_for_mount(xs, ys, yaws, rolls, pitches, h, T_bc, t_sample, args.wall_dist)
    r_straight = resid_for_mount(xs, ys, yaws, rolls, pitches, h, T_bc, s_sample, args.wall_dist)

    print(f"\n=== 当前挂装 (前左) 拼接残差 @ {args.wall_dist}m ===")
    print(f"  直行: mean={r_straight.mean():.2f}mm, p95={np.percentile(r_straight,95):.2f}mm")
    print(f"  转弯: mean={r_turn.mean():.2f}mm, p95={np.percentile(r_turn,95):.2f}mm")
    ratio = r_turn.mean() / max(r_straight.mean(), 1e-6)
    print(f"  转弯/直行 残差比: {ratio:.2f}x")
    if ratio > 2:
        print(f"  -> 转弯残差显著放大, 重影主要出现在转弯处")

    # 2. 四种挂装方向敏感性
    print(f"\n=== 挂装方向敏感性 (转弯段残差) ===")
    print(f"  {'方向':6} {'x(mm)':>8} {'y(mm)':>8} {'resid_mean':>12} {'resid_p95':>12}")
    for fx, fy in [(+1,+1),(+1,-1),(-1,+1),(-1,-1)]:
        Tt = build_T_body_camera(fx, fy, raw_t)
        r = resid_for_mount(xs, ys, yaws, rolls, pitches, h, Tt, t_sample, args.wall_dist)
        label = f"{'前' if fx>0 else '后'}{'左' if fy>0 else '右'}"
        print(f"  {label:6} {fx*abs(raw_t[0])*1000:>+8.1f} {fy*abs(raw_t[1])*1000:>+8.1f} "
              f"{r.mean():>10.2f}mm {np.percentile(r,95):>10.2f}mm")

    print(f"\n=== 局限提示 ===")
    print(f"  残差小只说明 odom+位姿公式自洽, 不能证明挂装方向是物理真值。")
    print(f"  验证物理挂装需用 build_pointcloud.py 叠真实点云看墙地是否贴合。")


if __name__ == "__main__":
    main()
