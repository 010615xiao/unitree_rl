#!/usr/bin/env python3
"""将 depth_pc1_rgb、depth_pc2_rgb、jpg 横向拼接为一张图，保存到 vim_compare/"""

import argparse
from pathlib import Path

import numpy as np
from PIL import Image


def main():
    parser = argparse.ArgumentParser(description="拼接 pc1_rgb + pc2_rgb + jpg 为对比图")
    parser.add_argument("--data_dir", type=Path, required=True, help="data 目录")
    parser.add_argument("--output_dir", type=Path, default=None, help="输出目录 (默认: data_dir/vim_compare)")
    args = parser.parse_args()

    data_dir = args.data_dir
    out_dir = args.output_dir or (data_dir / "vim_compare")
    out_dir.mkdir(parents=True, exist_ok=True)

    pc1_dir = data_dir / "depth_pc1_rgb"
    pc2_dir = data_dir / "depth_pc2_rgb"
    jpg_dir = data_dir / "jpg"

    pc1_files = sorted(pc1_dir.glob("*.png"))
    print(f"pc1: {len(pc1_files)}, pc2: {len(list(pc2_dir.glob('*.png')))}, jpg: {len(list(jpg_dir.glob('*.jpg')))}")

    for pc1_path in pc1_files:
        name = pc1_path.stem
        pc2_path = pc2_dir / f"{name}.png"
        jpg_path = jpg_dir / f"{name}.jpg"

        if not pc2_path.exists() or not jpg_path.exists():
            continue

        im1 = np.array(Image.open(pc1_path).convert("RGB"))
        im2 = np.array(Image.open(pc2_path).convert("RGB"))
        im3 = np.array(Image.open(jpg_path).convert("RGB"))

        h = max(im1.shape[0], im2.shape[0], im3.shape[0])

        def resize_keep_ratio(im, target_h):
            ratio = target_h / im.shape[0]
            new_w = int(im.shape[1] * ratio)
            return np.array(Image.fromarray(im).resize((new_w, target_h)))

        im1 = resize_keep_ratio(im1, h)
        im2 = resize_keep_ratio(im2, h)
        im3 = resize_keep_ratio(im3, h)

        stitched = np.hstack([im1, im2, im3])
        Image.fromarray(stitched).save(out_dir / f"{name}.png")

    print(f"Saved to {out_dir}")


if __name__ == "__main__":
    main()
