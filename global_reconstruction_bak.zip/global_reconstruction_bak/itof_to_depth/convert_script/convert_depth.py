import argparse
import numpy as np
import cv2
import os
import glob
from tqdm import tqdm


def convert_bin_dir(bin_dir, output_dir, output_rgb_dir):
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(output_rgb_dir, exist_ok=True)

    bin_files = sorted(glob.glob(os.path.join(bin_dir, '*.bin')))
    total = len(bin_files)
    print(f"找到 {total} 个bin文件")

    skipped = 0
    pbar = tqdm(bin_files, desc="转换", unit="file", ncols=100)
    for bin_file in pbar:
        basename = os.path.splitext(os.path.basename(bin_file))[0]
        npy_path = os.path.join(output_dir, basename + '.npy')

        with open(bin_file, 'rb') as f:
            data = np.fromfile(f, dtype=np.int16)

        depth_map = data.reshape(352, 640).astype(np.float32)

        # 无效值 5000 -> 0
        depth_map[depth_map == 5000] = 0

        # 保存npy
        np.save(npy_path, depth_map)

        # 归一化生成可视化png
        valid_mask = depth_map > 0
        if np.any(valid_mask):
            valid_min = float(depth_map[valid_mask].min())
            valid_max = float(depth_map[valid_mask].max())

            depth_vis = np.zeros_like(depth_map, dtype=np.uint8)
            depth_vis[valid_mask] = ((depth_map[valid_mask] - valid_min) / (valid_max - valid_min + 1e-8) * 255).astype(np.uint8)

            png_path = os.path.join(output_dir, basename + '.png')
            cv2.imwrite(png_path, depth_vis)

            depth_colored = cv2.applyColorMap(depth_vis, cv2.COLORMAP_JET)
            depth_colored[~valid_mask] = [255, 255, 255]
            rgb_path = os.path.join(output_rgb_dir, basename + '.png')
            cv2.imwrite(rgb_path, depth_colored)

            pbar.set_postfix(range=f"{valid_min:.0f}-{valid_max:.0f}mm")
        else:
            skipped += 1
            depth_vis = np.zeros((352, 640), dtype=np.uint8)
            png_path = os.path.join(output_dir, basename + '.png')
            cv2.imwrite(png_path, depth_vis)

            depth_colored = np.ones((352, 640, 3), dtype=np.uint8) * 255
            rgb_path = os.path.join(output_rgb_dir, basename + '.png')
            cv2.imwrite(rgb_path, depth_colored)

            pbar.set_postfix(range="无有效值")

    pbar.close()
    print(f"完成: {total} 帧, {skipped} 帧无有效深度")


def main():
    parser = argparse.ArgumentParser(description="bin深度图转换 (int16 -> float32 npy + 可视化png)")
    parser.add_argument("--input", "-i", required=True, help="输入bin文件夹路径")
    parser.add_argument("--output", "-o", required=True, help="输出深度图文件夹路径")
    parser.add_argument("--output_rgb", default=None, help="输出伪彩色可视化文件夹路径 (默认: output_dir_rgb)")
    args = parser.parse_args()

    output_rgb_dir = args.output_rgb or (args.output.rstrip('/') + '_rgb')

    print(f"输入: {args.input}")
    print(f"输出: {args.output}")
    print(f"可视化: {output_rgb_dir}")
    print()

    convert_bin_dir(args.input, args.output, output_rgb_dir)

    print("\n处理完成！")


if __name__ == "__main__":
    main()
