#!/usr/bin/env python3
"""itof_test: bin转depth_rgb + 与jpg拼接"""

import argparse
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image


def parse_timestamp(name: str) -> float:
    """从文件名提取时间戳 (秒)"""
    # itof_output_13_15_37_38_122 或 13_15_37_38_827
    parts = name.split("_")
    # 找到数字部分 (跳过前缀)
    nums = [int(p) for p in parts if p.isdigit()]
    if len(nums) >= 5:
        h, m, s, ms_hi, ms_lo = nums[-5], nums[-4], nums[-3], nums[-2], nums[-1]
    else:
        h, m, s, ms_hi, ms_lo = 0, 0, 0, 0, 0
    return h * 3600 + m * 60 + s + ms_hi / 100 + ms_lo / 10000


def main():
    parser = argparse.ArgumentParser(description="itof_test bin转depth_rgb + 拼接jpg")
    parser.add_argument("--data_dir", type=Path, required=True, help="itof_test 目录")
    parser.add_argument("--output_dir", type=Path, default=None, help="输出目录 (默认: data_dir/vim_compare)")
    args = parser.parse_args()

    data_dir = args.data_dir
    out_dir = args.output_dir or (data_dir / "vim_compare")
    out_dir.mkdir(parents=True, exist_ok=True)

    # Step 1: bin -> depth_rgb
    bin_dir = data_dir
    depth_npy_dir = data_dir / "depth_npy"
    depth_rgb_dir = data_dir / "depth_rgb"

    print("Step 1: 转换 bin -> depth_rgb")
    subprocess.run([
        sys.executable, str(Path(__file__).parent / "convert_depth.py"),
        "-i", str(bin_dir),
        "-o", str(depth_npy_dir),
        "--output_rgb", str(depth_rgb_dir)
    ], check=True)

    # Step 2: 按顺序配对 (2 bin : 1 jpg)
    print("\nStep 2: 按顺序配对 (2 bin : 1 jpg)")
    bin_files = sorted(depth_rgb_dir.glob("*.png"))
    jpg_files = sorted(data_dir.glob("seg_input_*.jpg"))

    print(f"  depth_rgb: {len(bin_files)}, jpg: {len(jpg_files)}")

    triples = []
    for i, jpg_path in enumerate(jpg_files):
        b1 = bin_files[i * 2]
        b2 = bin_files[i * 2 + 1]
        triples.append((b1, b2, jpg_path))

    print(f"  配对: {len(triples)} 组")

    # Step 3: 拼接 (bin1 + bin2 + jpg)
    print("\nStep 3: 拼接")
    for b1, b2, jpg_path in triples:
        im1 = np.array(Image.open(b1).convert("RGB"))
        im2 = np.array(Image.open(b2).convert("RGB"))
        im3 = np.array(Image.open(jpg_path).convert("RGB"))

        h = max(im1.shape[0], im2.shape[0], im3.shape[0])
        def resize_h(im, target_h):
            ratio = target_h / im.shape[0]
            return np.array(Image.fromarray(im).resize((int(im.shape[1] * ratio), target_h)))

        im1 = resize_h(im1, h)
        im2 = resize_h(im2, h)
        im3 = resize_h(im3, h)

        stitched = np.hstack([im1, im2, im3])
        out_name = jpg_path.stem + ".png"
        Image.fromarray(stitched).save(out_dir / out_name)

    print(f"\n完成 -> {out_dir} ({len(triples)} 张)")


if __name__ == "__main__":
    main()
