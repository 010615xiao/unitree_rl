#!/usr/bin/env python3
"""从实际 odom 数据反推 RGB 相机相对机器人 body 的挂装位置 (运动学实证)。

原理 (完全不依赖 mount 先验, 也不依赖标定链平移符号):
  - 机器人 odom 给出 body 原点在世界的位姿 T_world_body (t_body, R_world_body)。
  - 相机位姿 T_world_camera 由 (脚本当前实现) = T_world_body @ T_body_camera 给出,
    即相机中心 = body 原点 + R_world_body @ t_mount  (t_mount 为 body 系下挂装平移)。
  - 因此对任意一帧:  t_mount = R_world_body^T @ (t_camera - t_body)
    这个 t_mount 在所有帧上应当是同一个常量 (与 yaw 无关)。
  - 若相机在前左, 则 t_mount 的 x>0 (前), y>0 (左), 且各帧方差应极小。

本脚本:
  1. 用 odom_to_camera_pose 的标定链重建 T_body_camera (不应用 mount 先验,
     即不强制 abs() 取符号), 再重建相机中心轨迹。
  2. 同时直接从 odom 取 body 原点轨迹。
  3. 逐帧反算 t_mount = R_wb^T (t_cam - t_body), 统计 x/y/z 分布。
  4. 额外: 用纯最小二乘从 (t_cam - t_body) 与 R_world_body 直接拟合 t_mount,
     不经过标定链, 作为交叉验证。

判据:
  - 若 t_mount 的 mean.x>0 且 mean.y>0 -> 相机在 body 前左 (与默认假设一致)。
  - 若 std 极小 -> 相机相对 body 刚性固定 (模型自洽)。
  - 若 mean.x<0 或 mean.y<0 -> 假设错误, 需翻转 mount_forward / mount_side。
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

# 复用 odom_to_camera_pose.py 的核心函数, 避免逻辑分叉
SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
from odom_to_camera_pose import (  # noqa: E402
    TFC_RAW, TOC_RAW, R_CAM2ROBOT,
    invert_transform, robot_to_world_rotmat,
)


def build_T_body_camera_no_prior() -> np.ndarray:
    """标定链推导 T_body_camera, 但保留平移原始符号 (不应用 mount 先验)。

    与 odom_to_camera_pose.camera_to_body_transform 的区别:
    后者对 x/y 取 abs() 并按 mount_forward/mount_side 重新加符号; 本函数不这样做,
    以便观察标定链本身给出的挂装方向。
    """
    Tfc = TFC_RAW.copy()
    Toc = TOC_RAW.copy()
    Tfc[:3, 3] /= 1000.0  # mm -> m
    Toc[:3, 3] /= 1000.0

    Tfo = Tfc @ invert_transform(Toc)       # body -> optical
    T_calib = invert_transform(Tfo)          # optical -> body (标定原值)
    raw_t = T_calib[:3, 3].copy()

    T_body_camera = np.eye(4, dtype=np.float64)
    T_body_camera[:3, :3] = R_CAM2ROBOT
    T_body_camera[:3, 3] = raw_t             # 保留原符号
    return T_body_camera, raw_t


def load_odom_0622(path: Path):
    """读 0622 OdomPose.txt, 返回 (names, x_m, y_m, yaw, roll, pitch) 数组。"""
    xs, ys, yaws, rolls, pitches, names = [], [], [], [], [], []
    with open(path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) < 6:
                continue
            names.append(parts[0])
            xs.append(float(parts[1]) / 1000.0)
            ys.append(float(parts[2]) / 1000.0)
            yaws.append(float(parts[3]))
            rolls.append(float(parts[4]))
            pitches.append(float(parts[5]))
    return (names, np.array(xs), np.array(ys), np.array(yaws),
            np.array(rolls), np.array(pitches))


def main():
    import argparse
    parser = argparse.ArgumentParser(description="从实际 odom 反推相机挂装位置")
    parser.add_argument("--odom", type=Path, required=True,
                        help="0622 格式 odom 文件 (OdomPose.txt 或 odom_matched.txt)")
    parser.add_argument("--camera-height", type=float, default=0.065,
                        help="相机高度 m (仅影响 z, 不影响 x/y 反推)")
    parser.add_argument("--max-frames", type=int, default=20000,
                        help="最多分析帧数 (均匀采样, 默认 20000)")
    args = parser.parse_args()

    names, xs, ys, yaws, rolls, pitches = load_odom_0622(args.odom)
    n = len(xs)
    print(f"加载 {n} 帧 odom: {args.odom}")
    if n == 0:
        print("!! 无数据")
        return

    # 均匀采样
    if n > args.max_frames:
        idx = np.linspace(0, n - 1, args.max_frames, dtype=int)
        xs, ys, yaws, rolls, pitches = (
            xs[idx], ys[idx], yaws[idx], rolls[idx], pitches[idx])
        print(f"均匀采样 {args.max_frames}/{n} 帧分析")
        n = len(xs)

    T_body_camera, raw_t = build_T_body_camera_no_prior()
    print(f"\n=== 标定链原值 (未应用 mount 先验) ===")
    print(f"  raw_translation: x={raw_t[0]:+.4f}m, y={raw_t[1]:+.4f}m, z={raw_t[2]:+.4f}m")
    print(f"  R_CAM2ROBOT = \n{R_CAM2ROBOT}")
    print(f"  -> T_body_camera 平移 = {T_body_camera[:3, 3]}")

    # 逐帧重建 body 原点 与 相机中心, 反推 t_mount
    t_mount_frames = []      # 用标定链 T_body_camera 重建
    t_body_xy = np.stack([xs, ys], axis=1)   # body 原点 xy (z=0)
    t_cam_xy = np.zeros((n, 2))

    R_wb_list = []
    cam_minus_body = []

    h = args.camera_height
    for i in range(n):
        R_wb = robot_to_world_rotmat(yaws[i], pitches[i], rolls[i])
        # body 原点世界坐标
        t_body = np.array([xs[i], ys[i], 0.0])
        # 相机中心世界坐标 (用标定链 T_body_camera 重建, 高度被覆盖为 h)
        T_wc = np.eye(4)
        T_wc[:3, :3] = R_wb @ T_body_camera[:3, :3]
        t_cam = R_wb @ T_body_camera[:3, 3] + t_body
        t_cam[2] = h
        t_cam_xy[i] = t_cam[:2]

        # 反推: t_mount = R_wb^T (t_cam - t_body)
        t_mount = R_wb.T @ (t_cam - t_body)
        t_mount_frames.append(t_mount)

        R_wb_list.append(R_wb)
        cam_minus_body.append(t_cam - t_body)

    t_mount_frames = np.array(t_mount_frames)  # (n, 3)
    R_wb_arr = np.array(R_wb_list)             # (n, 3, 3)
    cmb = np.array(cam_minus_body)             # (n, 3)

    print(f"\n=== 方法1: 用标定链 T_body_camera 重建相机, 反推 t_mount ===")
    print(f"  t_mount mean: x={t_mount_frames[:,0].mean():+.4f}m, "
          f"y={t_mount_frames[:,1].mean():+.4f}m, z={t_mount_frames[:,2].mean():+.4f}m")
    print(f"  t_mount std : x={t_mount_frames[:,0].std():.4f}m, "
          f"y={t_mount_frames[:,1].std():.4f}m, z={t_mount_frames[:,2].std():.4f}m")
    print(f"  t_mount x range: [{t_mount_frames[:,0].min():+.4f}, {t_mount_frames[:,0].max():+.4f}]")
    print(f"  t_mount y range: [{t_mount_frames[:,1].min():+.4f}, {t_mount_frames[:,1].max():+.4f}]")

    # 方法2: 纯最小二乘拟合 t_mount, 不经标定链
    # 关系: t_cam - t_body = R_wb @ t_mount  =>  对每个轴: cmb = R_wb @ t_mount
    # 堆叠成 A t_mount = b, A = R_wb (n,3,3) -> (3n,3), b = cmb (3n,)
    A = R_wb_arr.reshape(n * 3, 3)
    b = cmb.reshape(n * 3)
    t_mount_lsq, residuals, rank, sv = np.linalg.lstsq(A, b, rcond=None)
    pred = (A @ t_mount_lsq).reshape(n, 3)
    resid = pred - cmb
    print(f"\n=== 方法2: 纯最小二乘拟合 t_mount (不经标定链) ===")
    print(f"  t_mount (lstsq): x={t_mount_lsq[0]:+.4f}m, y={t_mount_lsq[1]:+.4f}m, z={t_mount_lsq[2]:+.4f}m")
    print(f"  残差 std: x={resid[:,0].std():.4f}m, y={resid[:,1].std():.4f}m, z={resid[:,2].std():.4f}m")
    print(f"  残差 max: {np.abs(resid).max():.4f}m")

    # 判定方向
    def dir_sign(v, name):
        if v > 0.005:
            return f"{name}+ ({'前' if name=='x' else '左' if name=='y' else '上'})"
        if v < -0.005:
            return f"{name}- ({'后' if name=='x' else '右' if name=='y' else '下'})"
        return f"{name}≈0"

    m = t_mount_lsq
    print(f"\n=== 挂装方向判定 (基于最小二乘) ===")
    print(f"  {dir_sign(m[0], 'x')}, {dir_sign(m[1], 'y')}, {dir_sign(m[2], 'z')}")
    front = m[0] > 0
    left = m[1] > 0
    print(f"  -> 相对 body 前方(X+): {'前' if front else '后'}")
    print(f"  -> 相对 body 左侧(Y+): {'左' if left else '右'}")
    print(f"  结论: 相机在 body 的 {'前' if front else '后'}{'左' if left else '右'}"
          f" (front={'True' if front else 'False'}, left={'True' if left else 'False'})")

    # 与标定链原值对比
    print(f"\n=== 交叉验证: 标定链原值 vs 运动学反推 ===")
    print(f"  标定链 raw_translation: x={raw_t[0]:+.4f}, y={raw_t[1]:+.4f}, z={raw_t[2]:+.4f}")
    print(f"  运动学反推 (lstsq)    : x={m[0]:+.4f}, y={m[1]:+.4f}, z={m[2]:+.4f}")
    print(f"  差异: x={m[0]-raw_t[0]:+.4f}, y={m[1]-raw_t[1]:+.4f}, z={m[2]-raw_t[2]:+.4f}")

    # y 方向特别注意: 标定链 y=+0.009 很小, 看运动学是否也这么小
    print(f"\n  注: y 方向标定链仅 {raw_t[1]*1000:.1f}mm, 运动学反推 {m[1]*1000:.1f}mm; "
          f"y 接近 0 时左右判定不确定, 需看 std")


if __name__ == "__main__":
    main()
