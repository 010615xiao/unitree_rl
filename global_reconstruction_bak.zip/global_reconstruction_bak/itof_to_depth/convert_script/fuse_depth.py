#!/usr/bin/env python3
"""
融合 long 和 short 深度图：用 short 中 <500mm 的深度填充 long 中的无效区域

Usage:
    python fuse_depth.py --long_dir data/depth_long --short_dir data/depth_short \
                         --mapping data/mapping.txt --output data/depth_fused
"""

import argparse
import numpy as np
import os
import re
from tqdm import tqdm


def parse_mapping(mapping_file):
    """解析 mapping.txt 获取 long-short 配对"""
    with open(mapping_file) as f:
        lines = f.readlines()
    
    pairs = []
    i = 0
    while i < len(lines) - 2:
        parts1 = [p.strip() for p in lines[i + 2].split('|')]
        if len(parts1) < 6:
            i += 1
            continue
        bin1, type1, jpg1 = parts1[1], parts1[2], parts1[4]
        
        if i + 3 < len(lines):
            parts2 = [p.strip() for p in lines[i + 3].split('|')]
            if len(parts2) >= 6:
                bin2, type2, jpg2 = parts2[1], parts2[2], parts2[4]
                if jpg1 == jpg2:
                    if type1 == 'long':
                        pairs.append((bin1, bin2, jpg1))
                    else:
                        pairs.append((bin2, bin1, jpg1))
                    i += 2
                    continue
        i += 1
    
    return pairs


def fuse_depths(depth_long, depth_short, near_threshold=500):
    """
    融合深度图：
    - <near_threshold mm: 优先用 short（近距离更准确）
    - >=near_threshold mm: 保留 long
    
    Args:
        depth_long: long 曝光深度图 (mm)
        depth_short: short 曝光深度图 (mm)
        near_threshold: 近距离阈值 (mm)，此范围内优先用 short
    
    Returns:
        fused: 融合后的深度图
        replaced_count: 被 short 替换的像素数
    """
    fused = depth_long.copy()
    
    # short 中 <threshold 的有效深度
    short_valid_near = (depth_short > 0) & (depth_short < near_threshold)
    
    # 情况1: short 有近距深度，long 无效 -> 填充
    long_invalid = (depth_long == 0) | (depth_long >= 5000)
    fill_mask = short_valid_near & long_invalid
    
    # 情况2: short 有近距深度，long 也有效 -> 替换（short 更准确）
    long_valid = ~long_invalid
    replace_mask = short_valid_near & long_valid
    
    # 合并：所有 short 有近距深度的位置都用 short
    use_short_mask = short_valid_near & (depth_short > 0)
    fused[use_short_mask] = depth_short[use_short_mask]
    
    return fused, np.sum(fill_mask), np.sum(replace_mask)


def main():
    parser = argparse.ArgumentParser(description="融合 long 和 short 深度图")
    parser.add_argument("--long_dir", required=True, help="Long 曝光深度图目录")
    parser.add_argument("--short_dir", required=True, help="Short 曝光深度图目录")
    parser.add_argument("--mapping", required=True, help="mapping.txt 路径")
    parser.add_argument("--output", required=True, help="输出融合深度图目录")
    parser.add_argument("--threshold", type=int, default=500, 
                        help="Short 中用于填充的近距阈值 (mm, 默认 500)")
    args = parser.parse_args()
    
    os.makedirs(args.output, exist_ok=True)

    pairs = parse_mapping(args.mapping)
    print(f"配对数量: {len(pairs)}")
    print(f"融合策略: <{args.threshold}mm 优先用 short, >=阈值保留 long")
    print()

    total_long_before = 0
    total_filled = 0
    total_replaced = 0
    total_long_after = 0

    for idx, (long_bin, short_bin, jpg) in enumerate(tqdm(pairs, desc="融合", unit="frame", ncols=100)):
        long_npy = os.path.join(args.long_dir, long_bin.replace('.bin', '.npy'))
        short_npy = os.path.join(args.short_dir, short_bin.replace('.bin', '.npy'))

        if not os.path.exists(long_npy) or not os.path.exists(short_npy):
            continue

        # 加载深度图
        depth_long = np.load(long_npy)
        depth_short = np.load(short_npy)

        # 统计融合前
        before = np.sum((depth_long > 0) & (depth_long < 5000))

        # 融合
        fused, fill_count, replace_count = fuse_depths(depth_long, depth_short, args.threshold)

        # 统计融合后
        after = np.sum((fused > 0) & (fused < 5000))

        total_long_before += before
        total_filled += fill_count
        total_replaced += replace_count
        total_long_after += after

        # 保存
        output_name = long_bin.replace('.bin', '.npy')
        output_path = os.path.join(args.output, output_name)
        np.save(output_path, fused)

    print(f"\n=== 融合完成 ===")
    print(f"Long 原始有效像素: {total_long_before:,}")
    print(f"填充像素数 (long无效): {total_filled:,}")
    print(f"替换像素数 (short更准确): {total_replaced:,}")
    print(f"融合后有效像素: {total_long_after:,}")
    print(f"输出目录: {args.output}")


if __name__ == "__main__":
    main()
