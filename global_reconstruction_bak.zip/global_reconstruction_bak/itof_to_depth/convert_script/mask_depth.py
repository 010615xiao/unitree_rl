#!/usr/bin/env python3
"""
将深度图中 >max_depth 的值置为无效(0)

Usage:
    python mask_depth.py --input data/depth_fused --output data/depth_fused_masked --max_depth 2.5
"""

import argparse
import numpy as np
import os
from pathlib import Path
from tqdm import tqdm


def main():
    parser = argparse.ArgumentParser(description="Mask far depth values")
    parser.add_argument("--input", required=True, help="输入深度图目录")
    parser.add_argument("--output", required=True, help="输出目录")
    parser.add_argument("--max_depth", type=float, default=2.5, help="最大有效深度(m)")
    parser.add_argument("--unit", choices=["m", "mm"], default="mm",
                        help="输入深度图单位 (默认 mm)")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    # 统一阈值到输入单位
    threshold = args.max_depth * 1000.0 if args.unit == "mm" else args.max_depth
    unit_str = "mm" if args.unit == "mm" else "m"

    files = sorted(Path(args.input).glob("*.npy"))
    print(f"输入: {args.input} ({len(files)} 帧)")
    print(f"输出: {args.output}")
    print(f"阈值: >{threshold:.0f}{unit_str} ({args.max_depth}m) 置无效")
    print()

    total_before = 0
    total_masked = 0

    for i, f in enumerate(tqdm(files, desc="遮罩", unit="file", ncols=100)):
        depth = np.load(str(f))
        valid_before = np.sum((depth > 0) & np.isfinite(depth))

        # >threshold 或 inf 置 0
        mask = (depth > threshold) | ~np.isfinite(depth)
        depth[mask] = 0.0

        valid_after = np.sum((depth > 0) & np.isfinite(depth))
        masked = valid_before - valid_after
        total_before += valid_before
        total_masked += masked

        # 转换为米 (batch_infer_itof.py 期望 m)
        if args.unit == "mm":
            depth = depth / 1000.0

        np.save(os.path.join(args.output, f.name), depth)

    print(f"\n=== 完成 ===")
    print(f"原始有效像素: {total_before:,}")
    print(f"屏蔽像素: {total_masked:,} ({total_masked/total_before*100:.1f}%)")
    print(f"剩余有效像素: {total_before - total_masked:,}")


if __name__ == "__main__":
    main()
