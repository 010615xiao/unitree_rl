#!/usr/bin/env python3
"""
Convert robot-center odometry to RGB camera poses.

Outputs:
  1. data/rgb_camera_poses.txt
     Full 4x4 T_camera_to_world matrices. This is the correct input for
     point-cloud reconstruction.

  2. data/odom_matched_camera.txt
     Compatibility/visualization file that replaces x, y, yaw with RGB camera
     center x/y and RGB optical-axis yaw. Do not use this lossy file for
     reconstruction when the full 4x4 poses are available.

Coordinate conventions for this project:
  - odom yaw=0 points to world +X.
  - robot/body +X is forward, +Y is left, +Z is up.
  - RGB/depth optical frame is +X right, +Y down, +Z forward.
  - The RGB camera is mounted at the robot front-left position.

Example:
  python odom_to_camera_pose.py --odom data/odom_matched.txt --camera_height 0.065
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable, List, Tuple

import numpy as np


TFC_RAW = np.array(
    [
        [0.00274122, 0.999996, -0.00104241, 28.1954],
        [0.00734858, -0.00106299, -0.999973, -26.4031],
        [-0.99997, 0.00273391, -0.00735188, -74.2395],
        [0, 0, 0, 1],
    ],
    dtype=np.float64,
)

TOC_RAW = np.array(
    [
        [-0.999985, 1.12736e-09, 0.00549903, 92.5241],
        [0.00267231, -0.87398, 0.485954, -2.12581],
        [0.00480604, 0.485962, 0.873967, 79.83],
        [0, 0, 0, 1],
    ],
    dtype=np.float64,
)

# Simplified camera-to-body rotation (matches physical mounting).
# cam +Z (forward) -> body +X (forward)
# cam +X (right)   -> body -Y (left)
# cam +Y (down)    -> body -Z (down)
# The calibration chain (TFC_RAW/TOC_RAW) has a coordinate convention
# mismatch that introduces ~30° roll error, so we use this fixed rotation
# for pose generation and only take the translation from calibration.
R_CAM2ROBOT = np.array(
    [[0, 0, 1],
     [-1, 0, 0],
     [0, -1, 0]],
    dtype=np.float64,
)


def invert_transform(T: np.ndarray) -> np.ndarray:
    out = np.eye(4, dtype=np.float64)
    R = T[:3, :3]
    t = T[:3, 3]
    out[:3, :3] = R.T
    out[:3, 3] = -R.T @ t
    return out


def robot_to_world_rotmat(yaw: float, pitch: float, roll: float) -> np.ndarray:
    """Robot/body to world. In this data, yaw=0 means world +X."""
    cy, sy = np.cos(yaw), np.sin(yaw)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cr, sr = np.cos(roll), np.sin(roll)

    Rz = np.array([[cy, -sy, 0.0], [sy, cy, 0.0], [0.0, 0.0, 1.0]])
    Ry_neg_pitch = np.array([[cp, 0.0, -sp], [0.0, 1.0, 0.0], [sp, 0.0, cp]])
    Rx_roll = np.array([[1.0, 0.0, 0.0], [0.0, cr, -sr], [0.0, sr, cr]])
    return Rz @ Ry_neg_pitch @ Rx_roll


def camera_to_body_transform(mount_forward: str, mount_side: str) -> Tuple[np.ndarray, np.ndarray]:
    """Return T_body_camera and the raw translation from the calibration chain.

    Rotation uses the fixed R_CAM2ROBOT (matches physical mounting).
    Translation is taken from the calibration chain with mount-prior signs.
    """
    Tfc = TFC_RAW.copy()
    Toc = TOC_RAW.copy()
    Tfc[:3, 3] /= 1000.0
    Toc[:3, 3] /= 1000.0

    # Tfo is body/odom frame -> RGB optical frame.
    Tfo = Tfc @ invert_transform(Toc)
    T_calib = invert_transform(Tfo)
    raw_translation = T_calib[:3, 3].copy()

    # Build T_body_camera: fixed rotation + calibrated translation.
    T_body_camera = np.eye(4, dtype=np.float64)
    T_body_camera[:3, :3] = R_CAM2ROBOT

    # Physical prior for this robot: RGB camera is front-left.
    if mount_forward == "front":
        T_body_camera[0, 3] = abs(raw_translation[0])
    elif mount_forward == "back":
        T_body_camera[0, 3] = -abs(raw_translation[0])
    else:
        T_body_camera[0, 3] = raw_translation[0]

    if mount_side == "left":
        T_body_camera[1, 3] = abs(raw_translation[1])
    elif mount_side == "right":
        T_body_camera[1, 3] = -abs(raw_translation[1])
    else:
        T_body_camera[1, 3] = raw_translation[1]

    T_body_camera[2, 3] = raw_translation[2]

    return T_body_camera, raw_translation


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert robot odom to RGB camera poses.")
    parser.add_argument("--odom", type=Path, required=True, help="Path to data/odom_matched.txt")
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Compatibility odom output. Default: same folder/odom_matched_camera.txt",
    )
    parser.add_argument(
        "--poses_output",
        type=Path,
        default=None,
        help="Full 4x4 pose output. Default: same folder/rgb_camera_poses.txt",
    )
    parser.add_argument(
        "--camera_height",
        type=float,
        default=0.065,
        help="Override RGB camera z height in world meters. Use 'none' by omitting only if you edit this script.",
    )
    parser.add_argument(
        "--mount_forward",
        choices=["front", "back", "as_calibrated"],
        default="front",
        help="Camera center forward/back prior in robot body frame.",
    )
    parser.add_argument(
        "--mount_side",
        choices=["left", "right", "as_calibrated"],
        default="left",
        help="Camera center side prior. +Y is left; this project uses left.",
    )
    parser.add_argument(
        "--format",
        choices=["0622", "0707"],
        default="0622",
        help="Dataset format. 0622: tab-sep, cols 1-5=x/y/yaw/roll/pitch. 0707: space-sep, cols 6/7/8=x/y/yaw, no roll/pitch.",
    )
    return parser.parse_args()


def iter_odom_lines(path: Path, fmt: str = "0622") -> Iterable[Tuple[str, List[str]]]:
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            stripped = line.rstrip("\n")
            if not stripped.strip():
                yield stripped, []
                continue
            # 0622: tab-separated; 0707: space-separated
            sep = "\t" if fmt == "0622" else " "
            yield stripped, stripped.split(sep)


def angle_diff(a: float, b: float) -> float:
    return (a - b + np.pi) % (2.0 * np.pi) - np.pi


def write_outputs(args: argparse.Namespace) -> None:
    odom_path = args.odom
    output_path = args.output or (odom_path.parent / "odom_matched_camera.txt")
    poses_output = args.poses_output or (odom_path.parent / "rgb_camera_poses.txt")
    fmt = getattr(args, "format", "0622")

    T_body_camera, raw_translation = camera_to_body_transform(args.mount_forward, args.mount_side)

    converted_lines: List[str] = []
    pose_lines = [
        "# enc_time\ttime_str\tm00\tm01\tm02\tm03\tm10\tm11\tm12\tm13\t"
        "m20\tm21\tm22\tm23\tm30\tm31\tm32\tm33"
    ]
    diagnostics = []

    for raw_line, parts in iter_odom_lines(odom_path, fmt):
        if fmt == "0707":
            # 0707: space-sep, cols 6/7/8 = x/y/yaw (mm/rad), no roll/pitch
            if not parts or len(parts) < 9:
                converted_lines.append(raw_line)
                continue
            x_m = float(parts[6]) / 1000.0
            y_m = float(parts[7]) / 1000.0
            yaw = float(parts[8])
            roll = 0.0
            pitch = 0.0
        else:
            # 0622: tab-sep, cols 1-5 = x/y/yaw/roll/pitch
            if not parts or len(parts) < 6:
                converted_lines.append(raw_line)
                continue
            x_m = float(parts[1]) / 1000.0
            y_m = float(parts[2]) / 1000.0
            yaw = float(parts[3])
            roll = float(parts[4])
            pitch = float(parts[5])

        R_world_body = robot_to_world_rotmat(yaw, pitch, roll)
        T_world_body = np.eye(4, dtype=np.float64)
        T_world_body[:3, :3] = R_world_body
        T_world_body[:3, 3] = [x_m, y_m, 0.0]

        T_world_camera = T_world_body @ T_body_camera
        if args.camera_height is not None:
            T_world_camera[2, 3] = args.camera_height

        x_new = T_world_camera[0, 3]
        y_new = T_world_camera[1, 3]
        # RGB optical +Z is the actual forward/look direction.
        yaw_new = np.arctan2(T_world_camera[1, 2], T_world_camera[0, 2])

        parts_out = parts.copy()
        if fmt == "0707":
            parts_out[6] = str(int(round(x_new * 1000.0)))
            parts_out[7] = str(int(round(y_new * 1000.0)))
            parts_out[8] = str(yaw_new)
            converted_lines.append(" ".join(parts_out))
        else:
            parts_out[1] = str(int(round(x_new * 1000.0)))
            parts_out[2] = str(int(round(y_new * 1000.0)))
            parts_out[3] = str(yaw_new)
            converted_lines.append("\t".join(parts_out))

        time_str = parts[11] if len(parts) > 11 else ""
        matrix_text = "\t".join(f"{v:.12g}" for v in T_world_camera.reshape(-1))
        pose_lines.append(f"{parts[0]}\t{time_str}\t{matrix_text}")

        body_offset = R_world_body.T @ (T_world_camera[:3, 3] - T_world_body[:3, 3])
        diagnostics.append((x_m, y_m, yaw, x_new, y_new, yaw_new, body_offset))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    poses_output.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(converted_lines) + "\n", encoding="utf-8")
    poses_output.write_text("\n".join(pose_lines) + "\n", encoding="utf-8")

    print_pose_diagnostics(raw_translation, T_body_camera, diagnostics)
    print(f"\nSaved compatibility odom -> {output_path}")
    print(f"Saved full RGB camera poses -> {poses_output}")


def print_pose_diagnostics(
    raw_translation: np.ndarray, T_body_camera: np.ndarray, diagnostics: List[tuple]
) -> None:
    print("Calibration/mount summary")
    print(
        f"  raw calibration body translation: "
        f"x={raw_translation[0]:+.4f}m, y={raw_translation[1]:+.4f}m, z={raw_translation[2]:+.4f}m"
    )
    print(
        f"  used body translation (+X front, +Y left): "
        f"x={T_body_camera[0,3]:+.4f}m, y={T_body_camera[1,3]:+.4f}m, z={T_body_camera[2,3]:+.4f}m"
    )
    if not diagnostics:
        return

    offsets = np.array([d[6] for d in diagnostics], dtype=np.float64)
    xy = offsets[:, :2]
    radius = np.linalg.norm(xy, axis=1)
    print(
        f"  per-frame body offset range: "
        f"x[{xy[:,0].min():+.4f},{xy[:,0].max():+.4f}]m, "
        f"y[{xy[:,1].min():+.4f},{xy[:,1].max():+.4f}]m"
    )
    print(
        f"  per-frame body offset mean: "
        f"x={xy[:,0].mean():+.4f}m, y={xy[:,1].mean():+.4f}m, radius={radius.mean():.4f}m"
    )
    if np.all(xy[:, 0] > 0.0) and np.all(xy[:, 1] > 0.0):
        print("  mount check: OK, every frame is front-left (+X, +Y).")
    else:
        print("  mount check: WARNING, some frames are not front-left.")

    print("\nFirst 5 frames")
    print(f"{'idx':>3} | {'robot_x':>8} {'robot_y':>8} {'robot_yaw':>9} | "
          f"{'cam_x':>8} {'cam_y':>8} {'cam_yaw':>9}")
    for idx, (x, y, yaw, cx, cy, cyaw, _offset) in enumerate(diagnostics[:5]):
        print(
            f"{idx:3d} | {x:8.3f} {y:8.3f} {np.degrees(yaw):9.2f} | "
            f"{cx:8.3f} {cy:8.3f} {np.degrees(cyaw):9.2f}"
        )

    orig_len = sum(
        np.hypot(diagnostics[i][0] - diagnostics[i - 1][0], diagnostics[i][1] - diagnostics[i - 1][1])
        for i in range(1, len(diagnostics))
    )
    cam_len = sum(
        np.hypot(diagnostics[i][3] - diagnostics[i - 1][3], diagnostics[i][4] - diagnostics[i - 1][4])
        for i in range(1, len(diagnostics))
    )
    print(f"\nTrajectory length: robot={orig_len:.3f}m, rgb_camera={cam_len:.3f}m")

    print("\nMotion direction sanity check")
    for i in range(100, len(diagnostics), 100):
        dx = diagnostics[i][3] - diagnostics[i - 100][3]
        dy = diagnostics[i][4] - diagnostics[i - 100][4]
        if np.hypot(dx, dy) < 0.01:
            continue
        move_yaw = np.arctan2(dy, dx)
        yaw_diff = np.degrees(angle_diff(move_yaw, diagnostics[i][5]))
        print(
            f"  frame {i}: cam_yaw={np.degrees(diagnostics[i][5]):7.1f} deg, "
            f"move_dir={np.degrees(move_yaw):7.1f} deg, diff={yaw_diff:+.1f} deg"
        )


def main() -> None:
    args = parse_args()
    write_outputs(args)


if __name__ == "__main__":
    main()

