#!/usr/bin/env python3
"""
Match jpg files with bin files and odometry entries.

Supports two dataset formats:

Format 0622 (default):
    Timestamp-based matching. Each jpg corresponds to 2 consecutive bin files
    (long/short exposure). OdomPose matched by closest timestamp.

    Directory structure under <base_dir>:
        jpg_bin/               - bin + jpg files (timestamp-named)
        OdomPose.txt           - tab-separated, last column: DD_HH:MI:SS.mmm

    Output: bin_long/, bin_short/, jpg/, mapping.txt, odom_matched.txt

Format 0707:
    Name-based matching. pointcloud1/ and pointcloud2/ contain bin files with
    matching names. Images in images/. Odometry in odometry.txt.

    Directory structure under <base_dir>:
        pointcloud1/           - bin files: ptcloud_align_*.bin
        pointcloud2/           - bin files: ptcloud_align_*.bin (same names)
        images/                - jpg files: ptcloud_align_*.jpg
        odometry.txt           - col1=name, cols 7-9=x/y/yaw (mm/rad)

    Output: bin_pc1/, bin_pc2/, jpg/, odom_matched.txt

Usage:
    python match_data.py <base_dir> [--format 0622|0707]
"""

import os
import re
import sys
import shutil
from bisect import bisect_left
from pathlib import Path


def time_to_ms(DD, HH, MI, SS, mmm):
    return DD * 86400000 + HH * 3600000 + MI * 60000 + SS * 1000 + mmm


def parse_bin_time(fname):
    """itof_output_DD_HH_MI_SS_mmm.bin -> ms"""
    m = re.search(r'itof_output_(\d+)_(\d+)_(\d+)_(\d+)_(\d+)\.bin', fname)
    if not m:
        return None
    return time_to_ms(*[int(x) for x in m.groups()])


def parse_jpg_time(fname):
    """seg_input_DD_HH_MI_SS_mmm.jpg -> ms"""
    m = re.search(r'seg_input_(\d+)_(\d+)_(\d+)_(\d+)_(\d+)\.jpg', fname)
    if not m:
        return None
    return time_to_ms(*[int(x) for x in m.groups()])


def parse_odom_time(ts):
    """DD_HH:MI:SS.mmm -> ms"""
    m = re.search(r'(\d+)_(\d+):(\d+):(\d+)\.(\d+)', ts)
    if not m:
        return None
    return time_to_ms(*[int(x) for x in m.groups()])


def parse_ptcloud_time(fname):
    """ptcloud_align_YYYYMMDD_HHMMSS_microsec.{jpg,bin} -> ms。

    基准与 parse_odom_time 一致 (按 day-of-month 起算的 ms)，以便直接比较。
    微秒截断为毫秒 (//1000)。
    """
    m = re.search(r'ptcloud_align_\d{4}(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})_(\d+)', fname)
    if not m:
        return None
    _mo, dd, hh, mi, ss, us = m.groups()
    return time_to_ms(int(dd), int(hh), int(mi), int(ss), int(us) // 1000)


def find_closest(sorted_times, target):
    """Binary search for the closest value in a sorted list. Returns (index, abs_delta)."""
    pos = bisect_left(sorted_times, target)
    best_idx = None
    best_delta = float('inf')
    for idx in (pos - 1, pos):
        if 0 <= idx < len(sorted_times):
            d = abs(sorted_times[idx] - target)
            if d < best_delta:
                best_delta = d
                best_idx = idx
    return best_idx, best_delta


# ======================================================================
# Format 0622: timestamp-based matching
# ======================================================================

def match_0622(args):
    base = args.base_dir
    jpg_bin_dir = os.path.join(base, args.bin_dir)
    odom_file = os.path.join(base, "OdomPose.txt")

    out_dir = args.output_dir or os.path.join(base, "data")
    out_bin_long_dir = os.path.join(out_dir, "bin_long")
    out_bin_short_dir = os.path.join(out_dir, "bin_short")
    out_jpg_dir = os.path.join(out_dir, "jpg")

    for d in (out_bin_long_dir, out_bin_short_dir, out_jpg_dir):
        os.makedirs(d, exist_ok=True)

    # 1. Load bin files, sort by timestamp
    bin_files = sorted(f for f in os.listdir(jpg_bin_dir) if f.endswith('.bin'))
    bin_times = []
    for bf in bin_files:
        t = parse_bin_time(bf)
        if t is None:
            print(f"  [SKIP] Cannot parse bin time: {bf}")
        else:
            bin_times.append((t, bf))
    bin_times.sort(key=lambda x: x[0])
    print(f"Loaded {len(bin_times)} bin files from jpg_bin/")

    # 2. Load jpg files, sort by timestamp
    jpg_files = sorted(f for f in os.listdir(jpg_bin_dir) if f.endswith('.jpg'))
    jpg_entries = []
    for jf in jpg_files:
        t = parse_jpg_time(jf)
        if t is None:
            print(f"  [SKIP] Cannot parse jpg time: {jf}")
        else:
            jpg_entries.append((t, jf))
    jpg_entries.sort(key=lambda x: x[0])
    print(f"Loaded {len(jpg_entries)} jpg files from jpg_bin/")

    # 3. Pair check
    expected_bins = len(jpg_entries) * 2
    if len(bin_times) != expected_bins:
        print(f"  [WARN] Expected {expected_bins} bin files (2 x {len(jpg_entries)} jpg), "
              f"got {len(bin_times)}")

    # 4. Load OdomPose, sort by time
    odom_entries = []
    with open(odom_file, errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t')
            if len(parts) < 2:
                continue
            ts = parts[-1]
            t = parse_odom_time(ts)
            if t is None:
                continue
            odom_entries.append((t, line))
    odom_entries.sort(key=lambda x: x[0])
    odom_sorted_times = [t for t, _ in odom_entries]
    print(f"Loaded {len(odom_entries)} OdomPose entries")

    # 5. Match
    mapping_lines = []
    odom_matched_lines = []
    header = (
        f"{'#':>6} | {'Bin File':<40} | {'Type':<6} | {'Bin Time (ms)':<13} | "
        f"{'JPG File':<40} | {'JPG Time (ms)':<13} | {'Bin Δ(ms)':<10} | {'Odom Δ(ms)'}"
    )
    separator = "-" * len(header)
    mapping_lines.append(header)
    mapping_lines.append(separator)

    matched_jpg = 0
    skipped_odom = 0
    row_idx = 0

    for jpg_idx, (jpg_t, jpg_fname) in enumerate(jpg_entries):
        bin_idx_a = jpg_idx * 2
        bin_idx_b = jpg_idx * 2 + 1

        if bin_idx_b >= len(bin_times):
            print(f"  [WARN] Not enough bins for jpg[{jpg_idx}] {jpg_fname}, skipping")
            break

        bin_a_t, bin_a_fname = bin_times[bin_idx_a]
        bin_b_t, bin_b_fname = bin_times[bin_idx_b]

        odom_idx, odom_delta = find_closest(odom_sorted_times, jpg_t)
        if odom_idx is None:
            print(f"  [WARN] No OdomPose found for {jpg_fname}")
            skipped_odom += 1
            continue
        odom_t, odom_line = odom_entries[odom_idx]

        # Copy files
        shutil.copy2(os.path.join(jpg_bin_dir, jpg_fname),
                      os.path.join(out_jpg_dir, jpg_fname))
        shutil.copy2(os.path.join(jpg_bin_dir, bin_a_fname),
                      os.path.join(out_bin_long_dir, bin_a_fname))
        shutil.copy2(os.path.join(jpg_bin_dir, bin_b_fname),
                      os.path.join(out_bin_short_dir, bin_b_fname))

        delta_a = bin_a_t - jpg_t
        mapping_lines.append(
            f"{row_idx:<6} | {bin_a_fname:<40} | {'long':<6} | {bin_a_t:<13} | "
            f"{jpg_fname:<40} | {jpg_t:<13} | {delta_a:<10} | {odom_delta}"
        )
        odom_matched_lines.append(odom_line)
        row_idx += 1

        delta_b = bin_b_t - jpg_t
        mapping_lines.append(
            f"{row_idx:<6} | {bin_b_fname:<40} | {'short':<6} | {bin_b_t:<13} | "
            f"{jpg_fname:<40} | {jpg_t:<13} | {delta_b:<10} | {odom_delta}"
        )
        odom_matched_lines.append(odom_line)
        row_idx += 1

        matched_jpg += 1

    # 6. Save
    mapping_path = os.path.join(out_dir, "mapping.txt")
    with open(mapping_path, 'w') as f:
        f.write('\n'.join(mapping_lines) + '\n')

    odom_path = os.path.join(out_dir, "odom_matched.txt")
    with open(odom_path, 'w') as f:
        f.write('\n'.join(odom_matched_lines) + '\n')

    total_bins = matched_jpg * 2
    print(f"\nDone! Matched {matched_jpg} jpg files -> {total_bins} bin entries.")
    if skipped_odom:
        print(f"  Skipped {skipped_odom} jpg (no OdomPose available)")
    print(f"Output saved to {out_dir}/")
    print(f"  bin_long/        : {len(os.listdir(out_bin_long_dir))} files (long exposure)")
    print(f"  bin_short/       : {len(os.listdir(out_bin_short_dir))} files (short exposure)")
    print(f"  jpg/             : {len(os.listdir(out_jpg_dir))} files")
    print(f"  mapping.txt      : {total_bins} entries ({matched_jpg} jpg x 2 bins)")
    print(f"  odom_matched.txt : {len(odom_matched_lines)} entries")


# ======================================================================
# Format 0707: name-based matching
# ======================================================================

def match_0707(args):
    base = Path(args.base_dir)
    pc1_dir = base / "pointcloud1"
    pc2_dir = base / "pointcloud2"
    img_dir = base / "images"
    odom_file = base / "odometry.txt"

    out_dir = Path(args.output_dir) if args.output_dir else base / "data"
    out_bin_pc1_dir = out_dir / "bin_pc1"
    out_bin_pc2_dir = out_dir / "bin_pc2"
    out_jpg_dir = out_dir / "jpg"

    for d in (out_bin_pc1_dir, out_bin_pc2_dir, out_jpg_dir):
        d.mkdir(parents=True, exist_ok=True)

    # 1. Discover files by name stem
    pc1_files = {p.stem: p for p in sorted(pc1_dir.glob("*.bin"))}
    pc2_files = {p.stem: p for p in sorted(pc2_dir.glob("*.bin"))}
    jpg_files = {p.stem: p for p in sorted(img_dir.glob("*.jpg"))}

    print(f"pointcloud1/ : {len(pc1_files)} bin files")
    print(f"pointcloud2/ : {len(pc2_files)} bin files")
    print(f"images/      : {len(jpg_files)} jpg files")

    # 2. Find common stems across all three
    common = sorted(set(pc1_files) & set(pc2_files) & set(jpg_files))
    print(f"Common stems : {len(common)}")

    only_pc1 = set(pc1_files) - set(common)
    only_pc2 = set(pc2_files) - set(common)
    only_img = set(jpg_files) - set(common)
    if only_pc1:
        print(f"  [INFO] {len(only_pc1)} bin in pc1 only (no pc2/jpg match)")
    if only_pc2:
        print(f"  [INFO] {len(only_pc2)} bin in pc2 only (no pc1/jpg match)")
    if only_img:
        print(f"  [INFO] {len(only_img)} jpg with no bin match")

    # 3. Load odometry, index by name (col 0)
    # 0707 odometry.txt is space-separated: name c1 c2 c3 c4 c5 x y yaw
    # Filter out entries where x=0 and y=0 (invalid odometry)
    odom_by_name = {}
    zero_xy_names = set()
    with open(odom_file, errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 9:
                continue
            name = parts[0]
            x_val = float(parts[6])
            y_val = float(parts[7])
            if x_val == 0.0 and y_val == 0.0:
                zero_xy_names.add(name)
                continue
            odom_by_name[name] = line
    print(f"odometry.txt : {len(odom_by_name)} entries"
          + (f" ({len(zero_xy_names)} skipped: x=y=0)" if zero_xy_names else ""))

    # 4. Match and copy — only stems with valid odometry
    matched = 0
    skipped_odom = 0
    skipped_zero_xy_frame = 0
    odom_matched_lines = []

    for stem in common:
        # Skip frames with no valid odometry (x=y=0 or missing)
        if stem not in odom_by_name:
            if stem in zero_xy_names:
                skipped_zero_xy_frame += 1
            else:
                skipped_odom += 1
            continue

        # Copy files
        shutil.copy2(str(pc1_files[stem]), str(out_bin_pc1_dir / (stem + ".bin")))
        shutil.copy2(str(pc2_files[stem]), str(out_bin_pc2_dir / (stem + ".bin")))
        shutil.copy2(str(jpg_files[stem]), str(out_jpg_dir / (stem + ".jpg")))

        odom_matched_lines.append(odom_by_name[stem])
        matched += 1

    # 5. Save odom_matched.txt
    odom_path = out_dir / "odom_matched.txt"
    with open(odom_path, 'w') as f:
        f.write('\n'.join(odom_matched_lines) + '\n')

    print(f"\nDone! Matched {matched} frames.")
    if skipped_zero_xy_frame:
        print(f"  Skipped {skipped_zero_xy_frame} frames (x=y=0 in odometry)")
    if skipped_odom:
        print(f"  Skipped {skipped_odom} frames (no odometry entry)")
    print(f"Output saved to {out_dir}/")
    print(f"  bin_pc1/         : {len(list(out_bin_pc1_dir.iterdir()))} files")
    print(f"  bin_pc2/         : {len(list(out_bin_pc2_dir.iterdir()))} files")
    print(f"  jpg/             : {len(list(out_jpg_dir.iterdir()))} files")
    print(f"  odom_matched.txt : {len(odom_matched_lines)} entries")


# ======================================================================
# Format ep0005: 0707 布局 + 0622 风格 OdomPose.txt (时间戳最近匹配)
# ======================================================================

def match_ep0005(args):
    """ep0005 混合格式匹配。

    目录结构 (与 0707 相同):
        pointcloud1/   - bin: ptcloud_align_*.bin
        pointcloud2/   - bin: ptcloud_align_*.bin (同名)
        images/        - jpg: ptcloud_align_*.jpg (同名)
        OdomPose.txt   - tab 分隔 11 列: enc_time x y yaw roll pitch 0 0 x y 时间戳

    匹配方式:
      - pointcloud1/pointcloud2/images 按文件名一一对应 (0707 风格)。
      - OdomPose.txt 按 jpg 文件名中的时间戳找最近一条 odom (0622 风格)。
      - 输出 odom_matched.txt 时把 col0 (enc_time) 替换成文件名, 保留 roll/pitch,
        使下游 odom_to_camera_pose --format 0622 能读到 roll/pitch, 且 pose 名 == depth 名。
    """
    base = Path(args.base_dir)
    pc1_dir = base / "pointcloud1"
    pc2_dir = base / "pointcloud2"
    img_dir = base / "images"
    odom_file = base / "OdomPose.txt"

    out_dir = Path(args.output_dir) if args.output_dir else base / "data"
    out_bin_pc1_dir = out_dir / "bin_pc1"
    out_bin_pc2_dir = out_dir / "bin_pc2"
    out_jpg_dir = out_dir / "jpg"

    for d in (out_bin_pc1_dir, out_bin_pc2_dir, out_jpg_dir):
        d.mkdir(parents=True, exist_ok=True)

    # 1. 按文件名发现文件
    pc1_files = {p.stem: p for p in sorted(pc1_dir.glob("*.bin"))}
    pc2_files = {p.stem: p for p in sorted(pc2_dir.glob("*.bin"))}
    jpg_files = {p.stem: p for p in sorted(img_dir.glob("*.jpg"))}

    print(f"pointcloud1/ : {len(pc1_files)} bin files")
    print(f"pointcloud2/ : {len(pc2_files)} bin files")
    print(f"images/      : {len(jpg_files)} jpg files")

    common = sorted(set(pc1_files) & set(pc2_files) & set(jpg_files))
    print(f"同名一一对应 : {len(common)} 帧")

    only_pc1 = set(pc1_files) - set(common)
    only_pc2 = set(pc2_files) - set(common)
    only_img = set(jpg_files) - set(common)
    if only_pc1:
        print(f"  [INFO] {len(only_pc1)} bin 仅在 pointcloud1 (无 pc2/jpg)")
    if only_pc2:
        print(f"  [INFO] {len(only_pc2)} bin 仅在 pointcloud2 (无 pc1/jpg)")
    if only_img:
        print(f"  [INFO] {len(only_img)} jpg 无 bin 对应")

    # 2. 加载 OdomPose.txt, 按时间戳排序 (跳过 x=y=0 的无效条目)
    odom_entries = []
    skipped_zero = 0
    skipped_parse = 0
    with open(odom_file, errors="ignore") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) < 11:
                skipped_parse += 1
                continue
            try:
                x_val = float(parts[1])
                y_val = float(parts[2])
            except ValueError:
                skipped_parse += 1
                continue
            if x_val == 0.0 and y_val == 0.0:
                skipped_zero += 1
                continue
            t = parse_odom_time(parts[-1])
            if t is None:
                skipped_parse += 1
                continue
            odom_entries.append((t, line))
    odom_entries.sort(key=lambda x: x[0])
    odom_sorted_times = [t for t, _ in odom_entries]
    print(f"OdomPose.txt  : {len(odom_entries)} 有效条目 "
          f"(跳过 {skipped_zero} 个 x=y=0, {skipped_parse} 个解析失败)")

    if not odom_entries:
        print("[ERROR] OdomPose.txt 无有效时间戳条目, 无法匹配")
        return

    # 3. 对每个 jpg, 用文件名时间戳找最近 odom
    odom_matched_lines = []
    matched = 0
    no_time = 0
    deltas = []
    for stem in common:
        jpg_t = parse_ptcloud_time(stem)
        if jpg_t is None:
            no_time += 1
            continue
        idx, delta = find_closest(odom_sorted_times, jpg_t)
        if idx is None:
            continue
        deltas.append(delta)

        # 复制 bin/jpg (保留 ptcloud_align 文件名)
        shutil.copy2(str(pc1_files[stem]), str(out_bin_pc1_dir / (stem + ".bin")))
        shutil.copy2(str(pc2_files[stem]), str(out_bin_pc2_dir / (stem + ".bin")))
        shutil.copy2(str(jpg_files[stem]), str(out_jpg_dir / (stem + ".jpg")))

        # odom 行 col0 替换成文件名 (保留 x/y/yaw/roll/pitch/时间戳)
        parts = odom_entries[idx][1].split("\t")
        parts[0] = stem
        odom_matched_lines.append("\t".join(parts))
        matched += 1

    # 4. 保存
    odom_path = out_dir / "odom_matched.txt"
    with open(odom_path, "w") as f:
        f.write("\n".join(odom_matched_lines) + "\n")

    print(f"\nDone! 匹配 {matched} 帧 (jpg 时间无法解析 {no_time} 帧)。")
    if deltas:
        deltas_sorted = sorted(deltas)
        n = len(deltas_sorted)
        print(f"  时间戳偏差 delta(ms): 中位≈{deltas_sorted[n // 2]:.1f}, "
              f"p90≈{deltas_sorted[int(n * 0.9)]:.1f}, max={deltas_sorted[-1]:.0f}")
    print(f"输出: {out_dir}/")
    print(f"  bin_pc1/        : {len(list(out_bin_pc1_dir.iterdir()))} files")
    print(f"  bin_pc2/        : {len(list(out_bin_pc2_dir.iterdir()))} files")
    print(f"  jpg/            : {len(list(out_jpg_dir.iterdir()))} files")
    print(f"  odom_matched.txt: {len(odom_matched_lines)} entries (col0=文件名, tab分隔, 含 roll/pitch)")


# ======================================================================
# Main
# ======================================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Match jpg + bin + odom data")
    parser.add_argument("base_dir", help="Base directory containing the dataset")
    parser.add_argument("--format", choices=["0622", "0707", "ep0005"], default="0622",
                        help="Dataset format (default: 0622). ep0005=0707布局+OdomPose按时间戳最近匹配")
    parser.add_argument("--bin_dir", default="jpg_bin",
                        help="[0622] Name of the folder containing bin and jpg files (default: jpg_bin)")
    parser.add_argument("--output-dir", default=None,
                        help="Output directory for intermediate files (default: base_dir/data)")
    args = parser.parse_args()

    if args.format == "0707":
        match_0707(args)
    elif args.format == "ep0005":
        match_ep0005(args)
    else:
        match_0622(args)


if __name__ == "__main__":
    main()
