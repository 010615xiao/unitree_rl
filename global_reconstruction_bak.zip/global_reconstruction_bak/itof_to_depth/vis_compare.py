#!/usr/bin/env python3
"""可视化对比: 长曝光深度 / 短曝光深度 / RGB，拼成一张图。"""

import argparse
from pathlib import Path

import cv2
import numpy as np


def main():
    parser = argparse.ArgumentParser(description="对比长曝光/短曝光/RGB")
    parser.add_argument("--data-dir", type=Path,
                        default=Path(__file__).resolve().parent / "data",
                        help="pipeline 产出的 data/ 目录")
    parser.add_argument("--index", type=int, default=None,
                        help="帧索引 (0-based, 默认处理所有帧)")
    parser.add_argument("--output", type=Path, default=None,
                        help="输出图片路径 (默认 data/viz_compare/compare_<index>.png)")
    args = parser.parse_args()

    data_dir = args.data_dir
    long_dir = data_dir / "depth_long_rgb"
    short_dir = data_dir / "depth_short_rgb"
    jpg_dir = data_dir / "jpg"

    for d in [long_dir, short_dir, jpg_dir]:
        if not d.is_dir():
            raise FileNotFoundError(f"目录不存在: {d}")

    long_files = sorted(long_dir.glob("*.png"))
    short_files = sorted(short_dir.glob("*.png"))
    jpg_files = sorted(jpg_dir.glob("*.jpg"))

    n = min(len(long_files), len(short_files), len(jpg_files))
    indices = [args.index] if args.index is not None else range(n)

    if args.index is not None and args.index >= n:
        raise ValueError(f"索引 {args.index} 超出范围 (共 {n} 帧)")

    out_dir = data_dir / "viz_compare"
    out_dir.mkdir(exist_ok=True)

    for idx in indices:
        img_long = cv2.imread(str(long_files[idx]))
        img_short = cv2.imread(str(short_files[idx]))
        img_rgb = cv2.imread(str(jpg_files[idx]))

        for name, img in [("long", img_long), ("short", img_short), ("rgb", img_rgb)]:
            if img is None:
                raise IOError(f"无法读取帧 {idx}: {name}")

        # 统一高度
        target_h = max(img_long.shape[0], img_short.shape[0], img_rgb.shape[0])
        resized = []
        for img in [img_long, img_short, img_rgb]:
            if img.shape[0] != target_h:
                scale = target_h / img.shape[0]
                img = cv2.resize(img, (int(img.shape[1] * scale), target_h))
            resized.append(img)

        # 加标题
        labels = ["Long Exposure", "Short Exposure", "RGB"]
        titled = []
        for img, label in zip(resized, labels):
            h, w = img.shape[:2]
            bar_h = 30
            bar = np.zeros((bar_h, w, 3), dtype=np.uint8)
            cv2.putText(bar, label, (10, 22), cv2.FONT_HERSHEY_SIMPLEX,
                        0.7, (255, 255, 255), 2)
            titled.append(np.vstack([bar, img]))

        result = np.hstack(titled)

        out_path = args.output or (out_dir / f"compare_{idx:04d}.png")
        cv2.imwrite(str(out_path), result)
        print(f"[{idx+1}/{n}] 已保存: {out_path.name}")

    print(f"完成: {len(indices)}/{n} 帧 -> {out_dir}")


if __name__ == "__main__":
    main()
