---
name: pipeline-filter-step
description: How to add a filtering/preprocessing step to the iTOF pipeline that removes bad frames while keeping all related files in sync
source: auto-skill
extracted_at: '2026-07-13T11:58:38.737Z'
---

# Adding a Filtering Step to the iTOF Pipeline

When adding a step that removes frames based on some quality criterion (e.g. too few valid depth pixels), all related files must be filtered together to avoid downstream mismatches.

## The Problem

The pipeline produces multiple parallel file sets that must stay in 1:1 correspondence:

| Directory/File | Content |
|---|---|
| `depth_fused/` | Fused depth .npy files |
| `jpg/` | RGB images |
| `odom_matched.txt` | Odometry entries (1 or 2 lines per frame depending on format) |
| `mapping.txt` | 0622 format only: bin↔jpg mapping |

If you filter only `depth_fused/` but leave `jpg/` and `odom_matched.txt` untouched, downstream steps (like LingBot-Depth) will fail with count mismatches.

## Pattern for Filter Steps

### 1. Function signature

Add `fmt: str = "0622"` parameter so the step handles both formats:

```python
def step3_5_filter_depth(work_dir: Path, min_valid: int, fmt: str = "0622") -> bool:
```

### 2. Build cross-reference mapping

Use `mapping.txt` (0622) or filename matching (0707) to link depth files to their corresponding jpg files:

```python
# 0622: parse mapping.txt (pipe-delimited table)
depth_to_jpg = {}
with open(mapping_file) as f:
    for line in f:
        parts = [p.strip() for p in line.split("|")]
        if len(parts) >= 5:
            bin_name = parts[1]      # itof_output_*.bin
            jpg_name = parts[4]      # seg_input_*.jpg
            depth_name = bin_name.replace(".bin", ".npy")
            depth_to_jpg[depth_name] = jpg_name
```

### 3. Move files to `_filtered_out/` directories

Don't delete — move to parallel `_filtered_out/` directories for inspection:

```python
depth_out = data_dir / "depth_fused_filtered_out"
jpg_out = data_dir / "jpg_filtered_out"
depth_out.mkdir(exist_ok=True)
jpg_out.mkdir(exist_ok=True)

# Move depth
shutil.move(str(npy_file), str(depth_out / npy_file.name))
# Move corresponding jpg
shutil.move(str(jpg_src), str(jpg_out / jpg_name))
```

### 4. Filter odom_matched.txt and rgb_camera_poses.txt

For 0622, each frame has 2 odom entries (long + short bin). Collect all bin names to remove, then filter the file:

```python
removed_bins = set()
for depth_name in removed_depth:
    stem = depth_name.replace(".npy", "")
    removed_bins.add(stem)          # e.g. "ptcloud_align_20260713_184309"
    removed_bins.add(stem + ".bin") # e.g. "ptcloud_align_20260713_184309.bin"
    # 0622: also add the paired bin from mapping.txt
    ...

odom_lines = odom_file.read_text().splitlines()
kept = [line for line in odom_lines if line.split()[0] not in removed_bins]
odom_file.write_text("\n".join(kept) + "\n")
```

**Critical:** odom files use bare names (no `.bin` suffix) while depth files use `.npy`. Always add BOTH `stem` and `stem + ".bin"` to `removed_bins`. Using only one form causes silent match failures — the filter step appears to succeed but odom/poses are never actually filtered, leading to downstream count mismatches (e.g. 701 poses vs 515 frames).

Also filter `rgb_camera_poses.txt` the same way — it has the same first-column format as `odom_matched.txt`.

### 5. Skip-if-already-done check + supplementary filtering

Check if `_filtered_out/` already has files before re-running. If skipped, still verify odom/poses were filtered (use a marker file like `poses_filtered.txt`):

```python
if depth_out.is_dir() and any(depth_out.glob("*.npy")):
    log("  [SKIP] 已过滤")
    if not (data_dir / "poses_filtered.txt").exists():
        # supplementary: re-derive removed_bins from filtered_out/*.npy
        # and filter odom_matched.txt + rgb_camera_poses.txt
        ...
        (data_dir / "poses_filtered.txt").touch()
    return True
```

### 6. Wire into prep_steps

Pass `fmt` through:

```python
prep_steps = [
    lambda: step1_match_data(raw_dir, work_dir, fmt),
    lambda: step2_convert_depth(work_dir, fmt),
    lambda: step3_fuse_depth(work_dir, fmt),
    lambda: step3_5_filter_depth(work_dir, min_valid_depth, fmt),  # new
    lambda: step4_mask_depth(work_dir, max_depth, fmt),
]
```

### 7. CLI + config

Follow the parameterized scripts pattern — add both CLI arg and config.yaml entry:

```python
# CLI
parser.add_argument("--min-valid-depth", type=int, default=None,
                    help="... (默认从 config.yaml)")

# Config loading
min_valid_depth = args.min_valid_depth if args.min_valid_depth is not None \
    else cfg_get(config, "depth", "min_valid_depth", default=500)
```

```yaml
# config.yaml
depth:
  min_valid_depth: 500
```

## Key Lessons

1. **Always filter in sync** — depth, jpg, odom_matched.txt, and rgb_camera_poses.txt must all stay aligned
2. **Use mapping.txt for 0622** — it's the authoritative bin↔jpg link
3. **Move, don't delete** — `_filtered_out/` directories allow inspection
4. **Skip-if-done with supplementary check** — check `_filtered_out/` existence, but also verify odom/poses were filtered (use marker file)
5. **Thread `fmt` through** — both 0622 and 0707 need support
6. **`removed_bins` must include both `stem` and `stem + ".bin"`** — odom/pose files use bare names without `.bin` suffix. Using only one form causes silent match failures where the filter appears to succeed but odom/poses are never actually filtered
7. **Don't reference variables from the main path in the skip block** — the skip block runs independently; any variables like `depth_to_jpg` defined in the main filtering logic won't exist when skipped
