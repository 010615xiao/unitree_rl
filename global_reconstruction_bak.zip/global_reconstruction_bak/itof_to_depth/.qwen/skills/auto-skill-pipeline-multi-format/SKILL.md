---
name: pipeline-multi-format
description: How to add a new dataset format to the iTOF-to-depth pipeline (pipeline.py + convert_script/) and reconstruction (build_pointcloud.py)
source: auto-skill
extracted_at: '2026-07-07T13:14:22.279Z'
---

# Adding a New Dataset Format to the Pipeline

When a new dataset format needs to be supported (e.g. a future "0808" format alongside existing "0622" and "0707"), follow this systematic approach:

## 1. Identify format differences

Determine what varies between formats:
- **Directory structure**: which subdirectories and files exist (e.g. `jpg_bin/` vs `pointcloud1/`)
- **File naming**: timestamp-based vs name-based matching
- **Exposure scheme**: dual-exposure (long/short requiring fusion) vs multi-source overlay (pc1/pc2)
- **Pose format**: different odometry file formats (e.g. `OdomPose.txt` vs `odometry.txt`)
- **Pose column layout**: delimiter (tab vs space), column indices for x/y/yaw/roll/pitch
- **Pose dedup ratio**: how many pose entries per frame (e.g. 2:1 for 0622, 1:1 for 0707)

## 2. Update auto-detection (`detect_format()`)

Add a new branch in `pipeline.py:detect_format()` checking for unique directory/file markers of the new format. Check the most specific format first.

## 3. Update `match_data.py`

Add a new `match_<format>()` function in `convert_script/match_data.py` and wire it into the `--format` dispatch. Pay attention to delimiter differences (tab vs space) when parsing odometry files.

## 4. Thread `fmt` through pipeline steps

Each step function in `pipeline.py` already accepts `fmt: str`. Add a new conditional branch:

| Step | What to change |
|------|---------------|
| `step1_match_data` | Check file, pass `--format` to match_data.py |
| `step2_convert_depth` | Map bin subdirectory names (e.g. `bin_new` → `depth_new`) |
| `step3_fuse_depth` | Both formats use simple overlay in pipeline.py (no external script). 0622: long priority (`np.where(long > 0, long, short)`). 0707: pc1 priority (`np.where(pc1 > 0, pc1, pc2)`). All formats produce `depth_fused/` |
| `step4_mask_depth` | Always reads from `depth_fused/` (unified across formats after step3) |
| `step5_odom_to_camera_pose` | Pass `--format` to `odom_to_camera_pose.py`; update script's `iter_odom_lines()` separator and `write_outputs()` column mapping |
| `_export_poses` | Adjust dedup stride if needed; also check column count (see gotcha below) |
| `step7_export` | Conditional odom dedup (stride vs 1:1 copy) |

## 5. Update `odom_to_camera_pose.py`

When adding a new format, update the script to handle:
- **Delimiter**: `iter_odom_lines()` uses `"\t"` or `" "` based on format
- **Column extraction**: `write_outputs()` extracts x/y/yaw/roll/pitch from format-specific columns
- **Output formatting**: Use appropriate separator and update correct column indices

## 6. Update CLI and pre-checks

- Add new format to `--format` choices in `argparse` (both pipeline.py and odom_to_camera_pose.py)
- Add format-specific pre-checks (required directories/files)

## 7. Key design principles

- **Default to auto-detect**: `--format` is optional; `detect_format()` is the fallback
- **Unified output directories**: All formats should produce the same intermediate directories (`depth_fused/`, `depth_fused_masked/`) so downstream steps are format-agnostic
- **Format-aware fusion**: Different formats may have different fusion strategies (dual-exposure vs overlay), but all converge to `depth_fused/`
- **Keep step signatures stable**: add `fmt` as a keyword arg with default `"0622"` for backward compatibility
- **Skip-existing logic**: each step checks for output existence before running — this works across formats as long as the check file is format-appropriate

## 8. Gotcha: variable column count in `rgb_camera_poses.txt`

Different formats produce different numbers of whitespace-separated fields per line in `rgb_camera_poses.txt` because empty columns collapse under `str.split()`:

- **0622**: `name \t enc_time \t time_str \t m00 ... m33` → 18+ parts after `split()`
- **0707**: `name \t \t m00 ... m33` → 17 parts (enc_time is empty, collapses)

**Rule**: `_export_poses` must use `len(parts) >= 17` (not `>= 18`) and extract the matrix with `parts[-16:]` so it works for any format regardless of how many leading metadata columns exist. When adding a new format, verify how many non-matrix columns `odom_to_camera_pose.py` writes and ensure the threshold in `_export_poses` accommodates it.

## 9. Reconstruction side: `build_pointcloud.py` format support

The reconstruction module (`global_reconstruction/reconstruction/build_pointcloud.py`) also reads `odom_matched_camera.txt` and must support the same formats.

**Key difference from pipeline**: reconstruction uses an **explicit env var** (`GLOBAL_RECON_DATA_FORMAT`) rather than auto-detection, defaulting to `"0622"`.

### How it works

- `DATA_FMT = os.environ.get("GLOBAL_RECON_DATA_FORMAT", "0622")` at module level
- `load_odom_camera(path, fmt=DATA_FMT)` — explicit `fmt` parameter, no auto-detection
  - 0622: tab-sep, cols 1/2/3/4/5 = x(mm)/y(mm)/yaw/pitch/roll
  - 0707: space-sep, cols 6/7/8 = x(mm)/y(mm)/yaw, no pitch/roll (default 0)
- `load_poses_from_odom_camera(data_dir)` reads `DATA_FMT` and passes it through

### Usage

```bash
# Default 0622 format
GLOBAL_RECON_DATA_DIR=./datasets/itof_0622 python -m global_reconstruction.reconstruction.build_pointcloud

# Specify 0707 format
GLOBAL_RECON_DATA_DIR=./datasets/itof_0707 GLOBAL_RECON_DATA_FORMAT=0707 python -m global_reconstruction.reconstruction.build_pointcloud
```

### When adding a new format

1. Add a new branch in `load_odom_camera()` for the format's delimiter, column indices, and which fields exist
2. Update the docstring to document the new format's column layout
3. User sets `GLOBAL_RECON_DATA_FORMAT=<new_format>` when running reconstruction
