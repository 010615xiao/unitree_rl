---
name: pointcloud-reconstruction
description: How to reconstruct colored point clouds from iTOF depth + poses using build_pointcloud.py, including frame selection and trajectory analysis
source: auto-skill
extracted_at: '2026-07-16T13:32:48.791Z'
---

# Point Cloud Reconstruction from iTOF Data

## build_pointcloud.py Usage

Reconstructs colored scene point clouds from depth maps + camera poses + RGB images.

```bash
# Full reconstruction with RGB coloring
python build_pointcloud.py --voxel-size 0.03 --trajectory

# Use specific depth source (depth_fused, depth_pc1, depth_pc2)
python build_pointcloud.py --depth-dir data/depth_pc1 --voxel-size 0.03

# Reconstruct only a frame range
python build_pointcloud.py --frame-range 4940:4975 --voxel-size 0.01

# Custom output path
python build_pointcloud.py --output result.ply
```

### Key Parameters

| Flag | Default | Description |
|------|---------|-------------|
| `--depth-dir` | `data/depth_fused/` | Depth source directory |
| `--voxel-size` | `0.0` (off) | Voxel downsampling in meters |
| `--frame-range` | all | Frame range `start:end` (inclusive) |
| `--trajectory` | off | Also output `trajectory.ply` (blue→red time gradient) |
| `--max-depth` | `5.0` | Max depth in meters |
| `--output` | `data/pointcloud_fused.ply` | Output PLY path |

### Outputs

- `data/pointcloud_fused.ply` — Scene point cloud with RGB colors
- `data/trajectory.ply` — Camera trajectory (when `--trajectory`), colored blue→red by time

## Critical: Name-Based Matching

**Always match depth files to poses by filename stem, never by index.**

After filtering steps (like step3.5), depth and pose files may have different counts. Index-based pairing causes silent misalignment — wrong poses applied to wrong frames.

The script builds `name → pose` and `name → jpg` dictionaries, then pairs by stem:

```python
# Build mappings
name_to_pose = {}
for T, line_text in zip(poses, pose_lines):
    name_to_pose[line_text.split()[0]] = T

# Pair by stem
for df in depth_files:
    if df.stem in name_to_pose:
        pairs.append((df, name_to_pose[df.stem], name_to_jpg.get(df.stem)))
```

This handles:
- Filtered datasets where depth/pose counts differ
- 0622 format where poses have 2:1 dedup
- Missing RGB images (gracefully skips color)

## Trajectory Analysis: Finding Straight Segments

To find the longest straight-line segment from camera poses:

```python
import numpy as np

# Load camera positions from rgb_camera_poses.txt
pts = np.array([T[:3,3] for T in poses])  # (N, 3)

# Compute displacement directions (XY plane)
disp = np.diff(pts[:, :2], axis=0)
disp_unit = disp / np.linalg.norm(disp, axis=1)[:, np.newaxis]

# Sliding window: find longest segment where consecutive displacement angles < threshold
threshold_deg = 30.0
best_dist = 0
cur_start = 0
for i in range(1, len(disp_unit)):
    angle = np.degrees(np.arccos(np.clip(np.dot(disp_unit[cur_start], disp_unit[i]), -1, 1)))
    if angle > threshold_deg:
        seg_dist = np.linalg.norm(pts[i] - pts[cur_start])
        if seg_dist > best_dist:
            best_dist = seg_dist
            best_start, best_end = cur_start, i
        cur_start = i
```

**Use displacement direction, not camera facing direction.** The camera may rotate while moving straight (or vice versa). Displacement between consecutive positions is the reliable indicator of actual movement direction.

## trajectory_to_pointcloud.py Format Auto-Detection

The trajectory script auto-detects 0622 vs 0707 format by checking the delimiter:

```python
def detect_odom_format(path):
    with open(path) as f:
        for line in f:
            if line.strip() and not line.startswith("#"):
                return "0622" if "\t" in line else "0707"
    return "0707"
```

- **0622**: tab-separated, cols 1/2/3 = x(mm)/y(mm)/yaw(rad)
- **0707**: space-separated, cols 6/7/8 = x(mm)/y(mm)/yaw(rad)

Always guard against empty arrays after parsing:
```python
if len(pts_odom) == 0:
    print("!! Cannot parse odom file")
    return
```
