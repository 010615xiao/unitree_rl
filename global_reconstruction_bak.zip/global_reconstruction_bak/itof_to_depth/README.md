# iTOF to Depth — 预处理管线

将 iTOF（间接飞行时间）传感器的原始数据转换为标准 RGB-D 数据集，供 `global_reconstruction/` 主流程直接使用。

## 数据流

```
原始数据 (OdomPose.txt + jpg_bin/)
  │
  ├─ Step 1: match_data        时间戳对齐 (jpg + 2bin + odom)
  ├─ Step 2: convert_depth     bin -> npy (int16 -> float32)
  ├─ Step 3: fuse_depth        双曝光融合 (long + short -> fused)
  ├─ Step 4: mask_depth        远距离遮罩 (>2.5m -> 0, mm -> m)
  ├─ Step 5: odom_to_camera    里程计 -> 相机 4x4 位姿
  ├─ Step 6: LingBot-Depth     稀疏 -> 稠密深度补全
  └─ Step 7: export            导出为 da3_ezviz 标准格式
  │
  ▼
datasets/<name>/
  rgb/              00000.jpg ...
  depth/            00000.npy ...      (float32, 米, inf=无效)
  conf/             00000_conf.npy ... (float32, [0,1])
  camera_poses.txt  每行 16 个浮点数 (row-major 4x4 T_c2w)
  intrinsic.txt     每行: fx fy cx cy
```

## 快速开始

```bash
# 最简用法 — 所有参数从 config.yaml 读取
python itof_to_depth/pipeline.py

# 指定数据集名称
python itof_to_depth/pipeline.py --name itof_0617

# 覆盖部分参数 (其余仍从 config 读取)
python itof_to_depth/pipeline.py --name itof_0617 --camera_height 0.08

# 中间数据已存在，仅执行导出
python itof_to_depth/pipeline.py --export-only

# 跳过 LingBot-Depth 推理 (已有稠密深度)
python itof_to_depth/pipeline.py --skip-infer
```

## 配置

`itof_to_depth/config.yaml` 保存所有默认参数：

```yaml
defaults:
  raw_dir: "itof_to_depth/itof"        # 原始数据 (jpg_bin/ + OdomPose.txt)
  work_dir: "itof_to_depth"             # 中间产物
  name: "itof_0616"                     # 输出数据集名

camera:
  height: 0.065                         # 相机高度 (m)
                                        # 设为 "auto" 或 "sam3": 用 SAM3 自动计算
                                        # (需要 SAM3 服务运行在 services.sam3_url)
  intrinsics_file: "data/intrinsics.txt"  # 内参文件 (相对于 work_dir)

depth:
  max_depth: 2.5                        # 遮罩最大深度 (m)

# ================= SAM3 服务 =================
services:
  sam3_url: "http://localhost:20023"     # SAM3 分割服务 (camera.height=auto 时使用)

lingbot:
  model: "external/lingbot-depth/model/model.pt"
  device: "auto"
  filter_flying: 0.0
```

CLI 参数优先级高于 config.yaml。内参文件**自动检测** (`work_dir/data/intrinsics.txt`)，无需手动指定。

## 参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--raw_dir` | (必填) | 原始数据目录，包含 `jpg_bin/` 和 `OdomPose.txt` |
| `--work_dir` | = raw_dir | 中间产物目录，中间文件写入 `<work_dir>/data/` |
| `--name` | (必填) | 输出数据集名称，输出到 `datasets/<name>/` |
| `--intrinsics` | - | 内参文件路径 (会被拷贝到 `data/intrinsics.txt`) |
| `--camera_height` | 0.065 | 相机高度 (m) |
| `--max_depth` | 2.5 | 遮罩最大深度 (m) |
| `--model` | `external/lingbot-depth/model/model.pt` | LingBot-Depth 模型 |
| `--device` | auto | 推理设备 (auto/cuda/cpu) |
| `--filter_flying` | 0.0 | LingBot 边缘裁剪比例 |
| `--skip_infer` | false | 跳过 Step 6 (LingBot-Depth) |
| `--export_only` | false | 仅执行 Step 7 (导出) |
| `--output_dir` | `datasets/<name>/` | 自定义输出路径 |

## 与主项目对接

导出的数据集可被 `global_reconstruction/` 的 `DatasetAdapter` 自动识别为 `da3_ezviz` 格式：

```bash
# 方式 1: 修改 config.yaml
data:
  default_dir: "datasets/itof_0617"

# 方式 2: 环境变量
GLOBAL_RECON_DATA_DIR=datasets/itof_0617 \
    python -m global_reconstruction.reconstruction.reconstruct_and_segment
```

## 目录结构

```
itof_to_depth/
  pipeline.py            管线主入口 (Step 1-7)
  convert_script/        各步骤独立脚本
    match_data.py          Step 1: 时间戳对齐
    convert_depth.py       Step 2: bin -> npy
    fuse_depth.py          Step 3: 双曝光融合
    mask_depth.py          Step 4: 远距离遮罩
    odom_to_camera_pose.py Step 5: 位姿转换
    visualize_pose_compare.py  位姿对比可视化 (调试用)
  data/                  中间产物和最终数据

external/lingbot-depth/  LingBot-Depth 模型 (第三方)
```

## 注意事项

- **双曝光**: 每张 jpg 对应 2 个 bin 文件 (long + short 曝光)，Step 3 融合两者
- **位姿去重**: `rgb_camera_poses.txt` 每个 jpg 有 2 条相同位姿，导出时取 stride=2
- **内参文件**: LingBot 硬编码读取 `<work_dir>/data/intrinsics.txt`，pipeline 会自动拷贝
- **断点续跑**: 每步检查输出是否已存在，存在则跳过，可安全重跑
