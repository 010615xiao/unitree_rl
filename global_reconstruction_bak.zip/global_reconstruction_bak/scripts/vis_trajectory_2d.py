"""对比两条轨迹 txt 在 2D 平面上的差异。

用法:
    python scripts/vis_trajectory_2d.py [--txt1 PATH] [--txt2 PATH] [--output PATH]

默认读取 output/vis_poses/da3_poses.txt 和 output/vis_poses/itof_poses.txt。
左图 IToF, 右图 DA3。
"""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def load_da3_poses(path: Path) -> np.ndarray:
    """4x4 c2w 矩阵 (Y-up), 提取 X-Z 平面作为俯视图 (不旋转)"""
    positions = []
    with open(path) as f:
        for line in f:
            vals = line.strip().split()
            if len(vals) < 16:
                continue
            T = np.array([float(v) for v in vals]).reshape(4, 4)
            positions.append([T[0, 3], T[2, 3]])
    return np.array(positions).reshape(-1, 2)


def load_itof_poses(path: Path) -> np.ndarray:
    """自动检测两种 IToF 格式:
      - tab 分隔, col 1/2 = x/y (mm)
      - 空格分隔, col 6/7 = x/y (mm)
    """
    positions = []
    with open(path) as f:
        first_line = f.readline()
        f.seek(0)
        use_tab = '\t' in first_line
        for line in f:
            parts = line.strip().split('\t' if use_tab else None)
            if use_tab:
                if len(parts) < 3:
                    continue
                positions.append([float(parts[1]) / 1000.0, float(parts[2]) / 1000.0])
            else:
                if len(parts) < 8:
                    continue
                positions.append([float(parts[6]) / 1000.0, float(parts[7]) / 1000.0])
    return np.array(positions).reshape(-1, 2)


def plot_trajectory(ax, pts, title, color):
    n = len(pts)
    t = np.linspace(0.15, 1, n)
    cmap = plt.get_cmap(color)
    # 连线 (用多段线实现渐变颜色)
    for i in range(n - 1):
        ax.plot(pts[i:i+2, 0], pts[i:i+2, 1], color=cmap(t[i]), linewidth=1.2)
    ax.scatter([pts[0, 0]], [pts[0, 1]], c="green", s=80, marker="^", zorder=5, label="Start")
    ax.scatter([pts[-1, 0]], [pts[-1, 1]], c="red", s=80, marker="s", zorder=5, label="End")
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_title(title)
    ax.legend(fontsize=8)
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.3)


def main():
    parser = argparse.ArgumentParser(description="2D trajectory comparison")
    parser.add_argument("--txt1", type=Path, default="output/vis_poses/da3_poses.txt")
    parser.add_argument("--txt2", type=Path, default="output/vis_poses/itof_poses.txt")
    parser.add_argument("--output", type=Path, default="output/vis_poses/trajectory_comparison.png")
    args = parser.parse_args()

    pts_da3 = load_da3_poses(args.txt1)
    pts_itof = load_itof_poses(args.txt2)

    print(f"DA3 : {pts_da3.shape[0]} frames, X=[{pts_da3[:,0].min():.3f}, {pts_da3[:,0].max():.3f}] Z=[{pts_da3[:,1].min():.3f}, {pts_da3[:,1].max():.3f}]")
    print(f"IToF: {pts_itof.shape[0]} frames, X=[{pts_itof[:,0].min():.3f}, {pts_itof[:,0].max():.3f}] Y=[{pts_itof[:,1].min():.3f}, {pts_itof[:,1].max():.3f}]")

    # 用前两个位姿的方向向量对齐 DA3 到 IToF
    dir_itof = pts_itof[1] - pts_itof[0]
    dir_da3 = pts_da3[1] - pts_da3[0]
    angle_itof = np.arctan2(dir_itof[1], dir_itof[0])
    angle_da3 = np.arctan2(dir_da3[1], dir_da3[0])
    rot_angle = angle_itof - angle_da3  # DA3 需要旋转的角度
    print(f"  IToF 初始方向: {np.rad2deg(angle_itof):.1f}°")
    print(f"  DA3  初始方向: {np.rad2deg(angle_da3):.1f}°")
    print(f"  DA3 旋转角度:  {np.rad2deg(rot_angle):.1f}°")

    c, s = np.cos(rot_angle), np.sin(rot_angle)
    R = np.array([[c, -s], [s, c]])
    pts_da3 = (pts_da3 - pts_da3[0]) @ R.T + pts_itof[0]

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    plot_trajectory(axes[0], pts_itof, "IToF Trajectory", "Reds")
    plot_trajectory(axes[1], pts_da3, "DA3 Trajectory", "Blues")
    # 统一坐标范围
    all_x = np.concatenate([pts_itof[:, 0], pts_da3[:, 0]])
    all_y = np.concatenate([pts_itof[:, 1], pts_da3[:, 1]])
    pad = 2.0
    xlim = (all_x.min() - pad, all_x.max() + pad)
    ylim = (all_y.min() - pad, all_y.max() + pad)
    for ax in axes:
        ax.set_xlim(xlim)
        ax.set_ylim(ylim)
    fig.tight_layout()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=150)
    print(f"Saved: {args.output}")


if __name__ == "__main__":
    main()
