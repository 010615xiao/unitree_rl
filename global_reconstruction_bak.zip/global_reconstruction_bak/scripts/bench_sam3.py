#!/usr/bin/env python3
"""Benchmark SAM3 segmentation latency.

Tests:
  1. /health          — round-trip HTTP latency
  2. /predict x1      — single prompt, single image
  3. /predict_batch   — N prompts, single image (real pipeline scenario)
  4. Payload size     — response JSON size for mask transfer

Usage:
  python scripts/bench_sam3.py --image <path> [--prompts 8] [--runs 3]
"""

import argparse
import json
import sys
import time

import requests

SAM3_BASE = "http://localhost:20023"

DEFAULT_PROMPTS = [
    "floor", "wall", "door", "window",
    "chair", "table", "sofa", "shelf",
    "tv", "monitor", "lamp", "plant",
    "person", "box", "cabinet", "vending_machine",
]


def bench_health(runs=3):
    """Measure /health round-trip."""
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        r = requests.get(f"{SAM3_BASE}/health", timeout=5)
        times.append(time.perf_counter() - t0)
    return times


def bench_predict(image_path, prompt, runs=3):
    """Measure /predict with a single prompt."""
    payload = {"image_path": image_path, "text": prompt, "confidence_threshold": 0.35}
    times = []
    resp_size = 0
    num_masks = 0
    for i in range(runs):
        t0 = time.perf_counter()
        r = requests.post(f"{SAM3_BASE}/predict", json=payload, timeout=60)
        elapsed = time.perf_counter() - t0
        times.append(elapsed)
        if i == 0:
            resp_size = len(r.content)
            data = r.json()
            if data.get("success"):
                num_masks = len(data.get("masks", []))
    return times, resp_size, num_masks


def bench_batch(image_path, prompts, runs=3, mask_format="json"):
    """Measure /predict_batch with multiple prompts."""
    payload = {"image_path": image_path, "texts": prompts,
               "confidence_threshold": 0.35, "mask_format": mask_format}
    times = []
    resp_size = 0
    total_masks = 0
    per_prompt = {}
    for i in range(runs):
        t0 = time.perf_counter()
        r = requests.post(f"{SAM3_BASE}/predict_batch", json=payload, timeout=120)
        elapsed = time.perf_counter() - t0
        times.append(elapsed)
        if i == 0:
            resp_size = len(r.content)
            data = r.json()
            if data.get("success"):
                for name, seg in data["results"].items():
                    mask_key = "masks_b64" if mask_format == "base64_png" else "masks"
                    n = len(seg.get(mask_key, []))
                    total_masks += n
                    per_prompt[name] = {
                        "masks": n,
                        "scores": [round(s, 3) for s in seg.get("scores", [])],
                    }
    return times, resp_size, total_masks, per_prompt


def main():
    parser = argparse.ArgumentParser(description="Benchmark SAM3 latency")
    parser.add_argument("--image", required=True, help="Path to test image")
    parser.add_argument("--prompts", type=int, default=8,
                        help="Number of prompts for batch test (default: 8)")
    parser.add_argument("--runs", type=int, default=3,
                        help="Repetitions per test (default: 3)")
    args = parser.parse_args()

    try:
        r = requests.get(f"{SAM3_BASE}/health", timeout=5)
        print(f"SAM3 server: {r.json()}")
    except Exception as e:
        print(f"SAM3 server not reachable: {e}")
        sys.exit(1)

    prompts = DEFAULT_PROMPTS[:args.prompts]
    print(f"\nImage: {args.image}")
    print(f"Batch prompts ({len(prompts)}): {prompts}")
    print(f"Runs per test: {args.runs}\n")
    print("=" * 70)

    # --- Test 1: Health ---
    times = bench_health(args.runs)
    avg = sum(times) / len(times)
    print(f"[1] /health round-trip")
    print(f"    avg={avg*1000:.1f}ms  min={min(times)*1000:.1f}ms  max={max(times)*1000:.1f}ms")

    # --- Test 2: Single /predict (json vs base64_png) ---
    print(f"\n[2] /predict single prompt — JSON vs base64_png")
    for fmt in ["json", "base64_png"]:
        for p in ["floor", "chair"]:
            payload = {"image_path": args.image, "text": p, "mask_format": fmt}
            times_list = []
            resp_size = 0
            for i in range(args.runs):
                t0 = time.perf_counter()
                r = requests.post(f"{SAM3_BASE}/predict", json=payload, timeout=30)
                times_list.append(time.perf_counter() - t0)
                if i == 0:
                    resp_size = len(r.content)
            a = sum(times_list) / len(times_list)
            print(f"    [{fmt:>11s}] '{p}': avg={a*1000:.0f}ms  resp={resp_size/1024:.0f}KB")

    # --- Test 3: /predict_batch comparison ---
    print(f"\n[3] /predict_batch — JSON vs base64_png")
    for n in [4, 8, min(16, len(DEFAULT_PROMPTS))]:
        batch_prompts = DEFAULT_PROMPTS[:n]
        for fmt in ["json", "base64_png"]:
            times, resp_size, total_masks, _ = bench_batch(
                args.image, batch_prompts, runs=args.runs, mask_format=fmt
            )
            a = sum(times) / len(times)
            print(f"    [{fmt:>11s}] prompts={n:2d}: avg={a*1000:.0f}ms  "
                  f"masks={total_masks}  resp={resp_size/1024:.0f}KB")

    # --- Test 4: Payload size comparison ---
    print(f"\n[4] Payload size comparison (8-prompt batch)")
    for fmt in ["json", "base64_png"]:
        payload = {"image_path": args.image, "texts": DEFAULT_PROMPTS[:8],
                   "confidence_threshold": 0.35, "mask_format": fmt}
        r = requests.post(f"{SAM3_BASE}/predict_batch", json=payload, timeout=120)
        print(f"    [{fmt:>11s}] response={len(r.content)/1024:.0f}KB")

    print(f"\n{'=' * 70}")


if __name__ == "__main__":
    main()
