"""
Incremental side-by-side MP4:
  Left  — RGB frames in sequence
  Right — Growing global point cloud viewed from current camera pose

Each frame's depth is backprojected, transformed to global frame, and
accumulated into the global cloud. The right panel shows the cloud
as seen from the current camera — so you see the scene "build up" in real time.

Usage:
  python render_side_by_side.py --data_dir data_test_itof_loop --output out.mp4
"""

import argparse
import os
import glob
import numpy as np
import cv2
import open3d as o3d
from tqdm import tqdm


def load_data(data_dir):
    rgb_dir = os.path.join(data_dir, "rgb")
    depth_dir = os.path.join(data_dir, "depth")
    conf_dir = os.path.join(data_dir, "conf")
    poses_path = os.path.join(data_dir, "camera_poses.txt")
    intrinsic_path = os.path.join(data_dir, "intrinsic.txt")

    rgb_files = sorted(glob.glob(os.path.join(rgb_dir, "*.jpg")))
    if not rgb_files:
        rgb_files = sorted(glob.glob(os.path.join(rgb_dir, "*.png")))

    # Load poses and intrinsics
    all_poses = []
    with open(poses_path) as f:
        for line in f:
            vals = list(map(float, line.split()))
            if len(vals) == 16:
                all_poses.append(np.array(vals).reshape(4, 4))

    all_intrinsics = []
    with open(intrinsic_path) as f:
        for line in f:
            all_intrinsics.append(list(map(float, line.split())))

    # Only keep frames with complete data (rgb + depth + pose + intrinsic)
    valid_rgb, valid_depth, valid_conf = [], [], []
    valid_poses, valid_intrinsics = [], []
    for idx, rf in enumerate(rgb_files):
        stem = os.path.splitext(os.path.basename(rf))[0]
        dp = os.path.join(depth_dir, stem + ".npy")
        cp = os.path.join(conf_dir, stem + "_conf.npy")
        if os.path.exists(dp) and idx < len(all_poses) and idx < len(all_intrinsics):
            valid_rgb.append(rf)
            valid_depth.append(dp)
            valid_conf.append(cp if os.path.exists(cp) else None)
            valid_poses.append(all_poses[idx])
            valid_intrinsics.append(all_intrinsics[idx])

    n = len(valid_rgb)
    print(f"Loaded {n} valid frames (skipped {len(rgb_files) - n} incomplete)")
    return valid_rgb, valid_depth, valid_conf, valid_poses, np.array(valid_intrinsics)


def backproject_frame(depth, conf, pose, K, conf_threshold, rgb_bgr):
    """Backproject one frame's depth into global colored points."""
    h, w = depth.shape
    fx, fy, cx, cy = K

    if conf is not None:
        mask = conf > conf_threshold
    else:
        mask = depth > 0.05

    vi, ui = np.where(mask)
    z = depth[vi, ui]

    x = (ui - cx) * z / fx
    y = (vi - cy) * z / fy
    pts_cam = np.stack([x, y, z, np.ones_like(z)], axis=1)
    pts_global = (pose @ pts_cam.T).T[:, :3]

    colors = rgb_bgr[vi, ui][:, ::-1].astype(np.float64) / 255.0  # BGR→RGB float
    return pts_global, colors


def incremental_voxel_downsample(points, colors, voxel_size):
    """Fast voxel downsampling using open3d."""
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    pcd.colors = o3d.utility.Vector3dVector(colors)
    pcd = pcd.voxel_down_sample(voxel_size=voxel_size)
    return np.asarray(pcd.points), np.asarray(pcd.colors)


def project_points_to_image(points, colors, pose, K, W, H, max_depth=5.0):
    """Fast numpy projection: global points → camera view image."""
    fx, fy, cx, cy = K
    T_inv = np.linalg.inv(pose)

    # World → camera
    pts_cam = (T_inv[:3, :3] @ points.T).T + T_inv[:3, 3]
    z = pts_cam[:, 2]
    valid = (z > 0.01) & (z < max_depth)
    pts_cam = pts_cam[valid]
    cols = colors[valid]
    z = pts_cam[:, 2]

    # Project
    u = (fx * pts_cam[:, 0] / z + cx + 0.5).astype(np.int32)
    v = (fy * pts_cam[:, 1] / z + cy + 0.5).astype(np.int32)

    ib = (u >= 0) & (u < W) & (v >= 0) & (v < H)
    u, v, cols, z = u[ib], v[ib], cols[ib], z[ib]

    if len(u) == 0:
        return np.full((H, W, 3), 40, dtype=np.uint8)

    # Depth sort: near first, then np.unique keeps first = nearest
    order = np.argsort(z)
    u, v, cols = u[order], v[order], cols[order]

    pixel_idx = v * W + u
    _, first_idx = np.unique(pixel_idx, return_index=True)
    pixel_idx = pixel_idx[first_idx]
    cols = cols[first_idx]

    img = np.full((H, W, 3), 40, dtype=np.uint8)
    rgb_bgr = (np.clip(cols, 0, 1) * 255).astype(np.uint8)[:, ::-1]
    img.flat[pixel_idx * 3] = rgb_bgr[:, 0]
    img.flat[pixel_idx * 3 + 1] = rgb_bgr[:, 1]
    img.flat[pixel_idx * 3 + 2] = rgb_bgr[:, 2]

    return img


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, required=True)
    parser.add_argument("--output", type=str, default="render_incremental.mp4")
    parser.add_argument("--fps", type=int, default=15)
    parser.add_argument("--conf_threshold", type=float, default=0.75)
    parser.add_argument("--voxel_size", type=float, default=0.01,
                        help="Voxel size for incremental downsampling (meters)")
    parser.add_argument("--downsample_every", type=int, default=10,
                        help="Run voxel downsample every N frames to control growth")
    parser.add_argument("--max_depth", type=float, default=15.0,
                        help="Max depth distance for projection rendering (meters)")
    parser.add_argument("--point_size", type=int, default=1,
                        help="Point splat size in pixels (1=no splat)")
    args = parser.parse_args()

    rgb_files, depth_files, conf_files, poses, intrinsics = load_data(args.data_dir)
    n_frames = len(rgb_files)

    sample_depth = np.load(depth_files[0])
    dh, dw = sample_depth.shape
    sample_rgb = cv2.imread(rgb_files[0])
    rh, rw = sample_rgb.shape[:2]
    print(f"RGB: {rw}x{rh}, Depth: {dw}x{dh}")

    # Use depth resolution as the common height; scale RGB to match
    canvas_h = dh
    rgb_scale = dh / rh
    rw_scaled = int(rw * rgb_scale)
    canvas_w = rw_scaled + dw
    print(f"Canvas: {canvas_w}x{canvas_h} (RGB scaled to {rw_scaled}x{canvas_h})")

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(args.output, fourcc, args.fps, (canvas_w, canvas_h))

    # Incremental accumulation
    all_points = []
    all_colors = []
    total_pts = 0

    for i in tqdm(range(n_frames), desc="Rendering incremental"):
        # Load this frame's data
        depth = np.load(depth_files[i])
        conf = np.load(conf_files[i]) if conf_files[i] is not None else None
        rgb_bgr = cv2.imread(rgb_files[i])
        rgb_resized = cv2.resize(rgb_bgr, (dw, dh))

        # Backproject to global
        new_pts, new_cols = backproject_frame(
            depth, conf, poses[i], intrinsics[i], args.conf_threshold, rgb_resized
        )
        all_points.append(new_pts)
        all_colors.append(new_cols)
        total_pts += len(new_pts)

        # Periodic voxel downsample to keep memory/render manageable
        if (i + 1) % args.downsample_every == 0:
            merged_pts = np.concatenate(all_points, axis=0)
            merged_col = np.concatenate(all_colors, axis=0)
            merged_pts, merged_col = incremental_voxel_downsample(
                merged_pts, merged_col, args.voxel_size
            )
            all_points = [merged_pts]
            all_colors = [merged_col]

        # Current accumulated cloud
        cur_pts = np.concatenate(all_points, axis=0)
        cur_col = np.concatenate(all_colors, axis=0)

        # Left: RGB (scaled to match depth height)
        rgb = cv2.imread(rgb_files[i])
        rgb = cv2.resize(rgb, (rw_scaled, canvas_h))

        # Right: project current cloud from current pose
        right = project_points_to_image(cur_pts, cur_col, poses[i],
                                        intrinsics[i], dw, dh,
                                        max_depth=args.max_depth)

        if args.point_size > 1:
            kernel = np.ones((args.point_size, args.point_size), np.uint8)
            mask = (right[:, :, 0] > 40) | (right[:, :, 1] > 40) | (right[:, :, 2] > 40)
            dilated = cv2.dilate(right, kernel, iterations=1)
            right[~mask] = dilated[~mask]

        canvas = np.hstack([rgb, right])

        # Overlay
        cv2.putText(canvas, f"Frame {i+1}/{n_frames}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(canvas, "RGB", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 1)
        cv2.putText(canvas, f"3D Cloud ({len(cur_pts)//1000}K pts)", (rw_scaled + 10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 1)

        out.write(canvas)

    out.release()
    print(f"\nOutput: {args.output}")
    print(f"Resolution: {canvas_w}x{canvas_h}, Frames: {n_frames}, FPS: {args.fps}")
    print(f"Duration: {n_frames / args.fps:.1f}s")


if __name__ == "__main__":
    main()
