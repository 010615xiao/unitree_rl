#!/usr/bin/env python3
"""
SAM 3.1 分割服务器
支持文本提示和几何提示（box/point）

使用示例:
    python sam3_server.py --checkpoint_path /path/to/sam3.1_multiplex.pt --port 20023
"""

import base64
import cv2
import io
import logging
import numpy as np
import os
import sys
import torch
import argparse
import traceback
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image

# 添加 sam3 到路径
SAM3_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sam3-main')
if SAM3_DIR not in sys.path:
    sys.path.insert(0, SAM3_DIR)

from sam3.model_builder import build_sam3_image_model
from sam3.model.sam3_image_processor import Sam3Processor

# 配置日志格式
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)

app = Flask(__name__)
CORS(app)

# 全局变量
model = None
processor = None
device = "cuda" if torch.cuda.is_available() else "cpu"
DEFAULT_CONFIDENCE_THRESHOLD = 0.5


def load_model(model_path: str):
    """加载 SAM 3.1 模型"""
    global model, processor

    try:
        logging.info(f"正在加载 SAM 3.1 模型：{model_path}")

        # BPE tokenizer 路径
        bpe_path = os.path.join(SAM3_DIR, "sam3", "assets", "bpe_simple_vocab_16e6.txt.gz")
        if not os.path.exists(bpe_path):
            alt_paths = [
                os.path.join(SAM3_DIR, "assets", "bpe_simple_vocab_16e6.txt.gz"),
                "./sam3-main/sam3/assets/bpe_simple_vocab_16e6.txt.gz",
            ]
            for p in alt_paths:
                if os.path.exists(p):
                    bpe_path = p
                    break
            else:
                raise FileNotFoundError(f"找不到 BPE tokenizer 文件: {bpe_path}")

        logging.info(f"使用 BPE 路径：{bpe_path}")

        model = build_sam3_image_model(
            bpe_path=bpe_path,
            checkpoint_path=model_path,
            device=device,
            eval_mode=True,
            load_from_HF=False,
        )
        processor = Sam3Processor(model, device=device, confidence_threshold=DEFAULT_CONFIDENCE_THRESHOLD)

        logging.info("SAM 3.1 模型加载完成！")
        return True
    except Exception as e:
        logging.error(f"模型加载失败：{e}")
        logging.error(traceback.format_exc())
        return False


def load_image_from_data(data: dict):
    """从请求数据加载图像"""
    if "image_path" in data:
        image_path = data["image_path"]
        if not os.path.exists(image_path):
            return None, f"图像文件不存在：{image_path}"
        image = Image.open(image_path).convert("RGB")
        return image, None
    elif "image" in data:
        image_bytes = base64.b64decode(data['image'])
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        return image, None
    else:
        return None, "需要提供 image 或 image_path"


@app.route('/health', methods=['GET'])
def health_check():
    """健康检查接口"""
    try:
        return jsonify({
            "status": "ok",
            "model": "SAM3.1",
            "device": device,
        })
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500


@app.route('/predict', methods=['POST'])
def predict():
    """
    SAM 3 分割预测 - 支持文本提示和几何提示

    输入:
        - image: base64 编码的图像 或 image_path: 图像路径
        - text: 文本提示 (例如 "a red car")
        - boxes: [N, 4] 边界框数组 [x1, y1, x2, y2] (可选)
        - confidence_threshold: 置信度阈值 (默认 0.35)
    输出:
        - masks: [N, H, W] 掩码数组（列表形式）
        - scores: [N] 置信度分数
        - boxes: [N, 4] 边界框 [x0, y0, x1, y1]
    """
    global model, processor

    if model is None:
        return jsonify({"error": "模型未加载"}), 500

    try:
        data = request.get_json()

        # 加载图像
        image, error = load_image_from_data(data)
        if error:
            return jsonify({"error": error}), 400

        # 设置图像
        inference_state = processor.set_image(image)

        # 文本提示
        text_prompt = data.get("text", None)
        if text_prompt:
            output = processor.set_text_prompt(state=inference_state, prompt=text_prompt)
        else:
            return jsonify({"error": "需要提供 text 文本提示"}), 400

        # 可选：添加几何提示（box）
        if "boxes" in data and len(data["boxes"]) > 0:
            for box in data["boxes"]:
                # 转换为归一化的 [center_x, center_y, width, height] 格式
                x1, y1, x2, y2 = box
                w, h = image.size
                cx, cy = (x1 + x2) / (2 * w), (y1 + y2) / (2 * h)
                bw, bh = (x2 - x1) / w, (y2 - y1) / h
                processor.add_geometric_prompt(
                    box=[cx, cy, bw, bh],
                    label=True,
                    state=inference_state,
                )
            output = inference_state

        # 获取结果
        masks = output.get("masks", None)
        boxes = output.get("boxes", None)
        scores = output.get("scores", None)

        if masks is None or masks.numel() == 0:
            return jsonify({
                "success": True,
                "masks": [],
                "scores": [],
                "boxes": [],
                "message": "未检测到目标"
            })

        # 处理结果
        masks_list = []
        scores_list = []
        boxes_list = []

        for i in range(masks.shape[0]):
            mask = masks[i].squeeze().cpu().numpy()
            masks_list.append(mask.tolist())
            scores_list.append(float(scores[i].item()) if scores is not None else 1.0)
            if boxes is not None:
                boxes_list.append([float(x.item()) for x in boxes[i]])

        logging.info(f"分割完成，检测到 {len(masks_list)} 个对象")
        return jsonify({
            "success": True,
            "masks": masks_list,
            "scores": scores_list,
            "boxes": boxes_list,
            "image_shape": [image.size[1], image.size[0]],  # [H, W]
            "num_detections": len(masks_list)
        })

    except Exception as e:
        logging.error(f"推理失败：{e}")
        logging.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route('/segment', methods=['POST'])
def segment():
    """
    分割接口，使用文本提示 + 可选 box

    输入:
        - image: base64 编码的图像 或 image_path: 图像路径
        - text: 文本提示
        - box: [x1, y1, x2, y2] 单个边界框 (可选)
    输出:
        - mask: [H, W] 掩码（base64 编码）
        - score: 置信度分数
    """
    global model, processor

    if model is None:
        return jsonify({"error": "模型未加载"}), 500

    try:
        data = request.get_json()

        text_prompt = data.get("text", None)
        if not text_prompt:
            return jsonify({"error": "需要提供 text 文本提示"}), 400

        # 加载图像
        image, error = load_image_from_data(data)
        if error:
            return jsonify({"error": error}), 400

        # 设置图像并运行文本提示
        inference_state = processor.set_image(image)
        output = processor.set_text_prompt(state=inference_state, prompt=text_prompt)

        # 可选：添加 box 提示
        box = data.get("box", None)
        if box:
            w, h = image.size
            x1, y1, x2, y2 = box
            cx, cy = (x1 + x2) / (2 * w), (y1 + y2) / (2 * h)
            bw, bh = (x2 - x1) / w, (y2 - y1) / h
            processor.add_geometric_prompt(
                box=[cx, cy, bw, bh],
                label=True,
                state=inference_state,
            )
            output = inference_state

        # 获取结果
        masks = output.get("masks", None)
        scores = output.get("scores", None)

        if masks is None or masks.numel() == 0:
            return jsonify({
                "success": False,
                "message": "未检测到目标"
            })

        # 获取最高分的掩码
        best_idx = scores.argmax().item()
        mask = masks[best_idx].squeeze().cpu().numpy()
        score = float(scores[best_idx].item())

        mask_uint8 = (mask * 255).astype(np.uint8)

        # 编码掩码为 base64
        _, buffer = cv2.imencode('.png', mask_uint8)
        mask_base64 = base64.b64encode(buffer.tobytes()).decode('utf-8')

        logging.info(f"分割完成，最高分: {score:.3f}")
        return jsonify({
            "success": True,
            "mask": mask_base64,
            "score": score,
            "image_shape": [image.size[1], image.size[0]]
        })

    except Exception as e:
        logging.error(f"推理失败：{e}")
        logging.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500


@app.route('/infer', methods=['POST'])
def infer():
    """图像分割推理接口（/segment 的别名）"""
    return segment()


def main():
    parser = argparse.ArgumentParser(description='SAM 3.1 Server')
    parser.add_argument('--checkpoint_path', type=str, required=True,
                        help='Path to SAM 3.1 model checkpoint')
    parser.add_argument('--port', type=int, default=20023,
                        help='Port to run the server on (default: 20023)')
    parser.add_argument('--host', type=str, default='0.0.0.0',
                        help='Host to run the server on (default: 0.0.0.0)')

    args = parser.parse_args()

    logging.info("正在启动 SAM 3.1 服务器...")
    logging.info(f"模型路径：{args.checkpoint_path}")
    logging.info(f"服务端口：{args.port}")

    # 加载指定模型
    if not load_model(args.checkpoint_path):
        logging.error("无法启动服务器：模型加载失败")
        exit(1)

    logging.info("模型加载成功，正在启动服务器...")
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == '__main__':
    main()
