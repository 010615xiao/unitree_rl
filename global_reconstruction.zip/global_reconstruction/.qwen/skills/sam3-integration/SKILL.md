---
name: sam3-integration
description: Handle SAM3 server integration for text-prompted segmentation — box coordinate format, mask normalization, image size consistency, and detection limit configuration
source: auto-skill
extracted_at: '2026-05-28T12:09:11.730Z'
---

# SAM3 Integration

Handle box coordinates, masks, image size consistency, and detection limits when integrating the SAM3 segmentation server with the reconstruction pipeline.

## When to Use

- Calling SAM3 server for text-prompted object segmentation
- Processing SAM3 detection results (boxes, masks, scores)
- Creating grounded view artifacts (annotated images, bounding boxes)
- Configuring per-category detection limits

## Core Problem

The SAM3 server returns box coordinates as **[x0, y0, x1, y1] pixel coordinates** (already scaled to the original image file size). But the pipeline may resize images before passing them to downstream functions like `create_object_grounded_views`. Mismatched image dimensions cause bounding boxes and masks to be drawn in wrong positions.

## SAM3 Server Response Format

The SAM3 server (`sam3_server.py`) returns:

```python
{
    'success': True,
    'masks': [...],       # List of float32 masks in [0, 1]
    'scores': [...],      # Confidence scores
    'boxes': [...],       # Pixel [x0, y0, x1, y1] format (NOT normalized!)
    'image_shape': [H, W] # [height, width] of the actual image file
}
```

**Critical**: `boxes` are **[x0, y0, x1, y1] in pixel coordinates** — the server already converts from cxcywh and scales by image dimensions (see `sam3_image_processor.py` line ~204):

```python
boxes = box_ops.box_cxcywh_to_xyxy(out_bbox)   # convert to xyxy
scale_fct = torch.tensor([img_w, img_h, img_w, img_h]).to(self.device)
boxes = boxes * scale_fct[None, :]              # already scaled to pixels!
state["boxes"] = boxes
```

**Do NOT** treat boxes as normalized `[cx, cy, w, h]` — that was a bug that caused box coordinates to be multiplied by image size again, shifting them hundreds of pixels off.

## Processing SAM3 Boxes — Direct Pixel Use

Since boxes are already pixel coordinates, use them directly:

```python
detections = []
for i in range(len(masks_data)):
    mask = np.array(masks_data[i], dtype=np.float32)
    mask = (mask > 0.5).astype(np.uint8) * 255  # float [0,1] → uint8 0/255
    score = scores[i] if i < len(scores) else 0.5

    if i < len(boxes):
        box_px = [int(boxes[i][0]), int(boxes[i][1]), int(boxes[i][2]), int(boxes[i][3])]
    else:
        ys, xs = np.where(mask > 0)
        if len(xs) == 0:
            continue
        box_px = [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]

    detections.append({
        'mask': mask,
        'box': box_px,
        'score': score,
    })

# Sort by score, take top-N (configurable, default 5)
detections.sort(key=lambda d: d['score'], reverse=True)
detections = detections[:SAM3_MAX_DETECTIONS]
```

## Detection Limit Configuration

The per-category detection limit is configurable:

```yaml
# config.yaml
object_segmentation:
  sam3_max_detections_per_category: 5  # default 5, was previously hardcoded to 3
```

Corresponding constant in `reconstruct_and_segment.py`:

```python
SAM3_MAX_DETECTIONS = cfg.object_segmentation.get('sam3_max_detections_per_category', 3)
```

## Image Resizing and Box/Mask Scaling

The pipeline resizes color images to match depth resolution before processing:

```python
color = adapter.load_color(color_file)
if color.shape[:2] != depth.shape:
    color = cv2.resize(color, (depth.shape[1], depth.shape[0]))
```

But SAM3 processes the **original image file**, so its boxes and masks are in original image coordinates. The resize ratio is pre-computed **once per category** (not per detection) to avoid repeated file I/O:

```python
# Pre-compute (outside the per-detection loop):
_orig_sample = cv2.imread(str(color_file))
_sam3_orig_h, _sam3_orig_w = (_orig_sample.shape[:2]) if _orig_sample is not None else (orig_h, orig_w)
_need_resize = (_sam3_orig_h != orig_h or _sam3_orig_w != orig_w)
_sx, _sy = (orig_w / _sam3_orig_w, orig_h / _sam3_orig_h) if _need_resize else (1.0, 1.0)

# Inside the per-detection loop — for grounded views ONLY:
grounded_box = mask_data.get('box')
grounded_mask = mask_data.get('mask')
if _need_resize:
    if grounded_box is not None:
        grounded_box = [int(grounded_box[0] * _sx), int(grounded_box[1] * _sy),
                        int(grounded_box[2] * _sx), int(grounded_box[3] * _sy)]
    if grounded_mask is not None:
        grounded_mask = cv2.resize(grounded_mask.astype(np.float32),
                                   (orig_w, orig_h), interpolation=cv2.INTER_NEAREST).astype(np.uint8)

# 3D back-projection uses the ORIGINAL mask (mask_data['mask']) — mask_to_3d_points auto-resizes to depth dimensions
points_3d = mask_to_3d_points(mask_data['mask'], depth, K_frame, T_c2w, confidence, CONFIDENCE_THRESHOLD)

# Grounded views use the SCALED box/mask — they must match the resized image_rgb
grounded_view = create_object_grounded_views(
    image_path=color_file,
    image_rgb=color,          # resized image
    ...,
    box=grounded_box,         # scaled to match resized image
    mask=grounded_mask,       # scaled to match resized image
)
```

**Key design principle**: 3D point cloud projection and grounded view annotation use **different mask copies**:
- **3D projection**: original SAM3 mask → `mask_to_3d_points` internally resizes to match depth image
- **Grounded views**: scaled box/mask → must match the `image_rgb` (resized color image) dimensions

**Why this matters**: If you scale the mask before `mask_to_3d_points`, it will be resized twice (once manually, once internally), causing misalignment. Conversely, if you don't scale for `create_object_grounded_views`, annotations will be drawn in wrong positions.

## Mask Normalization

SAM3 masks are returned as float32 in [0, 1]:

```python
mask = (mask > 0.5).astype(np.uint8) * 255  # threshold at 0.5, scale to 0/255
```

**Why 255**: Downstream functions like `_mask_to_bbox_xyxy` and `mask > 128` expect uint8 masks with values 0 or 255.

## Verification

Check annotated images to verify box alignment:

```bash
ls unified_output/object_views/
```

**Expected**: The bounding box should tightly surround the detected object in `annotated.png`. If the box is offset or misaligned, check:
1. Are boxes being used as pixel coordinates (not normalized)?
2. Was the image resized between SAM3 detection and `create_object_grounded_views`?
3. Are box and mask coordinates properly scaled to match the resized image?
4. Was the mask accidentally resized before 3D back-projection (double-resize bug)?

## Common Pitfalls

1. **Treating boxes as normalized**: SAM3 returns `[x0, y0, x1, y1]` pixel coordinates, NOT normalized `[cx, cy, w, h]`. Multiplying them by image size again shifts boxes hundreds of pixels off.
2. **Not scaling boxes/masks after resize**: If the color image is resized before `create_object_grounded_views`, boxes and masks must be scaled proportionally.
3. **Double-resizing mask before 3D projection**: `mask_to_3d_points` auto-resizes masks internally — do NOT resize before calling it.
4. **Mask not thresholded**: Passing float32 masks directly to functions expecting uint8 causes incorrect results.
5. **Using image_path size instead of image_rgb size**: The file size may differ from the in-memory `image_rgb` shape after resizing.
6. **Reading original image per detection**: Pre-compute resize ratio outside the inner loop to avoid repeated `cv2.imread` calls.
