---
name: incremental-voxel-downsampling
description: Memory-efficient point cloud accumulation by voxel-downsampling incrementally every N frames instead of accumulating all raw points before a single downsample
source: auto-skill
extracted_at: '2026-05-27T12:01:54.954Z'
---

# Incremental Voxel Downsampling

Memory-efficient approach to accumulating large point clouds: instead of storing all raw points and downsampling once at the end, perform voxel downsampling incrementally every N frames, merging with previously downsampled results.

## When to Use

- Processing hundreds of frames without frame skipping (all frames contribute points)
- Each frame generates hundreds of thousands of 3D points (e.g., high-res depth maps upsampled to RGB resolution)
- Total accumulated points would reach hundreds of millions or billions
- Available RAM is limited

## Problem

Naive accumulation: every frame's points are appended to a list, then `np.vstack()` is called at the end before a single voxel downsample. For 477 frames at 1280x720 resolution, this produces ~2.7 billion raw points consuming ~15 GB of RAM before any filtering occurs.

## Solution: Incremental Merge-and-Downsample

Every N frames (e.g., 50), flush the current batch into a voxel-downsampled accumulator:

```python
# Before the loop
INCREMENTAL_DS_EVERY = 50
merged_points = np.empty((0, 3), dtype=np.float32)
merged_colors = np.empty((0, 3), dtype=np.uint8)
batch_points = []
batch_colors = []

# Inside the frame loop
for i, depth_file in enumerate(depth_files):
    # ... generate points from frame ...
    if len(points) > 0:
        batch_points.append(points)
        batch_colors.append(colors)

    # Incremental downsample every N frames (or on the last frame)
    if processed % INCREMENTAL_DS_EVERY == 0 or processed == total_frames:
        if batch_points:
            batch_pts = np.vstack(batch_points)
            batch_cols = np.vstack(batch_colors)

            # Merge with previously downsampled points
            if len(merged_points) > 0:
                batch_pts = np.vstack([merged_points, batch_pts])
                batch_cols = np.vstack([merged_colors, batch_cols])

            # Voxel downsample the combined set
            merged_points, merged_colors = voxel_downsample(
                batch_pts, batch_cols, VOXEL_SIZE)

            # Release batch memory
            batch_points = []
            batch_colors = []

# After loop — merged_points is already downsampled
```

## Why This Works

Voxel downsampling is **idempotent with merge**: downsampling (A ∪ B) gives the same result as downsampling (downsample(A) ∪ B) then downsampling again — because the voxel grid is deterministic. Each incremental step re-downsamples the full accumulated set, so the result converges to the same output as a single final downsample.

The key cost is that every N frames you re-process the already-downsampled points. But since downsampled points are small (millions, not billions), this overhead is negligible compared to the memory savings.

## Memory Profile Comparison

| Approach | Peak Memory (477 frames, 1280x720) |
|----------|-----------------------------------|
| Naive (all raw, downsample at end) | ~15 GB |
| Incremental (every 50 frames) | ~2 GB |

## Tuning INCREMENTAL_DS_EVERY

- **Smaller N** (e.g., 20): lower peak memory, slightly more overhead from re-downsampling
- **Larger N** (e.g., 100): higher peak memory, less overhead
- **50** is a good default for typical 3D reconstruction workloads

## Removing the Dense Pointcloud Save

When using incremental downsampling, the intermediate dense pointcloud is never fully materialized, so skip saving `global_pointcloud_dense.ply`. Only save the final `global_pointcloud.ply` (downsampled + denoised).

## Applying to Multiple Scripts

If the same accumulation pattern exists in multiple scripts (e.g., a standalone `build_pointcloud.py` and a combined `reconstruct_and_segment.py`), apply the pattern to all of them. Stale references to the old `all_points` list (e.g., in length checks during DBSCAN) must be cleaned up:

```python
# OLD (broken after refactor):
global_colors = global_colors[mask] if len(global_colors) == len(all_global_points) else global_colors[mask]

# NEW (all_global_points no longer exists as a merged array):
global_colors = global_colors[mask]
```
