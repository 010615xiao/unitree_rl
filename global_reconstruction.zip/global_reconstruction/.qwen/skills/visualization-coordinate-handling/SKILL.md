---
name: visualization-coordinate-handling
description: Handle coordinate system consistency in top-view and other visualizations — avoid double-flipping axes and ensure projection matches the data coordinate system
source: auto-skill
extracted_at: '2026-05-28T06:12:00.000Z'
---

# Visualization Coordinate Handling

Ensure visualization functions (top-view projections, overlay plots, etc.) produce correctly oriented images when the data is in a rotated/aligned coordinate system.

## When to Use

- Creating top-down (XZ plane) visualizations of point clouds
- Overlaying segmentation results on density images
- Any 2D projection visualization where axis orientation matters

## Core Problem

When projecting 3D points to a 2D image and displaying with matplotlib, there are **two independent mechanisms** that affect axis orientation:

1. **Histogram bin indexing** — how 3D coordinates map to 2D array indices
2. **Display axis inversion** — `set_ylim(z_max, z_min)` flips the display Y-axis

Using **both** causes a **double flip**, resulting in an upside-down image.

## What NOT to Do

❌ **Don't flip z_idx AND set_ylim** — they cancel each other:

```python
# WRONG: double flip — image appears upside down
z_idx_flipped = (resolution - 1) - z_idx  # flip #1: in histogram indexing
flat_idx = z_idx_flipped * resolution + x_idx
# ... later in display ...
ax.set_ylim(z_max, z_min)  # flip #2: in axis display
```

## Correct Approach

### 1. Use Raw Indices for Histogram, Let Display Control Orientation

```python
# CORRECT: raw z_idx for histogram
x_idx = np.clip(np.digitize(proj_points[:, 0], x_bins) - 1, 0, resolution - 1)
z_idx = np.clip(np.digitize(proj_points[:, 1], z_bins) - 1, 0, resolution - 1)
flat_idx = z_idx * resolution + x_idx

# Compute density_img...

# Display: use extent + set_ylim to control orientation
ax.imshow(density_img, origin='lower',
          extent=[x_min, x_max, z_min, z_max])
ax.set_ylim(z_max, z_min)  # flip display so +Z is "up" in the image
```

**Why**: `origin='lower'` places array index [0,0] at the bottom-left of the display. `set_ylim(z_max, z_min)` reverses the Y-axis so that larger Z values appear higher on screen — matching the intuitive "top-down" view where +Z is forward/up.

### 2. XZ Projection for Y-Up Coordinate Systems

When Y is the vertical axis (after trajectory alignment):

```python
# Project to XZ plane (ignore Y/height)
proj_points = points[mask][:, [0, 2]]  # columns 0=X, 2=Z

# Bounds for display
x_min, z_min = proj_points.min(axis=0)
x_max, z_max = proj_points.max(axis=0)

# Display
ax.imshow(density_img, origin='lower', extent=[x_min, x_max, z_min, z_max])
ax.set_xlabel('X (m)')
ax.set_ylabel('Z (m)')
ax.set_ylim(z_max, z_min)  # +Z at top of image
```

### 3. Overlay Plots Must Use Same Bounds

When overlaying segmentation masks or room boundaries:

```python
# Same bounds as the density image
ax.set_xlim(x_min, x_max)
ax.set_ylim(z_max, z_min)  # must match the density image orientation
```

### 4. Height Filtering Must Use `floor_zero_level`, Not Global `y_min`

When creating the top-view projection mask, **do NOT use global `points[:, 1].min()`** as the height base — outlier noise points below the actual floor will shift the range and miss floor points:

```python
# WRONG: global y_min can be an outlier far below the real floor
mask = (points[:, 1] >= height_range[0] - 0.5) & \
       (points[:, 1] <= height_range[0] + 2.5)

# CORRECT: use floor_zero_level as the reference (from trajectory/floor segmentation)
y_base = floor_zero_level  # e.g., -1.49m
mask = (points[:, 1] >= y_base - 0.5) & \
       (points[:, 1] <= y_base + 4.0)
```

The `floor_zero_level` is the Y-coordinate of the floor plane after trajectory alignment. It represents the actual floor surface height, unlike `y_min` which can be affected by noise/outliers.

If `floor_zero_level` is unavailable, fall back to the floor segmentation result's `y_min` (not the global point cloud `y_min`).

## Pipeline Integration

### Pass `floor_zero_level` from Main Pipeline

In `reconstruct_and_segment.py`, pass the floor zero level to the visualization function:

```python
# In reconstruct_and_segment.py:
floor_zero = floor_levels[0]['y_min'] if floor_levels else None  # NOT 'zero_level'
generate_top_view_visualization(global_points, global_colors, rooms, top_view_output_dir,
                               floor_zero_level=floor_zero)
```

**⚠ Critical**: The floor level dict uses `'y_min'` (not `'zero_level'`) as the key for the floor zero plane Y-coordinate. Using the wrong key causes `KeyError`.

### Visualization Function Signature

`generate_top_view_visualization` must accept and propagate `floor_zero_level`:

```python
def generate_top_view_visualization(points, colors, rooms, output_dir, resolution=1000, floor_zero_level=None):
    """Generate top-view visualization with correct height filtering."""
    # Create top view with floor_zero_level for proper height range
    density_img, bounds = create_top_view(points, colors, resolution=resolution, floor_zero_level=floor_zero_level)

    # Segmentation overlay also uses floor_zero_level
    y_base = floor_zero_level if floor_zero_level is not None else -2.0
    height_mask = (points[:, 1] >= y_base - 0.5) & (points[:, 1] <= y_base + 4.0)
    plot_segmentation_overlay(ax, points[height_mask][:, [0, 2]], ...)
```

### Room Centers Projection

Room centers are in 3D (X, Y, Z) — project to XZ for 2D display:

```python
# create_top_view returns density_img + (x_min, x_max, z_min, z_max)
density_img, bounds = create_top_view(points, colors, resolution=resolution)
x_min, x_max, z_min, z_max = bounds

# Room centers are in 3D (X, Y, Z) — project to XZ for 2D display
room_centers = np.array([[r['center'][0], r['center'][2]] for r in rooms])
```

## Common Pitfalls

1. **Double flip**: `z_idx_flipped` in histogram + `set_ylim(z_max, z_min)` in display → inverted image
2. **Missing set_ylim**: Without it, +Z appears at bottom (array index order), which is counter-intuitive for top-down views
3. **Mismatched bounds in overlay**: Voronoi/segmentation overlay with different `set_ylim` than density image → misaligned layers
4. **Confusing Z with Y**: In Y-up coordinates, the "top-down" projection is XZ, not XY

## 3D Visualization (visualize_graph.py) — Coordinate System Conversion

### Y-Up → Z-Up Conversion for PyVista/VTK

**Problem**: The reconstruction pipeline uses a **Y-up** coordinate system (Y = height, XZ = ground plane) after trajectory alignment. However, **PyVista/VTK uses Z-up** (Z = height, Y = depth). When you pass Y-up data directly to PyVista, it interprets the Y-axis as depth (forward/backward) and the Z-axis as height (up/down). This causes:
- Rooms/objects appearing mirrored or rotated
- The scene looks like "looking up from the ground" instead of a proper floor plan
- Floor planes appearing vertical instead of horizontal

**Solution**: Swap Y ↔ Z axes for **all** point clouds (floors, rooms, objects) before PyVista rendering:

```python
# In visualize_graph.py, when loading EACH entity (floors, rooms, objects):

# For floors:
floor_pcd = o3d.io.read_point_cloud(ply_path)
floor_xyz = np.asarray(floor_pcd.points)
floor_xyz[:, [1, 2]] = floor_xyz[:, [2, 1]]  # swap Y ↔ Z
floor_pcd.points = o3d.utility.Vector3dVector(floor_xyz)
floor_pcds[floor_info["floor_id"]] = floor_pcd

# For rooms (after ceiling filtering):
cloud_xyz = np.asarray(room_pcds[room_info["room_id"]].points)
cloud_xyz[:, [1, 2]] = cloud_xyz[:, [2, 1]]  # swap Y ↔ Z
room_pcds[room_info["room_id"]].points = o3d.utility.Vector3dVector(cloud_xyz)
cloud_xyz += floor_infos[room_info["floor_id"]]["viz_offset"]

# For objects:
cloud_xyz = np.asarray(object_pcds[object_info["object_id"]].points)
cloud_xyz[:, [1, 2]] = cloud_xyz[:, [2, 1]]  # swap Y ↔ Z
object_pcds[object_info["object_id"]].points = o3d.utility.Vector3dVector(cloud_xyz)
cloud_xyz += floor_infos[room_infos[object_info["room_id"]]["floor_id"]]["viz_offset"]
```

**⚠ ALL entities must be converted**: Floors, rooms, AND objects must all have the Y↔Z swap applied. Mixing converted and unconverted data causes spatial misalignment in the scene.

**⚠ NOT a simple negation**: Use `cloud_xyz[:, [1, 2]] = cloud_xyz[:, [2, 1]]` (swap), NOT `cloud_xyz[:, 1] = -cloud_xyz[:, 1]` (negation). Negation flips the internal structure (floor becomes ceiling), creating a "looking up from the ground" effect.

### Adjust Visualization Offsets for Z-Up

After the Y↔Z swap, the `viz_offset` and centroid offsets must also have Y↔Z swapped:

```python
# Original (Y-up): init_offset = np.array([7.0, 2.5, 4.0])  # (X, Y-up, Z-depth)
# After swap:      init_offset = np.array([7.0, 4.0, 2.5])  # (X, Z-up, Y-depth)

init_offset = np.array([7.0, 4.0, 2.5])  # Z-up: offset in height (Z), not Y

# Centroid offsets:
# Original (Y-up):  [0.0, 4.0, 0.0]  → 4.0m in Y (height)
# After swap (Z-up): [0.0, 0.0, 4.0]  → 4.0m in Z (height)

floor_centroids_viz = {
    floor_id: floor_centroids[floor_id] + floor_infos[floor_id]["viz_offset"] + [0.0, 0.0, 4.0]
    for floor_id in hier_topo.keys()
}
room_centroids_viz = {
    room_id: room_centroids[room_id] + [0.0, 0.0, 3.5]  # Z-up height
    for room_id in room_infos.keys()
}
```

## Verification

Compare the top-view image with the known room layout:
- Rooms should appear in their correct spatial positions relative to each other
- The trajectory path (if overlaid) should match the expected robot movement direction
- Room labels/IDs should correspond to the correct physical locations
- The 3D visualization (`visualization_result.png`) should match the 2D top-view layout (rooms/objects in the same XZ positions)
