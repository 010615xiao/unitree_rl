---
name: room-segmentation-validation
description: Validate watershed-based room segmentation by requiring floor points, tuning morphological operations, and filtering wall-only artifacts
source: auto-skill
extracted_at: '2026-05-28T02:49:37.987Z'
---

# Room Segmentation Validation

Approach for validating watershed-based room segmentation in point clouds to prevent wall-only areas from being falsely identified as rooms, while maintaining proper room boundaries.

## When to Use

- Room segmentation using 2D histogram + watershed on point clouds
- Isolated wall segments forming false room boundaries
- Rooms getting too large due to merged door openings
- Wall-only enclosed areas being detected as separate rooms

## Core Problem

In watershed-based room segmentation:
- **ALL points** (walls, furniture, floor) are needed in the histogram to form room boundaries
- But **wall-only enclosed areas** can form watershed basins and be falsely detected as rooms
- Aggressive morphological closing can merge door openings, combining separate rooms

## What NOT to Do

❌ **Don't filter input to only floor-category points** — the watershed needs walls/obstacles to form boundaries. Without walls, there are no barriers between rooms.

```python
# WRONG: Only floor points → no boundaries for watershed
floor_obj_points = []
for obj in objects:
    if obj['category'] == 'floor':
        floor_obj_points.append(obj['points'])
floor_surface = np.concatenate(floor_obj_points)
rooms = segment_rooms(floor_surface, ...)  # Watershed has no barriers!
```

## Correct Approach

### 1. Use ALL Points for Histogram (Keep Walls as Boundaries)

```python
# CORRECT: All points in the floor height range
floor_mask = (global_points[:, VERTICAL_AXIS] >= floor_zero_level) & \
             (global_points[:, VERTICAL_AXIS] < floor_zero_level + floor_height)
floor_points = global_points[floor_mask]
rooms = segment_rooms(floor_points, floor_zero_level, floor_height, save_path)
```

Walls create high-density cells in the 2D histogram → become watershed barriers → separate rooms.

### 2. Validate Each Room Has Sufficient Point Occupancy (Grid-Level, Before KDTree)

Build a **point occupancy grid** from ALL points projected to 2D, then validate at the grid level BEFORE doing expensive KDTree queries:

```python
# In segment_rooms(), BEFORE watershed:
# Use ALL points projected to 2D — normal rooms are dense, wall-only areas are sparse
point_occupancy = (hist_full > 0).astype(np.uint8)

# IMPORTANT: Add padding to match full_map shape
padding = 10  # Same padding used for walls_skeleton, outside_boundary
point_occupancy = cv2.copyMakeBorder(point_occupancy, padding, padding, padding, padding,
                                     cv2.BORDER_CONSTANT, value=0)

# In map_rooms_to_3d(), for each room component:
room_cells = comp_mask.sum()
occ_cells_in_room = (comp_mask & point_occupancy).sum()  # Grid AND operation
occ_ratio = occ_cells_in_room / room_cells if room_cells > 0 else 0

if occ_ratio < 0.3:
    print(f"  Room {room_id}: discarded (occupancy {occ_ratio:.0%} < 30%)")
    continue  # Wall-only/sparse area, skip expensive KDTree

# Only AFTER passing grid validation, do KDTree query:
_, idx = floor_tree.query(room_3d_samples, k=1, workers=-1)
room_points = floor_points[idx]
```

**Why occupancy instead of floor-only**: Normal rooms have floor + furniture + walls → high 2D occupancy density. Wall-only enclosed areas have only wall points → sparse occupancy. This is simpler and more robust than filtering by height.

**Why grid-level first**: KDTree + 3D sampling is expensive (~seconds per room). Grid AND is instant. Validate cheaply first.

**Why 30% occupancy ratio**: A real room should have most of its 2D area covered by points. Wall-only enclosed areas will have very low occupancy (<10%).

**⚠ CRITICAL: Padding must match** — `full_map` gets `padding=10` border via `cv2.copyMakeBorder`. `point_occupancy` MUST get the same padding, otherwise `comp_mask & point_occupancy` will fail with shape mismatch (e.g., `(600,380) vs (580,360)`).

### 3. Tune Morphological Closing (Avoid Merging Door Openings)

```python
# AGGRESSIVE (bad): iterations=2 fills door openings
full_map = cv2.morphologyEx(full_map, cv2.MORPH_CLOSE, kernel_rect_3, iterations=2)

# CONSERVATIVE (good): iterations=1 preserves narrow gaps
full_map = cv2.morphologyEx(full_map, cv2.MORPH_CLOSE, kernel_rect_3, iterations=1)
```

A typical door opening at 5cm resolution is ~16 cells wide. Closing with iterations=2 on a 3×3 kernel can expand walls by 6 pixels in each direction, easily closing narrow door gaps.

### 4. Set Minimum Room Area Appropriately (Preserve Small Real Rooms)

```python
# In distance_transform(), seed filtering:
min_area_m = 0.5  # At 5cm: (0.5/0.05)² = 100 cells
min_area = (min_area_m / resolution) ** 2
contours = [c for c in contours if cv2.contourArea(c) > min_area]
```

⚠ **Do not raise this above 0.5 m²** — increasing to 1.0 m² was tried but it filtered out genuinely small rooms (e.g., bathrooms, closets). The 30% occupancy validation (step 2) is sufficient to filter wall-only artifacts; the area threshold should only filter noise-level seeds.

### 5. Normalize `comp_mask` to 0/1 Binary Before Arithmetic

⚠ **CRITICAL** — watershed output markers are **0/255**, not 0/1. When a room has only one connected component, `comp_mask` is used directly with value 255:

```python
# WRONG: comp_mask has values 0/255, sum() = 255 × actual_cells
room_cells = comp_mask.sum()
occ_cells_in_room = (comp_mask & point_occupancy).sum()  # bitwise AND with 255 passes everything
occ_ratio = occ_cells_in_room / room_cells  # inflated by 255×, always << 30%

# CORRECT: normalize to 0/1 first
masks_to_process = components if len(components) > 1 else [(room > 0).astype(np.uint8)]

for comp_idx, comp_mask in enumerate(masks_to_process):
    room_cells = comp_mask.sum()          # now = actual cell count
    occ_cells_in_room = (comp_mask & point_occupancy).sum()
    occ_ratio = occ_cells_in_room / room_cells  # correct ratio
```

**Why**: `cv2.drawContours(markers, ..., i + 1, -1)` uses marker values starting from 1, and the single-component fallback uses `room` which was set to 255 via `room[room_vertex[0], room_vertex[1]] = 255`. All component masks must be normalized to 0/1 before `sum()` and bitwise operations.

## Complete Pipeline

```
Input: ALL points in floor height range (walls + floor + furniture)
    ↓
2D Histogram (walls form high-density barriers)
    ↓
Point Occupancy Grid (hist_full > 0, for validation)
    ↓
Gaussian Blur + Threshold (skeleton walls)
    ↓
Morphological Closing (iterations=1, preserve doors)
    ↓
Distance Transform + Watershed
    ↓
Seed Filtering (min_area = 1.0 m²)
    ↓
OCCUPANCY VALIDATION: require ≥30% of room cells have point occupancy
    ↓  (discard wall-only areas before expensive KDTree)
Map to 3D Points (KDTree query)
    ↓
Output: Valid rooms with real point occupancy
```

## Visualization

Save occupancy grid images for both kept and discarded rooms:

```python
# For kept rooms:
room_occupancy_vis = np.zeros_like(point_occupancy, dtype=np.uint8)
room_occupancy_vis[comp_mask > 0] = 128  # Room area = gray
room_occupancy_vis[(comp_mask > 0) & (point_occupancy > 0)] = 255  # Occupied = white
room_occupancy_vis[(comp_mask == 0) & (point_occupancy > 0)] = 64  # External occupied = dark

plt.figure(figsize=(8, 6))
plt.imshow(room_occupancy_vis, cmap='gray', origin='lower')
plt.title(f"Room {room_id}: occ={occ_ratio:.0%}, cells={room_cells}, occ_cells={occ_cells_in_room}")
plt.savefig(os.path.join(save_path, f'room_{room_id}_occupancy.png'), dpi=100)

# For discarded rooms (same pattern, different filename):
plt.savefig(os.path.join(save_path, f'room_{room_id}_discarded.png'), dpi=100)
```

Legend:
- **White (255)**: Room area with point occupancy ✓
- **Gray (128)**: Room area without points (empty space)
- **Dark (64)**: Outside room but has points
- **Black (0)**: No points, outside room

## Common Pitfalls

1. **Filtering input to only floor points**: Removes walls → watershed has no barriers → all points become one room
2. **Not validating output rooms**: Wall-only enclosed areas pass through → false rooms
3. **Too aggressive closing**: Door openings filled → adjacent rooms merged
4. **Minimum area too high (>0.5 m²)**: Small real rooms (bathrooms, closets) filtered out
5. **Padding mismatch**: `point_occupancy` without padding → shape mismatch with `comp_mask` (e.g., `(600,380) vs (580,360)`) → `ValueError: operands could not be broadcast together`
6. **Using floor-only occupancy grid**: If near-floor points are sparse (e.g., only 317 points in a 1.8M point cloud), the occupancy grid becomes too sparse to validate properly. Use ALL points instead.
7. **`comp_mask` value is 0/255 not 0/1**: `room[room_vertex[0], room_vertex[1]] = 255` → `comp_mask.sum()` = 255× actual count → occupancy ratio always << 30% → all rooms discarded. Normalize with `(room > 0).astype(np.uint8)` before arithmetic.
8. **Room PLYs without RGB colors**: `save_rooms` was using `plt.cm.tab10` solid colors instead of original RGB. Thread `floor_colors` through the entire pipeline:

```python
# In reconstruct_and_segment.py, pass floor_colors to segment_rooms:
rooms = segment_rooms(floor_points, floor_zero_level, floor_height, save_path,
                     floor_colors=floor_colors)

# In segment_rooms(), store colors after height filtering (keep aligned with xyz_full):
colors_full = floor_colors[mask_full]  # same mask as xyz_full
# Pass to map_rooms_to_3d:
rooms = map_rooms_to_3d(..., xyz_full, ..., colors_full=colors_full)

# In map_rooms_to_3d(), extract colors alongside points via KDTree:
floor_tree = cKDTree(floor_points)  # use xyz_full (filtered), NOT original floor_points
_, idx = floor_tree.query(room_3d_samples, k=1, workers=-1)
room_points = floor_points[idx]
room_colors = colors_full[idx]

# Dedup while keeping color correspondence:
_, unique_idx = np.unique(room_points, axis=0, return_index=True)
room_points = room_points[unique_idx]
room_colors = room_colors[unique_idx]

# Store in room dict:
rooms.append({
    'id': room_id_counter,
    'points': room_points,
    'colors': room_colors,
    ...
})

# In save_rooms(), normalize colors before saving:
if 'colors' in room and room['colors'] is not None:
    room_colors = np.asarray(room['colors'], dtype=np.float64)
    if room_colors.max() > 1.0:  # uint8 [0-255] → float [0-1]
        room_colors = room_colors / 255.0
    pcd.colors = o3d.utility.Vector3dVector(room_colors)
```

**⚠ Critical details**:
- **KDTree must be built on `xyz_full`** (height-filtered), NOT the original `floor_points`, because `colors_full` has the same length as `xyz_full`. Using the wrong tree causes `IndexError: index out of bounds`.
- **Color normalization**: PLY files store colors as float [0-1]. If you pass uint8 values (e.g., 255) directly, Open3D interprets them as >1.0 and displays as pure white.

## Verification

1. **Check occupancy grid images**: Look at `room_*_occupancy.png` in the output directory. White areas should cover most of each room's gray area.

2. **Check discarded room images**: `room_*_discarded.png` shows why rooms were rejected — typically sparse or empty interiors.

3. **Check room PLYs for point content**:

```python
from pathlib import Path
import open3d as o3d
import numpy as np

rooms_dir = Path('unified_output/rooms/floor_0_rooms')
for rf in sorted(rooms_dir.glob('room_*.ply')):
    pcd = o3d.io.read_point_cloud(str(rf))
    pts = np.asarray(pcd.points)
    y = pts[:, 1]
    print(f'{rf.name}: {len(pts):,} points, Y=[{y.min():.2f}, {y.max():.2f}]')
```

Expected: All rooms should have significant point counts (>10K points) and reasonable Y ranges.
