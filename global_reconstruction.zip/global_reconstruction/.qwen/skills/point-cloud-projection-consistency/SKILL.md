---
name: point-cloud-projection-consistency
description: Ensure object and scene point clouds use identical filtering (confidence, depth range) so object points strictly lie within scene points
source: auto-skill
extracted_at: '2026-05-28T11:38:33.605Z'
---

# Point Cloud Projection Consistency

Ensure object and scene point clouds use identical filtering criteria so object points strictly lie within scene points.

## When to Use

- Object point clouds appear to "float" outside the scene point cloud
- Object points don't align with scene points in visualization
- Debugging 3D point generation from depth + masks

## Core Problem

The pipeline generates point clouds from two different functions:

1. **Scene point cloud**: `depth_to_pointcloud(depth, color, K, T_c2w, confidence, conf_threshold)`
2. **Object point cloud**: `mask_to_3d_points(mask_2d, depth_img, K, T_c2w)`

Both use the same depth map, pose, and intrinsics — so theoretically object points should be a strict subset of scene points. But in practice, **different filtering criteria** cause mismatches.

## Filtering Mismatches

### Confidence Filtering

`depth_to_pointcloud` applies confidence filtering:

```python
valid_mask = (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
if confidence is not None and conf_threshold > 0:
    valid_mask &= (confidence >= conf_threshold)
```

`mask_to_3d_points` originally **did not**:

```python
# BEFORE (wrong):
valid_mask = (mask_binary > 0) & (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
```

This means low-confidence depth pixels are excluded from the scene but still generate object points → object points "float" outside scene.

**Fix**: Apply the same confidence filtering:

```python
# AFTER (correct):
valid_mask = (mask_binary > 0) & (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
if confidence is not None and conf_threshold > 0:
    valid_mask &= (confidence >= conf_threshold)
```

### Depth Range Filtering

Both functions should use the same `DEPTH_MIN` and `DEPTH_MAX` constants. Verify these are consistent.

## Correct Implementation

### `mask_to_3d_points` Signature

```python
def mask_to_3d_points(mask_2d, depth_img, K, T_c2w, confidence=None, conf_threshold=0.0):
    """2D 掩码 → 3D 点云"""
    depth = depth_img.astype(np.float32)

    # Resize mask to match depth resolution if needed
    if mask_2d.shape[:2] != depth.shape[:2]:
        mask_2d = cv2.resize(mask_2d.astype(np.float32), (depth.shape[1], depth.shape[0]),
                             interpolation=cv2.INTER_NEAREST).astype(np.uint8)

    mask_binary = (mask_2d > 128).astype(np.uint8)

    # Apply SAME filtering as depth_to_pointcloud
    valid_mask = (mask_binary > 0) & (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
    if confidence is not None and conf_threshold > 0:
        valid_mask &= (confidence >= conf_threshold)

    if valid_mask.sum() == 0:
        return np.empty((0, 3))

    # ... rest of projection logic (backproject using K, T_c2w)
```

### Call Site

Pass the same confidence map and threshold used for scene point cloud:

```python
# In the frame processing loop:
confidence = adapter.load_confidence(i) if CONFIDENCE_THRESHOLD > 0 else None

# For each detected object:
points_3d = mask_to_3d_points(
    mask_data['mask'], depth, K_frame, T_c2w,
    confidence, CONFIDENCE_THRESHOLD  # ← pass these!
)
```

## Verification

After fixing, verify object points lie within scene points:

```python
from scipy.spatial import cKDTree

scene_pcd = o3d.io.read_point_cloud('unified_output/floor_0.ply')
scene_pts = np.asarray(scene_pcd.points)

object_pcd = o3d.io.read_point_cloud('unified_output/objects/object_0_*.ply')
object_pts = np.asarray(object_pcd.points)

# For each object point, find nearest scene point
tree = cKDTree(scene_pts)
dists, _ = tree.query(object_pts, k=1)

print(f"Max distance to scene: {dists.max():.4f} m")
print(f"Mean distance to scene: {dists.mean():.4f} m")
print(f"Points > 0.05m from scene: {(dists > 0.05).sum()} / {len(object_pts)}")
```

Expected: Max distance should be close to 0 (or voxel size). If distances are large, filtering is still inconsistent.

## Other Potential Mismatches

| Filter | `depth_to_pointcloud` | `mask_to_3d_points` | Status |
|--------|----------------------|---------------------|--------|
| Depth range (`DEPTH_MIN/MAX`) | ✅ | ✅ | Consistent |
| Confidence threshold | ✅ | ❌ (was missing) | **Fixed** |
| Mask resolution alignment | N/A | ✅ (auto-resize) | Consistent |
| Camera intrinsics (`K`) | ✅ | ✅ | Consistent |
| Pose (`T_c2w`) | ✅ | ✅ | Consistent |
