---
name: object-merge-strategy
description: AABB box-based merge with Union-Find for transitivity, background/foreground separation, and multi-frame views saving
source: auto-skill
extracted_at: '2026-05-29T08:00:00.000Z'
---

## Problem

The original multi-round merge (4 rounds with semantic similarity, distance fallback) caused **over-merging**:
- Round 4 (distance < 1.0m + semantic similarity) would merge distinct adjacent objects (e.g., two chairs 0.8m apart).
- Wall/Floor fragments participating in iterative merging would "swallow" other objects (e.g., a door embedded in a wall) because Embedding similarity considered them semantically related.
- Point cloud overlap/IoU computation was extremely slow — O(n²) voxelization with `set(map(tuple, voxels))`.
- Greedy single-pass merge had **missing transitivity**: A-B and B-C merge, but A-C doesn't overlap → C left as separate object.

## Solution: `iterative_merge_objects()` (current)

Located in `reconstruct_and_segment.py`. Uses **AABB 3D box overlap** + **Union-Find** for transitive merging.

### Architecture: Background/Foreground Separation

```python
# Wall/Floor are EXCLUDED from iterative merging
bg_objects = [obj for obj in all_objects if obj['category'] in MERGE_CATEGORIES]
fg_objects = [obj for obj in all_objects if obj['category'] not in MERGE_CATEGORIES]

# Only foreground objects go through iterative merge
merged_fg_objects = iterative_merge_objects(fg_objects)

# Wall/Floor are collapsed separately (no overlap checks, just concatenate all points)
```

**Why**: Prevents wall/floor from polluting the merge of other objects. A door embedded in a wall will never be merged into the wall because they're processed in completely separate pipelines.

### Core function: `_can_merge_objects()` — Pure AABB Box Overlap

```python
def _can_merge_objects(obj_a, obj_b, overlap_threshold=0.15, iou_threshold=0.10, dilation=0.08):
    # 1. Compute AABB for both objects (with dilation expansion)
    bbox_a_min = pts_a.min(axis=0) - dilation
    bbox_a_max = pts_a.max(axis=0) + dilation
    bbox_b_min = pts_b.min(axis=0) - dilation
    bbox_b_max = pts_b.max(axis=0) + dilation

    # 2. Compute intersection volume
    inter_min = np.maximum(bbox_a_min, bbox_b_min)
    inter_max = np.minimum(bbox_a_max, bbox_b_max)
    inter_size = np.maximum(0.0, inter_max - inter_min)
    inter_vol = inter_size.prod()

    # 3. Compute individual volumes
    vol_a = (bbox_a_max - bbox_a_min).prod()
    vol_b = (bbox_b_max - bbox_b_min).prod()

    # 4. Check bidirectional overlap OR IoU
    overlap_a = inter_vol / vol_a
    overlap_b = inter_vol / vol_b
    if overlap_a >= overlap_threshold and overlap_b >= overlap_threshold:
        return True
    union_vol = vol_a + vol_b - inter_vol
    iou = inter_vol / union_vol if union_vol > 0 else 0.0
    return iou >= iou_threshold
```

**Deleted functions** (no longer used):
- `_point_cloud_overlap_ratio()` — was O(n) per-point bounding box check
- `_point_cloud_iou()` — was O(n) voxelization + Python set operations

**Why AABB**: Point cloud overlap was slow (O(n²) voxelization with `set(map(tuple, voxels))`). AABB box overlap is O(1) — just min/max comparisons and multiplication. Much faster and more robust to point cloud misalignment.

**Trade-off**: Less precise for C-shaped objects (empty cavity counts as volume), but speed improvement is dramatic — Round 2 went from minutes to seconds.

### Merge algorithm: Union-Find (Transitive)

```python
def iterative_merge_objects(all_objects, max_rounds=4):
    objects = list(all_objects)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]  # path compression
            x = parent[x]
        return x

    def union(x, y):
        px, py = find(x), find(y)
        if px != py:
            parent[px] = py

    # Two-pass: compare all pairs, build connectivity
    for i in range(n):
        for j in range(i + 1, n):
            if should_merge(objects[i], objects[j]):
                union(i, j)

    # Group by root, merge each cluster
    clusters = defaultdict(list)
    for i in range(n):
        clusters[find(i)].append(objects[i])
    return [_merge_cluster(c) for c in clusters.values()]
```

**Why Union-Find**: Old greedy algorithm had **missing transitivity** — A merges with B, B merges with C, but A doesn't overlap C → C left as separate object. Union-Find ensures A-B-C all merge into one cluster.

### Single-round strategy

| Parameter | Value | Description |
|-----------|-------|-------------|
| Overlap threshold | 0.15 | Bidirectional box overlap ≥ 15% |
| IoU threshold | 0.10 | Box IoU ≥ 10% |
| Category check | **Exact match only** | `cat_a == cat_b` (no semantic similarity) |
| Distance fallback | **Removed** | No distance-based merge (prevents over-merging) |
| Merge algorithm | **Union-Find** | Ensures transitivity (A-B, B-C → A-B-C) |

### Multi-frame views saving

After merge, each object's `source_views` contain grounded views from all frames where the object was detected and successfully merged. The save logic copies annotated views to a single folder:

```python
obj_view_dir = OBJECT_VIEW_OUTPUT_DIR / obj['name']  # e.g., urinal_0/
for source_view in obj.get('source_views', []):
    shutil.copy2(source_view['annotated_image'], obj_view_dir / f"annotated_{frame}_{idx:03d}.png")
```

**Result**: `urinal_0/` folder contains `annotated_00000_000.png`, `annotated_00005_001.png`, etc. — all frames where this urinal was detected and merged.

### Config

- `config.yaml` → `object_segmentation.merge_categories: ['wall', 'floor']` — categories collapsed to one instance each **after** iterative merging.
- `config.yaml` → `object_segmentation.source_view_limit: 12` — maximum views saved per object.

### Key design decisions

1. **Exact category match only** — `door` and `wall` are never merged even if they overlap 100%, because categories differ.
2. **Bidirectional overlap** — stricter than IoU alone; both A⊆B and B⊆A must have sufficient overlap.
3. **Union-Find for transitivity** — ensures chain-merges (A-B-C) are not broken by pairwise non-overlap.
4. **AABB box overlap** — O(1) volume calculation, replaced slow point cloud voxelization.
5. **Dilation = 8cm** — tolerates typical registration/SLAM drift between frames.
6. **Background/foreground isolation** — wall/floor excluded from iterative merge, preventing "swallowing" of foreground objects.

### Pitfalls

- AABB is less precise for C-shaped or hollow objects (empty cavity counts as volume). If false merges occur, lower thresholds or consider OBB (oriented bounding box).
- Each detection creates a new per-frame instance. Multi-frame aggregation ONLY happens through `iterative_merge_objects`. If fragments don't overlap enough geometrically, they remain separate — the system does NOT use distance-based matching at detection time (this was tried and caused over-merging of adjacent objects).
- Voronoi visualization in `visualize_room_segmentation.py` requires ≥ 3 rooms; otherwise it skips and prints a warning.
