---
name: object-views-saving-strategy
description: How grounded views are collected, merged, and saved per-object after point cloud merging — avoid reprojection, preserve original detection views
source: auto-skill
extracted_at: '2026-05-29T03:20:00.000Z'
---

# Object Views Saving Strategy

## Problem

After merging 3D object fragments from multiple frames, the pipeline needs to save annotated view images for each final object. Two approaches were tried:

### Approach 1 (Rejected): Reprojection Views
```python
final_objects = rebuild_final_object_grounded_views(final_objects, poses, K)
```
This reprojects the merged 3D point cloud back onto each camera frame to generate new masks and bounding boxes.

**Why it fails**:
- **Occlusion**: The merged 3D object is complete, but a given frame may only see part of it (occluded by furniture, walls, etc.). The reprojected mask includes the occluded parts, making the bounding box look wrong.
- **View frustum issues**: Objects partially outside the camera's field of view produce distorted masks.
- **Replaces original views**: The reprojection logic was replacing the original high-quality detection views with these broken reprojection views.
- **100xxx index offset**: `create_reprojected_object_grounded_view` uses `object_index=100000 + int(object_index)`, creating confusing file names like `100001_annotated.png` that don't match original detection indices.

### Approach 2 (Current): Preserve Original Detection Views
```python
# Remove reprojection entirely
# rebuild_final_object_grounded_views(final_objects, poses, K)  ← REMOVED
```

Keep the original grounded views generated during detection. These are high-quality because:
- SAM3 produced the mask directly on that frame (no occlusion issues)
- The bounding box tightly fits the visible portion of the object
- The annotated image clearly shows what was detected

## How It Works

### Step 1: Grounded View Creation During Detection

Each time SAM3 successfully segments an object:
```python
grounded_view = create_object_grounded_views(
    image_path=color_file,
    image_rgb=color,
    frame=timestamp_str,
    category=category,
    object_index=len(all_objects),
    box=grounded_box,
    mask=grounded_mask,
    score=mask_data.get('score'),
)
```

This creates:
- `annotated.png`: Original image with object highlighted (red tint + blue bounding box + category label)
- Context crop: Zoomed-in view centered on the object
- Object crop: Tight crop of the object itself (background dimmed)

The view is stored in the object's `source_views` list.

### Step 2: View Merging During Object Merge

When `iterative_merge_objects` or the background merge step combines fragments:
```python
def _merge_cluster(cluster):
    source_views = merge_source_views(cluster)
    # ...
```

`merge_source_views` deduplicates views by `(frame, bbox_xyxy, annotated_image, object_crop)` and sorts by score/mask area. The result is a consolidated list of views from all frames that contributed to this object.

**Limit**: `OBJECT_SOURCE_VIEW_LIMIT` (default 12) caps the number of views per object.

### Step 3: Save Views to Per-Object Folders

After all merging is complete, iterate through final objects:
```python
for i, obj in enumerate(final_objects):
    # Save PLY
    obj_file = OUTPUT_DIR / "objects" / f"object_{i:04d}_{obj['name']}.ply"
    save_point_cloud(obj_file, obj['points'], colors)

    # Save views
    obj_view_dir = OBJECT_VIEW_OUTPUT_DIR / obj['name']
    obj_view_dir.mkdir(parents=True, exist_ok=True)

    saved_view_indices = set()
    for view_idx, source_view in enumerate(obj.get('source_views', [])):
        annotated_path = source_view.get('annotated_image')
        if not annotated_path or not Path(annotated_path).exists():
            continue

        # Deduplicate by frame
        frame_key = source_view.get('frame', f'view_{view_idx}')
        if frame_key in saved_view_indices:
            continue
        saved_view_indices.add(frame_key)

        # Copy to per-object folder
        src = Path(annotated_path)
        dest_name = f"annotated_{src.stem}_{view_idx:03d}.png"
        dst = obj_view_dir / dest_name
        shutil.copy2(src, dst)
```

**Result**: Each object gets its own folder with all its annotated views:
```
object_views/
├── urinal_0/
│   ├── annotated_00000_000.png
│   ├── annotated_00005_001.png
│   └── annotated_00012_002.png
├── door_3/
│   └── annotated_00010_000.png
└── wall_0/
    ├── annotated_00000_000.png
    ├── annotated_00008_001.png
    └── ...
```

## Key Design Decisions

1. **Original views > Reprojection views**: SAM3 masks on original frames are always more accurate than reprojected 3D-to-2D masks, which suffer from occlusion and view frustum issues.

2. **Per-object folder naming**: Use `{category}_{id}` as folder name (e.g., `urinal_0`, `door_3`). This matches the PLY file naming and makes it easy to correlate views with 3D geometry.

3. **Deduplication by frame**: Multiple views from the same frame are rare (same object detected twice in one frame), but if they occur, only keep one per frame to avoid redundancy.

4. **View limit of 12**: Prevents objects seen in many frames from accumulating hundreds of views. The `merge_source_views` function sorts by score/area, so the best views are kept.

5. **Copy, not symlink**: Use `shutil.copy2` to preserve original files even if the detection output directory is cleaned up later.

## When to Use

- After any 3D object merging step that combines fragments from multiple frames
- When saving visual documentation of detected objects alongside their 3D geometry
- When VLM-based analysis needs grounded views for specific object instances (see `describe_object_environment`)

## Pitfalls

1. **Merge must succeed for multi-frame views**: If `iterative_merge_objects` doesn't merge fragments of the same physical object (e.g., due to low point cloud overlap), each fragment will only have its own single-frame view. The per-object folder will contain just one image.

2. **Background categories are separate**: Wall/Floor fragments are merged outside `iterative_merge_objects`. Their views are collected separately but saved using the same per-object folder logic.

3. **View index in filename**: The `_000`, `_001` suffix in `annotated_00000_000.png` is the index within the `source_views` list, NOT the original frame number. Use the frame metadata if you need the actual frame timestamp.

4. **Temporary detection views**: The original grounded views are created in a temporary location during detection. The copy step at the end is essential — without it, views would be lost if the temp directory is cleaned.
