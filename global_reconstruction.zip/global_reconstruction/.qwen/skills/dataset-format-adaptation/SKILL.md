---
name: dataset-format-adaptation
description: Adapt data processing pipelines to support new dataset formats while maintaining backward compatibility
source: auto-skill
extracted_at: '2026-05-27T11:46:18.814Z'
---

# Dataset Format Adaptation

Systematic approach to adapting data processing pipelines to support new dataset formats while maintaining backward compatibility with existing formats.

## When to Use

- Adding support for a new dataset format to an existing pipeline
- Need to handle multiple dataset formats with different file structures
- Dataset has per-frame varying parameters (intrinsics, exposure, etc.)
- Need to support different pose file formats (TUM quaternion vs 4x4 matrix)
- Need to support different depth formats (uint16 mm PNG vs float32 m NPY)

## Core Approach

### 1. Auto-Detect Dataset Format via File Signatures

Check for format-specific files to identify the dataset type:

```python
def _detect_dataset_type(self):
    """检测数据集类型"""
    if (self.data_dir / "camera_poses.txt").exists() and \
       (self.data_dir / "rgb").is_dir():
        print(f"  📷 检测到 da3_ezviz 格式 (Depth Anything V3 + EZVIZ)")
        return "da3_ezviz"
    return "standard"
```

**Key insight**: Use unique file combinations as signatures. `camera_poses.txt` + `rgb/` is unique to da3_ezviz format.

### 2. Use Adapter Pattern to Abstract Format Differences

Create a `DatasetAdapter` class that:
- Detects format in `__init__`
- Sets format-specific paths (`images_dir`, `depth_dir`, `poses_file`)
- Provides unified API (`load_depth()`, `get_depth_file_list()`, `match_color_file()`)
- Handles format-specific logic internally

```python
class DatasetAdapter:
    def __init__(self, data_dir):
        self.dataset_type = self._detect_dataset_type()
        
        if self.dataset_type == "da3_ezviz":
            self.images_dir = self.data_dir / "rgb"
            self._depth_ext = ".npy"
        else:
            self.images_dir = self.data_dir / "images"
            self._depth_ext = ".png"
```

### 3. Handle Per-Frame Varying Parameters

When intrinsics or other parameters vary per frame:

```python
def _load_per_frame_intrinsics(self):
    """Load per-frame intrinsics (da3_ezviz: fx fy cx cy per line)"""
    with open(self.intrinsic_file, 'r') as f:
        for i, line in enumerate(f):
            parts = line.split()
            if len(parts) >= 4:
                self._per_frame_intrinsics[i] = (
                    float(parts[0]), float(parts[1]),
                    float(parts[2]), float(parts[3])
                )

def get_K_for_frame(self, frame_idx):
    """Get intrinsics for specific frame (scaled to RGB resolution)"""
    if frame_idx not in self._per_frame_intrinsics:
        return self.K  # fallback to average K
    fx, fy, cx, cy = self._per_frame_intrinsics[frame_idx]
    # Scale to RGB resolution if needed
    return self._scale_intrinsics(fx, fy, cx, cy)
```

**Usage in main loop**:
```python
for i, depth_file in enumerate(depth_files):
    K_frame = adapter.get_K_for_frame(i)  # per-frame K
    points = depth_to_pointcloud(depth, color, K_frame, T_c2w)
```

### 4. Support Multiple Pose File Formats

Detect format by line structure:

```python
def load_poses(pose_file):
    poses = {}
    seq_idx = 0
    with open(pose_file, 'r') as f:
        for line in f:
            parts = line.strip().split()
            
            if len(parts) == 16:
                # 4x4 matrix format (da3_ezviz: 16 floats, row-major)
                T_c2w = np.array([float(x) for x in parts]).reshape(4, 4)
                timestamp = f"{seq_idx:05d}"
                seq_idx += 1
                poses[timestamp] = T_c2w
                
            elif len(parts) >= 8:
                # TUM format (timestamp tx ty tz qx qy qz qw)
                timestamp = parts[0]
                # ... parse TUM format ...
                poses[timestamp] = T_c2w
```

**Key insight**: Use `len(parts)` to distinguish formats. 16 values = 4x4 matrix, 8+ values = TUM.

### 5. Resolution Alignment: Work at Depth-Native Resolution

When depth and RGB have different resolutions, the **preferred approach** (used by DA3-Streaming) is to work at the depth-native resolution — downsample RGB to match depth, keep intrinsics unchanged.

**Why this is better than upsampling depth**:
- Intrinsics are calibrated at the depth model's output resolution
- Upsampling depth introduces interpolation artifacts at pixel boundaries
- Fewer points per frame → dramatically lower memory and faster processing
- Confidence maps are also at depth resolution, so everything stays aligned

```python
class DatasetAdapter:
    def __init__(self, data_dir):
        # ... format detection ...

        self.depth_resolution = self._get_depth_resolution()
        self.rgb_resolution_original = self._get_rgb_resolution()

        if self.dataset_type == "da3_ezviz":
            # Work at depth resolution: RGB downsampled, intrinsics unchanged
            self.process_resolution = self.depth_resolution
            self.rgb_resolution = self.depth_resolution
            self.needs_depth_upsample = False
        else:
            # Standard format: depth upsampled to RGB (legacy behavior)
            self.process_resolution = self.rgb_resolution_original
            self.rgb_resolution = self.rgb_resolution_original
            self.needs_depth_upsample = (self.depth_resolution != self.rgb_resolution)
```

**RGB downsampling** — add a `load_color()` method that automatically resizes:

```python
def load_color(self, color_file):
    """Load color image and resize to working resolution"""
    color = cv2.imread(str(color_file), cv2.IMREAD_COLOR)
    color = cv2.cvtColor(color, cv2.COLOR_BGR2RGB)

    if self.dataset_type == "da3_ezviz":
        th, tw = self.process_resolution
        if color.shape[0] != th or color.shape[1] != tw:
            color = cv2.resize(color, (tw, th), interpolation=cv2.INTER_LINEAR)

    return color
```

**Depth loading** — for da3_ezviz, return native resolution (no upsampling):

```python
def load_depth(self, depth_file, target_resolution=None):
    if self.dataset_type == "da3_ezviz":
        # Return at native depth resolution
        return np.load(str(npy_path)).astype(np.float32)
    # standard: upsample if needed
```

**Intrinsics** — no scaling needed for da3_ezviz since depth and intrinsics are both at depth-native resolution:

```python
def get_K_for_frame(self, frame_idx):
    # da3_ezviz: return intrinsics as-is (already at depth resolution)
    # standard: scale intrinsics to match upsampled depth resolution
```

**Impact on point count** (example: da3_ezviz 504×280 depth, 1280×720 RGB):

| Strategy | Resolution | Points/frame | Total (477 frames) |
|----------|-----------|-------------|-------------------|
| Upsample depth → RGB | 1280×720 | ~822,032 | ~270 million |
| **Downsample RGB → depth** | **504×280** | **~141,120** | **~47 million** |

This ~83% reduction in points dramatically improves memory and speed with minimal quality loss since the depth model's actual information content is at its native resolution.

### 5b. Legacy: Upsampling Depth to RGB (Standard Format)

For standard datasets where intrinsics are calibrated at RGB resolution, upsample depth and scale intrinsics:

```python
scale_w = rgb_width / depth_width
scale_h = rgb_height / depth_height
K[0, 0] *= scale_w  # fx
K[1, 1] *= scale_h  # fy
K[0, 2] *= scale_w  # cx
K[1, 2] *= scale_h  # cy
```

**Rule of thumb**: Always work at the resolution where intrinsics are calibrated. For monocular depth estimation outputs (DA3, MiDaS, etc.), this is the depth-native resolution. For real depth sensors (RealSense, Kinect), this is the RGB resolution.

### 6. Update All Dependent Files Systematically

When adding a new format, update:
1. **Adapter class** (`data_adapter.py`): detection, paths, loading methods
2. **Config files** (`config.yaml`): add new file candidates
3. **Config loader** (`config_loader.py`): support new directory names
4. **All pose loaders**: update every `load_poses()` function in the codebase
5. **Main loop**: use per-frame parameters if available

**Checklist**:
- [ ] Adapter detects new format
- [ ] Adapter provides unified API
- [ ] Config lists new file candidates
- [ ] All `load_poses()` support new format
- [ ] Main loop uses per-frame parameters
- [ ] Backward compatibility verified

## Common Pitfalls

1. **Upsampling depth instead of downsampling RGB**: For monocular depth models, intrinsics are calibrated at the depth model's output resolution. Upsampling depth to RGB introduces interpolation artifacts and wastes compute. Work at depth-native resolution.
2. **Forgetting to scale intrinsics**: Only needed when upsampling depth (standard format). For depth-native resolution (da3_ezviz), intrinsics are already correct.
3. **Using global K for per-frame data**: Always use `get_K_for_frame(i)` in main loop
4. **Missing pose format in auxiliary scripts**: Update ALL `load_poses()` functions, not just the main one
5. **Hardcoded directory names**: Use adapter properties (`adapter.images_dir`) not hardcoded paths
6. **Not testing backward compatibility**: Always verify old format still works after changes
7. **Unnecessary confidence map resizing**: When working at depth-native resolution, confidence maps are already aligned — skip the resize

### 7. Handle Additional Data Modalities (Confidence/Quality Maps)

Some datasets include per-pixel quality metrics (e.g., depth confidence maps from monocular depth estimation). Use these to filter low-quality 3D points during reconstruction.

**Adapter side** — provide a method to load the auxiliary data:

```python
def load_confidence(self, frame_idx):
    """Load per-frame confidence map (returns None if unavailable)"""
    if self.dataset_type != "da3_ezviz":
        return None
    conf_path = self.data_dir / "conf" / f"{frame_idx:05d}_conf.npy"
    if conf_path.exists():
        return np.load(str(conf_path))
    return None
```

**Point cloud generation** — add optional confidence filtering to `depth_to_pointcloud()`:

```python
def depth_to_pointcloud(depth, color, K, T_c2w, confidence=None, conf_threshold=0.0):
    valid_mask = (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
    if confidence is not None and conf_threshold > 0:
        valid_mask &= (confidence >= conf_threshold)
    v, u = np.where(valid_mask)
    # ... rest of point cloud generation unchanged
```

**Main loop** — load confidence (no resize needed when working at depth-native resolution):

```python
confidence = None
if CONFIDENCE_THRESHOLD > 0:
    confidence = adapter.load_confidence(i)
    # No resize needed: confidence is already at depth-native resolution

points, colors = depth_to_pointcloud(depth, color, K_frame, T_c2w,
                                      confidence, CONFIDENCE_THRESHOLD)
```

**Config** — make threshold configurable (0 = disabled):

```yaml
reconstruction:
  confidence_threshold: 0.75  # 0 = disabled
```

**Key considerations**:
- When working at depth-native resolution, confidence maps are already aligned with depth — no resize needed
- Return `None` gracefully when the modality is unavailable (standard format has no confidence)
- Use `getattr(cfg.reconstruction, 'confidence_threshold', 0.0)` for backward-compatible config access
- Update ALL scripts that call `depth_to_pointcloud()` (main pipeline + standalone build_pointcloud)
- Typical confidence distribution: threshold 0.75 retains ~90% of points, filtering the least reliable depth estimates

## Verification

Test both formats after changes:

```bash
# Test new format
GLOBAL_RECON_DATA_DIR=./da3_ezviz python reconstruct_and_segment.py

# Test old format (backward compatibility)
python reconstruct_and_segment.py  # uses config default_dir
```

Check:
- Adapter correctly detects format
- All files loaded (depth, RGB, poses, intrinsics, confidence maps)
- File-to-pose mapping works
- Per-frame intrinsics applied
- Confidence filtering applied (when enabled)
- Point cloud generated correctly
- Standard format unaffected when confidence maps are absent
