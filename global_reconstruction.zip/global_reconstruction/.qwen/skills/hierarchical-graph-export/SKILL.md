---
name: hierarchical-graph-export
description: Export monolithic scene_graph.json + PLY files into hierarchical floors/rooms/objects layout compatible with HoloAgent visualize_graph.py
source: auto-skill
extracted_at: '2026-05-27T13:47:22.784Z'
---

# Hierarchical Graph Export for visualize_graph.py

Convert the `reconstruct_and_segment.py` monolithic output (`scene_graph.json` + separate PLY files) into the per-entity JSON+PLY directory layout expected by HoloAgent's `visualize_graph.py`.

## When to Use

- After running `reconstruct_and_segment.py` and wanting to visualize the scene graph with `visualize_graph.py`
- When you need to bridge the `reconstruct_and_segment.py` output format with HoloAgent tools

## Schema Mismatch

`reconstruct_and_segment.py` produces:
```
unified_output/
  scene_graph.json              ← single monolithic JSON
  rooms/floor_*_rooms/room_*.ply  ← room PLYs only, no per-room JSON
  objects/object_*.ply            ← object PLYs only, no per-object JSON
  (no floors/ directory)
```

`visualize_graph.py` expects:
```
<graph_path>/
  floors/<floor_id>.ply + .json   ← per-floor PLY + metadata
  rooms/<room_id>.ply + .json     ← per-room PLY + metadata
  objects/<obj_id>.ply + .json    ← per-object PLY + metadata
```

## ID Naming Convention

| Level | Format | Example |
|---|---|---|
| Floor | `"<F>"` | `"0"` |
| Room | `"<F>_<R>"` | `"0_1"` (floor 0, room 1) |
| Object | `"<F>_<R>_<O>"` | `"0_1_2"` (floor 0, room 1, object 2) |

Where F = floor index, R = room local index within floor, O = object local index within room.

## Required JSON Fields

### floors/*.json
```json
{
  "floor_id": "0",
  "name": "Floor 0",
  "rooms": ["0_0", "0_1", "0_2"],
  "vertices": [[x,y,z], ...],       // 8 corners of 3D bbox
  "floor_height": 3.35,
  "floor_zero_level": -1.49
}
```

### rooms/*.json
```json
{
  "room_id": "0_1",
  "name": "Room 0_1",
  "floor_id": "0",
  "objects": ["0_1_0", "0_1_1"],     // object IDs in this room
  "vertices": [[x,z], ...],           // 4 corners of 2D footprint (XZ)
  "room_height": 4.14,
  "room_zero_level": -1.49
}
```

### objects/*.json
```json
{
  "object_id": "0_1_0",
  "name": "door_3",
  "room_id": "0_1",
  "object_height": 2.96,
  "object_zero_level": -1.49,
  "embedding": [],                    // CLIP embedding (empty if unavailable)
  "view_ids": [],
  "best_view_id": ""
}
```

## Implementation: export_hierarchical_graph()

### Critical Ordering: Pre-compute Object ID Map

The object ID mapping must be **pre-computed before exporting rooms**, because each room's JSON includes its `objects` list. If you export objects after rooms, the room JSON won't know its object IDs.

```python
def export_hierarchical_graph(output_dir, floor_levels, rooms, objects, scene_graph):
    graph_dir = output_dir / "hierarchical_graph"
    floors_dir = graph_dir / "floors"
    rooms_dir = graph_dir / "rooms"
    objects_dir = graph_dir / "objects"

    # === Step 1: Export Floors ===
    room_id_map = {}  # global_room_id → (floor_id_str, room_local_id, room_id_str)
    obj_id_map = {}   # global_obj_id → object_id_str

    for floor_idx, floor_data in enumerate(floor_levels):
        floor_id_str = str(floor_idx)
        # Save floor PLY (points + colors)
        # Compute 8-vertex 3D bbox
        # Collect room IDs for this floor → room_id_map
        # Save floor JSON with rooms list

    # === Step 2: Pre-compute object ID mapping ===
    # MUST be done before room export so rooms can reference their objects
    _room_obj_counter = defaultdict(int)
    for sg_obj in scene_graph.get('objects', []):
        sg_room_id = sg_obj.get('room_id')
        if sg_room_id in room_id_map:
            f_id, _, r_id = room_id_map[sg_room_id]
        else:
            f_id = str(sg_obj.get('floor_id', 0))
            r_id = f"{f_id}_0"
        local = _room_obj_counter[(f_id, r_id)]
        _room_obj_counter[(f_id, r_id)] += 1
        obj_id_map[sg_obj['id']] = f"{f_id}_{r_id.split('_', 1)[1]}_{local}"

    # === Step 3: Export Rooms (now objects list is available) ===
    for floor_idx, floor_data in enumerate(floor_levels):
        for room_local_id, room in enumerate(floor_rooms):
            room_id_str = f"{floor_id_str}_{room_local_id}"
            # Save room PLY
            # Compute room_height, room_zero_level from Y-axis bounds
            # Compute 2D vertices from XZ projection
            # Collect object IDs from obj_id_map → room JSON objects list
            # Save room JSON

    # === Step 4: Export Objects ===
    for sg_obj in scene_graph.get('objects', []):
        object_id_str = obj_id_map[sg_obj['id']]
        # Get points/colors from objects[obj_global_id]
        # Save object PLY
        # Compute object_height, object_zero_level
        # Save object JSON
```

### Height Computation

Use `VERTICAL_AXIS` (Y=1) for height calculations:
```python
# Room height
r_y = room_points[:, VERTICAL_AXIS]
room_zero_level = float(r_y.min())
room_height = float(r_y.max() - r_y.min())

# Object height
o_y = obj_points[:, VERTICAL_AXIS]
object_zero_level = float(o_y.min())
object_height = float(o_y.max() - o_y.min())
```

### 2D Room Footprint

Use `HORIZONTAL_AXES` (XZ=[0,2]):
```python
r_xz = room_points[:, HORIZONTAL_AXES]
v_min = r_xz.min(axis=0)
v_max = r_xz.max(axis=0)
vertices = [
    [float(v_min[0]), float(v_min[1])],
    [float(v_max[0]), float(v_min[1])],
    [float(v_max[0]), float(v_max[1])],
    [float(v_min[0]), float(v_max[1])],
]
```

### Color Handling

Handle both [0,1] float and [0,255] int color ranges:
```python
if colors.max() > 1.0:
    pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
else:
    pcd.colors = o3d.utility.Vector3dVector(colors)
```

## Pipeline Integration

Insert after `build_scene_graph()` but **before** memory cleanup (room/floor points must still be in memory):

```python
# Step [9] Build scene graph
scene_graph = build_scene_graph(global_pcd, rooms, final_objects, merged_info, floor_levels)

# Step [9.6] Export hierarchical graph ← INSERT HERE
export_hierarchical_graph(OUTPUT_DIR, floor_levels, rooms, final_objects, scene_graph)

# Step [10] Top view visualization
# ... (after this, points are freed via del)
```

**Critical**: Must run before `del global_points` and room `del room['points']` cleanup.

## Running visualize_graph.py

```bash
# Install pyvista if needed
pip install pyvista

# Run visualization (off-screen rendering)
cd /path/to/HoloAgent/fsr_vln
python application/visualize_graph.py \
    graph_path=/path/to/unified_output/hierarchical_graph
```

Output: `visualization_result.png` (1024×768)

## Common Pitfalls

1. **Ordering bug**: Exporting objects after rooms without pre-computing ID map → room JSON `objects` lists are empty
2. **Memory timing**: Calling after point cleanup → empty PLY files (0 points)
3. **Color range mismatch**: Not normalizing [0,255] → [0,1] for Open3D colors
4. **Wrong axis**: Using axis 0 instead of VERTICAL_AXIS(1) for height
5. **Stale object references**: Object IDs in scene_graph may not match final_objects indices if filtering happened
6. **Missing floor/room for object**: Objects without valid room_id need fallback (default to "0_0")
7. **Tilted coordinate system**: If trajectory plane rotation is used but data is rotated back to original coordinates before export, all height/area computations will be wrong. The export function must receive data in **aligned coordinates (Y=up)**. See `trajectory-plane-axis-alignment` skill for details.
8. **JSON serialization of numpy types**: `json.dump()` cannot serialize `np.float32`, `np.int64`, etc. — always use `default=str`:
   ```python
   # ❌ WRONG — TypeError: Object of type float32 is not JSON serializable
   json.dump(floor_json, f, indent=2)

   # ✅ CORRECT — uses str() for non-serializable types
   json.dump(floor_json, f, indent=2, default=str)
   ```
   This affects all three export calls (floor/room/object JSON). Even values explicitly cast with `float()` can sometimes retain numpy types through intermediate operations (e.g., `float(np.float32(3.35))` may return `np.float32` in some numpy versions). Using `default=str` as a safety net is essential.

## Verification

After export, verify:
```bash
# Check file counts
ls hierarchical_graph/floors/*.json | wc -l   # should match floor count
ls hierarchical_graph/rooms/*.json | wc -l    # should match room count
ls hierarchical_graph/objects/*.json | wc -l  # should match object count

# Verify JSON cross-references
python -c "
import json, glob
for f in sorted(glob.glob('hierarchical_graph/floors/*.json')):
    data = json.load(open(f))
    for r in data['rooms']:
        room = json.load(open(f'hierarchical_graph/rooms/{r}.json'))
        assert room['floor_id'] == data['floor_id']
        for o in room['objects']:
            obj = json.load(open(f'hierarchical_graph/objects/{o}.json'))
            assert obj['room_id'] == room['room_id']
print('All cross-references valid')
"
```
