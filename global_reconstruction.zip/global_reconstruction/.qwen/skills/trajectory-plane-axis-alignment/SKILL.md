---
name: trajectory-plane-axis-alignment
description: Align coordinate axes to true gravity direction using camera trajectory plane fitting for accurate floor/room segmentation
source: auto-skill
extracted_at: '2026-05-28T08:45:00.000Z'
---

# Trajectory Plane Axis Alignment

When 3D reconstruction outputs have tilted coordinate systems (camera Y-axis ≠ true up), floor/room segmentation based on Y-height produces incorrect results. Use RANSAC plane fitting on camera trajectory to identify the true "up" direction, then rotate the point cloud into aligned space for processing.

## When to Use

- Floor segmentation detects multiple floors in single-floor data
- Height histogram shows spread across walking direction instead of vertical
- Camera trajectory is parallel to ground but coordinate system is tilted
- Monocular depth estimation outputs (DA3, MiDaS) often have world coordinates in camera-relative frame

## Problem Diagnosis

**Symptoms**:
- Floor segmentation: 4 floors detected in single-floor apartment
- Height range: 21m spread in what should be ~0.2m height variation
- Coordinate ranges: one axis has large range (walking direction) but is being used as "height"

**Root cause analysis**:
```python
# Check coordinate ranges in raw poses
positions = np.array([T[:3,3] for T in poses])
for i, ax in enumerate('XYZ'):
    r = positions[:,i]
    print(f'{ax}: [{r.min():.2f}, {r.max():.2f}] range={r.max()-r.min():.2f}m')

# Expected for single-floor indoor:
# - 2 axes: large range (10-25m, walking directions)
# - 1 axis: small range (<1m, height)
# If the axis used as "height" has large range → wrong axis
```

**Check camera orientation**:
```python
# Camera Y-axis in world coordinates (should be ~[0,1,0] if Y=up)
all_ups = np.array([T[:3,1] for T in poses]).mean(axis=0)
print(f'Mean camera up: {all_ups.round(4)}')
# If not close to [0,1,0], coordinate system is tilted
```

## Solution: Trajectory Plane Rotation

### 1. Fit Plane to Camera Trajectory

Camera moves parallel to ground → trajectory points lie on a plane → plane normal = true "up" direction.

```python
def fit_trajectory_plane(positions):
    """RANSAC plane fitting on camera positions"""
    np.random.seed(42)
    n = len(positions)
    best_normal, best_d, best_count = None, None, 0
    
    for _ in range(1000):
        idx = np.random.choice(n, 3, replace=False)
        p1, p2, p3 = positions[idx]
        normal = np.cross(p2 - p1, p3 - p1)
        norm = np.linalg.norm(normal)
        if norm < 1e-6:
            continue
        normal /= norm
        d = -np.dot(normal, p1)
        distances = np.abs(positions @ normal + d)
        inliers = np.where(distances < 0.05)[0]  # 5cm threshold
        if len(inliers) > best_count:
            best_count = len(inliers)
            best_normal = normal
            best_d = d
    
    # Refine with SVD on inliers
    inlier_pts = positions[inliers]
    centroid = inlier_pts.mean(axis=0)
    _, _, vh = np.linalg.svd(inlier_pts - centroid)
    best_normal = vh[-1]
    best_d = -np.dot(best_normal, centroid)
    
    # Ensure normal points "up" (positive Y direction)
    if best_normal[1] < 0:
        best_normal = -best_normal
    
    return best_normal, best_d
```

**Verification**: Height range should be small (<1m for single floor):
```python
heights = positions @ normal + d
print(f'Height range: {heights.max() - heights.min():.2f}m')
# Should be ~0.1-0.5m for single floor
```

### 2. Build Rotation Matrix (Rodrigues Formula)

Rotate the fitted normal to align with Y-axis `[0, 1, 0]`:

```python
def build_trajectory_rotation_matrix(normal):
    """
    Build rotation matrix to align normal → [0, 1, 0]
    
    Returns:
        R: 3x3 rotation matrix (original → aligned)
        R_inv: 3x3 inverse rotation (aligned → original)
    """
    normal = np.asarray(normal, dtype=np.float64)
    normal = normal / np.linalg.norm(normal)
    target = np.array([0.0, 1.0, 0.0])
    
    cos_angle = np.clip(np.dot(normal, target), -1.0, 1.0)
    
    # Already aligned
    if abs(cos_angle - 1.0) < 1e-6:
        return np.eye(3), np.eye(3)
    
    # Opposite direction
    if abs(cos_angle + 1.0) < 1e-6:
        R = np.diag([1.0, -1.0, -1.0])
        return R, R.T
    
    # Rodrigues rotation formula
    v = np.cross(normal, target)
    s = np.linalg.norm(v)
    c = cos_angle
    
    vx = np.array([
        [0, -v[2], v[1]],
        [v[2], 0, -v[0]],
        [-v[1], v[0], 0]
    ])
    
    R = np.eye(3) + vx + vx @ vx * ((1 - c) / (s * s))
    
    # Verify: R @ normal should be close to [0, 1, 0]
    rotated = R @ normal
    if abs(rotated[1] - 1.0) > 0.01:
        R = R.T  # flip if wrong direction
    
    R_inv = R.T  # orthogonal matrix: inverse = transpose
    return R, R_inv
```

### 3. Forward Rotation (Before Segmentation)

Rotate point cloud and poses into aligned space where Y = true height:

```python
# After fitting trajectory plane
R_align, R_align_inv = build_trajectory_rotation_matrix(normal)

# Rotate global points
global_points = (R_align @ global_points.T).T.astype(np.float32)

# Rotate poses (for downstream use)
R_align_4x4 = np.eye(4)
R_align_4x4[:3, :3] = R_align
for ts in poses:
    poses[ts] = R_align_4x4 @ poses[ts]

print(f'Rotated {len(global_points):,} points + {len(poses)} poses')

# Now floor/room segmentation works correctly
floor_levels = segment_floors(global_points, global_colors)
# ... room segmentation ...
```

**Verification after rotation**:
```python
rotated_positions = (R_align @ positions.T).T
for i, ax in enumerate('XYZ'):
    r = rotated_positions[:,i]
    print(f'{ax}: range={r.max()-r.min():.2f}m')
# Y should now have small range (<1m)
```

### 4. KEEP Aligned Coordinates (Do NOT Rotate Back)

**Critical**: Do NOT rotate back to original coordinates after segmentation. All downstream steps assume Y=up:

- Gateway detection (uses `VERTICAL_AXIS` for floor masking)
- Scene graph building (uses `HORIZONTAL_AXES=[0,2]` for room adjacency and distance)
- Top-view generation (projects onto XZ plane)
- Hierarchical graph export (uses Y for height, XZ for area)

If you rotate back to original (tilted) coordinates, ALL of these produce wrong results.

```python
# ✅ CORRECT: Keep everything in aligned coordinates
# After floor/room segmentation, just continue processing
# global_points, floor_levels, rooms all stay in aligned space (Y=up)

# Save global point cloud PLY in aligned coordinates (overwrite pre-rotation version)
save_point_cloud(global_pcd_file, global_points, global_colors)
```

```python
# ❌ WRONG: Rotating back to original coordinates
# global_points = (R_align_inv @ global_points.T).T  # DON'T DO THIS
# for floor_data in floor_levels:
#     floor_data['points'] = (R_align_inv @ ...)      # DON'T DO THIS
```

### 5. Pose Handling for Downstream Steps

Poses are already rotated in step 3 (in-place). Do NOT reload from disk later:

```python
# Step 3: Rotates poses in-place
for ts in poses:
    poses[ts] = R_align_4x4 @ poses[ts]

# ... later in pipeline (e.g., step 7 trajectory fitting, gateway detection) ...
# ✅ CORRECT: Use the already-rotated poses variable
trajectory_plane = fit_trajectory_plane_from_poses(poses)
positions = np.array([T[:3, 3] for T in poses.values()])

# ❌ WRONG: Reloading from disk gives original (un-rotated) poses
# poses = load_poses(POSES_FILE)  # DON'T DO THIS - overwrites aligned poses
```

### 6. Apply R_align to Object Point Clouds

**Critical**: Object point clouds are accumulated from 2D→3D reprojection **before** the R_align rotation is applied. The pose-based reprojection uses unrotated poses, so `obj['points']` and `obj['center']` are in the **original coordinate system**, not the aligned one.

After computing `R_align`, rotate all object point clouds to match the aligned global point cloud:

```python
# After: global_points = (R_align @ global_points.T).T
# After: poses[ts] = R_align_4x4 @ poses[ts]

# ALSO rotate all accumulated object instances:
for obj in all_objects:
    obj['points'] = (R_align @ obj['points'].T).T
    obj['center'] = (R_align @ obj['center'])

print(f'  ✓ 已旋转 {len(global_points):,} 个点 + {len(poses)} 个位姿 + {len(all_objects)} 个物体实例')
```

**Why**: If objects are NOT rotated:
- Room PCDs are in aligned coordinates (Y=up)
- Object PCDs are in original coordinates (Y≠up)
- In `visualize_graph.py`, objects appear displaced from their rooms
- Scene graph room→object links point to wrong positions

**Where to apply**: In `reconstruct_and_segment.py`, after pose rotation and before object merging (step [4] cross-frame merge):

```python
# Line ~2939 in reconstruct_and_segment.py:
R_align_4x4 = np.eye(4)
R_align_4x4[:3, :3] = R_align
for ts in poses:
    poses[ts] = R_align_4x4 @ poses[ts]

# INSERT here:
for obj in all_objects:
    obj['points'] = (R_align @ obj['points'].T).T
    obj['center'] = (R_align @ obj['center'])
```

This ensures all downstream steps (object merging, scene graph building, hierarchical export) operate on objects in the same aligned coordinate system as rooms and floors.

## Integration Pattern

**Pipeline flow** (all in aligned coordinates — NO reverse rotation):
1. Load poses (without coordinate transforms for formats that already have Y≈up)
2. Fit trajectory plane → get normal
3. Build rotation matrix R_align, R_align_inv (keep R_inv for reference, but do not use)
4. **Forward rotate**: global_points, poses (in-place)
5. **Re-save global PLY** in aligned coordinates (overwrites pre-rotation version)
6. **Process in aligned space**: floor segmentation, room segmentation
7. **Continue in aligned space**: object merge, gateway detection, scene graph, top-view, export
8. Save all outputs in aligned coordinates (Y=up)

**Code structure**:
```python
# Step 3: Trajectory plane fitting
trajectory_plane_result = fit_trajectory_plane_from_poses(poses)
R_align, R_align_inv = build_trajectory_rotation_matrix(
    trajectory_plane_result['normal']
)

# Forward rotation
global_points = (R_align @ global_points.T).T.astype(np.float32)
R_align_4x4 = np.eye(4)
R_align_4x4[:3, :3] = R_align
for ts in poses:
    poses[ts] = R_align_4x4 @ poses[ts]

# Re-save global PLY in aligned coordinates
save_point_cloud(global_pcd_file, global_points, global_colors)

# ... floor/room segmentation in aligned space ...
# ... gateway detection in aligned space (using already-rotated poses) ...
# ... scene graph, top-view, hierarchical export — all in aligned space ...
# NO reverse rotation at any point
```

## Coordinate Transform Considerations

**Disable format-specific transforms** for datasets that already have Y≈up:

```python
# da3_ezviz (DA3-Streaming) has Y≈up, don't apply Z→Y swap
USE_AXIS_TRANSFORM = (
    cfg.coordinate.use_axis_transform and 
    adapter.dataset_type != "da3_ezviz"
)

if cfg.coordinate.use_axis_transform and adapter.dataset_type == "da3_ezviz":
    print("  ℹ️  da3_ezviz: skip axis transform (Y already ≈ up)")
```

**Why this matters**: Applying a Z→Y swap to data that already has Y≈up will swap the walking direction into height, causing the exact problem this technique solves.

## Real-World Example

**da3_ezviz dataset** (477 frames, single-floor apartment):
- Original: X=14m, Y=7m, Z=22m → Y used as height → 4 fake floors
- Camera tilt: ~17° from Y-up
- After trajectory plane rotation: X=14m, **Y=0.18m**, Z=23m → 1 floor ✅

**Key metrics**:
- Trajectory plane fit: 449/477 inliers (94%), mean deviation 19mm
- Rotation angle: 17.3°
- Height range before: 21.86m (walking direction)
- Height range after: 0.18m (true height)

## Common Pitfalls

1. **Applying coordinate transforms to already-aligned data**: Check if Y is already close to up before applying Z→Y swaps
2. **Forgetting to rotate poses**: Downstream steps (gateway detection, trajectory export) need rotated poses
3. **Rotating back to original coordinates**: DO NOT rotate back after segmentation. All downstream steps (Gateway, scene graph, top-view, hierarchical export) assume Y=up. Rotating back breaks ALL of them.
4. **Reloading poses from disk after rotation**: `load_poses()` gives original (un-rotated) poses, which overwrites the already-rotated in-memory poses. Use the in-memory `poses` variable instead.
5. **Using wrong axis for height**: Always verify coordinate ranges match expectations before segmentation
6. **Hardcoding axis indices**: Use named constants or check which axis has smallest range
7. **Not verifying rotation**: Always check `R @ normal ≈ [0, 1, 0]` and `R @ R_inv = I`
8. **Saving global PLY before rotation**: If you save global PLY before step 3, it's in wrong coordinates. Re-save after rotation, or defer saving until after rotation.

## Verification Checklist

- [ ] Trajectory plane fitted with high inlier ratio (>90%)
- [ ] Height range in aligned space <1m for single floor
- [ ] Rotation matrix verified: `R @ normal ≈ [0, 1, 0]`
- [ ] Rotation matrix orthogonal: `R @ R.T = I`
- [ ] Floor segmentation produces expected number of floors
- [ ] Room segmentation produces reasonable room count
- [ ] Global PLY re-saved in aligned coordinates (after rotation)
- [ ] Poses NOT reloaded from disk after rotation
- [ ] No reverse rotation applied — all outputs in aligned coordinates (Y=up)
- [ ] Downstream steps (gateway detection, scene graph, top-view) work correctly
- [ ] Top-view projection looks reasonable (floor plan visible, not distorted)
- [ ] visualize_graph.py renders scene graph with correct viewing angle

## Related Skills

- **dataset-format-adaptation**: Understanding coordinate systems in different dataset formats
- **incremental-voxel-downsampling**: Memory management for large point clouds (unrelated but often used together)
