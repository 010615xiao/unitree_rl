---
name: sam3-prompt-effectiveness
description: SAM3 text prompt effectiveness patterns — which prompt styles work vs fail, and fallback strategies when specific object names are not recognized
source: auto-skill
extracted_at: '2026-05-28T14:30:00.000Z'
---

# SAM3 Prompt Effectiveness Patterns

## Problem

SAM3's text-prompted segmentation is inconsistent with specific object category names. Some common indoor objects (e.g., `hand dryer`, `vending machine`) produce zero masks even though they are clearly visible in the image.

## Root Cause

SAM3's text encoder was trained on a specific vocabulary. If an object name is not in its training vocabulary, it may return zero detections even with a high-quality mask model. This is different from classification models — SAM3 needs to **understand the text prompt** to guide mask generation.

## Tested Prompts — What Works vs What Doesn't

Testing on bathroom scene (frame 25, wall-mounted hand dryer clearly visible):

### Failed Prompts (0 masks)

| Prompt | Result |
|--------|--------|
| `hand dryer` | 0 masks |
| `hand_dryer` | 0 masks |
| `air dryer` | 0 masks |
| `hand blower` | 0 masks |
| `wall-mounted dryer` | 0 masks |
| `bathroom dryer` | 0 masks |
| `water dispenser` | 0 masks |
| `soap dispenser` | 0 masks |

### Successful Prompts (1+ masks)

| Prompt | Masks | Best Score |
|--------|-------|------------|
| `wall-mounted device` | 1 | 0.81 |
| `dispenser` | 1 | 0.75 |
| `white wall device` | 1 | 0.69 |
| `wall-mounted equipment` | 1 | 0.61 |
| `bathroom fixture` | 1 | 0.50 |

## Key Insight

**Generic descriptive prompts often work better than specific object names.**

SAM3 responds well to:
- **Structural descriptions**: `wall-mounted device`, `white box on wall`
- **Functional categories**: `dispenser`, `appliance`
- **Contextual labels**: `bathroom fixture`

SAM3 often fails with:
- **Compound nouns**: `hand dryer`, `water dispenser`
- **Underscored names**: `hand_dryer`, `trash_can`
- **Specific product types** not in training vocabulary

## Strategy: Two-Phase Prompting

### Phase 1: Try specific name (VLM output)

```python
# VLM detects "hand dryer" → try it first
sam3_text = obj_info.get('sam3_prompt', category)  # e.g., "hand dryer"
detections = sam3_segment(color_file, sam3_text)
```

### Phase 2: Fallback to generic prompt if zero masks

```python
if not detections:
    # Try fallback prompts known to work for this category
    FALLBACK_PROMPTS = {
        'hand_dryer': ['wall-mounted device', 'dispenser'],
        'vending_machine': ['wall-mounted device', 'machine'],
        'water_dispenser': ['dispenser', 'wall-mounted device'],
        'soap_dispenser': ['dispenser', 'wall-mounted device'],
        # Add more as needed
    }
    
    for fallback in FALLBACK_PROMPTS.get(category, []):
        detections = sam3_segment(color_file, fallback)
        if detections:
            print(f"  SAM3 fallback: {category} → '{fallback}' → {len(detections)} masks")
            break
```

### Special Cases: Hard-coded sam3_prompt

For categories known to fail, set a `sam3_prompt` override (like `water_dispenser → 'a water cooler'`):

```python
if category == 'water_dispenser':
    obj_info['sam3_prompt'] = 'a water cooler'
if category == 'hand_dryer':
    obj_info['sam3_prompt'] = 'wall-mounted device'
```

## How to Test New Categories

When a new category produces zero masks, systematically test:

```python
img_path = 'path/to/test/image.jpg'
category = 'hand_dryer'

# Test specific names
specific = ['hand dryer', 'hand_dryer', 'air dryer', 'hand blower']
# Test generic descriptors
generic = ['wall-mounted device', 'dispenser', 'white wall device',
           'wall-mounted equipment', 'bathroom fixture', 'appliance']
# Test with articles
with_articles = ['a hand dryer', 'the hand dryer']

all_prompts = specific + generic + with_articles

for prompt in all_prompts:
    resp = requests.post(SAM3_URL, json={'image_path': img_path, 'text': prompt}, timeout=30)
    result = resp.json()
    n = len(result.get('masks', [])) if result.get('success') else 0
    scores = result.get('scores', [])[:3] if n > 0 else []
    print(f'  {prompt!r:30s} → {n} mask(s)  scores={scores}')
```

## When to Use

- Any time a VLM-detected category produces zero SAM3 masks
- When adding new object categories to the detection pipeline
- When debugging why SAM3 isn't segmenting visible objects

## Pitfalls

1. **Don't give up after one failed prompt**: A category name that fails may have a generic descriptor that works.
2. **Underscores don't help**: `hand_dryer` and `hand dryer` often both fail — the issue is vocabulary, not formatting.
3. **Articles sometimes matter**: `a water cooler` may work better than `water cooler` (SAM3 was tested with natural language descriptions).
4. **Context matters**: `bathroom fixture` works in a bathroom but may not be the right descriptor in an office.
5. **Save successful prompts**: When you find a prompt that works for a category, add it to `FALLBACK_PROMPTS` or the `sam3_prompt` override so you don't have to rediscover it.
