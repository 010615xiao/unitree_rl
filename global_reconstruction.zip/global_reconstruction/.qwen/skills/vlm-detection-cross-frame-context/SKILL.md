---
name: vlm-detection-cross-frame-context
description: Multi-frame VLM detection: history image thumbnails, cross-frame category voting, and prompt injection for consistent object detection across sequential frames
source: auto-skill
extracted_at: '2026-05-28T12:30:00.000Z'
---

# VLM Detection with Cross-Frame Context

## Problem

In multi-frame 3D scene reconstruction pipelines, VLM-based object detection runs independently on each detection frame. This causes:

1. **Category name inconsistency**: The same physical object may be named differently across frames (e.g., `chair`, `office_chair`, `swivel_chair`)
2. **Hallucinated categories**: Open-ended prompts encourage VLM to invent category names that downstream SAM3 segmentation doesn't recognize
3. **Token waste**: Long prompts with examples and category lists consume ~500 tokens per call but VLM doesn't reliably follow all rules
4. **Confidence is subjective**: VLM's `confidence` field reflects the model's self-assessment, not real probability — it's unreliable for filtering and was unused downstream
5. **JSON format instability**: VLM sometimes outputs bare arrays `[{"category":...}]` or comma-separated objects instead of `{"objects":[...]}`

## Solution: Multi-Frame History + Category Context + Robust Parsing

### State Variable

Maintain a running dictionary of discovered categories across the entire dataset:

```python
discovered_categories = {}  # canonical_name → detection_count
```

### Prompt Injection

Pass `discovered_categories` to the VLM detection function. When non-empty, the prompt injects known category names:

```
Previously detected objects in this scene: chair, desk, floor, wall.
Use these exact category names if those objects are still visible.
```

This makes the VLM **self-reinforcing** — once a category name is established, subsequent frames prefer that same name.

### Category Canonicalization

Use a synonym mapping to normalize VLM output:

```python
CATEGORY_SYNONYMS = {
    "desk": ["office_desk", "work_desk"],
    "chair": ["office_chair", "desk_chair"],
    "sofa": ["couch"],
    "tv": ["television"],
}

def _canonicalize_category(cat):
    cat = cat.lower().strip().replace(' ', '_').replace('-', '_')
    for canonical, synonyms in CATEGORY_SYNONYMS.items():
        if cat == canonical or cat in synonyms:
            return canonical
    return cat
```

### Simplified Prompt

Remove examples, confidence rules, and exhaustive category lists. Keep only 4 core rules:

```
You are an indoor object detection assistant. Detect indoor objects and output STRICT JSON.

## Output Format (MANDATORY)
{"objects":[{"category":"name"},...]}
NO markdown, NO explanations.

## Detection Rules
1. Categories: Use short, common names (e.g., "chair" NOT "office_chair").
   If you detect an object that maps to one of the known categories below, use the known name.
2. Visibility: ONLY include objects ≥50% visible.
3. Limit: Max 12 objects. Prioritize larger/prominent ones.
4. Skip: ceiling, sky, outdoor objects, pets.

Previously detected objects in this scene: {known_categories}.
Use these exact category names if those objects are still visible.

Analyze the image and output ONLY the JSON object NOW:
```

### Pipeline Integration

```python
# Main loop:
discovered_categories = {}  # canonical_name → count
detection_history_images = []  # [(file_path, base64_thumb), ...]
VLM_MAX_HISTORY = 3
VLM_HISTORY_THUMB_SIZE = (512, 384)

for each detection frame:
    # 1. Create thumbnail of current frame and add to history buffer
    thumb = cv2.resize(color, VLM_HISTORY_THUMB_SIZE, interpolation=cv2.INTER_AREA)
    _, buf = cv2.imencode('.jpg', thumb, [cv2.IMWRITE_JPEG_QUALITY, 80])
    thumb_b64 = base64.b64encode(buf.tobytes()).decode('utf-8')
    detection_history_images.append((str(color_file), thumb_b64))

    # 2. Keep only most recent N frames (sliding window)
    if len(detection_history_images) > VLM_MAX_HISTORY:
        detection_history_images = detection_history_images[-VLM_MAX_HISTORY:]

    # 3. Pass history (excluding current frame) to VLM
    history_for_vlm = detection_history_images[:-1] if len(detection_history_images) > 1 else None

    detected_objects = vlm_detect_objects(
        color_file, discovered_categories, history_images=history_for_vlm,
    )

    # 4. Update discovered categories after each VLM call
    for obj in detected_objects:
        cat = obj['category']
        discovered_categories[cat] = discovered_categories.get(cat, 0) + 1
```

### Multi-Frame VLM API Call

OpenAI-compatible APIs support multiple images in a single `content` array:

```python
content_items = []

# Add history frames (if any)
if history_images:
    for _, hist_b64 in history_images:
        content_items.append({
            "type": "image_url",
            "image_url": {"url": f"data:image/png;base64,{hist_b64}"},
        })

# Add current frame (LAST — VLM must know which frame to detect in)
content_items.append({
    "type": "image_url",
    "image_url": {"url": f"data:image/png;base64,{image_base64}"},
})

# Add text prompt
content_items.append({"type": "text", "text": prompt})
```

The prompt explicitly tells VLM:
- "The LAST image is the current frame you should detect objects in"
- "Use earlier frames for context if helpful"

### Robust JSON Parsing

VLM output can vary in format. Parse with fallbacks:

```python
try:
    detection_result = json.loads(content)
except json.JSONDecodeError:
    # Try wrapping as array: {"category":"a"}, {"category":"b"} → [{...}, {...}]
    fixed = content.strip().strip(',').strip()
    if not fixed.startswith('['):
        fixed = f'[{fixed}]'
    if not fixed.endswith(']'):
        fixed = fixed + ']'
    detection_result = json.loads(fixed)

# Extract objects list (supports both {"objects":[...]} and bare array)
if isinstance(detection_result, dict):
    objects = detection_result.get('objects', [])
    if not isinstance(objects, list):
        objects = [detection_result]  # single object
elif isinstance(detection_result, list):
    objects = detection_result
else:
    return []
```

## How It Works in Practice

```
Frame 12 (1st detection):
  history_images: []
  VLM input: [Frame_12_full] + prompt (no context)
  VLM → ["chair", "office_chair", "desk", "wall", "floor"]
  Canonicalize → {chair: 1, desk: 1, wall: 1, floor: 1}

Frame 24 (2nd detection):
  history_images: [(Frame_12_thumb)]
  VLM input: [Frame_12_thumb, Frame_24_full] + "Previously detected: chair, desk, floor, wall"
  VLM → ["chair", "desk", "wall", "floor", "monitor"]  ← consistent names + new
  Canonicalize → {chair: 2, desk: 2, wall: 2, floor: 2, monitor: 1}

Frame 36 (3rd detection):
  history_images: [(Frame_12_thumb), (Frame_24_thumb)]
  VLM input: [Frame_12, Frame_24, Frame_36] + "Previously detected: chair, desk, floor, monitor, wall"
  VLM → ["chair", "wall", "floor"]  ← desk occluded, but name stays in context
  Canonicalize → {chair: 3, desk: 2, wall: 3, floor: 3, monitor: 1}

Frame 48 (4th detection):
  history_images: [(Frame_12), (Frame_24), (Frame_36)] → truncated to 3 → [(Frame_24), (Frame_36)]
  VLM input: [Frame_24, Frame_36, Frame_48] + full category context
  → Sliding window of visual context, append-only category context
```

## Key Design Decisions

1. **Two independent context channels**: Visual context (history images, sliding window of 3) and category context (discovered_categories, append-only). They reinforce each other but operate independently.
2. **History thumbnails are small**: 512x384 JPEG at 80% quality ≈ 30-50KB base64 per frame. 3 history frames add ~150KB token overhead.
3. **Current frame is always full resolution**: History frames provide context; the current frame is what VLM actually detects objects in.
4. **Prompt position matters**: Current frame must be the LAST image in the content array. The prompt explicitly states this.
5. **Append-only discovered categories**: Once a category is discovered, it stays in the context even if occluded in later frames. This prevents the VLM from "forgetting" established names.
6. **Count tracking, not filtering**: We count how many times each category appears but don't filter based on count. The count is useful for debugging/reporting but doesn't affect merging.
7. **No confidence field**: The VLM prompt no longer asks for `confidence` — downstream code never used it for filtering. If needed, the presence of a category in `discovered_categories` with a high count implicitly indicates consistent visibility.
8. **Synonym map as safety net**: Even if the VLM ignores the context and outputs a variant name, `_canonicalize_category` catches it.
9. **JSON parsing with fallbacks**: VLM output format is unpredictable. Try standard parse first, then try wrapping as array, then extract from dict or list.

## Correct/ Wrong Prompt Examples

Include both correct and wrong examples in the prompt to anchor VLM output format:

```
### Correct examples:
{"objects":[{"category":"chair"},{"category":"desk"},{"category":"wall"}]}
{"objects":[{"category":"sofa"},{"category":"tv"},{"category":"floor"},{"category":"window"}]}
{"objects":[]}

### WRONG (never do this):
[{"category":"chair"},{"category":"desk"}]          ← bare array, missing "objects" key
{"objects":[{"category":"chair","confidence":0.9}]}   ← no "confidence" field
{"objects":[{"category":"Office Chair"}]}             ← not lowercase, not short name
```

This reduced JSON parsing failures significantly compared to the original prompt that only showed the format spec.

## Ambiguous Object Distinction Rules

Some objects are visually similar and VLM may confuse them. Add explicit distinction rules in the prompt:

```
5. If it has product display and payment interface (coin slot, card reader, QR code),
   call it "vending_machine" NOT "refrigerator".
6. "refrigerator" is ONLY for kitchen-style fridges (solid doors, handles, kitchen context).
```

**Design principle**: Use positive features (what it HAS) and negative context (what it's NOT) to disambiguate. Don't use hard synonym mapping for ambiguous cases — let the prompt rule do the work so `refrigerator` can still appear when it's actually a kitchen fridge.

**When to add**: Whenever you notice a consistent misclassification pattern in VLM output. Test the rule on multiple frames to confirm it helps without causing false positives.

## When to Use

- Sequential frame processing where VLM detects object categories
- Multi-camera pipelines where different views may name objects differently
- Any scenario where category name consistency matters for downstream processing (SAM3 text prompts, object merging, semantic aggregation)

## Pitfalls

1. **Synonym map must be maintained**: If VLM outputs a new variant, add it to `CATEGORY_SYNONYMS` or add a rule in `_canonicalize_category`.
2. **Cross-frame context only works with VLM**: If VLM is unavailable and fallback to fixed categories, `discovered_categories` won't be populated.
3. **Don't filter by count**: A category seen only once may still be valid (e.g., a rare object that appears in only one frame). Use count for reporting, not for filtering.
4. **New scenes start empty**: The first detection frame has no context — the VLM output quality on the first frame is critical. Consider a more specific prompt for the first call if needed.
