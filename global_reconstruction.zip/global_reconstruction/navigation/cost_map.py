#!/usr/bin/env python3
"""
Cost Map Generator: 为可行走区域计算基于障碍物距离的代价

1. 对 floor grid 计算 distance transform (每个单元格到最近障碍物的距离)
2. 归一化为 cost: 远离障碍物 = 低代价, 靠近障碍物 = 高代价
3. A* 规划时结合距离代价 + 路径长度,走出更安全的路线
  
  - distance: 到最近障碍物的距离 (米)
  - sigma: 影响范围 (默认 0.5m)
  - distance_weight: 障碍物避障权重 (默认 5.0)
  - base_cost: 基础移动代价 (默认 1.0)
"""

import numpy as np
from scipy.ndimage import distance_transform_edt
from typing import Tuple, Optional


class CostMap:
    """导航代价地图"""
    
    def __init__(self, grid: np.ndarray, resolution: float,
                 x_min: float, z_min: float,
                 sigma: float = 0.5,
                 distance_weight: float = 5.0,
                 base_cost: float = 1.0,
                 complete_boundary_wall: bool = True):
        """
        Args:
            grid: 栅格地图 (0=未知, 1=可行走, 100=障碍物)
            resolution: 栅格分辨率 (米)
            x_min, z_min: 栅格左下角世界坐标
            sigma: 障碍物影响范围 (米)
            distance_weight: 障碍物避障权重
            base_cost: 基础移动代价
            complete_boundary_wall: floor 外围补全 wall
        """
        self.grid = grid.copy()
        self.resolution = resolution
        self.x_min = x_min
        self.z_min = z_min
        self.sigma = sigma
        self.distance_weight = distance_weight
        self.base_cost = base_cost
        
        self.height, self.width = grid.shape
        self.cost_map = None
        self.distance_map = None
        
        # 补全外围 wall
        if complete_boundary_wall:
            self._complete_boundary_wall()
        
        self._compute()
    
    def _complete_boundary_wall(self):
        """
        floor 外围补全 wall (点云重建缺失)

        1. 找到 floor 区域的外边界 (形态学膨胀 - 原区域 = 边界环)
        2. 将边界环外围紧邻的未知区域标记为 wall
        3. 确保 distance transform 时外围 wall 也被计入
        """
        floor_mask = (self.grid == 1).astype(np.uint8)

        if floor_mask.sum() == 0:
            return

        from scipy.ndimage import binary_dilation, binary_erosion, label

        # Step 1: 对 floor 做膨胀，覆盖 floor 边缘的噪声/缺口
        floor_dilated = binary_dilation(floor_mask, iterations=2).astype(np.uint8)

        # Step 2: 膨胀后的区域 减去 原 floor = 外扩环 (紧邻 floor 外围)
        outer_ring = floor_dilated & (self.grid == 0)

        if outer_ring.sum() < 100:
            # 膨胀 5 个像素, 取外围
            floor_dilated2 = binary_dilation(floor_mask, iterations=5).astype(np.uint8)
            boundary_band = floor_dilated2 & (~floor_mask.astype(np.uint8))
            outer_ring = boundary_band & (self.grid == 0)

        if outer_ring.sum() > 0:
            self.grid[outer_ring.astype(bool)] = 100

        # Step 3: 在栅格四条边的未知区域补一圈 wall (防止边缘开放)
        margin = 2
        edge_unknown = (self.grid[0:margin, :] == 0)
        self.grid[0:margin, :][edge_unknown] = 100
        edge_unknown = (self.grid[-margin:, :] == 0)
        self.grid[-margin:, :][edge_unknown] = 100
        edge_unknown = (self.grid[:, 0:margin] == 0)
        self.grid[:, 0:margin][edge_unknown] = 100
        edge_unknown = (self.grid[:, -margin:] == 0)
        self.grid[:, -margin:][edge_unknown] = 100

        new_wall_count = int(np.sum(self.grid == 100))
        print(f"  补全外围 wall: 新增 {new_wall_count} 个障碍单元格")
    
    def _compute(self):
        """计算 distance transform 和 cost map"""
        # 只对实际障碍物 (100) 做 distance transform
        # 未知区域 (0) 不作为障碍物参与距离计算,否则 walkable 紧贴 unknown 导致距离全为 0
        obstacle_only = (self.grid == 100).astype(np.uint8)

        if obstacle_only.sum() == 0:
            dist_pixels = np.ones((self.height, self.width), dtype=np.float64) * 100
        else:
            # Euclidean distance transform 从每个 walkable 单元格到最近障碍物的像素距离
            # distance_transform_edt 从 0 值像素到最近非 0 值像素的距离
            dist_pixels = distance_transform_edt(1 - obstacle_only)

        # 转换为米
        self.distance_map = dist_pixels * self.resolution

        # Cost map: 距离越近,代价越高
        # 高斯衰减: cost = base_cost + weight * exp(-d² / (2*σ²))
        sigma_pixels = self.sigma / self.resolution
        self.cost_map = self.base_cost + self.distance_weight * np.exp(
            -0.5 * (dist_pixels / sigma_pixels) ** 2
        )

        # 障碍物区域设置高代价
        self.cost_map[obstacle_only == 1] = 1000.0

        # 未知区域设置较高代价
        unknown_mask = (self.grid == 0)
        self.cost_map[unknown_mask] = np.maximum(self.cost_map[unknown_mask], 50.0)
    
    def get_cost(self, row: int, col: int) -> float:
        """获取单元格代价"""
        if 0 <= row < self.height and 0 <= col < self.width:
            return float(self.cost_map[row, col])
        return 1000.0  # 越界 = 极高代价
    
    def get_distance(self, row: int, col: int) -> float:
        """获取到最近障碍物的距离 (米)"""
        if 0 <= row < self.height and 0 <= col < self.width:
            return float(self.distance_map[row, col])
        return 0.0
    
    def get_cost_between_cells(self, r1: int, c1: int, r2: int, c2: int) -> float:
        """
        计算两个单元格之间的移动代价
        
        使用两个单元格的平均 cost,加上对角线惩罚
        """
        cost1 = self.get_cost(r1, c1)
        cost2 = self.get_cost(r2, c2)
        
        # 基础移动代价: 平均 cost
        base = (cost1 + cost2) / 2.0
        
        # 对角线移动惩罚 (sqrt(2) 倍)
        if abs(r1 - r2) == 1 and abs(c1 - c2) == 1:
            return base * 1.414
        
        return base
    
    def visualize(self, output_path: str = "cost_map.png"):
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 3, figsize=(24, 8))

        # 获取可行走区域的统计值
        valid_dist = self.distance_map[self.grid == 1]
        valid_cost = self.cost_map[self.grid == 1]

        d_vmin = 0.0
        d_vmax = float(np.percentile(valid_dist, 99)) if len(valid_dist) > 0 else 1.0

        c_vmin = float(valid_cost.min()) if len(valid_cost) > 0 else 0.0
        c_vmax = float(np.percentile(valid_cost, 99)) if len(valid_cost) > 0 else 10.0

        # Distance Map
        ax1 = axes[0]
        dist_vis = np.ma.masked_where(self.grid != 1, self.distance_map)
        im1 = ax1.imshow(dist_vis, cmap='viridis', origin='lower',
                        extent=[self.x_min, self.x_min + self.width * self.resolution,
                               self.z_min, self.z_min + self.height * self.resolution],
                        aspect='equal', vmin=d_vmin, vmax=d_vmax)
        plt.colorbar(im1, ax=ax1, label='Distance to obstacle (m)')
        ax1.set_title(f'Distance to Nearest Obstacle\n'
                     f'Mean: {valid_dist.mean():.2f}m, '
                     f'Min: {valid_dist.min():.2f}m, '
                     f'P99: {d_vmax:.2f}m', fontsize=14)
        ax1.set_xlabel('X (m)')
        ax1.set_ylabel('Z (m)')
        ax1.grid(True, alpha=0.3)

        # Cost Map
        ax2 = axes[1]
        cost_vis = np.ma.masked_where(self.grid != 1, self.cost_map)
        im2 = ax2.imshow(cost_vis, cmap='hot_r', origin='lower',
                        extent=[self.x_min, self.x_min + self.width * self.resolution,
                               self.z_min, self.z_min + self.height * self.resolution],
                        aspect='equal', vmin=c_vmin, vmax=c_vmax)
        plt.colorbar(im2, ax=ax2, label='Navigation cost')
        ax2.set_title(f'Navigation Cost Map (vmin={c_vmin:.2f}, vmax={c_vmax:.2f})\n'
                     f'Low cost (green) = safe, High cost (red) = near obstacles', fontsize=14)
        ax2.set_xlabel('X (m)')
        ax2.set_ylabel('Z (m)')
        ax2.grid(True, alpha=0.3)

        # Cost 分布直方图
        ax3 = axes[2]
        ax3.hist(valid_cost, bins=100, color='steelblue', alpha=0.7, edgecolor='none')
        ax3.axvline(valid_cost.mean(), color='red', linestyle='--',
                   label=f'Mean: {valid_cost.mean():.2f}')
        ax3.axvline(np.median(valid_cost), color='green', linestyle='--',
                   label=f'Median: {np.median(valid_cost):.2f}')
        ax3.set_title('Cost Distribution (walkable cells)', fontsize=14)
        ax3.set_xlabel('Cost')
        ax3.set_ylabel('Count')
        ax3.legend()
        ax3.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  已保存: {output_path}")


def create_cost_map_from_grid(grid: np.ndarray, resolution: float,
                              x_min: float, z_min: float,
                              **kwargs) -> CostMap:
    return CostMap(grid, resolution, x_min, z_min, **kwargs)


if __name__ == '__main__':
    import pickle
    from pathlib import Path
    
    grid_map_path = Path(__file__).parent.parent / "unified_output/navigation/grid_map_floor.pkl"
    
    if grid_map_path.exists():
        with open(grid_map_path, 'rb') as f:
            grid_data = pickle.load(f)
        
        cost_map = CostMap(
            grid=grid_data['grid'],
            resolution=grid_data['resolution'],
            x_min=grid_data['x_min'],
            z_min=grid_data['z_min'],
            sigma=0.5,
            distance_weight=5.0,
            base_cost=1.0
        )
        
        output_dir = Path(__file__).parent / "viz_floor_obstacle"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        cost_map.visualize(str(output_dir / "07_cost_map.png"))
        print("Cost map 生成完成!")
    else:
        print(f"未找到栅格地图: {grid_map_path}")
