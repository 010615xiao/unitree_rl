#!/usr/bin/env python3
"""
2D 栅格地图生成
1. Floor: Y 阈值提取 (最低点 + threshold)
2. 填充 floor 空洞: 基于 floor 点云的 convex hull + 插值
3. 障碍物: 高度阈值 + scene graph 中的 wall/pillar 对象
4. Gateway: scene graph 中的 door 对象
5. 房间: scene graph 中的 rooms (用于定位)
"""

import numpy as np
import open3d as o3d
from scipy.ndimage import binary_dilation, binary_erosion, label, distance_transform_edt
from scipy.spatial import ConvexHull, Delaunay
from pathlib import Path
import json
import pickle


class GridMap:
    """2D 栅格地图 - 基于实际 floor + scene graph 信息"""
    
    def __init__(self, floor_points_2d, obstacle_points_2d=None, resolution=0.05, padding=10):
        self.resolution = resolution
        self.padding = padding
        
        # 边界计算
        if obstacle_points_2d is not None and len(obstacle_points_2d) > 0:
            all_pts = np.vstack([floor_points_2d, obstacle_points_2d])
        else:
            all_pts = floor_points_2d
        
        self.x_min, self.z_min = all_pts.min(axis=0)
        self.x_max, self.z_max = all_pts.max(axis=0)
        
        self.width = int(np.ceil((self.x_max - self.x_min) / resolution)) + 2 * padding
        self.height = int(np.ceil((self.z_max - self.z_min) / resolution)) + 2 * padding
        
        # 初始化: 0 = 未知/不可行走
        self.grid = np.zeros((self.height, self.width), dtype=np.uint8)
        
        # 标记可行走 (floor 点)
        self._mark_floor(floor_points_2d)
        
        # 填充 floor 空洞 (连通 floor 区域)
        self._fill_floor_gaps()
        
        # 标记障碍物
        if obstacle_points_2d is not None and len(obstacle_points_2d) > 0:
            self._mark_obstacles(obstacle_points_2d)
        
        # 连通组件
        self.connected_components = None
        self.component_labels = None
        self.component_gateways = []
        
        # Door 信息
        self.doors = []
    
    def _world_to_grid(self, x, z):
        grid_x = int((x - self.x_min) / self.resolution) + self.padding
        grid_z = int((z - self.z_min) / self.resolution) + self.padding
        return grid_x, grid_z
    
    def world_to_grid(self, x, z):
        """世界坐标 → 栅格坐标 (public)"""
        return self._world_to_grid(x, z)
    
    def _grid_to_world(self, grid_x, grid_z):
        x = (grid_x - self.padding) * self.resolution + self.x_min + self.resolution / 2
        z = (grid_z - self.padding) * self.resolution + self.z_min + self.resolution / 2
        return x, z
    
    def _mark_floor(self, floor_points_2d):
        """标记 floor 点"""
        for pt in floor_points_2d:
            gx, gz = self._world_to_grid(pt[0], pt[1])
            if 0 <= gx < self.width and 0 <= gz < self.height:
                self.grid[gz, gx] = 1
    
    def _fill_floor_gaps(self):
        """填充 floor 空洞 (基于形态学操作)"""
        floor_mask = (self.grid == 1).astype(np.uint8)
        
        # 闭运算: 先膨胀后腐蚀，填充小空洞
        kernel = np.ones((5, 5), dtype=np.uint8)
        closed = binary_dilation(floor_mask, structure=kernel, iterations=2)
        closed = binary_erosion(closed, structure=kernel, iterations=2)
        
        dist = distance_transform_edt(~floor_mask.astype(bool))
        fill_mask = closed & (dist < 20)  # 20 像素内填充
        
        # 更新 grid
        self.grid[fill_mask & (self.grid == 0)] = 1
    
    def _mark_obstacles(self, obstacle_points_2d):
        """标记障碍物"""
        # 统计 obstacle
        floor_mask = (self.grid == 1).astype(np.uint8)
        
        for pt in obstacle_points_2d:
            gx, gz = self._world_to_grid(pt[0], pt[1])
            if 0 <= gx < self.width and 0 <= gz < self.height:
                if self.grid[gz, gx] != 1:
                    self.grid[gz, gx] = 100
        
        obstacle_count = np.sum(self.grid == 100)
        floor_protected = np.sum(floor_mask & (self.grid == 1))
        print(f"  Obstacle cells: {obstacle_count:,}, Floor protected: {floor_protected:,}")
    
    def set_doors(self, doors):
        """
        门的位置
        doors: list of dict with 'center', 'bbox', 'name'
        """
        self.doors = doors
        
        # 门的位置作为连接点
        gateways = []
        for door in doors:
            center = door['center']
            gx, gz = self._world_to_grid(center[0], center[2])
            
            # 在 grid 中标记门的位置 (可行走)
            if 0 <= gx < self.width and 0 <= gz < self.height:
                self.grid[gz, gx] = 1
            
            # 膨胀门周围区域为可行走
            for dx in range(-2, 3):
                for dz in range(-2, 3):
                    nx, nz = gx + dx, gz + dz
                    if 0 <= nx < self.width and 0 <= nz < self.height:
                        if self.grid[nz, nx] == 0:  # 只影响未知区域
                            self.grid[nz, nx] = 1
            
            gateways.append({
                'door_name': door.get('name', 'unknown'),
                'center_2d': [center[0], center[2]],
                'center_grid': [gx, gz],
            })
        
        self.component_gateways = gateways
        return gateways
    
    def find_connected_components(self, min_points=100):
        """查找连通组件"""
        walkable = (self.grid == 1).astype(np.uint8)
        labeled, num_features = label(walkable)
        self.component_labels = labeled
        
        components = {}
        for comp_id in range(1, num_features + 1):
            mask = labeled == comp_id
            pts_2d = []
            for gz in range(self.height):
                for gx in range(self.width):
                    if mask[gz, gx]:
                        x, z = self._grid_to_world(gx, gz)
                        pts_2d.append((x, z))
            
            if len(pts_2d) >= min_points:
                pts_arr = np.array(pts_2d)
                centroid = pts_arr.mean(axis=0)
                components[comp_id] = {
                    'points': pts_2d,
                    'centroid': centroid,
                    'num_points': len(pts_2d),
                    'bbox_min': pts_arr.min(axis=0),
                    'bbox_max': pts_arr.max(axis=0),
                }
        
        self.connected_components = components
        return components
    
    def get_grid(self):
        return self.grid.copy()
    
    def is_walkable(self, grid_x, grid_z):
        if not (0 <= grid_x < self.width and 0 <= grid_z < self.height):
            return False
        return self.grid[grid_z, grid_x] == 1
    
    def save_visualization(self, output_path):
        import cv2
        vis = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        
        # 可行走
        walkable_mask = self.grid == 1
        vis[walkable_mask] = [0, 255, 0]
        
        # 障碍
        obstacle_mask = self.grid == 100
        vis[obstacle_mask] = [0, 0, 255]
        
        # 未知
        unknown_mask = self.grid == 0
        vis[unknown_mask] = [50, 50, 50]
        
        # 门位置
        for gw in self.component_gateways:
            gx, gz = gw['center_grid']
            if 0 <= gx < self.width and 0 <= gz < self.height:
                vis[gz, gx] = [255, 255, 0]
                for d in range(-3, 4):
                    if 0 <= gx + d < self.width:
                        vis[gz, gx + d] = [255, 255, 0]
                    if 0 <= gz + d < self.height:
                        vis[gz + d, gx] = [255, 255, 0]
        
        if self.connected_components:
            colors = [
                [0, 180, 180], [180, 0, 180], [180, 180, 0],
                [0, 90, 180], [180, 90, 0], [90, 0, 180],
                [0, 180, 90], [180, 0, 90],
            ]
            for idx, comp_id in enumerate(sorted(self.connected_components.keys())):
                color = colors[idx % len(colors)]
                mask = self.component_labels == comp_id
                vis[mask & walkable_mask] = color
        
        cv2.imwrite(str(output_path), vis)
        print(f"  栅格地图可视化已保存: {output_path}")


def extract_floor_and_obstacles(points, floor_y_threshold=0.6):
    """
    提取 floor 和 obstacle
    使用 Y 阈值 + 垂直点密度分析

    参数:
        points: 全局点云 (N, 3)
        floor_y_threshold: floor 高度阈值 (米)
            - 推荐值: 0.2-0.5m
            - 过大 (如 1.0m) 会导致矮家具被误判为 floor

    返回:
        floor_2d: floor 点 2D 坐标
        obstacle_2d: obstacle 点 2D 坐标
        floor_y_global: 全局 floor_y
    """
    # 按 Z 分带提取 floor
    z_min_all = points[:, 2].min()
    z_max_all = points[:, 2].max()
    
    floor_2d_list = []
    floor_y_map = {}
    floor_y_by_z = {}
    
    band_size = 5.0
    z_bands = np.arange(z_min_all - band_size, z_max_all + band_size, band_size)
    
    for i in range(len(z_bands) - 1):
        z_low = z_bands[i]
        z_high = z_bands[i + 1]
        
        band_mask = (points[:, 2] >= z_low) & (points[:, 2] < z_high)
        band_pts = points[band_mask]
        
        if len(band_pts) < 100:
            continue
        
        # 局部 Y 10th percentile + threshold = floor threshold
        y_10 = np.percentile(band_pts[:, 1], 10)
        floor_y = y_10 + floor_y_threshold
        
        z_mid = (z_low + z_high) / 2
        floor_y_map[z_mid] = floor_y
        
        floor_mask = band_pts[:, 1] < floor_y
        floor_pts = band_pts[floor_mask]
        if len(floor_pts) > 0:
            floor_2d_list.append(floor_pts[:, [0, 2]])
    
    floor_2d = np.vstack(floor_2d_list) if floor_2d_list else np.array([]).reshape(0, 2)
    floor_y_global = min(floor_y_map.values()) if floor_y_map else 0
    
    # 提取 obstacle：单元内点云的 Y 跨度 > 0.5m → obstacle
    print(f"  提取障碍物 (基于垂直 Y 跨度)...")
    
    # 检测障碍物
    obstacle_resolution = 0.2
    x_min, x_max = points[:, 0].min(), points[:, 0].max()
    z_min, z_max = points[:, 2].min(), points[:, 2].max()
    
    grid_x = int(np.ceil((x_max - x_min) / obstacle_resolution)) + 2
    grid_z = int(np.ceil((z_max - z_min) / obstacle_resolution)) + 2
    
    # 计算 Y 分布
    obstacle_cells = set()
    for idx in range(0, len(points), 100):  # 抽样
        batch = points[idx:idx+100]
        for pt in batch:
            gx = int((pt[0] - x_min) / obstacle_resolution)
            gz = int((pt[2] - z_min) / obstacle_resolution)
            if 0 <= gx < grid_x and 0 <= gz < grid_z:
                obstacle_cells.add((gx, gz))
    
    # 计算 Y 跨度
    from collections import defaultdict
    cell_ys = defaultdict(list)
    for pt in points[::50]:  # 抽样
        gx = int((pt[0] - x_min) / obstacle_resolution)
        gz = int((pt[2] - z_min) / obstacle_resolution)
        cell_ys[(gx, gz)].append(pt[1])
    
    obstacle_2d_list = []
    for (gx, gz), ys in cell_ys.items():
        y_span = max(ys) - min(ys)
        if y_span > 0.5:  # Y 跨度 > 0.5m → 障碍物
            # 转换回世界坐标
            x = (gx - 1) * obstacle_resolution + x_min
            z = (gz - 1) * obstacle_resolution + z_min
            obstacle_2d_list.append([x, z])
    
    obstacle_2d = np.array(obstacle_2d_list) if obstacle_2d_list else np.array([]).reshape(0, 2)
    
    print(f"  Floor 提取 (自适应 Z 分带, band={band_size}m):")
    print(f"  总 band 数: {len(floor_y_map)}")
    for z_mid in sorted(floor_y_map.keys()):
        fy = floor_y_map[z_mid]
        print(f"    Z≈{z_mid:.1f}: floor_y={fy:.2f}")
    
    print(f"  总 Floor 点数: {len(floor_2d):,}")
    print(f"  总 Obstacle 点数 (footprint): {len(obstacle_2d):,}")
    print(f"  全局 floor_y (最小值): {floor_y_global:.3f}")
    
    return floor_2d, obstacle_2d, floor_y_global


def create_grid_map_from_pointcloud(global_pcd_path, scene_graph_path=None,
                                    resolution=0.05, floor_y_threshold=0.6):
    """
    全局点云 + scene graph 创建栅格地图

    参数:
        global_pcd_path: 全局点云路径
        scene_graph_path: scene graph JSON 路径
        resolution: 栅格分辨率
        floor_y_threshold: floor 高度阈值 (米)

    返回:
        grid_map: GridMap 对象
        floor_y: 地面高度
    """
    print(f"加载点云: {global_pcd_path}")
    pcd = o3d.io.read_point_cloud(str(global_pcd_path))
    points = np.asarray(pcd.points)
    print(f"  总点数: {len(points):,}")
    
    # 提取 floor 和 obstacle
    print("提取 floor 和 obstacle...")
    floor_2d, obstacle_2d, floor_y = extract_floor_and_obstacles(
        points, floor_y_threshold
    )
    
    # 创建栅格地图
    print(f"创建栅格地图 (分辨率: {resolution}m)...")
    grid_map = GridMap(floor_2d, obstacle_2d, resolution=resolution)
    
    # 加载 scene graph 中的 doors
    if scene_graph_path and Path(scene_graph_path).exists():
        print("加载 scene graph doors...")
        with open(scene_graph_path, 'r') as f:
            scene_graph = json.load(f)
        
        doors = []
        for obj in scene_graph.get('objects', []):
            if obj.get('category') == 'door':
                doors.append(obj)
        
        print(f"  找到 {len(doors)} 个门")
        grid_map.set_doors(doors)
    
    print("膨胀障碍物...")
    obstacle_mask = (grid_map.grid == 100).astype(np.uint8)
    kernel = np.ones((3, 3), dtype=np.uint8)
    from scipy.ndimage import binary_dilation
    dilated = binary_dilation(obstacle_mask, structure=kernel, iterations=3)
    # 不覆盖 floor
    grid_map.grid[dilated & (grid_map.grid != 1)] = 100
    
    print("查找连通组件...")
    components = grid_map.find_connected_components(min_points=100)
    print(f"  找到 {len(components)} 个连通组件")
    
    return grid_map, floor_y


def main():
    import argparse
    parser = argparse.ArgumentParser(description='2D 栅格地图生成器')
    parser.add_argument('--pcd', type=str, default='unified_output/global/global_pointcloud.ply')
    parser.add_argument('--scene-graph', type=str, default='unified_output/scene_graph.json')
    parser.add_argument('--resolution', type=float, default=0.05)
    parser.add_argument('--output', type=str, default='navigation/grid_map_floor.png')
    args = parser.parse_args()
    
    from pathlib import Path
    base_dir = Path(__file__).resolve().parent.parent
    pcd_path = base_dir / args.pcd
    sg_path = base_dir / args.scene_graph
    output_path = base_dir / args.output
    
    print("=" * 60)
    print("2D 栅格地图生成器")
    print("=" * 60)
    
    grid_map, floor_y = create_grid_map_from_pointcloud(
        str(pcd_path), str(sg_path), args.resolution
    )
    
    output_path.parent.mkdir(parents=True, exist_ok=True)
    grid_map.save_visualization(output_path)
    
    print(f"\n栅格尺寸: {grid_map.width} x {grid_map.height}")
    print(f"世界范围: X[{grid_map.x_min:.2f}, {grid_map.x_max:.2f}], "
          f"Z[{grid_map.z_min:.2f}, {grid_map.z_max:.2f}]")
    print(f"可行走: {np.sum(grid_map.grid == 1):,}, 障碍: {np.sum(grid_map.grid == 100):,}")
    
    if grid_map.connected_components:
        for comp_id, comp in sorted(grid_map.connected_components.items()):
            c = comp['centroid']
            print(f"  组件 {comp_id}: 中心=({c[0]:.2f}, {c[1]:.2f}), 点数={comp['num_points']:,}")
    
    if grid_map.component_gateways:
        print(f"\n门 ({len(grid_map.component_gateways)} 个):")
        for gw in grid_map.component_gateways:
            print(f"  {gw['door_name']}: ({gw['center_2d'][0]:.2f}, {gw['center_2d'][1]:.2f})")
    
    import pickle
    data_path = output_path.with_suffix('.pkl')
    with open(data_path, 'wb') as f:
        pickle.dump({
            'grid': grid_map.get_grid(),
            'x_min': grid_map.x_min,
            'z_min': grid_map.z_min,
            'resolution': grid_map.resolution,
            'padding': grid_map.padding,
            'floor_y': floor_y,
            'width': grid_map.width,
            'height': grid_map.height,
            'connected_components': grid_map.connected_components,
            'component_gateways': grid_map.component_gateways,
            'doors': grid_map.doors,
        }, f)
    print(f"\n栅格数据已保存: {data_path}")
    print("=" * 60)


if __name__ == '__main__':
    main()
