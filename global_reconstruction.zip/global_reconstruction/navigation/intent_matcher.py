"""
意图识别

    from navigation.intent_matcher import IntentMatcher
    matcher = IntentMatcher(scene_graph_path="unified_output/scene_graph.json")
    result = matcher.match("帮我找个能坐的地方")
    print(result["object_name"])  # -> "chair_9"
"""

import json
import re
import os
import sys
import time
import requests
import numpy as np
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent.parent))
from config_loader import get_config, service_url, model_path

_cfg = get_config()
VLM_API_URL = service_url('vlm_api_url')
VLM_MODEL = model_path('vlm_model_legacy')
VLM_TIMEOUT = 60


def clean_json_output(content: str) -> str:
    """Extract JSON from VLM response, handling fenced code blocks."""
    content = content.strip()
    # Remove markdown code fences
    pattern = r"```(?:json)?\s*(.*?)\s*```"
    match = re.search(pattern, content, re.DOTALL)
    if match:
        content = match.group(1).strip()
    return content


def query_vlm_text(prompt: str) -> Optional[dict]:
    payload = {
        "model": VLM_MODEL,
        "messages": [
            {
                "role": "system",
                "content": "You are a helpful assistant. Output valid JSON only.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
        "max_tokens": 300,
    }

    try:
        response = requests.post(VLM_API_URL, json=payload, timeout=VLM_TIMEOUT)
        response.raise_for_status()
        data = response.json()
        content = data["choices"][0]["message"]["content"].strip()
        cleaned = clean_json_output(content)
        return json.loads(cleaned)
    except Exception as e:
        print(f"[IntentMatcher] VLM query failed: {e}")
        return None


# ============================================================================
# SceneInventory — 从 scene_graph.json 构建可查询的场景清单
# ============================================================================

class SceneInventory:
    """
    Parses scene_graph.json into a queryable inventory.

    Provides:
      - category_counts: {"chair": 33, "desk": 5, ...}
      - objects_by_category: {"chair": [obj1, obj2, ...], ...}
      - get_objects(category) -> list of object dicts
      - find_object_by_name(name) -> object dict or None
    """

    def __init__(self, scene_graph_path: str):
        self.scene_graph_path = scene_graph_path
        with open(scene_graph_path, "r") as f:
            self.scene_graph = json.load(f)

        # Build category counts
        self.category_counts = {}
        self.objects_by_category = {}

        for obj in self.scene_graph.get("objects", []):
            cat = obj.get("category", "unknown")
            self.category_counts[cat] = self.category_counts.get(cat, 0) + 1
            if cat not in self.objects_by_category:
                self.objects_by_category[cat] = []
            self.objects_by_category[cat].append(obj)

        # Build rooms lookup
        self.rooms = {}
        for room in self.scene_graph.get("rooms", []):
            self.rooms[room["id"]] = room

    def get_category_inventory(self) -> str:
        """返回类别清单: 'chair (33个), desk (5个), ...'"""
        items = sorted(self.category_counts.items(), key=lambda x: -x[1])
        return ", ".join(f"{cat} ({count}个)" for cat, count in items)

    def get_objects(self, category: str) -> list:
        """获取类别下的所有物体实例"""
        return self.objects_by_category.get(category, [])

    def find_object_by_name(self, name: str) -> Optional[dict]:
        """按 name 查找物体"""
        for obj in self.scene_graph.get("objects", []):
            if obj.get("name") == name:
                return obj
        return None

    def get_room_name(self, room_id: int) -> str:
        """获取 room 名称"""
        room = self.rooms.get(room_id)
        if room:
            semantic_name = room.get("name", "").strip()
            if semantic_name:
                return f"room_{room_id}({semantic_name})"
            return f"room_{room_id}"
        return "unknown_room"

    def format_candidate(self, obj: dict) -> str:
        """格式化物体实例"""
        name = obj.get("name", "unknown")
        category = obj.get("category", "unknown")
        center = obj.get("center", [0, 0, 0])
        room_id = obj.get("room_id", -1)
        env_desc = obj.get("environment_description", "")
        nearby_raw = obj.get("nearby_objects", [])

        # nearby_objects
        if isinstance(nearby_raw, list) and len(nearby_raw) > 0:
            if isinstance(nearby_raw[0], dict):
                nearby = [item.get("category", "") for item in nearby_raw[:6]]
            else:
                nearby = nearby_raw[:6]
        elif isinstance(nearby_raw, dict):
            nearby = sorted(nearby_raw.keys(), key=lambda k: -nearby_raw[k])[:6]
        else:
            nearby = []

        lines = [
            f"  {name}:",
            f"    center: [{center[0]:.2f}, {center[1]:.2f}, {center[2]:.2f}]",
            f"    room: {self.get_room_name(room_id)}",
        ]
        if env_desc:
            lines.append(f"    environment: {env_desc}")
        if nearby:
            lines.append(f"    nearby: {', '.join(nearby)}")

        # 高层路径
        path_info = obj.get("_path_info")
        if path_info:
            lines.append(f"    navigation: {path_info.get('room_sequence', '未知')}")
            lines.append(f"    gateways: {path_info.get('gateway_sequence', '无')}")
            dist = path_info.get('path_length_3d', -1)
            if dist > 0:
                lines.append(f"    path_length: {dist:.1f}m")

        return "\n".join(lines)

    def format_candidates_list(self, category: str) -> str:
        """格式化某类别下所有物体实例"""
        objects = self.get_objects(category)
        if not objects:
            return f"(No objects of category '{category}')"
        lines = [f"Category '{category}' has {len(objects)} instance(s):"]
        for obj in objects:
            lines.append(self.format_candidate(obj))
        return "\n".join(lines)

    @property
    def all_object_names(self) -> set:
        """场景中所有物体名称集合"""
        return {obj.get("name", "") for obj in self.scene_graph.get("objects", [])}


# ============================================================================
# IntentMatcher — 意图识别匹配
# ============================================================================

@dataclass
class MatchResult:
    """意图匹配结果"""
    object_name: str               # 物体名
    category: str                  # 类别
    confidence: float              # 置信度 0-1
    reasoning: str                 # VLM 推理说明
    method: str                    # "direct" | "category_vlm" | "instance_vlm"
    input_type: str                # "coordinate" | "exact_name" | "fuzzy_intent"

    def to_dict(self) -> dict:
        return {
            "object_name": self.object_name,
            "category": self.category,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "method": self.method,
            "input_type": self.input_type,
        }

_COORD_RE = re.compile(r"^\s*-?\d+\.?\d*\s*,\s*-?\d+\.?\d*\s*,\s*-?\d+\.?\d*\s*$")


class IntentMatcher:
    """
    两步意图识别:
      1. 判断输入类型 (坐标 / 精确名称 / 模糊意图)
      2. 模糊意图:
         a. 类别选择 — 从场景真实类别中选择最匹配的
         b. 实例消歧 — 如果该类别有多个实例，从中选择最可能的一个
    """

    def __init__(self, scene_graph_path: str):
        self.inventory = SceneInventory(scene_graph_path)
        self.prompts_dir = Path(__file__).parent / "prompts"

    def _load_prompt(self, name: str) -> str:
        """Load a prompt template from the prompts/ directory."""
        path = self.prompts_dir / f"{name}.md"
        with open(path, "r") as f:
            return f.read()

    def match(self, user_input: str, start_position: list = None,
              navigator=None, rooms=None) -> MatchResult:
        """
        意图识别+匹配

        Args:
            user_input: 用户输入，坐标 / 精确名称 / 模糊意图
            start_position: 起点 [x, y, z]，用于计算高层路径
            navigator: FloorNavigator 实例，用于计算高层路径
            rooms: 房间数据列表

        Returns:
            MatchResult with object_name, category, confidence, reasoning
        """
        # Step 0: 判断输入类型
        user_input = user_input.strip()

        # 坐标格式
        if _COORD_RE.match(user_input):
            coords = [float(x.strip()) for x in user_input.split(",")]
            return MatchResult(
                object_name=user_input,
                category="coordinate",
                confidence=1.0,
                reasoning=f"坐标输入: ({coords[0]}, {coords[1]}, {coords[2]})",
                method="direct",
                input_type="coordinate",
            )

        # 精确物体名称
        if user_input in self.inventory.all_object_names:
            obj = self.inventory.find_object_by_name(user_input)
            return MatchResult(
                object_name=user_input,
                category=obj.get("category", "unknown"),
                confidence=1.0,
                reasoning=f"精确匹配场景图中物体: {user_input}",
                method="direct",
                input_type="exact_name",
            )

        # 模糊意图 — 走 VLM 流程
        return self._match_fuzzy_intent(user_input, start_position, navigator, rooms)

    def _match_fuzzy_intent(self, user_intent: str, start_position: list = None,
                            navigator=None, rooms=None) -> MatchResult:
        """
        两步 VLM 匹配:
          1. 类别选择
          2. 实例聚类分组 + Top-K 截断 + 高层路径信息
        """
        t_total = time.time()

        # Step 1: VLM 类别选择
        t0 = time.time()
        category = self._select_category(user_intent)
        t_vlm1 = time.time() - t0
        if category is None:
            return MatchResult(
                object_name="",
                category="",
                confidence=0.0,
                reasoning=f"无法识别意图 '{user_intent}' 对应的场景目标",
                method="category_vlm",
                input_type="fuzzy_intent",
            )

        # 该类别下的物体
        candidates = self.inventory.get_objects(category)
        if not candidates:
            return MatchResult(
                object_name="",
                category=category,
                confidence=0.0,
                reasoning=f"类别 '{category}' 在场景中不存在",
                method="category_vlm",
                input_type="fuzzy_intent",
            )

        # 如果只有 1 个，直接返回
        if len(candidates) == 1:
            obj = candidates[0]
            t_all = time.time() - t_total
            print(f"\n  [IntentMatcher 耗时细分]")
            print(f"    VLM 类别选择: {t_vlm1:.3f}s")
            print(f"    路径增强: 跳过 (单候选)")
            print(f"    VLM 组消歧: 跳过 (单候选)")
            print(f"    总计: {t_all:.3f}s")
            print()
            return MatchResult(
                object_name=obj["name"],
                category=category,
                confidence=0.8,
                reasoning=f"VLM 选择类别 '{category}'，该类别只有 1 个实例: {obj['name']}",
                method="category_vlm",
                input_type="fuzzy_intent",
            )

        # 空间聚类: N 个物体 → K 个组
        groups = self._cluster_candidates(candidates, merge_distance=1.5)
        print(f"  空间聚类: {len(candidates)} 个 {category} → {len(groups)} 个组")

        # 计算每组到起点的 A* 路径距离,排序
        if start_position and navigator and rooms:
            for g in groups:
                center = g['center']
                goal_3d = [center[0], 0.0, center[2]]
                try:
                    path_3d, gw_names = navigator.plan_high_level_path(start_position, goal_3d, rooms)
                    g['path_length'] = sum(
                        np.linalg.norm(np.array(path_3d[i+1]) - np.array(path_3d[i]))
                        for i in range(len(path_3d)-1)
                    ) if len(path_3d) > 1 else 0
                except Exception:
                    g['path_length'] = float('inf')
        else:
            for g in groups:
                g['path_length'] = np.linalg.norm(np.array(g['center'][:2]) - np.array(start_position[:2])) if start_position else 0

        groups.sort(key=lambda g: g['path_length'])

        # 计算高层路径信息
        t_enrich = 0.0
        if start_position and navigator and rooms:
            t0 = time.time()
            self._enrich_candidates_with_paths(start_position, candidates, navigator, rooms)
            t_enrich = time.time() - t0

        # Step 2: VLM 消歧
        t0 = time.time()
        group_result = self._select_group(user_intent, category, groups)
        t_vlm2 = time.time() - t0
        t_all = time.time() - t_total

        print(f"\n  [IntentMatcher 耗时细分]")
        print(f"    VLM 类别选择: {t_vlm1:.3f}s")
        print(f"    路径增强 ({len(candidates)} 候选): {t_enrich:.3f}s")
        print(f"    VLM 组消歧: {t_vlm2:.3f}s")
        print(f"    总计: {t_all:.3f}s")
        print()

        if group_result is None:
            # VLM 失败， fallback 到最近组的代表物体
            fallback = groups[0]['representative']
            return MatchResult(
                object_name=fallback["name"],
                category=category,
                confidence=0.3,
                reasoning=f"VLM 组消歧失败，fallback 到最近的组: {fallback['name']} (距离 {groups[0].get('distance', 0):.1f}m)",
                method="group_vlm",
                input_type="fuzzy_intent",
            )

        selected_group, group_reasoning, vlm_selected_name = group_result

        obj = selected_group.get('_selected_object')
        if obj is None:
            obj = selected_group['representative']

        return MatchResult(
            object_name=obj["name"],
            category=category,
            confidence=0.7,
            reasoning=f"{group_reasoning} (组内 {selected_group['member_count']} 个物体)",
            method="group_vlm",
            input_type="fuzzy_intent",
        )

    def _enrich_candidates_with_paths(self, start_position: list, candidates: list,
                                       navigator, rooms):
        """为每个候选物体计算高层路径信息，作为 VLM 实例消歧的辅助信息"""
        old_stdout = sys.stdout
        sys.stdout = open(os.devnull, 'w')
        try:
            for candidate in candidates:
                center = candidate.get("center", [0, 0, 0])
                goal_3d = [center[0], 0.0, center[2]]
                try:
                    path_3d, gw_names = navigator.plan_high_level_path(
                        start_position, goal_3d, rooms
                    )
                    room_ids = []
                    if hasattr(navigator, 'find_room_for_position'):
                        start_room = navigator.find_room_for_position(start_position, rooms)
                        goal_room = navigator.find_room_for_position(goal_3d, rooms)
                        if start_room is not None:
                            room_ids.append(start_room)
                        if goal_room is not None and goal_room != start_room:
                            room_ids.append(goal_room)

                    candidate['_path_info'] = {
                        'gateway_sequence': ' → '.join(gw_names) if gw_names else '直达',
                        'num_gateways': len(gw_names),
                        'path_length_3d': sum(
                            np.linalg.norm(np.array(path_3d[i+1]) - np.array(path_3d[i]))
                            for i in range(len(path_3d)-1)
                        ) if len(path_3d) > 1 else 0,
                        'room_sequence': f"R{room_ids[0]}→R{room_ids[-1]}" if len(room_ids) >= 1 else "未知",
                    }
                except Exception as e:
                    candidate['_path_info'] = {
                        'gateway_sequence': f'计算失败({str(e)[:25]})',
                        'num_gateways': -1,
                        'path_length_3d': -1,
                        'room_sequence': '未知',
                    }
        finally:
            sys.stdout.close()
            sys.stdout = old_stdout

    def _select_category(self, user_intent: str) -> Optional[str]:
        """Step 1: VLM 类别选择"""
        template = self._load_prompt("category_select")
        prompt = template.format(
            user_intent=user_intent,
            category_inventory=self.inventory.get_category_inventory(),
        )

        result = query_vlm_text(prompt)
        if result and "selected_category" in result:
            cat = result["selected_category"]
            # 验证类别确实存在于场景中
            if cat in self.inventory.category_counts:
                return cat
            else:
                print(f"[IntentMatcher] VLM returned invalid category '{cat}', trying fallback...")
        return None

    def _cluster_candidates(self, candidates: list, merge_distance: float = 1.5) -> list:
        """
        空间聚类: 将同房间、距离相近的同类物体合并为组。
        使用 flood-fill / BFS 方式。

        每个组包含:
        - center: 组中心 (成员坐标均值)
        - representative: 离组中心最近的物体
        - member_count: 成员数
        - member_names: 所有成员名称
        - room_id: 所在房间
        - nearby_objects: 组中心周围的物体摘要
        - environment_description: 组环境描述
        """
        if len(candidates) <= 1:
            return [{"center": c.get("center", [0,0,0]), "representative": c,
                     "member_count": 1, "member_names": [c["name"]],
                     "room_id": c.get("room_id", -1),
                     "nearby_objects": c.get("nearby_objects", []),
                     "environment_description": c.get("environment_description", ""),
                     "distance": 0} for c in candidates]

        # 按房间分组
        by_room = {}
        for c in candidates:
            rid = c.get("room_id", -1)
            by_room.setdefault(rid, []).append(c)

        groups = []
        for rid, room_objs in by_room.items():
            # 对每个房间内的物体做距离聚类
            room_groups = self._cluster_single_room(room_objs, merge_distance)
            groups.extend(room_groups)

        return groups

    def _cluster_single_room(self, objs: list, merge_distance: float) -> list:
        """对单个房间内的物体做距离聚类"""
        n = len(objs)
        if n == 0:
            return []

        # 计算 pairwise 距离
        centers = np.array([o.get("center", [0,0,0])[:2] for o in objs])  # XZ 平面
        dist_matrix = np.sqrt(((centers[:, np.newaxis, :] - centers[np.newaxis, :, :]) ** 2).sum(axis=2))

        # BFS 聚类
        visited = [False] * n
        room_groups = []
        for i in range(n):
            if visited[i]:
                continue
            # 新组: BFS 从 i 开始
            group_indices = []
            queue = [i]
            while queue:
                idx = queue.pop(0)
                if visited[idx]:
                    continue
                visited[idx] = True
                group_indices.append(idx)
                # 找未访问的邻居
                for j in range(n):
                    if not visited[j] and dist_matrix[idx, j] <= merge_distance:
                        queue.append(j)

            # 构建组
            members = [objs[k] for k in group_indices]
            group_center = np.mean(np.array([m.get("center", [0,0,0]) for m in members]), axis=0).tolist()

            # 选代表: 离组中心最近的物体
            member_centers = np.array([m.get("center", [0,0,0]) for m in members])
            dists = np.linalg.norm(member_centers - np.array(group_center), axis=1)
            rep_idx = np.argmin(dists)
            representative = members[rep_idx]

            # 聚合 nearby_objects: 去重集合
            all_nearby = set()
            for m in members:
                nearby_raw = m.get("nearby_objects", [])
                if isinstance(nearby_raw, list):
                    for item in nearby_raw:
                        if isinstance(item, dict):
                            all_nearby.add(item.get("category", ""))
                        elif isinstance(item, str):
                            all_nearby.add(item)
                elif isinstance(nearby_raw, dict):
                    all_nearby.update(nearby_raw.keys())
            nearby_sorted = sorted(all_nearby)  # 按字母排序

            # 聚合 environment 信息
            primary_desc = ""
            spatial_parts = []
            seen_spatial = set()
            for m in members:
                desc = (m.get("environment_description") or "").strip()
                if not primary_desc and desc:
                    primary_desc = desc
                spatial = (m.get("environment_spatial_context") or "").strip()
                if spatial and spatial not in seen_spatial:
                    spatial_parts.append(spatial)
                    seen_spatial.add(spatial)
                if primary_desc and len(spatial_parts) >= 3:
                    break

            if spatial_parts:
                merged_env = primary_desc + " [" + "; ".join(spatial_parts) + "]"
            elif primary_desc:
                merged_env = primary_desc
            else:
                merged_env = ""

            room_groups.append({
                "center": group_center,
                "representative": representative,
                "member_count": len(members),
                "member_names": [m["name"] for m in members],
                "_all_member_objects": members,
                "room_id": representative.get("room_id", -1),
                "nearby_objects": [{"category": k} for k in nearby_sorted],
                "environment_description": merged_env,
                "distance": 0,
            })

        return room_groups

    def _select_group(self, user_intent: str, category: str, groups: list) -> Optional[tuple]:
        """
        Step 2: VLM 组消歧。从分组中选择最可能的组。
        Returns: (selected_group, reasoning) 或 None
        """
        if len(groups) == 1:
            g = groups[0]
            g["_selected_object"] = g["representative"]
            return (g, f"只有 1 个 {category} 组，包含 {g['member_count']} 个物体", g["representative"]["name"])

        # 构建组描述文本 (按 A* 路径距离排序, 带显式排名)
        groups_text = ""
        total = len(groups)
        for rank, g in enumerate(groups, 1):
            room_id = g.get("room_id", -1)
            room_name = self.inventory.get_room_name(room_id)
            dist = g.get("path_length", 0)

            lines = [
                f"  #{rank}/{total} Group (room={room_name}, {g['member_count']} objects, path_distance={dist:.1f}m):",
                f"    center: [{g['center'][0]:.2f}, {g['center'][1]:.2f}, {g['center'][2]:.2f}]",
                f"    members: {', '.join(g['member_names'])}",
            ]
            env = g.get("environment_description", "")
            if env:
                lines.append(f"    environment: {env}")

            # nearby_objects
            nearby = g.get("nearby_objects", [])
            if isinstance(nearby, list) and len(nearby) > 0:
                nearby_str = ", ".join([item["category"] for item in nearby[:8]])
                lines.append(f"    nearby: {nearby_str}")

            # 路径信息 (导航信息)
            rep = g.get("representative", {})
            pi = rep.get("_path_info")
            if pi:
                lines.append(f"    navigation: {pi.get('room_sequence', '未知')}")
                lines.append(f"    gateways: {pi.get('gateway_sequence', '无')}")

            groups_text += "\n".join(lines) + "\n\n"

        template = self._load_prompt("instance_select")
        prompt = template.format(
            user_intent=user_intent,
            category=category,
            candidates_text=groups_text,
        )

        result = query_vlm_text(prompt)
        if result and "selected_object" in result:
            obj_name = result["selected_object"]
            reasoning = result.get("reasoning", "")
            for g in groups:
                if obj_name in g["member_names"]:
                    # 找到 VLM 选中的具体物体对象
                    selected_obj = None
                    for m in g.get("_all_member_objects", []):
                        if m["name"] == obj_name:
                            selected_obj = m
                            break
                    g["_selected_object"] = selected_obj  # 存到组上
                    return (g, reasoning, obj_name)
                if obj_name.lower() in " ".join(g["member_names"]).lower():
                    selected_obj = None
                    for m in g.get("_all_member_objects", []):
                        if m["name"].lower() == obj_name.lower():
                            selected_obj = m
                            break
                    g["_selected_object"] = selected_obj
                    return (g, reasoning, obj_name)
            print(f"[IntentMatcher] VLM returned '{obj_name}' not in any group, trying fallback...")
        return None  # caller handles fallback

    def _select_instance(self, user_intent: str, category: str, candidates: list) -> Optional[tuple]:
        """Step 2: VLM 实例消歧
        Returns: (obj_name, reasoning) 或 None
        """
        template = self._load_prompt("instance_select")
        candidates_text = ""
        for obj in candidates:
            candidates_text += self.inventory.format_candidate(obj) + "\n\n"

        prompt = template.format(
            user_intent=user_intent,
            category=category,
            candidates_text=candidates_text,
        )

        result = query_vlm_text(prompt)
        if result and "selected_object" in result:
            obj_name = result["selected_object"]
            reasoning = result.get("reasoning", "")
            valid_names = {obj["name"] for obj in candidates}
            if obj_name in valid_names:
                return (obj_name, reasoning)
            else:
                print(f"[IntentMatcher] VLM returned invalid object '{obj_name}', not in candidates")
        return None


# ============================================================================
# CLI 快速测试
# ============================================================================

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="IntentMatcher quick test")
    parser.add_argument("input", type=str, help="User input (fuzzy intent, name, or coords)")
    parser.add_argument("--scene-graph", type=str,
                        default="unified_output/scene_graph.json",
                        help="Path to scene_graph.json")
    args = parser.parse_args()

    matcher = IntentMatcher(args.scene_graph)
    result = matcher.match(args.input)

    print("\n" + "=" * 60)
    print(f"Input:  {args.input}")
    print(f"Result: {json.dumps(result.to_dict(), indent=2, ensure_ascii=False)}")
    print("=" * 60)
