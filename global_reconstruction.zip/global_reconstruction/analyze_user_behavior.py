#!/usr/bin/env python3
"""
用户行为分析 - 多帧图像 VLM 分析

  # 指定起始帧和帧数
  python analyze_user_behavior.py --start 0 --num_frames 10

  # 交互模式(手动选择帧范围)
  python analyze_user_behavior.py --interactive

  # 分析整个数据集(自动分段)
  python analyze_user_behavior.py --analyze-all
"""

import argparse
import base64
import json
import os
import sys
from pathlib import Path
from datetime import datetime

import cv2
import requests
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from config_loader import get_config, service_url, model_path
from data_adapter import DatasetAdapter

# ================= 配置 =================
cfg = get_config()
BASE_DIR = Path(__file__).parent
DATA_DIR = Path(cfg.data.default_dir)

VLM_API_URL = service_url('vlm_api_url')
VLM_MODEL_NAME = model_path('vlm_model_legacy')

# 默认分析帧数
DEFAULT_START_FRAME = 0
DEFAULT_NUM_FRAMES = cfg.vlm_analysis.batch_frame_size

# 批量分析时每段的帧数
BATCH_FRAME_SIZE = cfg.vlm_analysis.batch_frame_size

# 输出目录
OUTPUT_DIR = BASE_DIR / "behavior_analysis"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
# ===========================================


def image_to_base64(image_path):
    """将图片转换为 base64"""
    with open(image_path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')


def get_sorted_image_files(images_dir):
    """获取排序后的图像文件列表"""
    image_files = sorted(images_dir.glob("*.png"))
    if not image_files:
        image_files = sorted(images_dir.glob("*.jpg"))
    if not image_files:
        image_files = sorted(images_dir.glob("*.jpeg"))
    return image_files


def build_behavior_prompt(num_frames):
    prompt = f"""You are observing a sequence of {num_frames} consecutive frames captured by a mobile robot indoors. These frames show a person in the scene.

## Your Task
Describe what the person in these frames is doing, as if you were narrating a scene to someone. Write naturally and conversationally. Include:

- What is the person doing? Describe their actions in plain language.
- How do they move or change position across the frames?
- What is around them? Mention relevant objects, furniture, or environmental details that give context.
- If there are multiple phases (e.g., first they walk over, then they pick something up), describe the progression naturally.

## Guidelines

1. **Write like a person describing a video** — not like a robot filling out a form. Use phrases like "The person walks toward..." rather than "Subject exhibits locomotion..."
2. **Be specific about what you see** — "a person in a blue shirt leaning over a desk, reaching for a coffee mug" is better than "interacting with furniture"
3. **Mention changes across frames** — if the person moves, changes posture, or picks something up, describe that transition
4. **If no person is clearly visible**, say so plainly: "No person is clearly visible in these frames — the camera is pointed at a wall..."
5. **Keep it concise** — 2-5 sentences is usually enough

## Output Format
Output your description as plain text. No JSON, no markdown, no bullet points. Just a natural paragraph describing what you see."""

    return prompt


def call_vlm_multi_analysis(image_paths, prompt, max_tokens=500, temperature=0.3, timeout=120):
    """ VLM 多帧分析"""
    valid_paths = []
    for path in image_paths:
        if Path(path).exists():
            valid_paths.append(path)

    if not valid_paths:
        print("  错误: 没有有效的图像路径")
        return None

    print(f"  发送 {len(valid_paths)} 帧图像到 VLM...")

    try:
        content = []
        for image_path in valid_paths:
            image_base64 = image_to_base64(image_path)
            image_suffix = Path(image_path).suffix.lower()
            image_mime = "jpeg" if image_suffix in {".jpg", ".jpeg"} else "png"
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:image/{image_mime};base64,{image_base64}"},
            })
        content.append({"type": "text", "text": prompt})

        payload = {
            "model": VLM_MODEL_NAME,
            "messages": [{
                "role": "user",
                "content": content,
            }],
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": False,
        }

        response = requests.post(VLM_API_URL, json=payload, timeout=timeout)
        response.raise_for_status()

        result = response.json()
        response_text = result['choices'][0]['message']['content'].strip()

        # 清理可能残留的 markdown
        if response_text.startswith('```'):
            response_text = response_text.split('\n', 1)[-1]
        if response_text.endswith('```'):
            response_text = response_text.rsplit('\n', 1)[0]
        response_text = response_text.strip()

        return response_text

    except requests.exceptions.ConnectionError:
        print(f"  错误: 无法连接到 VLM 服务 ({VLM_API_URL})")
        return None
    except requests.exceptions.Timeout:
        print(f"  错误: VLM 请求超时 ({timeout}秒)")
        return None
    except Exception as e:
        print(f"  错误: VLM 调用失败: {e}")
        return None


def format_analysis_result(result, frame_range=None):
    """格式化分析结果为可读文本"""
    if not result:
        return "无分析结果"

    lines = []
    lines.append("=" * 60)
    if frame_range:
        lines.append(f"帧范围: {frame_range}")
    lines.append("=" * 60)
    lines.append("")
    lines.append(result)
    lines.append("")
    lines.append("=" * 60)
    return "\n".join(lines)


def analyze_single_segment(image_files, start_idx, num_frames, save_output=True):
    """分析单个帧段"""
    end_idx = min(start_idx + num_frames, len(image_files))
    segment_files = image_files[start_idx:end_idx]

    if len(segment_files) == 0:
        print("  警告: 没有图像可供分析")
        return None

    print(f"\n分析帧段: {start_idx} - {end_idx-1} (共 {len(segment_files)} 帧)")
    print(f"  第一帧: {segment_files[0].name}")
    print(f"  最后帧: {segment_files[-1].name}")

    prompt = build_behavior_prompt(len(segment_files))
    result = call_vlm_multi_analysis(segment_files, prompt)

    if result:
        # 打印可读格式
        formatted = format_analysis_result(result, f"{start_idx}-{end_idx-1}")
        print(formatted)

        # 保存文本结果
        if save_output:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = OUTPUT_DIR / f"behavior_{timestamp}_frames_{start_idx}-{end_idx-1}.txt"
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(f"帧范围: {start_idx} - {end_idx-1}\n")
                f.write(f"帧数: {len(segment_files)}\n")
                f.write(f"第一帧: {segment_files[0].name}\n")
                f.write(f"最后帧: {segment_files[-1].name}\n")
                f.write(f"分析时间: {datetime.now().isoformat()}\n")
                f.write("=" * 60 + "\n\n")
                f.write(result)
                f.write("\n")
            print(f"\n  ✓ 结果已保存: {output_file}")

    return result


def check_vlm_service():
    """检查 VLM 服务是否可用"""
    try:
        payload = {
            "model": VLM_MODEL_NAME,
            "messages": [{"role": "user", "content": "Hello"}],
            "max_tokens": 10,
            "stream": False,
        }
        response = requests.post(VLM_API_URL, json=payload, timeout=5)
        if response.status_code == 200:
            print(f"✓ VLM 服务可用 ({VLM_API_URL})")
            return True
        else:
            print(f"✗ VLM 服务返回状态码: {response.status_code}")
            return False
    except Exception as e:
        print(f"✗ 无法连接 VLM 服务: {e}")
        print(f"  请确认服务已启动在 {VLM_API_URL}")
        return False


def main():
    parser = argparse.ArgumentParser(description="用户行为分析 - 多帧图像 VLM 分析")
    parser.add_argument("--data-dir", type=str, default=str(DATA_DIR), help="数据集目录")
    parser.add_argument("--start", type=int, default=DEFAULT_START_FRAME, help="起始帧索引 (默认: 0)")
    parser.add_argument("--num-frames", "--num_frames", type=int, default=DEFAULT_NUM_FRAMES, help="分析帧数 (默认: 10)")
    parser.add_argument("--interactive", action="store_true", help="交互模式,手动选择帧范围")
    parser.add_argument("--analyze-all", action="store_true", help="分析整个数据集(自动分段)")
    parser.add_argument("--batch-size", type=int, default=BATCH_FRAME_SIZE, help=f"批量分析时每段的帧数 (默认: {BATCH_FRAME_SIZE})")
    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("用户行为分析 - 多帧图像 VLM 分析")
    print("=" * 60)

    # 检查 VLM 服务
    if not check_vlm_service():
        print("\n请先启动 VLM 服务:")
        print(f"  vllm serve {VLM_MODEL_NAME} --port 8008 ...")
        return

    # 初始化数据适配器
    print(f"\n加载数据集: {args.data_dir}")
    try:
        adapter = DatasetAdapter(args.data_dir)
    except Exception as e:
        print(f"  ✗ 数据集加载失败: {e}")
        return

    # 获取图像文件列表
    image_files = get_sorted_image_files(adapter.images_dir)
    if not image_files:
        print(f"  ✗ 未找到图像文件: {adapter.images_dir}")
        return

    print(f"  ✓ 找到 {len(image_files)} 帧图像")

    # 交互模式
    if args.interactive:
        print(f"\n可用帧数: {len(image_files)}")
        print(f"前5帧: {[f.name for f in image_files[:5]]}")
        try:
            start = int(input(f"请输入起始帧 (0-{len(image_files)-1}, 直接回车=0): ") or 0)
            num = int(input(f"请输入分析帧数 (1-{len(image_files)-start}, 直接回车={DEFAULT_NUM_FRAMES}): ") or DEFAULT_NUM_FRAMES)
        except ValueError:
            print("输入无效,使用默认值")
            start = 0
            num = DEFAULT_NUM_FRAMES

        start = max(0, min(start, len(image_files) - 1))
        num = max(1, min(num, len(image_files) - start))
        analyze_single_segment(image_files, start, num)
        return

    # 分析整个数据集
    if args.analyze_all:
        print(f"\n分析整个数据集: {len(image_files)} 帧, 每段 {args.batch_size} 帧")
        all_results = []
        for start_idx in range(0, len(image_files), args.batch_size):
            result = analyze_single_segment(image_files, start_idx, args.batch_size)
            if result:
                all_results.append({
                    "frame_range": f"{start_idx}-{min(start_idx + args.batch_size, len(image_files)) - 1}",
                    "description": result,
                })

        # 保存汇总
        if all_results:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            summary_file = OUTPUT_DIR / f"behavior_summary_{timestamp}.txt"
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write(f"用户行为分析汇总 - 共 {len(image_files)} 帧, 每段 {args.batch_size} 帧\n")
                f.write(f"生成时间: {datetime.now().isoformat()}\n")
                f.write("=" * 60 + "\n\n")
                for seg in all_results:
                    f.write(f"帧范围: {seg['frame_range']}\n")
                    f.write("-" * 60 + "\n")
                    f.write(seg['description'])
                    f.write("\n\n")
            print(f"\n✓ 汇总结果已保存: {summary_file}")
        return

    # 默认模式: 分析指定帧段
    analyze_single_segment(image_files, args.start, args.num_frames)


if __name__ == "__main__":
    main()
