#!/usr/bin/env python3
"""
SAM 3 多类别分割测试脚本
对指定图片进行 "people", "chair", "table", "vending machines", "floor", "microwave" 分割，
并将分割结果覆盖在原图上保存。
"""

import os
import sys
import numpy as np
import torch
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# 添加 sam3-main 到路径
SAM3_ROOT = "/workspace/wxd/Agent/Spagent/spagent/checkpoints/sam3/sam3-main"
sys.path.insert(0, SAM3_ROOT)

from sam3 import build_sam3_image_model
from sam3.model.sam3_image_processor import Sam3Processor

IMAGE_PATH = "/workspace/wxd/VLN/datasets/icra_ic7f/images/1757051149085.7839.png"
CHECKPOINT_PATH = "/workspace/wxd/Agent/Spagent/spagent/checkpoints/sam3/sam3.1_multiplex.pt"
BPE_PATH = os.path.join(SAM3_ROOT, "sam3/assets/bpe_simple_vocab_16e6.txt.gz")
OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "sam3_segmentation_result.png")

# 要分割的类别
CLASSES = ["people", "chair", "table", "vending machines", "floor", "microwave"]

# 为每个类别分配一个颜色
CLASS_COLORS = {
    "people": "#FF0000",       # 红色
    "chair": "#00FF00",        # 绿色
    "table": "#0000FF",        # 蓝色
    "vending machines": "#FFA500",  # 橙色
    "floor": "#800080",        # 紫色
    "microwave": "#00FFFF",    # 青色
}


def build_composite_mask(all_outputs, image_size):
    """
    将多个类别的分割结果合并成一张复合掩码图。
    每个类别用不同颜色表示。
    """
    w, h = image_size
    composite = np.zeros((h, w, 3), dtype=np.uint8)

    for cls_name, outputs in all_outputs.items():
        color_hex = CLASS_COLORS.get(cls_name, "#FFFFFF")
        rgb = mcolors.hex2color(color_hex)
        rgb_uint8 = (np.array(rgb) * 255).astype(np.uint8)

        masks = outputs["masks"]  # [N, H, W]
        scores = outputs["scores"]

        if masks.numel() == 0:
            print(f"  [{cls_name}] 未检测到任何实例")
            continue

        # 过滤低分结果
        valid = scores > 0.5
        masks = masks[valid]
        scores = scores[valid]

        if masks.numel() == 0:
            print(f"  [{cls_name}] 无超过阈值(0.5)的实例")
            continue

        print(f"  [{cls_name}] 检测到 {masks.shape[0]} 个实例 (最高分: {scores.max().item():.3f})")
        print(f"    masks shape: {masks.shape}")

        # 合并该类别的所有mask（取or）
        # masks shape could be [N, H, W] or [N, 1, H, W]
        if masks.dim() == 4:
            masks = masks.squeeze(1)  # [N, H, W]
        mask_merged = masks.max(dim=0).values.cpu().numpy()  # [H, W]
        print(f"    mask_merged shape: {mask_merged.shape}")
        mask_bool = mask_merged > 0

        # 将颜色叠加到复合图上
        composite[mask_bool] = rgb_uint8

    return composite


def overlay_mask_on_image(image, composite, alpha=0.45):
    """将复合掩码半透明叠加到原图上"""
    img_array = np.array(image).astype(np.float32)
    comp_array = composite.astype(np.float32)
    mask_any = (comp_array.sum(axis=2) > 0).astype(np.float32)[:, :, np.newaxis]
    blended = img_array * (1 - alpha * mask_any) + comp_array * alpha * mask_any
    blended = np.clip(blended, 0, 255).astype(np.uint8)
    return Image.fromarray(blended)


def main():
    print("=" * 60)
    print("SAM 3 多类别分割测试")
    print("=" * 60)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"使用设备: {device}")

    # 构建模型
    print("加载 SAM 3 模型...")
    model = build_sam3_image_model(
        bpe_path=BPE_PATH,
        checkpoint_path=CHECKPOINT_PATH,
        device=device,
        eval_mode=True,
        load_from_HF=False,
    )
    processor = Sam3Processor(model, device=device, confidence_threshold=0.5)
    print("模型加载完成。")

    # 加载图像
    print(f"加载图像: {IMAGE_PATH}")
    image = Image.open(IMAGE_PATH).convert("RGB")
    width, height = image.size
    print(f"图像尺寸: {width} x {height}")

    # 设置图像
    inference_state = processor.set_image(image)

    # 对每个类别进行分割
    all_outputs = {}
    for cls_name in CLASSES:
        print(f"\n分割类别: {cls_name}")
        processor.reset_all_prompts(inference_state)
        output = processor.set_text_prompt(state=inference_state, prompt=cls_name)
        all_outputs[cls_name] = {
            "masks": output["masks"].clone(),
            "boxes": output["boxes"].clone(),
            "scores": output["scores"].clone(),
        }

    # 合并掩码
    print("\n" + "-" * 40)
    print("合并分割结果...")
    composite_mask = build_composite_mask(all_outputs, image.size)

    # 叠加到原图
    result_image = overlay_mask_on_image(image, composite_mask, alpha=0.45)

    # 保存结果
    result_image.save(OUTPUT_PATH)
    print(f"\n结果已保存到: {OUTPUT_PATH}")

    # 也保存一张纯掩码图
    mask_image = Image.fromarray(composite_mask)
    mask_output = OUTPUT_PATH.replace(".png", "_mask_only.png")
    mask_image.save(mask_output)
    print(f"纯掩码已保存到: {mask_output}")

    print("\n完成！")


if __name__ == "__main__":
    main()
