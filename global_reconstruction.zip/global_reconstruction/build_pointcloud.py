#!/usr/bin/env python3
"""
从 RGB-D 序列构建全局 3D 点云

数据格式:
  - color/*.png: 彩色图像
  - depth/*.png: 深度图像 (单位：毫米)
  - poses.txt: 相机位姿 (格式：timestamp tx ty tz qx qy qz qw)
  - d435i.yaml: 相机内参
"""

import os
import numpy as np
import cv2
import yaml
from pathlib import Path
from data_adapter import DatasetAdapter
from config_loader import get_config

# ================= 配置参数 =================
cfg = get_config()

DATA_DIR = Path(os.environ.get("GLOBAL_RECON_DATA_DIR", cfg.data.default_dir))

adapter = DatasetAdapter(DATA_DIR)

COLOR_DIR = adapter.images_dir
DEPTH_DIR = adapter.depth_dir
POSES_FILE = adapter.poses_file

# 输出文件
OUTPUT_DIR = DATA_DIR.parent / "reconstruction"
OUTPUT_DIR.mkdir(exist_ok=True)
OUTPUT_PLY = OUTPUT_DIR / "global_pointcloud.ply"

# 点云处理参数
VOXEL_SIZE = cfg.reconstruction.voxel_size
SKIP_FRAMES = cfg.reconstruction.skip_frames

# 坐标轴变换矩阵
# da3_ezviz (DA3-Streaming) 输出的世界坐标系 Y 轴近似高度方向，不需要 Z→Y 变换
USE_AXIS_TRANSFORM = cfg.coordinate.use_axis_transform and adapter.dataset_type != "da3_ezviz"
T_SWITCH_AXIS = np.array(cfg.coordinate.switch_axis, dtype=np.float64)

# 深度过滤
DEPTH_MIN = cfg.reconstruction.depth_min
DEPTH_MAX = cfg.reconstruction.depth_max

# DBSCAN 去噪参数
USE_DBSCAN = True
DBSCAN_EPS = cfg.reconstruction.dbscan_eps
DBSCAN_MIN_POINTS = cfg.reconstruction.dbscan_min_points

# 半径离群点移除
USE_RADIUS_OUTLIER = cfg.reconstruction.use_radius_outlier
RADIUS_OUTLIER_NB = cfg.reconstruction.radius_outlier_nb_points
RADIUS_OUTLIER_RADIUS = cfg.reconstruction.radius_outlier_radius

# 深度图缩放比例 (深度图单位：毫米 -> 米)
DEPTH_SCALE = cfg.reconstruction.depth_scale

# 置信度过滤
CONFIDENCE_THRESHOLD = getattr(cfg.reconstruction, 'confidence_threshold', 0.0)
# ===========================================
def load_poses(pose_file):
    """
    加载相机位姿,支持两种格式:
    - TUM 格式 (8 values): timestamp tx ty tz qx qy qz qw
    - 4x4 矩阵格式 (16 values): row-major camera-to-world 矩阵

    返回：{timestamp: 4x4 变换矩阵 (相机到世界)}
    """
    poses = {}
    seq_idx = 0
    with open(pose_file, 'r') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue

            parts = line.strip().split()

            if len(parts) == 16:
                # 4x4 矩阵格式 (da3_ezviz: camera_poses.txt)
                T_c2w = np.array([float(x) for x in parts], dtype=np.float64).reshape(4, 4)
                timestamp = f"{seq_idx:05d}"
                seq_idx += 1

                if USE_AXIS_TRANSFORM:
                    T_c2w = T_SWITCH_AXIS @ T_c2w

                poses[timestamp] = T_c2w

            elif len(parts) >= 8:
                # TUM 格式
                timestamp = parts[0]
                tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
                qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

                # 四元数转旋转矩阵
                R = quaternion_to_rotation_matrix(qx, qy, qz, qw)

                # 构建 4x4 变换矩阵 (世界到相机)
                T_w2c = np.eye(4)
                T_w2c[:3, :3] = R
                T_w2c[0, 3] = tx
                T_w2c[1, 3] = ty
                T_w2c[2, 3] = tz

                # 取逆得到相机到世界的变换
                T_c2w = np.linalg.inv(T_w2c)

                # 应用坐标轴变换
                if USE_AXIS_TRANSFORM:
                    T_c2w = T_SWITCH_AXIS @ T_c2w

                poses[timestamp] = T_c2w

    return poses


def quaternion_to_rotation_matrix(qx, qy, qz, qw):
    """四元数转旋转矩阵"""
    # 归一化四元数
    norm = np.sqrt(qx*qx + qy*qy + qz*qz + qw*qw)
    qx, qy, qz, qw = qx/norm, qy/norm, qz/norm, qw/norm

    R = np.eye(3)
    R[0, 0] = 1 - 2*qy*qy - 2*qz*qz
    R[0, 1] = 2*qx*qy - 2*qz*qw
    R[0, 2] = 2*qx*qz + 2*qy*qw
    R[1, 0] = 2*qx*qy + 2*qz*qw
    R[1, 1] = 1 - 2*qx*qx - 2*qz*qz
    R[1, 2] = 2*qy*qz - 2*qx*qw
    R[2, 0] = 2*qx*qz - 2*qy*qw
    R[2, 1] = 2*qy*qz + 2*qx*qw
    R[2, 2] = 1 - 2*qx*qx - 2*qy*qy

    return R


def depth_to_pointcloud(depth, color, K, T_cam2world, confidence=None, conf_threshold=0.0):
    """
    RGB-D转点云

    参数:
        depth: 深度图 (单位：米)
        color: 彩色图 (RGB)
        K: 相机内参矩阵 (3x3)
        T_cam2world: 相机到世界的变换矩阵 (4x4)
        confidence: 置信度图 (可选)
        conf_threshold: 置信度阈值 (0 = 不过滤)

    返回:
        points: 3D 点坐标 (N x 3)
        colors: 颜色 (N x 3)
    """
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    # 获取有效深度像素
    valid_mask = depth > 0
    if confidence is not None and conf_threshold > 0:
        valid_mask &= (confidence >= conf_threshold)
    v, u = np.where(valid_mask)

    if len(u) == 0:
        return np.empty((0, 3)), np.empty((0, 3))

    # 获取深度值
    depths = depth[v, u].flatten()

    # 反投影到相机坐标系
    # 相机坐标系：X 向右，Y 向下，Z 向前
    X_cam = (u - cx) * depths / fx
    Y_cam = (v - cy) * depths / fy
    Z_cam = depths

    # 齐次坐标
    points_cam = np.stack([X_cam, Y_cam, Z_cam, np.ones_like(X_cam)], axis=1)

    # 变换到世界坐标系
    points_world = (T_cam2world @ points_cam.T).T
    points_world = points_world[:, :3] / points_world[:, 3:4]

    # 获取颜色
    colors = color[v, u]

    return points_world, colors


def voxel_downsample(points, colors, voxel_size):
    """
    体素下采样
    """
    if len(points) == 0:
        return points, colors

    # 计算体素索引
    indices = np.floor(points / voxel_size).astype(np.int64)

    # 使用结构化数组进行快速去重
    idx_min = indices.min(axis=0)
    indices_norm = indices - idx_min
    range_max = indices_norm.max(axis=0) + 1

    # 计算线性索引
    linear_idx = (indices_norm[:, 0] * range_max[1] * range_max[2] +
                  indices_norm[:, 1] * range_max[2] +
                  indices_norm[:, 2])

    # 去重，保留每个体素的第一个点
    _, unique_idx = np.unique(linear_idx, return_index=True)

    # 取每个体素的第一个点
    downsampled_points = points[unique_idx]
    downsampled_colors = colors[unique_idx]

    return downsampled_points, downsampled_colors


def dbscan_denoise(points, colors, eps=DBSCAN_EPS, min_points=DBSCAN_MIN_POINTS):
    """
    DBSCAN 去噪 (保留最大连通簇)
    """
    try:
        import open3d as o3d
        
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
        
        # DBSCAN 聚类
        labels = np.array(pcd.cluster_dbscan(eps=eps, min_points=min_points, print_progress=False))
        
        # 统计每个簇的点数
        unique_labels, counts = np.unique(labels[labels >= 0], return_counts=True)
        
        if len(unique_labels) == 0:
            print(f"  DBSCAN 警告：未找到有效簇，保留所有点")
            return points, colors
        
        # 找到最大簇的标签
        largest_cluster_label = unique_labels[np.argmax(counts)]
        
        # 保留最大簇的点
        mask = labels == largest_cluster_label
        filtered_points = points[mask]
        filtered_colors = colors[mask]
        
        print(f"  DBSCAN 去噪：{len(points):,} → {len(filtered_points):,} 点 (保留最大簇)")
        
        return filtered_points, filtered_colors
    
    except ImportError:
        print("  Open3D 不可用，跳过 DBSCAN 去噪")
        return points, colors


def radius_outlier_removal(points, colors, nb_points=RADIUS_OUTLIER_NB, radius=RADIUS_OUTLIER_RADIUS):
    """
    半径离群点移除
    """
    try:
        import open3d as o3d
        
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
        
        # 半径离群点移除
        _, ind = pcd.remove_radius_outlier(nb_points=nb_points, radius=radius)
        
        filtered_points = points[ind]
        filtered_colors = colors[ind]
        
        print(f"  半径离群点移除：{len(points):,} → {len(filtered_points):,} 点")
        
        return filtered_points, filtered_colors
    
    except ImportError:
        print("  Open3D 不可用，跳过半径离群点移除")
        return points, colors


def save_ply_with_color(filename, points, colors):
    """保存带颜色的 PLY 文件 (使用 Open3D)"""
    try:
        import open3d as o3d

        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points.astype(np.float64))
        pcd.colors = o3d.utility.Vector3dVector(colors.astype(np.float64) / 255.0)

        o3d.io.write_point_cloud(str(filename), pcd, write_ascii=False, compressed=True)
        print(f"  使用 Open3D 保存 PLY：{filename}")
    except ImportError:
        print("  Open3D 不可用，使用备用保存方法")
        _save_ply_basic(filename, points, colors)


def _save_ply_basic(filename, points, colors):
    n_points = len(points)

    # 创建结构化数组
    vertex_data = np.zeros(n_points, dtype=[
        ('x', '<f4'), ('y', '<f4'), ('z', '<f4'),
        ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')
    ])

    vertex_data['x'] = points[:, 0].astype(np.float32)
    vertex_data['y'] = points[:, 1].astype(np.float32)
    vertex_data['z'] = points[:, 2].astype(np.float32)
    vertex_data['red'] = colors[:, 0].astype(np.uint8)
    vertex_data['green'] = colors[:, 1].astype(np.uint8)
    vertex_data['blue'] = colors[:, 2].astype(np.uint8)

    with open(filename, 'wb') as f:
        header = f"""ply
format binary_little_endian 1.0
element vertex {n_points}
property float x
property float y
property float z
property uchar red
property uchar green
property uchar blue
end_header
"""
        f.write(header.encode('ascii'))
        f.write(vertex_data.tobytes())


def main():
    print("=" * 60)
    print("RGB-D 全局 3D 点云重建工具")
    print("=" * 60)

    # 打印数据集信息
    adapter.print_info()

    # 检查数据目录
    print(f"\n数据目录：{DATA_DIR}")
    assert DATA_DIR.exists(), f"数据目录不存在：{DATA_DIR}"
    assert COLOR_DIR.exists(), f"彩色图目录不存在：{COLOR_DIR}"
    assert DEPTH_DIR.exists(), f"深度图目录不存在：{DEPTH_DIR}"
    assert POSES_FILE.exists(), f"位姿文件不存在：{POSES_FILE}"

    # 加载相机参数
    print("\n[1] 加载相机内参...")
    K = adapter.K
    print(f"  相机内参矩阵:\n{K}")
    print(f"  工作分辨率：{adapter.process_resolution} (H, W)")
    if CONFIDENCE_THRESHOLD > 0:
        print(f"  置信度过滤：≥ {CONFIDENCE_THRESHOLD}")
    else:
        print(f"  置信度过滤：关闭")

    # 加载位姿
    print("\n[2] 加载相机位姿...")
    poses = load_poses(POSES_FILE)
    print(f"  加载了 {len(poses)} 个位姿")

    # 获取深度图列表
    depth_files = adapter.get_depth_file_list()
    print(f"  找到 {len(depth_files)} 个深度图")

    # 建立深度图文件名到pose时间戳的映射
    file_to_pose = adapter.build_pose_timestamp_map(poses)

    # 增量式体素下采样: 每 INCREMENTAL_DOWNSAMPLE_EVERY 帧合并+下采样,控制内存
    INCREMENTAL_DOWNSAMPLE_EVERY = 50
    total_frames = len([i for i in range(len(depth_files)) if i % SKIP_FRAMES == 0])

    # 已下采样的累积点云
    merged_points = np.empty((0, 3), dtype=np.float32)
    merged_colors = np.empty((0, 3), dtype=np.uint8)

    # 当前批次的原始点云
    batch_points = []
    batch_colors = []

    print("\n[3] 逐帧重建点云 (增量下采样)...")
    processed = 0
    for i, depth_file in enumerate(depth_files):
        # 跳帧采样
        if i % SKIP_FRAMES != 0:
            continue

        frame_id = depth_file.stem

        # 使用映射获取对应的时间戳
        if frame_id not in file_to_pose:
            continue
        pose_timestamp = file_to_pose[frame_id]

        if pose_timestamp not in poses:
            continue

        # 读取深度图 (da3_ezviz: 原生分辨率; standard: 上采样到 RGB)
        depth = adapter.load_depth(depth_file, target_resolution=adapter.rgb_resolution)
        if depth is None:
            continue

        # 深度图单位转换 (毫米 -> 米)
        if depth.dtype == np.uint16:
            depth = depth.astype(np.float32) / DEPTH_SCALE
        elif depth.dtype == np.uint8:
            depth = depth.astype(np.float32)
            print(f"  警告：深度图为 uint8 格式，可能已归一化")

        # 深度过滤
        depth_mask = (depth >= DEPTH_MIN) & (depth <= DEPTH_MAX)
        depth_filtered = depth * depth_mask

        # 读取彩色图 (适配器自动缩放到工作分辨率)
        color_file = adapter.match_color_file(frame_id)
        if color_file is None:
            continue

        color = adapter.load_color(color_file)
        if color is None:
            continue

        # 确保彩色图和深度图尺寸一致 (安全校验)
        if color.shape[:2] != depth_filtered.shape:
            color = cv2.resize(color, (depth_filtered.shape[1], depth_filtered.shape[0]))

        # 应用深度掩码到彩色图
        color_masked = color * depth_mask[:, :, np.newaxis]

        # 加载置信度图 (da3_ezviz: 已在深度分辨率, 无需缩放)
        confidence = None
        if CONFIDENCE_THRESHOLD > 0:
            confidence = adapter.load_confidence(i)

        # 转换为点云
        K_frame = adapter.get_K_for_frame(i)
        points, colors = depth_to_pointcloud(depth_filtered, color_masked, K_frame, poses[pose_timestamp], confidence, CONFIDENCE_THRESHOLD)

        if len(points) > 0:
            batch_points.append(points)
            batch_colors.append(colors)

        processed += 1

        # 增量下采样: 每 N 帧合并当前批次并体素下采样
        if processed % INCREMENTAL_DOWNSAMPLE_EVERY == 0 or processed == total_frames:
            if batch_points:
                batch_pts = np.vstack(batch_points)
                batch_cols = np.vstack(batch_colors)

                # 与已累积的点云合并
                if len(merged_points) > 0:
                    batch_pts = np.vstack([merged_points, batch_pts])
                    batch_cols = np.vstack([merged_colors, batch_cols])

                # 体素下采样
                merged_points, merged_colors = voxel_downsample(batch_pts, batch_cols, VOXEL_SIZE)

                batch_points = []
                batch_colors = []

            print(f"  进度：{processed}/{total_frames} 帧，"
                  f"累积点数：{merged_points.shape[0]:,}")

    # 最终合并
    print("\n[4] 合并全局点云...")
    if len(merged_points) == 0:
        print("  错误：没有生成任何点云!")
        return

    all_points = merged_points
    all_colors = merged_colors
    print(f"  最终点数：{all_points.shape[0]:,}")

    # DBSCAN 去噪 (保留最大连通簇)
    if USE_DBSCAN:
        print(f"\n[5] DBSCAN 去噪 (eps={DBSCAN_EPS}, min_points={DBSCAN_MIN_POINTS})...")
        all_points, all_colors = dbscan_denoise(all_points, all_colors)

    # 半径离群点移除
    if USE_RADIUS_OUTLIER:
        print(f"\n[6] 半径离群点移除 (nb_points={RADIUS_OUTLIER_NB}, radius={RADIUS_OUTLIER_RADIUS}m)...")
        all_points, all_colors = radius_outlier_removal(all_points, all_colors)

    # 保存最终点云
    print(f"\n[7] 保存点云到 {OUTPUT_PLY}...")
    save_ply_with_color(OUTPUT_PLY, all_points, all_colors)
    print(f"  点云已保存!")

    # 统计信息
    print("\n" + "=" * 60)
    print("重建完成!")
    print("=" * 60)
    print(f"\n输出文件:")
    print(f"  - 点云：{OUTPUT_PLY}")
    print(f"\n点云统计:")
    print(f"  - 边界框 X: [{all_points[:, 0].min():.2f}, {all_points[:, 0].max():.2f}] 米")
    print(f"  - 边界框 Y: [{all_points[:, 1].min():.2f}, {all_points[:, 1].max():.2f}] 米")
    print(f"  - 边界框 Z: [{all_points[:, 2].min():.2f}, {all_points[:, 2].max():.2f}] 米")
    print(f"  - 最终点数：{all_points.shape[0]:,}")

    print("\n可视化建议:")
    print("  - 使用 CloudCompare / MeshLab / Open3D 查看 PLY 文件")
    print("  - Python: open3d.visualization.read_point_cloud('global_pointcloud.ply')")


if __name__ == "__main__":
    main()
