#!/usr/bin/env python
"""
可视化分层场景图 (Floors → Rooms → Objects)

用法:
    python visualize_graph.py [graph_path]

    graph_path 默认为: unified_output/hierarchical_graph

输出:
    <graph_path>/visualization_result.png
"""

import os
import sys
import json
import glob
import numpy as np
from collections import defaultdict

import open3d as o3d
import matplotlib.pyplot as plt
import pyvista as pv
from tqdm import tqdm

# 启用离屏渲染
pv.OFF_SCREEN = True


def get_cmap(n, name="hsv"):
    """Returns a function that maps each index in 0, 1, ..., n-1 to a distinct
    RGB color; the keyword argument name must be a standard mpl colormap name."""
    return plt.cm.get_cmap(name, n)


def main():
    # 解析参数
    graph_path = sys.argv[1] if len(sys.argv) > 1 else "unified_output/hierarchical_graph"
    if not os.path.isabs(graph_path):
        graph_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), graph_path)
    graph_path = os.path.abspath(graph_path)

    if not os.path.isdir(graph_path):
        print(f"错误: 目录不存在: {graph_path}")
        sys.exit(1)

    print(f"加载分层场景图: {graph_path}")

    # Initialize the PyVista plotter
    p = pv.Plotter()

    # ========== Load Floors ==========
    floors_ply_paths = sorted(glob.glob(os.path.join(graph_path, "floors", "*.ply")))
    floors_info_paths = sorted(glob.glob(os.path.join(graph_path, "floors", "*.json")))

    floor_pcds = {}
    floor_infos = {}
    hier_topo = defaultdict(dict)
    init_offset = np.array([7.0, 4.0, 2.5])  # 可视化偏移 (X, Z-up, Y-depth)，Y↔Z 已交换

    for counter, (ply_path, info_path) in enumerate(zip(floors_ply_paths, floors_info_paths)):
        with open(info_path, "r") as fp:
            floor_info = json.load(fp)
        floor_infos[floor_info["floor_id"]] = {
            k: v for k, v in floor_info.items()
            if k in ["floor_id", "name", "rooms", "floor_height", "floor_zero_level", "vertices"]
        }
        floor_infos[floor_info["floor_id"]]["viz_offset"] = init_offset * counter
        for r_id in floor_info["rooms"]:
            hier_topo[floor_info["floor_id"]][r_id] = []

        floor_pcd = o3d.io.read_point_cloud(ply_path)
        # Y-up → Z-up 坐标转换：交换 Y↔Z 轴
        floor_xyz = np.asarray(floor_pcd.points)
        floor_xyz[:, [1, 2]] = floor_xyz[:, [2, 1]]
        floor_pcd.points = o3d.utility.Vector3dVector(floor_xyz)
        floor_pcds[floor_info["floor_id"]] = floor_pcd

    print(f"  楼层: {len(floor_pcds)}")

    # ========== Load Rooms ==========
    rooms_ply_paths = sorted(glob.glob(os.path.join(graph_path, "rooms", "*.ply")))
    rooms_info_paths = sorted(glob.glob(os.path.join(graph_path, "rooms", "*.json")))

    room_pcds = {}
    room_infos = {}

    for ply_path, info_path in zip(rooms_ply_paths, rooms_info_paths):
        with open(info_path, "r") as fp:
            room_info = json.load(fp)
        room_infos[room_info["room_id"]] = {
            k: v for k, v in room_info.items()
            if k in ["room_id", "name", "floor_id", "room_height", "room_zero_level", "vertices"]
        }
        for o_id in room_info.get("objects", []):
            hier_topo[room_info["floor_id"]][room_info["room_id"]].append(o_id)

        # 加载房间点云，过滤天花板附近的点
        orig_cloud = o3d.io.read_point_cloud(ply_path)
        orig_cloud_xyz = np.asarray(orig_cloud.points)
        rinfo = room_infos[room_info["room_id"]]
        below_ceiling_filter = (
            orig_cloud_xyz[:, 1] < rinfo["room_zero_level"] + rinfo["room_height"] - 0.4
        )
        room_pcds[room_info["room_id"]] = orig_cloud.select_by_index(
            np.where(below_ceiling_filter)[0]
        )
        # Y-up → Z-up 坐标转换：交换 Y↔Z 轴
        cloud_xyz = np.asarray(room_pcds[room_info["room_id"]].points)
        cloud_xyz[:, [1, 2]] = cloud_xyz[:, [2, 1]]
        room_pcds[room_info["room_id"]].points = o3d.utility.Vector3dVector(cloud_xyz)
        # 应用可视化偏移
        cloud_xyz = np.asarray(room_pcds[room_info["room_id"]].points)
        cloud_xyz += floor_infos[room_info["floor_id"]]["viz_offset"]
        room_pcds[room_info["room_id"]].colors = o3d.utility.Vector3dVector(
            np.clip(np.array(room_pcds[room_info["room_id"]].colors) * 1.2, 0.0, 1.0)
        )

    print(f"  房间: {len(room_pcds)}")

    # ========== Load Objects ==========
    objects_ply_paths = sorted(glob.glob(os.path.join(graph_path, "objects", "*.ply")))
    objects_info_paths = sorted(glob.glob(os.path.join(graph_path, "objects", "*.json")))

    object_pcds = {}
    object_infos = {}
    object_feats = {}

    for ply_path, info_path in zip(objects_ply_paths, objects_info_paths):
        with open(info_path, "r") as fp:
            object_info = json.load(fp)
        object_infos[object_info["object_id"]] = {
            k: v for k, v in object_info.items()
            if k in ["object_id", "name", "room_id", "object_height", "object_zero_level"]
        }
        object_feats[object_info["object_id"]] = np.asarray(object_info.get("embedding", []))

        object_pcds[object_info["object_id"]] = o3d.io.read_point_cloud(ply_path)
        # Y-up → Z-up 坐标转换：交换 Y↔Z 轴
        cloud_xyz = np.asarray(object_pcds[object_info["object_id"]].points)
        cloud_xyz[:, [1, 2]] = cloud_xyz[:, [2, 1]]
        object_pcds[object_info["object_id"]].points = o3d.utility.Vector3dVector(cloud_xyz)
        # 应用可视化偏移
        cloud_xyz = np.asarray(object_pcds[object_info["object_id"]].points)
        cloud_xyz += floor_infos[room_infos[object_info["room_id"]]["floor_id"]]["viz_offset"]

    print(f"  物体: {len(object_pcds)}")

    # ========== 计算楼层质心 ==========
    max_floor_id = list(hier_topo.keys())[-1]
    max_floor_centroid = np.mean(np.asarray(floor_pcds[max_floor_id].points), axis=0)
    floor_centroids = {
        floor_id: np.mean(np.asarray(floor_pcds[floor_id].points), axis=0)
        for floor_id in hier_topo.keys()
    }
    floor_centroids_viz = {
        floor_id: floor_centroids[floor_id] + floor_infos[floor_id]["viz_offset"] + [0.0, 0.0, 4.0]  # Z-up 高度
        for floor_id in hier_topo.keys()
    }

    for floor_id, centroid_viz in floor_centroids_viz.items():
        p.add_mesh(
            pv.Sphere(center=tuple(centroid_viz), radius=0.5),
            color="orange",
        )

    # ========== 计算房间质心 ==========
    room_centroids = {
        room_id: np.mean(np.asarray(room_pcds[room_id].points), axis=0)
        for room_id in room_infos.keys()
    }
    room_centroids_viz = {
        room_id: room_centroids[room_id] + [0.0, 0.0, 3.5]  # Z-up 高度
        for room_id in room_infos.keys()
    }
    for room_id, centroid_viz in room_centroids_viz.items():
        p.add_mesh(
            pv.Sphere(center=tuple(centroid_viz), radius=0.15),
            color="blue",
        )

    # ========== 楼层质心 → 房间质心连线 ==========
    for room_id, room_info_data in room_infos.items():
        floor_id = room_info_data["floor_id"]
        if floor_id in floor_centroids_viz and room_id in room_centroids_viz:
            p.add_mesh(
                pv.Line(
                    tuple(floor_centroids_viz[floor_id]),
                    tuple(room_centroids_viz[room_id]),
                ),
                line_width=3,
                color="green",
                opacity=0.6,
            )

    # ========== 计算物体质心 + 可视化 ==========
    obj_centroids = {
        obj_id: np.mean(np.asarray(object_pcds[obj_id].points), axis=0)
        for obj_id in object_infos.keys()
    }

    for obj_id, obj_info in object_infos.items():
        name_lower = obj_info["name"].lower()
        # 跳过结构性元素
        if any(s in name_lower for s in ["wall", "floor", "ceiling", "paneling", "banner", "overhang"]):
            continue
        if len(object_pcds[obj_id].points) <= 10:
            continue

        print(f"  included object: {obj_info['name']}")
        object_name = obj_info["name"]

        # 跳过不需要显示的结构类别
        if object_name in [
            "divider", "ledge", "pillar", "tape", "stairs", "door", "doors",
            "stair", "window", "glass", "railing", "glass doors", "whiteboard",
            "sliding door", "carpet", "picture",
        ]:
            continue

        # 房间质心到物体的连线
        room_id = obj_info["room_id"]
        p.add_mesh(
            pv.Line(tuple(room_centroids_viz[room_id]), tuple(obj_centroids[obj_id])),
            line_width=1.5,
            opacity=0.5,
        )

        # 物体点云
        object_pcds[obj_id].paint_uniform_color(np.random.rand(3))
        cloud_xyz = np.asarray(object_pcds[obj_id].points)
        center = cloud_xyz.mean(axis=0)
        cloud = pv.PolyData(cloud_xyz)

        # 计算并绘制 3D AABB 边界框
        bbox_min = cloud_xyz.min(axis=0)
        bbox_max = cloud_xyz.max(axis=0)
        cx, cy, cz = bbox_min
        dx, dy, dz = bbox_max - bbox_min
        # 防止退化框（某一维度为 0）
        if min(dx, dy, dz) > 0.001:
            box_mesh = pv.Box(bounds=(cx, cx + dx, cy, cy + dy, cz, cz + dz))
            edges = box_mesh.extract_all_edges()
            if edges.n_points > 0:
                p.add_mesh(
                    edges,
                    color="red",
                    line_width=2,
                    opacity=0.8,
                )

        p.add_mesh(
            cloud,
            scalars=np.asarray(object_pcds[obj_id].colors),
            rgb=True,
            point_size=5,
            show_vertices=True,
        )
        p.add_point_labels(
            [center],
            [object_name],
            font_size=8,
            point_color="blue",
            text_color="black",
        )

    # ========== 渲染 ==========
    output_png = os.path.join(graph_path, "visualization_result.png")
    p.screenshot(output_png)
    print(f"\n已保存: {output_png}")


if __name__ == "__main__":
    main()
