"""
机器人轨迹平面拟合

从相机轨迹点云拟合一个平面，得到法向量和轨迹的平面度评估。

RANSAC 平面拟合

输出:
  - 平面法向量
  - 平面方程 ax + by + cz + d = 0
  - 轨迹点到平面的距离统计
  - 轨迹投影到平面上的2D坐标

  python fit_trajectory_plane.py
  python fit_trajectory_plane.py --method pca
  python fit_trajectory_plane.py --visualize
"""

import argparse
import numpy as np
from pathlib import Path
import open3d as o3d


def load_trajectory_points(ply_path):
    """加载轨迹点云"""
    pcd = o3d.io.read_point_cloud(str(ply_path))
    points = np.asarray(pcd.points)
    print(f"加载轨迹点云: {ply_path}")
    print(f"  点数: {len(points)}")
    return points


def ransac_plane_fit(points, threshold=0.05, max_iterations=1000):
    """
    RANSAC 平面拟合
    
    参数:
        points: (N, 3) 点云
        threshold: 内点距离阈值 (米)
        max_iterations: 最大迭代次数
    
    返回:
        best_normal: 平面法向量 (3,)
        best_d: 平面方程常数项
        inliers: 内点索引
    """
    np.random.seed(42)
    best_normal = None
    best_d = None
    best_inliers = []
    best_count = 0
    
    n_points = len(points)
    
    for _ in range(max_iterations):
        # 随机选择3个点
        idx = np.random.choice(n_points, 3, replace=False)
        p1, p2, p3 = points[idx]
        
        # 计算平面法向量 (两个向量的叉积)
        v1 = p2 - p1
        v2 = p3 - p1
        normal = np.cross(v1, v2)
        norm = np.linalg.norm(normal)
        
        if norm < 1e-6:  # 三点共线，跳过
            continue
        
        normal = normal / norm
        
        # 计算平面方程: ax + by + cz + d = 0
        d = -np.dot(normal, p1)
        
        # 计算所有点到平面的距离
        distances = np.abs(np.dot(points, normal) + d)
        
        # 统计内点
        inliers = np.where(distances < threshold)[0]
        
        if len(inliers) > best_count:
            best_count = len(inliers)
            best_normal = normal
            best_d = d
            best_inliers = inliers
        
        # 如果内点比例很高，提前终止
        if best_count > n_points * 0.95:
            break
    
    # 用所有内点重新拟合平面 (最小二乘)
    if len(best_inliers) > 0:
        inlier_points = points[best_inliers]
        centroid = inlier_points.mean(axis=0)
        centered = inlier_points - centroid
        _, _, vh = np.linalg.svd(centered)
        best_normal = vh[-1]  # 最小奇异值对应的向量
        
        # 确保法向量朝上 (Y 轴正方向)
        if best_normal[1] < 0:
            best_normal = -best_normal
        
        best_d = -np.dot(best_normal, centroid)
    
    inlier_ratio = best_count / n_points * 100
    print(f"\nRANSAC 平面拟合:")
    print(f"  法向量: [{best_normal[0]:.6f}, {best_normal[1]:.6f}, {best_normal[2]:.6f}]")
    print(f"  平面方程: {best_normal[0]:.4f}x + {best_normal[1]:.4f}y + {best_normal[2]:.4f}z + {best_d:.4f} = 0")
    print(f"  内点: {best_count}/{n_points} ({inlier_ratio:.1f}%)")
    
    return best_normal, best_d, best_inliers


def pca_plane_fit(points):
    """
    PCA 最小二乘平面拟合
    
    参数:
        points: (N, 3) 点云
    
    返回:
        normal: 平面法向量 (3,)
        d: 平面方程常数项
    """
    # 计算质心
    centroid = points.mean(axis=0)
    
    # 中心化
    centered = points - centroid
    
    # SVD 分解
    _, _, vh = np.linalg.svd(centered)
    normal = vh[-1]  # 最小奇异值对应的向量
    
    # 确保法向量朝上 (Y 轴正方向)
    if normal[1] < 0:
        normal = -normal
    
    d = -np.dot(normal, centroid)
    
    print(f"\nPCA 平面拟合:")
    print(f"  法向量: [{normal[0]:.6f}, {normal[1]:.6f}, {normal[2]:.6f}]")
    print(f"  平面方程: {normal[0]:.4f}x + {normal[1]:.4f}y + {normal[2]:.4f}z + {d:.4f} = 0")
    print(f"  质心: [{centroid[0]:.4f}, {centroid[1]:.4f}, {centroid[2]:.4f}]")
    
    return normal, d


def o3d_plane_fit(points):
    """
    Open3D 内置平面分割
    
    参数:
        points: (N, 3) 点云
    
    返回:
        normal: 平面法向量 (3,)
        d: 平面方程常数项
        inliers: 内点索引
    """
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    
    # 平面分割
    plane_model, inliers = pcd.segment_plane(
        distance_threshold=0.05,
        ransac_n=3,
        num_iterations=1000
    )
    
    a, b, c, d = plane_model
    normal = np.array([a, b, c])
    
    # 确保法向量朝上
    if normal[1] < 0:
        normal = -normal
        d = -d
    
    inlier_ratio = len(inliers) / len(points) * 100
    print(f"\nOpen3D 平面分割:")
    print(f"  法向量: [{normal[0]:.6f}, {normal[1]:.6f}, {normal[2]:.6f}]")
    print(f"  平面方程: {normal[0]:.4f}x + {normal[1]:.4f}y + {normal[2]:.4f}z + {d:.4f} = 0")
    print(f"  内点: {len(inliers)}/{len(points)} ({inlier_ratio:.1f}%)")
    
    return normal, d, inliers


def analyze_plane_fit(points, normal, d):
    """
    平面拟合质量
    
    参数:
        points: (N, 3) 点云
        normal: 平面法向量 (3,)
        d: 平面方程常数项
    
    返回:
        stats: 距离统计字典
    """
    # 计算所有点到平面的距离
    distances = np.abs(np.dot(points, normal) + d)
    
    stats = {
        'mean': distances.mean(),
        'std': distances.std(),
        'max': distances.max(),
        'min': distances.min(),
        'median': np.median(distances),
        'percentile_95': np.percentile(distances, 95),
    }
    
    print(f"\n轨迹点到平面距离统计:")
    print(f"  平均距离: {stats['mean']:.6f} m ({stats['mean']*1000:.2f} mm)")
    print(f"  标准差:   {stats['std']:.6f} m")
    print(f"  中位数:   {stats['median']:.6f} m")
    print(f"  95%分位:  {stats['percentile_95']:.6f} m")
    print(f"  最大距离: {stats['max']:.6f} m")
    
    # 平面度评估
    if stats['mean'] < 0.02:
        print(f"  ✓ 轨迹非常平坦 (平均偏差 < 2cm)")
    elif stats['mean'] < 0.05:
        print(f"  ✓ 轨迹较为平坦 (平均偏差 < 5cm)")
    elif stats['mean'] < 0.1:
        print(f"  ⚠ 轨迹有一定起伏 (平均偏差 < 10cm)")
    else:
        print(f"  ✗ 轨迹起伏较大 (平均偏差 > 10cm)")
    
    return stats


def project_to_plane(points, normal, d):
    """
    将3D点投影到平面上，得到2D坐标
    
    参数:
        points: (N, 3) 点云
        normal: 平面法向量 (3,)
        d: 平面方程常数项
    
    返回:
        points_2d: (N, 2) 投影后的2D坐标
        projection_matrix: 3x3 变换矩阵
    """
    # 构建投影坐标系
    # Z 轴 = 法向量
    z_axis = normal / np.linalg.norm(normal)
    
    # X 轴 = 世界 X 轴在平面上的投影
    x_axis = np.array([1, 0, 0])
    x_axis = x_axis - np.dot(x_axis, z_axis) * z_axis
    x_axis = x_axis / np.linalg.norm(x_axis)
    
    # Y 轴 = Z × X
    y_axis = np.cross(z_axis, x_axis)
    y_axis = y_axis / np.linalg.norm(y_axis)
    
    # 构建旋转矩阵
    R = np.array([x_axis, y_axis, z_axis])
    
    # 旋转点
    rotated = points @ R.T
    
    # 2D 坐标 (忽略 Z 方向)
    points_2d = rotated[:, :2]

    return points_2d, R


def resample_trajectory(points_3d, step_size=0.01):
    """
    沿轨迹按固定步长重采样 (真实 3D 欧氏距离)

    参数:
        points_3d: (N, 3) 原始轨迹点
        step_size: 采样步长 (米), 默认 0.01m (1cm)

    返回:
        resampled: (M, 3) 重采样后的轨迹点
        total_length: 轨迹总长度 (m)
    """
    # 计算累计距离
    distances = np.zeros(len(points_3d))
    for i in range(1, len(points_3d)):
        distances[i] = distances[i - 1] + np.linalg.norm(points_3d[i] - points_3d[i - 1])

    total_length = distances[-1]

    # 生成等距采样距离
    num_samples = int(np.floor(total_length / step_size)) + 1
    sample_distances = np.linspace(0, total_length, num_samples)

    # 线性插值得到采样点
    resampled = np.zeros((num_samples, 3))
    for i, sd in enumerate(sample_distances):
        idx = np.searchsorted(distances, sd, side='right') - 1
        idx = min(max(idx, 0), len(points_3d) - 2)

        seg_start_dist = distances[idx]
        seg_end_dist = distances[idx + 1]
        seg_length = seg_end_dist - seg_start_dist

        if seg_length > 1e-8:
            t = (sd - seg_start_dist) / seg_length
        else:
            t = 0.0

        resampled[i] = points_3d[idx] + t * (points_3d[idx + 1] - points_3d[idx])

    return resampled, total_length


def visualize(points, normal, d, inliers=None):
    """可视化平面拟合结果"""
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    
    colors = np.zeros((len(points), 3))
    if inliers is not None:
        colors[:] = [1, 0.2, 0.2]
        colors[inliers] = [0.2, 0.5, 1.0]
    else:
        distances = np.abs(np.dot(points, normal) + d)
        max_dist = distances.max()
        for i, dist in enumerate(distances):
            t = dist / max_dist if max_dist > 0 else 0
            colors[i] = [t, 0, 1 - t]
    
    pcd.colors = o3d.utility.Vector3dVector(colors)
    
    plane_center = -normal * d  # 平面上一点
    plane_size = 10.0
    
    # 创建两个正交向量在平面上
    v1 = np.array([1, 0, 0])
    v1 = v1 - np.dot(v1, normal) * normal
    v1 = v1 / np.linalg.norm(v1)
    v2 = np.cross(normal, v1)
    
    # 平面顶点
    plane_pts = []
    for i in [-1, 1]:
        for j in [-1, 1]:
            pt = plane_center + i * plane_size * v1 + j * plane_size * v2
            plane_pts.append(pt)
    
    # 三角网格
    mesh = o3d.geometry.TriangleMesh()
    mesh.vertices = o3d.utility.Vector3dVector(plane_pts)
    mesh.triangles = o3d.utility.Vector3iVector([[0, 1, 2], [1, 3, 2]])
    mesh.paint_uniform_color([0.8, 0.8, 0.8])
    mesh.compute_vertex_normals()
    
    # 法向量箭头
    arrow_length = 1.0
    arrow_origin = plane_center
    arrow_end = arrow_origin + arrow_length * normal
    
    arrow_sphere = o3d.geometry.TriangleMesh.create_sphere(radius=0.1)
    arrow_sphere.translate(arrow_end)
    arrow_sphere.paint_uniform_color([1, 0, 0])
    
    o3d.visualization.draw_geometries(
        [pcd, mesh, arrow_sphere],
        window_name="轨迹平面拟合",
        width=800,
        height=600,
    )


def main():
    parser = argparse.ArgumentParser(description='机器人轨迹平面拟合')
    parser.add_argument('--trajectory', type=str, default=None,
                       help='轨迹点云 PLY 路径')
    parser.add_argument('--method', type=str, default='ransac',
                       choices=['ransac', 'pca', 'o3d'],
                       help='拟合方法')
    parser.add_argument('--visualize', action='store_true',
                       help='可视化结果')
    parser.add_argument('--save-projection', action='store_true',
                       help='保存投影到2D平面的坐标')
    
    args = parser.parse_args()
    
    base_dir = Path(__file__).resolve().parent
    
    # 轨迹点云
    if args.trajectory is None:
        candidate_paths = [
            base_dir / 'unified_output' / 'camera_trajectory.ply',
            base_dir / 'unified_output' / 'global_pointcloud_with_trajectory.ply',
        ]
        
        traj_file = None
        for p in candidate_paths:
            if p.exists():
                traj_file = p
                break
        
        if traj_file is None:
            print("错误: 未找到轨迹点云，请先运行 export_camera_trajectory.py")
            return
    else:
        traj_file = Path(args.trajectory)
    
    # 加载点云
    points = load_trajectory_points(traj_file)
    
    # 平面拟合
    inliers = None
    if args.method == 'ransac':
        normal, d, inliers = ransac_plane_fit(points, threshold=0.05)
    elif args.method == 'pca':
        normal, d = pca_plane_fit(points)
        inliers = None
    elif args.method == 'o3d':
        normal, d, inliers = o3d_plane_fit(points)
    
    # 分析拟合质量
    stats = analyze_plane_fit(points, normal, d)
    
    # 投影
    points_2d, R = project_to_plane(points, normal, d)
    print(f"\n投影到2D平面:")
    print(f"  范围: [{points_2d[:, 0].min():.2f}, {points_2d[:, 0].max():.2f}] × "
          f"[{points_2d[:, 1].min():.2f}, {points_2d[:, 1].max():.2f}]")
    print(f"  轨迹总长度: {np.sum(np.linalg.norm(np.diff(points_2d, axis=0), axis=1)):.2f} m")
    
    plane_pcd_path = base_dir / 'unified_output' / 'fitted_plane.ply'
    
    # 生成平面上的密集点 (网格)
    # 找到轨迹在平面上的范围
    centroid = points.mean(axis=0)
    
    # 平面上的两个正交基向量
    v1 = np.array([1, 0, 0])
    v1 = v1 - np.dot(v1, normal) * normal
    v1 = v1 / np.linalg.norm(v1)
    v2 = np.cross(normal, v1)
    
    # 计算投影坐标范围
    proj_v1 = (points - centroid) @ v1
    proj_v2 = (points - centroid) @ v2
    
    margin = 2.0  # 外扩 2 米
    v1_min, v1_max = proj_v1.min() - margin, proj_v1.max() + margin
    v2_min, v2_max = proj_v2.min() - margin, proj_v2.max() + margin
    
    # 生成网格点
    grid_step = 0.2
    v1_range = np.arange(v1_min, v1_max, grid_step)
    v2_range = np.arange(v2_min, v2_max, grid_step)
    
    plane_points = []
    for i in v1_range:
        for j in v2_range:
            pt = centroid + i * v1 + j * v2
            # 投影到平面上
            dist = np.dot(pt - centroid, normal)
            pt = pt - dist * normal
            plane_points.append(pt)
    
    plane_points = np.array(plane_points)
    
    plane_pcd = o3d.geometry.PointCloud()
    plane_pcd.points = o3d.utility.Vector3dVector(plane_points)
    plane_pcd.paint_uniform_color([0.8, 0.8, 0.8])  # 浅灰色
    
    o3d.io.write_point_cloud(str(plane_pcd_path), plane_pcd)
    print(f"\n拟合平面点云已保存: {plane_pcd_path}")
    print(f"  平面点数: {len(plane_points):,}")

    # 轨迹点投影到平面
    # P_proj = P - (n·P + d) * n
    dist_to_plane = np.dot(points, normal) + d
    points_projected = points - dist_to_plane[:, np.newaxis] * normal

    # 重采样 (按 1cm 步长)
    print(f"\n轨迹重采样 (步长 0.01m):")
    resampled_points, total_length = resample_trajectory(points_projected, step_size=0.01)
    print(f"  原始轨迹点数: {len(points)}")
    print(f"  重采样后点数: {len(resampled_points)}")
    print(f"  轨迹总长度: {total_length:.2f} m")

    resampled_pcd_path = base_dir / 'unified_output' / 'trajectory_resampled.ply'
    resampled_pcd = o3d.geometry.PointCloud()
    resampled_pcd.points = o3d.utility.Vector3dVector(resampled_points)

    colors = np.zeros((len(resampled_points), 3))
    for i in range(len(resampled_points)):
        t = i / max(len(resampled_points) - 1, 1)
        colors[i] = [0, t, 1 - t]
    resampled_pcd.colors = o3d.utility.Vector3dVector(colors)

    o3d.io.write_point_cloud(str(resampled_pcd_path), resampled_pcd)
    print(f"  重采样轨迹已保存: {resampled_pcd_path}")
    
    if args.save_projection:
        output_file = base_dir / 'unified_output' / 'trajectory_2d_projection.npy'
        np.save(output_file, {
            'points_2d': points_2d,
            'points_3d': points,
            'normal': normal,
            'd': d,
            'R': R,
            'stats': stats,
        })
        print(f"投影数据已保存: {output_file}")
    
    if args.visualize:
        visualize(points, normal, d, inliers)


if __name__ == '__main__':
    main()
