#!/usr/bin/env python3
"""
统一的 3D 场景重建 + 物体分割 + 拓扑图生成

在遍历 RGB-D 帧时**同时**完成:
1. 全局场景 3D 点云累积
2. 物体语义分割点云 (floor, wall, door)
3. 分层场景拓扑图 (基于几何关系)

避免重复读取数据，一趟处理完成所有任务。

服务依赖:
- GroundingDINO: http://localhost:20021/detect
- SAM2: http://localhost:20020/infer
"""

import numpy as np
import open3d as o3d
import cv2
import yaml
import json
from pathlib import Path
from datetime import datetime
from tqdm import tqdm
import requests
import base64
from collections import defaultdict
import matplotlib.pyplot as plt

# 导入 HoloAgent 风格的房间分割
from segment_rooms_holoagent import segment_floors_holoagent, segment_rooms_holoagent, save_rooms, HORIZONTAL_AXES, VERTICAL_AXIS

# 导入俯视图可视化
from visualize_room_segmentation import generate_top_view_visualization

# ================= 配置 =================
BASE_DIR = Path(__file__).parent
DATA_DIR = Path("/workspace/wxd/VLN/datasets/icra_ic7f")

# 输入数据
IMAGES_DIR = DATA_DIR / "images"
DEPTH_DIR = DATA_DIR / "depth"
POSES_FILE = DATA_DIR / "poses.txt"
INTRINSIC_FILE = DATA_DIR / "d435i.yaml"

# 服务地址
VLM_API_URL = "http://localhost:8008/v1/chat/completions"
GROUNDING_DINO_URL = "http://localhost:20021/detect"
SAM2_URL = "http://localhost:20020/infer"

# 输出目录
OUTPUT_DIR = BASE_DIR / "unified_output"
SCENE_GRAPH_FILE = OUTPUT_DIR / "scene_graph.json"

# 点云重建参数 (与 HoloAgent 一致)
VOXEL_SIZE = 0.05         # 体素下采样大小 (米) - 与 HoloAgent 一致
SKIP_FRAMES = 18          # 跳帧采样 - 与 HoloAgent 一致
DEPTH_MIN = 0.3           # 最小深度 (米) - 去除近处噪声
DEPTH_MAX = 6.0           # 最大深度 (米) - 与 HoloAgent depth_cut 一致
DEPTH_SCALE = 1000.0      # 深度图缩放 (毫米→米)

# 物体分割参数 - 只检测 floor, wall, door
OBJECT_CATEGORIES = ['floor', 'wall', 'door']

MAX_FRAMES = 700              # 最大处理帧数 - 增加以覆盖更多场景 (总帧数/SKIP_FRAMES)
OBJECT_MIN_POINTS = 100       # 物体最少点数 - 与 HoloAgent 一致
OBJECT_MERGE_DISTANCE_THRESHOLD = 0.3  # 物体合并距离阈值 (米) - 小于此距离认为是同一物体

# 楼层分割参数 (与 HoloAgent 一致)
FLOOR_HEIGHT_THRESHOLD = 0.3   # 楼层高度差阈值
FLOOR_HIST_BIN_SIZE = 0.01     # 高度直方图 bin 大小 (米)
FLOOR_GAUSSIAN_SIGMA = 2       # 直方图高斯平滑 sigma
FLOOR_PEAK_DISTANCE = 0.2      # 峰值检测最小距离 (米)
FLOOR_PEAK_HEIGHT_PERCENTILE = 90  # 峰值高度百分位数阈值
FLOOR_DBSCAN_EPS = 1.0         # 峰值聚类 DBSCAN eps

# 房间分割参数 (与 HoloAgent 一致)
GRID_RESOLUTION = 0.05         # 2D 栅格地图分辨率 (米)
ROOM_HEIGHT_MIN_OFFSET = 1.0   # 房间高度下限偏移 (floor_zero_level + 1.0) HoloAgent 使用 1.0m
ROOM_HEIGHT_MAX_OFFSET = 0.3   # 房间高度上限偏移 (floor_height - 0.3)
HIST_THRESHOLD_RATIO = 0.25    # 直方图阈值比例
GAUSSIAN_BLUR_KERNEL = 5       # 高斯模糊核大小
GAUSSIAN_BLUR_SIGMA = 1        # 高斯模糊 sigma

# 优化：只在关键帧做检测 (每 N 帧检测一次)
OBJECT_DETECTION_INTERVAL = 3  # 每 3 帧检测一次物体

# 物体类别合并配置 - floor 和 wall 分别合并为单个物体
MERGE_CATEGORIES = ['wall', 'floor']  # 这些类别会合并为单个物体

# 点云去噪参数 (与 HoloAgent 一致)
DBSCAN_EPS = 0.01            # DBSCAN 去噪 eps
DBSCAN_MIN_POINTS = 100      # DBSCAN 去噪最小点数

# 坐标轴变换矩阵 (切换相机坐标系到 Open3D 坐标系，与 build_pointcloud.py 一致)
USE_AXIS_TRANSFORM = True
T_SWITCH_AXIS = np.array([
    [1, 0, 0, 0],
    [0, 0, 1, 0],
    [0, -1, 0, 0],
    [0, 0, 0, 1]
], dtype=np.float64)
# ===========================================


def load_intrinsics(yaml_file):
    """加载相机内参"""
    with open(yaml_file, 'r') as f:
        params = yaml.safe_load(f)
    
    fx = params.get('fx', params.get('Camera1.fx', 385.38))
    fy = params.get('fy', params.get('Camera1.fy', 384.85))
    cx = params.get('cx', params.get('Camera1.cx', 320.58))
    cy = params.get('cy', params.get('Camera1.cy', 240.08))
    
    K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])
    return K


def load_poses(pose_file):
    """加载位姿 (TUM 格式)"""
    poses = {}
    with open(pose_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) < 8:
                continue

            timestamp = parts[0]
            tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
            qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

            q = np.array([qx, qy, qz, qw])
            q = q / np.linalg.norm(q)
            x, y, z, w = q

            R = np.array([
                [1 - 2*y*y - 2*z*z, 2*x*y - 2*z*w, 2*x*z + 2*y*w],
                [2*x*y + 2*z*w, 1 - 2*x*x - 2*z*z, 2*y*z - 2*x*w],
                [2*x*z - 2*y*w, 2*y*z + 2*x*w, 1 - 2*x*x - 2*y*y]
            ])

            T_w2c = np.eye(4)
            T_w2c[:3, :3] = R
            T_w2c[:3, 3] = [tx, ty, tz]

            T_c2w = np.linalg.inv(T_w2c)

            # 应用坐标轴变换 (与 build_pointcloud.py 一致)
            if USE_AXIS_TRANSFORM:
                T_c2w = T_SWITCH_AXIS @ T_c2w

            poses[timestamp] = T_c2w

    return poses


def fit_trajectory_plane_from_poses(poses):
    """
    从相机位姿拟合机器人行走轨迹平面
    
    使用 RANSAC 鲁棒拟合，得到行走平面方程。
    用于：
    1. 导航路径点的 Y 高度计算
    2. 轨迹点云的 3D→2D 投影
    
    参数:
        poses: dict of {timestamp: T_c2w (4x4)} 相机位姿
    
    返回:
        result: dict 包含以下字段:
            - normal: 平面法向量 (3,)
            - d: 平面方程常数项 (ax + by + cz + d = 0)
            - centroid: 轨迹质心 (3,)
            - inlier_ratio: 内点比例
            - mean_distance: 平均距离偏差 (m)
    """
    # 提取所有相机位置
    positions = np.array([T[:3, 3] for T in poses.values()])
    n = len(positions)
    
    if n < 3:
        print("  警告: 位姿数量不足，使用默认水平面")
        return {
            'normal': np.array([0.0, 1.0, 0.0]),
            'd': 0.0,
            'centroid': positions.mean(axis=0) if n > 0 else np.zeros(3),
            'inlier_ratio': 0.0,
            'mean_distance': 0.0,
        }
    
    # RANSAC 平面拟合
    np.random.seed(42)
    threshold = 0.05  # 5cm 内点阈值
    max_iterations = 1000
    
    best_normal = None
    best_d = None
    best_count = 0
    best_inliers = []
    
    for _ in range(max_iterations):
        # 随机选择3个点
        idx = np.random.choice(n, 3, replace=False)
        p1, p2, p3 = positions[idx]
        
        # 计算法向量
        v1 = p2 - p1
        v2 = p3 - p1
        normal = np.cross(v1, v2)
        norm = np.linalg.norm(normal)
        
        if norm < 1e-6:
            continue
        
        normal = normal / norm
        d = -np.dot(normal, p1)
        
        # 统计内点
        distances = np.abs(np.dot(positions, normal) + d)
        inliers = np.where(distances < threshold)[0]
        
        if len(inliers) > best_count:
            best_count = len(inliers)
            best_normal = normal
            best_d = d
            best_inliers = inliers
        
        # 提前终止
        if best_count > n * 0.95:
            break
    
    # 用内点精化拟合 (SVD)
    if len(best_inliers) > 2:
        inlier_points = positions[best_inliers]
        centroid = inlier_points.mean(axis=0)
        centered = inlier_points - centroid
        _, _, vh = np.linalg.svd(centered)
        best_normal = vh[-1]
        
        # 确保法向量朝上 (Y 轴正方向)
        if best_normal[1] < 0:
            best_normal = -best_normal
        
        best_d = -np.dot(best_normal, centroid)
    
    centroid = positions.mean(axis=0)
    distances = np.abs(np.dot(positions, best_normal) + best_d)
    inlier_ratio = best_count / n * 100
    mean_dist = distances.mean()
    
    print(f"  轨迹点云: {n} 帧")
    print(f"  法向量: [{best_normal[0]:.6f}, {best_normal[1]:.6f}, {best_normal[2]:.6f}]")
    print(f"  平面方程: {best_normal[0]:.4f}x + {best_normal[1]:.4f}y + {best_normal[2]:.4f}z + {best_d:.4f} = 0")
    print(f"  内点: {best_count}/{n} ({inlier_ratio:.1f}%)")
    print(f"  平均偏差: {mean_dist*1000:.1f} mm")
    
    # 保存平面信息到文件
    plane_info_file = OUTPUT_DIR / "trajectory_plane.json"
    plane_info = {
        'normal': best_normal.tolist(),
        'd': float(best_d),
        'centroid': centroid.tolist(),
        'inlier_count': int(best_count),
        'total_points': int(n),
        'inlier_ratio': float(inlier_ratio),
        'mean_distance': float(mean_dist),
    }
    with open(plane_info_file, 'w') as f:
        json.dump(plane_info, f, indent=2)
    print(f"  ✓ 已保存: {plane_info_file}")
    
    return {
        'normal': best_normal,
        'd': best_d,
        'centroid': centroid,
        'inlier_ratio': inlier_ratio,
        'mean_distance': mean_dist,
    }


def depth_to_pointcloud(depth, color, K, T_c2w):
    """深度图 + 彩色图 → 3D 点云"""
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]
    
    valid_mask = (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
    v, u = np.where(valid_mask)
    
    if len(u) == 0:
        return np.empty((0, 3)), np.empty((0, 3))
    
    depths = depth[v, u].flatten()
    
    X_cam = (u - cx) * depths / fx
    Y_cam = (v - cy) * depths / fy
    Z_cam = depths
    
    points_cam = np.stack([X_cam, Y_cam, Z_cam, np.ones_like(X_cam)], axis=1)
    points_world = (T_c2w @ points_cam.T).T[:, :3]
    
    colors = color[v, u]
    return points_world, colors


def voxel_downsample(points, colors, voxel_size):
    """体素下采样"""
    if len(points) == 0:
        return points, colors
    
    indices = np.floor(points / voxel_size).astype(np.int64)
    _, unique_idx = np.unique(indices, axis=0, return_index=True)
    
    return points[unique_idx], colors[unique_idx]


# ================= VLM 物体检测 =================

def vlm_detect_objects(image_path):
    """
    使用 VLM 检测图像中的物体类别

    返回格式:
    {
        "objects": [
            {"category": "chair", "confidence": 0.9},
            {"category": "desk", "confidence": 0.85},
            ...
        ]
    }
    """
    prompt = """You are an indoor object detection assistant. Your task is to detect indoor objects and output STRICT JSON format.

## Output Format (MANDATORY)
You MUST output ONLY a valid JSON object with this exact structure:
{"objects":[{"category":"name","confidence":0.0-1.0},...]}

NO markdown, NO explanations, NO additional text.

## Examples

Example 1 (office scene):
{"objects":[{"category":"chair","confidence":0.9},{"category":"desk","confidence":0.85},{"category":"monitor","confidence":0.8},{"category":"wall","confidence":0.95},{"category":"floor","confidence":0.9}]}

Example 2 (living room):
{"objects":[{"category":"sofa","confidence":0.9},{"category":"table","confidence":0.75},{"category":"lamp","confidence":0.7},{"category":"window","confidence":0.85},{"category":"floor","confidence":0.95}]}

Example 3 (empty hallway):
{"objects":[{"category":"wall","confidence":0.95},{"category":"floor","confidence":0.95},{"category":"door","confidence":0.8}]}

## Detection Rules (STRICT)

1. Object categories: Detect ANY indoor objects you can identify. Common examples include:
   - Furniture: chair, desk, table, sofa, bed, cabinet, shelf, bookshelf, counter, stool, bench
   - Electronics: computer, monitor, tv, keyboard, mouse, lamp, clock, fan
   - Fixtures: door, window, stair, railing, pillar, sink, toilet, bathtub, mirror, curtain
   - Appliances: refrigerator, oven, microwave, dishwasher, washing_machine, trash_can
   - Decor: plant, picture, vase, rug, cushion
   - Architectural: wall, floor

2. Format: lowercase, use underscore for multi-word (e.g., "trash_can", "washing_machine")

3. Visibility requirement: ONLY include objects that are clearly visible (≥50% of the object can be seen)

4. Confidence scoring (MANDATORY):
   - 0.9-1.0: Object is fully visible and clear
   - 0.7-0.89: Object is mostly visible
   - 0.5-0.69: Object is partially visible but identifiable
   - Below 0.5: Do NOT include the object

5. Limit: Maximum 15 objects. Prioritize larger and more prominent objects.

6. DO NOT detect: ceiling, sky, outdoor objects, people, pets

## Task
Analyze the provided image and detect all visible indoor objects according to the rules above.

Output ONLY the JSON object NOW:"""

    try:
        image_base64 = image_to_base64(image_path)

        payload = {
            "model": "Qwen3-VL-8B-Instruct",
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}},
                    {"type": "text", "text": prompt}
                ]
            }],
            "max_tokens": 500,
            "temperature": 0.01,  # 降低温度以提高确定性
            "stream": False
        }

        response = requests.post(VLM_API_URL, json=payload, timeout=60)
        response.raise_for_status()

        result = response.json()
        content = result['choices'][0]['message']['content'].strip()

        # 清理 markdown 代码块
        content = clean_json_output(content)

        detection_result = json.loads(content)

        # 验证并规范化结果
        objects = detection_result.get('objects', [])
        if not isinstance(objects, list):
            print(f"  VLM 返回格式错误：objects 应为列表")
            return []

        # 规范化：确保每个物体都有 category 和 confidence
        valid_objects = []
        for obj in objects:
            if isinstance(obj, dict) and 'category' in obj:
                category = str(obj['category']).lower().strip()
                # 标准化类别名称
                category = category.replace(' ', '_').replace('-', '_')
                # 跳过 ceiling
                if category == 'ceiling':
                    continue
                valid_objects.append({
                    'category': category,
                    'confidence': float(obj.get('confidence', 0.5))
                })

        # 去重 (保留最高置信度)
        category_best = {}
        for obj in valid_objects:
            cat = obj['category']
            if cat not in category_best or obj['confidence'] > category_best[cat]['confidence']:
                category_best[cat] = obj
        objects = list(category_best.values())

        if objects:
            print(f"    VLM 检测到 {len(objects)} 个物体：{', '.join([o['category'] for o in objects[:5]])}{'...' if len(objects) > 5 else ''}")

        return objects

    except json.JSONDecodeError as e:
        print(f"  VLM JSON 解析失败：{e}")
        print(f"  原始输出：{content[:200] if 'content' in dir() else 'N/A'}...")
        return []
    except Exception as e:
        print(f"  VLM 物体检测失败：{e}")
        return []


def clean_json_output(content):
    """清理 VLM 输出，提取有效 JSON"""
    # 移除 markdown 代码块标记
    if content.startswith('```json'):
        content = content[7:]
    if content.startswith('```'):
        content = content[3:]
    if content.endswith('```'):
        content = content[:-3]
    
    content = content.strip()
    
    # 尝试找到第一个 { 和最后一个 }
    start = content.find('{')
    end = content.rfind('}') + 1
    
    if start >= 0 and end > start:
        return content[start:end]
    
    return content


def image_to_base64(image_path):
    """将图片转换为 base64"""
    with open(image_path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')


# ================= GroundingDINO + SAM2 =================

def grounding_dino_detect(image_path, category):
    """GroundingDINO 检测边界框"""
    try:
        payload = {
            "image_path": str(image_path),
            "text_prompt": category,
            "box_threshold": 0.3,
            "text_threshold": 0.25
        }
        
        response = requests.post(GROUNDING_DINO_URL, json=payload, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        if not result.get('success', False):
            return []
        
        boxes = result.get('boxes', [])
        labels = result.get('labels', [])
        scores = result.get('scores', [])
        
        detections = [
            {'bbox': box, 'confidence': scores[i] if i < len(scores) else 0.5, 'label': labels[i] if i < len(labels) else category}
            for i, box in enumerate(boxes[:3])  # 最多 3 个检测
        ]
        
        # 调试输出
        if len(detections) > 0:
            print(f"      DINO: {category} → {len(detections)} 个框")
        
        return detections
        
    except Exception as e:
        print(f"      DINO 失败 ({category}): {e}")
        return []


def sam2_segment(image_path, boxes):
    """SAM2 生成分割掩码"""
    try:
        img = cv2.imread(str(image_path))
        if img is None:
            return []
        img_height, img_width = img.shape[:2]
        
        masks = []
        for box in boxes:
            payload = {
                "image_path": str(image_path),
                "box": box
            }
            
            response = requests.post(SAM2_URL, json=payload, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            if not result.get('success', False):
                continue
            
            if 'mask' in result:
                mask_data = base64.b64decode(result['mask'])
                mask_np = cv2.imdecode(np.frombuffer(mask_data, dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
                
                if mask_np is not None and mask_np.shape == (img_height, img_width):
                    masks.append({
                        'mask': mask_np,
                        'box': box,
                        'score': result.get('score', 0)
                    })
        
        # 调试输出
        if len(masks) > 0:
            print(f"        SAM2: 生成 {len(masks)} 个掩码")
        
        return masks
        
    except Exception as e:
        print(f"        SAM2 失败：{e}")
        return []


def mask_to_3d_points(mask_2d, depth_img, K, T_c2w):
    """2D 掩码 → 3D 点云"""
    # depth_img 已经是米为单位 (在主函数中转换)
    depth = depth_img.astype(np.float32)
    
    # SAM2 掩码是 0/255，转换为 0/1
    mask_binary = (mask_2d > 128).astype(np.uint8)
    
    valid_mask = (mask_binary > 0) & (depth > DEPTH_MIN) & (depth < DEPTH_MAX)
    
    if valid_mask.sum() == 0:
        return np.empty((0, 3))
    
    v, u = np.where(valid_mask)
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]
    
    z_cam = depth[v, u]
    x_cam = (u - cx) * z_cam / fx
    y_cam = (v - cy) * z_cam / fy
    
    points_cam = np.stack([x_cam, y_cam, z_cam], axis=-1)
    points_hom = np.hstack([points_cam, np.ones((len(points_cam), 1))])
    points_world = (T_c2w @ points_hom.T).T[:, :3]
    
    return points_world


# ================= 楼层分割 (与 HoloAgent 一致) =================

def segment_floors(global_points, global_colors):
    """
    基于高度直方图 + 峰值检测的楼层分割 (与 HoloAgent 一致)

    流程:
    1. 体素下采样 (0.05m)
    2. 创建 Y 轴 (高度) 直方图 (bin=0.01m)
    3. 高斯平滑 + 峰值检测
    4. DBSCAN 聚类峰值
    5. 每两个峰值之间定义一个楼层
    """
    from sklearn.cluster import DBSCAN
    from scipy.signal import find_peaks
    from scipy.ndimage import gaussian_filter1d
    
    print("  体素下采样 (0.05m)...")
    down_points, down_colors = voxel_downsample(global_points, global_colors, 0.05)
    
    # 创建高度 (Y 轴) 直方图
    y_coords = down_points[:, 1]
    y_min, y_max = y_coords.min(), y_coords.max()
    
    # 计算 bin 数量 (bin 大小=0.01m)
    num_bins = int((y_max - y_min) / FLOOR_HIST_BIN_SIZE)
    print(f"  高度范围：{y_min:.2f}m ~ {y_max:.2f}m, {num_bins} 个 bin")
    
    # 创建直方图
    hist, bin_edges = np.histogram(y_coords, bins=num_bins)
    
    # 高斯平滑
    hist_smooth = gaussian_filter1d(hist.astype(float), sigma=FLOOR_GAUSSIAN_SIGMA)
    
    # 峰值检测
    distance = int(FLOOR_PEAK_DISTANCE / FLOOR_HIST_BIN_SIZE)  # 转换为 bin 数量
    min_peak_height = np.percentile(hist_smooth, FLOOR_PEAK_HEIGHT_PERCENTILE)
    print(f"  峰值检测：distance={distance} bins, min_height={min_peak_height:.1f}")
    
    peaks, _ = find_peaks(hist_smooth, distance=distance, height=min_peak_height)
    print(f"  检测到 {len(peaks)} 个峰值")
    
    if len(peaks) == 0:
        # 如果没有检测到峰值，将整个场景作为一个楼层
        print("  未检测到峰值，使用单楼层")
        floors = [{'id': 0, 'y_min': y_min, 'y_max': y_max, 'points': global_points, 'colors': global_colors}]
        return floors
    
    # 峰值位置 (实际高度值)
    peak_heights = bin_edges[peaks]
    print(f"  峰值高度：{peak_heights.round(2)}")
    
    # DBSCAN 聚类峰值
    clustering = DBSCAN(eps=FLOOR_DBSCAN_EPS, min_samples=1).fit(peak_heights.reshape(-1, 1))
    labels = clustering.labels_
    
    # 对每个聚类，取顶部和底部峰值作为楼层边界
    clustered_peaks = []
    for label in np.unique(labels):
        cluster_peaks = peak_heights[labels == label]
        if len(cluster_peaks) >= 2:
            # 取最高和最低的峰值
            clustered_peaks.extend([cluster_peaks.min(), cluster_peaks.max()])
        else:
            clustered_peaks.append(cluster_peaks[0])
    
    clustered_peaks = np.sort(clustered_peaks)
    print(f"  聚类后峰值：{clustered_peaks.round(2)}")
    
    # 生成楼层边界
    floors = []
    for i in range(0, len(clustered_peaks) - 1, 2):
        floor_y_min = clustered_peaks[i]
        floor_y_max = clustered_peaks[i + 1] if i + 1 < len(clustered_peaks) else y_max
        floors.append({'y_min': floor_y_min, 'y_max': floor_y_max})
    
    # 如果没有生成楼层，使用整个范围
    if len(floors) == 0:
        floors.append({'y_min': y_min, 'y_max': y_max})
    
    # 扩展第一个楼层到地面，最后一个楼层到天花板
    if len(floors) > 0:
        floors[0]['y_min'] = (floors[0]['y_min'] + y_min) / 2
        floors[-1]['y_max'] = y_max
    
    print(f"  检测到 {len(floors)} 个楼层")
    
    # 为每个楼层分配点云
    for i, floor in enumerate(floors):
        floor_mask = (global_points[:, 1] >= floor['y_min']) & (global_points[:, 1] <= floor['y_max'])
        floor['points'] = global_points[floor_mask]
        floor['colors'] = global_colors[floor_mask] if len(global_colors) == len(global_points) else global_colors[floor_mask]
        floor['id'] = i
        floor['floor_zero_level'] = floor['points'][:, 1].min() if len(floor['points']) > 0 else floor['y_min']
        floor['floor_height'] = floor['y_max'] - floor['floor_zero_level']
        print(f"    Floor {i}: {len(floor['points']):,} 点，zero_level={floor['floor_zero_level']:.2f}m, height={floor['floor_height']:.2f}m")
    
    return floors


# ================= 几何增强的房间分割 =================

def segment_rooms_by_floor(global_points, global_colors, objects):
    """
    基于 2D 直方图 + 形态学 + 距离变换的房间分割 (与 HoloAgent 一致)

    流程:
    1. 提取 floor 点云 (基于高度过滤)
    2. 投影到 2D (XZ 平面)
    3. 创建 2D 直方图/栅格地图
    4. 形态学操作提取墙体骨架 (GaussianBlur + threshold)
    5. 距离变换 + 分水岭算法分割房间
    6. 映射回 3D 点云
    """
    import cv2
    from scipy import ndimage
    from sklearn.neighbors import NearestNeighbors

    # Step 1: 提取 floor 点云 (使用最低楼层的地面点)
    floor_points_list = []
    for obj in objects:
        if obj['category'] == 'floor':
            floor_points_list.append(obj['points'])

    if len(floor_points_list) == 0:
        print("  未检测到 floor 点云，使用全局点云分割")
        return segment_rooms_geometric(global_points, global_colors)

    all_floor_points = np.vstack(floor_points_list)
    print(f"  Floor 点云：{len(all_floor_points):,} 点")

    # 计算楼层零平面和高度
    floor_zero_level = all_floor_points[:, 1].min()
    floor_height = all_floor_points[:, 1].max() - floor_zero_level
    print(f"  Floor zero level: {floor_zero_level:.2f}m, height: {floor_height:.2f}m")

    # Step 2: 高度过滤 (与 HoloAgent 一致：floor_zero_level+0.3 ~ floor_height-0.3)
    height_min = floor_zero_level + ROOM_HEIGHT_MIN_OFFSET
    height_max = floor_zero_level + floor_height - ROOM_HEIGHT_MAX_OFFSET
    floor_filtered = all_floor_points[(all_floor_points[:, 1] >= height_min) & 
                                       (all_floor_points[:, 1] <= height_max)]
    print(f"  高度过滤后：{len(floor_filtered):,} 点")

    if len(floor_filtered) < 100:
        print("  floor 点云太少，使用 fallback 方法")
        return segment_rooms_geometric(global_points, global_colors)

    # Step 3: 投影到 2D (XZ 平面)
    floor_2d = floor_filtered[:, [0, 2]]
    
    # 计算 2D 边界和栅格尺寸
    x_min, z_min = floor_2d.min(axis=0)
    x_max, z_max = floor_2d.max(axis=0)
    
    grid_size_x = int(np.ceil((x_max - x_min) / GRID_RESOLUTION)) + 1
    grid_size_z = int(np.ceil((z_max - z_min) / GRID_RESOLUTION)) + 1
    
    print(f"  2D 边界：X[{x_min:.2f}, {x_max:.2f}], Z[{z_min:.2f}, {z_max:.2f}]")
    print(f"  栅格尺寸：{grid_size_x} x {grid_size_z}")

    # Step 4: 创建 2D 直方图
    num_bins = (grid_size_z, grid_size_x)
    hist, _, _ = np.histogram2d(floor_2d[:, 1], floor_2d[:, 0], bins=num_bins,
                                 range=[[z_min, z_max], [x_min, x_max]])

    # 归一化并应用高斯模糊
    hist_norm = cv2.normalize(hist, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_blur = cv2.GaussianBlur(hist_norm, (GAUSSIAN_BLUR_KERNEL, GAUSSIAN_BLUR_KERNEL), GAUSSIAN_BLUR_SIGMA)

    # 阈值处理提取墙体骨架
    threshold = int(HIST_THRESHOLD_RATIO * 255)
    _, walls_skeleton = cv2.threshold(hist_blur, threshold, 255, cv2.THRESH_BINARY)

    # HoloAgent: 添加 border 避免丢失墙体
    walls_skeleton = cv2.copyMakeBorder(
        walls_skeleton, 10, 10, 10, 10, cv2.BORDER_CONSTANT, value=0
    )
    
    # HoloAgent: 墙体骨架形态学闭运算
    kernel_cross = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    walls_skeleton = cv2.morphologyEx(
        walls_skeleton, cv2.MORPH_CLOSE, kernel_cross, iterations=1
    )

    # Step 5: 提取外部边界 (HoloAgent 方法)
    hist_full, _, _ = np.histogram2d(
        floor_2d[:, 1], floor_2d[:, 0], bins=num_bins,
        range=[[z_min, z_max], [x_min, x_max]])
    hist_full = cv2.normalize(
        hist_full, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_full = cv2.GaussianBlur(hist_full, (21, 21), 2)
    _, outside_boundary = cv2.threshold(
        hist_full, 0, 255, cv2.THRESH_BINARY)
    
    # HoloAgent: 添加 border
    outside_boundary = cv2.copyMakeBorder(
        outside_boundary, 10, 10, 10, 10, cv2.BORDER_CONSTANT, value=0
    )
    
    # HoloAgent: 外部边界形态学闭运算
    kernel_rect_5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    outside_boundary = cv2.morphologyEx(
        outside_boundary, cv2.MORPH_CLOSE, kernel_rect_5, iterations=3
    )
    
    # HoloAgent: 提取外部轮廓并填充
    contours, _ = cv2.findContours(
        outside_boundary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    outside_boundary_filled = np.zeros_like(outside_boundary)
    cv2.drawContours(outside_boundary_filled, contours, -1, 255, -1)
    outside_boundary = outside_boundary_filled.astype(np.uint8)

    # 合并墙体骨架和外部边界 (HoloAgent: bitwise_or + bitwise_not)
    full_map = cv2.bitwise_or(
        walls_skeleton,
        cv2.bitwise_not(outside_boundary))

    # HoloAgent: full_map 形态学闭运算
    kernel_rect_3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    full_map = cv2.morphologyEx(
        full_map, cv2.MORPH_CLOSE, kernel_rect_3, iterations=2
    )

    # Step 6: 距离变换 + 分水岭算法 (与 HoloAgent 一致)
    # HoloAgent: 对 full_map 做反转后再做距离变换
    bw = cv2.bitwise_not(full_map)
    dist_transform = cv2.distanceTransform(bw, cv2.DIST_L2, cv2.DIST_MASK_3)

    # 归一化
    cv2.normalize(dist_transform, dist_transform, 0, 1.0, cv2.NORM_MINMAX)
    
    # HoloAgent: 高斯模糊 + Otsu 阈值
    dist_transform_uint8 = (dist_transform * 255).astype(np.uint8)
    dist_blur = cv2.GaussianBlur(dist_transform_uint8, (11, 1), 10)
    _, dist_thresh = cv2.threshold(dist_blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # 创建 markers
    dist_8u = dist_thresh.astype(np.uint8)
    contours, _ = cv2.findContours(dist_8u, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    print(f"  距离变换种子数：{len(contours)}")
    
    # 移除小面积种子 (HoloAgent: min_area = 0.5m²)
    min_area_m = 0.5
    min_area = (min_area_m / GRID_RESOLUTION) ** 2
    contours = [c for c in contours if cv2.contourArea(c) > min_area]
    print(f"  过滤后种子数：{len(contours)}")
    
    # 创建 marker 图像
    markers = np.zeros(dist_8u.shape, dtype=np.int32)
    for i, contour in enumerate(contours):
        cv2.drawContours(markers, [contour], -1, i + 1, -1)
    
    # 添加背景 marker
    cv2.circle(markers, (3, 3), 1, len(contours) + 1, -1)
    
    # 分水岭算法
    if len(contours) > 0:
        full_map_3ch = cv2.cvtColor(full_map, cv2.COLOR_GRAY2BGR)
        markers = cv2.watershed(full_map_3ch, markers)
    else:
        print("  没有种子区域，跳过分水岭")
        markers = np.zeros_like(full_map, dtype=np.int32)

    # Step 7: 为每个标记区域创建房间
    rooms = []
    unique_markers = np.unique(markers[markers > 1])  # 跳过背景 (1) 和未知区域 (0)

    print(f"  分水岭分割得到 {len(unique_markers)} 个区域")

    # 使用 KDTree 将 2D 房间映射回 3D 点云 (HoloAgent 方法)
    floor_tree = NearestNeighbors(n_neighbors=1).fit(floor_2d)
    
    for marker_id in unique_markers:
        room_mask = (markers == marker_id)

        # 获取房间 2D 点 (栅格坐标)
        room_2d_indices = np.where(room_mask)
        if len(room_2d_indices[0]) < 10:
            continue

        # 计算房间 2D 边界 (世界坐标)
        z_indices = room_2d_indices[0] * GRID_RESOLUTION + z_min
        x_indices = room_2d_indices[1] * GRID_RESOLUTION + x_min

        room_x_min, room_x_max = x_indices.min(), x_indices.max()
        room_z_min, room_z_max = z_indices.min(), z_indices.max()

        # HoloAgent: 将 2D 房间栅格映射回点云
        room_2d_cells = np.column_stack([x_indices, z_indices])
        _, indices = floor_tree.kneighbors(room_2d_cells, n_neighbors=1)
        room_floor_points = floor_filtered[indices.flatten()]

        if len(room_floor_points) < 50:
            continue

        # 房间中心
        room_center = room_floor_points.mean(axis=0)

        # 使用 KDTree 分配全局点云到房间
        global_tree = NearestNeighbors(n_neighbors=1).fit(global_points[:, [0, 2]])

        # 为房间生成 3D 边界框
        room_bbox_min = np.array([room_x_min, floor_zero_level, room_z_min])
        room_bbox_max = np.array([room_x_max, floor_zero_level + floor_height, room_z_max])

        # 分配点云：水平距离 < 0.5m 且高度在房间范围内
        room_center_2d = room_center[[0, 2]]
        dists, indices = global_tree.kneighbors(room_center_2d.reshape(1, 2), n_neighbors=100)

        room_points = []
        room_colors = []
        for i, pt in enumerate(global_points):
            pt_2d = pt[[0, 2]]
            dist_2d = np.linalg.norm(pt_2d - room_center_2d)
            height_ok = (pt[1] >= floor_zero_level - 0.5 and
                        pt[1] <= floor_zero_level + floor_height + 0.5)

            # 检查点是否在房间 2D 边界内
            in_bbox = (room_x_min - 0.5 <= pt_2d[0] <= room_x_max + 0.5 and
                      room_z_min - 0.5 <= pt_2d[1] <= room_z_max + 0.5)

            if in_bbox and height_ok:
                room_points.append(pt)
                room_colors.append(global_colors[i] if len(global_colors) == len(global_points) else [128, 128, 128])

        if len(room_points) < 100:
            continue

        room_points = np.array(room_points)
        room_colors = np.array(room_colors)

        rooms.append({
            'id': len(rooms),
            'points': room_points,
            'colors': room_colors,
            'center': room_points.mean(axis=0),
            'area': np.prod(room_points[:, [0, 2]].max(axis=0) - room_points[:, [0, 2]].min(axis=0)),
            'bbox': {
                'min': room_points.min(axis=0).tolist(),
                'max': room_points.max(axis=0).tolist()
            },
            'floor_zero_level': floor_zero_level,
            'floor_height': floor_height
        })

    print(f"  最终房间数：{len(rooms)}")
    return rooms


def segment_rooms_geometric(points, colors):
    """基于几何的房间分割 (fallback 方法)"""
    if len(points) < 1000:
        return []

    # 1. 提取 floor/ceiling (基于 Y 坐标)
    y_coords = points[:, 1]
    y_min, y_max = y_coords.min(), y_coords.max()

    floor_mask = y_coords < (y_min + 0.3)
    ceiling_mask = y_coords > (y_max - 0.3)

    # 2. 在水平面上聚类房间
    floor_points = points[floor_mask]
    if len(floor_points) < 100:
        return []

    from sklearn.cluster import DBSCAN

    # 地面点投影到 XZ 平面
    floor_2d = floor_points[:, [0, 2]]

    # DBSCAN 聚类房间
    db = DBSCAN(eps=0.5, min_samples=50).fit(floor_2d)
    labels = db.labels_

    rooms = []
    for label in np.unique(labels[labels >= 0]):
        room_mask = np.zeros(len(points), dtype=bool)
        room_floor_indices = np.where(labels == label)[0]

        # 找到对应的 3D 点索引
        floor_indices = np.where(floor_mask)[0]
        room_3d_indices = floor_indices[room_floor_indices]
        room_mask[room_3d_indices] = True

        room_points = points[room_mask]
        room_colors = colors[room_mask]

        if len(room_points) > 100:
            rooms.append({
                'points': room_points,
                'colors': room_colors,
                'center': room_points.mean(axis=0),
                'area': np.prod(room_points[:, [0, 2]].max(axis=0) - room_points[:, [0, 2]].min(axis=0))
            })

    return rooms


# ================= 场景拓扑图 =================

def build_scene_graph(global_pcd, rooms, objects, merged_objects, floors=None):
    """构建分层场景拓扑图"""

    scene_graph = {
        'timestamp': datetime.now().isoformat(),
        'global_bbox': {
            'min': global_pcd['points'].min(axis=0).tolist(),
            'max': global_pcd['points'].max(axis=0).tolist(),
            'num_points': len(global_pcd['points'])
        },
        'floors': [],
        'rooms': [],
        'connections': [],
        'objects_summary': {},
        'processing_config': {
            'max_frames': MAX_FRAMES,
            'skip_frames': SKIP_FRAMES,
            'object_detection_interval': OBJECT_DETECTION_INTERVAL,
            'actual_frames_processed': merged_objects.get('num_frames', 0),
            'detection_frames': merged_objects.get('detection_frames', 0),
            'merge_categories': MERGE_CATEGORIES,
            'detect_categories': OBJECT_CATEGORIES
        }
    }

    # 使用传入的 floors 参数 (与 HoloAgent 一致)
    if floors is not None and len(floors) > 0:
        for floor_idx, floor in enumerate(floors):
            floor_rooms = [i for i, r in enumerate(rooms) if r.get('floor_id') == floor_idx]
            scene_graph['floors'].append({
                'id': floor_idx,
                'y_level': floor.get('zero_level', 0),
                'floor_height': floor.get('height', 0),
                'num_rooms': len(floor_rooms),
                'room_ids': floor_rooms,
                'bbox': {
                    'min': [float(floor['points'][:, 0].min()),
                            float(floor['points'][:, 1].min()),
                            float(floor['points'][:, 2].min())] if len(floor.get('points', [])) > 0 else [0,0,0],
                    'max': [float(floor['points'][:, 0].max()),
                            float(floor['points'][:, 1].max()),
                            float(floor['points'][:, 2].max())] if len(floor.get('points', [])) > 0 else [0,0,0]
                }
            })
    else:
        # Fallback: 按 Y 坐标分层 (原方法)
        if len(rooms) > 0:
            y_sorted = sorted(rooms, key=lambda r: r['center'][1])

            current_floor = {'rooms': [], 'y_level': y_sorted[0]['center'][1]}
            floor_id = 0

            for room in y_sorted:
                if abs(room['center'][1] - current_floor['y_level']) > FLOOR_HEIGHT_THRESHOLD:
                    scene_graph['floors'].append({
                        'id': floor_id,
                        'y_level': current_floor['y_level'],
                        'num_rooms': len(current_floor['rooms']),
                        'room_ids': list(range(len(current_floor['rooms'])))
                    })
                    floor_id += 1
                    current_floor = {'rooms': [], 'y_level': room['center'][1]}
                current_floor['rooms'].append(room)

            if current_floor['rooms']:
                scene_graph['floors'].append({
                    'id': floor_id,
                    'y_level': current_floor['y_level'],
                    'num_rooms': len(current_floor['rooms']),
                    'room_ids': list(range(len(current_floor['rooms'])))
                })

    # 房间信息 (几何属性)
    scene_graph['rooms'] = [
        {
            'id': i,
            'center': r['center'].tolist(),
            'area': float(r.get('area', 0)),
            'num_points': r.get('num_points', len(r.get('points', []))),
            'bbox': r.get('bbox', {
                'min': r['points'].min(axis=0).tolist() if len(r.get('points', [])) > 0 else [0,0,0],
                'max': r['points'].max(axis=0).tolist() if len(r.get('points', [])) > 0 else [0,0,0]
            })
        }
        for i, r in enumerate(rooms)
    ]
    
    # 房间连接关系 (基于空间邻接)
    connections = []
    if len(rooms) > 1:
        for i, room in enumerate(rooms):
            for j, other_room in enumerate(rooms):
                if i >= j:
                    continue
                # 检查房间是否相邻 (中心距离 < 阈值)
                dist = np.linalg.norm(room['center'][[0, 2]] - other_room['center'][[0, 2]])
                if dist < 3.0:  # 3 米内认为相邻
                    connections.append({
                        'from': i,
                        'to': j,
                        'distance': float(dist)
                    })
    
    scene_graph['connections'] = connections
    
    # 物体统计
    object_counts = defaultdict(int)
    for obj in objects:
        object_counts[obj['category']] += 1

    scene_graph['objects_summary'] = dict(object_counts)
    scene_graph['num_objects'] = len(objects)

    # 物体列表 (带编号和名称)
    scene_graph['objects'] = [
        {
            'id': i,
            'name': obj.get('name', f"{obj['category']}_{obj.get('id', 0)}"),
            'category': obj['category'],
            'instance_id': obj.get('id', 0),
            'center': obj['points'].mean(axis=0).tolist(),
            'num_points': len(obj['points']),
            'num_frames': obj.get('num_frames', 1),
            'bbox': {
                'min': obj['points'].min(axis=0).tolist(),
                'max': obj['points'].max(axis=0).tolist()
            }
        }
        for i, obj in enumerate(objects)
    ]

    return scene_graph


def save_point_cloud(filename, points, colors):
    """保存点云为 PLY"""
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points.astype(np.float64))
    pcd.colors = o3d.utility.Vector3dVector(colors.astype(np.float64) / 255.0)
    o3d.io.write_point_cloud(str(filename), pcd, write_ascii=False, compressed=True)


def main():
    print("=" * 70)
    print("统一 3D 场景重建 + 物体分割 + 拓扑图生成")
    print("(单趟遍历同时完成全局点云和物体分割)")
    print("=" * 70)

    # 创建输出目录
    OUTPUT_DIR.mkdir(exist_ok=True, parents=True)
    (OUTPUT_DIR / 'global').mkdir(exist_ok=True)
    (OUTPUT_DIR / 'objects').mkdir(exist_ok=True)

    # 检查服务
    print("\n[0] 检查服务连接...")
    services_ok = True
    vlm_ok = False

    try:
        # 尝试调用 VLM API (使用实际的 chat/completions 端点测试)
        test_payload = {
            "model": "Qwen3-VL-8B-Instruct",
            "messages": [{"role": "user", "content": [{"type": "text", "text": "test"}]}],
            "max_tokens": 10
        }
        response = requests.post(VLM_API_URL, json=test_payload, timeout=5)
        if response.status_code == 200:
            print("  ✓ VLM API (物体检测)")
            vlm_ok = True
        else:
            print(f"  ✗ VLM API (状态码：{response.status_code})")
    except Exception as e:
        print(f"  ✗ VLM API ({str(e)[:50]})")

    try:
        requests.post(GROUNDING_DINO_URL, json={"image_path": "", "text_prompt": "test"}, timeout=5)
        print("  ✓ GroundingDINO")
    except:
        print("  ✗ GroundingDINO")
        services_ok = False

    try:
        requests.post(SAM2_URL, json={"image_path": "", "box": [0, 0, 10, 10]}, timeout=5)
        print("  ✓ SAM2")
    except:
        print("  ✗ SAM2")
        services_ok = False

    if not services_ok:
        print("\n警告：部分服务不可用，将跳过对应功能")
    
    # 加载数据
    print("\n[1] 加载数据...")
    K = load_intrinsics(INTRINSIC_FILE)
    poses = load_poses(POSES_FILE)
    depth_files = sorted(DEPTH_DIR.glob("*.png"))[:MAX_FRAMES * SKIP_FRAMES]
    
    print(f"  内参：fx={K[0,0]:.1f}, fy={K[1,1]:.1f}, cx={K[0,2]:.1f}, cy={K[1,2]:.1f}")
    print(f"  位姿：{len(poses)} 个")
    print(f"  深度图：{len(depth_files)} 个")
    
    # 打印配置信息
    print(f"\n[配置]")
    print(f"  最大帧数：{MAX_FRAMES}")
    print(f"  跳帧：每 {SKIP_FRAMES} 帧处理 1 帧")
    print(f"  物体检测间隔：每 {OBJECT_DETECTION_INTERVAL} 帧检测一次")
    print(f"  检测类别：{OBJECT_CATEGORIES}")
    print(f"  合并类别：{MERGE_CATEGORIES}")
    
    # ================= 一趟遍历：同时完成全局点云 + 物体分割 =================
    print("\n" + "=" * 70)
    print("[2] 一趟遍历：同时完成全局点云累积 + 物体语义分割")
    print("=" * 70)
    
    # 全局点云容器
    all_global_points = []
    all_global_colors = []

    # 物体点云容器 (按帧存储，后续合并)
    all_objects = []

    # 处理计数器
    num_frames_processed = 0
    num_objects_detected = 0
    num_detection_frames = 0
    num_vlm_detections = 0

    for i, depth_file in enumerate(tqdm(depth_files, desc="处理帧")):
        if i % SKIP_FRAMES != 0:
            continue

        timestamp_str = depth_file.stem

        if timestamp_str not in poses:
            continue

        # 读取深度图
        depth = cv2.imread(str(depth_file), cv2.IMREAD_UNCHANGED)
        if depth is None:
            continue

        if depth.dtype == np.uint16:
            depth = depth.astype(np.float32) / DEPTH_SCALE
        elif depth.dtype == np.uint8:
            depth = depth.astype(np.float32)

        # 读取彩色图
        color_file = IMAGES_DIR / f"{timestamp_str}.png"
        if not color_file.exists():
            color_file = IMAGES_DIR / f"{timestamp_str}.jpg"
        if not color_file.exists():
            continue

        color = cv2.imread(str(color_file), cv2.IMREAD_COLOR)
        if color is None:
            continue
        color = cv2.cvtColor(color, cv2.COLOR_BGR2RGB)

        if color.shape[:2] != depth.shape:
            color = cv2.resize(color, (depth.shape[1], depth.shape[0]))

        T_c2w = poses[timestamp_str]

        # ========== 任务 1: 生成全局点云 ==========
        points_global, colors_global = depth_to_pointcloud(depth, color, K, T_c2w)

        if len(points_global) > 0:
            all_global_points.append(points_global)
            all_global_colors.append(colors_global)

        # ========== 任务 2: VLM 物体检测 + GroundingDINO + SAM2 分割 ==========
        # 优化：只在关键帧检测物体
        if services_ok and (i // SKIP_FRAMES) % OBJECT_DETECTION_INTERVAL == 0:
            num_detection_frames += 1

            # Step 1: VLM 检测物体类别
            if vlm_ok:
                detected_objects = vlm_detect_objects(color_file)
                num_vlm_detections += 1
                # 提取类别列表 (去重)
                categories_to_detect = list(set([obj['category'] for obj in detected_objects]))
            else:
                # VLM 不可用，使用固定类别
                categories_to_detect = OBJECT_CATEGORIES

            # Step 2: 对每个检测到的类别进行 GroundingDINO + SAM2 分割
            for category in categories_to_detect:
                detections = grounding_dino_detect(color_file, category)
                if not detections:
                    continue

                boxes = [det['bbox'] for det in detections[:3]]  # 最多 3 个框
                masks = sam2_segment(color_file, boxes)

                # 将 2D 掩码投影到 3D
                for mask_data in masks:
                    points_3d = mask_to_3d_points(mask_data['mask'], depth, K, T_c2w)

                    if len(points_3d) > OBJECT_MIN_POINTS:
                        # 计算物体中心 (世界坐标)
                        object_center = points_3d.mean(axis=0)
                        
                        all_objects.append({
                            'category': category,
                            'points': points_3d,
                            'frame': timestamp_str,
                            'center': object_center,
                            'T_c2w': T_c2w.copy()
                        })
                        num_objects_detected += 1
                        if num_objects_detected <= 5:  # 只显示前 5 个
                            print(f"          ✓ 3D 物体：{category}, {len(points_3d)} 点，中心={object_center.round(2)}")

        num_frames_processed += 1

    print(f"\n  处理帧数：{num_frames_processed}")
    print(f"  检测帧数：{num_detection_frames} (每 {OBJECT_DETECTION_INTERVAL} 帧检测一次)")
    if vlm_ok:
        print(f"  VLM 检测次数：{num_vlm_detections}")
    print(f"  检测到物体实例：{num_objects_detected}")

    # ================= 合并全局点云 =================
    if len(all_global_points) == 0:
        print("  错误：没有生成任何点云!")
        return
    
    all_global_points = np.vstack(all_global_points)
    all_global_colors = np.vstack(all_global_colors)
    print(f"\n  全局点云 (原始): {len(all_global_points):,} 点")
    
    # 体素下采样
    global_points, global_colors = voxel_downsample(all_global_points, all_global_colors, VOXEL_SIZE)
    print(f"  全局点云 (下采样): {len(global_points):,} 点 (压缩比 {len(global_points)/len(all_global_points)*100:.1f}%)")

    # DBSCAN 去噪 (与 HoloAgent 一致)
    print("\n  DBSCAN 去噪...")
    global_pcd_temp = o3d.geometry.PointCloud()
    global_pcd_temp.points = o3d.utility.Vector3dVector(global_points)
    global_pcd_temp.colors = o3d.utility.Vector3dVector(global_colors) if len(global_colors) == len(global_points) else None

    # DBSCAN 去噪参数 (与 HoloAgent 一致)
    cl = global_pcd_temp.cluster_dbscan(eps=DBSCAN_EPS, min_points=DBSCAN_MIN_POINTS, print_progress=False)
    cl = np.array(cl)

    # 统计簇大小，保留最大簇 (跳过噪声点 -1)
    valid_labels = cl[cl >= 0]
    if len(valid_labels) > 0:
        cluster_sizes = np.bincount(valid_labels)
        max_cluster = np.argmax(cluster_sizes) + 1  # +1 因为标签从 0 开始，但需要跳过 -1
        inlier_mask = cl == max_cluster
    else:
        inlier_mask = np.ones(len(global_points), dtype=bool)

    print(f"  离群点：{len(global_points) - inlier_mask.sum():,} ({100*(len(global_points) - inlier_mask.sum())/len(global_points):.1f}%)")

    global_points = global_points[inlier_mask]
    global_colors = global_colors[inlier_mask] if len(global_colors) == len(all_global_points) else global_colors[inlier_mask]
    print(f"  去噪后点云：{len(global_points):,} 点")
    
    # 保存全局点云
    global_pcd_file = OUTPUT_DIR / "global" / "global_pointcloud.ply"
    save_point_cloud(global_pcd_file, global_points, global_colors)
    print(f"  ✓ 已保存：{global_pcd_file}")
    
    # ================= 合并跨帧物体 =================
    # ================= 机器人轨迹平面拟合 =================
    print("\n" + "=" * 70)
    print("[3] 机器人轨迹平面拟合 (RANSAC)")
    print("=" * 70)

    trajectory_plane_result = fit_trajectory_plane_from_poses(poses)

    # ================= 跨帧物体合并 + 同类物体编号 =================
    print("\n" + "=" * 70)
    print("[4] 跨帧物体合并 + 同类物体编号")
    print("=" * 70)

    # 第一步：同类别 + 近距离合并 (合并同一物体在不同帧中的检测)
    merged_objects = []
    used = set()

    for i, obj in enumerate(all_objects):
        if i in used:
            continue

        cluster = [obj]
        used.add(i)
        center_i = obj['points'].mean(axis=0)

        for j, other in enumerate(all_objects[i+1:], i+1):
            if j in used:
                continue
            if other['category'] != obj['category']:
                continue

            center_j = other['points'].mean(axis=0)
            # 使用世界坐标距离判断是否为同一物体
            if np.linalg.norm(center_i - center_j) < OBJECT_MERGE_DISTANCE_THRESHOLD:
                cluster.append(other)
                used.add(j)

        # 合并簇
        all_pts = np.vstack([c['points'] for c in cluster])
        merged_objects.append({
            'category': obj['category'],
            'points': all_pts,
            'num_frames': len(cluster)
        })

    print(f"  近距离合并后：{len(merged_objects)} 个物体")

    # 第二步：合并 wall 和 floor 为单个物体，其他类别进行编号
    final_objects = []
    category_counters = defaultdict(int)  # 记录每类物体的数量

    for category in MERGE_CATEGORIES:
        category_objects = [obj for obj in merged_objects if obj['category'] == category]
        if len(category_objects) > 0:
            all_pts = np.vstack([obj['points'] for obj in category_objects])
            final_objects.append({
                'category': category,
                'points': all_pts,
                'num_frames': sum([obj['num_frames'] for obj in category_objects]),
                'id': 0  # 合并为单个物体，ID 为 0
            })
            print(f"  合并 {category}: {len(category_objects)} → 1 (总点数：{len(all_pts):,})")

    # 处理其他需要编号的物体
    for obj in merged_objects:
        if obj['category'] not in MERGE_CATEGORIES:
            category = obj['category']
            # 为同类物体分配编号
            obj_with_id = {
                **obj,
                'id': category_counters[category],
                'name': f"{category}_{category_counters[category]}"
            }
            final_objects.append(obj_with_id)
            category_counters[category] += 1

    # 为没有 name 字段的物体添加 name
    for obj in final_objects:
        if 'name' not in obj:
            obj['name'] = f"{obj['category']}_{obj['id']}"

    print(f"  最终物体数：{len(final_objects)}")

    # 打印物体列表 (带编号)
    print("\n  物体列表:")
    for i, obj in enumerate(final_objects):
        print(f"    [{i:03d}] {obj['name']}: {len(obj['points']):,} 点 (帧数：{obj.get('num_frames', 1)})")

    # 保存物体点云 (带编号)
    for i, obj in enumerate(final_objects):
        colors = np.tile([128, 128, 128], (len(obj['points']), 1))
        obj_file = OUTPUT_DIR / "objects" / f"object_{i:04d}_{obj['name']}.ply"
        save_point_cloud(obj_file, obj['points'], colors)

    # 物体统计
    obj_counts = defaultdict(int)
    for obj in final_objects:
        obj_counts[obj['category']] += 1

    print("\n  物体统计:")
    for cat, count in sorted(obj_counts.items()):
        print(f"    {cat}: {count} 个")

    # ================= 楼层分割 (HoloAgent 风格) =================
    print("\n" + "=" * 70)
    print("[5] 楼层分割 (HoloAgent 风格：高度直方图 + 峰值检测)")
    print("=" * 70)

    # 使用 HoloAgent 风格的楼层分割
    floor_levels = segment_floors_holoagent(global_points)
    
    if len(floor_levels) == 0:
        print("  未检测到楼层，使用全局高度范围")
        floor_levels = [{'zero_level': global_points[:, VERTICAL_AXIS].min(), 
                        'height': global_points[:, VERTICAL_AXIS].max() - global_points[:, VERTICAL_AXIS].min(),
                        'peak': global_points[:, VERTICAL_AXIS].max()}]

    # ================= 房间分割 (HoloAgent 风格) =================
    print("\n" + "=" * 70)
    print("[6] 房间分割 (HoloAgent: 2D 直方图 + 形态学 + 距离变换/分水岭)")
    print("=" * 70)

    # 对每个楼层进行房间分割
    all_rooms = []
    for floor_idx, floor_data in enumerate(floor_levels):
        print(f"\n  处理 Floor {floor_idx}...")
        
        floor_zero_level = floor_data['zero_level']
        floor_height = floor_data['height']
        
        # 提取楼层点云
        floor_mask = (global_points[:, VERTICAL_AXIS] >= floor_zero_level) & \
                     (global_points[:, VERTICAL_AXIS] < floor_zero_level + floor_height)
        floor_points = global_points[floor_mask]
        floor_colors = global_colors[floor_mask] if len(global_colors) == len(global_points) else []

        print(f"  Floor 点云：{len(floor_points):,} 点")

        # 房间分割
        room_save_path = OUTPUT_DIR / "rooms" / f"floor_{floor_idx}"
        rooms = segment_rooms_holoagent(floor_points, floor_zero_level, floor_height, str(room_save_path))

        # 保存房间
        rooms_output_dir = OUTPUT_DIR / "rooms" / f"floor_{floor_idx}_rooms"
        save_rooms(rooms, str(rooms_output_dir))
        
        # 添加到总房间列表
        for room in rooms:
            room['floor_id'] = floor_idx
            all_rooms.append(room)

    rooms = all_rooms
    print(f"\n  总房间数：{len(rooms)}")

    # 房间已经由 save_rooms 保存，这里只打印统计信息
    for i, room in enumerate(rooms):
        print(f"    Room {i} (Floor {room.get('floor_id', 0)}): {len(room['points']):,} 点，面积 {room.get('area', 0):.1f}m², 中心={room['center'].round(2)}")

    # ================= 拟合轨迹平面 =================
    print("\n" + "=" * 70)
    print("[7] 拟合机器人行走轨迹平面")
    print("=" * 70)

    poses = load_poses(POSES_FILE)
    trajectory_plane = fit_trajectory_plane_from_poses(poses)

    # 从位姿生成重采样轨迹 (用于 gateway 检测)
    positions = np.array([T[:3, 3] for T in poses.values()])
    n_poses = len(positions)

    # 计算累计距离
    distances = np.zeros(n_poses)
    for i in range(1, n_poses):
        distances[i] = distances[i - 1] + np.linalg.norm(positions[i] - positions[i - 1])

    total_length = distances[-1]
    step_size = 0.01  # 1cm
    num_samples = int(np.floor(total_length / step_size)) + 1
    sample_distances = np.linspace(0, total_length, num_samples)

    # 线性插值重采样
    resampled_traj = np.zeros((num_samples, 3))
    for i, sd in enumerate(sample_distances):
        idx = np.searchsorted(distances, sd, side='right') - 1
        idx = min(max(idx, 0), n_poses - 2)
        seg_len = distances[idx + 1] - distances[idx]
        t = (sd - distances[idx]) / seg_len if seg_len > 1e-8 else 0.0
        resampled_traj[i] = positions[idx] + t * (positions[idx + 1] - positions[idx])

    traj_pcd = o3d.geometry.PointCloud()
    traj_pcd.points = o3d.utility.Vector3dVector(resampled_traj)
    traj_path = OUTPUT_DIR / "trajectory_resampled.ply"
    o3d.io.write_point_cloud(str(traj_path), traj_pcd)
    print(f"  ✓ 已保存重采样轨迹: {traj_path} ({num_samples} 点, {total_length:.2f}m)")

    # ================= 基于轨迹的 Gateway 检测 =================
    print("\n" + "=" * 70)
    print("[8] Gateway 检测 (基于实际行走轨迹)")
    print("=" * 70)

    # 加载重采样轨迹
    if traj_path.exists():
        traj_pcd_loaded = o3d.io.read_point_cloud(str(traj_path))
        trajectory = np.asarray(traj_pcd_loaded.points)
        print(f"  轨迹点数: {len(trajectory)}")

        # 导入 gateway detector
        from navigation.gateway_detector import GatewayDetector

        # 提取 floor 点云 (用于 detector)
        floor_zero_level = floor_levels[0]['zero_level'] if floor_levels else global_points[:, VERTICAL_AXIS].min()
        floor_height = floor_levels[0]['height'] if floor_levels else global_points[:, VERTICAL_AXIS].max() - floor_zero_level
        floor_mask = (global_points[:, VERTICAL_AXIS] >= floor_zero_level) & \
                     (global_points[:, VERTICAL_AXIS] < floor_zero_level + floor_height)
        floor_points = global_points[floor_mask]

        # 创建 detector
        detector = GatewayDetector(floor_points, resolution=0.05)

        # 加载房间点云 (真实的房间分割, 而不是 bbox)
        rooms_dir = OUTPUT_DIR / "rooms" / "floor_0_rooms"
        room_pointclouds = {}
        if rooms_dir.exists():
            for room_file in rooms_dir.glob("room_*.ply"):
                room_id = int(room_file.stem.replace("room_", ""))
                room_pcd = o3d.io.read_point_cloud(str(room_file))
                room_pts = np.asarray(room_pcd.points)
                room_pointclouds[room_id] = room_pts
            print(f"  ✓ 加载了 {len(room_pointclouds)} 个房间的点云")
        
        # 为每个房间创建 room dict (带 points)
        enriched_rooms = []
        for room in rooms:
            room_data = dict(room)
            if room['id'] in room_pointclouds:
                room_data['points'] = room_pointclouds[room['id']]
            enriched_rooms.append(room_data)

        # 生成房间栅格
        room_raster = detector.compute_room_raster(enriched_rooms)
        floor_grid = detector._compute_floor_grid()

        # 检测 gateway
        gateways = detector.detect_gateways_from_trajectory(
            trajectory=trajectory,
            rooms=enriched_rooms,
            room_raster=room_raster,
            floor_grid=floor_grid,
            merge_distance=1.0
        )

        # 将 gateway 投影到拟合的轨迹平面
        plane_normal = trajectory_plane['normal']
        plane_d = trajectory_plane['d']

        def project_to_plane(point):
            """将点投影到平面上 (沿法向量方向)"""
            dist = np.dot(plane_normal, point) + plane_d
            return point - dist * plane_normal

        for gw in gateways:
            gw.position_3d = project_to_plane(gw.position_3d)

        print(f"\n  已将 {len(gateways)} 个 gateway 投影到轨迹平面")

        # 保存 gateway 点云
        gateway_output_dir = OUTPUT_DIR / "navigation" / "gateways"
        gateway_output_dir.mkdir(parents=True, exist_ok=True)

        if gateways:
            # 保存 gateway 点云 (黄色)
            gw_cloud = []
            gw_colors = []
            for gw in gateways:
                pos = gw.position_3d
                # 每个 gateway 生成 100 个点用于可视化
                for _ in range(100):
                    pt = pos + np.random.normal(0, 0.08, 3)
                    gw_cloud.append(pt)
                    gw_colors.append([1.0, 1.0, 0.0])  # 黄色

            gw_pcd = o3d.geometry.PointCloud()
            gw_pcd.points = o3d.utility.Vector3dVector(np.array(gw_cloud))
            gw_pcd.colors = o3d.utility.Vector3dVector(np.array(gw_colors))

            gw_ply_path = gateway_output_dir / "gateways.ply"
            o3d.io.write_point_cloud(str(gw_ply_path), gw_pcd)
            print(f"  ✓ 已保存 gateway 点云: {gw_ply_path} ({len(gw_cloud)} 点)")

            # 保存 gateway JSON
            gw_data = {
                'gateways': [{
                    'id': gw.id,
                    'room_a': gw.room_a,
                    'room_b': gw.room_b,
                    'position': gw.position.tolist(),
                    'position_3d': gw.position_3d.tolist(),
                    'width': gw.width,
                    'confidence': gw.confidence
                } for gw in gateways],
                'total': len(gateways)
            }

            gw_json_path = gateway_output_dir / "gateways.json"
            with open(gw_json_path, 'w') as f:
                json.dump(gw_data, f, indent=2)
            print(f"  ✓ 已保存 gateway 数据: {gw_json_path}")

            print(f"\n  Gateway 列表 ({len(gateways)} 个):")
            for gw in gateways:
                print(f"    GW{gw.id}: Room {gw.room_a} ↔ Room {gw.room_b} "
                      f"@ ({gw.position_3d[0]:.2f}, {gw.position_3d[1]:.2f}, {gw.position_3d[2]:.2f}) "
                      f"穿越={int(gw.confidence * 10)}, 宽≈{gw.width:.2f}m")
        else:
            print("  未检测到 gateway")
    else:
        print(f"  警告: 轨迹文件不存在 {traj_path}，跳过 gateway 检测")

    # ================= 构建场景拓扑图 =================
    print("\n" + "=" * 70)
    print("[9] 构建场景拓扑图")
    print("=" * 70)

    global_pcd = {'points': global_points, 'colors': global_colors}
    merged_info = {
        'num_frames': num_frames_processed,
        'detection_frames': num_detection_frames
    }
    # floors 使用 floor_levels
    scene_graph = build_scene_graph(global_pcd, rooms, final_objects, merged_info, floor_levels)

    with open(SCENE_GRAPH_FILE, 'w') as f:
        json.dump(scene_graph, f, indent=2, default=str)

    print(f"  ✓ 已保存：{SCENE_GRAPH_FILE}")
    print(f"  楼层数：{len(scene_graph['floors'])}")
    print(f"  房间数：{len(scene_graph.get('rooms', []))}")
    print(f"  房间连接数：{len(scene_graph.get('connections', []))}")
    print(f"  物体数：{scene_graph['num_objects']}")

    # ================= 生成俯视图可视化 =================
    print("\n" + "=" * 70)
    print("[10] 生成俯视图可视化")
    print("=" * 70)

    top_view_output_dir = OUTPUT_DIR / "top_view"
    generate_top_view_visualization(global_points, global_colors, rooms, top_view_output_dir)

    # ================= 完成 =================
    print("\n" + "=" * 70)
    print("完成!")
    print("=" * 70)
    print(f"\n输出目录：{OUTPUT_DIR}")
    print(f"  - 全局点云：{OUTPUT_DIR / 'global' / 'global_pointcloud.ply'} ({len(global_points):,} 点)")
    print(f"  - 房间点云：{OUTPUT_DIR / 'rooms' / 'floor_*_rooms' / 'room_*.ply'} ({len(rooms)} 个)")
    print(f"  - 物体点云：{OUTPUT_DIR / 'objects' / 'object_*.ply'} ({len(final_objects)} 个)")
    print(f"  - Gateway 点云：{OUTPUT_DIR / 'navigation' / 'gateways' / 'gateways.ply'} (黄色)")
    print(f"  - 场景拓扑图：{SCENE_GRAPH_FILE}")
    print(f"  - 俯视图可视化：{OUTPUT_DIR / 'top_view' / '*.png'}")

    # 打印场景图摘要
    print("\n场景拓扑图摘要:")
    print(json.dumps(scene_graph, indent=2, default=str)[:1500])


if __name__ == "__main__":
    main()
