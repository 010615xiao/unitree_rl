"""
导出相机轨迹点云

从 poses.txt 读取所有相机位姿，将相机位置导出为点云文件，
可在 MeshLab/CloudCompare 中与全局点云一起查看。

输出:
  unified_output/camera_trajectory.ply  - 相机轨迹点云（绿色球体）
  unified_output/camera_trajectory_with_orientation.ply - 带朝向的轨迹（箭头）

用法:
  python export_camera_trajectory.py
  python export_camera_trajectory.py --poses /path/to/poses.txt --output /path/output.ply
  python export_camera_trajectory.py --with-orientation  # 导出带朝向的轨迹
"""

import argparse
import numpy as np
from pathlib import Path
import open3d as o3d
from scipy.spatial.transform import Rotation as R


def load_poses_tum(pose_file):
    """
    加载 TUM 格式位姿文件
    
    格式: timestamp tx ty tz qx qy qz qw
    
    应用与 build_pointcloud.py 相同的坐标轴变换:
        T_c2w = T_switch_axis @ inv(T_w2c)
    
    返回:
        poses: list of dict, 每个包含 timestamp, position (3,), rotation (3x3), T_c2w (4x4)
    """
    # 坐标轴变换矩阵 (与 build_pointcloud.py 一致)
    T_SWITCH_AXIS = np.array([
        [1, 0, 0, 0],
        [0, 0, 1, 0],
        [0, -1, 0, 0],
        [0, 0, 0, 1]
    ], dtype=np.float64)
    
    poses = []
    with open(pose_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) < 8:
                continue
            
            timestamp = parts[0]
            tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
            qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])
            
            # 四元数转旋转矩阵
            quat = [qx, qy, qz, qw]
            quat = quat / np.linalg.norm(quat)
            rot_matrix = R.from_quat(quat).as_matrix()
            
            # 构建世界到相机变换
            T_w2c = np.eye(4)
            T_w2c[:3, :3] = rot_matrix
            T_w2c[:3, 3] = [tx, ty, tz]
            
            # 取逆得到相机到世界变换
            T_c2w = np.linalg.inv(T_w2c)
            
            # 应用坐标轴变换 (与 build_pointcloud.py 一致)
            T_c2w = T_SWITCH_AXIS @ T_c2w
            
            # 提取变换后的位置和旋转
            position = T_c2w[:3, 3]
            rotation = T_c2w[:3, :3]
            
            poses.append({
                'timestamp': timestamp,
                'position': position,
                'rotation': rotation,
                'T_c2w': T_c2w,
            })
    
    return poses


def create_trajectory_pointcloud(poses):
    """
    创建相机轨迹点云（每个位姿一个点）
    
    参数:
        poses: 位姿列表
    
    返回:
        pcd: open3d.PointCloud
    """
    positions = np.array([p['position'] for p in poses])
    
    # 颜色：从蓝色渐变到绿色（表示时间顺序）
    n = len(poses)
    colors = np.zeros((n, 3))
    for i in range(n):
        t = i / max(n - 1, 1)
        colors[i] = [0.0, 0.3 + t * 0.7, 1.0 - t * 0.5]  # 蓝→绿
    
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(positions)
    pcd.colors = o3d.utility.Vector3dVector(colors)
    
    return pcd


def create_trajectory_with_orientation(poses, arrow_length=0.3):
    """
    创建带朝向的相机轨迹点云（每个位姿一个点 + 朝向向量）
    
    参数:
        poses: 位姿列表
        arrow_length: 箭头长度
    
    返回:
        pcd: open3d.PointCloud
    """
    all_points = []
    all_colors = []
    
    for i, pose in enumerate(poses):
        pos = pose['position']
        rot = pose['rotation']
        
        # 相机光轴方向（世界坐标系）
        camera_axis = rot @ np.array([0, 0, -1])
        camera_axis = camera_axis / np.linalg.norm(camera_axis)
        
        # 位姿点
        all_points.append(pos)
        
        # 朝向箭头终点
        all_points.append(pos + arrow_length * camera_axis)
        
        # 颜色
        t = i / max(len(poses) - 1, 1)
        color_start = [0.0, 0.5 + t * 0.5, 1.0 - t * 0.5]  # 起点颜色
        color_end = [1.0 - t * 0.5, 0.8, t * 0.3]            # 终点颜色
        all_colors.append(color_start)
        all_colors.append(color_end)
    
    all_points = np.array(all_points)
    all_colors = np.array(all_colors)
    
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(all_points)
    pcd.colors = o3d.utility.Vector3dVector(all_colors)
    
    return pcd


def main():
    parser = argparse.ArgumentParser(description='导出相机轨迹点云')
    parser.add_argument('--poses', type=str, default=None,
                       help='poses.txt 路径 (自动查找)')
    parser.add_argument('--output', type=str, default=None,
                       help='输出 PLY 路径')
    parser.add_argument('--with-orientation', action='store_true',
                       help='导出带朝向的轨迹（箭头）')
    parser.add_argument('--radius', type=float, default=0.03,
                       help='轨迹点半径 (默认 0.03m)')
    parser.add_argument('--points-per-pose', type=int, default=50,
                       help='每个位姿的点数 (默认 50)')
    parser.add_argument('--arrow-length', type=float, default=0.3,
                       help='箭头长度 (默认 0.3m, 仅 --with-orientation)')
    
    args = parser.parse_args()
    
    base_dir = Path(__file__).resolve().parent
    
    # 自动查找 poses.txt
    if args.poses is None:
        candidate_paths = [
            base_dir / 'poses.txt',
            Path('/workspace/wxd/VLN/datasets/icra_ic7f/poses.txt'),
            Path('/workspace/wxd/VLN/datasets/icra_ic4f/poses.txt'),
        ]
        
        poses_file = None
        for p in candidate_paths:
            if p.exists():
                poses_file = p
                break
        
        if poses_file is None:
            print("错误: 未找到 poses.txt，请使用 --poses 指定")
            return
    else:
        poses_file = Path(args.poses)
        if not poses_file.exists():
            print(f"错误: poses 文件不存在: {poses_file}")
            return
    
    print(f"加载位姿: {poses_file}")
    poses = load_poses_tum(poses_file)
    print(f"  共 {len(poses)} 帧")
    
    if len(poses) == 0:
        print("错误: 无有效位姿数据")
        return
    
    # 打印第一帧和最后一帧
    first = poses[0]
    last = poses[-1]
    print(f"  第一帧: {first['timestamp']}, 位置: {first['position']}")
    print(f"  最后一帧: {last['timestamp']}, 位置: {last['position']}")
    
    # 计算轨迹范围
    positions = np.array([p['position'] for p in poses])
    bbox_min = positions.min(axis=0)
    bbox_max = positions.max(axis=0)
    print(f"  轨迹范围: {bbox_min} → {bbox_max}")
    print(f"  移动距离: {np.linalg.norm(bbox_max - bbox_min):.2f}m")
    
    # 生成点云
    if args.with_orientation:
        print(f"\n生成带朝向的轨迹点云（箭头长度: {args.arrow_length}m）...")
        pcd = create_trajectory_with_orientation(
            poses, arrow_length=args.arrow_length
        )
    else:
        print(f"\n生成轨迹点云（共 {len(poses)} 个点）...")
        pcd = create_trajectory_pointcloud(poses)
    
    # 输出路径
    if args.output is None:
        output_dir = base_dir / 'unified_output'
        output_dir.mkdir(exist_ok=True)
        
        if args.with_orientation:
            output_file = output_dir / 'camera_trajectory_with_orientation.ply'
        else:
            output_file = output_dir / 'camera_trajectory.ply'
    else:
        output_file = Path(args.output)
        output_file.parent.mkdir(parents=True, exist_ok=True)
    
    # 保存
    o3d.io.write_point_cloud(str(output_file), pcd)
    print(f"\n轨迹点云已保存: {output_file}")
    print(f"  总点数: {len(pcd.points):,}")
    
    # 可选：与全局点云合并
    global_pcd_path = base_dir / 'unified_output' / 'global' / 'global_pointcloud.ply'
    if global_pcd_path.exists():
        print(f"\n检测到全局点云: {global_pcd_path}")
        merge = input("是否合并轨迹到全局点云? (y/n): ").strip().lower()
        if merge in ['y', 'yes']:
            global_pcd = o3d.io.read_point_cloud(str(global_pcd_path))
            combined = global_pcd + pcd
            
            combined_path = base_dir / 'unified_output' / 'global_pointcloud_with_trajectory.ply'
            o3d.io.write_point_cloud(str(combined_path), combined)
            print(f"合并点云已保存: {combined_path}")
            print(f"  总点数: {len(combined.points):,}")


if __name__ == '__main__':
    main()
