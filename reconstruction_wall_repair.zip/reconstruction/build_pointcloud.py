#!/usr/bin/env python3
"""
从 RGB-D 序列构建全局 3D 点云
参考：HoloAgent/fsr_vln 项目

数据格式:
  - color/*.png: 彩色图像
  - depth/*.png: 深度图像 (单位：毫米)
  - poses.txt: 相机位姿 (格式：timestamp tx ty tz qx qy qz qw)
  - d435i.yaml: 相机内参
"""

import os
import numpy as np
import cv2
import yaml
from pathlib import Path

# ================= 配置参数 =================
BASE_DIR = Path(__file__).parent.parent  # 指向 icra_ic7f 目录

COLOR_DIR = BASE_DIR / "images"
DEPTH_DIR = BASE_DIR / "depth"
POSES_FILE = BASE_DIR / "poses.txt"
CAMERA_CONFIG = BASE_DIR / "d435i.yaml"

# 输出文件
OUTPUT_PLY = BASE_DIR / "reconstruction" / "global_pointcloud.ply"
OUTPUT_PLY_DENSE = BASE_DIR / "reconstruction" / "global_pointcloud_dense.ply"

# 点云处理参数 (参考 HoloAgent/fsr_vln 项目)
VOXEL_SIZE = 0.03         # 体素下采样大小 (米)
SKIP_FRAMES = 10          # 跳帧采样

# 坐标轴变换矩阵 (用于切换相机坐标系到 Open3D 坐标系)
USE_AXIS_TRANSFORM = True
T_SWITCH_AXIS = np.array([
    [1, 0, 0, 0],
    [0, 0, 1, 0],
    [0, -1, 0, 0],
    [0, 0, 0, 1]
], dtype=np.float64)

# 深度过滤
DEPTH_MIN = 0.1           # 最小深度 (米)
DEPTH_MAX = 10.0          # 最大深度 (米) - 减小到 10m 减少远处噪声

# DBSCAN 去噪参数 (开启以去除噪声)
USE_DBSCAN = True         # 开启：去除噪声点
DBSCAN_EPS = 0.05         # DBSCAN 邻域半径 (增加到 5cm)
DBSCAN_MIN_POINTS = 50    # DBSCAN 最小点数 (减小到 50)

# 半径离群点移除 (开启以去除噪声)
USE_RADIUS_OUTLIER = True
RADIUS_OUTLIER_NB = 500   # 邻域点数 (减小到 500)
RADIUS_OUTLIER_RADIUS = 0.5  # 半径 (米) (减小到 0.5m)

# 深度图缩放比例 (深度图单位：毫米 -> 米)
DEPTH_SCALE = 1000.0
# ===========================================


def load_camera_config(config_file):
    """加载相机内参"""
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)

    K = np.array([
        [config['Camera1.fx'], 0, config['Camera1.cx']],
        [0, config['Camera1.fy'], config['Camera1.cy']],
        [0, 0, 1]
    ])
    return K


def load_poses(pose_file):
    """
    加载相机位姿 (TUM 格式：timestamp tx ty tz qx qy qz qw)
    返回：{timestamp: 4x4 变换矩阵 (相机到世界)}
    
    注意：位姿文件中的变换是世界到相机 (w2c)，需要取逆得到相机到世界 (c2w)
    然后应用坐标轴变换以匹配 Open3D 坐标系
    """
    poses = {}
    with open(pose_file, 'r') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue

            parts = line.strip().split()
            if len(parts) != 8:
                continue

            timestamp = parts[0]
            tx, ty, tz = float(parts[1]), float(parts[2]), float(parts[3])
            qx, qy, qz, qw = float(parts[4]), float(parts[5]), float(parts[6]), float(parts[7])

            # 四元数转旋转矩阵
            R = quaternion_to_rotation_matrix(qx, qy, qz, qw)

            # 构建 4x4 变换矩阵 (世界到相机)
            T_w2c = np.eye(4)
            T_w2c[:3, :3] = R
            T_w2c[0, 3] = tx
            T_w2c[1, 3] = ty
            T_w2c[2, 3] = tz

            # 取逆得到相机到世界的变换
            T_c2w = np.linalg.inv(T_w2c)
            
            # 应用坐标轴变换 (如果需要)
            if USE_AXIS_TRANSFORM:
                T_c2w = T_SWITCH_AXIS @ T_c2w

            poses[timestamp] = T_c2w

    return poses


def quaternion_to_rotation_matrix(qx, qy, qz, qw):
    """四元数转旋转矩阵"""
    # 归一化四元数
    norm = np.sqrt(qx*qx + qy*qy + qz*qz + qw*qw)
    qx, qy, qz, qw = qx/norm, qy/norm, qz/norm, qw/norm

    R = np.eye(3)
    R[0, 0] = 1 - 2*qy*qy - 2*qz*qz
    R[0, 1] = 2*qx*qy - 2*qz*qw
    R[0, 2] = 2*qx*qz + 2*qy*qw
    R[1, 0] = 2*qx*qy + 2*qz*qw
    R[1, 1] = 1 - 2*qx*qx - 2*qz*qz
    R[1, 2] = 2*qy*qz - 2*qx*qw
    R[2, 0] = 2*qx*qz - 2*qy*qw
    R[2, 1] = 2*qy*qz + 2*qx*qw
    R[2, 2] = 1 - 2*qx*qx - 2*qy*qy

    return R


def depth_to_pointcloud(depth, color, K, T_cam2world):
    """
    将深度图和彩色图转换为点云

    参数:
        depth: 深度图 (单位：米)
        color: 彩色图 (RGB)
        K: 相机内参矩阵 (3x3)
        T_cam2world: 相机到世界的变换矩阵 (4x4)

    返回:
        points: 3D 点坐标 (N x 3)
        colors: 颜色 (N x 3)
    """
    fx, fy = K[0, 0], K[1, 1]
    cx, cy = K[0, 2], K[1, 2]

    # 获取有效深度像素
    valid_mask = depth > 0
    v, u = np.where(valid_mask)

    if len(u) == 0:
        return np.empty((0, 3)), np.empty((0, 3))

    # 获取深度值
    depths = depth[v, u].flatten()

    # 反投影到相机坐标系
    # 相机坐标系：X 向右，Y 向下，Z 向前
    X_cam = (u - cx) * depths / fx
    Y_cam = (v - cy) * depths / fy  # 不需要负号
    Z_cam = depths

    # 齐次坐标
    points_cam = np.stack([X_cam, Y_cam, Z_cam, np.ones_like(X_cam)], axis=1)

    # 变换到世界坐标系
    points_world = (T_cam2world @ points_cam.T).T
    points_world = points_world[:, :3] / points_world[:, 3:4]

    # 获取颜色
    colors = color[v, u]

    return points_world, colors


def voxel_downsample(points, colors, voxel_size):
    """
    体素下采样 (同时处理点和颜色)
    """
    if len(points) == 0:
        return points, colors

    # 计算体素索引
    indices = np.floor(points / voxel_size).astype(np.int64)

    # 使用结构化数组进行快速去重
    idx_min = indices.min(axis=0)
    indices_norm = indices - idx_min
    range_max = indices_norm.max(axis=0) + 1

    # 计算线性索引
    linear_idx = (indices_norm[:, 0] * range_max[1] * range_max[2] +
                  indices_norm[:, 1] * range_max[2] +
                  indices_norm[:, 2])

    # 去重，保留每个体素的第一个点
    _, unique_idx = np.unique(linear_idx, return_index=True)

    # 取每个体素的第一个点
    downsampled_points = points[unique_idx]
    downsampled_colors = colors[unique_idx]

    return downsampled_points, downsampled_colors


def dbscan_denoise(points, colors, eps=DBSCAN_EPS, min_points=DBSCAN_MIN_POINTS):
    """
    DBSCAN 去噪 (保留最大连通簇)
    """
    try:
        import open3d as o3d
        
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
        
        # DBSCAN 聚类
        labels = np.array(pcd.cluster_dbscan(eps=eps, min_points=min_points, print_progress=False))
        
        # 统计每个簇的点数
        unique_labels, counts = np.unique(labels[labels >= 0], return_counts=True)
        
        if len(unique_labels) == 0:
            print(f"  DBSCAN 警告：未找到有效簇，保留所有点")
            return points, colors
        
        # 找到最大簇的标签
        largest_cluster_label = unique_labels[np.argmax(counts)]
        
        # 保留最大簇的点
        mask = labels == largest_cluster_label
        filtered_points = points[mask]
        filtered_colors = colors[mask]
        
        print(f"  DBSCAN 去噪：{len(points):,} → {len(filtered_points):,} 点 (保留最大簇)")
        
        return filtered_points, filtered_colors
    
    except ImportError:
        print("  Open3D 不可用，跳过 DBSCAN 去噪")
        return points, colors


def radius_outlier_removal(points, colors, nb_points=RADIUS_OUTLIER_NB, radius=RADIUS_OUTLIER_RADIUS):
    """
    半径离群点移除
    """
    try:
        import open3d as o3d
        
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.colors = o3d.utility.Vector3dVector(colors / 255.0)
        
        # 半径离群点移除
        _, ind = pcd.remove_radius_outlier(nb_points=nb_points, radius=radius)
        
        filtered_points = points[ind]
        filtered_colors = colors[ind]
        
        print(f"  半径离群点移除：{len(points):,} → {len(filtered_points):,} 点")
        
        return filtered_points, filtered_colors
    
    except ImportError:
        print("  Open3D 不可用，跳过半径离群点移除")
        return points, colors


def save_ply_with_color(filename, points, colors):
    """保存带颜色的 PLY 文件 (使用 Open3D)"""
    try:
        import open3d as o3d

        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points.astype(np.float64))
        pcd.colors = o3d.utility.Vector3dVector(colors.astype(np.float64) / 255.0)

        o3d.io.write_point_cloud(str(filename), pcd, write_ascii=False, compressed=True)
        print(f"  使用 Open3D 保存 PLY：{filename}")
    except ImportError:
        print("  Open3D 不可用，使用备用保存方法")
        _save_ply_basic(filename, points, colors)


def _save_ply_basic(filename, points, colors):
    """基础 PLY 保存方法 (二进制)"""
    n_points = len(points)

    # 创建结构化数组
    vertex_data = np.zeros(n_points, dtype=[
        ('x', '<f4'), ('y', '<f4'), ('z', '<f4'),
        ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')
    ])

    vertex_data['x'] = points[:, 0].astype(np.float32)
    vertex_data['y'] = points[:, 1].astype(np.float32)
    vertex_data['z'] = points[:, 2].astype(np.float32)
    vertex_data['red'] = colors[:, 0].astype(np.uint8)
    vertex_data['green'] = colors[:, 1].astype(np.uint8)
    vertex_data['blue'] = colors[:, 2].astype(np.uint8)

    with open(filename, 'wb') as f:
        header = f"""ply
format binary_little_endian 1.0
element vertex {n_points}
property float x
property float y
property float z
property uchar red
property uchar green
property uchar blue
end_header
"""
        f.write(header.encode('ascii'))
        f.write(vertex_data.tobytes())


def main():
    print("=" * 60)
    print("RGB-D 全局 3D 点云重建工具 (icra_ic4f)")
    print("参考：HoloAgent/fsr_vln 项目")
    print("=" * 60)

    # 检查数据目录
    print(f"\n数据目录：{BASE_DIR}")
    assert BASE_DIR.exists(), f"数据目录不存在：{BASE_DIR}"
    assert COLOR_DIR.exists(), f"彩色图目录不存在：{COLOR_DIR}"
    assert DEPTH_DIR.exists(), f"深度图目录不存在：{DEPTH_DIR}"
    assert POSES_FILE.exists(), f"位姿文件不存在：{POSES_FILE}"
    assert CAMERA_CONFIG.exists(), f"相机配置文件不存在：{CAMERA_CONFIG}"

    # 加载相机参数
    print("\n[1] 加载相机内参...")
    K = load_camera_config(CAMERA_CONFIG)
    print(f"  相机内参矩阵:\n{K}")
    print(f"  图像尺寸：640x480")

    # 加载位姿
    print("\n[2] 加载相机位姿...")
    poses = load_poses(POSES_FILE)
    print(f"  加载了 {len(poses)} 个位姿")

    # 获取深度图列表
    depth_files = sorted(list(DEPTH_DIR.glob("*.png")))
    print(f"  找到 {len(depth_files)} 个深度图")

    # 存储所有点云和颜色
    all_points = []
    all_colors = []

    print("\n[3] 逐帧重建点云...")
    processed = 0
    for i, depth_file in enumerate(depth_files):
        # 跳帧采样
        if i % SKIP_FRAMES != 0:
            continue

        frame_id = depth_file.stem

        if frame_id not in poses:
            continue

        # 读取深度图
        depth = cv2.imread(str(depth_file), cv2.IMREAD_UNCHANGED)
        if depth is None:
            continue

        # 深度图单位转换 (毫米 -> 米)
        if depth.dtype == np.uint16:
            depth = depth.astype(np.float32) / DEPTH_SCALE
        elif depth.dtype == np.uint8:
            depth = depth.astype(np.float32)
            print(f"  警告：深度图为 uint8 格式，可能已归一化")

        # 深度过滤
        depth_mask = (depth >= DEPTH_MIN) & (depth <= DEPTH_MAX)
        depth_filtered = depth * depth_mask

        # 读取彩色图
        color_file = COLOR_DIR / f"{frame_id}.png"
        if not color_file.exists():
            continue

        color = cv2.imread(str(color_file), cv2.IMREAD_COLOR)
        if color is None:
            continue

        # BGR -> RGB
        color = cv2.cvtColor(color, cv2.COLOR_BGR2RGB)

        # 确保彩色图和深度图尺寸一致
        if color.shape[:2] != depth_filtered.shape:
            color = cv2.resize(color, (depth_filtered.shape[1], depth_filtered.shape[0]))

        # 应用深度掩码到彩色图
        color_masked = color * depth_mask[:, :, np.newaxis]

        # 转换为点云
        points, colors = depth_to_pointcloud(depth_filtered, color_masked, K, poses[frame_id])

        if len(points) > 0:
            all_points.append(points)
            all_colors.append(colors)

        processed += 1
        if processed % 50 == 0:
            current_points = sum(len(p) for p in all_points)
            print(f"  进度：{processed}/{len(depth_files)//SKIP_FRAMES} 帧，累计点数：{current_points:,}")

    # 合并所有点云
    print("\n[4] 合并全局点云...")
    if len(all_points) == 0:
        print("  错误：没有生成任何点云!")
        return

    all_points = np.vstack(all_points)
    all_colors = np.vstack(all_colors)
    print(f"  合并后总点数：{all_points.shape[0]:,}")

    # 保存密集点云 (未下采样)
    print(f"\n[5] 保存密集点云到 {OUTPUT_PLY_DENSE}...")
    save_ply_with_color(OUTPUT_PLY_DENSE, all_points, all_colors)
    print(f"  密集点云已保存!")

    # 体素下采样
    print(f"\n[6] 体素下采样 (体素大小：{VOXEL_SIZE}m)...")
    downsampled_points, downsampled_colors = voxel_downsample(
        all_points, all_colors, VOXEL_SIZE
    )
    print(f"  下采样后点数：{downsampled_points.shape[0]:,}")
    print(f"  压缩比：{len(downsampled_points) / len(all_points) * 100:.1f}%")

    # DBSCAN 去噪 (保留最大连通簇)
    if USE_DBSCAN:
        print(f"\n[7] DBSCAN 去噪 (eps={DBSCAN_EPS}, min_points={DBSCAN_MIN_POINTS})...")
        downsampled_points, downsampled_colors = dbscan_denoise(
            downsampled_points, downsampled_colors
        )

    # 半径离群点移除
    if USE_RADIUS_OUTLIER:
        print(f"\n[8] 半径离群点移除 (nb_points={RADIUS_OUTLIER_NB}, radius={RADIUS_OUTLIER_RADIUS}m)...")
        downsampled_points, downsampled_colors = radius_outlier_removal(
            downsampled_points, downsampled_colors
        )

    # 保存下采样后的点云
    print(f"\n[9] 保存下采样点云到 {OUTPUT_PLY}...")
    save_ply_with_color(OUTPUT_PLY, downsampled_points, downsampled_colors)
    print(f"  点云已保存!")

    # 统计信息
    print("\n" + "=" * 60)
    print("重建完成!")
    print("=" * 60)
    print(f"\n输出文件:")
    print(f"  - 密集点云：{OUTPUT_PLY_DENSE}")
    print(f"  - 下采样点云：{OUTPUT_PLY}")
    print(f"\n点云统计:")
    print(f"  - 边界框 X: [{all_points[:, 0].min():.2f}, {all_points[:, 0].max():.2f}] 米")
    print(f"  - 边界框 Y: [{all_points[:, 1].min():.2f}, {all_points[:, 1].max():.2f}] 米")
    print(f"  - 边界框 Z: [{all_points[:, 2].min():.2f}, {all_points[:, 2].max():.2f}] 米")
    print(f"  - 总点数：{all_points.shape[0]:,}")
    print(f"  - 下采样后点数：{downsampled_points.shape[0]:,}")

    print("\n可视化建议:")
    print("  - 使用 CloudCompare / MeshLab / Open3D 查看 PLY 文件")
    print("  - Python: open3d.visualization.read_point_cloud('global_pointcloud.ply')")


if __name__ == "__main__":
    main()
