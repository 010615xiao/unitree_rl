#!/usr/bin/env python3
"""
HoloAgent 风格的房间分割脚本
直接从全局点云和楼层信息分割房间

注意：适配当前数据集的坐标系
- Y 轴：垂直方向（高度）
- X 轴：水平方向
- Z 轴：前后方向（房间延伸）
"""

import os
import numpy as np
import open3d as o3d
import cv2
from scipy.spatial import cKDTree
from scipy.ndimage import gaussian_filter1d
import matplotlib.pyplot as plt
from tqdm import tqdm

# 配置参数 (与 HoloAgent 一致)
GRID_RESOLUTION = 0.05  # 网格分辨率 (米)
ROOM_HEIGHT_MIN_OFFSET = 1.0  # 房间最小高度偏移
ROOM_HEIGHT_MAX_OFFSET = 0.3  # 房间最大高度偏移 (从天花板减去)
HIST_THRESHOLD_RATIO = 0.25  # 直方图阈值比例
GAUSSIAN_BLUR_KERNEL = 5  # 高斯模糊核大小
GAUSSIAN_BLUR_SIGMA = 1  # 高斯模糊 sigma

# 坐标轴配置
HORIZONTAL_AXES = [0, 2]  # X, Z 用于 2D 投影
VERTICAL_AXIS = 1  # Y 轴为高度


def load_pointcloud(ply_path):
    """加载点云"""
    pcd = o3d.io.read_point_cloud(ply_path)
    points = np.asarray(pcd.points)
    colors = np.asarray(pcd.colors)
    if len(colors) == 0:
        colors = None
    return points, colors


def segment_floors_holoagent(points, voxel_size=0.05):
    """HoloAgent 风格的楼层分割"""
    print("  体素下采样...")
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    pcd = pcd.voxel_down_sample(voxel_size)
    points = np.asarray(pcd.points)
    
    # 高度直方图
    y_coords = points[:, VERTICAL_AXIS]
    y_min, y_max = y_coords.min(), y_coords.max()
    bin_size = 0.01
    num_bins = int((y_max - y_min) / bin_size) + 1
    
    hist, bin_edges = np.histogram(y_coords, bins=num_bins, range=(y_min, y_max))
    hist_smooth = gaussian_filter1d(hist.astype(float), sigma=2)
    
    # 峰值检测
    from scipy.signal import find_peaks
    peaks, _ = find_peaks(hist_smooth, distance=20, height=np.max(hist_smooth) * 0.1)
    
    print(f"  检测到 {len(peaks)} 个峰值")
    
    # HoloAgent: 单楼层场景，直接使用 y_min 和 y_max
    floors = []
    if len(peaks) > 0:
        peak_h = bin_edges[peaks[np.argmax(hist_smooth[peaks])]]
        floors.append({
            'zero_level': y_min,
            'height': y_max - y_min,
            'peak': peak_h
        })
    
    print(f"  检测到 {len(floors)} 个楼层")
    for i, f in enumerate(floors):
        print(f"    Floor {i}: zero_level={f['zero_level']:.2f}m, height={f['height']:.2f}m")
    return floors


def segment_rooms_holoagent(floor_points, floor_zero_level, floor_height, save_path):
    """HoloAgent 风格的房间分割"""
    print(f"  Floor zero level: {floor_zero_level:.2f}m, height: {floor_height:.2f}m")
    
    xyz = floor_points.copy()
    xyz_full = floor_points.copy()
    
    # 高度裁剪 (与 HoloAgent 完全一致)
    xyz = xyz[xyz[:, VERTICAL_AXIS] < floor_zero_level + floor_height - ROOM_HEIGHT_MAX_OFFSET]
    xyz = xyz[xyz[:, VERTICAL_AXIS] >= floor_zero_level + ROOM_HEIGHT_MIN_OFFSET]
    xyz_full = xyz_full[xyz_full[:, VERTICAL_AXIS] < floor_zero_level + floor_height - 0.2]
    
    print(f"  高度过滤后：{len(xyz)} 点")
    
    # 投影到 2D
    pcd_2d = xyz[:, HORIZONTAL_AXES]
    xyz_full_2d = xyz_full[:, HORIZONTAL_AXES]
    
    # 计算网格尺寸
    grid_size = (
        int(np.max(pcd_2d[:, 0]) - np.min(pcd_2d[:, 0])),
        int(np.max(pcd_2d[:, 1]) - np.min(pcd_2d[:, 1]))
    )
    grid_size = (grid_size[0] + 1, grid_size[1] + 1)
    print(f"  栅格尺寸：{grid_size}")
    
    # 计算 2D 直方图
    num_bins = (int(grid_size[0] // GRID_RESOLUTION),
                int(grid_size[1] // GRID_RESOLUTION))
    num_bins = (num_bins[1] + 1, num_bins[0] + 1)
    
    hist, _, _ = np.histogram2d(pcd_2d[:, 1], pcd_2d[:, 0], bins=num_bins)
    hist_full, _, _ = np.histogram2d(xyz_full_2d[:, 1], xyz_full_2d[:, 0], bins=num_bins)
    
    os.makedirs(save_path, exist_ok=True)
    
    # 墙体骨架处理
    padding = 10
    hist_norm = cv2.normalize(hist, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_blur = cv2.GaussianBlur(hist_norm, (GAUSSIAN_BLUR_KERNEL, GAUSSIAN_BLUR_KERNEL), GAUSSIAN_BLUR_SIGMA)
    hist_threshold = HIST_THRESHOLD_RATIO * np.max(hist_blur)
    _, walls_skeleton = cv2.threshold(hist_blur, hist_threshold, 255, cv2.THRESH_BINARY)
    walls_skeleton = cv2.copyMakeBorder(walls_skeleton, padding, padding, padding, padding, cv2.BORDER_CONSTANT, value=0)
    kernel_cross = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    walls_skeleton = cv2.morphologyEx(walls_skeleton, cv2.MORPH_CLOSE, kernel_cross, iterations=1)
    
    # 外部边界处理
    hist_full_norm = cv2.normalize(hist_full, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    hist_full_blur = cv2.GaussianBlur(hist_full_norm, (21, 21), 2)
    _, outside_boundary = cv2.threshold(hist_full_blur, 0, 255, cv2.THRESH_BINARY)
    outside_boundary = cv2.copyMakeBorder(outside_boundary, padding, padding, padding, padding, cv2.BORDER_CONSTANT, value=0)
    kernel_rect_5 = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    outside_boundary = cv2.morphologyEx(outside_boundary, cv2.MORPH_CLOSE, kernel_rect_5, iterations=3)
    
    # 提取外部轮廓
    outside_boundary_filled = np.zeros_like(outside_boundary)
    contours, _ = cv2.findContours(outside_boundary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(outside_boundary_filled, contours, -1, 255, -1)
    outside_boundary_filled = outside_boundary_filled.astype(np.uint8)
    
    # 可视化
    plt.figure(figsize=(15, 5))
    plt.subplot(1, 4, 1)
    plt.imshow(walls_skeleton, cmap='gray', origin='lower')
    plt.title('Walls Skeleton')
    plt.axis('off')
    plt.subplot(1, 4, 2)
    plt.imshow(outside_boundary_filled, cmap='gray', origin='lower')
    plt.title('Outside Boundary')
    plt.axis('off')
    
    # 合并墙体骨架和外部边界
    full_map = cv2.bitwise_or(walls_skeleton, cv2.bitwise_not(outside_boundary_filled))
    kernel_rect_3 = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    full_map = cv2.morphologyEx(full_map, cv2.MORPH_CLOSE, kernel_rect_3, iterations=2)

    # 【新增】补全外围墙体 (与导航 cost_map 一致的补全策略)
    full_map = complete_boundary_walls(full_map)

    plt.subplot(1, 4, 3)
    plt.imshow(full_map, cmap='gray', origin='lower')
    plt.title('Full Map (with boundary walls)')
    plt.axis('off')
    
    # 距离变换 + 分水岭
    room_vertices = distance_transform(full_map, GRID_RESOLUTION, save_path)
    
    plt.subplot(1, 4, 4)
    markers_vis = np.zeros_like(full_map, dtype=float)
    for i, room in enumerate(room_vertices):
        if len(room[0]) > 0:
            markers_vis[room[0], room[1]] = i + 1
    plt.imshow(markers_vis, cmap='jet', origin='lower')
    plt.title(f'Rooms: {len(room_vertices)}')
    plt.axis('off')
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_path, 'room_segmentation.png'), dpi=150)
    plt.close()
    
    print(f"  分割得到 {len(room_vertices)} 个房间")
    
    # 将 2D 房间映射回 3D 点云
    rooms = map_rooms_to_3d(room_vertices, full_map, floor_points, floor_zero_level, 
                           floor_height, pcd_2d, save_path)
    
    return rooms


def distance_transform(occupancy_map, resolution, tmp_path):
    """HoloAgent 距离变换"""
    bw = cv2.bitwise_not(occupancy_map.copy())
    full_map = occupancy_map.copy()
    
    bw = np.uint8(bw)
    dist = cv2.distanceTransform(bw, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
    print(f"  距离范围：{np.min(dist):.2f} ~ {np.max(dist):.2f}")
    
    cv2.normalize(dist, dist, 0, 255, cv2.NORM_MINMAX)
    plt.figure()
    plt.imshow(dist, cmap='jet', origin='lower')
    plt.title('Distance Transform')
    plt.savefig(os.path.join(tmp_path, 'dist.png'))
    plt.close()
    
    dist = np.uint8(dist)
    blur = cv2.GaussianBlur(dist, (11, 1), 10)
    plt.figure()
    plt.imshow(blur, cmap='jet', origin='lower')
    plt.title('Distance Blur')
    plt.savefig(os.path.join(tmp_path, 'dist_blur.png'))
    plt.close()
    
    _, dist_thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    plt.figure()
    plt.imshow(dist_thresh, cmap='jet', origin='lower')
    plt.title('Distance Threshold')
    plt.savefig(os.path.join(tmp_path, 'dist_thresh.png'))
    plt.close()
    
    dist_8u = dist_thresh.astype(np.uint8)
    contours, _ = cv2.findContours(dist_8u, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    print(f"  种子数：{len(contours)}")
    
    # HoloAgent: min_area = 0.5m²
    min_area_m = 0.5
    min_area = (min_area_m / resolution) ** 2
    contours = [c for c in contours if cv2.contourArea(c) > min_area]
    print(f"  过滤后种子数：{len(contours)}")
    
    markers = np.zeros(dist.shape, dtype=np.int32)
    for i, contour in enumerate(contours):
        cv2.drawContours(markers, [contour], -1, i + 1, -1)
    cv2.circle(markers, (3, 3), 1, len(contours) + 1, -1)
    
    full_map_3ch = cv2.cvtColor(full_map, cv2.COLOR_GRAY2BGR)
    markers = cv2.watershed(full_map_3ch, markers)
    
    room_vertices = []
    for i in range(len(contours)):
        room_vertices.append(tuple(np.where(markers == i + 1)))
    
    plt.figure()
    plt.imshow(markers, cmap='jet', origin='lower')
    plt.title('Watershed Markers')
    plt.savefig(os.path.join(tmp_path, 'markers.png'))
    plt.close()
    
    return room_vertices


def complete_boundary_walls(full_map, iterations=1, margin=2):
    """
    补全外围墙体 (与导航 cost_map._complete_boundary_wall 思想一致)

    在 cost_map 中: 对 floor (1) 做膨胀，膨胀覆盖 unknown (0) 的部分标记为 wall (100)
    在 full_map 中: 对 room (0) 做膨胀，膨胀覆盖 wall (255) 的部分保留为 wall
                    → 等价于: 对 wall (255) 做膨胀 → wall 向 room 方向扩展

    参数:
        full_map: 原始栅格地图 (0=房间/可行走, 255=墙体/障碍)
        iterations: 膨胀迭代次数 (对应 cost_map 中 floor 的膨胀次数)
        margin: 边缘补全宽度

    返回:
        补全后的栅格地图
    """
    # Step 1+2: 对墙体 (255) 做膨胀 → wall 向 room 方向扩展
    # 这与 cost_map 中对 floor 做膨胀 → wall 向 unknown 方向扩展 是对称的
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    wall_mask = (full_map == 255).astype(np.uint8)
    wall_dilated = cv2.dilate(wall_mask, kernel, iterations=iterations)
    full_map[wall_dilated.astype(bool)] = 255

    # Step 3: 在栅格四条边补一圈墙体 (防止边缘开放)
    # 与 cost_map 中 margin=2 的边缘补墙逻辑一致
    # 上边
    full_map[0:margin, :] = 255
    # 下边
    full_map[-margin:, :] = 255
    # 左边
    full_map[:, 0:margin] = 255
    # 右边
    full_map[:, -margin:] = 255

    print(f"  补全外围 wall: 新增 {int(wall_dilated.sum() - wall_mask.sum())} 个障碍单元格")

    return full_map


def check_connected_components(occupancy_grid_map, min_cells=25):
    """
    检查栅格地图中的连通分量，返回每个分量的掩码。
    用于检测分水岭分割后是否仍有不连通的区域被错误归为一个房间。
    """
    grid = (occupancy_grid_map > 0).astype(np.uint8)
    n_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(grid, connectivity=4)
    
    components = []
    for i in range(1, n_labels):  # 跳过背景 (label=0)
        area = stats[i, cv2.CC_STAT_AREA]
        if area >= min_cells:
            mask = (labels == i).astype(np.uint8)
            components.append(mask)
    
    return components


def map_rooms_to_3d(room_vertices, full_map, floor_points, floor_zero_level,
                    floor_height, pcd_2d, save_path):
    """将 2D 房间映射回 3D 点云 (HoloAgent 方法 + 连通性检查)"""
    rooms = []
    room_id_counter = 0

    # 创建 floor 点云的 KDTree
    floor_tree = cKDTree(floor_points)

    for i, room_vertex in enumerate(tqdm(room_vertices, desc="Assign floor points to rooms")):
        if len(room_vertex[0]) == 0:
            continue

        # 创建房间掩码
        room = np.zeros_like(full_map)
        room[room_vertex[0], room_vertex[1]] = 255

        # 【新增】连通性检查：如果一个房间包含多个不连通的区域，拆分为多个房间
        components = check_connected_components(room, min_cells=25)
        if len(components) > 1:
            print(f"  房间 {i}: 检测到 {len(components)} 个不连通区域，进行拆分")
        
        masks_to_process = components if len(components) > 1 else [room]
        
        for comp_idx, comp_mask in enumerate(masks_to_process):
            # 映射到 2D 点云
            room_2d = map_grid_to_point_cloud(comp_mask, GRID_RESOLUTION, pcd_2d)

            if len(room_2d) < 10:
                continue

            # HoloAgent: 在不同高度层（Y 轴）挤压 2D 房间形成 3D 采样点
            # 我们的坐标系：Y 轴向上，所以需要在 Y 方向挤压
            y_levels = np.arange(floor_zero_level, floor_zero_level + floor_height, 0.05)

            room_3d_samples = []
            for y in y_levels:
                # room_2d 是 (x, z) 坐标，需要加上 y 坐标形成 (x, y, z)
                room_3d = np.column_stack([room_2d[:, 0], np.full(len(room_2d), y), room_2d[:, 1]])
                room_3d_samples.append(room_3d)
            room_3d_samples = np.vstack(room_3d_samples)

            # 使用 KDTree 查询原始点云
            _, idx = floor_tree.query(room_3d_samples, k=1, workers=-1)
            room_points = floor_points[idx]

            # 去重
            room_points = np.unique(room_points, axis=0)

            if len(room_points) < 50:
                continue

            room_center = room_points.mean(axis=0)
            room_area = np.prod(room_points[:, HORIZONTAL_AXES].max(axis=0) - room_points[:, HORIZONTAL_AXES].min(axis=0))

            rooms.append({
                'id': room_id_counter,
                'points': room_points,
                'center': room_center,
                'area': room_area,
                'bbox': {
                    'min': room_points.min(axis=0).tolist(),
                    'max': room_points.max(axis=0).tolist()
                }
            })
            room_id_counter += 1

    print(f"  最终房间数：{len(rooms)}")
    return rooms


def map_grid_to_point_cloud(occupancy_grid_map, resolution, point_cloud):
    """网格到点云映射 (HoloAgent 方法)"""
    occupancy_grid_map = (occupancy_grid_map > 0).astype(np.uint8)
    y_cells, x_cells = np.where(occupancy_grid_map == 1)
    
    # HoloAgent: 10.5 像素偏移 (padding=10 + 0.5 中心偏移)
    mapped_x_coords = (x_cells - 10.5) * resolution + np.min(point_cloud[:, 0])
    mapped_y_coords = (y_cells - 10.5) * resolution + np.min(point_cloud[:, 1])
    
    return np.column_stack((mapped_x_coords, mapped_y_coords))


def save_rooms(rooms, output_dir):
    """保存房间点云"""
    os.makedirs(output_dir, exist_ok=True)
    
    for room in rooms:
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(room['points'])
        
        color_idx = room['id'] % 10
        colors = plt.cm.tab10(color_idx)[:3]
        pcd.colors = o3d.utility.Vector3dVector(np.tile(colors, (len(room['points']), 1)))
        
        output_path = os.path.join(output_dir, f"room_{room['id']}.ply")
        o3d.io.write_point_cloud(output_path, pcd)
        print(f"  已保存：{output_path} ({len(room['points']):,} 点)")


def main():
    """主函数"""
    import argparse
    parser = argparse.ArgumentParser(description='HoloAgent 风格房间分割')
    parser.add_argument('--global_pcd', type=str, 
                       default='fsrvln_output/scene_graph.ply',
                       help='全局点云路径')
    parser.add_argument('--output_dir', type=str, 
                       default='unified_output/rooms_holoagent',
                       help='输出目录')
    args = parser.parse_args()
    
    print("=" * 70)
    print("HoloAgent 房间分割")
    print("=" * 70)
    
    print(f"\n加载点云：{args.global_pcd}")
    points, colors = load_pointcloud(args.global_pcd)
    print(f"  点云数量：{len(points):,}")
    
    print("\n楼层分割...")
    floor_levels = segment_floors_holoagent(points)
    
    if len(floor_levels) == 0:
        print("  未检测到楼层，使用全局高度范围")
        floor_levels = [{'zero_level': points[:, VERTICAL_AXIS].min(), 
                        'height': points[:, VERTICAL_AXIS].max() - points[:, VERTICAL_AXIS].min(),
                        'peak': points[:, VERTICAL_AXIS].max()}]
    
    for floor_idx, floor_data in enumerate(floor_levels):
        print(f"\n处理 Floor {floor_idx}...")
        
        floor_zero_level = floor_data['zero_level']
        floor_height = floor_data['height']
        
        floor_mask = (points[:, VERTICAL_AXIS] >= floor_zero_level) & (points[:, VERTICAL_AXIS] < floor_zero_level + floor_height)
        floor_points = points[floor_mask]
        
        print(f"  Floor 点云：{len(floor_points):,} 点")
        
        room_save_path = os.path.join(args.output_dir, f"floor_{floor_idx}")
        rooms = segment_rooms_holoagent(floor_points, floor_zero_level, floor_height, room_save_path)
        
        rooms_output_dir = os.path.join(args.output_dir, f"floor_{floor_idx}_rooms")
        save_rooms(rooms, rooms_output_dir)
    
    print("\n" + "=" * 70)
    print("完成!")
    print("=" * 70)


if __name__ == '__main__':
    main()
