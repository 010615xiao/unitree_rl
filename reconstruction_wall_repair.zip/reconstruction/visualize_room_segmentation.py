#!/usr/bin/env python3
"""
可视化房间分割结果：俯视图 + Voronoi 图 + 分割叠加图
"""

import numpy as np
import open3d as o3d
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scipy.spatial import Voronoi, voronoi_plot_2d
import json
import argparse
from pathlib import Path


# 默认输出目录
BASE_DIR = Path(__file__).parent
DEFAULT_OUTPUT_DIR = BASE_DIR / "unified_output" / "top_view"


def load_point_cloud(pcd_path):
    """加载点云并返回 XYZ 和颜色"""
    pcd = o3d.io.read_point_cloud(pcd_path)
    points = np.asarray(pcd.points)
    colors = np.asarray(pcd.colors)
    if len(colors) == 0:
        colors = np.ones_like(points) * 0.5
    return points, colors


def create_top_view(points, colors, resolution=1000, height_range=None):
    """创建俯视图（XZ 平面投影）- 使用原始点云不采样"""
    if height_range is None:
        height_range = (points[:, 1].min(), points[:, 1].max())

    # 只取一定高度范围内的点（地面附近 + 墙面）
    mask = (points[:, 1] >= height_range[0] - 0.5) & \
           (points[:, 1] <= height_range[0] + 2.5)
    proj_points = points[mask][:, [0, 2]]  # XZ 平面
    proj_colors = colors[mask]

    print(f"    投影点：{len(proj_points):,} 点 (原始点云)")

    # 创建 2D 直方图
    x_min, z_min = proj_points.min(axis=0)
    x_max, z_max = proj_points.max(axis=0)

    # 使用 bincount 加速计算（完全向量化）
    x_bins = np.linspace(x_min, x_max, resolution + 1)
    z_bins = np.linspace(z_min, z_max, resolution + 1)

    # 分配点到 bin
    x_idx = np.clip(np.digitize(proj_points[:, 0], x_bins) - 1, 0, resolution - 1)
    z_idx = np.clip(np.digitize(proj_points[:, 1], z_bins) - 1, 0, resolution - 1)

    # 创建密度图和颜色图 - 使用 bincount 向量化
    # 注意：numpy 数组 [行，列] = [z, x]，因为 imshow 第一个维度是纵轴
    # 翻转 z_idx 使得从上方往下看（Z 最大值在下方，符合从上往下的视角）
    z_idx_flipped = (resolution - 1) - z_idx
    flat_idx = z_idx_flipped * resolution + x_idx

    # 计算每个 bin 的点数
    count_img = np.bincount(flat_idx, minlength=resolution*resolution)
    count_img = count_img.reshape(resolution, resolution)

    # 计算每个 bin 的颜色和
    color_sum = np.zeros((resolution * resolution, 3))
    np.add.at(color_sum, flat_idx, proj_colors)
    color_sum = color_sum.reshape(resolution, resolution, 3)

    # 平均颜色
    mask_2d = count_img > 0
    density_img = np.zeros((resolution, resolution, 3))
    density_img[mask_2d] = color_sum[mask_2d] / count_img[mask_2d][:, np.newaxis]

    return density_img, (x_min, x_max, z_min, z_max)


def plot_voronoi_with_rooms(ax, room_centers, room_bboxes, bounds, colors=None):
    """绘制 Voronoi 图和房间边界"""
    x_min, x_max, z_min, z_max = bounds

    # 生成 Voronoi 图
    vor = Voronoi(room_centers)

    # 绘制 Voronoi 图
    voronoi_plot_2d(vor, ax, show_vertices=False, line_colors='gray',
                    line_width=1, line_alpha=0.5, point_size=0)

    # 绘制房间中心
    if colors is None:
        colors = plt.cm.tab10(np.linspace(0, 1, len(room_centers)))

    ax.scatter(room_centers[:, 0], room_centers[:, 1],
               c=colors[:, :3], s=100, edgecolors='black',
               linewidths=1.5, zorder=5, label='Room centers')

    # 绘制房间边界框
    for i, (center, bbox) in enumerate(zip(room_centers, room_bboxes)):
        # 从房间点云计算实际边界
        if 'points' in bbox and len(bbox['points']) > 0:
            pts = np.array(bbox['points'])[:, [0, 2]]
            rect = plt.Rectangle(
                pts.min(axis=0),
                *(pts.max(axis=0) - pts.min(axis=0)),
                fill=True, alpha=0.3, color=colors[i, :3],
                linewidth=2, edgecolor='black'
            )
            ax.add_patch(rect)

        # 标注房间编号
        ax.annotate(f'R{i}', center, fontsize=9, ha='center', va='center',
                   fontweight='bold', color='white',
                   bbox=dict(boxstyle='round', facecolor='black',
                            alpha=0.7, pad=0.3))

    ax.set_xlim(x_min, x_max)
    ax.set_ylim(z_max, z_min)  # 反转 Y 轴，与俯视图 origin='lower' 一致
    ax.set_aspect('equal')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Z (m)')
    ax.set_title('Voronoi Diagram + Room Boundaries')
    ax.grid(True, alpha=0.3)

    return ax


def plot_segmentation_overlay(ax, points, room_labels, room_centers, bounds,
                               alpha=0.6):
    """在俯视图上叠加房间分割结果"""
    x_min, x_max, z_min, z_max = bounds

    # 为每个房间分配颜色
    n_rooms = len(room_centers)
    cmap = plt.cm.tab10(np.linspace(0, 1, n_rooms))

    # 创建散点图
    scatter = ax.scatter(points[:, 0], points[:, 1],
                         c=room_labels, cmap='tab10',
                         s=1, alpha=alpha, edgecolors='none')

    # 绘制房间中心
    ax.scatter(room_centers[:, 0], room_centers[:, 1],
               c='red', s=150, marker='x',
               linewidths=3, zorder=10, label='Room centers')

    ax.set_xlim(x_min, x_max)
    ax.set_ylim(z_max, z_min)  # 反转 Y 轴，与俯视图 origin='lower' 一致
    ax.set_aspect('equal')
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Z (m)')
    ax.set_title('Room Segmentation Overlay')
    ax.grid(True, alpha=0.3)
    ax.legend()

    return ax


def assign_points_to_rooms(points, room_centers):
    """将点分配到最近的房间中心"""
    points_2d = points[:, [0, 2]]
    # room_centers 已经是 2D 的 (X, Z)
    centers_2d = room_centers

    # 计算每个点到所有房间中心的距离
    dists = np.linalg.norm(points_2d[:, np.newaxis] - centers_2d, axis=2)
    labels = np.argmin(dists, axis=1)

    return labels


def generate_top_view_visualization(points, colors, rooms, output_dir, resolution=1000):
    """
    生成俯视图可视化（可被其他脚本调用）

    参数:
        points: 点云坐标 (N, 3)
        colors: 点云颜色 (N, 3)，范围 0-1 或 0-255（自动检测并归一化）
        rooms: 房间列表，每个房间包含 center, bbox, area 等信息
        output_dir: 输出目录路径
        resolution: 图像分辨率（像素数量）

    返回:
        生成的文件路径列表
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True, parents=True)

    # 自动检测颜色范围并归一化到 0-1
    colors = np.asarray(colors, dtype=np.float32)
    if colors.max() > 1.0:
        colors = colors / 255.0
        print(f"    检测到颜色范围 0-255，已归一化到 0-1")

    print("=" * 60)
    print("生成俯视图可视化")
    print("=" * 60)

    # 提取房间中心和边界
    room_centers = np.array([[r['center'][0], r['center'][2]] for r in rooms])
    room_bboxes = []
    for r in rooms:
        if 'bbox' in r:
            bbox_min = np.array(r['bbox']['min'])
            bbox_max = np.array(r['bbox']['max'])
            room_bboxes.append({'points': np.array([bbox_min, bbox_max])})
        else:
            room_bboxes.append({})
    
    # 创建俯视图
    print("\n[1] 创建俯视图...")
    density_img, bounds = create_top_view(points, colors, resolution=resolution)
    x_min, x_max, z_min, z_max = bounds
    print(f"    范围：[{x_min:.2f}, {z_min:.2f}] ~ [{x_max:.2f}, {z_max:.2f}]")
    
    # 将点分配到房间
    print("\n[2] 分配点到房间...")
    room_labels = assign_points_to_rooms(points, room_centers)
    
    # 创建可视化
    print("\n[3] 生成可视化...")
    
    # 1. 组合图（4个子图）
    fig = plt.figure(figsize=(20, 5))
    
    # 子图 1: 原始俯视图
    ax1 = fig.add_subplot(141)
    ax1.imshow(density_img, origin='lower',
               extent=[x_min, x_max, z_min, z_max])
    ax1.set_xlabel('X (m)')
    ax1.set_ylabel('Z (m)')
    ax1.set_title('Top View (XZ Projection)')
    ax1.set_aspect('equal')
    ax1.grid(True, alpha=0.3)
    
    # 子图 2: Voronoi 图 + 房间边界
    ax2 = fig.add_subplot(142)
    plot_voronoi_with_rooms(ax2, room_centers, room_bboxes, bounds)
    
    # 子图 3: 分割叠加图
    ax3 = fig.add_subplot(143)
    height_mask = (points[:, 1] >= -2.0) & (points[:, 1] <= 1.0)
    plot_segmentation_overlay(ax3, points[height_mask][:, [0, 2]],
                              room_labels[height_mask], room_centers, bounds)
    
    # 子图 4: 房间面积统计
    ax4 = fig.add_subplot(144)
    areas = [r['area'] for r in rooms]
    room_ids = range(len(rooms))
    bars = ax4.bar(room_ids, areas, color=plt.cm.tab10(np.linspace(0, 1, len(rooms))))
    ax4.set_xlabel('Room ID')
    ax4.set_ylabel('Area (m²)')
    ax4.set_title('Room Areas')
    ax4.set_xticks(room_ids)
    ax4.grid(True, alpha=0.3, axis='y')
    
    for bar, area in zip(bars, areas):
        ax4.annotate(f'{area:.1f}',
                     xy=(bar.get_x() + bar.get_width() / 2, bar.get_height()),
                     xytext=(0, 3), textcoords="offset points",
                     ha='center', va='bottom', fontsize=9)
    
    plt.tight_layout()
    combined_file = output_dir / "top_view_combined.png"
    plt.savefig(combined_file, dpi=150, bbox_inches='tight')
    print(f"    组合图：{combined_file}")
    plt.close(fig)
    
    # 2. 单独保存俯视图
    fig_top = plt.figure(figsize=(12, 10))
    ax_top = fig_top.add_subplot(111)
    ax_top.imshow(density_img, origin='lower',
                  extent=[x_min, x_max, z_min, z_max])
    ax_top.set_xlabel('X (m)', fontsize=14)
    ax_top.set_ylabel('Z (m)', fontsize=14)
    ax_top.set_title('Top View (XZ Projection)', fontsize=16)
    ax_top.set_aspect('equal')
    ax_top.grid(True, alpha=0.3)
    plt.tight_layout()
    
    topview_file = output_dir / "top_view.png"
    plt.savefig(topview_file, dpi=300, bbox_inches='tight')
    print(f"    俯视图：{topview_file}")
    plt.close(fig_top)
    
    # 3. 单独保存 Voronoi 图
    fig2, ax = plt.subplots(figsize=(12, 10))
    plot_voronoi_with_rooms(ax, room_centers, room_bboxes, bounds)
    plt.tight_layout()
    
    voronoi_file = output_dir / "top_view_voronoi.png"
    plt.savefig(voronoi_file, dpi=150, bbox_inches='tight')
    print(f"    Voronoi 图：{voronoi_file}")
    plt.close(fig2)
    
    # 4. 单独保存分割叠加图
    fig3, ax = plt.subplots(figsize=(12, 10))
    height_mask = (points[:, 1] >= -2.0) & (points[:, 1] <= 1.0)
    plot_segmentation_overlay(ax, points[height_mask][:, [0, 2]],
                              room_labels[height_mask], room_centers, bounds)
    plt.tight_layout()
    
    overlay_file = output_dir / "top_view_segmentation_overlay.png"
    plt.savefig(overlay_file, dpi=150, bbox_inches='tight')
    print(f"    分割叠加图：{overlay_file}")
    plt.close(fig3)
    
    print("\n" + "=" * 60)
    print("完成！")
    print("=" * 60)
    
    return [combined_file, topview_file, voronoi_file, overlay_file]


def main():
    parser = argparse.ArgumentParser(description='可视化房间分割')
    parser.add_argument('--pcd', type=str, 
                        default='unified_output/global/global_pointcloud.ply',
                        help='全局点云文件')
    parser.add_argument('--scene-graph', type=str,
                        default='unified_output/scene_graph.json',
                        help='场景图 JSON 文件')
    parser.add_argument('--output-dir', type=str,
                        default=str(DEFAULT_OUTPUT_DIR),
                        help='输出目录路径')
    parser.add_argument('--resolution', type=int, default=1000,
                        help='俯视图分辨率（像素数量）')
    args = parser.parse_args()
    
    # 加载点云
    print(f"\n[加载点云] {args.pcd}")
    points, colors = load_point_cloud(args.pcd)
    print(f"    {len(points):,} 点")
    
    # 加载场景图
    print(f"\n[加载场景图] {args.scene_graph}")
    with open(args.scene_graph, 'r') as f:
        scene_graph = json.load(f)
    
    rooms = scene_graph['rooms']
    print(f"    {len(rooms)} 个房间")
    
    # 生成可视化
    generate_top_view_visualization(points, colors, rooms, args.output_dir, args.resolution)


if __name__ == '__main__':
    main()